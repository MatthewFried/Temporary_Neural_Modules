# CoP preservation bundle — 19 November 2026

This supplements the user's v72 GitHub code backup. It preserves the report exports and manuscript work available in this session. It is not a complete raw-experiment backup and does not assert that these files are absent from GitHub; that repository has not been inspected.

## Start here

- `manuscript/pakdd/paper.tex` and `paper.pdf`: current 12-page paper, with the approved concise abstract and revised introduction from this conversation. These are the authoritative manuscript versions in this bundle.
- `current_overleaf/CoP_Overleaf_Files.zip`: the matching three-file Overleaf upload (paper.tex, references.bib, swap.pdf).
- `manuscript/evidence/`: draw/seed operands, state subsets, diagnostic rows, contrast inventory, descriptive calculations and source hashes used for the paper.
- `manuscript/pakdd/check_numbers.py`: arithmetic and manuscript-number checks; `NUMERICAL_AUDIT.json` is the recorded result.
- `reports_original/`: byte-for-byte copies of the uploaded v70 reanalysis, v71 closeout and v72 closeout ZIPs. Preserve all three: v70 contains broader state/diagnostic exports; the closeout packages contain final registry/export checks and figures. Each archive retains its original internal paths.
- `REPORT_ARCHIVE_INDEX.csv`: every report archive member, size and SHA-256.
- `notes/CoP_v70_Closeout_for_Claude.txt`: the available local closeout review.
- `historical/` and `manuscript/extended/`: earlier source packages, draft/Word material and revision history. They are for reference, not the latest submission. Root-level manuscript.md/manuscript.tex and prose readmes under manuscript are also earlier extended drafts. Some old scripts contain original workspace paths and need adaptation before rerunning.

## Recheck or rebuild

From this bundle's root, in a Python environment with numpy, pandas and scipy:

```sh
python manuscript/pakdd/check_numbers.py
```

This uses the bundled evidence only; it does not rerun training or revalidate checkpoints. To regenerate the figure also install matplotlib, then run `python manuscript/pakdd/make_figure.py`. To compile the paper with a normal TeX installation, run `bash manuscript/pakdd/build.sh`. The LNCS class and bibliography style are included. The old Word/export scripts are retained for provenance and have not been made portable here.

## Still preserve on the lab machine

The full trained checkpoints, optimizer/RNG states, dataset caches and split assignments, original per-run logs/configurations, manifests, and environment/package/CUDA records are not included here. Keep the original result directories used by v72 and their upstream dependencies, not just the final closeout folder. Code on GitHub plus this archive is sufficient to inspect the manuscript tables, but is not sufficient for every checkpoint-based intervention or diagnostic.

The uploaded v70 archive itself explicitly omitted these large tables (see its `skipped_large_files.json`):

- fork29_contrasts.csv
- fork31_contrasts.csv
- fork31_contrasts_by_draw.csv
- fork31_states_by_draw.csv
- image30_contrasts.csv

Back those up from the original results if available. No full model-weight files were found in the local review trees inspected for this bundle. Older v70/v71 code ZIPs are not duplicated here because this bundle focuses on evidence accompanying the user's v72 code backup. If exact historical reruns are needed, retain their code versions too.

`notes/other_CoP_files_inventory.json` lists additional CoP items found in the recent file inventory, including earlier reports and review notes. They are references only, not included bytes; this is not an exhaustive inventory of the entire project. A complete conversation transcript is not included.

## Integrity

`FILES.json` records each included payload's size, SHA-256 and available source path. `SHA256SUMS.txt` covers every other file, including FILES.json. Run `sha256sum -c SHA256SUMS.txt` from the extracted bundle root. Report archive CRCs and all indexed member hashes were checked while packaging.
