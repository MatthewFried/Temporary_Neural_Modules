"""Make an editable reading copy of the LNCS paper. PDF remains the layout master."""
from pathlib import Path
import re, subprocess, sys
R=Path(__file__).resolve().parent
def run(*args): subprocess.run(args,cwd=R,check=True)
s=(R/'paper.tex').read_text()
bbl=(R/'paper.bbl').read_text()
refs=re.split(r'\\bibitem\{([^}]+)\}',bbl)[1:]
refmap={refs[i]:i//2+1 for i in range(0,len(refs),2)}
aux=(R/'paper.aux').read_text()
labels=dict(re.findall(r'\\newlabel\{([^}]+)\}\{\{([^}]+)\}',aux))
s=re.sub(r'\\cite\{([^}]+)\}',lambda m:'['+', '.join(str(refmap[k]) for k in m[1].split(','))+']',s)
s=re.sub(r'\\(?:eqref|ref)\{([^}]+)\}',lambda m:('('+labels[m[1]]+')') if m[0].startswith('\\eqref') else labels[m[1]],s)
abstract=s.split('\\begin{abstract}')[1].split('\\keywords')[0]
s=s.split('\\section{Introduction}')[1].split('\\bibliographystyle')[0]
s='\\section*{Abstract}\n'+abstract+'\n\\section{Introduction}'+s
s=s.replace('{swap.pdf}','{swap.png}')
s=re.sub(r'\\paragraph\{([^}]+)\}',r'\\noindent\\textbf{\1} ',s)
s=re.sub(r'\\multicolumn\{2\}\{l\}\{\\textit\{([^}]+)\}\}',r'\\textit{\1} & {}',s)
s=re.sub(r'\$(-?[\d.]+)\\ \[(-?[\d.]+),(-?[\d.]+)\]\$',r'\1 [\2, \3]',s)
# Preserve display labels in Word: Pandoc otherwise drops equation numbering.
def equation(m):
    body=m[1]
    lab=re.search(r'\\label\{([^}]+)\}',body)
    body=re.sub(r'\\label\{[^}]+\}','',body)
    return '\\['+body+'\\qquad\\text{('+labels[lab[1]]+')}\\]'
s=re.sub(r'\\begin\{equation\}(.*?)\\end\{equation\}',equation,s,flags=re.S)
for name, prefix in [('table','Table'),('figure','Figure')]:
    # Read the label to number captions consistently with the typeset paper.
    def cap(m):
        body=m[0];label=re.search(r'\\label\{([^}]+)\}',body)
        if label: body=body.replace('\\caption{','\\caption{'+prefix+' '+labels[label[1]]+'. ',1)
        return body
    s=re.sub(r'\\begin\{'+name+r'\}.*?\\end\{'+name+r'\}',cap,s,flags=re.S)
s+='\n\\section*{References}\n'
for i in range(0,len(refs),2):
    content=refs[i+1].split('\\end{thebibliography}')[0].strip()
    content=re.sub(r'\\doi\{([^}]+)\}',r'\\url{https://doi.org/\1}',content)
    s+='\n['+str(refmap[refs[i]])+'] '+content+'\n\n'
(R/'word_input.tex').write_text(s)
run(sys.executable,'style_docx.py','reference')
run('pandoc','word_input.tex','-f','latex','--standalone',
    '--metadata','title=How Temporary Neural Modules Change the Retained Network',
    '--number-sections','--reference-doc=reference.docx','-o','CoP_Manuscript.docx')
run(sys.executable,'style_docx.py','final')
