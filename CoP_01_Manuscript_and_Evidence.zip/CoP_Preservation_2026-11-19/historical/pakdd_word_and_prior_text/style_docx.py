from pathlib import Path
from copy import deepcopy
import sys
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT

root=Path(__file__).resolve().parent
mode=sys.argv[1] if len(sys.argv)>1 else 'reference'
doc=Document() if mode=='reference' else Document(root/'CoP_Manuscript.docx')
sec=doc.sections[0]
sec.page_width=Inches(8.5);sec.page_height=Inches(11)
sec.top_margin=sec.bottom_margin=Inches(.75)
sec.left_margin=sec.right_margin=Inches(.8)
for name in ['Normal','Body Text','First Paragraph']:
    if name in doc.styles:
        s=doc.styles[name];s.font.name='Times New Roman';s.font.size=Pt(11)
        s.font.color.rgb=RGBColor(0,0,0)
        s.paragraph_format.line_spacing=1.08;s.paragraph_format.space_after=Pt(5)
        s.paragraph_format.widow_control=True
for name,size in [('Title',21),('Subtitle',11),('Heading 1',15),('Heading 2',13),('Heading 3',11.5),('Heading 4',11)]:
    s=doc.styles[name];s.font.name='Times New Roman';s.font.size=Pt(size);s.font.color.rgb=RGBColor(0,0,0)
    s.font.bold=name.startswith('Heading') or name=='Title'
    s.paragraph_format.space_before=Pt(12 if name.startswith('Heading') else 0)
    s.paragraph_format.space_after=Pt(6)
    s.paragraph_format.keep_with_next=True
for name in ['Caption','Image Caption','Table Caption']:
    if name in doc.styles:
        s=doc.styles[name];s.font.name='Times New Roman';s.font.size=Pt(9.5);s.font.color.rgb=RGBColor(0,0,0)
        s.paragraph_format.space_after=Pt(8);s.paragraph_format.line_spacing=1.0
if mode=='reference':
    fp=sec.footer.paragraphs[0];fp.alignment=WD_ALIGN_PARAGRAPH.CENTER
    field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');fp._p.append(field)
    doc.save(root/'reference.docx')
else:
    for el in doc.styles.element.xpath('.//w:pBdr'):
        el.getparent().remove(el)
    for el in doc._element.xpath('.//w:pBdr'):
        el.getparent().remove(el)
    # Citation text remains editable; the PDF retains clickable citation links.
    for el in doc._element.xpath('.//w:hyperlink'):
        for child in list(el):
            el.addprevious(child)
        el.getparent().remove(el)
    # Rebuild Pandoc's table containers for portable Word/LibreOffice layout.
    for old in list(doc.tables):
        new=doc.add_table(rows=len(old.rows),cols=len(old.columns))
        for ri,row in enumerate(old.rows):
            for ci,cell in enumerate(row.cells):
                target=new.cell(ri,ci)
                target.paragraphs[0].clear()
                for pi,paragraph in enumerate(cell.paragraphs):
                    dest=target.paragraphs[0] if pi==0 else target.add_paragraph()
                    for child in paragraph._p:
                        if child.tag!=qn('w:pPr'):
                            dest._p.append(deepcopy(child))
        old._tbl.addprevious(new._tbl)
        old._tbl.getparent().remove(old._tbl)
    for t in doc.tables:
        t.autofit=False
        cols=len(t.columns)
        first=t.cell(0,0).text
        if cols==2:
            widths=[4.7,2.1]
        elif cols==5:
            widths=[.7,1.5,1.6,1.6,1.4]
        elif cols==4:
            if first=='Contrast':widths=[3.45,1.85,.85,.65]
            elif first=='Setting and endpoint':widths=[2.9,1.2,1.4,1.3]
            elif first=='Fork and continuation':widths=[2.6,1.6,1.3,1.3]
            else:widths=[1.1,1.65,2.5,1.55]
        elif cols==3:widths=[3.5,2.4,.9]
        elif cols==6:
            widths=[2.0,.85,1.0,.85,1.0,1.1] if first=='State' else [1.25,.85,.85,.8,1.35,1.7]
        else:widths=[6.8/cols]*cols
        for i,col in enumerate(t.columns):col.width=Inches(widths[i])
        props=t._tbl.tblPr
        borders=OxmlElement('w:tblBorders')
        for edge in ['top','left','bottom','right','insideH','insideV']:
            e=OxmlElement('w:'+edge);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)
        props.append(borders)
        for ri,row in enumerate(t.rows):
            trpr=row._tr.get_or_add_trPr();ns=OxmlElement('w:cantSplit');trpr.append(ns)
            if ri==0 and trpr.find(qn('w:tblHeader')) is None:
                repeat=OxmlElement('w:tblHeader');trpr.append(repeat)
            for ci,cell in enumerate(row.cells):
                cell.width=Inches(widths[ci]);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
                tcpr=cell._tc.get_or_add_tcPr();margins=OxmlElement('w:tcMar')
                for side in ['top','left','bottom','right']:
                    e=OxmlElement('w:'+side);e.set(qn('w:w'),'70');e.set(qn('w:type'),'dxa');margins.append(e)
                tcpr.append(margins)
                if ri==0:
                    sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'EAEAEA');tcpr.append(sh)
                for p in cell.paragraphs:
                    p.paragraph_format.line_spacing=1.0;p.paragraph_format.space_after=Pt(2);p.paragraph_format.space_before=Pt(2)
                    p.alignment=WD_ALIGN_PARAGRAPH.LEFT if ci==0 else WD_ALIGN_PARAGRAPH.CENTER
                    for run in p.runs:run.font.size=Pt(9.5);run.font.bold=(ri==0)
    figure_number=0
    for p in doc.paragraphs:
        raw_style=p._p.pPr.style if p._p.pPr is not None else None
        if p._p.xpath('.//w:drawing'):
            p.paragraph_format.keep_with_next=True
        if raw_style in ['ImageCaption','Caption'] or p.style.name in ['Image Caption','Caption']:
            p.style=doc.styles['Caption']
            p.paragraph_format.space_after=Pt(8)
            figure_number+=1
            if not p.text.startswith('Figure '):
                run=p.add_run('Figure '+str(figure_number)+'. ')
                p._p.insert(1 if p._p.pPr is not None else 0,run._r)
            p.paragraph_format.keep_with_next=False
            for run in p.runs:
                run.font.size=Pt(9.5);run.font.bold=False
        if raw_style=='Bibliography' or p.style.name=='Bibliography':
            # Plain paragraph content avoids renderer artifacts at reference ends.
            content=p.text
            p.clear();p.add_run(content)
            p.style=doc.styles['Body Text']
            p.paragraph_format.left_indent=Inches(.2)
            p.paragraph_format.first_line_indent=Inches(-.2)
            p.paragraph_format.space_after=Pt(5)
            for run in p.runs:run.font.size=Pt(10)
    doc.save(root/'CoP_Manuscript.docx')
