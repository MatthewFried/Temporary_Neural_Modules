# What Temporary Modules Teach the Retained Network

Complete manuscript draft prepared from the verified v70 analyses and v72 closeout.

## Files

- `manuscript.md` is the editable master text, including methodology, results, discussion, limitations, complete contrast tables and validation appendices.
- `references.bib` contains 15 references checked against primary publication pages or author preprints on 17 November 2026.
- `manuscript.tex` is an editable LaTeX rendering with the bibliography resolved; `manuscript.md` plus `references.bib` retain citation keys for later venue conversion.
- `figures/` contains the four verified closeout figures.
- `evidence/` contains the 864 pair rows, registry checks, sensitivity table and final findings report. `contrast_inventory.json` maps paper labels to exact registry keys, metrics and signs.
- `evidence_map.md` links the methods and claims to their source records and states the novelty boundaries.
- `CoP_Manuscript.docx` and `CoP_Manuscript.pdf` are reading and editing copies.

No new experiments were run to prepare this manuscript. Numbers were taken from the frozen closeout; table labels were shortened for readability without changing their estimands.

This is a complete research draft, not a submission to a selected venue. The author list, affiliations, acknowledgments, public code URL, venue template and any required disclosure statements should be set by the authors before submission. The draft makes no unconditional priority claim and no assertion that the image study reproduces the synthetic benefit.

## Rebuild

From this folder, with Pandoc, XeLaTeX and Python with `python-docx` installed:

```sh
python build.py
```

The PDF is typeset with LaTeX; the Word document has the same text with visible equation labels and editable tables. `table_widths.lua` and `style_docx.py` control their respective layouts.

The full saved models and complete experimental code are not included in this compact manuscript package. Their identities and locations belong to the experimental release. The table builder uses the frozen v70 registry JSONs and is provided for provenance; the completed tables are already embedded in the master manuscript.

