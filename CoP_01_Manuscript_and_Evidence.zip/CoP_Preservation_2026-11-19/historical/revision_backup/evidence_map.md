# Evidence map and claim boundaries

## Central claim

The paper distinguishes the present forward contribution of temporary modules from their effect on what retained layers learn. It tests persistent effects on a specified first layer under controlled continuation and function-preserving reallocation. It does not claim to introduce expansion, gradient routing, folding or model stitching.

The main empirical novelty candidate is the conjunction of (a) shared-checkpoint routed versus ordinary continuation, (b) a branch swap preserving the current predictor, (c) a later component-performance interaction, and (d) continued compact training after exact folding, with the image reversal reported as a boundary.

## Results

All files below refer to the frozen v70 reports except the pair exports and final findings, which are the v72 closeout.

| Paper section | Record |
|---|---|
| 4.1 | `registry29.json`, `early_routing_improves_normalised_extraction`, `early_routing_worsens_the_complete_network` |
| 4.2 | `registry29.json`, `late_folding_retains_a_component_advantage`, `expansion_history_beats_compact_continuation`, `expansion_history_beats_reset_matched_compact`, `expansion_history_beats_compact_continuation_4U` |
| 4.2 compute | `fork29_compute.csv`, `image30_compute.csv`, A / snap_2500 / folded_reset; post-ancestor MAC ratios |
| 4.3 | `registry31.json`, `swap_changes_routed_learning`, `swap_under_routing`, `swap_under_ordinary_gradients`, `swap_changes_routed_learning_native` |
| 4.3 first update | `mech31_gradients.csv`, A / snap_1000 / swap / float64; 24 ancestors, medians |
| 4.4 | `registry31.json`, `shift_changes_routed_learning`; regrowth in `mech31_regrowth.csv`, A / snap_1000 / full shift |
| 4.5 | All 13 `registry30.json` contrasts; distinguishes five primary from eight secondary contrasts |
| 4.6 | B secondary rows from `registry29.json`; numerical evidence in `FINAL_FINDINGS.md` |
| Appendix C | All 36 results from `registry29.json`, `registry30.json`, `registry31.json`; exact mapping in `contrast_inventory.json` |
| Appendix D | `ref29_rows.csv`, `ref30_rows.csv`, `ref31_rows.csv`, `fork31_audits.csv`, `retrain*.json`, CPU/CUDA XML, v72 `tests72.xml`, `float64_sensitivity.csv` |

The four figures are unchanged PNGs from the verified v72 closeout. The table means, signs, intervals and draw counts are generated directly from the registries.

## Method definitions

Definitions were read from `cop_research_v71` and the actual frozen run manifests. The v72 manifest records the same hashes for the training files; v72 changes reporting only.

| Method | Source |
|---|---|
| MLP and image experiment composition, forks and controls | `cop/orchestration/wave13.py`, wave29_v62_panel, wave30_v65_image_panel, wave31_v65_mechanism_panel, wave32 reset controls; `view29_manifest.jsonl`, `view30_manifest.jsonl` |
| Synthetic generator | `cop/data/synthetic.py`, build_shortcut |
| Image task and effective sizes | `cop/data/images.py`, build_image_shortcut; `data30.txt` |
| CNN structure and fold-compatible receiver | `cop/graph/builders.py`, build_cnn_cut |
| Neutral branch insertion and mask placement | `cop/graph/edits.py`, add_branch; `cop/experiments/growth.py`, _t_specialized |
| Fixed random partitions | `cop/experiments/trajectory.py`, _setup_spec_partition and _spec_split |
| Ancestor selection | `cop/experiments/common.py`, Selector; `cop/experiments/trajectory.py`, run_baseline |
| Swap and redistribution algebra | `cop/graph/redistribute.py` |
| Extraction definitions | `audit_v5/tools/fork_continuation.py`, component_change.py and image_forks.py |
| Inference and declared contrast scope | `configs/v66_wave29_registry.json`, v66_image_registry.json, v66_mechanism_registry.json |

## Prior work and novelty boundaries

- Net2Net: function-preserving growth is established.
- ExpandNets and RepVGG: training-time expansion with algebraic contraction is established.
- Arora et al. and RepOptimizer: equal expressiveness does not imply equal optimization; changing training geometry is established.
- Gradient Routing and ERA: backward masks, expansion and ablation are established; the paper must also acknowledge their discussion of absorption.
- GRAM: auxiliary modules trained for removable capability profiles are established, including contemporary large-model evidence.
- Maini et al.: layer rewinding, retraining and example-tied localization are established.
- SimCLR: a disposable training head improving retained representations is established.
- Model stitching: combining early and later layers as an evaluative tool is established; successful stitching is not an information-equivalence certificate.
- Shortcut-learning and JTT: the paper does not claim a new competitive group-robustness method.

The literature search supports this specific positioning but cannot prove universal absence of prior work. Avoid a blanket “first to show temporary modules change representations” statement.

## Essential interpretation constraints

1. Most headline benefits are normalised-extraction benefits, not native-network improvements.
2. The immediate swap gradient difference follows algebraically from the routing rule. The later component outcome is the empirical contribution.
3. Folding preserves the first layer immediately by construction. Persistence is assessed after compact continuation, against explicit controls.
4. The ordinary-versus-routed comparison changes gradient exposure, not only direction.
5. The primary synthetic native-harm test is unresolved.
6. The primary full-shift interaction is unresolved; its secondary arm cannot promote it.
7. The image result is a reversal, not a successful beneficial replication.
8. Normalised extraction is recipient-dependent and uses known blocks; an image whole-filter secondary reduces the latter dependence.
9. Two late mechanism secondaries are conditional. No primary is excluded.
10. Analysis plans are internal, not public preregistrations. The familywise correction does not cover the entire exploratory history.

