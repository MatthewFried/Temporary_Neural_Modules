---
title: What Temporary Modules Teach the Retained Network
subtitle: Function preserving interventions in expanded neural networks
lang: en-US
bibliography: references.bib
link-citations: true
geometry:
  - letterpaper
  - margin=0.85in
fontsize: 11pt
colorlinks: true
linkcolor: black
urlcolor: blue
toc: false
---

## Abstract

A module can influence a neural network both through the computation it performs and through the learning it induces elsewhere. Removing the module measures its current contribution, but does not reveal how it changed the retained network during training. We study this distinction by inserting initially function-preserving branches, continuing training from shared checkpoints, and either retaining, swapping, or algebraically folding the branches into the backbone. We evaluate the resulting first layer in the original network, with its norms and bias restored to the original values, separately from the accuracy of the complete trained model. Across 12 synthetic-task draws with two optimizer seeds each, continued gradient routing reduces this extracted component's error by 1.76 percentage points relative to ordinary backpropagation. A late folded continuation retains a 3.07-point advantage over the original network and a 2.72-point advantage over a compact control matched for optimizer reset. Swapping branches while preserving the forward function produces a 1.81-point routing-by-swap interaction in subsequent component error. The corresponding image experiment reverses the beneficial effect: routing worsens extracted-component error by 12.51 points. These results support a controlled distinction between present computation and persistent effects on learning, while ruling out a general claim that routed expansion improves representations. Temporary modules provide experimental interventions for studying how a network acquires its components, even when those modules need not remain at inference.

## 1 Introduction

Suppose a small neural network is expanded by inserting additional branches. The insertion initially leaves every prediction unchanged. The larger network then trains, and the branches are eventually removed or folded into the original architecture. What has the intervention changed? A final accuracy comparison can show that the training procedure helped or hurt. It does not identify whether the additions learned useful computation themselves, changed the features learned by the original layers, or changed how those layers work together.

This distinction matters when temporary structure is used to train compact models or when modular structure is intended to make capabilities removable. A branch may be unnecessary for representing the final predictor yet have affected the route by which the backbone reached it. Conversely, a branch whose deletion causes substantial damage may be supporting a particular interface rather than providing computation that a compact model could never represent. The effect of deleting a component from a trained network and the effect of having trained with that component answer different questions.

Existing research supplies important parts of this picture. Net2Net preserves a network's function while changing its architecture [@chen2016net2net]. ExpandNets and RepVGG use training-time structure that can be contracted for inference [@guo2020expandnets; @ding2021repvgg]. Overparameterization can alter optimization even without increasing expressiveness [@arora2018optimization], and some benefits of structural reparameterization can instead be introduced through the optimizer [@ding2023repoptimizer]. These findings already establish that the parameterization used during training matters. A further accuracy improvement from temporary expansion would not, by itself, settle what the additions caused the retained layers to learn.

We address that question through controlled interventions inside an expansion trajectory. At a saved checkpoint, we continue the same network with ordinary or routed gradients, exchange the computations assigned to branches while preserving their sum, or fold affine additions into the receiving layer and continue compact training. We then measure a specified retained component in a fixed recipient: the learned first layer placed in the original network. Restoring the original norms and bias reduces a simple scaling explanation without fitting a new readout. Native accuracy is reported separately.

The principal finding is a persistent component effect whose sign depends on the setting. In the synthetic experiment, routing improves the normalised first-layer extraction, and a component advantage remains after folding and further compact training. A function-preserving branch swap changes the subsequent extracted component more under routing than under ordinary gradients. In the image experiment, the same general procedure harms both the extracted component and the complete network. The contrast between these outcomes is part of the result: preserving the initial predictor does not make an intervention neutral for learning, and a measurable influence on learning need not be useful.

Our contribution is an experimental decomposition of temporary modules' effects. Shared-checkpoint continuations separate ongoing routing from the state already learned; fixed-recipient extraction separates the retained component from the native downstream network; and function-preserving swaps test whether reallocating branch computation changes subsequent learning. The immediate gradient difference under routing follows from the update rule. The empirical contribution is its relationship to later component performance, its survival after compact continuation, and its failure to yield the same benefit in a second domain. We do not propose expansion, gradient routing, folding, or model stitching as new primitives.

## 2 Background and related work

### 2.1 Temporary capacity and optimization

Net2Net constructs function-preserving changes that permit deeper or wider networks to inherit a trained predictor [@chen2016net2net]. ExpandNets trains compact networks through linear overparameterization and contracts the added layers algebraically [@guo2020expandnets]. RepVGG similarly separates a multibranch training structure from a simple inference structure [@ding2021repvgg]. Dense–Sparse–Dense training changes the available parameters over training and returns to a dense architecture [@han2017dsd]. Together, these methods establish that the architecture used to learn a predictor need not be the architecture used to deploy it.

This phenomenon has an optimization interpretation. Arora et al. show that depth in linear networks can induce a preconditioning effect [@arora2018optimization]. RepOptimizer incorporates model-specific gradient transformations without retaining the corresponding training-time structure [@ding2023repoptimizer]. We therefore treat altered optimization as an expected consequence of expansion. Our question concerns the location and persistence of its effects: whether a specified retained layer changes usefully, whether that change remains after compact continuation, and whether forward-equivalent reallocations alter it.

### 2.2 Routing and localization

Gradient routing applies data-dependent masks during backpropagation. Cloud et al. use it to localize computation and introduce Expand, Route, Ablate for capability removal [@cloud2024routing]. Their discussion of absorption already concerns how computation in one region influences what is learned elsewhere. GRAM adds auxiliary modules during pretraining and selectively updates them to obtain capability profiles through module removal [@roland2026gram]. Maini et al. study memorization through gradient accounting, layer rewinding and retraining, and introduce example-tied dropout to influence its location [@maini2023memorization].

These are close precedents. Our distinction is the controlled comparison of later learning after branch computation is reassigned without changing the current predictor, together with extraction of a retained component and continuation after exact folding. We use fixed random example partitions rather than semantic forget/retain categories. The resulting study does not establish unlearning or capability isolation; it examines effects on the backbone that remain relevant when interpreting modular training.

### 2.3 Temporary heads and representation measurement

SimCLR demonstrates that a learned projection between a representation and its training objective can improve the representation evaluated downstream [@chen2020simclr]. This is a direct precedent for a module helping to train features that remain useful after the module is discarded. Our image panel includes a late nonlinear auxiliary-head arm as a related control, although it uses supervised classification rather than a contrastive objective.

Model stitching evaluates whether an early representation can support another model's later layers through a learned interface [@bansal2021stitching]. Our extraction is a restricted version of this idea: the recipient is the donor's own ancestor, neuron indices are retained, and no alignment layer is fitted. This restriction supports an intervention-specific interpretation but makes the result recipient-dependent. Smith et al. show that successful stitching can connect representations with substantially different information [@smith2025alignment]. Accordingly, our metric measures compatibility with a specified recipient, not an intrinsic quantity of information or a proof of semantic equivalence.

### 2.4 Shortcut settings as controlled test environments

Shortcut learning provides a setting in which training accuracy can conceal reliance on an unstable cue [@geirhos2020shortcut]. Group-robustness methods such as Just Train Twice target performance under such correlations [@liu2021jtt]. We use controlled shortcuts to create competing predictive signals and to define evaluation environments. We do not claim a competitive robustness algorithm: there is no comprehensive comparison with group-robustness methods, and an improvement on a shortcut-independent test set does not establish improved worst-group performance.

The contribution relative to these strands can be stated precisely. We evaluate the persistent effect of temporary internal branches on a fixed retained component, using shared-checkpoint forks and forward-equivalent changes to branch allocation. This combines established tools to answer a more specific causal question about the training procedure. Claims of universal novelty for expansion or of improved localization would exceed this contribution.

## 3 Methodology

### 3.1 Separate present contribution from training history

Let $f_0$ be a trained compact network, and let $h_\theta(x)$ denote the backbone representation at a chosen cut. We insert residual branches $b_{\phi_j}$ and write the merge as

$$z=h_\theta(x)+\sum_{j=1}^{J}b_{\phi_j}(h_\theta(x)). \tag{1}$$

Each new branch initially contributes zero, so insertion preserves the predictor. All branches participate in every forward pass. The principal branches are affine maps represented by two trainable affine factors with no intervening nonlinearity. Their factorization changes the training parameterization, while the merged affine computation remains foldable into the next layer.

Deleting branches from a fixed trained state measures the effect of replacing the sum in (1) by zero. A history comparison instead trains two descendants of the same ancestor and compares their retained components. Neither effect determines the other. In particular, algebraic foldability establishes representability by a compact network; it does not establish that compact training would have reached the same parameters or component performance.

### 3.2 Routing changes the backward computation

For training example $i$, branch $j$ receives a binary mask $m_{ij}$. The forward output remains $b_j(h_i)$, while its backward path is multiplied by $m_{ij}$. Equivalently, the implementation uses

$$\widetilde b_j(h_i)=m_{ij}b_j(h_i)+(1-m_{ij})\operatorname{sg}(b_j(h_i)), \tag{2}$$

where $\operatorname{sg}$ is the stop-gradient operator. The direct backbone path is never masked. If $\delta_i$ is the backward signal at the merge, the signal reaching its input is

$$g_i^{\mathrm{routed}}=\left[I+\sum_jm_{ij}J_j(h_i)\right]^\top\delta_i, \qquad
g_i^{\mathrm{ordinary}}=\left[I+\sum_jJ_j(h_i)\right]^\top\delta_i, \tag{3}$$

where $J_j$ is the branch Jacobian. Equation (3) describes the prescribed backward rule; the routed signal is generally not the ordinary derivative of the unchanged forward predictor.

Branches are added in pairs. A fixed random partition assigns approximately 95% of training examples to branch $a$ and the remainder to branch $b$. In the synthetic experiment the exact fraction matches the observed majority-group proportion, but membership is randomized rather than assigned by group. The image experiment fixes the fraction at 0.95. The same membership applies to each pair. Ordinary continuation releases these masks and passes each example's gradient through every branch. Thus ordinary and routed continuation differ in gradient exposure as well as in which branch Jacobians contribute; we do not interpret this comparison as isolating direction at fixed gradient magnitude.

### 3.3 Shared-checkpoint continuations

The expansion trajectory has two rounds of $U=2{,}000$ updates. A zero-output branch pair is inserted at the beginning of each round, at the same cut. We fork at 1,000 updates, when one pair is present, and at 2,500 updates, when two pairs are present. Forks keep the architecture present at their start unless they fold it; they do not perform the trajectory's later scheduled insertions. Every fork ends at a total of 4,000 updates since the selected ancestor, giving 3,000 or 1,500 continuation updates respectively.

The principal continuations are:

| Continuation | Added branches | Backpropagation | Optimizer at fork |
|:--|:--|:--|:--|
| Routed | Trainable | Fixed example masks retained | Reset |
| Ordinary | Trainable | Masks released | Reset |
| Frozen scaffold | Frozen at checkpoint | Masks released | Reset |
| Folded compact | Composed into receiving layer and removed | Ordinary | Reset |
| Routed carried | Trainable | Fixed example masks retained | Carried |

Fork comparisons share the saved state, minibatch stream, learning rate, training budget and input-freeze condition. A primary lineage leaves every backbone parameter trainable, denoted A. A secondary lineage, B, holds the first layer's shortcut-input weights at their ancestor values. B uses privileged knowledge of the feature layout and is not the basis of the main claim.

Compact controls continue the same ancestor for 4,000 updates, or for 8,000 updates as a longer-budget comparison. Separate compact controls reset the optimizer at the corresponding fork time. These controls distinguish additional training and optimizer reset from expansion history. Equal update counts do not imply equal computation; we report measured training multiply–accumulate counts separately.

### 3.4 Function-preserving interventions

**Branch swap.** Within each pair, exchange the complete affine-branch parameters while leaving example masks attached to their original branch slots. The sum of branch outputs is unchanged in exact arithmetic. Under ordinary backpropagation, the summed Jacobian is also unchanged at the edit. Under routing, the change in the signal at the cut for one pair is

$$g_i^{\mathrm{swap}}-g_i
=(m_{ia}-m_{ib})(J_b-J_a)^\top\delta_i. \tag{4}$$

Equation (4) supplies a transparent manipulation check. It does not predict the sign of a later generalization effect. The empirical test is whether the swap changes subsequent component performance differently under the two backward rules.

**Folding.** Write the aggregate branch map as $Mh+c$, so the receiving layer computes $W[(I+M)h+c]+b$. Replace it by

$$W_{\mathrm{fold}}=W(I+M),\qquad b_{\mathrm{fold}}=b+Wc. \tag{5}$$

Remove the branches and their masks, then continue ordinary training in the compact architecture. This preserves the current forward function in exact arithmetic but generally changes subsequent updates. Immediate preservation of the first layer is built into folding; the substantive test is the component's performance after further compact training relative to the specified controls.

**Redistribution without removal.** To move a fraction $t$ of the branch computation into the receiver, set $s=1-t$, scale branch outputs by $s$, and use

$$W'=W(I+M)(I+sM)^{-1},\qquad b'=b+Wc-sW'c, \tag{6}$$

when the inverse exists. The full-shift case $t=1$ leaves zero-output branches in place and trainable. It is therefore distinct from folding and deletion: the branches may grow again. Partial redistribution requires a conditioning check because casting the transformed parameters to float32 can change the predictor appreciably.

Swaps and redistributions also change the parameter configuration from which training proceeds. We therefore interpret the resulting interaction as a routing-by-reallocation effect on learning, not as identification of a unique backward path as its sole cause.

### 3.5 Extract the retained component into a fixed recipient

Write $f_0(x)=D_0(\sigma(W_0x+b_0))$, with all layers after the first included in $D_0$. Raw extraction evaluates $D_0(\sigma(W_tx+b_t))$ using a descendant's first layer. Neither the original downstream network nor a fitted interface is trained during this measurement.

For the primary normalised extraction, partition input coordinates into declared blocks $C_k$. For output unit $r$, set

$$\overline W_{t,r,C_k}
=\frac{\lVert W_{0,r,C_k}\rVert_2}{\lVert W_{t,r,C_k}\rVert_2}W_{t,r,C_k},\qquad
E_t(x)=D_0(\sigma(\overline W_tx+b_0)). \tag{7}$$

The implementation checks eligibility and norm restoration rather than silently accepting undefined or failed normalisations. For a convolutional first layer, a block includes all spatial kernel entries in its input-channel group. Synthetic blocks are label-generating, shortcut and noise coordinates; image blocks are RGB channels and the shortcut channel. A secondary image measure restores each output filter's overall norm without using this grouping.

Equation (7) removes blockwise per-unit magnitude differences and first-layer bias changes. Its error remains a joint property of the extracted layer and $D_0$. A lower error does not prove that the layer contains more information, transfers to arbitrary recipients, or learns a new semantic feature. Normalisation is a controlled intervention on the measurement, not a claim that the edited layer was the one used by the native network.

### 3.6 Experimental settings

The synthetic input is $x=(c,s,n)$, with 12 Gaussian label-generating coordinates, one shortcut coordinate and 12 Gaussian noise coordinates. A latent group $g$ has rare-group probability 0.05, and $y=\mathbf{1}\{w_g^\top c>0\}$ for independently sampled group-specific rule vectors. The group is not supplied as a predictor input. The shortcut is $s=2a-1+0.5\epsilon$, with $\epsilon\sim\mathcal N(0,1)$. In training and source validation, $a=y$ with probability 0.95. In the main test set, $a$ is independent of $y$. The model is a ReLU MLP with six hidden layers of width 128; the cut follows hidden layer 3. Each branch has internal width 32.

The image task uses eight CIFAR-10 classes [@krizhevsky2009cifar]: airplane, automobile, ship and truck versus cat, deer, dog and horse. The three RGB channels are standardised using training-subset statistics. A fourth, spatially constant channel carries the same noisy shortcut construction. The test images come from the official test split, with the shortcut independent of the label. No data augmentation is used. The CNN has two 32-channel $3\times3$ convolutional layers, max pooling, a 32-to-64 channel $1\times1$ receiving layer, a 64-channel $3\times3$ convolution, max pooling, global average pooling and a binary classifier. Hidden affine layers are followed by ReLU; there is no batch normalisation. The cut is after the first pooling operation. Affine branches act positionwise with internal width 32. The unpadded $1\times1$ receiver permits exact folding including image borders.

| Setting | Training examples | Source validation | Test examples | Ancestor training budget | Repetitions |
|:--|--:|--:|--:|--:|:--|
| Synthetic MLP | 4,096 | 2,048 | 8,192 | 4,000 updates | 12 draws × 2 seeds |
| CIFAR-derived CNN | 8,192 | 2,000 | 8,000 | 6,000 updates | 12 draws × 2 seeds |

All models use AdamW with learning rate $10^{-3}$, betas $(0.9,0.999)$, batch size 128, no weight decay, no clipping and a constant learning rate. Training uses float32. The ancestor is selected by minimum source-validation cross-entropy among declared checkpoints, retaining its complete training state. Descendant measurements use the fixed-budget checkpoints named in the analysis plan, not a checkpoint selected by test performance. The synthetic draws vary generated data and rule vectors. Image draws vary the sampled training data and shortcut realizations over a fixed underlying CIFAR split; they are not 12 independent image datasets.

### 3.7 Estimands and uncertainty

We report test-error differences in percentage points. Paired differences are first averaged over the two optimizer seeds within each draw, then summarised over 12 draws with Student $t$ intervals. The four primary synthetic contrasts use 98.75% intervals; the five primary image contrasts use 99% intervals; the two primary mechanism interactions use 97.5% intervals. These correspond to Bonferroni familywise 95% coverage within each panel. Secondary contrasts use unadjusted 95% intervals and do not replace unresolved primary tests.

For the swap, let $e_{r,s}$ be normalised-extraction error under routing condition $r$ and swap condition $s$. The primary interaction is

$$\Delta_{\mathrm{swap}}=(e_{\mathrm{routed,swap}}-e_{\mathrm{routed,base}})
-(e_{\mathrm{ordinary,swap}}-e_{\mathrm{ordinary,base}}). \tag{8}$$

A positive interaction means the swap increases component error more under routing. It does not mean that the swap is beneficial. We use the analogous interaction for full redistribution.

The work developed through earlier exploratory panels. The synthetic primary contrast plan was recorded while its replication panel was training, before its results were inspected; the image and mechanism plans were recorded before results from their panels existed. These were internal analysis plans, not public preregistrations. Later reset-matched controls are labelled secondary. Multiplicity adjustments apply to the stated families, not retrospectively to the entire exploratory program.

## 4 Results

### 4.1 Routing changes the extracted component without a resolved native benefit

At the early synthetic fork, routed continuation reduces normalised-extraction error by 1.76 points relative to ordinary continuation, with a 98.75% interval of [0.31, 3.21]. The difference is favourable in all 12 draw means. Both continuations begin at the same expanded checkpoint and use fresh optimizer states, so this contrast concerns the continued backward rule rather than initialisation or an optimizer-reset difference.

The corresponding native-error contrast is a 0.26-point increase under routing, with interval [−0.78, 1.31]. It is unresolved. Thus the replication supports a component advantage, but does not confirm the earlier exploratory suggestion that a better component is necessarily accompanied by worse native accuracy. The component metric and the complete-network metric must be interpreted separately.

![Early continuation effects in the two settings. Differences are routed minus ordinary error; negative values favour routing. Small points are draw means after averaging optimizer seeds. Bars use each panel's primary interval level. Normalised extraction evaluates an edited first layer inside the fixed ancestor.](figures/fig1_component_effects.png){width=95%}

### 4.2 The component advantage remains after folding and compact training

At the late synthetic fork, the folded compact continuation yields a 3.07-point extracted-component advantage over $f_0$, with primary interval [1.64, 4.50]. It also improves on the 4,000-update compact continuation by 3.02 points [1.57, 4.48]. Each comparison is favourable in all 12 draws.

Additional controls narrow the interpretation. Against the compact control with a reset at the same fork time, the advantage is 2.72 points [1.68, 3.77], favourable in 11 of 12 draws. Against 8,000 compact updates, it is 3.02 points [1.94, 4.10], favourable in all 12 draws. Both are secondary comparisons. These results argue against explaining the measured advantage solely by additional compact training or the presence of an optimizer reset.

The cost comparison is not exact matching. From the selected ancestor onward, the late folded synthetic path uses approximately 1.144 times the training MACs of the 4,000-update compact control and 0.572 times those of the 8,000-update control. The corresponding image ratios are 1.038 and 0.519. These counts exclude the ancestor training shared by the compared arms and do not measure wall-clock efficiency. We make no claim that expansion is the cheapest way to obtain the component.

Folding itself does not prove absorption or feature migration: it composes the current affine computation into the receiver. What the comparison establishes is that, after 1,500 further compact updates, the first-layer extraction still differs favourably from the specified compact histories. It remains possible that a different compact optimizer or training recipe could reproduce the effect.

![Late folded continuations compared with the ancestor and compact controls. Negative differences favour the folded history. Primary comparisons use the panel's adjusted intervals; reset-matched comparisons are secondary and use 95% intervals. All plotted outcomes are normalised extraction, not native accuracy.](figures/fig2_folding_controls.png){width=95%}

### 4.3 A forward-preserving swap changes later learning under routing

The early swap interaction is 1.81 points, with a 97.5% interval of [0.43, 3.19], positive in all 12 draws. Swapping branches increases extracted-component error by 1.73 points [0.67, 2.79] under routing. The ordinary-gradient swap contrast is −0.08 points [−0.26, 0.10] and is unresolved; both individual-arm intervals are secondary.

The intervention preserves the forward sum while changing which learned branch map is associated with each example partition. The positive interaction therefore supplies evidence that this association matters for later component performance. It is more specific than observing different endpoints from two independently trained expanded models.

The first-update diagnostic agrees with the algebra. Across the 24 ancestor instances, the median relative change of the first-layer gradient under an ordinary swap is $1.25\times10^{-15}$, while it is 0.856 under routed backpropagation. The median gradient cosine is 1 under ordinary gradients and 0.625 under routing; the median update cosine is 1 and 0.482 respectively. The routed distribution is heterogeneous, including near-opposite gradients, so the median does not describe every instance. These diagnostics verify that the edit changes the intended learning computation. The later error interaction, rather than the immediate gradient identity, is the empirical finding.

The corresponding native-error interaction is unresolved: 0.95 points [−1.79, 3.70]. Again, an effect detectable in the retained component need not appear as a resolved change in the final network's error. The experiment does not identify a unique semantic feature or prove that the changed upstream gradient is the only mediator of the long-run effect.

![Function-preserving branch swaps. The upper panel reports the routing-by-swap interaction and its individual arms in normalised-extraction error. The lower panels show first-update gradient diagnostics for 24 ancestor instances; horizontal lines mark medians. The primary interaction uses a 97.5% interval and the individual arms use 95% intervals.](figures/fig3_swap_mechanism.png){width=95%}

### 4.4 Full redistribution and regrowth do not establish necessity

The early full-shift interaction is 1.12 points [−0.08, 2.32] at its primary 97.5% level. It is unresolved. Although the routed full-shift arm alone has a secondary 95% interval just above zero, that comparison does not establish the planned interaction.

After the full shift, the branches start at zero output and can regrow. At the final recorded update, median net branch-output RMS divided by merge-input RMS is approximately 0.242 under routing and 0.0412 under ordinary gradients. The distribution spans several orders of magnitude. Regrowth shows that the available branches become active again; it does not show that their computation is indispensable, irreducible, or beneficial. The distinction between full shift and folding is essential because the former leaves trainable branches available.

### 4.5 The beneficial component effect reverses on images

In the image setting, early routed continuation increases normalised-extraction error by 12.51 points, with a 99% interval of [7.77, 17.25], and increases native error by 13.96 points [10.02, 17.90]. Both changes occur in the harmful direction in all 12 draws. The normalised component of the late folded continuation is worse than $f_0$ by 7.10 points [0.46, 13.75]. Its difference from the update-matched compact control is 6.49 points [−0.11, 13.10], which is unresolved at the primary level. Against the reset-matched compact control, the secondary difference is 6.99 points [2.63, 11.35], favouring the compact control.

This reversal is not confined to the blockwise normalisation. Restoring each output filter's overall norm, without separating RGB and shortcut channels, gives a 13.31-point routed disadvantage [9.94, 16.69] at the secondary level. Freezing the first layer's shortcut-channel weights also does not rescue the effect: the B lineage has a 14.55-point disadvantage [10.41, 18.70] in normalised extraction.

The end-of-expansion routed arm is worse than the late nonlinear-head arm by 12.09 points [4.87, 19.30] at the primary level. The head's own comparison with compact continuation is unresolved, with a 0.46-point advantage [−0.44, 1.36] at 95%. The head comparison changes placement, nonlinearity and routing together, so it does not identify which difference accounts for the result. It does show that the harmful routed image outcome should not be described as an unavoidable consequence of adding any temporary module.

The image result limits the generality of the synthetic benefit. Data, architecture and cut geometry change together, preventing attribution of the reversal to any one of them. The common finding is that temporary training structure can leave a measurable effect in the retained first layer. The direction of that effect is not stable across the tested settings.

### 4.6 Secondary findings and numerical validation

The synthetic B lineage reproduces an early normalised component advantage of 1.81 points [0.75, 2.87] and a raw-extraction advantage of 2.47 points [1.20, 3.75]. Because B uses the known shortcut location, these are mechanistic controls rather than evidence for a general method requiring no feature information. Appendix C reports all 36 planned contrasts, including the negative and unresolved results.

The final evaluation compares stored models against a separate raw-PyTorch reference, checks edited parameters and result-table agreement, and verifies checkpoint reproduction. All 8,016 applicable float64 function comparisons pass. Re-evaluating the 24 fully covered statistical hypotheses from float64 reference error counts changes none of their readings. Two numerical exceptions remain declared; neither affects a primary contrast. Two late mechanism secondaries are conditional on 23 of 24 draw–seed pairs. Appendix D gives the exceptions and the scope of the checks. Numerical repeatability supports the implementation audit, but does not broaden the scientific conclusions.

## 5 Discussion

### 5.1 What is learned from the intervention

The motivating question has two levels. First, can a temporary module affect a retained component? Existing work on overparameterization and temporary projection heads makes this plausible. Second, can we distinguish that effect from the module's current forward contribution and follow it after removal? The present experiments address this second level through coordinated interventions and component-specific measurement.

The branch swap is the clearest example. The same summed computation is available immediately before and after the edit, but the assignment of branch computations to backward routes changes. The later first-layer outcome changes correspondingly in the synthetic setting. The fold comparison then asks a different question: whether a component advantage remains once the expanded representation of the predictor has been removed and compact training resumes. Together these comparisons identify effects of the training history that an immediate deletion score alone would not measure.

This does not imply that training history is irrecoverably encoded or that the retained layer has become impossible to learn compactly. Nor does it contradict modular localization methods. It shows why a module's current predictive contribution and its influence on the rest of the network during training should be assessed separately when such methods are analysed.

### 5.2 Why the negative result belongs in the explanation

A useful component effect is not guaranteed by function preservation, exact folding, or a change in gradients. The image experiment makes this limitation substantial rather than hypothetical. Its degradation persists under an alternative normalisation and an input-freeze control. Treating that reversal as a boundary result keeps the paper's claim tied to what was measured: the intervention changes learning, and the value of the resulting change depends on the setting.

The native and extracted metrics also separate two meanings of improvement. An extracted layer can work better with its ancestor's later layers without yielding a resolved native advantage in its descendant. This is evidence about a specified component–recipient combination. It does not establish that the descendant contains a universally superior representation or that its downstream layers are necessarily compensating for damage.

### 5.3 Limitations

The experiments cover a controlled synthetic family and one CIFAR-derived binary task, with one architecture in each confirmatory setting. They do not establish scaling to transformers, performance on unmodified multiclass benchmarks, or worst-group robustness. The synthetic group-dependent labels also impose ambiguity when the latent group is not observable. The image uncertainty estimates are conditional on the fixed source dataset and split.

The primary normalised metric uses the declared input-block layout, even though the A training intervention does not freeze a known shortcut. The identity of the downstream recipient is another restriction. Affine folding concerns the tested graph structure; it is not a procedure for removing arbitrary nonlinear modules. The routed backward rule differs from ordinary differentiation, and releasing masks changes total branch gradient exposure. Full redistribution changes parameterization as well as gradient routing. None of these experiments establishes equivalence to, or superiority over, all possible compact optimizers.

Finally, the extensive exploratory development preceded the fixed comparison families. Within-family adjustments and new draws reduce particular selection concerns, but do not make the overall research process preregistered. The manuscript distinguishes the planned primary tests, later secondary controls and descriptive diagnostics for this reason.

## 6 Conclusion

Temporary modules are useful experimental tools for studying how a network learns its parts. In the synthetic setting, routed branches induce a measurable first-layer advantage that remains after folding and compact continuation. Reassigning branch computation while preserving the forward function changes subsequent component performance under routing. In the image setting, the same class of intervention is harmful. The evidence therefore supports a specific conclusion: the effect of a module on learning extends beyond its present forward contribution, and that effect can persist in the retained network without being uniformly beneficial.

## Appendix A Algebra and intervention scope

For affine branches $b_j(h)=B_j(A_jh+a_j)+b_j^{\mathrm{out}}$, the aggregate map is $M=\sum_jB_jA_j$ and $c=\sum_j(B_ja_j+b_j^{\mathrm{out}})$. Substitution into the receiving layer gives (5). For partial redistribution, the modified preactivation is $W'(I+sM)h+sW'c+b'$; inserting (6) reduces it to $W(I+M)h+Wc+b$. The construction requires $I+sM$ to be invertible. Full folding does not require that inverse.

For a swap, the sum $b_a(h)+b_b(h)$ and its ordinary derivative are unchanged. The routed derivative before the edit is $I+m_aJ_a+m_bJ_b$ and after it is $I+m_aJ_b+m_bJ_a$, giving (4). These are algebraic identities, not new general theorems about optimization. Floating-point evaluation can differ through summation order or parameter casting, which is why the implementation records separate precision checks.

A frozen affine scaffold is not generally equivalent to folded compact training. If the fixed scaffold is $z=Ah+c$, the receiver's effective compact weight is $WA$. Under SGD, with $G$ the compact weight gradient and $g_b$ its bias gradient, one expanded receiver update induces

$$\Delta(WA)=-\eta\left(GA^\top A+g_bc^\top A\right). \tag{9}$$

Direct compact SGD instead induces $-\eta G$. The offset term matters, and AdamW introduces additional coordinate-dependent state. Thus the frozen scaffold is a diagnostic arm, not a substitute for actual folding and compact continuation.

## Appendix B Implementation and evaluation details

The principal synthetic data draws are 349–360; image draws are 361–372. Each uses optimizer seeds 0 and 1. Mechanism forks reuse the synthetic ancestors and checkpoints, so they are not an additional independent replication of that dataset. All branches in a pair use the same input representation. The random partition is saved with the trajectory, and the direct residual path remains unmasked. New branch output factors start at zero while their input factors are initialized, making their initial forward contribution zero without preventing subsequent learning.

The ancestor selection rule evaluates declared candidates on source-validation cross-entropy, breaks ties in favour of the earlier checkpoint, and preserves the selected optimizer and data-stream state. Eight scheduled candidates are configured; the selection mechanism also supports the initial candidate. The fixed-budget endpoints analysed here are not replaced by validation-selected descendants. Compact reset controls carry the ancestor's optimizer to the specified fork time and then reset it before the remaining updates.

The synthetic test redraws the shortcut independently of the label. A separate reversed-correlation set and rare-group set exist in the experimental package, but are not substitutes for the primary test distribution. In the image task, all 8,000 official test images belonging to the eight selected classes are used; the effective count is 8,000 rather than the generic 8,192 test-size configuration field. Three disjoint validation subsets of 2,000 official training images are available, but the ancestor uses source validation. RGB normalization is fitted only on the selected training subset; the shortcut channel retains its specified raw scale.

For each scalar contrast, let $d_{so}$ be the paired value for draw $s$ and optimizer seed $o$. We compute $\bar d_s$ by averaging eligible seeds within a draw, then report $\bar d\pm t_{n-1,1-\alpha/2}\,s_d/\sqrt n$ over draw means. The two conditional late mechanism contrasts each omit the declared failed draw–seed state; the affected draw therefore contributes its one remaining eligible seed. These are not complete-pair estimates and are labelled conditional. No primary test uses this exception.

## Appendix C Complete contrast inventory

The following tables use the registry's favourable orientation. Positive values favour the named directional hypothesis. For two-sided mechanism contrasts, positive values mean increased extraction error under the stated edit or interaction, not a performance benefit. Primary intervals use the family-specific adjusted level; secondary intervals are 95%. “Unresolved” means the interval includes zero. All differences are percentage points.

### C1 Synthetic MLP

P denotes primary (98.75% intervals); S denotes secondary (95% intervals). Draw counts are the number of positive draw means. A dagger marks a conditional comparison with 23 eligible draw–seed pairs.

| Contrast | Difference and interval | Positive draws | Role |
|:--|--:|:--:|:--:|
| Early routing benefit in normalised extraction | +1.76 [+0.31, +3.21] | 12/12 | P |
| Early routing harm in native error | +0.26 [-0.78, +1.31] | 5/12 | P |
| Late folded benefit over ancestor | +3.07 [+1.64, +4.50] | 12/12 | P |
| Late folded benefit over compact 4,000 | +3.02 [+1.57, +4.48] | 12/12 | P |
| B early routing benefit in normalised extraction | +1.81 [+0.75, +2.87] | 10/12 | S |
| B early routing benefit in raw extraction | +2.47 [+1.20, +3.75] | 10/12 | S |
| B early routing harm in native error | -0.21 [-3.52, +3.10] | 3/12 | S |
| B late folded benefit in raw extraction | +3.75 [+2.30, +5.21] | 12/12 | S |
| Late folded benefit over compact 8,000 | +3.02 [+1.94, +4.10] | 12/12 | S |
| Late folded benefit over reset compact | +2.72 [+1.68, +3.77] | 11/12 | S |
| Early folded benefit over reset compact | +1.22 [+0.57, +1.88] | 10/12 | S |
| Early routed benefit over reset compact | +2.84 [+1.65, +4.02] | 12/12 | S |

### C2 CIFAR derived CNN

P denotes primary (99% intervals); S denotes secondary (95% intervals). Draw counts are the number of positive draw means. A dagger marks a conditional comparison with 23 eligible draw–seed pairs.

| Contrast | Difference and interval | Positive draws | Role |
|:--|--:|:--:|:--:|
| Early routing benefit in normalised extraction | -12.51 [-17.25, -7.77] | 0/12 | P |
| Early routing harm in native error | +13.96 [+10.02, +17.90] | 12/12 | P |
| Late folded benefit over ancestor | -7.10 [-13.75, -0.46] | 3/12 | P |
| Late folded benefit over compact 4,000 | -6.49 [-13.10, +0.11] | 3/12 | P |
| Routed expansion benefit over late head | -12.09 [-19.30, -4.87] | 1/12 | P |
| Early routing benefit with whole-filter norms | -13.31 [-16.69, -9.94] | 0/12 | S |
| Routed expansion benefit over ordinary expansion | -12.15 [-17.04, -7.26] | 0/12 | S |
| Late head benefit over compact | +0.46 [-0.44, +1.36] | 7/12 | S |
| B early routing benefit in normalised extraction | -14.55 [-18.70, -10.41] | 0/12 | S |
| B early routing benefit in raw extraction | -16.94 [-21.60, -12.28] | 0/12 | S |
| Late folded benefit over compact 8,000 | -6.62 [-11.12, -2.11] | 3/12 | S |
| Late folded benefit over reset compact | -6.99 [-11.35, -2.63] | 3/12 | S |
| Early routed benefit over reset compact | -12.86 [-16.50, -9.22] | 0/12 | S |

### C3 Function preserving mechanism interventions

P denotes primary (97.5% intervals); S denotes secondary (95% intervals). Draw counts are the number of positive draw means. A dagger marks a conditional comparison with 23 eligible draw–seed pairs.

| Contrast | Difference and interval | Positive draws | Role |
|:--|--:|:--:|:--:|
| Early swap interaction | +1.81 [+0.43, +3.19] | 12/12 | P |
| Early full-shift interaction | +1.12 [-0.08, +2.32] | 9/12 | P |
| Swap minus no swap under routing | +1.73 [+0.67, +2.79] | 12/12 | S |
| Swap minus no swap under ordinary gradients | -0.08 [-0.26, +0.10] | 5/12 | S |
| Half shift minus unedited under routing | +0.41 [-0.82, +1.64] | 5/12 | S |
| Full shift minus unedited under routing | +0.93 [+0.01, +1.86] | 9/12 | S |
| Early swap interaction in native error | +0.95 [-1.79, +3.70] | 6/12 | S |
| Late swap interaction † | +0.94 [+0.11, +1.78] | 10/12 | S |
| Late full-shift interaction † | +0.52 [-0.10, +1.14] | 10/12 | S |
| B early swap interaction in raw extraction | +2.47 [+0.89, +4.05] | 10/12 | S |
| Full shift minus unedited under ordinary gradients | -0.19 [-0.39, +0.01] | 4/12 | S |


![Regrowth after moving the entire affine branch map into the receiver. Thin curves correspond to individual ancestor instances; thick curves are medians. The initial zero is omitted from the logarithmic axis. These curves describe reuse of the branches, not their necessity.](figures/figS1_regrowth.png){width=85%}

## Appendix D Numerical validation and retained exceptions

The final report contains 8,016 reference rows: 2,808 synthetic, 2,808 image and 2,400 mechanism measurements. A separately implemented raw-PyTorch evaluator is compared with the graph implementation in float64 at a per-logit tolerance of $10^{-9}(1+|z|)$. All function comparisons pass. All applicable parameter, eligibility and table checks pass. Retraining 15 selected runs reproduces 114 saved checkpoints value by value. The training-validation record reports 1,248 CPU tests passed and 68 CUDA tests passed; the report-only closeout additionally records 37 passing tests. These counts are engineering evidence, not additional statistical samples.

One half-shift B fork on synthetic draw 349, seed 0, fails its saved-parameter function-preservation threshold: the recorded discrepancy is $1.21836\times10^{-5}$ against $10^{-5}$, with a transformation condition number of approximately $101{,}451$. Reproduction of the same result does not cancel the failure. No planned hypothesis reads that state.

A separate late A routed-reset state exceeds a first-order floating-point error estimate on one of 8,192 CPU-evaluated examples. The worst ratio is 57.11. Float64 implementation agreement passes; reference, CPU and GPU each make 4,047 classification errors. The state remains excluded from the two late mechanism secondary comparisons. Evaluating the affected example alone removes the observed discrepancy, and a sign change is recorded in an intermediate preactivation. These observations do not identify the cause of the exceedance.

The rounding calculation is an empirical first-order estimate, not a rigorous upper bound. It neglects higher-order terms, activation-pattern changes and transform-convolution algorithms, and uses float32 for the image calculation's local terms and Jacobians. It cannot replace the independent function comparison. Across the reference rows, float32 and float64 error counts differ by at most one example. All 24 fully covered hypotheses, including eight primary hypotheses, retain their statistical reading when recomputed from float64 counts. Contrasts involving unevaluated compact or late-head operands are explicitly outside that sensitivity check.

## Appendix E Reproducibility and evidence organization

The manuscript uses the frozen v70 analyses and the v72 closeout exports. Every reported hypothesis is associated with explicit operands, a draw and optimizer-seed identity, an eligibility decision and an exclusion reason. The complete exports comprise 864 planned draw–seed comparisons across 36 hypotheses. The mechanism data share ancestors with the synthetic panel; counts are not summed as independent runs or replications.

The accompanying manuscript source package includes the contrast exports, the final findings report, figure assets, bibliography and an evidence map linking manuscript claims to registry keys and implementation definitions. Full checkpoints remain in the experimental archive identified by the release manifest; they are not embedded in this manuscript package. All figures and tables use the fixed final analyses. No additional training was performed to prepare the paper.

## References

::: {#refs}
:::
