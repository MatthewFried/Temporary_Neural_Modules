# Author review of the PAKDD working draft

The paper asks what temporary modules change in retained layers, and what becomes of that change when their training intervention ends. The principal evidence is the shared-checkpoint continuation, the forward-preserving swap, and the comparison of the component before and after folded continuation.

## Venue requirements checked

The PAKDD 2027 Research Track requires anonymous Springer LNCS/LNAI format, a PDF of at most 12 pages including references and appendices, and an abstract of at most 200 words. The current draft uses the unmodified Springer class and bibliography style, with no margin, font-size or line-spacing compression. It is 11 pages. The conference currently lists December 4, 2026, 23:59 Anywhere on Earth as the extended Research Track deadline.

The author's kit also says generative AI may only be used for grammatical error correction and requires disclosure in the submission form. This project has used AI for substantive writing and analysis assistance. The current document is a working draft, not a determination of submission eligibility. Ask the programme chairs how that prior involvement should be handled before submission. Later human editing or a disclosure alone should not be assumed to satisfy the restriction. Preserve an accurate record of the assistance.

Official sources, checked November 17, 2026:

- https://pakdd2027.org/pages/calls/authors-kit
- https://www.pakdd2027.org/pages/calls/research
- https://www.pakdd2027.org/pages/dates
- https://ctan.org/pkg/llncs

The research-track page does not establish permission for an additional appendix outside the 12-page PDF. The extended manuscript and evidence files in this package are author materials. The short paper is self-contained and includes every planned primary contrast.

## Motivation and contribution

PAKDD lists technical quality, relevance, originality, significance and presentation quality as review criteria. The paper addresses reliable interpretation of modular neural training: output-based evaluation can miss how a training intervention changes a retained layer. The important empirical combination is a forward-preserving reassignment, its later component effect, the loss instability accompanying that effect, and its different continuation behaviour in the two settings.

The general idea that expansion changes optimization is established. So are gradient routing, auxiliary modules, algebraic folding, temporary projection heads and model stitching. The related-work section names these precedents, including Expand, Route, Ablate and GRAM. The manuscript claims a particular controlled investigation of retained-component dynamics. It makes no unconditional first-in-literature claim. Its contribution should be assessed as an empirical mechanism study, with moderate and bounded novelty, rather than as a new general-purpose learning algorithm.

## Reviews completed

1. **Research question and motivation.** Reorganized the paper around retained-layer changes and their continuation. Removed the suggestion that folding creates the reported synthetic advantage.
2. **Numerical review.** Independently recomputed all 36 planned contrasts from saved operand rows, the 11 additional descriptive comparisons from state exports, the six absolute-error rows, loss tails, gradient medians, regrowth and cost values. Verified all 11 primary estimates and adjusted intervals in the LaTeX table. The draw is the statistical unit; seeds are averaged within it. `NUMERICAL_AUDIT.json` records results and file hashes.
3. **Methods and interpretation.** Checked routing, swap symmetry, fold algebra, first-layer normalization and the image late-head definition against the available implementation. The image layout-free normalization is per output filter over all inputs; an older findings summary describes this imprecisely. The manuscript follows the code. No new training or saved-checkpoint execution was performed during this revision.
4. **Prose and consistency.** Removed overstated teaching and persistence language, shortened repeated qualifications, explained the first-layer choice, and kept normalization dependence, high routed loss and image damage in the main results.
5. **Layout.** Compiled with Springer LNCS, checked cross-references and citations, checked for overflowing text, and visually reviewed every PDF page. The Word file is an editable reading copy; the LaTeX PDF is the format master.

## What still needs author judgment

- Resolve the conference's AI policy before deciding to submit. Confirm author list and order before submission; remove identifying material from any separately supplied code or files.
- Read the mechanistic explanation as a supported interpretation. Swapping changes the routed update and later extraction score, but the experiments do not identify a unique dynamical cause of stability or generalization.
- Keep the scope clear: two controlled task/architecture settings, an ancestor-dependent component measure, and no broad robustness benchmark claim. Architecture, data and optimization state change together in the image comparison.
- The unresolved raw synthetic effect and the near-stationary ordinary regime are substantive limitations. Reframing cannot turn them into broad feature-learning or robust-retention evidence.
- The full experimental code and checkpoints are outside this manuscript package. Decide on an anonymous reproducibility release separately; do not promise a public artifact that has not been prepared.

The arithmetic review supports the reported numbers. It cannot certify every training-code path or guarantee novelty or acceptance. The useful remaining author work is to sharpen the scientific argument and confirm that these bounded claims are the ones the authors intend to defend.
