"""Recompute manuscript contrasts from exported operand/state rows. No model runs."""
from pathlib import Path
import json, re, hashlib
import numpy as np
import pandas as pd
from scipy.stats import t

ROOT = Path(__file__).resolve().parent
E = ROOT.parent / 'evidence'
inv = json.loads((E / 'contrast_inventory.json').read_text())
paper = (ROOT / 'paper.tex').read_text()
records = []

def near(a, b):
    np.testing.assert_allclose(a, b, atol=1e-12, rtol=0)

def stat(values, level=.95):
    d = values.groupby(level='data_draw').mean()
    assert len(d) == 12
    mean = float(d.mean())
    h = float(t.ppf((1+level)/2, 11) * d.std(ddof=1) / np.sqrt(12))
    return mean, mean-h, mean+h, int((d > 0).sum())

for reg in (29, 30, 31):
    df = pd.read_csv(E / f'registry{reg}_pairs.csv')
    for item in [x for x in inv if x['registry'] == reg]:
        rows = df[df.key == item['key']].copy()
        assert len(rows) == 24
        assert not rows.duplicated(['data_draw','optimizer_seed']).any()
        raw = rows.operand1_value - rows.operand2_value
        if rows.operand3_value.notna().any():
            assert rows.operand3_value.notna().all()
            raw -= rows.operand3_value - rows.operand4_value
        near(raw, rows.value)
        fav = -raw if item['favourable'] == 'second - first' else raw
        near(fav, rows.favourable_value)
        use = rows.eligible
        assert int(use.sum()) == item['n_draw_seed_pairs']
        values = pd.Series(fav[use].to_numpy(), index=pd.MultiIndex.from_frame(
            rows.loc[use, ['data_draw','optimizer_seed']]))
        s = stat(values, item['interval_level'])
        near(s[:3], [item['mean_favourable'],item['interval_low'],item['interval_high']])
        assert s[3] == int(item['draws_favourable'].split('/')[0])
        nums = [f'{100*x:.2f}' for x in s[:3]]
        if item['role'] == 'primary':
            expected = nums[0] + '\\ [' + nums[1] + ',' + nums[2] + ']'
            assert expected in paper, (item['key'], expected)
        records.append({'registry': reg, 'key': item['key'], 'eligible_pairs':len(values),
                        'mean':s[0], 'low':s[1], 'high':s[2], 'passed':True})

N='state_at_f0_block_row_norms_f0_bias_test_err'
tables={k:pd.read_csv(E/f'{k}_descriptive_states.csv') for k in ('fork29','image30','fork31')}
def state(panel, name, fork=None):
    d=tables[panel]
    d=d[(d.state==name)&(d.parent==('f0' if name=='f0' else 'A_routed_affine'))]
    if fork is not None: d=d[d.fork==fork]
    assert len(d)==24 and not d.duplicated(['data_draw','optimizer_seed']).any()
    return d.set_index(['data_draw','optimizer_seed']).sort_index()

specs=[
 ('synthetic_start_benefit_snap_1000','fork29',('f0',),('start','snap_1000'),N),
 ('synthetic_start_benefit_snap_2500','fork29',('f0',),('start','snap_2500'),N),
 ('synthetic_end_benefit','fork29',('f0',),('trajectory_end','snap_2500'),N),
 ('synthetic_fold_loss_from_start','fork29',('folded_reset','snap_2500'),('start','snap_2500'),N),
 ('synthetic_fold_minus_ordinary','fork29',('folded_reset','snap_2500'),('ordinary_reset','snap_2500'),N),
 ('synthetic_raw_routing_benefit','fork29',('ordinary_reset','snap_1000'),('routed_reset','snap_1000'),'extraction_test_err'),
 ('synthetic_late_native_routing_harm','fork29',('routed_reset','snap_2500'),('ordinary_reset','snap_2500'),'native_test_err'),
 ('synthetic_late_native_routing_harm_eligible','fork29',('routed_reset','snap_2500'),('ordinary_reset','snap_2500'),'native_test_err'),
 ('image_early_start_harm','image30',('start','snap_1000'),('f0',),N),
 ('image_early_ordinary_recovery','image30',('start','snap_1000'),('ordinary_reset','snap_1000'),N),
 ('swap_routed_minus_ordinary','fork31',('routed_swap','snap_1000'),('ordinary_reset','snap_1000'),N)]
saved=json.loads((E/'descriptive_summary.json').read_text())
for key, panel, a, b, metric in specs:
    left,right=state(panel,*a),state(panel,*b)
    v=100*(left[metric]-right[metric])
    if key.endswith('_eligible'):
        v=v[left.f0!='base-81cd0cc2470964a23041']
    s=stat(v)
    near(s[:3], [saved[key][k] for k in ('mean','low','high')])
    assert s[3]==saved[key]['positive']
    records.append({'key':key, 'eligible_pairs':len(v), 'mean':s[0], 'low':s[1], 'high':s[2], 'passed':True})

# Absolute-error table: exact displayed rows, preserving the order of metrics.
for panel,label in [('fork29','MLP'),('image30','CNN')]:
    for name,fork in [('f0',None),('ordinary_reset','snap_1000'),('routed_reset','snap_1000')]:
        d=state(panel,name,fork)
        nums=[100*d[k].groupby(level='data_draw').mean().mean()
              for k in ('extraction_test_err',N,'native_test_err')]
        rendered=' & '.join(f'{x:.2f}' for x in nums)
        assert rendered in paper, (label,name,rendered)

# Loss summaries: match the manuscript's precision and all-run scope.
loss_expected={('snap_1000','ordinary_reset'):('2.42e-08','.3g','0.395','.3f',0),
 ('snap_1000','routed_reset'):('0.0378','.4f','205.67','.2f',4),
 ('snap_2500','ordinary_reset'):('1.03e-07','.3g','0.333','.3f',0),
 ('snap_2500','routed_reset'):('0.3965','.4f','244.70','.2f',8)}
loss=[]
for (fork,name),(med,mfmt,mx,xfmt,count) in loss_expected.items():
    x=state('fork29',name,fork).native_train_loss
    assert int((x>1).sum())==count
    assert format(x.median(),mfmt)==med
    assert format(x.max(),xfmt)==mx
    loss.append({'fork':fork,'state':name,'median':float(x.median()),'maximum':float(x.max()),'above_one':count})
G=pd.read_csv(E/'swap_gradient_diagnostics.csv')
diagnostics={}
for mode in ('ordinary','routed'):
    d=G[G['mode']==mode]
    assert len(d)==24
    diagnostics[mode]={k:float(d[k].median()) for k in ('raw_grad_rel_change','raw_grad_cos','disp_trainable_cos')}
np.testing.assert_allclose(diagnostics['routed']['raw_grad_rel_change'],.856,atol=.0005)
np.testing.assert_allclose(diagnostics['routed']['raw_grad_cos'],.625,atol=.0005)
np.testing.assert_allclose(diagnostics['routed']['disp_trainable_cos'],.482,atol=.0005)

# Other descriptive numbers printed in the main text.
assert f"{100*state('fork29','routed_reset','snap_2500').native_val_err.mean():.2f}"=='11.07'
assert f"{100*state('fork29','ordinary_reset','snap_2500').native_val_err.mean():.2f}"=='5.05'
assert f"{state('fork29','start','snap_2500').native_train_loss.median():.4f}"=='0.0991'
assert f"{state('fork29','folded_reset','snap_2500').native_train_loss.median():.3g}"=='1.33e-07'
assert f"{state('image30','start','snap_1000').native_train_loss.median():.3g}"=='0.147'
assert f"{state('image30','ordinary_reset','snap_1000').native_train_loss.median():.3g}"=='0.00514'
for panel, expected in [('fork29','0.67'),('image30','16.21')]:
    d=tables[panel];d=d[(d.state=='compact_2U')&(d.parent==('A' if panel=='image30' else 'A_routed_affine'))]
    assert len(d)==24
    assert f'{100*d.change_over_f0_norm.mean():.2f}'==expected
regrowth=pd.read_csv(E/'early_regrowth.csv')
for mode,expected,fmt in [('routed_shift100','0.242','.3f'),('ordinary_shift100','0.0412','.4f')]:
    d=regrowth[regrowth.continuation==mode];d=d[d['update']==d['update'].max()]
    assert len(d)==24
    assert format(d.net_over_input.median(),fmt)==expected
costs=pd.read_csv(E/'folded_costs.csv')
assert len(costs)==24
assert f'{costs.fork_over_compact_2U_macs.mean():.3f}'=='1.144'
assert f'{costs.fork_over_compact_4U_macs.mean():.3f}'=='0.572'

abstract=paper.split('\\begin{abstract}')[1].split('\\keywords')[0]
assert len(abstract.split())<=200
assert '\\usepackage{geometry}' not in paper
assert '\\vspace{-' not in paper
assert '\\linespread' not in paper
report={'planned_contrasts_checked':36, 'primary_rows_verified_in_tex':11,
 'descriptive_contrasts_checked':11,'absolute_table_rows_checked':6,
 'abstract_words':len(abstract.split()),'loss_summaries':loss,'diagnostics':diagnostics,
 'comparisons':records,'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()
 for p in sorted(E.glob('*.csv'))},'scope':'Arithmetic and manuscript checks on saved report exports; no training or checkpoint execution.'}
(ROOT/'NUMERICAL_AUDIT.json').write_text(json.dumps(report,indent=2)+'\n')
print({k:report[k] for k in ('planned_contrasts_checked','primary_rows_verified_in_tex','descriptive_contrasts_checked','absolute_table_rows_checked','abstract_words')})
