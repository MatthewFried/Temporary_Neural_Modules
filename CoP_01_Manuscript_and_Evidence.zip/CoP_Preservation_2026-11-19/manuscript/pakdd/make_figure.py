from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent
E=R.parent/'evidence'
G=pd.read_csv(E/'swap_gradient_diagnostics.csv')
P=pd.read_csv(E/'registry31_pairs.csv')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':8.5,
 'axes.labelsize':8,'xtick.labelsize':8,'ytick.labelsize':7.5,'pdf.fonttype':42})
fig,axes=plt.subplots(1,2,figsize=(4.8,2.22),gridspec_kw={'wspace':.57})
blue='#2864a4';grey='#6a6a6a'
ax=axes[0]
for i,mode in enumerate(('ordinary','routed')):
 d=G[G['mode']==mode].sort_values(['data_draw','optimizer_seed'])
 assert len(d)==24
 v=d.raw_grad_cos.to_numpy()
 ax.scatter(i+np.linspace(-.13,.13,24),v,s=12,color=grey if i==0 else blue,alpha=.65,edgecolors='none')
 ax.hlines(np.median(v),i-.22,i+.22,color='black',lw=1.3)
ax.set_xticks([0,1],['Ordinary','Routed']);ax.set_ylim(-1.12,1.16);ax.set_yticks([-1,0,1])
ax.set_ylabel('Gradient cosine: swapped vs. original')
ax.set_title('(a) Immediate gradient');ax.set_xlim(-.45,1.45)
ax=axes[1]
vals=[]
for key in ('swap_under_ordinary_gradients','swap_under_routing'):
 d=P[P.key==key];assert len(d)==24
 vals.append(100*d.groupby('data_draw').value.mean().sort_index())
assert vals[0].index.equals(vals[1].index)
for x,y in zip(vals[0],vals[1]):
 ax.plot([0,1],[x,y],color='#b8c6d0',lw=.6,alpha=.8,zorder=1)
ax.scatter(np.zeros(12),vals[0],s=13,c=grey,zorder=2)
ax.scatter(np.ones(12),vals[1],s=13,c=blue,zorder=2)
ax.axhline(0,color='black',ls=':',lw=.7)
ax.set_xticks([0,1],['Ordinary','Routed']);ax.set_xlim(-.4,1.4)
ax.set_ylabel('Swap-induced error increase (points)')
ax.set_title('(b) Later component error')
for ax in axes:
 ax.spines[['top','right']].set_visible(False)
 ax.grid(axis='y',alpha=.12)
fig.subplots_adjust(left=.12,right=.98,bottom=.17,top=.87)
fig.savefig(R/'swap.pdf',bbox_inches='tight')
fig.savefig(R/'swap.png',bbox_inches='tight',dpi=250)
