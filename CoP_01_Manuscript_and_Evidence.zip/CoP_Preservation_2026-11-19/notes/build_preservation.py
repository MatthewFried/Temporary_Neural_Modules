from pathlib import Path
import hashlib, json, shutil, zipfile, csv, sys, importlib.metadata

W=Path(__file__).resolve().parent
R=W/'CoP_Preservation_2026-11-19'
R.mkdir(exist_ok=True)
origins={}
def copy(src,dst):
    src=W/src; dst=R/dst
    dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(src,dst)
    origins[str(dst.relative_to(R))]=str(src.relative_to(W))

for name in ['cop_v70_reanalysis_reports.zip','cop_v71_closeout.zip','cop_v72_closeout.zip']:
    copy(Path('upload')/name,Path('reports_original')/name)
for p in (W/'cop_paper/evidence').iterdir():
    if p.is_file():copy(p.relative_to(W),Path('manuscript/evidence')/p.name)
for name in ['paper.tex','references.bib','paper.pdf','paper.bbl','swap.pdf','swap.png','llncs.cls','splncs04.bst','LNCS_README.md','LNCS_history.txt','check_numbers.py','NUMERICAL_AUDIT.json','build.sh','make_figure.py','AUTHOR_REVIEW.md']:
    copy(Path('cop_paper/pakdd')/name,Path('manuscript/pakdd')/name)
for name in ['reanalysis.py','evidence_map.md','README.md','build_revision_assets.py','build_tables.py','build.py','style_docx.py','table_widths.lua','reference.docx','REVISION_NOTES.md','manuscript.md','manuscript.tex','references.bib']:
    copy(Path('cop_paper')/name,Path('manuscript')/name)
for folder in ['extended','figures']:
    for p in (W/'cop_paper'/folder).rglob('*'):
        if p.is_file():copy(p.relative_to(W),Path('manuscript')/p.relative_to(W/'cop_paper'))
for name in ['build_word.py','style_docx.py','reference.docx','CoP_Manuscript.docx','paper_before_reframing.tex']:
    copy(Path('cop_paper/pakdd')/name,Path('historical/pakdd_word_and_prior_text')/name)
copy(Path('CoP_Overleaf_Files.zip'),Path('current_overleaf/CoP_Overleaf_Files.zip'))
copy(Path('CoP_Manuscript_Source.zip'),Path('historical/CoP_Manuscript_Source_before_latest_reframing.zip'))
copy(Path('CoP_v70_Closeout_for_Claude.txt'),Path('notes/CoP_v70_Closeout_for_Claude.txt'))
for p in (W/'cop_revision_backup').iterdir():
    if p.is_file():copy(p.relative_to(W),Path('historical/revision_backup')/p.name)
copy(Path('preservation_inventory.json'),Path('notes/other_CoP_files_inventory.json'))

with (R/'REPORT_ARCHIVE_INDEX.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['archive','member','uncompressed_bytes','sha256'])
    for p in sorted((R/'reports_original').glob('*.zip')):
        with zipfile.ZipFile(p) as z:
            assert z.testzip() is None
            for info in z.infolist():
                if not info.is_dir():w.writerow([p.name,info.filename,info.file_size,hashlib.sha256(z.read(info)).hexdigest()])

(R/'README.md').write_text('''# CoP preservation bundle — 19 November 2026

This supplements the user's v72 GitHub code backup. It preserves the report exports and manuscript work available in this session. It is not a complete raw-experiment backup and does not assert that these files are absent from GitHub; that repository has not been inspected.

## Start here

- `manuscript/pakdd/paper.tex` and `paper.pdf`: current 12-page paper, with the approved concise abstract and revised introduction from this conversation. These are the authoritative manuscript versions in this bundle.
- `current_overleaf/CoP_Overleaf_Files.zip`: the matching three-file Overleaf upload (paper.tex, references.bib, swap.pdf).
- `manuscript/evidence/`: draw/seed operands, state subsets, diagnostic rows, contrast inventory, descriptive calculations and source hashes used for the paper.
- `manuscript/pakdd/check_numbers.py`: arithmetic and manuscript-number checks; `NUMERICAL_AUDIT.json` is the recorded result.
- `reports_original/`: byte-for-byte copies of the uploaded v70 reanalysis, v71 closeout and v72 closeout ZIPs. Preserve all three: v70 contains broader state/diagnostic exports; the closeout packages contain final registry/export checks and figures. Each archive retains its original internal paths.
- `REPORT_ARCHIVE_INDEX.csv`: every report archive member, size and SHA-256.
- `notes/CoP_v70_Closeout_for_Claude.txt`: the available local closeout review.
- `historical/` and `manuscript/extended/`: earlier source packages, draft/Word material and revision history. They are for reference, not the latest submission. Root-level manuscript.md/manuscript.tex and prose readmes under manuscript are also earlier extended drafts. Some old scripts contain original workspace paths and need adaptation before rerunning.

## Recheck or rebuild

From this bundle's root, in a Python environment with numpy, pandas and scipy:

```sh
python manuscript/pakdd/check_numbers.py
```

This uses the bundled evidence only; it does not rerun training or revalidate checkpoints. To regenerate the figure also install matplotlib, then run `python manuscript/pakdd/make_figure.py`. To compile the paper with a normal TeX installation, run `bash manuscript/pakdd/build.sh`. The LNCS class and bibliography style are included. The old Word/export scripts are retained for provenance and have not been made portable here.

## Still preserve on the lab machine

The full trained checkpoints, optimizer/RNG states, dataset caches and split assignments, original per-run logs/configurations, manifests, and environment/package/CUDA records are not included here. Keep the original result directories used by v72 and their upstream dependencies, not just the final closeout folder. Code on GitHub plus this archive is sufficient to inspect the manuscript tables, but is not sufficient for every checkpoint-based intervention or diagnostic.

The uploaded v70 archive itself explicitly omitted these large tables (see its `skipped_large_files.json`):

- fork29_contrasts.csv
- fork31_contrasts.csv
- fork31_contrasts_by_draw.csv
- fork31_states_by_draw.csv
- image30_contrasts.csv

Back those up from the original results if available. No full model-weight files were found in the local review trees inspected for this bundle. Older v70/v71 code ZIPs are not duplicated here because this bundle focuses on evidence accompanying the user's v72 code backup. If exact historical reruns are needed, retain their code versions too.

`notes/other_CoP_files_inventory.json` lists additional CoP items found in the recent file inventory, including earlier reports and review notes. They are references only, not included bytes; this is not an exhaustive inventory of the entire project. A complete conversation transcript is not included.

## Integrity

`FILES.json` records each included payload's size, SHA-256 and available source path. `SHA256SUMS.txt` covers every other file, including FILES.json. Run `sha256sum -c SHA256SUMS.txt` from the extracted bundle root. Report archive CRCs and all indexed member hashes were checked while packaging.
''')
(R/'python_analysis_environment.json').write_text(json.dumps({'python':sys.version,'packages':{k:importlib.metadata.version(k) for k in ['numpy','pandas','scipy','matplotlib']},'scope':'Analysis packaging environment only; not the original GPU training environment.'},indent=2)+'\n')
copy(Path('build_preservation.py'),Path('notes/build_preservation.py'))
rows=[]
for p in sorted(R.rglob('*')):
    if p.is_file() and p.name not in ['FILES.json','SHA256SUMS.txt']:
        rel=str(p.relative_to(R));rows.append({'path':rel,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source':origins.get(rel,'generated during preservation')})
(R/'FILES.json').write_text(json.dumps(rows,indent=2)+'\n')
all_files=[p for p in sorted(R.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.txt']
(R/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(R))+'\n' for p in all_files))
out=W/'CoP_Preservation_2026-11-19.zip'
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(R.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(W))
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    for row in rows:
        assert hashlib.sha256(z.read(R.name+'/'+row['path'])).hexdigest()==row['sha256']
print(json.dumps({'archive':str(out),'bytes':out.stat().st_size,'payload_files':len(rows),'sha256':hashlib.sha256(out.read_bytes()).hexdigest()},indent=2))
