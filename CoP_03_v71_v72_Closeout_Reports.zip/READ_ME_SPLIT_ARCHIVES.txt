These three archives divide the original CoP preservation bundle without removing or modifying any original files. Each is below 25,000,000 bytes.

01: manuscript, numerical evidence, scripts, historical drafts, notes and full inventory.
02: original v70 reanalysis report ZIP.
03: original v71 and v72 closeout report ZIPs.

Extract all three into the same directory. They populate one CoP_Preservation_2026-11-19 folder. Its README describes the contents and missing lab-machine data. SHA256SUMS.txt covers the combined folder; run its check after extracting all three. The original report ZIPs inside reports_original remain unchanged and can be extracted separately.
