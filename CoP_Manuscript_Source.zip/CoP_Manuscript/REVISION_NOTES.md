# Revision after manuscript review

The additional state-table calculations were independently recomputed. No training or model execution was performed. All 36 planned contrasts in Appendix C are unchanged. The new all-run late summaries retain one previously flagged state, explicitly labelled; a 23-pair conditional sensitivity is also reported. The new comparisons are explicitly descriptive, with unadjusted draw-level 95% intervals.

## Changes to interpretation and reporting

1. **Title and framing.** Changed the title to *How Temporary Neural Modules Change the Retained Network*. The abstract, introduction, results and discussion now frame the result as component change under routed updates, evaluated alongside optimization stability.
2. **Before and after folding.** Added the 3.26-point advantage already present at the late fork, the 0.19-point subsequent erosion, and the unresolved folded-versus-ordinary difference. Folding is no longer presented as adding the gain. Persistence is bounded to the tested continuation and its low-loss endpoint.
3. **Training instability.** Added median loss, worst loss and counts above 1 for ordinary and routed continuations. Added the late source-validation errors and the unresolved native-error difference. Explained why the modified backward rule lacks a general descent guarantee, without asserting that every routed step is ascent.
4. **Swap interpretation.** Described ordinary swapping with a reset optimizer as exact relabelling in exact arithmetic. Added the swapped-routed versus ordinary endpoint comparison and the swapped-routed loss distribution. The results are consistent with suppressing additional routed component drift; they do not establish equality of entire trajectories.
5. **Normalisation.** Added the unrestricted lineage A raw-extraction contrast next to the primary normalised result. The resolved early benefit is specific to the edited layer in its ancestor recipient.
6. **Absolute levels and image recovery.** Added absolute native, raw and normalised errors, both ancestor levels, and the early image fork's damage and subsequent ordinary recovery. Included the compact controls' first-layer movement.
7. **Figures and prose.** Redrew all four figures. Removed internal checkpoint names and update-budget codes, made performance gains positive in performance plots, and labelled mechanism error increases separately. Removed unused dagger explanations from C1/C2. Consolidated analysis-plan provenance into Appendix B and reduced repetitive negative/contrastive phrasing.
8. **Supplement.** Added Appendix F, the state-table subsets, derived pair rows, absolute summaries and a runnable reanalysis script.

## Qualifications to the review

- The late synthetic fork is not already at negligible training loss: median loss is 0.0991 and falls to 1.33e-7 after folding and compact training. Further fitting occurs. The small extraction change is a narrower result than resistance to active competing learning, but “nothing would be unlearned” is stronger than the evidence.
- The folded-minus-ordinary difference in error is -0.0743 points [-0.2442, 0.0956]; reversing the subtraction gives the review's +0.0743. The manuscript now names the subtraction explicitly.
- An unresolved difference is not an equivalence certificate. This applies to folded versus ordinary and swapped-routed versus ordinary endpoints.
- The routed signal differs from the true forward-loss derivative, so descent is not guaranteed. Establishing the sign of every actual optimizer step would require stepwise measurements.
- The published PMLR page and arXiv abstract both explicitly use **GRAM**. PMLR confirms volume **306**, pages **105584–105617**. The existing bibliography is retained. The poster's alternative label does not supersede the cited version.

- The all-run late native-error contrast uses the state already flagged by the first-order numerical audit. Excluding it changes +4.09 [-0.13, 8.30] to +3.02 [-0.42, 6.47]. Both are unresolved. The late loss median changes from 0.3965 to 0.2812; the maximum remains 244.70 and the count above 1 remains 8. The revision reports both summaries without clearing the existing failure.

Sources checked on 17 November 2026:
- https://proceedings.mlr.press/v306/roland26a.html
- https://arxiv.org/abs/2607.08077

The scope of the novelty is the controlled intervention study linking branch allocation, the prescribed backward rule, retained-component performance and subsequent ordinary continuation. Expansion, routing, folding and stitching are established techniques. The new loss and starting-state context materially narrows any claim of durable or intrinsically better feature learning.
