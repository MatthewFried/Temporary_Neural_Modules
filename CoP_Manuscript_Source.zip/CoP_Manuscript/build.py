"""Rebuild the manuscript with Pandoc, XeLaTeX and python-docx installed."""
from pathlib import Path
import re
import subprocess
import sys

root = Path(__file__).resolve().parent

def run(*args):
    subprocess.run(args, cwd=root, check=True)

common = ['--citeproc', '--resource-path=.', '--lua-filter=table_widths.lua']
run('pandoc', 'manuscript.md', '--standalone', *common,
    '--pdf-engine=xelatex', '-o', 'CoP_Manuscript.pdf')
run('pandoc', 'manuscript.md', '--standalone', *common,
    '-t', 'latex', '-o', 'manuscript.tex')
run(sys.executable, 'style_docx.py', 'reference')
# Pandoc's OMML writer omits LaTeX tags; retain visible equation labels in Word.
text = (root / 'manuscript.md').read_text()
text = re.sub(r'\\tag\{(\d+)\}', r'\\qquad \\text{(\1)}', text)
temporary = root / 'docx_input.md'
temporary.write_text(text)
try:
    run('pandoc', temporary.name, '--citeproc', '--resource-path=.',
        '--reference-doc=reference.docx', '-o', 'CoP_Manuscript.docx')
    run(sys.executable, 'style_docx.py', 'final')
finally:
    temporary.unlink(missing_ok=True)
