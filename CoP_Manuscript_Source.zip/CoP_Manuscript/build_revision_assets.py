"""Build descriptive tables and manuscript figures from saved report exports."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent
q=json.loads((R/'evidence/descriptive_summary.json').read_text())
inv=json.loads((R/'evidence/contrast_inventory.json').read_text())
pairs=pd.read_csv(R/'evidence/descriptive_pairs.csv')
A=pd.read_csv(R/'evidence/descriptive_absolute.csv')
N='state_at_f0_block_row_norms_f0_bias_test_err'
# Supplement: explicitly descriptive, preserving sign definitions.
labels={
 'synthetic_start_benefit_snap_1000':'Synthetic: ancestor minus early starting state',
 'synthetic_start_benefit_snap_2500':'Synthetic: ancestor minus late starting state',
 'synthetic_end_benefit':'Synthetic: ancestor minus original trajectory end',
 'synthetic_fold_loss_from_start':'Synthetic late: folded endpoint minus starting state',
 'synthetic_fold_minus_ordinary':'Synthetic late: folded minus ordinary endpoint',
 'synthetic_raw_routing_benefit':'Synthetic early, raw: ordinary minus routed',
 'synthetic_late_native_routing_harm':'Synthetic late, native: routed minus ordinary (all 24)',
 'synthetic_late_native_routing_harm_eligible':'Same contrast, excluding reference exception (23 pairs)',
 'image_early_start_harm':'Image early: starting state minus ancestor',
 'image_early_ordinary_recovery':'Image early: starting state minus ordinary endpoint',
 'swap_routed_minus_ordinary':'Synthetic early: swapped routed minus ordinary endpoint'}
parts=['## Appendix F Descriptive reanalysis of saved states','These comparisons were added during manuscript review. They average eligible optimizer seeds within each of 12 draws and use unadjusted 95% Student $t$ intervals. Every contrast uses 24 matched pairs except the explicitly labelled 23-pair sensitivity. The all-run late routed summaries include the state flagged by the first-order numerical estimate in Appendix D (draw 350, optimizer seed 1). Retaining it for a descriptive summary does not clear its audit status; the exclusion sensitivity is reported alongside it. The remaining new contrasts do not use that state. Positive values follow the explicit subtraction in the first column. Unless marked raw or native, the metric is normalised extraction.','### F1 Additional paired comparisons','| Descriptive contrast | Difference and 95% interval (points) | Positive draws |','|:--|--:|:--:|']
for key,label in labels.items():
 x=q[key];parts.append(f'| {label} | {x["mean"]:+.2f} [{x["low"]:+.2f}, {x["high"]:+.2f}] | {x["positive"]}/12 |')
parts+=['','### F2 Absolute endpoint values','Error columns are percentages, averaged over draw means. Loss is the median native training cross-entropy over 24 runs, in natural-log units per example. The ancestor has identical raw, normalised and native errors. All expanded states below are unrestricted lineage A.']
state_labels={'f0':'Ancestor','compact_2U':'Compact, 4,000 updates','start':'Starting state','routed_reset':'Routed endpoint','ordinary_reset':'Ordinary endpoint','folded_reset':'Folded endpoint'}
for panel,title in [('fork29','Synthetic MLP'),('image30','CIFAR-derived CNN')]:
 parts+=['',f'**{title}.**','', '| State | Raw error | Normalised error | Native error | Source-val error | Median loss |','|:--|--:|--:|--:|--:|--:|']
 for _,r in A[A.panel==panel].iterrows():
  lab=state_labels[r.state]+(' (early)' if r.fork=='snap_1000' else ' (late)' if r.fork=='snap_2500' else '')
  if panel=='fork29' and r.state=='routed_reset' and r.fork=='snap_2500':lab+=' †'
  nums=[f'{100*r[m]:.2f}' for m in ['extraction_test_err',N,'native_test_err','native_val_err']]
  parts.append('| '+lab+' | '+' | '.join(nums)+f' | {r.loss_median:.3g} |')
parts+=['','† This all-run row retains the declared reference exception. For the conditional 23-pair native-error contrast, the affected draw contributes its one remaining optimizer seed.','', '### F3 Loss tails and component movement','The synthetic early routed loss ranges from $3.62\\times10^{-9}$ to 205.67; 4 of 24 runs exceed 1. The late routed range is $4.14\\times10^{-8}$ to 244.70; 8 of 24 exceed 1. Excluding the flagged late state changes the median to 0.2812, with 8 of 23 above 1 and the same maximum 244.70. Both ordinary endpoints have 0 of 24 above 1; their maxima are 0.395 and 0.333. Swapped routed continuation has median loss $1.05\\times10^{-7}$ and maximum 0.694, so the very low median does not describe every run.','','The compact synthetic control moves its first-layer weight matrix by a mean 0.67% of the ancestor norm (median 0.48%) over 4,000 updates. The corresponding image figures are 16.21% and 15.75%. These are endpoint displacement norms relative to the ancestor, not accumulated path lengths.','','The late synthetic starting loss has median 0.0991 and maximum 17.59. Folded continuation reduces them to $1.33\\times10^{-7}$ and 0.117. Thus folding is followed by actual fitting, despite the small change in normalised-extraction error.','','All source rows and calculations are included in the manuscript package: `*_descriptive_states.csv`, `descriptive_pairs.csv`, `descriptive_absolute.csv`, `descriptive_summary.json`, and `reanalysis.py`.']
s=(R/'manuscript.md').read_text();mark='## Appendix F Descriptive reanalysis of saved states'
if mark in s:s=s[:s.index(mark)].rstrip()
# Bibliography is emitted by citeproc after the appendices.
s=s.replace('\n## References\n','\n').replace('::: {#refs}\n:::','')
(R/'manuscript.md').write_text(s.rstrip()+'\n\n'+'\n\n'.join(parts[:3])+'\n\n'+'\n'.join(parts[3:])+'\n\n## References\n\n::: {#refs}\n:::\n')
# Plot helpers.
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':11,'axes.labelsize':10,'savefig.dpi':220})
blue='#2864a4';orange='#bd542b';grey='#555555'
def registered(reg,key,sign=1):
 x=next(a for a in inv if a['registry']==reg and a['key']==key)
 lo=x['interval_low']*100;hi=x['interval_high']*100;m=x['mean_favourable']*100
 return (sign*m,min(sign*lo,sign*hi),max(sign*lo,sign*hi))
def desc(key,sign=1):
 x=q[key];return(sign*x['mean'],min(sign*x['low'],sign*x['high']),max(sign*x['low'],sign*x['high']))
def forest(ax,rows,xlabel):
 # rows: label, mean/low/high, color
 for i,(label,(m,lo,hi),col) in enumerate(rows):
  ax.errorbar(m,i,xerr=[[m-lo],[hi-m]],fmt='o',color=col,capsize=3,markersize=5,lw=1.6)
  ax.text(1.02,i,f'{m:+.2f} [{lo:+.2f}, {hi:+.2f}]',transform=ax.get_yaxis_transform(),va='center',fontsize=9,clip_on=False)
 ax.set_yticks(range(len(rows)),[x[0] for x in rows]);ax.invert_yaxis();ax.set_ylim(len(rows)-.5,-.6)
 ax.axvline(0,color='#888',lw=.8);ax.grid(axis='x',alpha=.18);ax.set_xlabel(xlabel)
 for sp in ['top','right','left']:ax.spines[sp].set_visible(False)
 ax.tick_params(axis='y',length=0,pad=10)
def save(fig,name):fig.savefig(R/'figures'/name,bbox_inches='tight',facecolor='white');plt.close(fig)
rows=[('Synthetic: normalised extraction (98.75%)',registered(29,'early_routing_improves_normalised_extraction'),blue),('Synthetic: raw extraction (95%, descriptive)',desc('synthetic_raw_routing_benefit'),grey),('Synthetic: native model (98.75%)',registered(29,'early_routing_worsens_the_complete_network',-1),blue),('Image: normalised extraction (99%)',registered(30,'early_routing_improves_normalised_extraction'),orange),('Image: native model (99%)',registered(30,'early_routing_worsens_the_complete_network',-1),orange)]
fig,ax=plt.subplots(figsize=(11,3.7));fig.subplots_adjust(left=.36,right=.73,bottom=.2);forest(ax,rows,'Error reduction under routing (percentage points)');ax.set_title('Early fork: routed versus ordinary continuation',pad=12);save(fig,'fig1_component_effects.png')
rows=[('Starting state versus ancestor',desc('synthetic_start_benefit_snap_2500'),grey),('Folded endpoint versus ancestor',registered(29,'late_folding_retains_a_component_advantage'),blue),('Folded endpoint versus starting state',desc('synthetic_fold_loss_from_start',-1),grey),('Folded versus ordinary endpoint',desc('synthetic_fold_minus_ordinary',-1),grey),('Folded versus compact, 4,000 updates',registered(29,'expansion_history_beats_compact_continuation'),blue),('Folded versus reset-matched compact',registered(29,'expansion_history_beats_reset_matched_compact'),blue)]
fig,ax=plt.subplots(figsize=(11,4.1));fig.subplots_adjust(left=.34,right=.73,bottom=.18);forest(ax,rows,'Error reduction relative to named reference (points)');ax.set_title('Late synthetic fork: advantage before and after folding',pad=12);save(fig,'fig2_folding_controls.png')
G=pd.read_csv(R/'evidence/swap_gradient_diagnostics.csv')
rows=[('Routing-by-swap interaction (97.5%)',registered(31,'swap_changes_routed_learning'),grey),('Swap under routing (95%)',registered(31,'swap_under_routing'),blue),('Swap under ordinary gradients (95%)',registered(31,'swap_under_ordinary_gradients'),orange),('Swapped routed minus ordinary (descriptive)',desc('swap_routed_minus_ordinary'),grey)]
fig=plt.figure(figsize=(11,6));gs=fig.add_gridspec(2,2,height_ratios=[1.7,1],hspace=.75,wspace=.4,left=.34,right=.74,bottom=.12,top=.93);ax=fig.add_subplot(gs[0,:]);forest(ax,rows,'Increase in normalised-extraction error (points)');ax.set_title('Early synthetic fork: branch swaps',pad=12)
for j,(metric,title) in enumerate([('raw_grad_rel_change','First-layer gradient: relative change'),('raw_grad_cos','First-layer gradient: cosine')]):
 ax=fig.add_subplot(gs[1,j])
 for i,(mode,col) in enumerate([('ordinary',orange),('routed',blue)]):
  vals=G[G['mode']==mode][metric].to_numpy();assert len(vals)==24
  jitter=np.linspace(-.14,.14,len(vals));ax.scatter(i+jitter,vals,s=10,alpha=.5,color=col)
  med=float(np.median(vals));ax.hlines(med,i-.25,i+.25,color=col,lw=2);ax.annotate(f'{med:.3g}',(i,med),xytext=(14,4),textcoords='offset points',fontsize=8)
 ax.set_xticks([0,1],['Ordinary','Routed']);ax.set_title(title,fontsize=9);ax.grid(axis='y',alpha=.15)
 if j==0:
  ax.set_yscale('log');ax.set_ylim(1e-16,max(G[metric])*1.8)
  ax.set_yticks([1e-15,1e-10,1e-5,1])
 else:ax.set_ylim(-1.15,1.2)
 for sp in ['top','right']:ax.spines[sp].set_visible(False)
save(fig,'fig3_swap_mechanism.png')
G=pd.read_csv(R/'evidence/early_regrowth.csv');fig,ax=plt.subplots(figsize=(9,3.5));fig.subplots_adjust(right=.83)
for mode,col in [('ordinary_shift100',orange),('routed_shift100',blue)]:
 z=G[G.continuation==mode]
 for _,g in z.groupby(['data_draw','optimizer_seed']):ax.plot(g['update'],g.net_over_input,color=col,alpha=.1,lw=.8)
 med=z.groupby('update').net_over_input.median();ax.plot(med.index,med.values,color=col,lw=2,label='Ordinary gradients' if mode.startswith('ordinary') else 'Routed gradients');ax.annotate(f'{med.iloc[-1]:.4g}',(med.index[-1],med.iloc[-1]),xytext=(8,0),textcoords='offset points',va='center',fontsize=9)
ax.set_yscale('log');ax.set_title('Early synthetic fork: branch regrowth after full redistribution');ax.set_xlabel('Updates after redistribution');ax.set_ylabel('Net branch-output RMS / merge-input RMS');ax.legend(frameon=False,fontsize=9);ax.grid(alpha=.15);ax.spines[['top','right']].set_visible(False);save(fig,'figS1_regrowth.png')
