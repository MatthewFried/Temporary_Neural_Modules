from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT.parent / 'review_v70/cop_v70_reanalysis_reports/cop_v70_reanalysis_reports/v70_reports'
LABELS = {
'early_routing_improves_normalised_extraction':'Early routing benefit in normalised extraction',
'early_routing_worsens_the_complete_network':'Early routing harm in native error',
'late_folding_retains_a_component_advantage':'Late folded benefit over ancestor',
'expansion_history_beats_compact_continuation':'Late folded benefit over compact 4,000',
'early_routing_improves_normalised_extraction_B':'B early routing benefit in normalised extraction',
'early_routing_improves_raw_extraction_B':'B early routing benefit in raw extraction',
'early_routing_worsens_the_complete_network_B':'B early routing harm in native error',
'late_folding_retains_a_component_advantage_B':'B late folded benefit in raw extraction',
'expansion_history_beats_compact_continuation_4U':'Late folded benefit over compact 8,000',
'expansion_history_beats_reset_matched_compact':'Late folded benefit over reset compact',
'expansion_history_beats_reset_matched_compact_early':'Early folded benefit over reset compact',
'routed_fork_against_reset_matched_compact':'Early routed benefit over reset compact',
'routed_expansion_beats_the_late_head':'Routed expansion benefit over late head',
'early_routing_improves_layout_free_extraction':'Early routing benefit with whole-filter norms',
'routed_expansion_beats_ordinary_expansion':'Routed expansion benefit over ordinary expansion',
'late_head_against_compact':'Late head benefit over compact',
'swap_changes_routed_learning':'Early swap interaction',
'shift_changes_routed_learning':'Early full-shift interaction',
'swap_under_routing':'Swap minus no swap under routing',
'swap_under_ordinary_gradients':'Swap minus no swap under ordinary gradients',
'half_shift_under_routing':'Half shift minus unedited under routing',
'full_shift_under_routing':'Full shift minus unedited under routing',
'swap_changes_routed_learning_native':'Early swap interaction in native error',
'swap_changes_routed_learning_late':'Late swap interaction',
'shift_changes_routed_learning_late':'Late full-shift interaction',
'swap_changes_routed_learning_B':'B early swap interaction in raw extraction',
'shift_under_ordinary_gradients':'Full shift minus unedited under ordinary gradients',
}

sections=[]; inventory=[]
for w,title,lev in [(29,'Synthetic MLP','98.75%'),(30,'CIFAR derived CNN','99%'),(31,'Function preserving mechanism interventions','97.5%')]:
    d=json.loads((REPORTS/f'registry{w}.json').read_text())
    sections += [f'### C{w-28} {title}', '', f'P denotes primary ({lev} intervals); S denotes secondary (95% intervals). Draw counts are the number of positive draw means. A dagger marks a conditional comparison with 23 eligible draw–seed pairs.', '',
    '| Contrast | Difference and interval | Positive draws | Role |',
    '|:--|--:|:--:|:--:|']
    for h in d['results']:
        a,b,c=[h[k]*100 for k in ('mean_favourable','interval_low','interval_high')]
        label=LABELS[h['key']]+(' †' if h['status']=='conditional' else '')
        sections.append(f"| {label} | {a:+.2f} [{b:+.2f}, {c:+.2f}] | {h['draws_favourable']} | {'P' if h['role']=='primary' else 'S'} |")
        inventory.append({'registry':w,'paper_label':label,**h})
    sections.append('')
p=ROOT/'manuscript.md';s=p.read_text();s=s.replace('<!-- COMPLETE_TABLES -->','\n'.join(sections));s=s.replace("$W'(I+sM)h+sb'_{\\mathrm{map}}+b'$, where $b'_{\\mathrm{map}}=W'c$", "$W'(I+sM)h+sW'c+b'$")
p.write_text(s)
(ROOT/'evidence/contrast_inventory.json').write_text(json.dumps(inventory,indent=2))

