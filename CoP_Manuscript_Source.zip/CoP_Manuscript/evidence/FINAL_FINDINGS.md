# CoP: final findings (v70 evidence, v72 close-out)

Numbers are test-error differences in percentage points, oriented so that a positive value favours the hypothesis as named (the registry's favourable orientation). One data draw is the unit; the two optimizer seeds of a draw are averaged first. Intervals are Student t over the 12 draws, at the registry's level: primary hypotheses at the Bonferroni level of their registry (98.75% for four primaries, 99% for five, 97.5% for two), secondary hypotheses at 95%. Sources: `<registry>.json` result `key`; the per-pair rows are in `<registry>_pairs.csv` (close-out reports).

**Raw extraction** (`extraction`) places the state's first layer, weights and bias, in f0 unchanged. **Normalised extraction** (`state_at_f0_block_row_norms_f0_bias`) places the state's first-layer weights in f0 rescaled, per unit and input block, to f0's norms, with f0's first-layer bias; the layout-free variant (`state_at_f0_block_norms_f0_bias`) uses one scale per input block. Only the normalised measures restore f0's norms and bias. Both measure the learned first-layer component, not the native accuracy of the trained network.

## (a) Supported findings

Hypotheses whose interval excludes zero in the favourable direction (replicated) or, for two-sided mechanism hypotheses, excludes zero (nonzero). Conditional rows rest on 23 of 24 pairs (section c).

| registry | hypothesis | role | estimate | interval | level | draws favourable | status | source |
|---|---|---|---|---|---|---|---|---|
| registry29 | early_routing_improves_normalised_extraction | primary | +1.76 | [+0.31, +3.21] | 98.75% | 12/12 | validated | `registry29.json:early_routing_improves_normalised_extraction` |
| registry29 | late_folding_retains_a_component_advantage | primary | +3.07 | [+1.64, +4.50] | 98.75% | 12/12 | validated | `registry29.json:late_folding_retains_a_component_advantage` |
| registry29 | expansion_history_beats_compact_continuation | primary | +3.02 | [+1.57, +4.48] | 98.75% | 12/12 | validated | `registry29.json:expansion_history_beats_compact_continuation` |
| registry29 | early_routing_improves_normalised_extraction_B | secondary | +1.81 | [+0.75, +2.87] | 95% | 10/12 | validated | `registry29.json:early_routing_improves_normalised_extraction_B` |
| registry29 | early_routing_improves_raw_extraction_B | secondary | +2.47 | [+1.20, +3.75] | 95% | 10/12 | validated | `registry29.json:early_routing_improves_raw_extraction_B` |
| registry29 | late_folding_retains_a_component_advantage_B | secondary | +3.75 | [+2.30, +5.21] | 95% | 12/12 | validated | `registry29.json:late_folding_retains_a_component_advantage_B` |
| registry29 | expansion_history_beats_compact_continuation_4U | secondary | +3.02 | [+1.94, +4.10] | 95% | 12/12 | validated | `registry29.json:expansion_history_beats_compact_continuation_4U` |
| registry29 | expansion_history_beats_reset_matched_compact | secondary | +2.72 | [+1.68, +3.77] | 95% | 11/12 | validated | `registry29.json:expansion_history_beats_reset_matched_compact` |
| registry29 | expansion_history_beats_reset_matched_compact_early | secondary | +1.22 | [+0.57, +1.88] | 95% | 10/12 | validated | `registry29.json:expansion_history_beats_reset_matched_compact_early` |
| registry29 | routed_fork_against_reset_matched_compact | secondary | +2.84 | [+1.65, +4.02] | 95% | 12/12 | validated | `registry29.json:routed_fork_against_reset_matched_compact` |
| registry30 | early_routing_worsens_the_complete_network | primary | +13.96 | [+10.02, +17.90] | 99% | 12/12 | validated | `registry30.json:early_routing_worsens_the_complete_network` |
| registry31 | swap_changes_routed_learning | primary | +1.81 | [+0.43, +3.19] | 97.5% | 12/12 | validated | `registry31.json:swap_changes_routed_learning` |
| registry31 | swap_under_routing | secondary | +1.73 | [+0.67, +2.79] | 95% | 12/12 | validated | `registry31.json:swap_under_routing` |
| registry31 | full_shift_under_routing | secondary | +0.93 | [+0.01, +1.86] | 95% | 9/12 | validated | `registry31.json:full_shift_under_routing` |
| registry31 | swap_changes_routed_learning_late | secondary | +0.94 | [+0.11, +1.78] | 95% | 10/12 | conditional | `registry31.json:swap_changes_routed_learning_late` |
| registry31 | swap_changes_routed_learning_B | secondary | +2.47 | [+0.89, +4.05] | 95% | 10/12 | validated | `registry31.json:swap_changes_routed_learning_B` |

In words, within the tested settings:
- Synthetic: routing during the early continuation lowers the extracted component's error relative to ordinary continuation; after the late fork, the folded continuation keeps a component advantage over f0, and over the matched compact continuation (primaries), and over the reset-matched compact continuation (secondary, 95%).
- Mechanism: swapping function-preserving branches at the early fork changes the extracted component more under routing than under ordinary gradients (the swap interaction); the swap under routing alone is nonzero, under ordinary gradients unresolved.
- Image: routing during the early continuation raises the native error of the continued network (the hypothesis that it worsens the complete network replicates there).

## (b) Contrary and inconclusive findings

Contrary: the interval excludes zero against the hypothesis. Inconclusive: it includes zero. Inconclusive is not evidence of no effect.

| registry | hypothesis | role | estimate | interval | level | draws favourable | status | source |
|---|---|---|---|---|---|---|---|---|
| registry29 | early_routing_worsens_the_complete_network | primary | +0.26 | [-0.78, +1.31] | 98.75% | 5/12 | validated | `registry29.json:early_routing_worsens_the_complete_network` |
| registry29 | early_routing_worsens_the_complete_network_B | secondary | -0.21 | [-3.52, +3.10] | 95% | 3/12 | validated | `registry29.json:early_routing_worsens_the_complete_network_B` |
| registry30 | early_routing_improves_normalised_extraction | primary | -12.51 | [-17.25, -7.77] | 99% | 0/12 | validated | `registry30.json:early_routing_improves_normalised_extraction` |
| registry30 | late_folding_retains_a_component_advantage | primary | -7.10 | [-13.75, -0.46] | 99% | 3/12 | validated | `registry30.json:late_folding_retains_a_component_advantage` |
| registry30 | expansion_history_beats_compact_continuation | primary | -6.49 | [-13.10, +0.11] | 99% | 3/12 | validated | `registry30.json:expansion_history_beats_compact_continuation` |
| registry30 | routed_expansion_beats_the_late_head | primary | -12.09 | [-19.30, -4.87] | 99% | 1/12 | validated | `registry30.json:routed_expansion_beats_the_late_head` |
| registry30 | early_routing_improves_layout_free_extraction | secondary | -13.31 | [-16.69, -9.94] | 95% | 0/12 | validated | `registry30.json:early_routing_improves_layout_free_extraction` |
| registry30 | routed_expansion_beats_ordinary_expansion | secondary | -12.15 | [-17.04, -7.26] | 95% | 0/12 | validated | `registry30.json:routed_expansion_beats_ordinary_expansion` |
| registry30 | late_head_against_compact | secondary | +0.46 | [-0.44, +1.36] | 95% | 7/12 | validated | `registry30.json:late_head_against_compact` |
| registry30 | early_routing_improves_normalised_extraction_B | secondary | -14.55 | [-18.70, -10.41] | 95% | 0/12 | validated | `registry30.json:early_routing_improves_normalised_extraction_B` |
| registry30 | early_routing_improves_raw_extraction_B | secondary | -16.94 | [-21.60, -12.28] | 95% | 0/12 | validated | `registry30.json:early_routing_improves_raw_extraction_B` |
| registry30 | expansion_history_beats_compact_continuation_4U | secondary | -6.62 | [-11.12, -2.11] | 95% | 3/12 | validated | `registry30.json:expansion_history_beats_compact_continuation_4U` |
| registry30 | expansion_history_beats_reset_matched_compact | secondary | -6.99 | [-11.35, -2.63] | 95% | 3/12 | validated | `registry30.json:expansion_history_beats_reset_matched_compact` |
| registry30 | routed_fork_against_reset_matched_compact | secondary | -12.86 | [-16.50, -9.22] | 95% | 0/12 | validated | `registry30.json:routed_fork_against_reset_matched_compact` |
| registry31 | shift_changes_routed_learning | primary | +1.12 | [-0.08, +2.32] | 97.5% | 9/12 | validated | `registry31.json:shift_changes_routed_learning` |
| registry31 | swap_under_ordinary_gradients | secondary | -0.08 | [-0.26, +0.10] | 95% | 5/12 | validated | `registry31.json:swap_under_ordinary_gradients` |
| registry31 | half_shift_under_routing | secondary | +0.41 | [-0.82, +1.64] | 95% | 5/12 | validated | `registry31.json:half_shift_under_routing` |
| registry31 | swap_changes_routed_learning_native | secondary | +0.95 | [-1.79, +3.70] | 95% | 6/12 | validated | `registry31.json:swap_changes_routed_learning_native` |
| registry31 | shift_changes_routed_learning_late | secondary | +0.52 | [-0.10, +1.14] | 95% | 10/12 | conditional | `registry31.json:shift_changes_routed_learning_late` |
| registry31 | shift_under_ordinary_gradients | secondary | -0.19 | [-0.39, +0.01] | 95% | 4/12 | validated | `registry31.json:shift_under_ordinary_gradients` |

In words: in the image setting the synthetic component result reverses (routing raises the extracted component's error; the folded continuation is worse than f0). Architecture and data change together between the settings, so these experiments do not identify which change causes the reversal. In the synthetic setting, the claim that routing worsens the complete network is inconclusive. The full-shift interaction is inconclusive at its primary level; its unadjusted secondary readings do not promote it.

## (c) Validation exceptions (kept, not repaired)

1. **Fork audit failure: storage certificate** (`*_audits.csv`, f0 `base-e992ad6a294336d8f3fd`, draw 349, seed 0, `B_routed_affine/snap_1000/routed_shift50`). The saved redistributed start differs from the pre-edit network in float64 by 1.21836e-05 against the declared 1e-5 threshold (condition number 101451; no decision changes). The threshold is not raised. The run reproduces on retraining, which does not cancel the failure. No registered hypothesis reads this state.
1. **First-order rounding-estimate exceedance** (`ref29_rows.csv`, f0 `base-81cd0cc2470964a23041`, `A_routed_affine/snap_2500/routed_reset`, measure native). On the CPU, 1 of 8192 examples exceed the estimate (worst ratio 57.11); on the GPU the worst ratio is 0.00271. Float64 implementation and reference agree; errors: reference 4047, CPU 4047, GPU 4047; decided-example disagreements 0. The state is excluded from the hypotheses that read it.
   Diagnosis (`diagnosis.json`, no training): example 2652, logit 1; reference margin 0.05118; ratio on the CPU 57.11, the same example alone 0, on the GPU 0.0; float32 pre-activations whose sign differs from float64 on the way: 1. This records a dependence on the evaluation batch and an activation sign change; it does not establish which caused the excess.

Conditional hypotheses (the exclusion is kept; restoring them would be a labelled sensitivity analysis): `registry31.json:swap_changes_routed_learning_late` (23 of 24 pairs), `registry31.json:shift_changes_routed_learning_late` (23 of 24 pairs). No primary hypothesis is affected.

## (d) Numerical assumptions and checks

- **Float64 agreement.** In every one of 8016 reference rows the implementation evaluated in float64 agrees with the independent reference (raw torch, separate code) to 1e-9 (1 + |z|) per logit (`ref*_rows.csv:function64_ok`: 8016 true). Parameter and table checks: all applicable rows pass.
- **The rounding estimate is first order, not a bound.** `reference_impl.RefNet.rounding_bound` (name kept) carries Higham-style local rounding errors (gamma_n per sum) to the logits through the network's Jacobian at the activation pattern of its own evaluation, in the dtype it was computed in (ref29: float64, ref30: float32, ref31: float64). It neglects second-order terms, ReLU units and max-pool winners that differ between that evaluation and the float32 one, and transform convolution algorithms (Winograd, FFT); the factor 1.01 is not a proof. It is an empirical consistency check; v69's fixed 1e-4 (1 + |z|) tolerance, which ignored conditioning, is reported in the same rows (`fixed1e4_*`). Neither is an arbiter of implementation correctness.
- **Effect of evaluation rounding on the results.** Across all reference rows the float32 and float64 error counts differ by at most 1 example(s). Recomputing the registered contrasts from the reference's float64 error counts (`float64_sensitivity.csv`): 24 hypotheses fully covered, including 8 primaries; readings changed: 0; largest change of a mean: 5.6e-17 (as a fraction). Hypotheses with compact or late-head operands are not covered (the reference did not evaluate those runs) and no float64 number is claimed for them.
- **Where the estimate is large.** On the most ill-conditioned states (wave 31 shift and swap continuations especially) the estimate approaches or exceeds the logits' size and many examples are undecided, so the decision check says little there; the error-count comparison above is the evidence.

## Validation record

- Tests: CPU 1281 collected, 1248 passed, 33 skipped (CUDA-only); CUDA 68 collected, 68 passed, 0 skipped (`cpu_tests.xml`, `cuda_tests.xml`; the named optimizer and rounding-estimate GPU cases are required).
- Reference: every f0 of each wave (ref29: 2808 rows, ref30: 2808 rows, ref31: 2400 rows); 8015 of 8016 pass every row criterion. Rows are measurements, not replications.
- Retrained from scratch and compared value by value: 15 runs, 114 checkpoints, all identical: True (`retrain*.json`). This is repeatability; agreement with the definitions is the reference's.
- Mechanism diagnostic: 24 of 24 f0, 1152 first-update rows, 1920 regrowth rows (`mech31_coverage.json`).
- Registries: every value recomputed from the states tables, 0 mismatches (`registry*.csv`); the per-pair export reproduces every registry mean and interval to 1e-12: True (`registry*_check.csv`).

## Mechanism diagnostics (descriptive)

First update after the swap, early fork, parent A (float64; `mech31_gradients.csv`, median over 24 f0 and the prescribed batches): first-layer gradient relative change 1.25e-15 (ordinary) and 0.856 (routed); gradient cosine 1 and 0.625; update cosine 1 and 0.482 (routed means: relative change 0.972, gradient cosine 0.26, update cosine 0.194; the routed cosines are bimodal, some near -1). These describe the learning step; they are not outcome tests. Regrowth after a full shift: see figure S1 (medians and per-f0 curves); regrowth shows the branches are used again, not that they are necessary.

## Release checks

- pass: export reproduces registry29: 12 of 12 hypotheses reproduce (`registry29_check.csv`)
- pass: registry29 recomputed from the states table: 0 mismatches, 0 hypotheses not fully recomputed (`registry29.csv`)
- pass: export reproduces registry30: 13 of 13 hypotheses reproduce (`registry30_check.csv`)
- pass: registry30 recomputed from the states table: 0 mismatches, 0 hypotheses not fully recomputed (`registry30.csv`)
- pass: export reproduces registry31: 11 of 11 hypotheses reproduce (`registry31_check.csv`)
- pass: registry31 recomputed from the states table: 0 mismatches, 0 hypotheses not fully recomputed (`registry31.csv`)
- pass: registry statuses: every status validated or conditional
- pass: conditional exclusions are declared exceptions: every exclusion refers to a declared exception
- pass: float64 sensitivity consistent: 24 hypotheses covered, 0 float32 operand mismatches (`float64_sensitivity.csv`)
- pass: float64 implementation agreement: 8016 of 8016 reference rows (`ref*_rows.csv:function64_ok`)
- pass: parameter, eligibility and table certificates: params_ok: 4320 of 4320 applicable rows, eligibility_ok: 3648 of 3648 applicable rows, table_ok: 7344 of 7344 applicable rows
- pass: failed reference rows are the declared ones: failed [('ref29', 'base-81cd0cc2470964a23041', 'A_routed_affine/snap_2500/routed_reset', 'native')]; declared [('ref29', 'base-81cd0cc2470964a23041', 'A_routed_affine/snap_2500/routed_reset', 'native')]
- pass: failed fork audits are the declared ones: failed [('base-e992ad6a294336d8f3fd', 'B_routed_affine/snap_1000/routed_shift50')]; declared [('base-e992ad6a294336d8f3fd', 'B_routed_affine/snap_1000/routed_shift50')]
- pass: retrained runs reproduce: 15 runs, 114 checkpoints (`retrain*.json`)
- pass: mechanism diagnostic complete: 24 of 24 f0, passed True
- pass: tests: CPU {'tests': 1281, 'skipped': 33, 'failures': 0, 'errors': 0}, CUDA {'tests': 68, 'skipped': 0, 'failures': 0, 'errors': 0}
- pass: nonzero steps are the declared ones: nonzero {'fork31': 1, 'ref29': 4, 'registry31': 3}; declared {'fork31': 1, 'ref29': 4, 'registry31': 3}

## Final status

The v70 run completed with 2 localized validation exceptions, declared in `v72_declared_exceptions.json` and kept as recorded; not every check passed. Steps not 0 in the final local verdict (`verdict.json`): {'fork31': 1, 'ref29': 4, 'registry31': 3}. The archive's own verdict lists `package_final` as pending because a step cannot report inside the archive it writes; a successful packaging step means the archive was written, not that the science passed.
