# Evidence map and claim boundaries

## Central claim

The revised paper follows a retained first layer under temporary expansion and gradient routing. Its main early synthetic benefit is resolved only after a prescribed normalisation. Routing can simultaneously produce severe training-loss instability. The late folded advantage is largely present before folding, and ordinary continuation with branches retained produces a similar endpoint. A forward-preserving swap suppresses the additional routed component change; ordinary swapping is an algebraic relabelling control. Image continuation reveals harm and partial ordinary recovery.

The novelty candidate is the controlled conjunction of shared-checkpoint continuation, forward-preserving reallocation, component extraction and post-fold continuation, interpreted with loss and starting-state measurements. The study does not establish broadly superior features or resistance to active competing learning.

## Results

All files below refer to the frozen v70 reports except the pair exports and final findings, which are the v72 closeout.

| Paper section | Record |
|---|---|
| 4.1 | `registry29.json`, `early_routing_improves_normalised_extraction`, `early_routing_worsens_the_complete_network` |
| 4.3 | `registry29.json`, `late_folding_retains_a_component_advantage`, `expansion_history_beats_compact_continuation`, `expansion_history_beats_reset_matched_compact`, `expansion_history_beats_compact_continuation_4U` |
| 4.3 compute | `fork29_compute.csv`, `image30_compute.csv`, A / snap_2500 / folded_reset; post-ancestor MAC ratios |
| 4.4 | `registry31.json`, `swap_changes_routed_learning`, `swap_under_routing`, `swap_under_ordinary_gradients`, `swap_changes_routed_learning_native` |
| 4.4 first update | `mech31_gradients.csv`, A / snap_1000 / swap / float64; 24 ancestors, medians |
| 4.5 | `registry31.json`, `shift_changes_routed_learning`; regrowth in `mech31_regrowth.csv`, A / snap_1000 / full shift |
| 4.6 | All 13 `registry30.json` contrasts; distinguishes five primary from eight secondary contrasts |
| 4.7 | B secondary rows from `registry29.json`; numerical evidence in `FINAL_FINDINGS.md` |
| Appendix C | All 36 results from `registry29.json`, `registry30.json`, `registry31.json`; exact mapping in `contrast_inventory.json` |
| Appendix D | `ref29_rows.csv`, `ref30_rows.csv`, `ref31_rows.csv`, `fork31_audits.csv`, `retrain*.json`, CPU/CUDA XML, v72 `tests72.xml`, `float64_sensitivity.csv` |

The planned table means, signs, intervals and draw counts are generated from the registries. The four figures are redrawn from these results and the newly labelled descriptive calculations; performance-plot signs now show error reductions as positive. The mechanism plot retains explicit error-increase signs.

## Method definitions

Definitions were read from `cop_research_v71` and the actual frozen run manifests. The v72 manifest records the same hashes for the training files; v72 changes reporting only.

| Method | Source |
|---|---|
| MLP and image experiment composition, forks and controls | `cop/orchestration/wave13.py`, wave29_v62_panel, wave30_v65_image_panel, wave31_v65_mechanism_panel, wave32 reset controls; `view29_manifest.jsonl`, `view30_manifest.jsonl` |
| Synthetic generator | `cop/data/synthetic.py`, build_shortcut |
| Image task and effective sizes | `cop/data/images.py`, build_image_shortcut; `data30.txt` |
| CNN structure and fold-compatible receiver | `cop/graph/builders.py`, build_cnn_cut |
| Neutral branch insertion and mask placement | `cop/graph/edits.py`, add_branch; `cop/experiments/growth.py`, _t_specialized |
| Fixed random partitions | `cop/experiments/trajectory.py`, _setup_spec_partition and _spec_split |
| Ancestor selection | `cop/experiments/common.py`, Selector; `cop/experiments/trajectory.py`, run_baseline |
| Swap and redistribution algebra | `cop/graph/redistribute.py` |
| Extraction definitions | `audit_v5/tools/fork_continuation.py`, component_change.py and image_forks.py |
| Inference and declared contrast scope | `configs/v66_wave29_registry.json`, v66_image_registry.json, v66_mechanism_registry.json |

## Prior work and novelty boundaries

- Net2Net: function-preserving growth is established.
- ExpandNets and RepVGG: training-time expansion with algebraic contraction is established.
- Arora et al. and RepOptimizer: equal expressiveness does not imply equal optimization; changing training geometry is established.
- Gradient Routing and ERA: backward masks, expansion and ablation are established; the paper must also acknowledge their discussion of absorption.
- GRAM: auxiliary modules trained for removable capability profiles are established, including contemporary large-model evidence.
- Maini et al.: layer rewinding, retraining and example-tied localization are established.
- SimCLR: a disposable training head improving retained representations is established.
- Model stitching: combining early and later layers as an evaluative tool is established; successful stitching is not an information-equivalence certificate.
- Shortcut-learning and JTT: the paper does not claim a new competitive group-robustness method.

The literature search supports this specific positioning but cannot prove universal absence of prior work. Avoid a blanket “first to show temporary modules change representations” statement.

## Essential interpretation constraints

1. Most headline benefits are normalised-extraction benefits, not native-network improvements.
2. The immediate swap gradient difference follows algebraically from the routing rule. The later component outcome is the empirical contribution.
3. Folding preserves the first layer immediately by construction. Persistence is assessed after compact continuation, against explicit controls.
4. The ordinary-versus-routed comparison changes gradient exposure, not only direction.
5. The primary synthetic native-harm test is unresolved.
6. The primary full-shift interaction is unresolved; its secondary arm cannot promote it.
7. The image result is a reversal, not a successful beneficial replication.
8. Normalised extraction is recipient-dependent and uses known blocks; an image whole-filter secondary reduces the latter dependence.
9. Two late mechanism secondaries are conditional. No primary is excluded.
10. Analysis plans are internal, not public preregistrations. The familywise correction does not cover the entire exploratory history.


## Descriptive reanalysis added during review

`reanalysis.py` reads the included `fork29_descriptive_states.csv`, `image30_descriptive_states.csv` and `fork31_descriptive_states.csv`, which are column subsets of the corresponding v70 state tables. It checks unique draw–seed keys, 24-pair coverage and normalisation eligibility. It produces `descriptive_pairs.csv`, `descriptive_summary.json` and `descriptive_absolute.csv`. Appendix F and Sections 4.1–4.4/4.6 use these outputs. All new intervals are unadjusted 95% intervals over 12 seed-averaged draws. All-run loss summaries include the declared late reference exception and retain its failure status. A separate 23-pair conditional native-error sensitivity and loss sensitivity exclude it; the affected draw contributes one seed. Loss tails otherwise summarize 24 individual runs.

The early swap diagnostics and regrowth plot use the included `swap_gradient_diagnostics.csv` and `early_regrowth.csv` subsets. The ordinary swap is a numerical symmetry control. The late starting loss and its reduction during folded continuation qualify the stationary-training interpretation. See `REVISION_NOTES.md` for all changes and the GRAM reference verification.
