---
title: How Temporary Neural Modules Change the Retained Network
subtitle: Routed updates, component extraction, and compact continuation
lang: en-US
bibliography: references.bib
link-citations: true
geometry:
  - letterpaper
  - margin=0.85in
fontsize: 11pt
colorlinks: true
linkcolor: black
urlcolor: blue
toc: false
header-includes:
  - '\usepackage{float}'
  - '\floatplacement{figure}{H}'
  - '\usepackage{needspace}'
---

## Abstract

Temporary neural modules can change both a predictor's computation and the updates received by its retained layers. We study these effects through shared-checkpoint continuations, function-preserving branch swaps, and exact folding followed by compact training. The component measure places a descendant's first layer in its ancestor, with the ancestor's weight norms and bias restored. Across 12 synthetic-task draws with two optimizer seeds each, routed continuation improves this normalised extraction by 1.76 percentage points over ordinary backpropagation; the raw-extraction difference is 0.49 points and unresolved. Routed training also raises training loss, with some runs exceeding 200 cross-entropy units. The late fork already has a 3.26-point normalised-extraction advantage over the ancestor. Folding and 1,500 compact updates leave a 3.07-point advantage, with little difference from ordinary continuation that retains the branches. Thus persistence is observed in a synthetic regime where ordinary continuations reach very low training loss. A branch swap preserves the current predictor but changes subsequent routed component error by 1.73 points; the swapped routed endpoint approaches ordinary continuation. Under ordinary gradients the swap is a relabelling symmetry. On a CIFAR-derived task, routing instead worsens normalised-extraction error by 12.51 points, while ordinary continuation partly reverses earlier damage. The study identifies how a backward-routing intervention can drive component changes separately from fitting the complete predictor, and shows why removal, persistence, and improvement require distinct measurements.

## 1 Introduction

Suppose we insert extra branches into a trained neural network without changing its predictions. We then train the expanded network and remove or fold the branches. What changed inside the layers that remain? The final network's accuracy gives one answer. Following a particular layer through the intervention gives another: the layer may work better in its original recipient, become dependent on the additions, or drift while the complete predictor deteriorates.

This question matters for training-time expansion and modular capability removal. A module affects the forward computation used for prediction and the updates that shape other components. Immediate deletion measures dependence on its current output. A comparison between training histories measures the changes accumulated while it was present. These measurements help distinguish a useful training aid from an unstable update rule, and a persistent change from one that further training quickly reverses.

Existing research establishes that training parameterization matters. Net2Net preserves a predictor while changing its architecture [@chen2016net2net]. ExpandNets and RepVGG introduce training-time structure that contracts for inference [@guo2020expandnets; @ding2021repvgg]. Linear overparameterization changes optimization [@arora2018optimization], and RepOptimizer reproduces aspects of structural reparameterization through gradient transformations [@ding2023repoptimizer]. Temporary projection heads and gradient-routing methods also explicitly influence representations or the location of computation. Our question concerns a specific retained component: how it changes under a controlled intervention, and what happens to that change when the intervention ends.

We use expanded networks with affine residual branches. At a shared checkpoint, we retain or release fixed per-example backward masks, exchange branches while preserving their summed forward output, or fold their affine maps into the receiving layer and continue compact training. We evaluate the first layer in the original network, both as trained and after restoring its original norms and bias. Training loss and native accuracy accompany these extraction measures.

The synthetic results reveal a separation between fitting and component movement. Ordinary continuation reaches very low training loss. Routed continuation can develop a better normalised first-layer extraction while training loss increases sharply. The raw-extraction improvement is unresolved. At the late fork, almost all of the advantage reported after folding is already present; retaining the branches with ordinary gradients gives a similar endpoint. A function-preserving swap suppresses much of the additional routed extraction change. The image experiment has a different outcome: routing damages the component, and ordinary continuation partly repairs it.

The contribution is a controlled account of these trajectories. The swap supplies a forward-preserving intervention with an exact ordinary-gradient symmetry control. Extraction, training loss and compact continuation then distinguish the component effect, the optimization failure and its subsequent persistence. The evidence supports a setting-dependent effect of routed updates on a retained layer. It also identifies the limits of reading that effect as better feature learning or robust retention after removal.

## 2 Background and related work

### 2.1 Temporary capacity and optimization

Net2Net constructs function-preserving changes that permit deeper or wider networks to inherit a trained predictor [@chen2016net2net]. ExpandNets trains compact networks through linear overparameterization and contracts the added layers algebraically [@guo2020expandnets]. RepVGG similarly separates a multibranch training structure from a simple inference structure [@ding2021repvgg]. Dense–Sparse–Dense training changes the available parameters over training and returns to a dense architecture [@han2017dsd]. Together, these methods establish that the architecture used to learn a predictor need not be the architecture used to deploy it.

This phenomenon has an optimization interpretation. Arora et al. show that depth in linear networks can induce a preconditioning effect [@arora2018optimization]. RepOptimizer incorporates model-specific gradient transformations without retaining the corresponding training-time structure [@ding2023repoptimizer]. We therefore treat altered optimization as an expected consequence of expansion. Our question concerns the location and persistence of its effects: how a specified retained layer changes, how ordinary continuation modifies it, and how forward-equivalent reallocations alter its trajectory.

### 2.2 Routing and localization

Gradient routing applies data-dependent masks during backpropagation. Cloud et al. use it to localize computation and introduce Expand, Route, Ablate for capability removal [@cloud2024routing]. Their discussion of absorption already concerns how computation in one region influences what is learned elsewhere. Gradient-routed auxiliary modules (GRAM) are added during pretraining and selectively updated to obtain capability profiles through removal [@roland2026gram]. Maini et al. study memorization through gradient accounting, layer rewinding and retraining, and introduce example-tied dropout to influence its location [@maini2023memorization].

These are close precedents. Our distinction is the controlled comparison of later learning after branch computation is reassigned without changing the current predictor, together with extraction of a retained component and continuation after exact folding. Our partitions are fixed random assignments of examples. The study concerns the resulting backbone dynamics; testing capability isolation would require capability-specific partitions and evaluations.

### 2.3 Temporary heads and representation measurement

SimCLR demonstrates that a learned projection between a representation and its training objective can improve the representation evaluated downstream [@chen2020simclr]. This is a direct precedent for a module helping to train features that remain useful after the module is discarded. Our image panel includes a late nonlinear auxiliary-head arm as a related control, using a supervised classification objective.

Model stitching evaluates whether an early representation can support another model's later layers through a learned interface [@bansal2021stitching]. Our extraction is a restricted version of this idea: the recipient is the donor's own ancestor, neuron indices are retained, and no alignment layer is fitted. This restriction supports an intervention-specific interpretation but makes the result recipient-dependent. Smith et al. show that successful stitching can connect representations with substantially different information [@smith2025alignment]. Accordingly, we interpret extraction as compatibility with the specified recipient.

### 2.4 Shortcut settings as controlled test environments

Shortcut learning provides a setting in which training accuracy can conceal reliance on an unstable cue [@geirhos2020shortcut]. Group-robustness methods such as Just Train Twice target performance under such correlations [@liu2021jtt]. We use controlled shortcuts to create competing predictive signals and to define evaluation environments. A competitive robustness claim would require comparisons with those methods and explicit worst-group evaluation. Here the shortcut-independent test distribution measures the consequences of the intervention.

The contribution relative to these strands can be stated precisely. We connect a forward-preserving branch reallocation to later component performance, and examine that performance together with training loss and ordinary continuation. Established expansion, routing and stitching tools make this intervention study possible.

## 3 Methodology

### 3.1 Separate present contribution from training history

Let $f_0$ be a trained compact network, and let $h_\theta(x)$ denote the backbone representation at a chosen cut. We insert residual branches $b_{\phi_j}$ and write the merge as

$$z=h_\theta(x)+\sum_{j=1}^{J}b_{\phi_j}(h_\theta(x)). \tag{1}$$

Each new branch initially contributes zero, so insertion preserves the predictor. All branches participate in every forward pass. The principal branches are affine maps represented by two trainable affine factors with no intervening nonlinearity. Their factorization changes the training parameterization, while the merged affine computation remains foldable into the next layer.

Deleting branches from a fixed trained state measures the effect of replacing the sum in (1) by zero. A history comparison instead trains two descendants of the same ancestor and compares their retained components. Neither effect determines the other. Algebraic foldability establishes compact representability. Whether direct compact training reaches the same component is an empirical question.

### 3.2 Routing changes the backward computation

For training example $i$, branch $j$ receives a binary mask $m_{ij}$. The forward output remains $b_j(h_i)$, while its backward path is multiplied by $m_{ij}$. Equivalently, the implementation uses

$$\widetilde b_j(h_i)=m_{ij}b_j(h_i)+(1-m_{ij})\operatorname{sg}(b_j(h_i)), \tag{2}$$

where $\operatorname{sg}$ is the stop-gradient operator. The direct backbone path is never masked. If $\delta_i$ is the backward signal at the merge, the signal reaching its input is

$$g_i^{\mathrm{routed}}=\left[I+\sum_jm_{ij}J_j(h_i)\right]^\top\delta_i, \qquad
g_i^{\mathrm{ordinary}}=\left[I+\sum_jJ_j(h_i)\right]^\top\delta_i, \tag{3}$$

where $J_j$ is the branch Jacobian. Equation (3) specifies a modified backward rule. Its signal can differ from the derivative of the unchanged forward predictor, so its optimizer update has no general descent guarantee for the forward training loss. For the actual parameter change $\Delta\theta$, the first-order change in that loss is $\nabla L^\top\Delta\theta$; the sign depends on the current state and optimizer. We therefore track training loss alongside component error. Rising loss in some trajectories is evidence of instability, without implying that every routed step is an ascent step.

Branches are added in pairs. A fixed random partition assigns approximately 95% of training examples to branch $a$ and the remainder to branch $b$. In the synthetic experiment the exact fraction matches the observed majority-group proportion, with randomized membership independent of group identity. The image experiment fixes the fraction at 0.95. The same membership applies to each pair. Ordinary continuation releases these masks and passes each example's gradient through every branch. Ordinary and routed continuation therefore differ in both gradient exposure and the branch Jacobians that contribute.

### 3.3 Shared-checkpoint continuations

The expansion trajectory has two rounds of $U=2{,}000$ updates. A zero-output branch pair is inserted at the beginning of each round, at the same cut. We fork at 1,000 updates, when one pair is present, and at 2,500 updates, when two pairs are present. Forks keep the architecture present at their start unless they fold it; they do not perform the trajectory's later scheduled insertions. Every fork ends at a total of 4,000 updates since the selected ancestor, giving 3,000 or 1,500 continuation updates respectively.

The principal continuations are:

| Continuation | Added branches | Backpropagation | Optimizer at fork |
|:--|:--|:--|:--|
| Routed | Trainable | Fixed example masks retained | Reset |
| Ordinary | Trainable | Masks released | Reset |
| Frozen scaffold | Frozen at checkpoint | Masks released | Reset |
| Folded compact | Composed into receiving layer and removed | Ordinary | Reset |
| Routed carried | Trainable | Fixed example masks retained | Carried |

Fork comparisons share the saved state, minibatch stream, learning rate, training budget and input-freeze condition. A primary lineage leaves every backbone parameter trainable, denoted A. A secondary lineage, B, holds the first layer's shortcut-input weights at their ancestor values. B uses privileged knowledge of the feature layout and is not the basis of the main claim.

Compact controls continue the same ancestor for 4,000 updates, or for 8,000 updates as a longer-budget comparison. Separate compact controls reset the optimizer at the corresponding fork time. These controls distinguish additional training and optimizer reset from expansion history. Equal update counts do not imply equal computation; we report measured training multiply–accumulate counts separately.

### 3.4 Function-preserving interventions

**Branch swap.** Within each pair, exchange the complete affine-branch parameters while leaving example masks attached to their original branch slots. The sum of branch outputs is unchanged in exact arithmetic. Under ordinary backpropagation with a reset optimizer, this is a parameter-relabelling symmetry: identical branch architectures, shared optimizer settings and identical minibatches give equivalent trajectories in exact arithmetic. The ordinary swap is therefore a symmetry control for numerical departures. Under routing, the change in the signal at the cut for one pair is

$$g_i^{\mathrm{swap}}-g_i
=(m_{ia}-m_{ib})(J_b-J_a)^\top\delta_i. \tag{4}$$

Equation (4) supplies a manipulation check. The sign and size of the later component-error change require measurement.

**Folding.** Write the aggregate branch map as $Mh+c$, so the receiving layer computes $W[(I+M)h+c]+b$. Replace it by

$$W_{\mathrm{fold}}=W(I+M),\qquad b_{\mathrm{fold}}=b+Wc. \tag{5}$$

Remove the branches and their masks, then continue ordinary training in the compact architecture. This preserves the current forward function in exact arithmetic but generally changes subsequent updates. Immediate preservation of the first layer is built into folding; the substantive test is the component's performance after further compact training relative to the specified controls.

**Redistribution without removal.** To move a fraction $t$ of the branch computation into the receiver, set $s=1-t$, scale branch outputs by $s$, and use

$$W'=W(I+M)(I+sM)^{-1},\qquad b'=b+Wc-sW'c, \tag{6}$$

when the inverse exists. The full-shift case $t=1$ leaves zero-output branches in place and trainable. It is therefore distinct from folding and deletion: the branches may grow again. Partial redistribution requires a conditioning check because casting the transformed parameters to float32 can change the predictor appreciably.

Swaps and redistributions change the parameter configuration from which training proceeds. The measured interaction describes the combined effect of routing and reallocation on later component performance.

### 3.5 Extract the retained component into a fixed recipient

Write $f_0(x)=D_0(\sigma(W_0x+b_0))$, with all layers after the first included in $D_0$. Raw extraction evaluates $D_0(\sigma(W_tx+b_t))$ using a descendant's first layer. Neither the original downstream network nor a fitted interface is trained during this measurement.

For the primary normalised extraction, partition input coordinates into declared blocks $C_k$. For output unit $r$, set

$$\overline W_{t,r,C_k}
=\frac{\lVert W_{0,r,C_k}\rVert_2}{\lVert W_{t,r,C_k}\rVert_2}W_{t,r,C_k},\qquad
E_t(x)=D_0(\sigma(\overline W_tx+b_0)). \tag{7}$$

The implementation checks eligibility and norm restoration; undefined or failed normalisations are excluded and reported. For a convolutional first layer, a block includes all spatial kernel entries in its input-channel group. Synthetic blocks are label-generating, shortcut and noise coordinates; image blocks are RGB channels and the shortcut channel. A secondary image measure restores each output filter's overall norm without using this grouping.

Equation (7) removes blockwise per-unit magnitude differences and first-layer bias changes. Its error remains a joint property of the extracted layer and $D_0$. This measure combines the descendant's weight directions with the ancestor's norms, bias and downstream network. We report raw extraction alongside it to show how much the conclusion depends on that edit.

### 3.6 Experimental settings

The synthetic input is $x=(c,s,n)$, with 12 Gaussian label-generating coordinates, one shortcut coordinate and 12 Gaussian noise coordinates. A latent group $g$ has rare-group probability 0.05, and $y=\mathbf{1}\{w_g^\top c>0\}$ for independently sampled group-specific rule vectors. The group is not supplied as a predictor input. The shortcut is $s=2a-1+0.5\epsilon$, with $\epsilon\sim\mathcal N(0,1)$. In training and source validation, $a=y$ with probability 0.95. In the main test set, $a$ is independent of $y$. The model is a ReLU MLP with six hidden layers of width 128; the cut follows hidden layer 3. Each branch has internal width 32.

The image task uses eight CIFAR-10 classes [@krizhevsky2009cifar]: airplane, automobile, ship and truck versus cat, deer, dog and horse. The three RGB channels are standardised using training-subset statistics. A fourth, spatially constant channel carries the same noisy shortcut construction. The test images come from the official test split, with the shortcut independent of the label. No data augmentation is used. The CNN has two 32-channel $3\times3$ convolutional layers, max pooling, a 32-to-64 channel $1\times1$ receiving layer, a 64-channel $3\times3$ convolution, max pooling, global average pooling and a binary classifier. Hidden affine layers are followed by ReLU; there is no batch normalisation. The cut is after the first pooling operation. Affine branches act positionwise with internal width 32. The unpadded $1\times1$ receiver permits exact folding including image borders.

| Setting | Training examples | Source validation | Test examples | Ancestor training budget | Repetitions |
|:--|--:|--:|--:|--:|:--|
| Synthetic MLP | 4,096 | 2,048 | 8,192 | 4,000 updates | 12 draws × 2 seeds |
| CIFAR-derived CNN | 8,192 | 2,000 | 8,000 | 6,000 updates | 12 draws × 2 seeds |

All models use AdamW with learning rate $10^{-3}$, betas $(0.9,0.999)$, batch size 128, no weight decay, no clipping and a constant learning rate. Training uses float32. The ancestor is selected by minimum source-validation cross-entropy among declared checkpoints, retaining its complete training state. Descendant measurements use fixed-budget checkpoints. The synthetic draws vary generated data and rule vectors. Image draws vary the sampled training data and shortcut realizations over a fixed underlying CIFAR split, so the uncertainty is conditional on that source dataset.

### 3.7 Estimands and uncertainty

We report test-error differences in percentage points. Paired differences are first averaged over the two optimizer seeds within each draw, then summarised over 12 draws with Student $t$ intervals. The four primary synthetic contrasts use 98.75% intervals; the five primary image contrasts use 99% intervals; the two primary mechanism interactions use 97.5% intervals. These correspond to nominal Bonferroni familywise 95% coverage within each panel under the $t$-interval assumptions. Secondary contrasts use unadjusted 95% intervals. Additional descriptive comparisons introduced during manuscript review use the same draw-level aggregation and unadjusted 95% intervals; they are labelled separately in Appendix F.

For the swap, let $e_{r,s}$ be normalised-extraction error under routing condition $r$ and swap condition $s$. The primary interaction is

$$\Delta_{\mathrm{swap}}=(e_{\mathrm{routed,swap}}-e_{\mathrm{routed,base}})
-(e_{\mathrm{ordinary,swap}}-e_{\mathrm{ordinary,base}}). \tag{8}$$

A positive interaction means the swap increases component error more under routing. We use the analogous interaction for full redistribution. In performance plots, positive values indicate an error reduction; the mechanism-interaction plot explicitly reports error increases.

## 4 Results

### 4.1 The early synthetic benefit depends on the extraction measure

The ancestor's mean test error is 24.19% on the synthetic task and 20.95% on the image task. The table gives absolute early-fork endpoint errors for lineage A, averaged over the two optimizer seeds within each of 12 draws. Both continuations start from the same expanded checkpoint and reset the optimizer.

| Setting and endpoint | Raw extraction (%) | Normalised extraction (%) | Native model (%) |
|:--|--:|--:|--:|
| Synthetic ancestor | 24.19 | 24.19 | 24.19 |
| Synthetic ordinary continuation | 23.60 | 22.76 | 23.57 |
| Synthetic routed continuation | 23.12 | 21.00 | 23.83 |
| Image ancestor | 20.95 | 20.95 | 20.95 |
| Image ordinary continuation | 21.20 | 21.66 | 19.84 |
| Image routed continuation | 35.43 | 34.17 | 33.80 |

In the synthetic experiment, routed continuation reduces normalised-extraction error by 1.76 points relative to ordinary continuation, with a primary 98.75% interval of [0.31, 3.21], favourable in all 12 draws. The raw-extraction difference is 0.49 points [−0.09, 1.06], an unresolved descriptive contrast. The resolved advantage therefore concerns the edited layer placed in its ancestor. The corresponding native-error contrast is also unresolved: routing increases error by 0.26 points [−0.78, 1.31]. These three outcomes separate the component as trained, the component after normalisation, and the complete trained network.

![Early-fork continuation effects, with positive values indicating lower error under routing. The normalised-extraction and native-model intervals use their panel's primary level (98.75% synthetic; 99% image). Raw synthetic extraction is descriptive and uses an unadjusted 95% interval. Points mark means over 12 draws, with optimizer seeds averaged within each draw.](figures/fig1_component_effects.png){width=95%}

### 4.2 Routed component change accompanies training instability

Ordinary synthetic training reaches very low training loss, whereas routed continuation can move into high-loss states. The table summarises native training cross-entropy over all 24 draw–seed runs. Its medians describe typical runs; the maximum and counts expose the unstable tail. All these summaries are descriptive.

| Fork and continuation | Median training loss | Maximum loss | Runs with loss > 1 |
|:--|--:|--:|--:|
| Early, ordinary | $2.42\times10^{-8}$ | 0.395 | 0/24 |
| Early, routed | 0.0378 | 205.67 | 4/24 |
| Late, ordinary | $1.03\times10^{-7}$ | 0.333 | 0/24 |
| Late, routed † | 0.3965 | 244.70 | 8/24 |

† The all-run late summaries retain the numerical exception described in Appendix D. Excluding that state gives median loss 0.2812, with 8 of 23 above 1 and the same maximum.

At the late fork, routed continuation ends with 11.07% mean source-validation error, compared with 5.05% under ordinary continuation. Native test error is worse by 4.09 points [−0.13, 8.30], with a harmful draw mean in 10 of 12 draws; this descriptive interval includes zero. Excluding the flagged state gives a conditional 3.02-point difference [−0.42, 6.47], also unresolved. The training-loss increase is consequential even where a test-error contrast is unresolved.

The compact synthetic control's first-layer weight matrix moves by a mean 0.67% of its ancestor norm over 4,000 further updates (median 0.48%). Along the original routed expansion trajectory, the normalised-extraction advantage over the ancestor is 1.63 points at update 1,000, 3.26 at update 2,500 and 4.14 at update 4,000. These are descriptive snapshots: a second branch pair is inserted at update 2,000, so elapsed time and branch count change together.

This pattern is consistent with routed updates sustaining component movement while ordinary training has little remaining fitting progress. The modified backward rule has no descent guarantee for the forward loss, and several routed runs show severe instability. The improved normalised extraction must therefore be interpreted together with the loss trajectory and the unresolved raw-extraction gain.

### 4.3 Folding largely preserves an advantage already present

At the late synthetic fork, normalised extraction is already 3.26 points better than the ancestor. After folding and 1,500 compact updates, that advantage is 3.07 points, with primary interval [1.64, 4.50]. The paired increase in extraction error from the fork to the folded endpoint is only 0.19 points [−0.01, 0.39]. Folding and ordinary continuation that retains the branches differ by −0.07 points [−0.24, 0.10] in endpoint error. The latter two comparisons are descriptive and unresolved. The data show little measurable erosion under either ordinary continuation, with no demonstrated advantage of folding over simply releasing the masks.

The optimization context qualifies this persistence. The late starting state's median training loss is 0.0991, which falls to $1.33\times10^{-7}$ after folded continuation. Further fitting does occur, but both ordinary continuations end in a very low-loss regime. The component comparison therefore demonstrates retention over this particular continuation; resistance to sustained competing learning remains untested.

Against other compact histories, the folded endpoint improves normalised extraction by 3.02 points [1.57, 4.48] over 4,000 compact updates, favourable in all 12 draws. The reset-matched control gives a 2.72-point advantage [1.68, 3.77], favourable in 11 draws, and the 8,000-update control gives 3.02 points [1.94, 4.10], favourable in all 12. The latter two comparisons are secondary. These controls establish a difference from the tested compact training recipes; the start-to-end comparison locates almost all of that difference before folding.

From the selected ancestor onward, the late folded synthetic path uses 1.144 times the training MACs of the 4,000-update control and 0.572 times those of the 8,000-update control. The corresponding image ratios are 1.038 and 0.519. These ratios exclude shared ancestor training and measure arithmetic cost. Folding itself composes the affine branches into the receiver and leaves the first layer unchanged at the edit.

![Late synthetic fork: the advantage already present, its subsequent change, and endpoint comparisons. Positive values favour the named state over its reference. The starting-state advantage, start-to-folded change and folded-versus-ordinary difference are descriptive 95% intervals. Endpoint comparisons with the ancestor and 4,000-update compact control are primary (98.75%); the reset-matched comparison is secondary (95%).](figures/fig2_folding_controls.png){width=95%}

### 4.4 A forward-preserving swap suppresses the additional routed change

The early swap interaction is 1.81 points [0.43, 3.19] at the primary 97.5% level, positive in all 12 draws. Swapping branches increases normalised-extraction error by 1.73 points [0.67, 2.79] under routing. Under ordinary gradients, the swap is an exact parameter-relabelling symmetry with a reset optimizer. Its measured −0.08-point difference [−0.26, 0.10] quantifies the finite-precision departure from that symmetry. Both individual-arm intervals are secondary.

The swapped routed endpoint has almost the same extraction error as unswapped ordinary continuation: routed swap minus ordinary is −0.03 points [−0.70, 0.64], a descriptive interval. Its median training loss is $1.05\times10^{-7}$, although the maximum is 0.694. This is consistent with the swap suppressing the additional routed drift that improves the normalised extraction in the unswapped synthetic arm. Endpoint similarity alone cannot establish that the underlying weights or complete trajectories coincide.

The first-update diagnostic agrees with the algebra. Across 24 ancestor instances, the median relative first-layer gradient change under an ordinary swap is $1.25\times10^{-15}$, versus 0.856 under routing. The median gradient cosine is 1 under ordinary gradients and 0.625 under routing; median update cosines are 1 and 0.482. The routed distribution includes near-opposite gradients. These values verify that the edit changes the prescribed backward computation while preserving the forward sum.

The native-error interaction is unresolved: 0.95 points [−1.79, 3.70]. The measured mechanism result is therefore specific: assigning the same learned branch maps to different backward partitions changes later normalised component error. The immediate gradient change follows algebraically from the routing rule. The empirical result connects that intervention to the later component and loss outcomes.

![Early-fork branch swaps. The upper panel reports increases in normalised-extraction error: the routing-by-swap interaction, within-rule swaps, and the descriptive swapped-routed versus ordinary endpoint comparison. The primary interaction uses 97.5%; the other intervals use 95%. Lower panels show first-update gradient diagnostics for 24 ancestors, with medians marked. The ordinary swap is a symmetry control.](figures/fig3_swap_mechanism.png){width=95%}

### 4.5 Redistribution and regrowth

The early full-shift interaction is 1.12 points [−0.08, 2.32] at its primary 97.5% level and remains unresolved. The routed full-shift arm alone has a secondary 95% interval just above zero; the interaction is the relevant test of the difference between backward rules.

Full shift leaves zero-output branches available for further training. At the final recorded update, median net branch-output RMS divided by merge-input RMS is 0.242 under routing and 0.0412 under ordinary gradients. The distribution spans several orders of magnitude. Regrowth measures renewed branch activity; assessing its necessity would require another intervention on the regrown computation. Folding removes these trainable branches, whereas full shift retains them.

### 4.6 Images show damage and partial recovery under ordinary training

On the image task, early routed continuation increases normalised-extraction error by 12.51 points [7.77, 17.25] at the primary 99% level and native error by 13.96 points [10.02, 17.90]. Both changes are harmful in every draw. The state at the early fork is already 5.98 points [1.70, 10.26] worse than the ancestor in normalised extraction. Ordinary continuation then recovers 5.27 points [1.95, 8.59]. These last two contrasts are descriptive. The routed-versus-ordinary endpoint difference thus combines additional routed damage with substantial ordinary recovery.

Ordinary image training remains active: the compact control's first-layer weights move by a mean 16.21% of their ancestor norm over 4,000 updates. At the early expanded fork, ordinary continuation reduces median training loss from 0.147 to 0.00514. This differs substantially from the nearly stationary compact synthetic control. Data, architecture and optimization state change together, so this comparison suggests a boundary for persistence without isolating its cause.

The late folded image component is worse than the ancestor by 7.10 points [0.46, 13.75]. Its disadvantage to the 4,000-update compact control is 6.49 points [−0.11, 13.10], unresolved at the primary level. Against the reset-matched control, the secondary disadvantage is 6.99 points [2.63, 11.35]. Thus removal and compact continuation can retain harmful component changes too.

The image reversal persists with alternative measurements and controls. Whole-filter normalisation gives a secondary 13.31-point routing disadvantage [9.94, 16.69]; freezing the known shortcut channel gives 14.55 points [10.41, 18.70] in lineage B. The end-of-expansion routed arm is worse than the late nonlinear-head arm by 12.09 points [4.87, 19.30] at the primary level. The head's own comparison with compact continuation is unresolved, with a 0.46-point advantage [−0.44, 1.36]. Placement, nonlinearity and routing all change in that head comparison.

### 4.7 Secondary findings and numerical validation

The synthetic B lineage gives an early normalised component advantage of 1.81 points [0.75, 2.87] and a raw-extraction advantage of 2.47 points [1.20, 3.75]. B uses the known shortcut location, so its raw result concerns a different intervention from the unrestricted A lineage. Appendix C reports all 36 planned contrasts. Appendix F gives the additional descriptive comparisons, absolute errors and loss summaries introduced during manuscript review.

The final evaluation compares stored models against a separate raw-PyTorch reference, checks edited parameters and result-table agreement, and verifies checkpoint reproduction. All 8,016 applicable float64 function comparisons pass. Re-evaluating the 24 fully covered statistical hypotheses from float64 reference error counts changes none of their readings. Two numerical exceptions remain declared; neither affects a primary contrast. Two late mechanism secondaries are conditional on 23 of 24 draw–seed pairs. Appendix D gives the exceptions and the scope of the checks.

## 5 Discussion

### 5.1 The component effect and its optimization context

The experiments distinguish three quantities: the current forward predictor, the backward update rule, and the performance of a retained component in a specified recipient. A branch swap can preserve the first while changing the second. The synthetic mechanism panel shows a subsequent change in the third. Exact ordinary-gradient relabelling provides a useful symmetry control for this experiment.

The loss summaries substantially narrow the interpretation. A normalised component advantage can coexist with instability in the complete network. In the synthetic task, routed updates continue to alter the component while ordinary controls settle into low-loss states. Swapping the branches leaves the swapped routed endpoint close to ordinary continuation in extraction error and median loss. This pattern supports routing-dependent drift as an explanation of the additional component change. Determining whether the same effect can be produced by a stable compact update rule remains open.

The extraction intervention also matters. For the main early synthetic contrast, the resolved improvement appears after restoring ancestor norms and bias. The raw layer's smaller improvement is unresolved. The result concerns the descendant's weight directions evaluated with that prescribed rescaling and recipient; transfer to new recipients and semantic feature identification require separate evidence.

### 5.2 What persistence after removal means here

The late synthetic component advantage is already present before folding. Folded and unfurled ordinary continuations preserve similar amounts of it. Their low endpoint training losses and the compact control's small movement make limited pressure for further change a plausible explanation of retention. The late fork still has fitting work to do: folding reduces its median loss from about 0.10 to $10^{-7}$. The observed persistence therefore covers further fitting in this regime, while leaving resistance to active competing learning unresolved.

The image trajectories demonstrate why that qualification matters. Ordinary continuation repairs much of the early routed component damage while continuing to reduce training loss. The two settings differ in several respects, and the experiments do not isolate optimization stationarity as the cause. Together they show that a removal score and a post-removal endpoint need the starting component and the subsequent training dynamics for interpretation.

### 5.3 Scope

The study covers one controlled synthetic family and one CIFAR-derived binary task, with one architecture in each confirmatory setting. Image uncertainty is conditional on the source dataset and split. The synthetic labels depend on a latent group, creating ambiguity when that group is unobserved. These settings establish neither broad benchmark superiority nor worst-group robustness.

Normalised extraction uses a specified ancestor recipient and declared input blocks; a whole-filter image measure provides a secondary check on the latter choice. Routing changes total branch gradient exposure as well as the gradient direction. Folding applies to the tested affine graph, and redistribution changes parameterization. The component comparisons are bounded by these interventions, optimizer settings and budgets. Earlier exploratory development and the later descriptive reanalysis also limit claims about confirmation; Appendix B records that provenance.

## 6 Conclusion

Temporary branches can alter a retained layer through the backward updates they induce. In the synthetic setting, routing produces a better normalised extraction alongside unstable training, while the raw improvement is unresolved. A forward-preserving swap largely suppresses the additional routed component change. Folding preserves an advantage already present, and ordinary continuation with branches retained gives a similar outcome. On images, routing damages the component and ordinary training partly reverses that damage. The useful experimental lesson is to measure the retained component, forward loss and post-intervention trajectory together when assessing what temporary modules have changed.

## Appendix A Algebra and intervention scope

For affine branches $b_j(h)=B_j(A_jh+a_j)+b_j^{\mathrm{out}}$, the aggregate map is $M=\sum_jB_jA_j$ and $c=\sum_j(B_ja_j+b_j^{\mathrm{out}})$. Substitution into the receiving layer gives (5). For partial redistribution, the modified preactivation is $W'(I+sM)h+sW'c+b'$; inserting (6) reduces it to $W(I+M)h+Wc+b$. The construction requires $I+sM$ to be invertible. Full folding does not require that inverse.

For a swap, the sum $b_a(h)+b_b(h)$ and its ordinary derivative are unchanged. The routed derivative before the edit is $I+m_aJ_a+m_bJ_b$ and after it is $I+m_aJ_b+m_bJ_a$, giving (4). These identities specify the edits and their immediate gradients. Floating-point evaluation can differ through summation order or parameter casting, which is why the implementation records separate precision checks.

A frozen affine scaffold is not generally equivalent to folded compact training. If the fixed scaffold is $z=Ah+c$, the receiver's effective compact weight is $WA$. Under SGD, with $G$ the compact weight gradient and $g_b$ its bias gradient, one expanded receiver update induces

$$\Delta(WA)=-\eta\left(GA^\top A+g_bc^\top A\right). \tag{9}$$

Direct compact SGD instead induces $-\eta G$. The offset term matters, and AdamW introduces additional coordinate-dependent state. Thus frozen-scaffold training and folded compact training are distinct diagnostic arms.

## Appendix B Implementation and evaluation details

The principal synthetic data draws are 349–360; image draws are 361–372. Each uses optimizer seeds 0 and 1. Mechanism forks reuse the synthetic ancestors and checkpoints, so they are not an additional independent replication of that dataset. All branches in a pair use the same input representation. The random partition is saved with the trajectory, and the direct residual path remains unmasked. New branch output factors start at zero while their input factors are initialized, making their initial forward contribution zero without preventing subsequent learning.

The ancestor selection rule evaluates declared candidates on source-validation cross-entropy, breaks ties in favour of the earlier checkpoint, and preserves the selected optimizer and data-stream state. Eight scheduled candidates are configured; the selection mechanism also supports the initial candidate. The fixed-budget endpoints analysed here are not replaced by validation-selected descendants. Compact reset controls carry the ancestor's optimizer to the specified fork time and then reset it before the remaining updates.

The synthetic test redraws the shortcut independently of the label. A separate reversed-correlation set and rare-group set exist in the experimental package, but are not substitutes for the primary test distribution. In the image task, all 8,000 official test images belonging to the eight selected classes are used; the effective count is 8,000 rather than the generic 8,192 test-size configuration field. Three disjoint validation subsets of 2,000 official training images are available, but the ancestor uses source validation. RGB normalization is fitted only on the selected training subset; the shortcut channel retains its specified raw scale.

For each scalar contrast, let $d_{so}$ be the paired value for draw $s$ and optimizer seed $o$. We compute $\bar d_s$ by averaging eligible seeds within a draw, then report $\bar d\pm t_{n-1,1-\alpha/2}\,s_d/\sqrt n$ over draw means. The two conditional late mechanism contrasts each omit the declared failed draw–seed state; the affected draw therefore contributes its one remaining eligible seed. These are not complete-pair estimates and are labelled conditional. No primary test uses this exception.

**Analysis provenance.** The work developed through earlier exploratory panels. The synthetic primary contrast plan was recorded while its replication panel was training, before its results were inspected; the image and mechanism plans were recorded before results from their panels existed. These were internal analysis plans, not public preregistrations. Later reset-matched controls are labelled secondary. Multiplicity adjustments apply to the stated families, not retrospectively to the entire exploratory program. Additional comparisons in Appendix F were calculated during manuscript review from saved state tables. They are descriptive, with unadjusted intervals, and leave the planned contrast inventory unchanged.

## Appendix C Complete contrast inventory

The following tables use the registry's favourable orientation. Positive values favour the named directional hypothesis. For two-sided mechanism contrasts, positive values mean increased extraction error under the stated edit or interaction, not a performance benefit. Primary intervals use the family-specific adjusted level; secondary intervals are 95%. “Unresolved” means the interval includes zero. All differences are percentage points.

### C1 Synthetic MLP

P denotes primary (98.75% intervals); S denotes secondary (95% intervals). Draw counts are the number of positive draw means. 

| Contrast | Difference and interval | Positive draws | Role |
|:--|--:|:--:|:--:|
| Early routing benefit in normalised extraction | +1.76 [+0.31, +3.21] | 12/12 | P |
| Early routing harm in native error | +0.26 [-0.78, +1.31] | 5/12 | P |
| Late folded benefit over ancestor | +3.07 [+1.64, +4.50] | 12/12 | P |
| Late folded benefit over compact 4,000 | +3.02 [+1.57, +4.48] | 12/12 | P |
| B early routing benefit in normalised extraction | +1.81 [+0.75, +2.87] | 10/12 | S |
| B early routing benefit in raw extraction | +2.47 [+1.20, +3.75] | 10/12 | S |
| B early routing harm in native error | -0.21 [-3.52, +3.10] | 3/12 | S |
| B late folded benefit in raw extraction | +3.75 [+2.30, +5.21] | 12/12 | S |
| Late folded benefit over compact 8,000 | +3.02 [+1.94, +4.10] | 12/12 | S |
| Late folded benefit over reset compact | +2.72 [+1.68, +3.77] | 11/12 | S |
| Early folded benefit over reset compact | +1.22 [+0.57, +1.88] | 10/12 | S |
| Early routed benefit over reset compact | +2.84 [+1.65, +4.02] | 12/12 | S |

### C2 CIFAR derived CNN

P denotes primary (99% intervals); S denotes secondary (95% intervals). Draw counts are the number of positive draw means. 

| Contrast | Difference and interval | Positive draws | Role |
|:--|--:|:--:|:--:|
| Early routing benefit in normalised extraction | -12.51 [-17.25, -7.77] | 0/12 | P |
| Early routing harm in native error | +13.96 [+10.02, +17.90] | 12/12 | P |
| Late folded benefit over ancestor | -7.10 [-13.75, -0.46] | 3/12 | P |
| Late folded benefit over compact 4,000 | -6.49 [-13.10, +0.11] | 3/12 | P |
| Routed expansion benefit over late head | -12.09 [-19.30, -4.87] | 1/12 | P |
| Early routing benefit with whole-filter norms | -13.31 [-16.69, -9.94] | 0/12 | S |
| Routed expansion benefit over ordinary expansion | -12.15 [-17.04, -7.26] | 0/12 | S |
| Late head benefit over compact | +0.46 [-0.44, +1.36] | 7/12 | S |
| B early routing benefit in normalised extraction | -14.55 [-18.70, -10.41] | 0/12 | S |
| B early routing benefit in raw extraction | -16.94 [-21.60, -12.28] | 0/12 | S |
| Late folded benefit over compact 8,000 | -6.62 [-11.12, -2.11] | 3/12 | S |
| Late folded benefit over reset compact | -6.99 [-11.35, -2.63] | 3/12 | S |
| Early routed benefit over reset compact | -12.86 [-16.50, -9.22] | 0/12 | S |

### C3 Function preserving mechanism interventions

P denotes primary (97.5% intervals); S denotes secondary (95% intervals). Draw counts are the number of positive draw means. A dagger marks a conditional comparison with 23 eligible draw–seed pairs.

| Contrast | Difference and interval | Positive draws | Role |
|:--|--:|:--:|:--:|
| Early swap interaction | +1.81 [+0.43, +3.19] | 12/12 | P |
| Early full-shift interaction | +1.12 [-0.08, +2.32] | 9/12 | P |
| Swap minus no swap under routing | +1.73 [+0.67, +2.79] | 12/12 | S |
| Swap minus no swap under ordinary gradients | -0.08 [-0.26, +0.10] | 5/12 | S |
| Half shift minus unedited under routing | +0.41 [-0.82, +1.64] | 5/12 | S |
| Full shift minus unedited under routing | +0.93 [+0.01, +1.86] | 9/12 | S |
| Early swap interaction in native error | +0.95 [-1.79, +3.70] | 6/12 | S |
| Late swap interaction † | +0.94 [+0.11, +1.78] | 10/12 | S |
| Late full-shift interaction † | +0.52 [-0.10, +1.14] | 10/12 | S |
| B early swap interaction in raw extraction | +2.47 [+0.89, +4.05] | 10/12 | S |
| Full shift minus unedited under ordinary gradients | -0.19 [-0.39, +0.01] | 4/12 | S |


![Regrowth after moving the entire affine branch map into the receiver. Thin curves correspond to individual ancestor instances; thick curves are medians. The initial zero is omitted from the logarithmic axis. The curves measure renewed branch activity.](figures/figS1_regrowth.png){width=85%}

## Appendix D Numerical validation and retained exceptions

The final report contains 8,016 reference rows: 2,808 synthetic, 2,808 image and 2,400 mechanism measurements. A separately implemented raw-PyTorch evaluator is compared with the graph implementation in float64 at a per-logit tolerance of $10^{-9}(1+|z|)$. All function comparisons pass. All applicable parameter, eligibility and table checks pass. Retraining 15 selected runs reproduces 114 saved checkpoints value by value. The training-validation record reports 1,248 CPU tests passed and 68 CUDA tests passed; the report-only closeout additionally records 37 passing tests. These counts are engineering evidence, not additional statistical samples.

One half-shift B fork on synthetic draw 349, seed 0, fails its saved-parameter function-preservation threshold: the recorded discrepancy is $1.21836\times10^{-5}$ against $10^{-5}$, with a transformation condition number of approximately $101{,}451$. Reproduction of the same result does not cancel the failure. No planned hypothesis reads that state.

A separate late A routed-reset state exceeds a first-order floating-point error estimate on one of 8,192 CPU-evaluated examples. The worst ratio is 57.11. Float64 implementation agreement passes; reference, CPU and GPU each make 4,047 classification errors. The state remains excluded from the two late mechanism secondary comparisons. Evaluating the affected example alone removes the observed discrepancy, and a sign change is recorded in an intermediate preactivation. These observations do not identify the cause of the exceedance.

The rounding calculation is an empirical first-order estimate, not a rigorous upper bound. It neglects higher-order terms, activation-pattern changes and transform-convolution algorithms, and uses float32 for the image calculation's local terms and Jacobians. It cannot replace the independent function comparison. Across the reference rows, float32 and float64 error counts differ by at most one example. All 24 fully covered hypotheses, including eight primary hypotheses, retain their statistical reading when recomputed from float64 counts. Contrasts involving unevaluated compact or late-head operands are explicitly outside that sensitivity check.

## Appendix E Reproducibility and evidence organization

The manuscript uses the frozen v70 analyses and the v72 closeout exports. Every reported hypothesis is associated with explicit operands, a draw and optimizer-seed identity, an eligibility decision and an exclusion reason. The complete exports comprise 864 planned draw–seed comparisons across 36 hypotheses. The mechanism data share ancestors with the synthetic panel; counts are not summed as independent runs or replications.

The accompanying manuscript source package includes the contrast exports, the final findings report, figure assets, bibliography and an evidence map linking manuscript claims to registry keys and implementation definitions. Full checkpoints remain in the experimental archive identified by the release manifest; they are not embedded in this manuscript package. The planned contrasts retain the fixed final analyses. Appendix F adds a descriptive reanalysis of the saved state tables. Figures were redrawn to include these comparisons and readable labels. No additional training was performed.

## Appendix F Descriptive reanalysis of saved states

These comparisons were added during manuscript review. They average eligible optimizer seeds within each of 12 draws and use unadjusted 95% Student $t$ intervals. Every contrast uses 24 matched pairs except the explicitly labelled 23-pair sensitivity. The all-run late routed summaries include the state flagged by the first-order numerical estimate in Appendix D (draw 350, optimizer seed 1). Retaining it for a descriptive summary does not clear its audit status; the exclusion sensitivity is reported alongside it. The remaining new contrasts do not use that state. Positive values follow the explicit subtraction in the first column. Unless marked raw or native, the metric is normalised extraction.

### F1 Additional paired comparisons

| Descriptive contrast | Difference and 95% interval (points) | Positive draws |
|:--|--:|:--:|
| Synthetic: ancestor minus early starting state | +1.63 [+0.79, +2.48] | 12/12 |
| Synthetic: ancestor minus late starting state | +3.26 [+2.10, +4.41] | 12/12 |
| Synthetic: ancestor minus original trajectory end | +4.14 [+2.77, +5.50] | 12/12 |
| Synthetic late: folded endpoint minus starting state | +0.19 [-0.01, +0.39] | 7/12 |
| Synthetic late: folded minus ordinary endpoint | -0.07 [-0.24, +0.10] | 6/12 |
| Synthetic early, raw: ordinary minus routed | +0.49 [-0.09, +1.06] | 9/12 |
| Synthetic late, native: routed minus ordinary (all 24) | +4.09 [-0.13, +8.30] | 10/12 |
| Same contrast, excluding reference exception (23 pairs) | +3.02 [-0.42, +6.47] | 10/12 |
| Image early: starting state minus ancestor | +5.98 [+1.70, +10.26] | 10/12 |
| Image early: starting state minus ordinary endpoint | +5.27 [+1.95, +8.59] | 11/12 |
| Synthetic early: swapped routed minus ordinary endpoint | -0.03 [-0.70, +0.64] | 5/12 |

### F2 Absolute endpoint values
Error columns are percentages, averaged over draw means. Loss is the median native training cross-entropy over 24 runs, in natural-log units per example. The ancestor has identical raw, normalised and native errors. All expanded states below are unrestricted lineage A.

**Synthetic MLP.**

| State | Raw error | Normalised error | Native error | Source-val error | Median loss |
|:--|--:|--:|--:|--:|--:|
| Ancestor | 24.19 | 24.19 | 24.19 | 5.39 | 0.000127 |
| Compact, 4,000 updates | 24.15 | 24.15 | 24.15 | 5.25 | 2.09e-07 |
| Starting state (early) | 23.68 | 22.56 | 23.95 | 5.28 | 9.78e-06 |
| Routed endpoint (early) | 23.12 | 21.00 | 23.83 | 5.45 | 0.0378 |
| Ordinary endpoint (early) | 23.60 | 22.76 | 23.57 | 5.18 | 2.42e-08 |
| Starting state (late) | 23.33 | 20.94 | 24.11 | 5.60 | 0.0991 |
| Routed endpoint (late) † | 23.04 | 20.16 | 27.15 | 11.07 | 0.397 |
| Ordinary endpoint (late) | 22.95 | 21.20 | 23.06 | 5.05 | 1.03e-07 |
| Folded endpoint (late) | 22.99 | 21.12 | 23.16 | 5.09 | 1.33e-07 |

**CIFAR-derived CNN.**

| State | Raw error | Normalised error | Native error | Source-val error | Median loss |
|:--|--:|--:|--:|--:|--:|
| Ancestor | 20.95 | 20.95 | 20.95 | 3.34 | 0.054 |
| Compact, 4,000 updates | 21.21 | 21.56 | 18.73 | 3.37 | 0.00138 |
| Starting state (early) | 27.65 | 26.93 | 30.33 | 5.86 | 0.147 |
| Routed endpoint (early) | 35.43 | 34.17 | 33.80 | 7.35 | 0.136 |
| Ordinary endpoint (early) | 21.20 | 21.66 | 19.84 | 3.48 | 0.00514 |
| Starting state (late) | 31.37 | 30.57 | 34.55 | 5.33 | 0.141 |
| Routed endpoint (late) | 33.76 | 33.55 | 35.16 | 5.60 | 0.15 |
| Ordinary endpoint (late) | 26.88 | 27.84 | 26.40 | 4.44 | 0.0608 |
| Folded endpoint (late) | 27.20 | 28.05 | 25.33 | 4.10 | 0.0443 |

† This all-run row retains the declared reference exception. For the conditional 23-pair native-error contrast, the affected draw contributes its one remaining optimizer seed.

### F3 Loss tails and component movement
The synthetic early routed loss ranges from $3.62\times10^{-9}$ to 205.67; 4 of 24 runs exceed 1. The late routed range is $4.14\times10^{-8}$ to 244.70; 8 of 24 exceed 1. Excluding the flagged late state changes the median to 0.2812, with 8 of 23 above 1 and the same maximum 244.70. Both ordinary endpoints have 0 of 24 above 1; their maxima are 0.395 and 0.333. Swapped routed continuation has median loss $1.05\times10^{-7}$ and maximum 0.694, so the very low median does not describe every run.

The compact synthetic control moves its first-layer weight matrix by a mean 0.67% of the ancestor norm (median 0.48%) over 4,000 updates. The corresponding image figures are 16.21% and 15.75%. These are endpoint displacement norms relative to the ancestor, not accumulated path lengths.

The late synthetic starting loss has median 0.0991 and maximum 17.59. Folded continuation reduces them to $1.33\times10^{-7}$ and 0.117. Thus folding is followed by actual fitting, despite the small change in normalised-extraction error.

All source rows and calculations are included in the manuscript package: `*_descriptive_states.csv`, `descriptive_pairs.csv`, `descriptive_absolute.csv`, `descriptive_summary.json`, and `reanalysis.py`.

## References

::: {#refs}
:::
