"""Descriptive reanalysis of saved v70 state tables; no training or model execution."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.stats import t
R=Path(__file__).resolve().parent
N='state_at_f0_block_row_norms_f0_bias_test_err'
keys=['data_draw','optimizer_seed']
tables={k:pd.read_csv(R/'evidence'/f'{k}_descriptive_states.csv') for k in ['fork29','image30','fork31']}

def pick(k,state,fork=None,parent='A_routed_affine'):
 d=tables[k];d=d[(d.state==state)&(d.parent==('f0' if state=='f0' else parent))]
 if fork is not None:d=d[d.fork==fork]
 assert len(d)==24,(k,state,fork,parent,len(d))
 assert not d.duplicated(keys).any()
 if state!='f0':assert d[N.replace('_test_err','_eligible')].all()
 return d.set_index(keys).sort_index()

def summary(v):
 means=v.groupby(level='data_draw').mean();assert len(means)==12
 m=float(means.mean());h=float(t.ppf(.975,11)*means.std(ddof=1)/np.sqrt(12))
 return dict(mean=m,low=m-h,high=m+h,positive=int((means>0).sum()),n_draws=12,n_pairs=len(v))

results={};pairs=[]
def contrast(id,k,left,right,metric=N,scale=100,exclude_f0=None):
 a=pick(k,*left);b=pick(k,*right)
 assert a.index.equals(b.index)
 v=scale*(a[metric]-b[metric])
 if exclude_f0 is not None:
  v=v[a.f0!=exclude_f0]
 results[id]=summary(v)
 results[id]['excluded_f0']=exclude_f0
 for (draw,seed),x in v.items():pairs.append(dict(contrast=id,data_draw=draw,optimizer_seed=seed,value=x))

for fork in ['snap_1000','snap_2500']:
 contrast('synthetic_start_benefit_'+fork,'fork29',('f0',),('start',fork))
contrast('synthetic_end_benefit','fork29',('f0',),('trajectory_end','snap_2500'))
contrast('synthetic_fold_loss_from_start','fork29',('folded_reset','snap_2500'),('start','snap_2500'))
contrast('synthetic_fold_minus_ordinary','fork29',('folded_reset','snap_2500'),('ordinary_reset','snap_2500'))
contrast('synthetic_raw_routing_benefit','fork29',('ordinary_reset','snap_1000'),('routed_reset','snap_1000'),metric='extraction_test_err')
contrast('synthetic_late_native_routing_harm','fork29',('routed_reset','snap_2500'),('ordinary_reset','snap_2500'),metric='native_test_err')
contrast('synthetic_late_native_routing_harm_eligible','fork29',('routed_reset','snap_2500'),('ordinary_reset','snap_2500'),metric='native_test_err',exclude_f0='base-81cd0cc2470964a23041')
contrast('image_early_start_harm','image30',('start','snap_1000'),('f0',))
contrast('image_early_ordinary_recovery','image30',('start','snap_1000'),('ordinary_reset','snap_1000'))
contrast('swap_routed_minus_ordinary','fork31',('routed_swap','snap_1000'),('ordinary_reset','snap_1000'))
# Helpful endpoints and magnitudes, reported independently from registered tests.
absolute=[]
for k in ['fork29','image30']:
 for state,fork in [('f0',None),('compact_2U','compact'),('start','snap_1000'),('routed_reset','snap_1000'),('ordinary_reset','snap_1000'),('start','snap_2500'),('routed_reset','snap_2500'),('ordinary_reset','snap_2500'),('folded_reset','snap_2500')]:
  parent='A' if k=='image30' and state=='compact_2U' else 'A_routed_affine'
  a=pick(k,state,fork,parent)
  loss=a.native_train_loss.to_numpy();row=dict(panel=k,state=state,fork=fork or 'f0')
  for m in [N,'extraction_test_err','native_test_err','native_val_err','change_over_f0_norm']:
   row[m]=float(a[m].groupby(level='data_draw').mean().mean())
  row.update(loss_median=float(np.median(loss)),loss_min=float(min(loss)),loss_max=float(max(loss)),loss_above1=int((loss>1).sum()),movement_median=float(a.change_over_f0_norm.median()))
  absolute.append(row)
a=pick('fork31','routed_swap','snap_1000');results['swap_routed_loss']={'median':float(a.native_train_loss.median()),'max':float(a.native_train_loss.max())}
a=pick('fork29','routed_reset','snap_2500')
z=a[a.f0!='base-81cd0cc2470964a23041'].native_train_loss
results['late_routed_loss_excluding_reference_exception']={'n_runs':len(z),'median':float(z.median()),'max':float(z.max()),'above1':int((z>1).sum())}
(R/'evidence'/'descriptive_summary.json').write_text(json.dumps(results,indent=2)+'\n')
pd.DataFrame(pairs).to_csv(R/'evidence'/'descriptive_pairs.csv',index=False)
pd.DataFrame(absolute).to_csv(R/'evidence'/'descriptive_absolute.csv',index=False)
print(json.dumps(results,indent=2))
print(pd.DataFrame(absolute).to_string(index=False))
