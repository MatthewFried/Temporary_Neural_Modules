function Table(t)
  local n = #t.colspecs
  local first = pandoc.utils.stringify(t.head.rows[1].cells[1].contents)
  local widths
  if n == 4 and first == 'Contrast' then
    widths = {0.49, 0.29, 0.14, 0.08}
  elseif n == 4 and first == 'Setting and endpoint' then
    widths = {0.43, 0.18, 0.21, 0.18}
  elseif n == 4 and first == 'Fork and continuation' then
    widths = {0.38, 0.25, 0.18, 0.19}
  elseif n == 3 then
    widths = {0.53, 0.33, 0.14}
  elseif n == 4 then
    widths = {0.17, 0.27, 0.35, 0.21}
  elseif n == 6 and first == 'State' then
    widths = {0.29, 0.13, 0.15, 0.13, 0.15, 0.15}
  elseif n == 6 then
    widths = {0.19, 0.13, 0.13, 0.13, 0.22, 0.20}
  end
  if widths then
    for i, w in ipairs(widths) do t.colspecs[i][2] = w end
  end
  return t
end

function Para(p)
  if pandoc.utils.stringify(p) == 'The principal continuations are:' then
    return {pandoc.RawBlock('latex', '\\Needspace{13\\baselineskip}'), p}
  end
end
