# Response to the independent v1 audit (cop_research_v1 -> v2)

Semantics version: `CODE_VERSION = "cop-2.0.0"`. Every v2 run id differs from every v1 run id, so v1 results stay identifiable and are never reused by v2.

Every finding below is **fixed**. None is disputed. Where the fix changed a contract, I list the new contract. Tests are in `tests/test_v2_audit.py`, and each test asserts the intended behaviour.

**Audit probes**
- `audit_v2/audit_results_v2.json`: the audit's 15 probes run against v2. All 15 report `defect_confirmed=false`.
- `audit_v2/audit_reproductions_v2.py`: the probes used for that run. Changes from the original are marked `# v2 adaptation`. They exist only where v2 deliberately rejects the probe's hand-made harness, for example a parent run without a provenance record.
- `audit_v2/audit_results_v2_unmodified_v1_probe.json`: the original probe file run unchanged against v2. 10 probes pass. The other 5 stop at the new v2 guards, which is the intended refusal.

**Not done here: the WSL CUDA pilot.** It has to run on your machine. `scripts/10_wsl_gpu_pilot.sh` runs it and writes `~/cop_wsl_pilot_v2.zip` for review. See "Gate C" below.

## Finding-by-finding disposition

| # | Finding | Disposition | Where | Tests |
|---|---|---|---|---|
| 1 | Transition checker accepts false claims | Fixed (rewritten; incomplete certificates hardened in the second pass, R1/R2) | `cop/finite/checker.py` `_check_transition`, `_t_explore`, `_bottleneck_to`, `_solve_hitting`; generator now exports closed-class members, the threshold override and `long_time_threshold` (`cop/finite/transition.py`, `cop/finite/__init__.py`) | `test_F1_*` (forgery rejected; 20 single-field corruptions rejected; unexported-graph aggregates; incomplete analyses; tampering of the other 5 certificate types; job status reflects the checker) |
| 2 | Analysis pools different conditions | Fixed | `cop/config.py` `condition_id` / `replication_key`; `cop/analysis/summarize.py` `paired_contrasts_report`, `continued_mismatch`, `condition_table`, condition-level figures | `test_F2_*` (omega 1 vs 4 = two contrasts with one pair each; widths, depth, optimizer state, penalties, cut subsets separate; seeds do not; mismatched continued baselines and duplicate replications reported; no same-seed collisions in waves 1, 2, 3, 5) |
| 3 | CoP matched control is not the same architecture | Fixed | `cop/cop_pegs/cycles.py` `matched_endpoint`, `run_baseline_cop`; config requires `parents.cycles`; manifest wires every matched control to its history | `test_F3_*` (partial cycles, revisits, narrowed pegs, no pegs, three orders, sequence embedding skip; exported params and structural hash equal; no tensor carried over) |
| 4 | Finite pegs become continuous after replacement | Fixed | `cop/cop_pegs/alternatives.py` `Interface`, `Assembly` (enforced by default), membership assertion per assembly; `cop.interface_enforce = relaxed` is the separately named continuous condition | `test_F4_*` |
| 5 | Table alternatives use the wrong code range | Fixed | `cop/graph/ops.py` `TableModule.from_quantizer` (uniform, vq, multi); an unconfigured table refuses to index | `test_F5_*` (one row per message on multidimensional alphabets; mapping saved with the module) |
| 6 | Random cut selection biased to cut 0 | Fixed | `cop/experiments/trajectory.py` `choose_cut` (separate selection draw; candidate set shared by all policies) | `test_F6_*` (uniform over 4 cutpoints with full and partial candidate sets) |
| 7 | Linear inverse restoration uses the wrong objective | Fixed | `cop/experiments/dissipation.py` `inverse_pairs`, `inverse_restore_penalty` (dispatch on explicit metadata; affine condition incl. bias; enforced pairs get no penalty) | `test_F7_*` (zero penalty and zero gradient at exact pairs, descent after perturbation, job on an exact parent) |
| 8 | Failed identity checks do not stop the run | Fixed | `trajectory.py` `insertion_gate` (incremental and all-at-once); `ScientificInvalid` -> status `invalid` with `invalid.json`; failed controls invalidate the control job; finite rejections invalidate the job; `cop.cli run` / `gate` exit non-zero | `test_F8_*` |
| 9 | Local CoP training ignores optimizer settings | Fixed | `cop/train/trainer.py` `LocalOpt` (one shared implementation of the train policy) used by every local loop; resolved policy saved in results; cop jobs are fp32 only (config check) | `test_F9_*` |
| 10 | P3/P4 do not save trained models | Fixed | `alternatives_modules.pt` / `alternatives_predictions.pt`, `split_modules.pt` / `split_predictions.pt`, `ckpt/reference_exported.pt`; full training-assembly usage counts; `reload_alternatives`, `reload_split`, `cop.cli verify-reload` | `test_F10_*` (fresh process reproduces every prediction bitwise) |
| 11 | Repair / CoP resume is a restart | Fixed | `cop/experiments/context.py` `JobState`, `local_loop`; resumable repair, dissipation (`_Steps`), chain training, alternatives, split, cycles, Theseus, shared fold, neutral mutation | `test_F11_*` (13 job kinds interrupted at 2 points each, plus 2 late-interruption cases from the second pass; checkpoints, metrics, results and work equal bitwise) |
| 12 | Repair extends successful cases; counters wrong | Fixed | `cop/experiments/repair.py` `extension_needed` (`is None`), `repair.extend_on`, counters set before logging | `test_F12_*` |
| 13 | fp64 checkpoint round trips lose precision | Fixed | `cop/graph/graph.py` `from_checkpoint` (per-tensor dtype restore, asserted); `predict` / `evaluate` / `export_compact` default to the model dtype | `test_F13_*` (also an fp64 trajectory interrupted and resumed) |
| 14 | Clean labels leak into specialisation | Fixed | `trajectory.py` `spec_masks` (observed labels; `class_halves_oracle` is a separate, labelled intervention) | `test_F14_*` |
| 15 | Normalised tolerances applied to raw MSE | Fixed | `repair.py` (`nmse_increase_vs_ft`), `deletion.py` `_preserves` (divides by target_scale^2); units written into certificates and reach tables | `test_F15_*` |
| 16 | Instance hash does not bind weights to positions | Fixed | `graph.py` `instance_hash` (Merkle hash with a content fingerprint of each node's module); `deletion.py` confirms every hash match on a probe batch before skipping | `test_F16_*` (swapped maps, shared vs independent copies, folded weights, cancel-pair dedupe still merges) |
| 17 | Code changes can silently reuse old runs | Fixed | `cop/utils.py` `semantic_code_hash`; `runner.py` provenance, `stale` status, `--rerun-stale`; `context.py` `parent_dir` (one parent validation API); `cop.cli accept-stale` (explicit, reasoned, recorded reuse) | `test_F17_*` |
| 18 | Uncertainty and compute definitions | Fixed | sequence intervals clustered by sequence (`metrics.cluster_ratio_ci`); paired per-example deltas (`metrics.paired_delta`); measured work by phase (`ctx.count_work`, `work` in summaries); calibration uses stored times for cache hits and has CoP families; seeded, persisted known-interface readouts; repair curves record the evaluation resolution | `test_F18_*` |

## Defects found while fixing (not in the audit)

1. **Route merges were not exact after the first growth round.** The new exactness gate caught this on its first smoke run. Adding a zero expert next to *trained* experts moves probability mass in the router softmax, so the output changes; in v1 this would have trained on silently with an `L0_failed_exact_insertion` label. v2 grows a route group by an exact *split* of the most recent expert: copied (or tied) parameters, router logits `l + log s` and `l + log(1 - s)`, with `s = growth.route_split = 0.3`. Where no exact split exists, the branch is declared approximate. Affects W3 E2 parallel/route and the I4 competition blocks. Test: `test_F8_route_growth_next_to_trained_experts_is_exact`.
2. **Image codes were quantised along the width axis.** `Quantizer` received `(B, k, H, W)` and broadcast its per-coordinate ranges over the last axis. This failed loudly when `W != k`, and was silently wrong when `W == k` (uniform) and always wrong for vq / multi. Quantisers now run channels-last. Affects image pegs with finite modes (Wave 5 CIFAR-10 P2 bits / codebooks, P3 on images). Test: `test_F4_image_codes_are_quantised_per_channel`.
3. **Wave-4 transition entries passed an unknown parameter** (`acceptance`, should be `rule`), so those two finite jobs would have failed. Test: `test_v2_manifests_resolve_and_wave4_transition_params_exist`.
4. **fp64 trajectories failed at export** (float32 verification inputs into a float64 model). Fixed by finding 13's dtype defaults. Test: `test_F13_fp64_trajectory_resume`.
5. **Insertion-time metric rows carried stale exposure counters** (found by the resume comparisons). Counters are now set from the trainer before every logging point.

## Second pass: independent review of the v2 fixes

Before freezing the code, a separate reviewer that had not written the fixes read the full v1-to-v2 diff and tried to break it. Its reproductions are in `audit_v2/review_second_pass/`. Each confirmed finding was fixed and has a regression test.

| # | Finding | Status | Fix | Tests |
|---|---|---|---|---|
| R1 | An incomplete transition certificate verified with almost every claim unchecked. A fabricated unreachable state with fabricated edges and "witnessed return" labels was `verified`. | Confirmed, fixed | `checker.py` `_check_transition_incomplete`: every exported state must be reachable from the specified initial states over exported edges; every exported edge must be a true transition (the full re-derived distribution for expanded states, a subset of it for the partially expanded one); initial reports, threshold, `n_states`, `n_edges`, `n_simple` and label counts are recomputed; an "incomplete" search must have an unexpanded state. Without an exported graph, only the initial states are checked and the verdict is `partially_checked` (job `unverified`). | `test_F1_incomplete_certificates_check_the_explored_subgraph` |
| R2 | Complete certificates: `long_expected_time` was checked only when `long_time_threshold` was present, and the threshold was not tied to the configuration. Duplicated fields (`domain.n_states`, `domain.state_cap`, `data.state_cap`, `coverage.incomplete_reason`, `precision`) were never compared. | Confirmed, fixed | The class now records the configured `state_cap` and `long_time_threshold`; `_check_transition_fields` compares every duplicated field; the flag is required exactly on states with a finite hitting time; `run_finite_job` rejects a certificate whose class differs from the job configuration. | `test_F1_long_time_flags_and_duplicated_fields_are_checked`, `test_F1_certificate_class_must_match_the_job_configuration` |
| R3 | `run_chain` resumed after its `final` checkpoint skipped chain training, so chain work and the exposure counters were lost (endpoint `training_updates` 20 vs 0). | Confirmed, fixed | `run_chain` always goes through the idempotent `chain_train` stage; its `done` checkpoint restores model, trainer and readouts and counts the work. Cycles restore `ctx.updates` / `ctx.examples` from the checkpointed work at every resume point (the hard-crash case the reviewer reasoned about). | `test_F11_late_interruption_keeps_work_and_counters[cop_chain_peg_edit]` |
| R4 | The analysis read raw `status.json`, so runs produced by different result-determining code were pooled. | Confirmed, fixed | `summarize.load_runs` uses `effective_status`; stale runs are excluded, listed in `validity_quarantine.*` and `analysis_errors.json` (`excluded_stale`); accepted stale reuse is listed in `accepted_stale_reuse.json`. | `test_F17_analysis_never_pools_stale_runs` |
| R5 | The checker's float64 hitting solve was dense (O(n^2) memory); an out-of-memory error would have turned a valid certificate into `rejected`. | Plausible, fixed | Sparse solve with a residual check. | `test_F1_numerical_hitting_check_is_sparse_and_exact_on_a_large_system` (30,000 unknowns) |
| R6 | Matched controls calibrated their quantisers once, on the random initialisation, while the parent's were fitted on trained activations. | Plausible, fixed | The control's quantisers are re-fitted on its own training activations at the parent's K = `cycles` evenly spaced points of one continuous run (optimizer state and schedule are not reset). The points are recorded as `control.quantizer_recalibration_at_updates`. | `test_F3_matched_controls_equal_parent_endpoint` |
| R7 | The interface's straight-through gradient was clipped, so a fitted module with outputs outside the range got no gradient on those coordinates. | Plausible, fixed | `Interface` returns exactly the quantiser's code and passes the gradient unchanged (unclipped straight-through). The peg quantisers inside trained chains are unchanged. | `test_F4_interface_gradient_is_unclipped_and_value_exact` |
| R8 | Alternatives read only the incoming code, so a middle pearl that also reads a late input would be compared with handicapped alternatives. | Latent (the MLP builder places every peg before the query, and `delayed_query` is not in P3/P4), guarded | `require_code_only_pearls` refuses such references (status `unsupported`) in P3 and P4. | `test_F10_alternatives_refuse_pearls_with_late_inputs` |
| R9 | Known-module pretraining was lost from `summary.work` when a trajectory resumed after that round; trajectory growth training was not in `ctx.work`. | Plausible, fixed | Trajectory checkpoints carry a work snapshot that is restored on resume; growth training is counted once at the end (`growth_train`). | `test_F11_late_interruption_keeps_work_and_counters[trajectory_known_pretrained]` (fails if the snapshot restore is removed) |
| R10 | `parent_dir` accepted `unverified` parents without saying so. | Plausible, fixed | An unverified parent makes the child `unverified`, with the reason recorded. | `test_F17_unverified_parent_makes_children_unverified` |
| R11 | Explicit zero-probability moves would make a genuine incomplete table certificate fail. | Plausible, fixed | Zero-probability re-derived moves are dropped before comparison. | `test_F1_incomplete_table_search_with_zero_probability_moves_verifies` |
| minor | `examples_seen` was always 0 in chain, cycles and dissipation rows. | Fixed | Counters set from the trainer / measured work. | resume comparisons |
| minor | `configure_torch` (TF32, determinism) sat in orchestration, outside the semantic hash. | Fixed | Moved to `cop/utils.py` (semantic); the applied settings are written to `provenance.json` as `numerics`. | `test_F17_provenance_records_numerics` |
| minor | I/O settings (`train.checkpoint_every`, `eval.save_predictions`) were part of `condition_id`. | Fixed | Excluded from the condition (still part of the run id). Evaluation settings stay in the condition because they can change reported numbers. | `test_F17_condition_id_ignores_io_settings_only` |
| minor | The matched control trains the folded export, not the parent's training-time parameterisation. | Kept, documented | The control is defined as direct training of the endpoint architecture (DEVIATIONS 53). | |
| minor | `_FP_CACHE` could return a stale fingerprint after an in-place `.data` edit that does not bump the tensor version. | Kept, documented | No such edit exists outside `from_checkpoint` (which builds new modules); deletion dedupe also confirms every hash match on a probe batch. | |

## Contracts that changed (read before interpreting v2 output)

- **Statuses.**
  - `complete` means computationally finished. `status.json` also carries `validity`: `valid`, or `unverified` (a claimed property could not be checked, for example a certificate above the checker limit).
  - `invalid` means a violated contract; the run is quarantined and its dependants are skipped.
  - `stale` means a completed run, or a quarantine, produced by different result-determining code.
  - Validity propagates: a child of an `unverified` parent is `unverified`.
  - Analysis pools only runs whose *effective* status is `complete` (stale runs are excluded) and that are `valid`. Everything else is listed in `summary/validity_quarantine.*` and `summary/analysis_errors.json`.
- **Approximate insertions.** `L0_approximate` requires implants *declared* approximate, and deleting exactly those implants must restore the outputs. Any other change is a failure.
- **Finite interfaces.** Every replacement and adapter output passes the destination quantiser (value exactly the code; unclipped straight-through gradient). Continuous replacements exist only as `cop.interface_enforce = relaxed`. Pearls that read late inputs are refused.
- **P4.** The internal codes of a split chain are continuous and are counted at `float_bits`. The chain's output passes the destination interface.
- **Matched controls.**
  - `direct_small` / `distill` copy the parent cycles run's exported endpoint, re-initialise it, re-calibrate quantisers on the re-initialised network and again on the control's own training activations at K - 1 evenly spaced points (K = `cycles`), and assert equality before and after training.
  - Exposure is the parent's *measured* training updates; direct_small also gets the baseline's updates.
  - The old "replace every pearl" baseline remains as `direct_small_all_pearls`, labelled independent.
- **Repair extensions.**
  - The deciding criterion is the configured target's criterion (`repair.extend_on = target`).
  - A first hit at update 0 counts as reached.
  - Regression task tolerances are in normalised units (`criteria.nmse` = excess MSE / target_scale^2).
- **Paired SE.** The deletion `paired_se` is replaced by `paired_delta`: per-example paired differences in correctness, loss or squared error, with standard errors; sequences are the clustered unit. Sequence `acc_ci95` is replaced by `acc_ci95_cluster` and `seq_exact_ci95`.
- **Provenance.**
  - Completed runs and parents are reused only when their semantic code hash matches.
  - The semantic hash covers every file except orchestration, analysis, the CLI and the environment report. The numerics settings (`configure_torch`) are semantic code, and the applied settings are recorded per run.
  - `--allow-code-change` applies only to continuing an *incomplete* run, and is recorded.
- **Resume.**
  - Every training job resumes at update granularity, and every local fit at step granularity.
  - Deletion and finite jobs are evaluation-only and recompute on restart.
  - Adaptive cut-policy probes recompute their round on restart (deterministic, recorded wasted work).

## Evidence in this archive

All evidence was produced by the frozen v2 code (semantic hash `5f0fc17a02584937`, git commit "v2: audit corrections and second-pass review fixes (code freeze)").

- `sandbox_checks/test_results/`: full pytest output and JUnit XML for the CPU sandbox: 190 passed, 2 skipped (the CPU-vs-GPU test, and CIFAR-100, which is not downloaded here), 0 failed. Real-data tests ran against the downloaded Covertype, California, Fashion-MNIST and CIFAR-10.
- `sandbox_checks/resume_comparisons.json`: job-level interrupted-versus-uninterrupted comparisons. 30 job kinds were each interrupted twice; all are bitwise equal on CPU.
- `sandbox_checks/reload_checks.json`: fresh-process reload of every sampled P3 / P4 run (7 alternatives, 3 split); all reproduce their saved predictions bitwise.
- `sandbox_checks/matched_controls.json`: parent-versus-control architecture and parameter equality for every sampled matched control (3); all equal.
- `sandbox_checks/sampled_runs/`: a per-block sample of waves 0-5 and the wave-9 pilot at smoke scale (CPU): 200 runs, all complete and valid; remaining CIFAR-10 jobs not sampled on this CPU (see its README).
- `audit_v2/`: the audit's probes (v1 re-run by me, v2 adapted, v2 unmodified), the second-pass review reproductions with their output on the frozen code, and the tools that produced `sandbox_checks/`.
- `sandbox_checks/manifest_counts.txt` and `manifests/`: regenerated and validated v2 manifests (unchanged by the second pass), with the condition-collision check (0 collisions).
- `PATCH_v1_to_v2.diff`: the complete source diff from v1.

## Gate C (WSL / GPU): what you run

```bash
bash scripts/setup_env.sh && bash scripts/00_fetch_data.sh
bash scripts/01_cpu_exact_tests.sh       # full test suite + Wave-0 CPU controls, gated
bash scripts/02_gpu_calibration.sh       # CUDA training + checkpoint reload check, Wave-0 CUDA controls, gated; timings
bash scripts/10_wsl_gpu_pilot.sh         # integration pilot -> ~/cop_wsl_pilot_v2.zip
```

The pilot covers:
- one small valid case per model family and job kind on the GPU (wave 9: 44 jobs), including the cache-heavy CoP image case;
- GPU interrupt/resume comparisons for 5 job kinds;
- fresh-process reloads of P3 / P4 runs;
- `pilot_report.json` with the exact environment, configs, status and validity, runtime, peak memory, measured work, and checkpoint and prediction hashes.

`run_all.sh` stops after the pilot until `PILOT_REVIEWED=1`.
