# Response to the v12 audit (CoP_v12_Audit_and_v13_Claude_Handoff, 26 October 2026)

v13 is a corrective and experiment-design release. Semantics `cop-6.0.0` (was `cop-5.0.0`): every run id
changes, so nothing from v9 or earlier is resumed or overwritten. v9 results stay read-only discovery evidence;
the only reuse is checkpoint-based remeasurement of costs (section "Reuse and provenance").

The research question is unchanged: where computation moves during expansion, how dependence develops, when
additions can be removed or replaced and at what repair cost. Final compact accuracy is one outcome. Negative
cells (X3 failures, locality failures, retention losses) stay in every manifest and table.

## Part A: the two reproduced bugs

| Item | Fix | Where | Tests / evidence |
|---|---|---|---|
| A1 identity gate | `d_edit = maxabs((q_exec - q64) - (p_exec - p64)) / s`, every difference in float64; fixed edit round-off limit by execution dtype (`IDENTITY_EDIT_ROUNDOFF_MAX_REL`: float32 1e-4, float64 1e-10), independent of the high-precision tolerance; observed agreement must satisfy the fixed bound `tol_hp + tol_edit`. The reference scale is max(mean abs p64, mean abs q64), so a function moved off zero is `changed`, not `low_scale`; a real change on any input set decides the overall verdict (order: nonfinite, changed, low_scale, execution_changed). `u_pre`, `u_post` kept as diagnostics (`preexisting_instability`) and never decide a verdict. New verdict `execution_changed`; insertion label `L0_inconclusive_execution_changed`. Docstring and records say "empirical agreement on these input sets, not a global identity proof". | `cop/experiments/common.py` (`identity_check`, `edit_roundoff_limit`), callers in `trajectory.py` (insertion gate) and `control.py` | `tests/test_v8_audit.py` v13 section: the audit's GraphNet counterexample cannot be labelled exact; identical pre-existing errors pass (lab case); opposite errors of equal norm fail; maxima moving between coordinates / examples fail; a real high-precision change fails; a small construction error within tolerance passes; low-scale and non-finite cases; CUDA test at float32 / float64 (`test_cuda_identity_gate_dtypes`, runs in scripts/15). The supplied probe on v13: verdict `execution_changed`, `d_edit = 6.0` (`audit_v6/evidence/identity_probe_on_v13.txt`). |
| A2 baseline cost | Baseline training writes an absolute, idempotent ledger phase `baseline_train` (`ctx.set_work`, from the trainer counters, so a resume cannot double count). `baseline_cost(run)` returns the ledger, else the checkpoint's trainer counters with `provenance: checkpoint_counters`, else `missing` and incomplete; never zero-and-complete for a trained checkpoint. Inline f0 (trained inside a trajectory) is costed from `baseline_ref`. Endpoint rows carry `baseline_macs`, `post_f0_macs`, `total_procedure_macs`, `total_procedure_complete`, `f0_cost_provenance`; pairs carry treated / control baseline and total-procedure costs. Baseline work enters the total exactly once: a treated descendant adds its f0 once; a scratch control M1 / M2 adds nothing (it has no f0), and its matched budget (unchanged code path) already includes the f0 updates. The M2 budget code was audited separately: it reads the baseline checkpoint counters and was correct, so budgets did not change; only reporting did. | `trajectory.py::run_baseline`, `continuation.py` (`baseline_cost`, `inline_f0_cost`, `run_work`), `context.py::set_work`, `analysis/strengthening.py` (`f0_cost`, endpoint and pair fields), `analysis/pilot_report.py` | `tests/test_v13.py`: trained baseline (positive counters), zero-update baseline, interrupted and resumed baseline (counted once), historical baseline without ledger (checkpoint fallback, provenance) and with no evidence (incomplete), inline versus external f0, M1 total cost with the baseline counted once and the training budget unchanged. The supplied probe on v13: `issue_reproduced: false` (`audit_v6/evidence/baseline_cost_probe_on_v13.txt`). |
| Historical cost tables | `cop summarize --historical` re-analyses a read-only results folder with the current analysis code, judging staleness against the code that produced it (`historical_provenance.json` records both hashes). Baseline costs of v9 come from checkpoint counters with provenance. scripts/15 rebuilds the v9 pilot tables into `~/cop_results_v13/historical_v9_pilot` and checks that no file under `~/cop_results_v9` changed. | `analysis/summarize.py`, `cli.py` | historical summarize tested on an older smoke folder (costs `checkpoint_counters`); scripts/15 step `historical_costs` on the lab machine |

## Phase 0.2: global numeric-validity counts

`summary/numeric_validity.json` separates (1) jobs whose own endpoint is numerically invalid, (2) descendants of
such a source, (3) incomplete contraction diagnostics, with those excluded by a source's own record listed apart,
and (4) multi-model jobs (transplants, alternatives, locality) that never belong in an endpoint table. Test:
`test_numeric_validity_separates_sources_descendants_and_multi_model_jobs`.

## Part C: three analyses, selection, controls

| Item | Implementation | Tests |
|---|---|---|
| C1 three analyses | (i) mechanism: path, damage and repair records and tables at declared checkpoints, never replaced by selection (`s13_removal_paths`, `s13_x4_information`, `s13_locality_controls`, `s13_finite_refit`, existing `s_locality`, `s_finite_interface`, `s_contraction_diagnostics`, `s_repair_*`); (ii) deployable endpoint: `s_selected_*` and `s13_tuned_*`; (iii) same final architecture: `s_matched_endpoint_*`, `s13_history_ingredients`, `s13_later_query_retention`. The map is written to `s13_analyses.json`. | table smoke in the CPU re-pilot |
| C2 selection | `train.select_candidates = K` declared points evenly over the job's FINAL COMPACT phase (the last is the final update); rule: lowest validation risk (MSE / cross-entropy) on `train.select_partition`, ties to the earlier point; test, shift, rare and train are refused as selection partitions. Both `endpoint.json` (fixed budget) and `endpoint_best_val.json` (selected; reloaded and evaluated the same way) are kept, with `selection.json` listing every candidate. Wired into baselines, continuations, dissipations (only after the last implant is physically removed), repairs and, new in v13, the CoP chain endpoint segment (gates at endpoint values; each candidate is the exported compact graph). f0 is selected inside its own baseline run; every descendant starts from that one `best_val` state with its optimizer, RNG and data streams (`tags.f0_stage` / `continue.start_stage = best_val`), and the f0 stage is part of the pairing key. The f0 fallback is decided symmetrically: tables are written with and without it (`s_selected_fixed_architecture_f0fallback_*`), both arms may select f0 and the pair says which did; f0 is never a fallback in matched-endpoint tables. Pairs need equal selection opportunities. The whole job's work is charged to both endpoints; the selected update is recorded separately. | `test_selection_keeps_the_fixed_endpoint_and_selects_only_compact_states_by_validation`, `test_selection_partition_must_be_validation`, `test_selection_survives_interruption_identically`, `test_selected_gain_is_symmetric_about_f0_and_requires_equal_opportunities`, `test_cop_chain_selects_only_exported_endpoint_states_with_equal_opportunities` |
| C2 shortcut validation | three validation-only environments generated with their own streams: `val_indep` (shortcut independent of the label), `val_reversed` (correlation reversed), `val_rare` (rare group only). They may be declared as `select_partition`; the re-pilot selects on ordinary in-distribution `val` and reports the others. | `test_shortcut_has_separate_validation_environments_and_selection_may_use_them` |
| C3 controls | every shortlisted cell: plain continuation at base and 0.3x LR, LR restart, a cosine schedule over the control's own budget, equal-compute C2; treated arms get the same two learning rates, scratch M1 too. `s13_tuned_*` compares the better of {base, 0.3x} by fixed-endpoint validation risk on each side (two opportunities each). | manifest test; tuned table smoke |
| C4 ingredients | at one endpoint architecture (peg dim 4 and 8, deep teacher cell): M1 / M1 0.3x / M2 direct scratch; `abrupt_calibrated_interfaces` (same f0, calibrated pegs, alpha anneal of one update); `treated` (gradual, no bridge); `gradual_with_bridge_all`; `gradual_with_local_bridge`. Scratch arms record `reinit.unchanged_after_reset` (trained tensors that survived the reset; must be empty), quantiser calibration, clipping fraction, distinct messages and per-module gradients at start and end. | `test_matched_direct_controls_record_later_query_retention` (reset audit) |

## Part D: re-pilot blocks (wave 13) and confirmation (wave 14)

`cop/orchestration/wave13.py`. Every entry carries `info_access` (group ids for routing or sampling, labels for
routing, random partition, clean labels, teacher targets, distillation, group ids at inference = false, selection
partition and opportunities) and `budget` (rule, parent, f0 added, removal / repair split, MAC matching).

* **D1 X4** (rho 0.7 and 0.95, n 4096, rare prevalence 0.05): expansions parallel, specialized by true group,
  specialized by true group with group-balanced sampling, specialized by a proportion-matched random partition
  (saved as `spec_partition.pt`), specialized by observed labels without group ids. Removal protocols from the
  same expanded checkpoint: treated = 50 removal + 700 repair, abrupt + 750, 500 + 250 (pilot scale; one round is
  500 updates), the historical 50 + 250 as context, and abrupt removal MAC-matched to the treated job; treated at
  0.3x LR. Controls: C1, C1 0.3x, LR restart, cosine, C2, group-balanced C1. Each specialization run writes
  `specialization_access.json` (counts by branch x group and label, gradient coverage per branch) and fails if
  permuting evaluation group metadata changes any prediction (`group_inference_check`). Dense path checkpoints
  (`path_u<u>`), 20 sampled path points with full evaluation (risk on every partition, logit norm, prediction
  drift and flip rate); the sampled peak is labelled "not a certified barrier". Group DRO is recorded as
  inapplicable (no implementation); group-balanced sampling is the group-aware comparator and is not branch
  masking.
* **D2 matched architectures**: F07 dims 2, 8, 32 and bits 1, 4, 16; the four C4 ingredients; F09 query before
  and after encoding for bit, xor_next and two_bits (the interaction is the result); M_E original-task error and
  later-query oracle accuracy for treated AND controls (controls now run the same later-query decoders);
  two representative X3 failures as boundary controls.
* **D3 finite codes** n = 3, 4, 5, two-bit capacity, families A (delayed query) and B (later query, task
  preserved): no bridge, gradual bridge, abrupt bridge, no bridge MAC-matched to the gradual bridge, permanent
  bridge as a diagnostic. Each job records model error, optimal-decoder error of the learned code and the global
  optimum where enumerated, then refits only the decoder with the encoder frozen (code checked unchanged,
  charged as diagnostic work).
* **D4 locality**: the five interface conditions x replacement width {4, 16} x repair budget {upr/2, 2 upr}, every
  tolerance in every job. Controls per checkpoint: exact local replacement (a copy of the original pearl spliced in
  through the same `replace_segment` path as a fitted replacement; certificate and risk must match), literal
  frozen-code lookup (the network with the fitted replacement, its outgoing message overwritten by the reference
  code table for every incoming code; agreement shows that holding the code fixed restores the function), and
  code matching (the replacement trained to reproduce the old interface values) next to direct task repair.
  Unreached tolerances are censored, not irreducible.
* **Confirmation (wave 14)**: the X4 rho 0.95 block, D2 and D3 on fresh draws: data/teacher 101-105 with
  optimizer seed 0, plus optimizer seeds 1 and 2 on draws 101 and 102. It is never launched automatically
  (scripts/16 needs `freeze` then `CONFIRM=1 ... run`, and refuses if code or manifest changed after the freeze).

## Smaller fixes found while implementing

* CoP MAC matching planned the global phase with the nominal batch size, so complete-domain finite tasks (fewer
  training examples than one batch) got about a quarter of the reference MACs; it also ignored the higher per-update
  cost of anneal and bridge segments. The endpoint segment's length is now planned when it starts, from the
  measured MACs so far and the endpoint gates, and checkpointed for resume; achieved / reference is recorded.
  Tests: within one update's MACs of the reference (`test_finite_code_mac_matching_...`,
  `test_removal_mac_matching_reaches_the_reference`).
* Probes skip auxiliary targets whose name starts with `_` (the saved random partition), and auxiliary targets
  missing from validation.

## Fixes after the independent review of the v13 patch

* X3 boundary controls did not pair with their treated arm (the scratch control's f0 stage was read as `baseline`):
  the control now carries `tags.f0_stage`, the analysis follows the `cycles` parent, and a test checks that every
  contrast in waves 13 and 14 has exactly one (f0 run, f0 stage).
* The locality positive controls compared the reference with itself; they now go through a real replacement
  (above). Test asserts that the lookup is applied to a network whose own risk differs from the reference.
* From-scratch histories (`growth.schedule = from_scratch`) were charged f0's training in the total procedure cost;
  they are not (`history_from_scratch` column).
* Fixed-budget C0 for v13 descendants: C0 is now the f0 state the chain actually started from (the baseline's
  selected endpoint for `best_val`), instead of being dropped.
* Validation-selection evaluations are charged: forward MACs of every candidate evaluation in a `search:` phase,
  added to `search_macs` and `total_procedure_macs`, kept out of training budgets and MAC matching.
* A job that diverges after its selected candidate keeps a valid selected endpoint (the candidate's own tensors and
  metrics are checked on reload), the same rule for every arm; the record says when the job diverged.
* The f0-fallback comparison uses the partition the selection used; a fallback `best_val` of a baseline keeps its
  trainer state; the MAC plan survives the chain's `_done` resume path; the historical 50 + 250 arm has its own
  contrast so it is never paired as a matched comparator; info_access reports selection opportunities only for jobs
  with a selector.

## Reuse and provenance

| Evidence | v13 handling |
|---|---|
| v9 pilot runs (`~/cop_results_v9`) | read-only; costs remeasured from checkpoints by `cop summarize --historical` (`historical_provenance.json`: producing semantic hash and the analysis code hash) |
| v9 endpoint and mechanism tables | kept as discovery evidence; not merged with v13 tables |
| any v9 training, endpoint or diagnostic | not resumed; v13 jobs have new run ids and run in `~/cop_results_v13` |

## Not done, or limited

* "Fresh structural constructor" cross-check of the scratch reset: not implemented; the reset audit checks that
  no trained floating tensor survives and records quantiser and gradient state.
* Quantiser calibration forward passes (treated pegs and scratch re-calibration) are not charged in MACs; both
  sides are uncharged, and the cost is one forward pass over `eval.calib_size` training inputs.
* A repair whose budget is extended (`repair.extend_on`) gets one extra selection candidate at the extended end;
  repair jobs are not in waves 13 or 14.
* The frozen-code lookup is implemented for vector and sequence layouts, uniform pegs and at most 65,536 incoming
  codes.
* "Selected-module changes" along removal paths are not recorded per module; drift, flip rate and logit norms are.
* Matching reference task performance in locality repair, branched interfaces, repeated-expansion replay
  controls, canonicalized coalition games and source-split residual prediction stay in the registry for staged
  follow-up; they are not in the re-pilot.
* The re-pilot uses the discovery seed only. Its tables guide the protocol; they are not confirmation.
