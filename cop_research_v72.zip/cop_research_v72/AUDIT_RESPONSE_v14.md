# Response to the v14 review (CoP_v15_review_and_Claude_instructions, 29 October 2026)

v15 changes semantic code (new finite-peg recipes, partition modes, path events, locality outcomes), so the code
version is `cop-7.0.0` and every run id changes. The v13 re-pilot is preserved: scripts/17 re-analyses its full
lab results with the v15 analysis code (`summarize --historical`, read-only).

## Priority 0

| Item | Fix | Where | Tests |
|---|---|---|---|
| 1. Later-query pairing | Rows carry replication, data / teacher draw, optimizer seed, f0 run and stage, budget panel, architecture, eligibility and endpoint policy. Pairs form inside one unit (contrast, f0 @ stage, replication, endpoint policy); a missing or duplicated arm rejects that pair with a reason; a control with a different architecture is rejected; `treated_lr0.3` is labelled a treatment variant. `tuned_gain` also rejects duplicated arms instead of keeping the last row. | `cop/analysis/v13_tables.py` (`history_ingredients_table`, `later_query_retention`, `tuned_gain`) | `test_later_query_pairs_stay_within_their_replication_under_every_ordering` (all 24 orderings), missing / duplicate / architecture rejections, `test_tuned_pairs_are_per_replication_and_duplicates_are_rejected`, `test_compact_gain_summary_..._two_replications_stay_two` (all orderings) |
| 2. Launcher failures | scripts/16 `run` records every stage (run, status, completion count against the manifest, result checks, fresh reload, summary, packaging) in `verdict.json` and exits non-zero when any fails, after still collecting diagnostics and packaging. The freeze records a protocol hash (whole cop package, launch scripts and the audit tools the verdict uses) besides the semantic hash and manifest; `run` refuses a changed protocol unless `PROTOCOL_AMENDMENT="reason"` is set, which is recorded in `PROTOCOL_AMENDMENTS.json`. A changed semantic hash or manifest is always refused. | `scripts/16_v13_confirmation.sh` | `tests/test_v15_launcher.py`: the real script in a mock home: success; failed run / checks / reload / summary; failed packaging; protocol change refused then recorded as an amendment; manifest change refused |
| 3. Removal-path export | Path events join their full evaluation by event identity: key events (start, right after an abrupt deletion or a fold, physically removed) from stage `path_<tag>`, sampled points from `pathfull@<update>`. Start and immediate deletion at update 0 stay separate rows; an event without an evaluation is flagged `missing`, never filled from another. New runs also log logit norm and prediction drift at the key events, and a frozen-weight sweep at the start of every removal (intact, all implant gates at 0.75 / 0.5 / 0.25 / 0, each single deletion, joint deletion; no training). `peak_kind` says the peak is a sampled maximum. | `cop/analysis/v13_tables.py::removal_path_table`, `frozen_sweep_table`; `cop/experiments/dissipation.py` | `test_removal_export_keeps_start_and_immediate_cut_apart` (the review's .3 / .9 fixture), `test_new_runs_record_logit_norm_and_drift_at_key_events_and_a_frozen_sweep` |
| 4. Replication hierarchy, costs | Every paired summary adds draw-level fields: `primary_*` (one effect per data / teacher draw at optimizer seed 0, bootstrap over draws), `pooled_draw_*` (effects averaged within a draw, each draw weighted once) and `within_draw_sd_over_optimizer_seeds`; the replication-level interval is labelled as not independent. Tuned pairs report the selected model's procedure cost and the whole tuning procedure's cost (every candidate's training, the shared baseline once); the selector is named (fixed-endpoint validation risk) and kept apart from the best-validation-checkpoint tables. | `cop/analysis/strengthening.py::draw_level`, `compact_gain`; `v13_tables.py::tuned_gain` | `test_draw_level_summary_weights_each_draw_once`, tuned cost assertions |

## Priority 1

| Item | Implementation |
|---|---|
| 5. Finite scratch control | Two strict finite-capacity recipes and one relaxation control, available to treated and scratch arms alike: `train.quant_range = ema` (train-only adaptive global range: lo / hi follow the 0.001 / 0.999 batch quantiles with momentum, frozen in evaluation, shared across examples, no per-example scale crosses the peg) and the original `fixed` range; `train.quant_warmup_updates = W` (continuous for the job's first W updates, then calibrated on training activations and quantised; labelled a capacity-relaxation history control). Learned clipping (PACT / LSQ style) is not implemented. Quantiser audits now record clipping, active messages, per-coordinate entropy, ranges and code drift from the reset at the start, end and selected checkpoint (and at export for treated chains). Tables report bits per message as dimension x bits. Wave 15 runs the recipe panel (F07 bits 1 / 4 / 16 and the M_E 2-bit cell; treated fixed / ema and scratch fixed / ema / warm-up, each at 1, 0.3 and 0.1 x LR) on the discovery draw. |
| 6. Later-query naming | Columns are `readout_<peg>_<part>_acc` with the decoder class, training-message count and unseen-message rate; the docstrings say these are training-fitted probes, not information oracles. M_E in confirmation adds the warm-start abrupt-interface arm. Not done: an f0 readout at the corresponding cut (f0 has no peg there; a probe on its full activation would not have the same readout budget). |
| 7. Locality outcomes | Per scope: task recovery (first passage, final, sustained from first passage, lost after passage), function disagreement with the reference (drift on val), and agreement of the transmitted integer code and canonical value at the outgoing interface. "Code matching" is renamed representation matching (MSE to the old pre-quantiser values; a learned repair, not a certificate) and gets the same three outcomes. Every row carries the reference model's risk; `s15_locality_performance_matched` pairs each pegged row with the no-peg row of closest reference risk. The positive controls state their certificate coverage. |

## Further changes

* Gradient partitions (review Family 2): `growth.spec_partition` gains `redrawn_random` (a fresh split every batch
  from a stream keyed by the trainer step) and `all_examples` (the same branch graph without masks);
  `growth.spec_random_fraction` sets the random share. The EMPIRICAL exposure under the actual sampler (per branch
  and group) accumulates in the trainer state and is reported as `spec_exposure`; the access record's proportions
  are labelled nominal. Wave 15 runs all seven partitions on X4 rho 0.95 with one removal protocol and C1.
* Confirmation (wave 14, still a draft until wave 15 is reviewed): the F07 finite-bit cells use the recipe panel
  (fixed / ema / warm-up at 1 and 0.3 x LR) instead of the collapsed strict comparison; a locality panel (five
  interfaces x widths 4 and 16, one repair budget) on the five primary draws; M_E adds the abrupt arm.
  1976 jobs, about 17 h serial on the RTX A4500 from the re-pilot's timings (locality about 4.4 h of it).
* scripts/17 (new): tests, the read-only v13 rebuild, wave 15, checks, reload, summary and the runtime estimate.

## Fixes after an independent review of the v15 patch

* Paired summaries now pool replications: a summary row is per (contrast, f0 stage, arm, panel), and a pair is
  formed only within one (f0 run @ stage, replication). Before, every replication (each with its own f0 run) got
  its own summary row, so a multi-draw confirmation would never have produced a pooled effect. Test uses a
  distinct f0 per replication and random orderings.
* The finite-recipe panel has its own comparisons (`s15_finite_recipe_tuned_*`: per strict recipe, treated and
  scratch over the same learning rates, best by validation; `s15_finite_recipe_matched_lr_*`: every recipe at every
  shared rate, the warm-up arm only against the treated fixed-range arm at the same rate, never in a best-of
  selection). Arms named treated_* are labelled treatment variants in every paired table.
* Locality performance matching stays within one replication and f0.
* The adaptive range never moves in restricted segments (decoder refit, locality repair scopes, bridge
  retirement), so an interface held fixed keeps its code.
* Wave 14 no longer trains duplicates: F07 dim 8 is the C4i dim-8 cell; the recipe panel uses only the F07 bit
  cells (the M_E 2-bit arms run in the M_E block).
* scripts/16: the freeze copies the manifest into the results folder and `run` uses that copy; a second freeze
  needs `REFREEZE_REASON` (recorded); every stage's output goes to `stage_<name>.log`; added stages check reload
  coverage against the endpoints and that the code at the end of the run is the frozen code or a recorded
  amendment. A `PROTOCOL_AMENDMENT` left set accepts later changes too (each is recorded): unset it after use.
* Tuning cost counts the shared f0 selection search once; `info_access` marks redrawn partitions as random;
  locality reports `dipped_after_first_passage` and `lost_at_end` separately.
* Limits found in v15 and fixed in v16: the frozen sweep deleted only the removal targets (the whole X4 / P2
  group), so one branch could not be deleted alone; in multi-phase removals only the first cut got a full
  evaluation. Still a limit: selected (best_val) checkpoints are not reloaded by the fresh-process check.

## v16 (multi-pass review of v15)

CHANGES_v16.md lists the fixes; COVERAGE_v15_review.md maps every request in the review to done / partial / not
done. Main fixes: branch-only deletion in the frozen sweep; full evaluation at every cut; gradient audits at the end
and selected checkpoint; pooled draw-level summaries for the recipe panel and M_E (v15 had per-replication rows
only); like-decoder pooling and probe-fit budget for readouts; `summarize --strict` so an analysis crash fails the
launcher; the locality cell added to wave 15.

## Not done

* Learned quantisation scales (PACT / LSQ); f0 readouts at the cut; the interface-relabelling experiment (Family 3),
  route-order and inverse-pair removal comparisons (Family 4), and co-adaptation-duration panels (Family 1) beyond
  the frozen-weight sweep. These are the next staged experiments, not part of wave 15.
* Novelty: no claim in this repository rests on identity-preserving insertion, grow / shrink inheritance,
  progressive module replacement, temporary linear capacity or stochastic branch regularization by themselves
  (Network Morphism, ExpandNets, LEMONADE, BERT-of-Theseus, StochasticBranch). Affine transplant success is not
  read as feature equivalence (Smith et al. 2025).
