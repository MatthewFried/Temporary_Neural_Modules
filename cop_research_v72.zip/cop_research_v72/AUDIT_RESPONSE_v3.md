# Response to the independent v3 audit (V3-01 ... V3-12), v4 (`cop-4.0.0`)

Each item gives the fix, the test that guards it, and what remains limited. Tests named `supplied::` are the audit's own gates in `tests/test_v3_audit_supplied.py`; the others are in `tests/test_v4_audit.py` unless a file is named. Evidence files are under `sandbox_checks/v4/` and `audit_v4/evidence/`.

## V3-01 Diverged repair reported with a stale endpoint

Fix: every model-producing job (baseline, trajectory, dissipation, repair, continue, CoP export) ends in `common.record_endpoint`. It reloads the named checkpoint from disk, evaluates it on every partition under stage `endpoint`, saves the predictions and writes `endpoint.json` (checkpoint, param hash, updates, `diverged`, `diverged_reason`, tensor and metric finiteness, `numerically_valid`, architecture hash, params, MACs, peg bits). Repair always evaluates at its last update. The analysis reads only the endpoint stage; `_endpoint_stage` and "largest repair@ step" selection are gone. A diverged or numerically invalid endpoint is ineligible, excluded from gains and counted in the denominators. The return policy is the final checkpoint for every job; no last-valid state is substituted. Divergence in any training phase of a job (for example a CoP chain, cycle or `direct_small` training) is recorded on the run context, carried in every checkpoint so a resumed attempt keeps it, and inherited by the endpoint. A CoP local fit (`LocalOpt`) that produces a non-finite loss or parameters fails the job with that reason.

Tests: `supplied::test_diverged_repair_not_reported_as_successful_endpoint`; `test_diverged_repair_between_evaluations_is_evaluated_where_it_stopped`; `test_cop_chain_divergence_reaches_the_endpoint_and_work_counts_actual_updates`; `test_local_loop_divergence_fails_the_job_instead_of_completing`; `test_every_endpoint_kind_records_a_reloadable_endpoint` (reloaded checkpoint reproduces every endpoint metric for six job kinds); `test_finite_weights_with_non_finite_outputs_are_not_an_endpoint`; `test_summary_counts_diverged_and_ineligible_and_lists_complete_but_diverged`.

Limitation: a diverged job stays `complete`; divergence is an endpoint property, not a job failure. A failed repair is not evidence of permanent loss.

## V3-02 Non-finite final updates escape detection

Fix: after every optimizer step the trainer checks the updated parameters (one fused max-abs reduction over the step's tensors), including on the last step. On failure it sets `diverged`, `diverged_at` and `diverged_reason`, counts the update and its work, and stops. Job work records, endpoint update counts and the budgets derived from them use the updates actually made, not the requested ones. The loss is still checked before backward. Output overflow with finite weights is caught by the endpoint evaluation (V3-01).

Tests: `supplied::test_final_step_nonfinite_parameters_mark_divergence`; `test_last_update_overflow_marks_divergence_and_counts_the_update`; `test_dissipation_work_counts_actual_updates_after_divergence`; `tests/test_strengthening_v3.py::test_divergence_stops_training_and_skips_later_segments`.

Limitation: gradients are not checked separately. Under SGD and Adam(W) a non-finite gradient gives a non-finite update, which the parameter check catches. An optimizer that could absorb a non-finite gradient without changing parameters would need its own check.

## V3-03 Compact gain ignores the architecture contract

Fix: three estimands. `fixed_architecture` needs treated, control and f0 to share one architecture hash. `matched_endpoint` needs treated and control to share an architecture that differs from f0's. `cost_frontier` covers differing architectures and is descriptive. The compact flag no longer decides when architecture records exist. Wave 7 adds endpoint-matched CoP controls: M1 (updates) and M2 (estimated compute) continue from the treated export with `reinit`, recalibrated quantisers and an asserted architecture, with f0's budget added. CoP cycles use the existing `direct_small` control as M1.

Tests: `supplied::test_noncompact_cannot_enter_fixed_architecture_gain`; `test_estimands_follow_the_endpoint_architectures`; `test_cop_export_against_f0_is_a_frontier_and_its_matched_control_is_matched`. Evidence: `sandbox_checks/v4/rejection_examples.json` (`cop_export_classification`: real smoke CoP exports, where C1 from f0 is `cost_frontier` and M1 / M2 are `matched_endpoint`).

Limitation: architecture equality does not cover interface budgets or retained side channels on its own. Those enter through peg bits and adapter accounting in the endpoint record, and are reported beside the gain, not used as a pairing condition.

## V3-04 Duplicate keys and label-only pairing

Fix: the pairing key is (contrast, f0 run, arm, replication, budget panel). Pairs must also agree on data identity, model identity and target regime. A duplicated key raises `ValueError` in strict mode. In non-strict mode (used by `summarize`) every entry of the key is excluded and recorded in `s_rejected.csv/json`. Summary rows report expected, eligible, diverged, ineligible, unmatched and paired counts.

Tests: `supplied::test_duplicate_pairs_must_be_rejected`; `test_pairing_rejects_duplicates_and_incompatible_contracts_but_not_other_scales`. Evidence: `audit_v4/evidence/contract_collisions.json` (full plus pilot in one root: v3 label key 953 collisions, v4 contract key 0); `sandbox_checks/v4/rejection_examples.json` (a duplicated control, an incompatible data identity and a diverged treated row injected into the real smoke table, with the strict error and the non-strict records).

Limitation: optimizer policy and budget policy are not compared field by field. They are fixed by the manifest generator per contrast and enter the run id.

## V3-05 CPU and accelerator tensors mixed

Fix: affine and symbol alignment fits move inputs to CPU, fit in float64 and return a CPU module that the caller moves to the model's device and dtype. C8 masks are CPU row indices moved to the weight's device when applied; random regrowth rows are drawn from a CPU generator and moved before any arithmetic. Later-query decoding moves codes to CPU before the table lookup, so seen and unseen rows are built on one device.

Tests (CPU): `test_alignment_fits_run_on_cpu_for_any_input_device`. CUDA: `supplied::test_cuda_affine_alignment`, `supplied::test_cuda_symbol_alignment`, `supplied::test_cuda_prune_regrow`, `supplied::test_cuda_later_query_mixed_seen_unseen_codes`, `test_cuda_affine_and_symbol_alignment`, `test_cuda_end_to_end_jobs_and_resume` (transplant, C8 across prune and regrowth with resume, a later-query chain, a CoP bridge, a tree contraction, all on the GPU).

Limitation: no GPU in the sandbox, so every CUDA test was skipped here. `scripts/12_v4_gpu_gates.sh` runs them and treats a skip as a failure. The meta-device probe now fails with "Cannot copy out of meta tensor" because the fit moves data to CPU; that is the intended policy, not a device mix.

## V3-06 C8 pruning not persistent

Fix: `Segment.post_step` re-zeroes the masked rows after every optimizer step, so every evaluation and checkpoint sees the pruned model. At prune and at regrowth the optimizer moments of the affected rows are zeroed (`moment_policy reset_at_prune_and_regrow`, recorded per event). Masks and event positions are checkpointed, so a run that stops inside a prune window resumes exactly.

Tests: `supplied::test_pruned_channels_stay_zero_for_evaluation_with_optimizer_momentum` (with the documented adapter that passes the optimizer, DEVIATIONS 93); `test_pruned_rows_stay_zero_through_steps_evaluation_and_resume` (steps inside the window, a job that ends mid-prune, saved zero rows, interrupted versus uninterrupted equality). Resume: `continue_C8_end_mid_prune` and `continue_prune_regrow` in `sandbox_checks/v4/resume_comparisons_v4.json`.

Limitation: Adam's step counter is per tensor and is not reset, so a regrown row uses the tensor's bias correction. This is part of the named C8 intervention.

## V3-07 Fixed versus relearned pegs confounded

Fix: three switches, `cop.cycle_peg_maps` (frozen / learned), `cop.cycle_peg_width` (constant / narrowed) and `cop.cycle_peg_recalibrate` (yes / no). `fixed` and `relearned` remain as compound presets. F07c is now the 2 x 2 maps x width grid, plus both presets. X3 compares maps at constant width. Each cycle records `peg_dims` and `peg_bits_per_example`.

Tests: `test_map_adaptation_cells_share_dimensions_bits_and_narrowing` (frozen and learned maps at the same width schedule give identical per-cycle dimensions, bits and narrowing events); `test_wave7_has_the_matched_factor_cells`. Resume: `cop_cycles_learned_constant`.

Limitation: frozen maps fix the encoder and decoder, not the transmitted codes. Upstream activations still change.

## V3-08 Architecture hash ignores parameter sharing

Fix: the architecture hash is computed from a canonical serialisation of the effective graph (depth-first from the outputs, inputs in their ordered positions, identity nodes transparent, back-references where an input is the same node). Sharing classes are sets of canonical positions, so crossed ties between structurally symmetric nodes (A1=B1, A2=B2 versus A1=B2, A2=B1) get different hashes; an earlier v4 draft that used Merkle keys did not (found in review). Node ids and pkey names do not enter, so renaming stays invariant. Module-internal aliasing enters through the module's own parameter list in the node signature.

Tests: `supplied::test_parameter_sharing_changes_architecture_identity`; `test_sharing_pattern_is_part_of_architecture_identity` (untied, tied 1-2 and tied 0-1 give three hashes; a clone keeps its hash); `test_crossed_ties_between_symmetric_nodes_change_identity` (also: one node read twice differs from two equal nodes); `test_aliasing_inside_a_custom_module_changes_identity`.

Limitation: equal hashes mean the same parameterised family up to the ordered input positions: `add(a, b)` and `add(b, a)` of different subgraphs hash differently although addition commutes. They do not mean equal functions at given parameters.

## V3-09 Compute is a surrogate; incomplete totals plotted

Fix: the dense count is named `estimated_dense_3x_forward` (`macs_method`). A backward-aware estimate (`train_macs_bwd`: forward, weight gradients of trainable nodes, input gradients of nodes with a trainable ancestor) is recorded beside it. Every phase records `macs_complete`, and run and chain totals aggregate it. C2 (`parent_compute`) is refused when the parent's compute is incomplete. Figure 1 plots only complete chains. `budget.json` records the rounding overshoot. Docs now say "estimated".

Tests: `test_backward_aware_estimate_depends_on_what_trains`; `test_local_fit_phases_mark_compute_incomplete`; `tests/test_strengthening_v3.py::test_compute_matched_continuation_matches_the_treated_chain`.

Limitation: neither estimate is measured backward work. Elementwise ops, optimizer arithmetic and overhead are not counted. Budgets still use the dense estimate so C2 stays comparable across waves. Profiling representative traces is not done.

## V3-10 Transplant alignments not saved

Fix: alignment modules are registered types (`align_affine`, `align_symbol`, `align_identity`). The transplant job saves every row it evaluates (upstream, downstream, direct, aligned, BN-recalibrated) as `ckpt/transplant_<row>.pt`, evaluates each from the saved file, saves predictions and lists the checkpoints in `saved_models`. The route-removal clone is saved as `diagnostic_route_repair` with the erasure fill values (training means of the held coordinates), and its work is counted under `diagnostic:route_repair`, outside the chain.

Tests: `test_transplants_are_saved_and_reload_in_a_fresh_process` (subprocess reload, bitwise predictions). Evidence: `sandbox_checks/v4/fresh_reload.json`: a new process reloaded all 1,232 endpoint and transplant checkpoints of the v4 CPU smoke run and reproduced the saved test predictions bitwise, with equal architecture hashes.

Limitation: the route-removal bit reduction is still analytic. The quantiser node is not physically narrowed.

## V3-11 Comparisons that change more than the named factor

Fix:
* a. M_F runs same and moving cuts at `contract_every` 1 and 2, and nested at 2, so the three cuts meet at matched frequency and contraction training.
* b. F06e keeps the v3 policy comparison (fixed every 1 against damage-triggered), adds fixed every 2 (matched maximum interval) and `contract_trigger replay`, which contracts at the parent's realised rounds from its `contractions.json`.
* c. The trainer logs `trainable_state` at every segment start and freeze-schedule phase change, with trainable and total parameters and the trainable modules. F04 labels are renamed `..._growth_policy__contraction_trains_all`.
* d. Wave-7 controls refuse a non-constant learning-rate schedule or warmup, read from the treated job's resolved config, the overrides and the control config. Segment matching is not built.
* e. C7's fixed perturbation and composite decay stay named compound baselines (DEVIATIONS 77-78).

Tests: `test_replay_contracts_at_the_realised_adaptive_rounds`; `test_trainable_state_is_recorded_per_phase`; `test_wave7_has_the_matched_factor_cells`; `test_controls_refuse_a_non_constant_schedule`. Resume: `traj_replay_schedule`.

Limitation: replay skips the parent's damage probes, so replay and the triggered run differ by probe forwards (charged to the triggered run). C7 is not matched to the treated displacement.

## V3-12 Plots mix quantities and hide failures

Fix: figure 1 is per estimand, faceted by task, and its x-axis compares M1 / M2 with the treated chain plus f0 (their budgets include f0's); figures 2, 4, 6 and 7 are faceted by task and leave out numerically invalid endpoints with a count; figure 5b is per estimand and family; figure 6 has separate MACs, parameter and bit panels. No figure truncates to the first runs. Every per-run table carries `task` and `endpoint_numerically_valid`. The CoP chain's pre-export evaluation is now stage `chain_trained`, so stage `endpoint` always means the reloaded endpoint. `s_endpoint_eligibility.csv/json` lists every design job with its reasons. `s_untested_or_ineligible_cells.json` includes complete but ineligible or diverged cells. Summary rows carry the denominators, and the interval column says "exploratory percentile bootstrap over replications".

Tests: `test_summary_counts_diverged_and_ineligible_and_lists_complete_but_diverged`. Evidence: `sandbox_checks/v4/wave7_smoke_summary/`.

Limitation: wave 7 is a screening wave with three seeds. Primary contrasts must be chosen on validation and confirmed on new seeds and held-out tests (QUESTIONS 22).

## Review of the v4 draft

An independent reviewer checked the draft fixes against the audit (REVIEW_v4.md). It found that CoP training divergence did not reach the CoP endpoint, that job work records used requested updates after a divergence, that the first sharing-aware hash still collided for crossed ties between symmetric nodes, and five minor issues (figures mixing tasks, the route-repair fill values not saved, the schedule guard missing warmup in the treated config, two models logged under stage `endpoint` in CoP chains, and the figure-1 cost basis for M1 / M2). All eight are fixed in this package, with tests for the first three; every check and evidence file was regenerated afterwards.

