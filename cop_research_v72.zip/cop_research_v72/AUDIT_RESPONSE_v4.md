# Response to the review of v4 (v5, semantics `cop-5.0.0`)

The review (`CoP_v5_Review_and_Claude_Handoff`) asked for P0 to P5 before the scientific pilot and listed minimum correctness checks (its section 10). This file gives, per item, what changed, where, the test, and what stays limited. P0 to P5 are the review's priorities, not the specification's CoP work packages P1 to P5. The tests are in `tests/test_v5_review.py` unless named otherwise. The new blocks are described in docs/STRENGTHENING.md ("v5 additions"); the design choices are DEVIATIONS 98 to 108.

An independent agent then reviewed the v5 draft; its findings and their fixes are in REVIEW_v5.md and are included below.

Nothing here is a result. Everything below ran on CPU at smoke scale in the sandbox; the CUDA tests did not run (no GPU).

## Novelty and literature

The review's literature points are accepted. Model stitching and its interpretation (Bansal et al. 2021; Smith et al. 2025; Athanasiadis et al. 2026), Shapley and cooperative-game pruning (Adamczewski et al. 2024; Ding et al. 2026), folding and depth compression (Layer Folding 2022; LayerMerge 2024; Saukh et al. 2026) and the damage-versus-generalisation view of pruning (Bartoldson et al. 2020) already cover the broad claims. The code and docs therefore make no "first" claim and no claim that a measurement establishes a mechanism. Bartoldson et al. also give an alternative explanation that the controls must address: contraction can help through perturbation or regularisation (C7 is the perturbation control). What the framework can test is narrower and is stated as a question: whether controlled expansion histories change recovery cost and required repair scope at matched endpoints and work, whether a pre-removal diagnostic predicts that on new seeds, and whether stable interfaces change it. The finite bounds and the compositional certificate are measurement tools, not contributions.

## P0. Witness, terminology, bit budgets, query isolation

| item | change | where | test |
|---|---|---|---|
| tanh teacher is not a witness for a ReLU student | constructive witness only when the teacher embeds exactly (same activation, MLP, no BN or late query, enough width and depth; extra ReLU layers as identity blocks; head folds the output standardisation); verified against the noiseless teacher on train, val, test and a fresh sample (max abs error <= 1e-4); saved as checkpoint `witness` and `witness.json`. Otherwise the reason is recorded (approximation-mismatch condition) | `cop/data/witness.py`, `trajectory.record_witness` | `test_witness_reproduces_the_teacher_and_mismatch_is_reported` (ReLU witness verified, tanh and narrow students refused with reasons) |
| realisable cells | ReLU teacher depth 4, width 64 that the MLP 64 x 4 realises; tanh cells kept as the mismatch condition | `wave7.py` blocks `W7_v5_witness`, `W7_v5_witness_targets_T0/T1` | smoke run |
| gap closure only against a reachable, loss-compatible reference | (R_C1 - R_compact) / (R_C1 - R_witness) for regression on clean held-out targets, undefined at denominator <= DELTA | `v5_tables.gain_retention` | below |
| "absorption" | removed; eta = (R_C1 - R_compact) / (R_C1 - R_expanded) is called gain retention, raw numerator and denominator always kept, undefined at or below DELTA = 1e-3, never clipped | `v5_tables.gain_retention`, `s_gain_retention.csv` | `test_gain_retention_is_undefined_at_or_below_delta_and_never_clipped` (0, DELTA / 2, DELTA, negative, defined with eta = 3), `test_gain_retention_negative_numerator_is_kept` |
| total bits | K counts every bit at the bottleneck peg (dimension x bits per coordinate) | `finite_interface.bottleneck` | finite tests below |
| query isolation | the finite score requires the query not to reach any encoder (graph check) and the messages to be identical for every query of one x (data check) | `finite_interface_scores` | `test_finite_scores_need_bridge_removed_and_a_query_blind_encoder` (query at the input is refused) |

Limitations: witnesses exist for MLP teachers only. For classification the witness reproduces the logits, so argmax labels are exact but the cross-entropy infimum is not attained; gap closure is regression only. A witness separates approximation error from the rest; estimation error and label noise remain.

## P1. Non-mutating contraction diagnostics

`cop/experiments/diagnostics.py`, called before every contraction (dissipation start, repair start, each grow / contract cycle), for every implant that will be removed:

* A: affine fit on training activations, scored on validation activations: raw residual, residual relative to output variance and to the implant's change, condition number and rank, with the fitting convention stated in the module docstring and DEVIATIONS 101.
* B: downstream residual E||J_D(T(h)) r(h)||^2 by a Jacobian-vector product (first order; recorded as a limitation in each row).
* C: task risk after a virtual affine replacement on a clone (immediate damage, an intervention measurement).
* Baselines: single deletion damage, implant output size, gate values, pre-contraction risk.
* Maps saved and reloadable (`diagnostics/<tag>.pt`); fit, replacement and JVP seconds recorded.
* Parameters, buffers, gates and CPU / CUDA RNG states are fingerprinted before and after; any change fails the job.

Bypass, fold, fitted replacement and learned repair are reported as separate operations. Block `W7_v5_fold_frozen_backbone` folds a linear factor with the backbone frozen, which separates the algebraic fold from learned repair. The checkpoints needed for retrospective diagnostics (per-round trajectory checkpoints, the parent stage of every contraction) were already kept; the diagnostics can be rerun on them.

Tests: `test_tiny_affine_residual_can_carry_all_the_task_signal` (the review's epsilon example through the real graph code: rho = 0.25 eps^2 while the virtual replacement and the JVP both give output change 0.25 at eps = 1, 1e-3, 1e-6; this is also the coordinate-rescaling case, since the function is fixed and only the scale of one coordinate changes), `test_large_affine_residual_can_be_task_irrelevant` (rho = 2.5e5, virtual damage and JVP 0), `test_identity_and_exactly_foldable_implants_have_zero_residual_and_no_virtual_damage`, `test_diagnostics_change_no_state_and_saved_maps_reproduce_the_virtual_risk` (parameters, buffers, gradients, Adam state and RNG unchanged; reloaded maps reproduce the recorded virtual risk; idempotent per tag), `test_dissipation_job_records_unchanged_state_diagnostics`, `test_diagnostics_refuse_a_state_change` (an injected RNG draw fails the job). The state check also caught a real defect: a fold-type deletion baseline drew from the global RNG in a `node_factorization` cycle job (fixed, DEVIATIONS 108).

Predictor validation: `s_predictor_screen.json` is exploratory. Correlations are computed within replications; the first replication is the discovery set and the sign is checked on every other replication; one level of topology, cut location and nonlinearity at a time is held out for a transfer check; every baseline predictor is screened beside the diagnostics. `test_predictor_screen_uses_a_discovery_replication_and_held_out_replications`.

Limitations: rho is not scale-free and is a candidate predictor, not a damage bound. The Lipschitz bound in the review is the standard propagation argument and is not claimed as new. The JVP misses curvature and saturation. The screen fits nothing, so it is a sign check; predictor choices must be frozen before confirmatory seeds. Dense fitting costs O(N d^2 + d^3); the smoke run records it per implant.

## P2. Finite interfaces

| item | change | where | test |
|---|---|---|---|
| exact solver | decoder-codebook enumeration with the XOR anchor, exactly min(2^k, 2^n) distinct codewords; retention with a zero-error original task by task-pure (labelled) codebooks; full frontier by encoder enumeration where small; incomplete runs are marked incomplete and never reported as optimal | `cop/finite/codebook.py`, table `configs/finite_interface_optima.json` (`audit_v5/tools/finite_optima.py`, with cross-checks) | `test_codebook_solver_equals_exhaustive_encoder_enumeration` (n = 2 all k; n = 3, k = 0, 1), `test_exact_optima_match_the_review` (n = 3: .5, .75, 5/6, 1; n = 4 and n = 5 as in the review), `test_original_task_constraint_n3_k1_is_two_thirds_and_matches_brute_force` (8 errors of 24; parity and other cases against brute force) |
| two families | A: direct delayed-query learning (`FIN_A`, query injected after the peg); B: original task x_0 or a two-bit parity, later queries scored on the code (`FIN_B`) | `wave7.py` block `W7_v5_finite_interfaces`; `data/synthetic.py` `split_mode complete` | smoke run |
| decomposition | e_model - e_star = (e_model - e_oracle) + (e_oracle - e_star), checked to close; a model beating the oracle of its own code is flagged as a protocol violation | `codebook.decomposition`, `finite_interface_scores` | `test_decomposition_closes` |
| family B ceiling | the task-preserving optimum when the code is task-pure; otherwise the exact frontier at the code's own task error (when enumerable) | `finite_interface_scores`, `s_finite_interface.csv` (`e_later_star_relevant`) | retention test above |
| bypass removed, query-blind | scored only with no bypass around the bottleneck peg and a query-blind encoder | `finite_interface_scores` | `test_finite_scores_need_bridge_removed_and_a_query_blind_encoder` (permanent bridge refused, temporary bridge scored after retirement, early query refused) |
| bridge arms | no bridge, temporary bridge retired gradually or abruptly, permanent bridge (diagnostic), matched total updates, same f0; risk and finite score with the bridge open, right after retirement, and at the endpoint | `chain.py` bridge phases, `bridge_phases.json` | smoke run |
| small-domain splits | train, val and test are each the complete cube and are labelled complete-domain | `split_mode complete` | smoke run |

Limitations: the full frontier is enumerable only for small cases (at most 2^17 encoders), the delayed-query table stops at the solver cap (n = 5, k = 4 is not tabulated), and the parity task-preserving optimum is enumerated for n <= 4. Optima are communication bounds; whether the tested encoder family can attain them is not claimed. Complete-domain scores include training inputs and use ground truth; they are diagnostics, not generalisation. The bridge sees only the original-task loss, never later-query labels.

## P3. Interface locality

`cop/cop_pegs/locality.py` (task kind `locality`, block `W7_v5_locality`): five paired arms on one f0 per seed with the same placement, schedule and data stream (no interface, continuous, continuous stabilized, learned finite, stabilized finite); co-adaptation checkpoints at 25, 50 and 100% of endpoint training, reused by every fork; nested scopes 0 to 4; success is the declared criterion on task risk against the checkpoint's own exported model (drift from its function recorded separately); the smallest successful tested scope is reported, failed or diverged forks never count, and no success is censored. Code stability is reported literally and after the best one-to-one relabelling (continuous codes: relative change and affine-aligned residual). For finite pegs, an incoming-table certificate compares the pearl's outgoing code for every incoming code.

Tests: `test_smallest_successful_scope_ignores_failed_and_diverged_forks_and_records_censoring`, `test_incoming_table_certificate_fails_on_a_changed_unseen_code` (a real locality job; a perturbed pearl changes a strict subset of codes; the full-table certificate fails, while a check restricted to the codes that still agree passes, which is the coverage-conditional case). The previous `repair_scope_table` still reports configured scope and trainable counts; the minimum successful tested scope is in `s_locality.csv`.

Limitations: one serial chain topology, the middle pearl only, one replacement width; a branched screen is not implemented (QUESTIONS 28). At smoke scale almost every fork is censored, as expected from 20-update budgets. The certificate is implemented for uniform finite pegs and enumerates the full table up to 65,536 incoming codes, which covers the wave-7 peg (8 x 2 bits); above that it checks the calibration codes and says so.

## P4. Static dependence game

`cop/analysis/dependence_game.py`, computed from existing exhaustive deletion files (no new jobs): sign d(S) = R(delete S) - R(checkpoint); Shapley values, pair interactions at the empty set and Shapley interaction indices, Moebius terms by order, greedy against best-k, the min-max one-at-a-time path, and the minimum batch size per tolerance. Structured or sampled landscapes, invalid deletions and missing coalitions are rejected with the reason. `same_graph_as` aliases are resolved, and coalitions changed by canonical descendant removal are flagged (`hierarchical`).

Tests: `test_shapley_efficiency_symmetry_and_dummy`, `test_inverse_pair_has_zero_shapley_nonzero_interaction_and_needs_a_batch_of_two` (also the symmetric strong-interaction game with greedy optimal), `test_incomplete_or_invalid_landscapes_are_rejected`.

Limitations: fixed weights only; with repair between removals the landscape no longer determines the path, and the dynamic order experiments (F06c) stay separate. Exact games need at most `deletion.max_exhaustive_atoms` (10) atoms.

## P5. Transplants

`transplant.design grid` (block `W7_v5_transplant_grid`): all four upstream x downstream pairs of f0 and the post-cycle model, with adapter families identity, orthogonal, affine, residual MLP (activation matching), and affine and MLP adapters trained on the task through the frozen network. Every pair, including the self pairs, gets the same family and budget; adapter parameters are reported and not credited to the backbone; every model is saved and reloaded before it is evaluated on the evaluation partitions and on every challenge partition the dataset has. The contrast is whether the new upstream improves the old downstream over the old upstream under the same adapter fitting. A second grid (`grid_vs_C1`) uses f0's work-matched continuation C1 as the old model, so the contrast does not just measure extra training.

Limitations: a transplant measures compatibility under the tested adapters. It does not separate features from conventions (a private convention can itself be affine), and a failed rescue has several possible causes; no feature-information claim is made. Counterfactual or invariance probes per task are not implemented.

## Section 9 (optimizer control)

No claim is made that an expansion's effect cannot be reproduced by an optimizer change. The comparator class is the implemented controls C1 to C8 and M1 / M2, with their budgets; DEVIATIONS 81 says what the compute estimate counts.

## Section 10 checks

| check | test |
|---|---|
| epsilon residual and task-irrelevant residual | `test_tiny_affine_residual_can_carry_all_the_task_signal`, `test_large_affine_residual_can_be_task_irrelevant` |
| identity and exactly foldable implant | `test_identity_and_exactly_foldable_implants_have_zero_residual_and_no_virtual_damage` |
| no measurement-induced state change | `test_diagnostics_change_no_state_and_saved_maps_reproduce_the_virtual_risk`, `test_diagnostics_refuse_a_state_change`, `test_dissipation_job_records_unchanged_state_diagnostics` |
| solver equals exhaustive enumeration (n = 2; n = 3, k = 1) | `test_codebook_solver_equals_exhaustive_encoder_enumeration` |
| n = 3 optima and the constrained 2/3 | `test_exact_optima_match_the_review`, `test_original_task_constraint_n3_k1_is_two_thirds_and_matches_brute_force` |
| decomposition closes | `test_decomposition_closes` |
| bridge removed, encoder query-blind | `test_finite_scores_need_bridge_removed_and_a_query_blind_encoder` |
| certificate fails on a changed unseen code | `test_incoming_table_certificate_fails_on_a_changed_unseen_code` |
| Shapley properties, inverse pair | `test_shapley_efficiency_symmetry_and_dummy`, `test_inverse_pair_has_zero_shapley_nonzero_interaction_and_needs_a_batch_of_two` |
| incomplete or invalid landscapes rejected | `test_incomplete_or_invalid_landscapes_are_rejected` |
| smallest tested scope ignores failed or diverged runs, records censoring | `test_smallest_successful_scope_ignores_failed_and_diverged_forks_and_records_censoring` |
| witness reproduces its teacher | `test_witness_reproduces_the_teacher_and_mismatch_is_reported` |
| zero, tiny or negative gain denominator | `test_gain_retention_is_undefined_at_or_below_delta_and_never_clipped`, `test_gain_retention_negative_numerator_is_kept` |
| CUDA smoke of fit, virtual replacement, JVP and reload | `test_cuda_diagnostics_fit_virtual_jvp_and_reload`, `test_cuda_v5_jobs` (not run here: no GPU; `scripts/12_v5_gpu_gates.sh` runs them and fails on a skip) |

## Runtime

Measured, not promised. Wave 7 grows from 3,603 to 4,077 jobs at full scale and from 1,201 to 1,359 at pilot and smoke scale. At smoke scale on this CPU, the v5 blocks took about 103 of 1,254 serial seconds, and the diagnostics inside the older contraction jobs about 28 s more (`sandbox_checks/v5/added_work_v5_blocks.json`). Smoke budgets are tens of updates, so these numbers do not transfer to the GPU pilot. Diagnostics scale with `eval.calib_size` and the activation width (dense fit O(N d^2 + d^3)), locality jobs are genuine training work (five arms, three checkpoints, four repair forks each), and the transplant grid fits six adapter families on four pairs. `scripts/11` measures a stratum sample on the GPU and prints the pilot estimate before running it.

## Evidence

`sandbox_checks/v5/README.md`: the full CPU suite, the wave-7 smoke run (1,359 jobs complete and valid), fresh-process reload of 1,546 checkpoints and both witnesses, and interrupted-versus-uninterrupted equality of the 8 new and 21 v4 job paths.
