# v12 -> v13 file-by-file change list

Full diff: PATCH_v12_to_v13.diff. Semantics `cop-5.0.0` -> `cop-6.0.0` (all run ids change).

| File | Change |
|---|---|
| cop/config.py | CODE_VERSION `cop-6.0.0`; new keys with validation: `train.select_candidates`, `train.select_partition` (validation partitions only); `growth.spec_partition`; `dissipation.post_match_macs_of`, `save_path_checkpoints`, `path_full_eval`; `cop.global_match_macs_of`, `decoder_refit_updates`, `locality_controls` |
| cop/experiments/common.py | `identity_check` rewritten around d_edit with fixed limits (`IDENTITY_EDIT_ROUNDOFF_MAX_REL`, `edit_roundoff_limit`), verdict `execution_changed`, u_pre / u_post diagnostics; `record_endpoint(..., name=)`; `selection_points`, `Selector` (validation-only selection inside the final compact phase, `best_val` checkpoint, `selection.json`, `endpoint_best_val.json`) |
| cop/experiments/trajectory.py | insertion gate labels and records for the new gate; baseline ledger phase `baseline_train`; selection in baselines; `_spec_split`, `spec_access_record`, `spec_masks(mode)`, random-matched partition (`spec_partition.pt`), `specialization_access.json`, `group_inference_check` (job fails if predictions depend on group metadata) |
| cop/experiments/continuation.py | `baseline_cost`, `inline_f0_cost`, `run_work` (baseline jobs report their ledger / checkpoint counters / missing); selection; scratch-reset audit (`unchanged_after_reset`, `quantizer_audit`, `gradient_audit`); later-query retention for controls |
| cop/experiments/context.py | `set_work` (absolute ledger phase), `has_json`, `load_json` |
| cop/experiments/control.py | Wave-0 controls use the new identity verdicts |
| cop/experiments/dissipation.py | selection after the last physical removal; MAC-matched final phase; dense path checkpoints; full path evaluations (risk on every partition, logit norm, drift, flip rate) |
| cop/experiments/repair.py | selection in the final repair phase |
| cop/experiments/probes.py | skip auxiliary targets starting with `_` or absent from validation |
| cop/cop_pegs/chain.py | `load_f0` honours `tags.f0_stage`; MAC-matched endpoint segment planned inside `train_chain` (resume-safe `mac_plan`); validation selection over the endpoint segment (exported candidates); `decoder_refit` |
| cop/cop_pegs/locality.py | locality controls: exact local replacement, literal frozen-code lookup (`frozen_code_lookup`), code matching; censoring note |
| cop/data/synthetic.py | shortcut validation environments `val_indep`, `val_reversed`, `val_rare` (other partitions unchanged; checked by hash) |
| cop/orchestration/wave13.py (new) | waves 13 (re-pilot) and 14 (confirmation); `info_access`, `budget_meta` on every entry |
| cop/orchestration/manifest.py | registers waves 13 and 14 |
| cop/analysis/strengthening.py | `f0_cost`, baseline / post-baseline / total-procedure cost fields; f0 stage in pairing keys; `selected_gain` and `s_selected_*` tables (with and without f0 fallback, rejected pairs); calls the v13 tables |
| cop/analysis/v13_tables.py (new) | `s13_tuned_*`, `s13_removal_paths`, `s13_x4_information`, `s13_history_ingredients`, `s13_later_query_retention`, `s13_finite_refit`, `s13_locality_controls`, `s13_analyses.json` |
| cop/analysis/summarize.py | `--historical` remeasurement (`historical_provenance.json`); `numeric_validity.json` |
| cop/analysis/pilot_report.py | baseline cost per job |
| cop/cli.py | `summarize --historical` |
| audit_v5/tools/runtime_v13.py (new) | runtime fit / estimate from measured timings |
| audit_v6/ (new) | the audit's two probes and their output on v13 |
| scripts/15_v13_repilot.sh (new) | tests, CUDA tests, probes, historical costs, wave 13, checks, reload, summary, runtime, zips |
| scripts/16_v13_confirmation.sh (new) | freeze and guarded launch of wave 14 |
| tests/test_v8_audit.py | v13 identity-gate regressions (CPU and CUDA) |
| tests/test_v13.py (new) | baseline ledger, selection, specialization, validation environments, manifests, MAC matching, decoder refit, locality controls, M_E controls, numeric validity, CUDA job test |
| AUDIT_RESPONSE_v12.md, CLAIMS_v13.md, CHANGES_v13.md, DEVIATIONS 126-136, README | documentation |
