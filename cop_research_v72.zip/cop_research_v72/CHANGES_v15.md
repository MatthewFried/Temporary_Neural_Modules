# v14 -> v15 file-by-file change list

Full diff: PATCH_v14_to_v15.diff. Semantics `cop-6.0.0` -> `cop-7.0.0` (all run ids change; the v13 re-pilot is
re-analysed read-only by scripts/17).

| File | Change |
|---|---|
| cop/config.py | CODE_VERSION `cop-7.0.0`; `train.quant_range` (fixed / ema), `train.quant_range_momentum`, `train.quant_warmup_updates`; `growth.spec_partition` adds `redrawn_random`, `all_examples`; `growth.spec_random_fraction` |
| cop/graph/ops.py | Quantizer: training-mode passthrough flag (warm-up recipe) |
| cop/train/trainer.py | finite-peg recipes: warm-up switch and calibration, EMA range hooks and update after each step |
| cop/experiments/trajectory.py | `_spec_split` redrawn / all-examples modes and random share; nominal access record; empirical `spec_exposure` in the trainer state and the result |
| cop/experiments/dissipation.py | logit norm and drift at key path events; `frozen_weight_sweep` at the start of every removal with `path_full_eval` |
| cop/experiments/continuation.py | `quant_recipe_name`; quantiser audit with per-coordinate entropy, ranges and code drift; audit at the selected checkpoint; recipe record |
| cop/cop_pegs/chain.py | quantiser audit and recipe record at export |
| cop/cop_pegs/locality.py | `interface_agreement` (integer code and canonical value), sustained / lost success, representation matching (renamed from code matching) with all three outcomes |
| cop/analysis/strengthening.py | `draw_level` summaries in every paired table |
| cop/analysis/v13_tables.py | identity fields and replication-safe pairing for the retention table; duplicate rejection, draw-level fields and full tuning cost in `tuned_gain`; removal-path export by event identity; readout naming; locality three-outcome table, performance-matched table, frozen-sweep table; empirical exposure in the X4 / P2 table |
| cop/orchestration/wave13.py | wave 15 control-development panel (finite-peg recipes, partition dynamics); wave 14 revised (recipe panel replaces strict finite-bit F07 cells, M_E abrupt arm, locality panel on the primary draws) |
| cop/orchestration/manifest.py | registers wave 15 |
| scripts/16_v13_confirmation.sh | per-stage verdict and non-zero exit on any failure; protocol hash with recorded amendments; fresh results folder `~/cop_results_v15`; `RATES` for the estimate |
| scripts/17_v15_rebuild_and_panel.sh (new) | tests, read-only rebuild of the v13 re-pilot, wave 15, checks, reload, summary, runtime |
| tests/test_v15.py, tests/test_v15_launcher.py (new) | regressions listed in AUDIT_RESPONSE_v14.md |
| tests/test_v13.py | renamed locality control key |
| AUDIT_RESPONSE_v14.md, CHANGES_v15.md, DEVIATIONS 138-142, REPILOT_v13_RESULTS.md (corrections), README | documentation |
