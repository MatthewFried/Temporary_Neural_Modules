# v15 -> v16 file-by-file change list (multi-pass review of v15)

Full diff: PATCH_v15_to_v16.diff. Semantics `cop-7.0.0` -> `cop-7.1.0` (removal evaluations and new audits
change job outputs, so run ids change); default results folder `~/cop_results_v16`. Coverage against the review:
COVERAGE_v15_review.md.

| File | Change | Why |
|---|---|---|
| cop/config.py | CODE_VERSION `cop-7.1.0` | outputs of removal and scratch jobs changed |
| cop/experiments/dissipation.py | frozen-weight sweep deletes EVERY implant alone (branches inside a group too) and records kind / slot / parent; every abrupt cut and every physical removal gets a full evaluation | v15 deleted only the removal targets (a whole group), so branch-only deletion (Family 2) was impossible; later cuts of multi-phase removals had no full evaluation |
| cop/experiments/continuation.py | gradient audit at the end and at the selected checkpoint of scratch arms | review item 5 asks for gradient norms at fixed and selected checkpoints; v15 had the start only |
| cop/cop_pegs/chain.py | later-query rows record the probe-fit budget (examples, code dimension) | review item 6 |
| cop/analysis/v13_tables.py | `draw_summary` (pooled over replications, draw-level, duplicate replication rejected, f0 stages kept apart); pooled summaries for the recipe panel (tuned and matched rate) and M_E retention; `same_decoder_class` per M_E pair, readout retention pooled over like-class pairs only; frozen-sweep rows labelled by implant kind / parent / target; gradient audit columns at start / end / selected; identity fallback (replication, f0 never empty) | v15 reported the recipe panel and M_E only per replication, so a 5-draw confirmation had no pooled effect for them |
| cop/cli.py | `summarize --strict`: exit 3 when a table-level analysis failed | v15's summary stage passed even when the v13 / v15 tables crashed (the error was only written to a file) |
| cop/orchestration/wave13.py | wave 15 adds the confirmation's locality cell (five interfaces, widths 4 and 16, budget 2 x upr) on the discovery draw | the three locality outcomes are new in v15 and had never run before the freeze |
| scripts/16, scripts/17 | `--strict` summaries; results folder `~/cop_results_v16` | |
| tests/test_v16.py | selected_gain with two replications and distinct f0 (selected values, pairs within replication), unequal selection opportunities; finite_recipe_gain with two replications under 20 permutations and pooled summary; draw_summary duplicate / f0-stage handling; M_E pooled retention and like-decoder pooling; branch-only deletion on a hand-built group; sweep table labels; strict summary | |
| tests/test_v15_launcher.py | the mock `cop summarize` requires `--strict` | |

Wave sizes: wave 15 94 jobs (84 + 10 locality), about 1.6 h serial from the lab re-pilot timings; wave 14 1976
jobs, about 17.1 h serial (the estimator does not price the extra full evaluations at later cuts, which are a
small share of a removal job).
