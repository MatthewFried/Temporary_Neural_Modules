# v16 -> v17 file-by-file change list (after the wave-15 panel and its review)

Full diff: PATCH_v16_to_v17.diff. Semantics `cop-7.1.0` -> `cop-7.2.0` (run ids change); results go to
`~/cop_results_v17`. Results of the panel: PANEL_v16_RESULTS.md.

| Review request (30 October) | Change | Where |
|---|---|---|
| 1. Confirm fixed vs redrawn on fresh data seeds and several partition seeds, kept separate | New seed stream `seeds.partition` (default: the insertion seed, so v16 draws are reproduced); a set partition seed adds `_part<p>` to the replication key, a within-draw replication like an optimizer seed (primary analysis = default partition, optimizer seed 0). Wave 14 now runs the partition-dynamics block on the five primary draws: every mode once, and the fixed and redrawn 95/5 splits also at partition seeds 1 and 2; each C1 carries its treated arm's key. Frozen deletion and repaired endpoints are kept. | config.py, experiments/trajectory.py, analysis/strengthening.py (`_rk`, `_parse_rep`), orchestration/wave13.py (`block_partition_dynamics`, wave 14) |
| 2. Adaptive-range, compute-matched finite scratch control; warm-up kept separate | Scratch budget panels: M1 = treated chain + f0 updates, M2 = treated chain + f0 training MACs (the whole treated procedure). Warm-up stays update-matched only and is never in a best-of selection. `finite_recipe_gain` compares within recipe AND budget panel and reports selected and whole-procedure MACs. | wave13.py (`finite_recipe_arms`), analysis/v13_tables.py |
| 1-bit adaptive-range clipping unresolved | `train.quant_ste_margin`: in training, the straight-through gradient also passes for inputs up to margin x (hi - lo) outside the range; the forward value is unchanged. Recipes `fixed_m`, `ema_m` (margin 1e-3) for treated and scratch alike. Read-only probe `audit_v8/tools/quant_boundary_probe.py` measures how many peg inputs sit just outside the range by rounding. | graph/ops.py, train/trainer.py, config.py |
| 3. Locality: first / final / sustained success; explicit tolerance for performance matching | `s15_locality_performance_matched` marks a pair matched only within 5% relative reference risk (`performance_matched`, `match_rule`); new `s17_locality_outcomes` counts first passage, success at end, sustained, found-then-lost and censoring per cell, with function disagreement and code agreement kept separate. | analysis/v13_tables.py |
| 4. Treated selected-checkpoint diagnostics; which checkpoint produced each readout | Treated chains record quantiser and gradient audits at the selected checkpoint and a gradient audit at export; every readout carries `checkpoint` (final / best_val); readouts are also taken at the selected checkpoint (columns `sel_readout_*`) for treated and scratch. | cop_pegs/chain.py, experiments/continuation.py, analysis/v13_tables.py |
| 5. Confirmation manifest lacked the partition panel; runtime used the old fit | Partition block added (above). `runtime_v13.py fitmany` fits one rate table on several result folders (re-pilot, v16 panel, wave 16); scripts/16 uses it when present. | audit_v5/tools/runtime_v13.py, scripts/16 |

New wave 16 (exploratory, draw 0, 106 jobs, about 1.1 h): finite recipes fixed / ema / fixed_m / ema_m for treated
and scratch, warm-up, both scratch budget panels, LR 1 and 0.3. It picks the confirmation's finite recipes.
scripts/18 runs tests, the probe, wave 16 and the combined runtime fit.

Wave 14 is still a draft: 2234 jobs, about 20.9 h serial (planning estimate from the re-pilot and panel rates;
scripts/18 refits on all three). Its finite recipes (`CONFIRM_TREATED_RECIPES`, `CONFIRM_FINITE_RECIPES`) are set
after wave 16.
