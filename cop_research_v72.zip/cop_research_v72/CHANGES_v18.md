# v17 -> v18 (analysis only, after wave 16)

Training semantics unchanged (`cop-7.2.0`): every run id is the same as in v17, so wave 16 results stay current
and the confirmation manifest is identical. Results: PANEL_v16_RESULTS.md (wave 16 section).

| File | Change |
|---|---|
| cop/analysis/v13_tables.py | `finite_recipe_gain_selected`: the recipe panel at each arm's validation-selected checkpoint (LR chosen by that checkpoint's validation risk on each side, equal selection candidates required); tables `s17_finite_recipe_tuned_selected_*`, `s17_finite_recipe_matched_lr_selected_*` |
| cop/orchestration/wave13.py | confirmation finite recipes set (fixed, ema and warm-up; scratch update- and compute-matched; LR 1 and 0.3); margin variants not carried (comment only, manifest unchanged) |
| tests/test_v17.py | selected-checkpoint recipe panel test |
