# v18 -> v19: the mechanism panel (wave 17)

Semantics `cop-7.3.0` (new config keys; every run id changes; the v18 confirmation keeps running from its own
folder and is not affected). Results go to `~/cop_results_v19`. Run with scripts/19.

Wave 17 is exploratory: the discovery draw 0 and draws 201, 202 (used nowhere else), 228 jobs, about 2 h. All
three blocks use the same removal protocol as the partition panel (linear removal over 0.1 x upr, repair to 1.5 x
upr) and start every removal with the frozen-weight sweep.

## Experiments

| Block | What it does | Where |
|---|---|---|
| Swaps (`V19_swaps`, family SW) | Two lineages from the same f0 and the same insertion state (identical insertion seed; they differ only in the gradient partition): a fixed random 95/5 split and a per-batch redrawn split. Removal from three ages (right after the round-2 insertion, mid round 2, end). Ancestral hybrids: end backbone with the implants from right after the round-2 insertion, and the reverse. Cross hybrids at the end: one lineage receives the other's implants (all, each round's pair, each single branch, each side's pair), both directions. Controls: C1, and C4 (distillation from the expanded model on the same updates). | `dissipation.hybrid` (`make_hybrid`), `wave13.block_swaps` |
| Reassignment (`V19_reassignment`, family RA) | The fixed 95/5 split changed during training: one full exchange early / at round 2 / just before contraction, one fresh redraw at round 2, 10% exchanged every tenth of a round (fresh random pairs each time, so the share still in its original branch decays geometrically), a ramp that moves a cumulative 50% of the smaller side's original examples over round 2 (only unmoved examples are exchanged), and a fresh split every tenth or every half round (between fixed and per-batch redrawn). Pair exchanges keep both branches' example counts exact. Same removal and a C1 per arm. | `growth.spec_reassign`, `wave13.block_reassignment` |
| Recoding (`V19_recode`, family RC) | Chains with 4 x 2-bit pegs (8-bit messages, two middle pearls) from three histories ending in the same architecture: gradual CoP, abrupt calibrated interfaces, compute-matched scratch (adaptive range). Each middle pearl is an exact finite map; its messages are relabelled (bit permutation, the XOR chain, a random invertible GF(2) map, a random codeword permutation) on the outgoing side, the incoming side or both; logistic and MLP replacements (16, 64 hidden) are fitted on the relabelled map and spliced back with the compensating tables, whose size is counted. | `cop.task_kind = recode` (`cop/cop_pegs/recode.py`), `wave13.block_recode` |

Every removal also reports, for each single branch deletion, the training-set damage on the examples that branch
was assigned versus the others (`damage_by_membership`; fixed splits use the split at the END of training). In a
hybrid, swapped-in branches are measured against their DONOR lineage's split; a branch with no stable split
(redrawn lineage) is marked not applicable.

An independent review of this patch found four defects, all fixed with tests: plain removals were labelled as
hybrids in the sweep table; swapped-in branches were measured against the receiver's split; the ramp compounded
fresh random exchanges (moving about 97% instead of the stated share); a job restored after a diverged update
could miss that update's reassignment event when writing the final split.

## Tables (summary/strengthening)

`s19_swaps` (start state, frozen intact, frozen with additions removed, repaired endpoint), `s19_reassignment`
(schedule, frozen states, mean own- vs other-partition deletion damage, repaired endpoint, C1, G), `s19_recode`
(pearl, relabelling, side, class, first update with every reachable message exact or censored, final exactness,
compensation bits, network risk with the spliced replacement). `s15_frozen_weight_sweep` carries the membership
damage and the hybrid labels.

## Checks in the code

* Hybrids refuse graphs that are not structurally identical, unknown slots, and modules shared between the
  swapped implants and the rest; a self-swap is the identity (test).
* The fixed and redrawn lineages have bitwise identical insertion states (test).
* Reassignment events are deterministic in their index and the partition seed; a resumed job replays them and
  matches an uninterrupted run (tests for periodic, periodic redraw and ramp).
* Swapping two branches' parameters together with their masks is a renaming (test); only reassigning examples
  is an intervention.
* Recoding: every relabelling is a bijection; the XOR chain turns a copied bit into a parity; the exact table
  spliced back reproduces the reference network; the network's own codes agree with the enumerated map.

## Not in this round

Order-of-expansion histories with the same final graph, repeated expand / contract cycles, moving computation
between neighbouring pearls, the bagging control (two compact models on the two subsets), and a relabelling
searched to make replacement easier. The pearl-group version of "smallest swappable group" is covered here for
branches only.
