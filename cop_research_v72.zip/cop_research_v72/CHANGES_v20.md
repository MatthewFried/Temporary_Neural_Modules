# v19 -> v20: fixes from the v19 review

Semantics `cop-7.4.0` (new config keys and changed recode jobs; every run id changes). Results go to
`~/cop_results_v20`; run `scripts/20_v20_mechanism_panel.sh`. scripts/19 now refuses to run. The v18
confirmation (scripts/16 from the v18 folder, `~/cop_results_v17/confirmation_full`) is not touched, and no
collected observation is relabelled as confirmation.

Wave 17 is still exploratory (draws 0, 201, 202). It now has 291 jobs (v19: 228). The recode jobs are much
larger than before: 36 jobs, 672 fits each at full scale. The old two-hour estimate does not carry over. Time a
pilot first (commands in the reply / README).

## Fixes that change training or what a job computes (rerun needed)

| Review item | Change | Where |
|---|---|---|
| 1 | Recode validity checks run before any fit: per-example prediction comparison with a declared tolerance (max abs error, normalised error, class disagreement); the enumerated map against the network's codes on train, val and test; Q^-1(h'(P(z))) = h(z) for every input symbol and every P, Q; the exact transformed splice against the reference predictions. A failure raises ScientificInvalid (status `invalid`) with `recode_checks.json` kept, and nothing is fitted. | `cop/cop_pegs/recode.py` |
| 2 | Fit inputs are validated; logits, loss, gradients and parameters are checked at every update; a non-finite value gives status `numerical_failure` (never exact, never censored), with the update and cause. The full-alphabet forward pass is checked too. | `fit_replacement` |
| 3 | Every fit is saved (maps, P/Q forward and inverse, frequencies, architecture, weights, fit seed, optimizer state, step, compiled table, predictions). The job resumes inside a fit and between fits. | `run_recode`, `recode/fits/*.pt` |
| 6 | Fit seed is its own axis, paired across relabellings; the encoding generator depends on the relabelling family and seed only (the symmetric control shares the bit permutation). `bitperm_symmetric`: the same initialised model with permuted input columns and output rows; its loss curve must match identity, else the run is invalid. Two regimes: `observed` (training support, frequency-weighted) and `full_alphabet` (every symbol, uniform). | `recode.py`, `cop.recode_*` |
| 6 | Matched recipes: gradual, abrupt and compute-matched scratch histories each under the fixed and the EMA range (strata `RC|<cell>|d4b2_fixed` and `..._ema`); the recode job reads the parent's final checkpoint, labelled as the training endpoint, not validation-selected. | `wave13.block_recode` |
| 9 | Recode grids are scale-aware (`RECODE_BUDGETS`): smoke runs every relabelling, side and regime with 20 updates; pilot 300; full 1000 with 2 encoding and 2 fit seeds. | `wave13.RECODE_BUDGETS` |
| 5 | Removal policy is explicit: `dissipation.removal_masks` (`released` = v19 behaviour, `retained` = the start checkpoint's split keeps masking gradients), `gate_schedule` (`anneal` = v19, `hold` = gates at 1, then removal), `optimizer_policy` (`reset_each_phase`, recorded). Every gated removal is evaluated at the end of its transition (`end_transition_k`). `retained` is refused for hybrids (one global mask pair cannot express mixed histories) and unsupported for per-batch redrawn splits. | `dissipation.py`, `config.py` |
| 5 | New SW jobs: the gate x mask crossing on the fixed lineage (hold/released, anneal/retained, hold/retained; anneal/released is the existing removal), same transition, repair budget and reset policy; matched compact controls C1_lr0.3, C1_cosine and C7_opt (optimizer reset at the removal's phase boundary) per lineage. | `wave13.block_swaps` |
| 7 | "all" hybrids name the four branch players explicitly, so the parent container is never copied. Each end-state removal first runs a frozen swap scan: all 16 subsets of the four players copied from the other lineage, raw and after an affine interface alignment (least squares on training inputs, folded into the branch's last linear layer, d x d + d values per branch, identity kept if the fit is not better). | `dissipation.swap_scan`, `align_swapped` |
| 7 | Path points also record test risk and the function distance from the receiver; the job records f0's, the receiver's and the donor's val risk and branch ages (job updates since insertion, from the slot's round). | `run_dissipation` |

## Fixes in analysis, checks and tooling only (no rerun needed for these alone)

| Review item | Change | Where |
|---|---|---|
| 1, 3 | `check_results.py --recode` verifies every complete recode job (controls present and passed, a nonempty plan, every planned fit with a record and a saved artifact, declared statuses only); an empty check set fails. Fresh reload rebuilds every fit and compensator in a new process and reports expected / checked / skipped (numerical failure) / failed counts; a missing or altered artifact fails. `recode_table` keeps skipped rows with reasons. | `audit_v8/tools/check_results.py`, `audit_v5/tools/fresh_reload.py`, `v13_tables.recode_table` |
| 4 | Cost accounting reads counters at any checkpoint stage (`post_insert_r2` included; unknown or missing gives `accounting_complete=False`), charges a hybrid's donor lineage, charges each run once at its latest needed stage (self-swap and early/late hybrids dedupe; different descendants share only their baseline), and exports own / source lineage / donor incremental / total. Comparison-only references (C1 budget parents, the swap-scan donor) are not charged. | `continuation.stage_work`, `chain_work_parts`, `strengthening.cost_parts` |
| 8 | Reassignment exports the realised events (pairs moved, denominator, share of the training set), ever-moved vs currently away, branch exposure; "end-assignment" and "initial-assignment" deletion damage; membership at earlier checkpoints replays the schedule to that update; `info_access` states the schedule and that masks act on gradients only; the per-batch redrawn reference (SW block) is joined into the RA table as a shared reference row. | `trajectory.py`, `dissipation.spec_membership`, `v13_tables.reassignment_table`, `wave13.info_access` |
| 7 | `s19_swaps` adds receiver / donor runs, branch ages, policies and repair curves: first evaluated compact update reaching each declared target (f0 val risk x 1.02, receiver val risk x 1.02, function within 0.1 x RMS of the receiver's outputs), test risk there, final success, censoring. New `s20_swap_scan`: one row per subset (raw, aligned, function change, adapter size, native scores). | `v13_tables.swap_table`, `swap_scan_table`, `repair_curve` |
| 9 | Runtime estimator prices recode jobs from their nested fit grid and class widths in a stratum of their own (`cop:recode`). Per-fit seconds, examples and MACs are recorded. | `audit_v5/tools/runtime_v13.py` |
| 10 | New launcher: every step's exit code is recorded (environment, status, manifest copy, packaging); the archive is written to a temporary name, CRC-checked, checked for required members and the verdict, then renamed; an older archive of the same name is deleted first; the external verdict is final and the archive is rewritten with it. A failed test, CUDA-skip check, manifest or validation skips the panel unless `DIAGNOSTIC_OVERRIDE=1`. | `scripts/20_v20_mechanism_panel.sh`, `scripts/package_reports.py`, `tests/test_v20_launcher.py` |
| 11 | LP separability per output bit (HiGHS) for linear fits on the fitted support, with copy, XOR and restricted-XOR controls. | `recode.lp_separable`, `lp_controls` |

## Tests

`tests/test_v20.py` (recode validity and injected failures, numerical guards, LP controls, symmetry trajectory,
resume inside and between fits, fresh reload and tampering, a CUDA recode test, masked vs released branch
gradients, removal policies, renaming through an Adam update with permuted or reset optimizer state, the
16-subset scan and alignment, branch ages, repair-curve targets, the wave-17 structure, recode strata and budgets)
and `tests/test_v20_launcher.py` (injected failures of every stage, prerequisite skip and override, stale
archive, packager verification). Only targeted unit tests ran in the sandbox; no smoke or panel run.

## Not in this round

A pristine all-additions-at-insertion reference graph (branch ages are recorded instead); masks per physical
branch for hybrids (refused); a learned-module splice for recoding (the splice stays a labelled functional
emulator, no deployment or inference-cost claims); performance matching between recode histories (reported as an
association with source risk and support beside it).
