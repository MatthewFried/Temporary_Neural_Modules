# v20 -> v21: recode fits in float64

Semantics `cop-7.4.1` (run ids change). Results go to `~/cop_results_v21`; run `scripts/21_v21_mechanism_panel.sh`.
scripts/20 now refuses to run.

## What happened in the v20 panel

255 of 291 jobs completed and reloaded bitwise. All 36 recode jobs were marked invalid by the symmetry control
("the permuted fit did not follow the identity fit"). Their validity checks before fitting passed.

The cause was float32 rounding. A bit permutation changes the order of the sums inside the replacement, which
changes results at the 1e-7 level. Adam amplifies that over 1000 full-batch updates: on a 120-symbol, 8-bit
map, the permuted and unpermuted MLP loss curves drifted apart by about 1e-3 relative to the initial loss, and
the first exact update moved from 500 to 525. The tolerance was 1e-4, so the control failed. It was a
numerical-precision failure, not a broken permutation.

## Fix (training-changing, recode jobs only)

* Replacement fits run in float64 (inputs, targets, weights, model, compiled table, reload). On the same probe
  the drift is at most about 2e-15 for the linear model and both MLPs, and the first exact update agrees.
* The symmetry tolerance is tightened from 1e-4 to 1e-6, more than eight orders of magnitude above the float64
  drift.
* Saved fits record their dtype; the fresh reload rebuilds the replacement in that dtype.
* Regression test: a 1000-update MLP64 fit and its permuted twin agree to 1e-10 and reach exactness at the same
  update. The deliberately unstable fit in the numerical-guard test now uses a step that overflows float64.

## Other

* The launcher tests no longer inherit `DIAGNOSTIC_OVERRIDE` or `COP_PYTEST` from the calling shell (in v20 they
  failed when the panel was launched with the override).
* The non-recode jobs did not change, but every run id changes with the code version, so the whole panel
  reruns (about 2 h on the A4500 in v20).
