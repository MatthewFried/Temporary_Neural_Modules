# v21 -> v22: the next experiments (wave 18) and the review's analysis points

Semantics `cop-7.5.0`. Results go to `~/cop_results_v22`; run `scripts/22_v22_panel.sh` (wave 18 only, 216 jobs,
exploratory). The v21 wave-17 run keeps running from its own folder; this version does not touch it.

## Wave 18 (draws 0, 201, 202 and fresh draws 203, 204, 205)

Same shortcut cell (rho 0.95, MLP 64, 2 rounds of U = 2000 updates), same removal protocol as the swap and
reassignment blocks (linear removal over 0.1 U, repair to 1.5 U), now with dense early repair evaluation at 1, 2,
4, ..., 256 updates after the removal (val and test risk at each point).

**Persistence with equal exposure (family PE).** New partition `cyclic_blocks`: every training example spends
95 % of the updates with its gradient on branch a and 5 % on branch b, in cycles of period T, with phases spread
uniformly over the examples. So every example has the same exposure, at every update 95 % of the training set is on branch a, and only the
length of each stay changes. Periods: 4000 (one cycle over the whole run), 2000, 500, 100 and 20 (19 + 1 updates,
the shortest cycle that holds the share). References on the same draws: the fixed split, the per-batch redrawn
split and the 10 % periodic exchange (the v20 lead, now on three fresh draws). One C1 per draw.

**Where the benefit lives (family BB).** Start states rebuilt from parts, all with the same removal:
- `f0_backbone_fresh_implants`: the untouched f0 backbone with every addition at its insertion state. This is the
  same final graph, still function-preserving, with no intervening training; the job checks that it computes f0.
  Once per draw (identical for both lineages).
- `f0_backbone_trained_branches`: the untouched f0 backbone with the fixed (or redrawn) lineage's trained branches.
- `trained_backbone_fresh_branches`: the lineage's trained backbone with every branch reset to its insertion state.
The plain removal of the same trajectory (family PE) is the reference row.

**Controls and comparator (family PE, per draw).**
- `C2`: compact continuation with the same training MACs as the fixed-split treatment (trajectory + removal).
  The fixed treatment used about 35 % more MACs than C1 in v20, so C1 alone does not control cost.
- `ETD_from_f0` and `ETD_scratch`: example-tied dropout (Maini et al., ICML 2023), the closest prior method
  (fixed per-example neuron assignments, memorization neurons dropped at test time). In every hidden layer of the
  compact MLP, 40 % of the units are always active and each example gets its own fixed 20 % of the remaining
  pool; at test time only the always-active units are kept (the paper's rule, no rescaling). From f0 it trains
  for the treated trajectory's 2U updates; from scratch for f0's updates plus 2U. Then the memorization neurons
  are dropped (their outgoing weights zeroed, checked to reproduce the test-time function; the native endpoint
  is evaluated and saved) and the plain network gets the same repair budget as the removal (R updates, fresh
  optimizer). Selection never picks a masked state.
- The fixed / redrawn contrast at two more partition draws (`seeds.partition` 1 and 2) on every data draw, with
  C1 under the same replication key: 60 more jobs.

**Measurements added to every job.**
- Realised per-example exposure: how often each training example was in a batch and how often its gradient reached
  branch a or b under the actual sampler (`spec_exposure_per_example` in the trajectory result, arrays in
  `spec_exposure_per_example.pt`).
- Function agreement beyond output RMS at every removal-path point: decision disagreement with the receiver,
  total-variation distance of the class probabilities, KL(receiver || model). Repair curves add decision and
  probability imitation targets (at most 5 % flips, mean TV at most 0.05).
- Endpoint tables keep IID test, rare group, shifted set and the counterfactual shortcut / causal sets
  separate, final and validation-selected.
- Recode fits record the smallest |logit| on their support and on the full alphabet, and the replacement and
  reference dtypes and the device. `audit_v5/tools/recode_audit.py` reads a results folder (v21 included) and
  reports coverage, the worst symmetry discrepancies with their cases (by regime, side and class), and the
  smallest decision margins recomputed from the saved replacements.

## Code

| Change | Where |
|---|---|
| `growth.spec_partition = cyclic_blocks`, `growth.spec_block_period`; phases saved as `spec_phase.pt`; exact per-example exposure exported (`spec_cyclic`); end-assignment membership for the frozen sweep; retained removal masks refused (no stable membership) | `trajectory.py` (`cyclic_membership`, `cyclic_phases`, `cyclic_a_len`), `dissipation.spec_membership`, `config.py` |
| `dissipation.rebuild` {backbone: receiver / f0, implants: receiver / fresh}, applied to the start state before any hybrid copy; implant states from the earliest `post_insert_r<k>` checkpoint; f0 + fresh must reproduce f0 (else invalid); a pristine state is charged no trained model | `dissipation.rebuild_state`, `continuation._consumed`, `chain_work_parts` |
| `dissipation.early_eval`: extra evaluation points early in every repair phase | `run_dissipation.train` |
| `continue.arm = example_tied_dropout` (`etd_p_gen`, `etd_p_mem`; two segments: dropout phase, repair); masks through the graph's value patch (per-example in training batches, generalization-only otherwise) | `continuation._ExampleTiedDropout`, `config.py` |
| Table `s22_etd` (native test-time errors right after the dropout phase, repaired endpoint, the draw's fixed-split removal and C1) | `v13_tables.etd_table` |
| Tables `s22_persistence` (schedule, realised exposure, frozen damage, repaired endpoint, repair curve, early points, C1, G) and `s22_backbone` (rebuilt state beside the plain removal of the same trajectory) | `v13_tables.persistence_table`, `backbone_table`, `early_repair` |

## From the review of v20 (analysis and checks)

- **Disjoint players.** The dependence game now also reports the game over disjoint players only: atoms that are no
  other atom's ancestor (the four branches, not their group container). Columns `disjoint_*` in
  `s_dependence_game`. The hierarchical game's pair interactions include parent / child pairs, whose
  "interaction" is an artefact of deleting a parent with its children.
- **Recode symmetry at the parameter level.** Beyond the loss curves, the symmetric fit's final weights must equal
  the identity fit's weights with the same permutation applied (relative difference within the tolerance), and
  the first exact update is compared. A test injects a wrong permutation and checks that the job is invalid.
- **Counting the alignment.** Each aligned swap records the adapters' parameters, fit seconds, training examples
  and normal-equation MACs; each scan records the backbone's and each branch's parameter count, so the adapters can
  be set against the computation they stand in for.

## Tests

`tests/test_v22.py` (cyclic exposure and split, config, exposure export and resume, cyclic membership and refused
masks, pristine rebuild = f0 with zero lineage cost and dense early points, the other two rebuilds, disjoint game,
the summary tables, wave-18 structure, wrong permutation -> invalid, symmetric fits with permuted parameters,
example-tied dropout masks / drop / job / resume, realised exposure and decision imitation, the wave-18 controls)
and `tests/test_v22_launcher.py`. The tests for the additions after the first draft (comparator, C2, seeds,
realised exposure, imitation, recode margins and audit) were written but not run here.
