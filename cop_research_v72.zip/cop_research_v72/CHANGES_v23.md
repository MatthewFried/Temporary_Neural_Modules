# v22 -> v23: fixes from the static review of v22

Semantics `cop-7.6.0`. Results go to `~/cop_results_v23`; run `scripts/23_v23_panel.sh` (wave 18, 240 jobs,
exploratory). scripts/22 now refuses to run. v21 and its results are untouched. Nothing here was run in the
sandbox: the code was read, manifests were generated and validated, modules import, and the new tests are
written for you to run (`tests/test_v23.py`, `tests/test_v23_launcher.py`).

## Change to estimand

| Item | Before (v22 draft) | Now | Kind |
|---|---|---|---|
| A. Matched exposure | Cyclic assignment on the trainer's global clock: equal nominal time per example, but realised exposure depended on when the sampler drew each example, and the second-round branches saw only part of a cycle | `matched_quota`: the round's minibatch stream is replayed in advance; every example gets the same integer number of branch-a and branch-b appearances per growth round in every arm of a family (q = floor(f x n + 1/2) of its n appearances); only the order differs (b-appearances in one run, runs of 8, alternating). Families 95/5 and 50/50 (at 95/5 an example has about 3 b-appearances per round, so only one-run vs alternating exists). Every batch is checked against the replayed stream (mismatch = invalid). The cyclic arms are dropped from the panel (code kept) | training |
| A. Exposure records | Pooled over the run | Per example, per growth round and per physical branch (born at its round, lives to the end), named mask eligibility (a zero gradient still counts); stream and quota hashes per round; the table flags whether every arm of a family on a draw had the same stream and quotas | training (records) |
| B. ETD selection | Candidates over the whole job, masked ones skipped: 4 (from f0) and 3 (scratch) instead of 8 | 8 candidates inside the repair phase (offsets 375 ... 3000), none in the masked phase; the table compares selected endpoints only when the candidate counts are equal | training (selection) |
| C. ETD scratch cost | f0's training added again | A re-initialised continuation consumes no trained f0 (`consumes_trained_f0`, no baseline or f0-selection cost); from-f0 ETD still pays f0 once; the dropout phase's own updates and MACs are recorded | analysis |
| D. ETD semantics | Native and repaired outcomes not separated; no dense repair path | Native endpoint (generalization neurons only) recorded as `endpoint_etd_native` with predictions; repair described as drop and regrow (zeroed columns can regrow); dense observations at 0, 1, 2, ..., 256 updates after the drop with agreement to the native model at the drop; phase budgets reported (ETD: dropout phase, no transition, 3000 repair; removal: 200 transition, 2800 repair) | training (records) |
| E. Test split | Called IID | Labelled: test = shortcut independent of the label (train / val: agrees with probability rho_train), shift = reversed, rare = rare group; counterfactual columns exported for native, final and selected outcomes | analysis |
| F. Recode symmetry | Unavailable pairs skipped; discrete outcomes recorded only | Every expected pair is checked, failed, inconclusive (discrete difference with a margin below 1e-6) or unavailable; unavailable pairs fail the result checker; the parameter comparison is described as a consequence, not a proof; gradient and Adam-moment covariance tested directly (with a resumed optimizer) | training (checks) |
| F. Recode audit | Weak coverage, optional manifest | Manifest required; plan, records and artifacts compared as sets with matching keys; pre-fit, transformed-identity and LP failures are problems; empty or unavailable symmetry sets are problems; margins recomputed on CPU and labelled; corrupt artifacts are per-fit problems | analysis |
| G. Fresh reload | Only endpoint.json | Also endpoint_best_val.json and endpoint_etd_native.json, with expected / checked / excluded / failed counts per kind | analysis |
| H. Pristine certificate | Output comparison at 1e-4 | Structural certificate: every branch term comes from an exactly zero output layer, containers hold only parameter-free sum merges (else unsupported), backbone tensors equal f0's; float64 outputs agree on train / val / test to 1e-12 relative. Imitation references named: f0, trained receiver (before the rebuild), job start | training (check) |
| I. Aligner cost | Solve MACs only; note called the adapter extra computation | Forward passes counted; the map is folded into the branch's last layer, so fitting work, fitting capacity and inference cost are reported separately | analysis |
| I. Launcher | Environment step not a prerequisite; inherited COP_HOME | The environment step must pass before training; COP_HOME is set to the release's own folder | tooling |
| I. Draws | | Tables carry data draw, draw set (discovery 0/201/202 vs fresh 203/204/205), partition seed (within-draw replication) and optimizer seed (all 0: no optimizer-seed robustness here) | analysis |

## Not changed

Example-tied dropout keeps p_gen 0.4 and p_mem 0.2 as a disclosed MLP adaptation (DEVIATIONS 168); the author
code was not checked against a pinned commit. No permanent-deletion control for ETD: the repair is described as
drop and regrow. The removal jobs and ETD do not share the repair minibatch stream.
