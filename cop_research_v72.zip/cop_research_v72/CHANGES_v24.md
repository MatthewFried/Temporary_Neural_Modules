# v23 -> v24: one fix

The v23 test run on the lab machine failed 3 tests (534 passed), so the launcher correctly skipped the panel.
All three came from the pristine-rebuild certificate: the specialised group container holds a parameter-free
pass-through node ('identity') next to its sum merge, and the certificate accepted only 'add'. It now accepts
'add' and 'identity' (both parameter-free; anything else is still refused). Without this, every
f0_backbone_fresh_implants job in wave 18 would have been unsupported.

Semantics `cop-7.6.1`. Results go to `~/cop_results_v24`; run `scripts/24_v24_panel.sh`. Everything else is as in
CHANGES_v23.md. The three failing tests were rerun here and pass.
