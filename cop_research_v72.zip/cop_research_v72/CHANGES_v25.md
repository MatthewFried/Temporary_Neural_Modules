# v24 -> v25: follow-ups to the v24 panel and two fixes

Semantics `cop-7.7.0` (new config keys, new outputs, every run id changes). Results go to `~/cop_results_v25`;
run `scripts/25_v25_panel.sh` (scripts/24 now refuses to run). The v18 confirmation and every earlier results
folder are untouched; the only step that reads an older folder is the v21 recode re-scoring, which writes into
the v25 reports. No collected observation is relabelled as confirmation: wave 19 is exploratory.

The primary hypothesis from v24: a persistent example-to-branch assignment leaves a benefit in the backbone that
repair recovers, while making the current computation depend on the branches. Wave 19 tests it under the
controls that v24 lacked.

## Fixes that change training or what a job computes (rerun needed)

| Change | Where |
|---|---|
| Recode exactness is decided by an integer count of wrong support messages (curve records `n_wrong`, `n_support`). v21-v24 compared a floating mean with 1.0; 36 v21 fits whose final evaluation read 0.9999999999999999 were recorded as censored. The map-vs-codes validity check now also uses integer mismatch counts. | `cop_pegs/recode.py` (`curve_exact`, `fit_replacement`, `run_recode`) |
| Recode records downstream-output preservation beside message exactness: decision agreement (and mismatch count) and output RMS difference of the spliced network against the reference network, per partition. | `run_recode` |
| `growth.spec_mask_route`: `gradient` (all earlier versions) or `forward` (a branch's output is zero in training for the examples not assigned to it, which masks its gradient too: the forward-masked comparator in the style of memorization sinks / example-tied dropout). Evaluation never applies masks. | `config.py`, `graph/ops.py`, `trajectory.spec_masks` |
| `dissipation.repair_scope`: `full`, `readout` (last parametric layer) or `top2` (last two) learn in the post-removal repair; the transition phase always trains everything. Needs a single-phase removal. Recorded with the trainable / compact parameter counts. | `dissipation.scope_pkeys`, `run_dissipation` |
| `continue.segment_reset`: one boolean per segment (fresh optimizer state at its start or carried). Used by C1_phase, the compact control in the treated history's phases. | `continuation.py` |
| Sink profile in every removal job (frozen, before repair): per-example training loss and error, intact and after the joint and each single deletion, by stratum (all; each stable split's own examples; rare group; shortcut-conflicting examples; noisy labels; f0's hardest quarter), with f0's own numbers per stratum. | `dissipation.sink_profile` |

## Analysis, checks and tooling only (no rerun needed for these alone)

| Change | Where |
|---|---|
| Fresh reload runs every run on the device its last complete attempt used, and every recode fit on the device in its own record (`--device recorded`, the default). An unavailable recorded CUDA device is a failure with that reason. This removes the v21 reload failures that were only CPU vs GPU recomputation (10 436 on GPU, 1 660 on CPU, matching the fits trained on the other device). | `audit_v5/tools/fresh_reload.py`, `recode.reload_recode` |
| `recode_integer_status.py`: re-scores saved fits of any version from their curves with integer exactness (no semantic-hash filter; it re-scores, it does not pool), writes per-fit status and exact rates recorded vs integer. The launcher runs it on `~/cop_results_v21/mechanism17` if present. | `audit_v5/tools/recode_integer_status.py` |
| `s19_recode` gains `status_integer`, `status_corrected`, `first_exact_update_integer`, `sustained_exact_from_integer`, `final_exact_integer`; the recode audit lists status corrections. | `v13_tables.integer_exactness`, `recode_audit.py` |
| New tables: `s25_panel` (one row per wave-19 removal or control: factors, frozen dependence, repaired endpoint, early repair path, the draw's C1 / C1_phase / ETD / fixed references and gains), `s25_sink_profile` (one row per job, condition and stratum), `s25_dependence_benefit` (Pearson r of frozen deletion damage vs repaired error across arms within a replication, within an arm across partition seeds of one draw, and within an arm overall; on s22_persistence and s25_panel). | `v13_tables.py` |
| `fetch_data.py covertype ROOT`: the second task's download runs once before the panel. | `audit_v5/tools/fetch_data.py` |

## Wave 19 (330 jobs at full scale)

| Block | Content |
|---|---|
| V25_core | shortcut cell, draws 0, 201, 202, 203, 204, 205: fixed, redrawn, q50 one run, q50 alternating, fixed_forward, redrawn_forward; C1, C1_phase, ETD_from_f0 |
| V25_scope | from the core fixed and redrawn end states and from f0 (pristine rebuild): immediate deletion then 1.5 U of repair with scope readout / top2 / full; the fresh-branch transition (trained backbone, branches reset, linear removal) |
| V25_optseed | draws 0, 203, 204 at optimizer / initialisation seed 1 (f0 retrained): fixed, redrawn, q50 one run / alternating, C1, C1_phase, fresh-branch transition |
| V25_noise | label noise 0.1 and 0.3, draws 0, 201, 203: fixed, redrawn, fixed_forward, C1, ETD_from_f0 |
| V25_width | branch width 8 and 128 (default 32), draws 0, 203, 204: fixed, redrawn |
| V25_task2 | covertype, n_train 4096, MLP-64, draws 0, 201, 203, fixed / redrawn at a 95 / 5 split: the core arms without redrawn_forward, C1, C1_phase, ETD_from_f0, fresh-branch transition, f0 backbone with trained branches, scope readout / full |

C1_phase segments are (U, U, 0.1 U, 1.4 U) with the optimizer carried at the two growth rounds (as the trajectory
carries it) and reset at the transition and the repair (as the removal resets it); same total updates as C1.
Abrupt removals get the whole 1.5 U as repair, so every removal has the same updates after the trajectory.

## Not in this round

Later-query preservation of recoded replacements (the third measure in the recode follow-up): it needs the
later-query decoders run through the spliced emulator, which is not a GraphNet; v25 adds message exactness and
downstream-output preservation side by side. Image-scale replication (CIFAR / an LM) is a separate track.

## Tests

`tests/test_v25.py` (forward route op, masks and trajectory record; repair scope changes only the scope's tensors;
scope order; sink profile strata with and without a stable split; segment_reset equivalences with opt_reset and
a single segment; integer exactness and re-scoring; the dependence table; wave-19 structure) and
`tests/test_v25_launcher.py` (the v24 launcher tests moved to scripts/25, plus the data step as a
prerequisite). Nothing was run here except compiling the changed files and generating and validating the wave-19
manifest (330 jobs, 0 validation errors).
