# v25 -> v26: three follow-up blocks added before the v25 panel ran

Semantics `cop-7.8.0` (every run id changes). Results go to `~/cop_results_v26`; run `scripts/26_v26_panel.sh`
(scripts/25 now refuses to run). Wave 20 holds every v25 block unchanged in design (CHANGES_v25.md) plus the
blocks below: 504 jobs at full scale. Exploratory, like wave 19. Earlier results folders are untouched.

## Changes to training or to what a job computes

| Change | Where |
|---|---|
| `growth.spec_mask_route = parameter`: only the specialised branch's parameters receive gradient from the examples not assigned to it; the gradient with respect to the branch's input still flows for every example, so every example's gradient reaches the upstream backbone through both branches. The v13-v25 gradient route (`gradient`) masks the gradient at the branch output, which also blocks that upstream path for unassigned examples. Implemented in the linear op (two products, one with detached parameters); a specialised branch with any other parametric op is refused. | `graph/ops.py` (`_param_route_mask`, `_f_linear`, `_f_mask_grad`), `trajectory.py`, `config.py` |
| `dissipation.repair_subset = n`: the post-removal repair phases sample a fixed random subset of n training examples (seeded by the job's repair seed, so arms of one draw share it) for the same number of updates; recorded with its index hash and rare-group count. | `dissipation.py` |
| Removal jobs accept training overrides (here: `train.warmup`, a linear LR warmup at the start of every removal phase, each of which starts with a fresh optimizer). | `wave13.W13.dissipation` |

## Wave 20 additions

| Block | Content |
|---|---|
| V26_route (6 draws) | the parameter route for fixed, redrawn, q50 one run, q50 alternating; the forward route for the two q50 arms; an unmasked expansion (every example in both branches) |
| V26_contraction (6 draws) | from the V25_core fixed, redrawn and q50 one-run end states: the linear removal and repair trained to imitate the frozen expanded model (`target = expanded`); stochastic bypass during the transition (keep 0.5, unscaled); the plain linear removal with an LR warmup of U / 20 updates at each removal phase |
| V26_repair_data (draws 0, 203, 204) | immediate deletion, then 1.5 U of repair from 256 or 1024 of the 4096 training examples, readout-only or full, from the fixed and redrawn end states and from f0 |

What each block asks: whether the persistence effect needs the masked upstream gradient (V26_route); whether
contraction helps by transferring the expanded solution or by letting the model leave it, and whether the error
spike at the first repair update (24.3 % -> 33.1 % in v24) is the fresh optimizer (V26_contraction); whether the
retained benefit is accessible with little repair data (V26_repair_data).

## Analysis

`s25_panel` gains removal target, warmup, bypass keep, repair subset and the subset's rare-group count;
`s25_dependence_benefit` uses plain removals only (task target, no warmup, full data).

## Tests

`tests/test_v26.py` (parameter route: same forward value, weight gradients from assigned rows only, input gradients
for every row; trajectory record; repair subset recorded, changes the repair and is the only data the repair
samples; wave-20 structure) and `tests/test_v26_launcher.py` (the launcher tests on scripts/26). Not run here; the
changed files compile and the wave-20 manifest generates and validates (504 jobs, 0 errors).
