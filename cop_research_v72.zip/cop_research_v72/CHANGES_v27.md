# v26 -> v27: selective reversal without retraining (analysis only)

No change to the cop package: semantics stay `cop-7.8.0` and the semantic code hash is unchanged, so the panel is
the v26 one (`scripts/26_v26_panel.sh`, results `~/cop_results_v26`); a v26 run already started can be resumed
from this folder.

`audit_v5/tools/selective_reversal.py RESULTS OUT_PREFIX`: for every plain removal (wave 18 family PE, waves
19 / 20 family X25) and every C1 control, the additions are deleted and each backbone layer is set to
(1 - a) x its value + a x its f0 value, a in {0, 1} for every subset of layers and in {0, 0.5, 1} for every
combination (k <= 5 layers), with NO training or head fitting; validation and test error are recorded for three
states (the trajectory's end, deleted at once; the end of the gate anneal; the repaired endpoint) and for C1. A
rule is chosen on the discovery draws' validation error and evaluated on the fresh draws' test error, beside f0.
Works on the v24 results as they are. The v26 launcher runs it as step reversal20.

Test: `tests/test_v26.py::test_selective_reversal_full_reversal_is_f0_and_no_reversal_is_the_deleted_state`.

## v28 (analysis only, same semantics)

The reversal rules are chosen on `val_indep` (the shortcut-independent validation environment) when the data
has it: the plain validation split follows the training shortcut correlation (about 4.7 % error vs about 20 % on
the shortcut-independent test split), so selecting on it picked the f0 combination almost everywhere in the v24
run. Rows record the selection partition and its error.
