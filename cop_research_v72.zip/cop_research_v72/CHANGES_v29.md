# v28 -> v29: the first-layer transplant lead from the v24 reversal analysis (superseded by v30 before it ran)

Semantics `cop-7.9.0`. The new panel is wave 21 (`scripts/29_v29_panel.sh`, results `~/cop_results_v29`, 108 jobs).
The v26 panel keeps running from the v28 folder (scripts/26 refuses to run here: different code). Nothing earlier
is touched.

The lead (v24 tables, exploratory): after the fixed-assignment removal and repair, putting ONLY the repaired first
layer into an otherwise untouched f0 gives 19.98 % shortcut-independent test error vs f0's 22.65 % (17 of 18 runs,
all 6 draws); the full repaired model gets 19.28 %. The same transplant from C1 gives 22.42 %, from the redrawn
history 22.38 %. Restoring the first layer to f0 inside the repaired model removes the gain (22.79 %). Most of
the transplantable change appears during repair (22.35 % from the expanded model, 22.10 % after the transition).
The code `0-1-1-1-1` was found by looking at those tables, so it is now fixed and replicated on new draws.

## Changes to training or to what a job computes

| Change | Where |
|---|---|
| `dissipation.repair_scope = first`: only the first parametric layer learns in the repair. | `config.py`, `dissipation.scope_pkeys` |
| `continue.trainable_scope = first`: a compact control in which only f0's first layer learns (C1_first). | `config.py`, `continuation.py` |

## Wave 21

Data draws 301-306 (never used before) at optimizer seed 0 and 301-303 at seed 1. Per draw: fixed and redrawn
trajectories with the plain linear removal and with a first-layer-only repair; C1, C2 (same compute), C1_phase,
C1_first; expanded_continue (the fixed expanded end state trained on for the removal's 1.5 U updates with its
branches, no masks, fresh optimizer: elapsed training without removal).

What reads it: `selective_reversal.py --trace` (run by the launcher) puts each state's first layer into f0
(`0-1-1-1-1`), and reports the full state (`0-0-0-0-0`) and the reverse transplant (`1-0-0-0-0`).
- replication: fixed repaired `0-1-1-1-1` vs f0 and vs the same transplant from C1, C2, C1_phase, redrawn
- does the rest of the network need to move: fixed `linear_repair_first` vs plain repair, and vs C1_first
- removal vs elapsed training: the transplant from expanded_continue vs from the repaired removal
- when it appears: the trace over every saved checkpoint of the history

## Analysis only

`selective_reversal.py` rewritten: control sources C1, C2, C1_phase, C1_first, expanded_continue (copies that
differ only by a partition seed are skipped: controls have no partition); removals with a restricted repair scope
(repaired state); `--codes` (declared combinations, evaluated also on cf_shortcut, cf_causal, shift and rare, and
summarised at the DRAW level with draws beating f0); `--trace` (the declared codes at every saved checkpoint of
each removal's history, with the first layer's input-column norms for the shortcut, causal and noise features);
rules list validation ties and report per-run choices separately for discovery and fresh runs; skipped jobs are
written with their reason. It still runs on v24 / v26 results.

## Tests

`tests/test_v29.py` (first-layer repair and C1_first change only the first layer; the expanded continuation keeps
its branches; wave-21 structure; the tool's declared codes, full restoration = f0, and trace) and
`tests/test_v29_launcher.py`. Not run here; compiled, and waves 19 / 20 / 21 generate (330 / 504 / 108 jobs) and
wave 21 validates.
