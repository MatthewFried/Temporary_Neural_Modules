# v29 -> v30: wave 21 extended around the first-layer transplant lead (v29 never ran)

Semantics `cop-7.10.0`. Run `scripts/30_v30_panel.sh`; results `~/cop_results_v30` (264 jobs). scripts/29 refuses
to run. The v26 panel keeps running from the v28 folder.

## What the v24 lead is, stated carefully

After the fixed-assignment removal and repair, putting the repaired first layer into an otherwise untouched f0
recovers most of the measured improvement (19.98 % vs f0 22.65 %, shortcut-independent test error; the full
repaired model 19.28 %). That shows the transplanted layer is sufficient for most of the gain in f0's surroundings;
it does not show the gain is stored only there, and restoring that layer inside the repaired model can fail for
reasons of incompatibility with the other trained layers. The repaired first layer keeps much of its benefit
with f0's downstream layers; that is not independence under every replacement. First-layer weight norms are
descriptive only; the explanation has to come from functional interventions.

## Changes to training or to what a job computes

| Change | Where |
|---|---|
| `dissipation.method = keep`: the expanded model trains on for `post_updates` with its additions (masks released, fresh optimizer, the removal jobs' minibatch stream); `keep_frozen_implants` freezes the additions' parameters. The export keeps the additions (not an f0-architecture endpoint). | `dissipation.py`, `config.py` |
| `dissipation.restore_before_repair = all_but_first`: at the start of the repair, every backbone layer except the first is reset to f0 (with `repair_scope = first`: can the first layer acquire the benefit directly in f0's surroundings?). | `dissipation.py`, `config.py` |
| Shortcut data: `rule = product` (y = 1[(u . c)(v . c) > 0], nonlinear in the causal variables; counterfactual partitions use the same rule) and `input_rotation = k` (every partition's input multiplied by one fixed orthogonal matrix; the matrix is in the bundle metadata). Defaults reproduce the earlier data exactly. | `data/synthetic.py` |
| Sink profile: no shortcut-sign strata for rotated inputs. | `dissipation.sink_profile` |

## Wave 21 (264 jobs; data draws 301-306, never used)

| Block | Content |
|---|---|
| V30_replication | fixed / redrawn with the plain linear removal, C1, C2, C1_phase; every draw at optimizer seeds 0 and 1 (balanced) |
| V30_forks | from the same trajectory end state (fixed and redrawn, seed 0): abrupt removal, keep, keep_frozen, each 1.5 U with the same stream and a fresh optimizer; the linear removal is the replication arm |
| V30_restricted | linear removal with only the first layer learning in the repair, the other layers at their post-expansion values (`linear_repair_first`) or reset to f0 (`linear_repair_first_restored`); C1_first |
| V30_cut | insertion cut early and late (the core uses the middle), fixed and redrawn |
| V30_boundary | draws 301-303: rotated inputs, the product rule, no shortcut (rho_train 0.5); fixed, redrawn, C1 |

C1_phase, precisely: f0 continued with its trainer state for segments (U, U, 0.1 U, 1.4 U), constant learning rate
throughout (as in the trajectory and the removal), the optimizer state carried across the first boundary (as the
trajectory carries it for the backbone; the trajectory's new branch parameters start fresh, which has no compact
counterpart) and reset at the second and third (as the removal resets at its transition and its repair).

## Analysis (audit_v5/tools/selective_reversal.py)

- Sources: plain linear removals (abrupt / after transition / repaired states), abrupt removals, keep and
  keep_frozen (state kept_end, additions deleted for the evaluation), first-layer repairs with or without the
  restore, and the controls C1, C2, C1_phase, C1_first, expanded_continue.
- `--codes auto` (default): the state itself, f0, every single layer kept, every neighbouring pair kept, and the
  first layer restored; fixed in advance, never selected on the evaluated draws.
- `--decompose`: the first layer's update W - W0 split into the generator's shortcut, causal and noise input
  columns (in the generator's coordinates, W Q^T, for rotated inputs) and the bias; all 16 subsets added to f0's
  first layer with every other layer at f0.
- Functional measures beside every error: cf_shortcut, cf_causal, shift, rare, val_indep, val, test, and the
  shortcut flip rate (share of cf_base examples whose decision changes when only the shortcut is flipped; the
  generator's paired intervention). Weight norms are kept in the trace as descriptive numbers only.
- Draw-level summaries (`_codes.csv`, `_decomposition_summary.csv`) and one row per draw and optimizer seed
  (`_codes_by_draw.csv`, `_decomposition_by_draw.csv`), paired with f0 in that draw.
- Trace rows carry the checkpoint file, phase (trajectory round, end, transition, repair, kept) and cumulative job
  update; a missing checkpoint is reported in `_skipped.csv`, never substituted.
- `_checks.csv`: restoring every layer must reproduce f0's test predictions bitwise (the tool exits 1 otherwise);
  the unreversed exported endpoint is compared with the job's saved endpoint predictions (max difference and
  decision agreement). Evaluation is in eval mode and nothing is trained.

## Not in this round

A serial-implant topology beside the branched one at matched parameters and compute (needs its own design), and
moving the restore time through the repair.

## Tests

`tests/test_v30.py` (first-layer repair with and without the restore, C1_first, keep and keep_frozen, the expanded
continuation, the boundary data, wave-21 structure, the tool's codes / trace / checks / decomposition) and
`tests/test_v30_launcher.py`. Not run here; compiled, and wave 21 generates and validates (264 jobs, 0 errors).
