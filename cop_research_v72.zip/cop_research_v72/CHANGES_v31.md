# v30 -> v31: fixes from the static review of v30 (v30 never ran)

Semantics `cop-7.11.0`. Run `scripts/31_v31_panel.sh`; results `~/cop_results_v31`; wave 21 now has 306 jobs.
scripts/30 refuses to run. Nothing earlier is touched; the v26 panel keeps running from the v28 folder.

## Changes to training or to what a job computes (new runs)

| Review item | Change | Where |
|---|---|---|
| 2 | `dissipation.split_updates`: methods keep and abrupt split their single training phase at the linear removal's transition length, with a fresh optimizer at the boundary and the minibatch stream continuing. New arms `abrupt_pm`, `keep_pm`, `keep_frozen_pm` (block V31_forks_phase_matched); the v30 arms stay as they were (different combined interventions). | `dissipation.py`, `wave13.py` |
| 2 | Schedule audit in every removal job: the parent checkpoint's state hash, the ordered training-example-id stream as a hash chain (in the trainer state, resume-safe), and per phase its start update, actual updates, optimizer handling, learning rate / schedule / warmup, trainable parameters, gate values and the stream hash at its end. | `dissipation.py` (`schedule_audit`) |
| 7 | Event ledger with checkpoints: physical deletion (`event_deleted_<k>`), the restoration before and after (`event_restore_before` / `_after`, the same update, distinct events), optimizer resets. | `dissipation.py` |
| 7 | `continue.save_eval_checkpoints`: C1_phase saves checkpoints at the treated history's boundaries (U, 2U, 2U + g) and at the removal's dense repair offsets, so the control can be traced at the same points. | `continuation.py`, `wave13.py` |
| 9 | `C1_first_window`: f0 with only its first layer learning for the restricted repair's own window (R - g updates), beside C1_first (C1's whole budget). | `wave13.py` |
| 4 | Every v31 design carries a role: `confirmation` (V30_replication) or `exploratory` (the rest). | `config.py` (design.role), `wave13.py` |

## Analysis and reporting (reanalysis only)

| Review item | Change | Where |
|---|---|---|
| 1 | The transplant analysis is manifest-driven (`--manifest`, `--strict`): expected jobs from the manifest; each job's rows are committed only when all of its required analyses pass (status, valid endpoint, data provenance against the job's logged split hashes, every state, every code, all 16 decomposition subsets, every inventoried trace checkpoint); failures go to `_coverage.json` and their rows to `_diagnostic_partial.csv`; every output is written atomically and always replaced; strict exits 1 on any failure or missing contrast partner. Duplicate controls are excluded only when the scientific config (without the partition seed) and the endpoint predictions are identical. Declared codes are validated. | `audit_v5/tools/selective_reversal.py` |
| 3 | Audits on the same function: the unedited endpoint checkpoint against its saved predictions (bitwise on the recorded device type, else 1e-4 relative and identical decisions; a missing or mis-shaped reference fails); compaction by branch deletion, or for a gated graph gates at 0 then export with a function check (otherwise a failure, no silent fallback); the zero code leaves the compact state bitwise unchanged; full restoration reproduces f0 bitwise. Rows carry `function` = native / branch_deleted / layer_transplant. | same |
| 4 | Aggregation: partition seeds within (draw, optimizer setting), settings within each data draw, then a summary over unique data draws (`n_unique_data_draws`, settings per draw, mean gain with a draw-level t interval, draws beating f0); contrasts against C1's same code paired on draw and setting, with missing partners flagged. One shared role helper (`v13_tables.draw_role`): declared role first, else discovery = draws 0, 201, 202 at optimizer seed 0, fresh = 203-205, other otherwise (no more "every seed >= 300 is fresh"). | same, `v13_tables.py` |
| 5 | The rotation matrix moves to the operand's device and dtype at every use; a CUDA test. | same, `tests/test_v31.py` |
| 6 | Decomposition identities enforced at prediction level for every analysed state: the empty subset reproduces f0 and the full subset (assigned exactly, no round trip) reproduces the first-layer transplant, bitwise; the groups are checked to cover every input exactly once; the rotation round-trip residual is reported. The rotation matrix is kept in float64 in the metadata. | same |
| 7 | Traces from a declared inventory: trajectory rounds and end (once per trajectory, shared by its forks), the ledger's event checkpoints, the dense repair offsets of every phase, controls' eval checkpoints; a missing one is a failure; each row has the file, phase, update, update source and origin ("updates since f0, excluding f0's own training"). | same |
| 8 | `endpoint_kind` (compact / native_expanded), endpoint MACs and architecture flag in the removal rows; native expanded endpoints never get compact-gain columns. | `v13_tables.py` |
| 9 | The restricted-repair arms are described by their actual timing: every layer trains in the transition; `linear_repair_first` keeps the other layers at their POST-TRANSITION values. | docs, `wave13.py` |
| 11 | The launcher runs the analysis with `--manifest --strict --codes auto --trace --decompose` and no grid (`--grid` is opt-in and exploratory); packaging requires the coverage report and the main tables. | `scripts/31_v31_panel.sh` |

## Tests

`tests/test_v31.py`: first-layer repair checked by parameter NAME on the abrupt and the gradual path (and the
trainable set recorded per phase); the restoration's before / after checkpoints and resume around it; C1_first by
name; keep learns the backbone and keep_frozen keeps the additions; phase-matched forks share the parent hash, the
ordered batch ids and the reset times with the linear removal; the product rule checked against its definition
and its counterfactual pairing; the strict analysis passing with all audits, its decomposition on rotated inputs
(CPU, and CUDA when present), and failing on a missing trace checkpoint (with stale output replaced and partial
rows quarantined), corrupted saved predictions, invalid codes and a failed job; unique-draw aggregation; the role
helper; wave-21 structure. `tests/test_v31_launcher.py`: the analysis mock writes real-shaped outputs; a missing
output fails packaging; a failing analysis fails the launcher. The weaker v30 tests they replace were removed.
Not run here; compiled, and waves 19 / 20 / 21 generate.

## Not done

Boundary cells keep C1 only (exploratory); moving the restore time through the repair; a serial-implant topology.
