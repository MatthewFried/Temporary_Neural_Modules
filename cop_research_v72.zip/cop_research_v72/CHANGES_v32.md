# v31 -> v32: does a history produce a REUSABLE first layer, and what in the history causes it? (v31 never ran)

Semantics `cop-7.12.0`. Run `scripts/32_v32_panel.sh`; results `~/cop_results_v32`; wave 21 has 384 jobs.
scripts/31 refuses to run. Everything in CHANGES_v31.md stands.

The question, stated narrowly: do persistent temporary connections, followed by their removal, produce a first-layer
change that ordinary continuation, generic damage and recovery, and the rebuilt starts do not, at comparable
budgets, and does that change help a recipient it was never trained with?  After deletion the additions cannot
teach anything except through surviving weights or optimizer state, so improvement during repair does not by
itself show that computation migrated out of them.  Three readings are kept apart: preservation (the backbone
already held it), new learning (removal changes the training problem), ordinary recovery (perturbation, resets
and more training would do the same).

## Changes to training (new runs)

| Change | Where |
|---|---|
| `keep_frozen_implants` now also applies to method linear: the additions stay in the forward pass with frozen parameters during the transition; with `gate_schedule = hold` they stay fully coupled (gates at 1) for `speed_updates`, then go at once. | `dissipation.py`, `config.py` |
| `continue.perturb_match = parent_frozen_deletion`: at the start of `perturb_segment`, a fixed random weight direction (each tensor's norm) is scaled by bisection until the validation error equals the budget parent removal's frozen joint-deletion validation error (the same immediate damage as deleting the additions), recorded in perturb_match.json. Matched on that one number only. | `continuation.py`, `config.py` |

## Wave 21 additions (exploratory; draws 301-306, optimizer seed 0)

| Block | Content |
|---|---|
| V32_coupling_time | fixed and redrawn: the additions kept coupled for U/2 or U updates, trained or frozen, then removed at once; the same total 1.5 U (the linear anneal and keep / keep_frozen are the short and the never ends) |
| V32_rebuild | fixed and redrawn: trained backbone with fresh additions, and f0 with the trained additions, each with the plain linear removal |
| V32_disturbance | C1_disturbed: f0 continued 2 U, then the matched random perturbation, then 1.5 U (fresh optimizer) |

## Analysis

- `audit_v5/tools/cross_transplant.py` (new; the launcher runs it strict as step cross21): each analysed state's
  first layer goes into an INDEPENDENTLY trained recipient, f0 of the same data draw at the other optimizer seed,
  through a fixed interface fitted on training inputs without labels (identity; a one-to-one unit permutation by
  correlation; an affine map, H x H + H values), folded into the recipient's second layer; the rest of the recipient
  is frozen. Controls through the same interfaces: the donor's own f0 first layer and a random first layer (what the
  interface alone recovers). Rows carry the interface's parameter count and training R^2 and the behavioural
  measures (counterfactual errors, shift, rare, shortcut flip rate). Donors without an independent recipient (the
  boundary cells) are excluded and listed.
- `selective_reversal.py` also analyses the held, frozen-held and rebuilt removals and C1_disturbed.
- The interaction to read: the change in transfer between a lineage's kept state and its removed states, for fixed
  vs redrawn, in the same recipients and through the same interface.

## Tests

`tests/test_v32.py`: a frozen hold leaves the additions unchanged while the backbone learns; the matched-damage
control reaches its target; the permutation and affine interfaces recover a unit-permuted copy of the recipient
exactly (the folding algebra); the cross-transplant tool's strict run. `tests/test_v32_launcher.py` (the
analysis mocks write real-shaped outputs). Not run here; compiled, and wave 21 generates and validates.

## Not in this round

The security / undesirable-behaviour extension (only after the controlled task establishes the effect); recipients
trained on other data draws; interfaces into deeper layers.
