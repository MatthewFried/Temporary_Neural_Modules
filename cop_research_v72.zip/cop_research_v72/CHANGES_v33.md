# v32 -> v33: portability against the additions' age (v32 never ran)

Semantics `cop-7.13.0` (the replication trajectories save age checkpoints, so their run ids change). Run
`scripts/33_v33_panel.sh`; results `~/cop_results_v33`; wave 21 has 384 jobs. scripts/32 refuses to run.

## Training change

The V30_replication trajectories save full checkpoints (`snap_<u>`) at u = U/8, U/4, U/2, 3U/4, U + U/8, U + U/4,
U + U/2, U + 3U/4 updates of their own training (the round boundary U itself is skipped; post_insert_r2 and final
are already saved). Nothing else about their training changes.

## Analysis

`audit_v5/tools/portability_age.py` (the launcher runs it strict as step age21): the replication arms come in pairs
that differ only in the optimizer seed. At every common age, for each direction, frozen interventions only:
the host as it is and with every addition deleted (what the host keeps), the same for the partner, the host's
additions copied into the partner raw and after the swap scan's affine interface alignment (what the additions carry
to another host), and the host's first layer (additions deleted) in the partner's f0 through the identity /
permutation / affine interfaces and in its own f0. Read as intervention outcomes, not an additive account:
redundancy and interactions mean no measure assigns the learning to one part.

## Not in this round (discussed, needs new training code or a new task family)

A stream with a new rule, a temporary shortcut and exceptional examples, with unlearning measured against a
retrained-without-them reference; an addition trained across several hosts in turn; the smallest replaceable group
compared across construction histories; schedules that separate growth from turnover.

## Tests

`tests/test_v33.py` (the age analysis on a two-seed pair, both directions, every age; the wave-21 snapshots) and
`tests/test_v33_launcher.py`. Not run here; compiled, and wave 21 generates and validates.
