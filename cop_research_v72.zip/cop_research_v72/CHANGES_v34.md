# v33 -> v34: the v33 static review (age-analysis accounting and integrity; the outstanding v32 corrections)

Semantics `cop-7.14.0` (every run id changes). Run `scripts/34_v34_panel.sh`; results `~/cop_results_v34`; wave 21
has 396 jobs (384 + 12). scripts/33 refuses to run. If a v33 run had started, its results stay in
`~/cop_results_v33` and are not reused. The v26 panel (`~/cop_results_v26`, semantics cop-7.8.0) is untouched.

## Training-changing fixes (new or changed jobs)

1. **C1_disturbed phase-matched** (review 7 / 9). Segments [U, U, g, R - g], fresh optimizer at the last two
   (segment_reset [F, F, T, T]), the perturbation at the start of segment 2: the removal time and abrupt_pm's
   reset times (recover_0 for g, recover_0b for R - g). Compare it with abrupt_pm, not with the linear removal.
2. **Matched perturbation** (review 7 / 9). Declared estimand (`continue.perturb_estimand`: absolute = the deleted
   parent's validation error, increment = the deletion's increase over its intact model, added to this model's
   unperturbed error). Bracket by doubling to 64, bisect the crossing, use the closer bracket end; the job is
   invalid (recorded in perturb_match.json, weights restored) when the target is not above the unperturbed error,
   is not reached by scale 64, or the achieved error is farther than max(perturb_match_tol = 0.005, 1 / n_val).
   Before v34 the job ran on with the largest scale and a shortfall.
3. **Explicit segment_reset** (review 9). A declared False now carries the optimizer state even when
   train.opt_state_on_edit is reset (before, False fell through to the global setting). The panel uses preserve,
   so this changes no panel job's training; it is a semantics change for that configuration.
4. **The fourth rebuilt-start corner** (review 9). V32_rebuild adds f0 + the additions at insertion
   (linear_f0_fresh) for fixed and redrawn on every mechanism draw: 12 jobs.
5. **Time-matched compact states** (review 7). The replication C1_phase also saves its states at the v33 age times
   (eval_at += v33_snapshots(U); evaluations only, the training stream is unchanged).

## Analysis-only fixes (no training change)

`audit_v5/tools/portability_age.py` (rewritten):

1. **Inventory from the manifest** (review 1). Stages come from train.snapshot_at and the declared two-round layout:
   post_insert_r1, the snapshots before U, round_1, post_insert_r2, the snapshots after U, final. Every stage of both
   runs and every planned measurement is required (units listed by key in the coverage report); a missing
   checkpoint on one side, both sides, all intermediate ones or final fails. Other layouts fail, not skip.
   Duplicated manifest run ids and duplicated output keys fail.
2. **Recipient baselines** (review 2). Each row carries its recipient's f0, intact and without-additions errors and
   gain_vs_<ref> = reference - value, paired within the direction before draw-level averaging.
3. **Alignment status** (review 3). align_swapped records fitted / identity_fallback / unsupported /
   numerical_failure per branch and checks representability before touching any parameter (the v33 helper copied
   the weight before refusing a biasless layer). Any unsupported or numerical failure fails the direction. Fitted
   maps are saved with source run / stage / parameter hashes (panel21/age_maps) and refolded from freshly loaded
   checkpoints; the predictions must match bitwise. Adapter cost, parameter count and residuals are kept.
4. **Checkpoint integrity** (review 4). Config equal to the manifest; lineage run / stage / config hash; parameter
   and graph hashes recomputed; finite tensors; no recorded divergence; recorded and logged data hashes equal to the
   regenerated ones for train and every evaluated partition; the trainer counter equal to the stage's update; the
   declared branch players and ages; finite predictions; function preserved at both insertions; the age-zero
   backbone equal to f0.
5. **Pairing policy** (review 5). independent_replicates: configs equal except parents and the seed streams;
   optimizer, init, minibatch, insertion and partition all differ; distinct f0s; exactly two members. The docs no
   longer say "differ only in the optimizer seed" (the panel pairs also differ in insertion and partition).
6. **Cohorts and the clock** (review 6). trajectory_updates is the clock; each row has the r1 / r2 ages; branch
   transfers report all players and, once round 2 exists, each cohort; round_1 and post_insert_r2 are separate
   stages with an event order. The age-zero insertion is included.
7. **Controls and readouts** (review 7). Donor-f0, random and self first layers through the same interfaces; the
   partner's own branches through the same alignment; val_indep, cf_shortcut, cf_causal, shift, rare and the flip
   rate; the time-matched C1_phase state. The analysis is labelled exploratory.
8. **No discarded work** (review 8). Only the needed subsets are evaluated (dissipation.transfer_models, shared
   with swap_scan). Wall time, fitting MACs and map storage are in the coverage report.

`audit_v5/tools/selective_reversal.py` (review 9): --limit is refused under --strict; provenance is required (a
logged hash for train and every evaluated partition); every state's checkpoint gets the integrity checks above; the
trace inventory comes from the config (expected_schedule) and the job's phase / event ledger must equal it.

`audit_v5/tools/cross_transplant.py` (review 9): recipients are the manifest's baselines with the same data, model
and recipe; a promised recipient that is missing or fails a check is a failure, not an exclusion; the recipient is
read at the donor's own f0 stage; every checkpoint is integrity-checked; non-finite fits fail.

`audit_v5/tools/audit_common.py`: the shared checks and the one failure type of the three tools.

Launcher (review 10): each analysis first deletes its own old outputs; `evidence21` (scripts/check_evidence.py)
fails when an analysis exited 0 without its tables or a passing coverage report; the analysis tables are required in
the archive only when that check passed, so a failed analysis still leaves a diagnostic archive while the exit status
stays nonzero.

## Kept as is, with the reading restricted

The hold arms (V32_coupling_time) keep the fixed total budget: a longer hold is a shorter repair and a later second
reset. They are a budget-allocation experiment, not an isolated duration effect. Aligned branch transfer shows
reconstructability through an adapter fitted to the recipient's own branch output; it does not by itself show that
the donor brought useful knowledge (raw transfer and the self control are reported beside it). The age curve is a
co-evolving pair; it does not isolate the effect of branch age.

## Tests

`tests/test_v34.py` (A-H of the review's list) and `tests/test_v34_launcher.py` (I). Updated: test_v31 (396 jobs),
test_v32 (matched perturbation within tolerance or invalid), test_v33 (the age run moved to v34). Not run here;
compiled, and wave 21 generates.
