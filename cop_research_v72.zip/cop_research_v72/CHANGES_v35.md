# v34 -> v35: the failures of the v34 CPU tests (the v34 panel never trained)

Semantics unchanged (`cop-7.14.0`; nothing ran under v34). Run `scripts/34_v34_panel.sh` from the v35 folder;
results still go to `~/cop_results_v34` (that folder holds only the failed reports, which are replaced).

1. Removal ledger: a resumed phase wrote "fresh at phase start (resumed inside)" into schedule_audit, so a resumed
   job's dissipation_result.json differed from an uninterrupted one (the resume tests test_v31 and test_v2_audit F11
   failed; weights, optimizer state and metrics were identical). The text is now always "fresh at phase start"; the
   attempt history is the separate field attempt_resumed_inside.
2. portability_age: the draw role came from each host's config, and the legacy rule depends on the optimizer seed,
   so the two directions of one draw could fall into different summary groups. The role is now the pair's.
   (The panel draws 301-306 have one role at both seeds, so the panel was not affected.)
3. test_v26's selective-reversal test read the v27 output (_rows.csv); rewritten for the current _codes.csv.
4. Launcher: when the training panel is skipped (a prerequisite failed), every step that reads its results is
   skipped too, instead of running on an empty folder.

The five failing tests and the launcher tests were run here and pass.
