# v35 -> v36: the disturbance control on every draw (v34/v35 panel: one C1_disturbed draw unreachable)

Semantics `cop-7.15.0` (every run id changes; a fresh panel). Run `scripts/36_v36_panel.sh`; results
`~/cop_results_v36`; wave 21 has 402 jobs. scripts/34 refuses to run. The v34/v35 run in `~/cop_results_v34` is
kept as it is and not reused.

## What the v35 run showed

395 of 396 jobs completed and the age analysis passed. One C1_disturbed job was invalid: on that draw the fixed
removal's immediate deletion takes validation error to 0.488, about chance, and the random perturbation never
reached it by scale 64. The five others matched exactly (deletion errors 0.27 to 0.52). The analyses failed only
because of that one job.

## Training change

1. `continue.perturb_match_metric`: val_err (the error rate, as before) or val_risk (cross-entropy, no ceiling).
   Both values are recorded at the chosen scale. Tolerance: val_err max(tol, 1 / n_val); val_risk tol (nats).
2. V32_disturbance has two arms on every draw: C1_disturbed (error matched) and C1_disturbed_loss (risk matched),
   both phase-matched to abrupt_pm. +6 jobs.

## Declared outcomes (analysis and launcher)

An error match can be impossible by design (the deletion is already at chance). The three failure outcomes of the
matched perturbation (target not above the unperturbed value, not reached by scale 64, not within tolerance) are
DECLARED outcomes (`audit_v5/tools/declared.py`): such a job ends invalid with the reason in perturb_match.json.
- The launcher's run21 passes after `cop run` exits 1 only when every job that did not complete has a declared
  outcome (`scripts/declared_outcomes.py`, report `declared21.json`, archived).
- check_results, selective_reversal and cross_transplant list such a job as an exclusion with its reason.
- Any other invalid, failed or missing job still fails all of them.

## Tests

`tests/test_v36.py` (loss matching reaches a target the error cannot; declared outcomes only for the matched
perturbation's own reasons; the script; strict analyses and the result check list a declared job and fail on any
other reason) and `tests/test_v36_launcher.py` (a declared invalid job passes run21 and is archived; an undeclared
one fails it). The full CPU suite ran here: 638 collected, all passed or skipped (CUDA).
