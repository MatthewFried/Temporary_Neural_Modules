# v36 -> v37: one flaky CUDA test (the v36 panel did not train)

Semantics unchanged (`cop-7.15.0`). Run `scripts/36_v36_panel.sh` from the v37 folder; results `~/cop_results_v36`
(its failed reports are replaced).

test_acceptance T22 compared a ResNet's CPU and GPU outputs within 1e-3 without turning TF32 off (PyTorch allows
TF32 convolutions on Ampere by default; the jobs turn it off through utils' device setup) and on an unseeded random
input, so it passed or failed by chance (v36: 1.37e-3). It now compares true fp32 on a fixed input. No job code
changed.
