# v37 -> v38: the report packager dropped large files (the v37 panel completed)

Semantics unchanged (`cop-7.15.0`). The v37 run of `scripts/36_v36_panel.sh` passed every step up to packaging;
`package` failed because scripts/package_reports.py silently skipped every file of 8 MB or more, and the layer
transplant trace (a required member) is larger. A required member is now always archived; other large files are
listed with their sizes in skipped_large_files.json inside the archive instead of being dropped silently.

Rerunning the launcher from the v38 folder reuses the 402 completed jobs (status complete, same semantics), reruns
the tests, checks and analyses, and packages.
