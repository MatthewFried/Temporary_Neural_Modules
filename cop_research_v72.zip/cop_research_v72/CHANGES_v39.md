# v38 -> v39: after the v36 first-layer decomposition

Semantics `cop-7.16.0`. Run `scripts/39_v39_panel.sh`; results `~/cop_results_v39`; wave 22, 144 jobs, data draws
307-312 at optimizer seeds 0 and 1. It also re-analyses the v36 panel read-only (`~/cop_results_v36`). The v36
panel and its launcher (`scripts/36_v36_panel.sh`) are unchanged.

## What prompted it

The v36 decomposition (confirmation draws, both seeds): putting only the causal-input columns of the fixed
expansion's first-layer change into f0 gives +8.12 points [6.78, 9.46] at the trajectory's end and +7.91 after the
repair; the shortcut column alone gives -8.76 and -4.86. The whole layer gives +1.21 before and +4.09 after. The
useful change is already present at the end of the expansion; the repair mainly makes the shortcut change less
harmful. (The v36 note that the gain "forms after the expansion" holds for the whole layer only.) Every phase after
the trajectory also differs from the trajectory's own training in two ways at once: the gradient masks are
released and the AdamW state is reset.

## Training change (new jobs only)

1. The keep fork accepts `removal_masks=retained` (the parent's split keeps masking the branch gradients) and
   `optimizer_policy=carry_from_parent` (every tensor's AdamW state from the trajectory's end, matched by name; a
   missing one is unsupported). Before v39 the keep phases never received a retained mask context; every keep job
   of v30-v38 had released masks, so no earlier result is affected. Each phase record says which masks and
   optimizer state it used; the event ledger has `optimizer_carried`.
2. Wave 22: V39_core (fixed / redrawn trajectories, the linear removal and C1, roles confirmation) and
   V39_continuation (from each fixed trajectory's end, keep for 1.5 U: masks retained / released x optimizer
   carried / reset; redrawn: the released pair).

## Analysis (selective_reversal, read-only)

- `--cross`: in f0, the causal and the shortcut first-layer changes each from the trajectory's end or from the
  endpoint, all four crossings, noise and bias at f0 (primary) or from the endpoint; paired contrasts and the
  interaction per draw.
- `--scale-controls`: f0's own causal weights rescaled (to the transplant's norm, row by row, or by a factor chosen
  on val_indep, with and without a shortcut factor) and the transplant's directions at f0's norms, beside the
  causal-column transplant.
- Both run on wave 22 (reversal22) and on the v36 panel (reanalysis21).

## Kept as they are

The decomposition uses the generator's known feature groups: an informative intervention, not a method that finds
useful features by itself. The crossings interact nonlinearly, so their rows are not additive. The second task
family is not in this version.

## Tests

`tests/test_v39.py` (masks and optimizer state reach the keep phase and change training; every tensor carried; the
ledger matches the config; resume of a carried keep is identical; config rules; the cross reproduces the
decomposition's rows; the controls; wave 22) and `tests/test_v39_launcher.py`. The full CPU suite ran here.
