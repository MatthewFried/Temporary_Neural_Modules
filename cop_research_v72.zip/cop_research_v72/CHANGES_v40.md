# v39 -> v40: a read-through of the v39 changes

Semantics unchanged (`cop-7.16.0`; nothing has run under v39). Run `scripts/39_v39_panel.sh` from the v40 folder;
results `~/cop_results_v39`.

1. Carried optimizer state placement (cop/experiments/repair._carry_parent_opt, used by the keep fork's
   carry_from_parent and by repair.opt_state=preserve): every state tensor, AdamW's `step` counter included, was
   moved to the parameter's device. torch.optim keeps `step` on the CPU unless the group is fused or capturable,
   and its own load_state_dict does the same, so an uninterrupted job and a resumed one held it differently on
   CUDA. The values are the same; the placement now follows torch's rule exactly (floating state takes the
   parameter's dtype and device).
2. Retained masks in removal jobs (cop/experiments/dissipation): the mask context was built without the parent's
   mask route, so a forward- or parameter-route parent would have been masked on the gradient route. It now passes
   the same route options as the trajectory. Wave 22 uses the default gradient route, so its jobs are the same.
3. tests/test_v39.py: a CUDA test of the carried keep fork with retained masks (completes; an interrupted run equals
   an uninterrupted one). It runs in the launcher's CUDA step.

Read and found correct: the config rules; the keep fork's mask and optimizer wiring (the trainer never rebuilds the
optimizer inside a segment, so the carried state survives); the ledger rule; wave 22 (cells, parents, draws); the
cross and rescaling code (generator coordinates W Q^T and back with Q as in the decomposition, every other layer and
the bias at f0 where declared, selection on val_indep only, contrast signs); the launcher's analysis, evidence and
packaging steps.
