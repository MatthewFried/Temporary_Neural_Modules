# v40 -> v41: the v40 static review

Semantics `cop-7.17.0`. Run `scripts/41_v41_panel.sh` from the v41 folder; results `~/cop_results_v41`.
`scripts/39_v39_panel.sh` now refuses to run. The training matrix is unchanged (wave 22, 144 jobs); no new grid.

## Training jobs (configs and records; no job's arithmetic changes)

1. Wave label. wave22_v39_panel built its jobs with the wave-21 builder, so entries and configs said wave 21. A
   W22 builder stamps 22; tests assert it on entries and configs.
2. Trace checkpoints for the component trace. The wave-22 trajectories save the v33 age snapshots
   (train.snapshot_at) and C1 saves its states (save_eval_checkpoints) at U, 2U, 2U + g, the linear removal's repair
   offsets, the keep forks' offsets and the snapshot times, all on the job-update clock. Saving and evaluating does
   not touch the training stream; C1's validation selection points are separate from eval_at.
3. Carry rules. carry_from_parent now also requires a constant learning rate without warmup (a schedule clock would
   need its own declaration), and the fork's optimizer and hyperparameters (optimizer, lr, betas, eps,
   weight_decay, momentum, schedule, warmup, grad_clip, precision) must equal the parent's, else the job is
   unsupported. Wave 22 satisfies both.
4. Optimizer audit. Every phase logs whether its fresh optimizer holds any moments (a reset that leaves moments
   raises), a checksum of the optimizer state by parameter name at the phase start and after its first update, and
   the step range. A carried phase must carry every tensor (unique names) and its checksum must equal the parent's
   named entries, else unsupported; the `optimizer_carried` event records the checksum.
5. Gradient eligibility. The retained-mask context records per-example eligibility in the trainer state (the
   holder is wired), and each masked phase logs whether eligibility for branch a equals the parent's split for every
   example seen and branch b is its complement. The removal policy logs the split's hash and the mask route.
6. Wording. The carry is "the parent's weights and Adam state on a matched fresh stream" (the removal jobs'
   minibatch stream, the same for all four forks), not a literal uninterrupted continuation of the trajectory.

## Analysis only (audit_v5/tools/selective_reversal.py, scripts, tests)

7. One arithmetic path. The decomposition, the cross, the rescaling controls and the new component trace build
   the first layer the same way: W0 + (the selected generator-coordinate column changes) @ Q, or the state's own W
   when every group comes from that state. Checked in every job: causal_transplant equals the decomposition's
   causal subset, cross after/after/f0 its shortcut+causal subset and after/after/after its full subset (all
   bitwise, same state); cross before/before/f0 equals the abrupt state's shortcut+causal subset (bitwise, else max
   |diff| <= 1e-5 with the same decisions, since it is another compact graph of the same checkpoint).
8. Component trace (`_decomposition_trace.csv`, with --trace --decompose). none, causal, shortcut,
   shortcut+causal and the full first-layer change at every trace checkpoint. The inventory adds the trajectory
   snapshots and each removal phase's last update (the end of the gate anneal, the end of a repair or keep phase)
   when the path schedule saved it.
9. Continuation factorial (`_continuation_factorial_by_setting / _by_draw / _summary.csv`, `_fork_audit.csv`).
   Paired within the forks of one parent (same draw, seed, partition seed, update): reset_vs_carry | masks M =
   err(M, carried) - err(M, reset); release_vs_retain | optimizer O = err(retained, O) - err(released, O);
   interaction = (reset_vs_carry | released) - (reset_vs_carry | retained). Positive means the named change lowers
   test error. Measures: native endpoint, branch-deleted, first layer alone in f0, causal, shortcut and both alone in
   f0, at the endpoint and at every traced fork checkpoint. Seeds are averaged within draws; the summary is over
   unique draws. A partner the design holds but the results lack, or a duplicate, fails strict coverage. The forks of
   one parent must share the start-state hash, the minibatch-stream hash, the batches drawn, the update count and
   the lr; carried forks the parent's optimizer checksum, reset forks no state; retained forks the same split hash
   and eligibility that follows it. Any mismatch fails coverage.
10. Further contrasts. `_native*.csv` (the unedited endpoints); `_decomposition_contrasts*.csv` (each arm's
    component rows against C1's same components, same draw and seed, C1 shared; and fixed against redrawn, with
    unpaired rows counted); `_cross_contrasts_by_draw.csv`; `_scale_contrasts*.csv` (each control minus the causal
    transplant, same job and state).
11. Inventories. Per job, before anything is committed: codes x states, one native row per endpoint, 16
    decomposition rows per state, 6 rescaling rows per state, 8 cross rows per eligible endpoint, 5 component-trace
    rows per trace checkpoint; unique keys; finite values. A failure moves the job's rows to the diagnostic file. A
    test hook (COP_TEST_DROP=<table>) drops one row to prove it. Cross exclusions (rebuilt starts, a start other than
    the trajectory's final checkpoint, now detected from tags.parent_stage) and data without a shortcut layout are
    listed in the coverage. The abrupt state is the job's parent stage.
12. Rescaling grid. f0-only, so it is evaluated once per (f0, data) on the selection partition alone (it evaluated
    every partition for every state before). The coverage counts grid-edge selections and zero-norm rows; each row
    records them. The docstring no longer says nothing is fitted: the two selected controls fit one or two scales on
    val_indep.
13. Preflight (`--preflight`). Checks a results folder's configs, states, saved predictions and trace checkpoints
    without evaluating. The launcher runs it on the v36 panel (preflight21) before any training, as a prerequisite.
14. Evidence. A table written as the analyses' empty sentinel counts as missing. The launcher requires the new
    tables (decomposition trace, native summary, the contrasts, the fork audit, the factorial).

## Tests

tests/test_v41.py: the wave label; the carried state against torch's load_state_dict and a one-step reference, and
a swapped name mapping that must differ; gradient routing of the retained masks against per-branch reference
gradients, a reversed split that must fail, the route flags; four forks run end to end with the fork audit, the
parent's checksum and split hash, eligibility, the factorial arithmetic, the component trace, the exact identities,
the inventory counts, and a tampered stream hash that must fail; missing and duplicate factorial partners; a dropped
row of six tables that must fail its jobs; a non-final start listed as a cross exclusion; rotated inputs; the
preflight (a deleted checkpoint fails it); the evidence sentinel. tests/test_v39.py: exact identities instead of the
two-example margin, and the wave label. tests/test_v41_launcher.py replaces test_v39_launcher.py (preflight before
training, a failed or missing preflight skips the panel, empty required tables fail the evidence).

Expected wave-22 inventory (derived in the tool, not hard-coded): 108 eligible jobs; 156 named states (2,496
decomposition rows, 936 rescaling rows); 96 cross endpoints (768 rows).
