# v41 -> v42: the v41 panel's follow-ups

Semantics `cop-7.18.0`. Run `scripts/42_v42_panel.sh` from the v42 folder; results `~/cop_results_v42`. It reads
`~/cop_results_v41` and `~/cop_results_v36` read only (V41_RESULTS / V36_RESULTS). `scripts/41_v41_panel.sh` now
refuses to run.

## Training jobs

1. `train.freeze_inputs` (default `none`, so every earlier job is unchanged). With `shortcut`, the first backbone
   layer's weights that read the shortcut input column get no gradient (zeroed before clipping) and are restored
   after every optimizer step, so momentum and weight decay cannot move them either. The values are the ones the
   job started with: f0's for a trajectory or a compact continuation from f0, still f0's for a child of a frozen
   trajectory that keeps the freeze. Allowed for trajectory, dissipation and continue jobs on the shortcut data with
   unrotated inputs (there the shortcut is one input column) and an mlp backbone; not with train.freeze /
   freeze_schedule. The trainer records the frozen columns and a hash of their values once per segment.
2. Wave 23 (132 jobs, draws 313-318 x optimizer seeds 0 and 1, all exploratory):
   - fixed: the fixed trajectory, its linear removal (treated) and the released / reset keep fork (keep);
   - fixed_scfrozen: the fixed trajectory with the shortcut column frozen through the expansion; its linear removal
     with the freeze lifted (treated) and kept (treated_frozen), and the keep fork with the freeze lifted (keep);
   - compact: C1 and C1_phase (the same updates and stream with the optimizer reset at the removal's transition and
     repair starts, the compact carry / reset pair);
   - compact_scfrozen: C1 with the shortcut column frozen.
   Every removal and keep phase also saves states at +512, +1024 and +2048 (evaluation only); the trajectories save
   the v33 age snapshots and the compact controls their states on the same clock.
   The branches read the middle hidden layer, so later layers can still amplify f0's own shortcut use: the freeze
   removes the first-layer route only. The native shortcut flip rate is reported with every endpoint.

## Analysis only (audit_v5/tools/selective_reversal.py, scripts, tests)

3. Displacement (`--displacement`, with --trace): each job's parameter distance from its start (the trajectory
   checkpoint it forked from; f0 for a compact control) at every own trace checkpoint and the endpoint: backbone,
   first layer and its causal / shortcut / noise columns (generator coordinates), additions; absolute and relative
   to the start's norm. `_displacement.csv`, `_displacement_summary.csv` (seeds averaged within draws). This is the
   check on whether v41's carried forks simply took smaller steps.
4. Rescaling: the causal grid extends to 16 (v41 selected 4.0, its top, for every f0). Two fitted per-row
   rescalings of f0's causal block toward the learned one: least squares on the weights, and least squares on the
   causal block's contribution to each unit's pre-activation on the selection partition (fit R^2 recorded). Every
   control now records its agreement with the causal transplant on test: decision disagreement and the mean
   total-variation distance of the softmax outputs. 8 rescaling rows per state.
5. Contrasts: C1 is matched per C1 variant (compact, compact_scfrozen), a duplicated reference is counted, never
   overwritten; the variant pairs (fixed vs redrawn, fixed vs fixed_scfrozen, compact vs compact_scfrozen) on the
   components and, new, on the native endpoints (`_native_contrasts.csv`).
6. Freeze check: in a lineage that holds the shortcut column (the job and, for a removal, its trajectory) every
   named state's and trace checkpoint's shortcut-column change must be exactly zero, else the job fails.
7. Launcher: preflight22 (the v41 panel, with the trace and displacement inventory) and preflight21 before
   training; reanalysis22 re-reads the v41 panel with the displacement, the fitted rescalings and the extended grid
   (the four-fork factorial is recomputed and required there); reanalysis21 re-reads the v36 panel with the new
   rescalings.

## Tests

tests/test_v42.py: the frozen column exact at the trajectory end and across the round boundary while the rest of
the layer trains; kept in a child, moving once lifted; exact in a frozen C1; resume equality of a frozen
trajectory; config rules; a miniature wave 23 through the analysis (zero shortcut change wherever the lineage froze
it, the frozen trajectory's shortcut-only subset equal to f0, displacement rows and one recomputed by hand, the
fitted rescalings and agreement columns, the grid to 16, per-variant C1 and variant-pair contrasts); a job that
claims the freeze while its column moved fails the lineage check, an edited checkpoint fails its hash; the variant
pair arithmetic; the wave-23 structure. tests/test_v42_launcher.py replaces test_v41_launcher.py. test_v39 and
test_v41 updated for 8 rescaling rows and the displacement.

Expected wave-23 inventory (derived in the tool): 96 eligible jobs; 168 named states (2,688 decomposition rows,
1,344 rescaling rows); 60 cross endpoints (480 rows).
