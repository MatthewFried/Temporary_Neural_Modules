# v42 -> v43: the v42 static review

Semantics `cop-7.19.0`. Run `scripts/43_v43_panel.sh` from the v43 folder; results `~/cop_results_v43`. It reads
`~/cop_results_v41` and `~/cop_results_v36` read only. `scripts/42_v42_panel.sh` now refuses to run. The v42 panel was
not run, so nothing earlier is superseded.

## Training jobs

1. Compact controls matched to the frozen expansion's schedules. `continue.freeze_segments` (one boolean per
   segment, a frozen prefix only) applies train.freeze_inputs per segment inside one job: the trainer, sampler and
   optimizer state carry across the release; only the declared resets apply. A segment carries its own freeze mode
   (Segment.freeze_inputs); the held values are the segment start's, which in a frozen prefix are the job's start
   values. Wave 23 adds, per draw and seed:
   - compact_scfrozen / C1_phase: frozen throughout, resets at 2U and 2U + g (the match of fixed_scfrozen /
     treated_frozen);
   - compact_scfrozen_lift / C1_phase: frozen for 2U, released at 2U, the same resets (the match of fixed_scfrozen /
     treated);
   - compact / C1_reset: one reset at 2U, then R updates (the keep fork's schedule).
2. Every compact control now runs 2U + R updates with a declared boundary at 2U (C1: segments [2U, R], no reset),
   so all of them can be compared at the end of the expansion. `continue.fork_audit` hashes the minibatch stream
   and records, at every fresh segment start before its optimizer rule, the model's parameter hash, the optimizer
   state by parameter name, the sampler (position, epoch, permutation hash), the RNG states and the stream so far,
   and after the rule how many tensors still hold optimizer state. A segmented replay without resets equals one
   segment bitwise, and the audit changes nothing (tested).
3. `train.log_update_norms`: the Euclidean norm of every update (backbone, first layer, its causal and shortcut
   columns, additions) summed into a cumulative path length in the trainer state; the first 32 updates of each
   segment kept; copied into the extra of path / at_u checkpoints. No effect on training. On for every wave-23 job
   but f0.
4. Wave 23 is now 168 jobs (132 analysed). The keep-fork and removal arms are unchanged.
5. info_access discloses `privileged_feature_layout` for any arm that freezes the shortcut column (expanded or
   compact): the feature layout is privileged knowledge of the generator, not per-example labels.

## Analysis only (audit_v5/tools/selective_reversal.py, launcher, tests)

6. C1 reference (the review's main bug). The code contrasts keyed C1 without its variant, so with two C1 variants
   one overwrote the other. Codes, components and native endpoints now share one matcher: each row is paired with
   C1 of every C1 variant the design holds, separately labelled (reference_variant / _arm / _state / _run_ids);
   a duplicate reference keeps its first row and fails coverage; a partner the design holds but the results lack
   fails coverage; one the design does not hold is reported as noncomparable.
7. Variant pairs (fixed vs redrawn, fixed vs fixed_scfrozen, compact vs compact_scfrozen): the cells and the
   required partners come from the manifest; missing partners on either side, a whole missing arm, or duplicates
   fail strict coverage. Native pairs keep their per-setting and per-draw tables.
8. Declared contrasts (`--contrasts wave23`, REGISTRIES): 18 contrasts, value = err(B) - err(A) (positive = A has
   the lower test error), on the native endpoint and the full first layer, causal, shortcut and causal+shortcut
   components:
   - release vs remain frozen (expanded and compact);
   - frozen vs ordinary expansion (removal and keep);
   - the compact schedules (single reset vs carry, two resets vs carry, two vs one, frozen vs ordinary);
   - each expanded schedule vs its matched compact control;
   - at 2U: frozen vs ordinary trajectory, and each trajectory vs its compact control at the same update;
   - within each removal lineage: repaired vs the trajectory end.
   Every arm a contrast names must be in the manifest, and every (cell, draw, seed) either side holds must have
   both values for every measure, else strict coverage fails.
9. Compact fork audit (`_compact_fork_audit.csv`): controls of one f0 that share a prefix (frozen or not) must
   agree at every shared segment start, 2U among them, on model, optimizer, sampler, RNG and stream; a reset must
   leave no optimizer state and a carried segment must keep it; all draw the same minibatches to the end.
10. Rescaling:
    - the fits are pure functions, signed and nonnegative (10 controls per state);
    - the causal-drive R^2 in the fit (selection partition) and held out ('val');
    - degenerate rows are flagged, never given a scale or an R^2;
    - negative scales are counted;
    - per-unit scale vectors are saved;
    - every agreement, fit and norm metric is aggregated over settings and draws (`_scale_metrics_*`);
    - grid-edge selections are counted over unique (f0, data, partition) grids;
    - the scale-selected controls are labelled oracle tuning.
11. Displacement is NET movement (columns renamed net_*), with an explicit reference checkpoint, additions_rel,
    'deleted or not applicable' after a deletion, the endpoint's update count, the path length since the reference
    when the job logged its update norms, and for compact controls a second reference: their own state at 2U.
12. Preflight loads and checks every intermediate trace checkpoint and the displacement reference (lineage,
    parameter and graph hashes, data hashes), and every checkpoint check now includes the owner's config hash
    (the manifest's config must equal the folder's).
13. Metadata: a trajectory's trace rows carry the trajectory's own freeze setting and the variant of all its
    children (never the first child's); coverage records every result-determining option and the analysis
    schema. The lineage check of the frozen column follows a compact control's frozen prefix.
14. Launcher: reversal23 declares `--contrasts wave23`; the evidence check requires the registry, the compact fork
    audit, the scale metric summaries and vectors and the native contrast tables.

## Tests

tests/test_v43.py:
- a miniature wave 23 with every arm, end to end: the registry (every contrast, its arithmetic, the 2U and
  within-job pairs), the trajectory metadata, C1 per variant in every table, the compact fork audit (equal at 2U,
  reset leaves no state, the same stream) and a tampered RNG record that must fail, path length never below net
  movement, the frozen column's zero path, the 2U reference, the rescaling metrics and vectors, and a corrupted
  intermediate checkpoint that must fail the preflight;
- the segmented replay equal to one segment;
- the freeze schedule (held, then released) with resume equality;
- the config rules;
- the C1 matcher with two variants in either order, duplicates and missing partners;
- the variant pairs with either side, a whole arm missing, duplicates and noncomparable partners;
- the registry with absent arms and a missing pair;
- the rescaling fits analytically (exact positive and negative scales, nonnegative fits, zero rows, an orthogonal
  residual, constant targets, similar accuracy with different predictions);
- the wave-23 structure;
- a CUDA test of the new training paths.

tests/test_v43_launcher.py replaces test_v42_launcher.py. test_v42's lineage test now meets the config-hash check
first and then, with matching hashes, the lineage check.

Expected wave-23 inventory (derived in the tool): 132 analysed jobs; 204 named states (3,264 decomposition
rows, 2,040 rescaling rows); 60 cross endpoints (480 rows).
