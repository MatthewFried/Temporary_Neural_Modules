# v43 -> v44: the downstream-frozen expansion and the extraction rule

Semantics `cop-7.20.0`. Run `scripts/44_v44_panel.sh` from the v44 folder; results `~/cop_results_v44`. It reads
`~/cop_results_v43` read only (preflight before training, reanalysis after). `scripts/43_v43_panel.sh` now refuses
to run. The v43 results stay as they are.

## Training jobs

1. `train.freeze_backbone`: none | downstream. With downstream, every backbone parameter outside the first layer
   (layers 2 to K, the output head included) is held at its value at the segment start: gradient zeroed before
   clipping, values restored after every optimizer step, so neither momentum nor weight decay moves it. The first
   layer (its shortcut column too) and the additions train. One record per segment in the trainer state
   (`backbone_hold_record`: the held parameter keys and a hash of the held values). Trajectory, dissipation and
   continue jobs with an mlp backbone; not combined with train.freeze / freeze_schedule; combinable with
   train.freeze_inputs.
2. `continue.freeze_segments` now governs both freezes (inputs and backbone): a frozen prefix holds whichever the
   job sets, then releases it.
3. Wave 24 (144 jobs, draws 319-324, never used, optimizer seeds 0 and 1; all exploratory):
   - fixed: the fixed trajectory, its linear removal (treated) and the keep fork (keep);
   - fixed_dsfrozen: the fixed trajectory with layers 2 to 5 held at f0 throughout the expansion; its removal and
     keep fork with the hold lifted;
   - compact: C1 [2U, R] carried, C1_reset (reset at 2U), C1_phase [U, U, g, R - g] (resets at 2U and 2U + g);
   - compact_dsfrozen_lift: C1_phase held for 2U then released (the match of fixed_dsfrozen / treated) and
     C1_reset held for 2U then released (the match of fixed_dsfrozen / keep).
   Every job but f0 logs its update norms; every compact control audits its fork point. 108 analysed jobs.
4. info_access discloses `backbone_hold` for any job that holds layers 2 to K.

## Analysis only (audit_v5/tools/selective_reversal.py, launcher, tests)

5. Full code map: `--codes all` evaluates every keep / restore combination (2^K = 32) on every named state.
   `--trace-codes` (default auto) sets the trace checkpoints' codes separately; `--codes-at-2u` uses the full set
   at the end of the expansion (the trajectory end and the compact controls' at_2U). Exploratory, not corrected
   for multiplicity.
6. Codes with the additions present (`--implant-codes`): on every state that has additions (abrupt,
   after_transition, kept_end), the raw graph with the gates as recorded and each backbone layer mixed toward f0.
   The zero code must reproduce the state, and an endpoint its saved native function, bitwise.
   `_codes_implants*.csv`, and `_codes_implants_contrasts*.csv` pairs each code present minus deleted, same job and
   state (positive = deleting the additions lowers test error).
7. Residual test: the learned causal block is split into a per-row scaling of f0's block plus a residual,
   C1 = s * C0 + Res, with s the signed row fit. Three versions are evaluated:
   - scaling only (f0_causal_row_ls_fit);
   - f0 plus the residual alone (new: f0_causal_plus_residual);
   - both together (the causal transplant; checked to add up).
   Every rescaling row carries residual_energy_fraction = |Res|^2 / |C1|^2 and |Res| / |C1 - C0|. That gives 11
   controls per state.
8. Downstream lineage check: in a lineage that holds layers 2 to K, every state must equal f0 there exactly. A
   removal's abrupt state follows its trajectory; a compact control's trace checkpoints are checked through its
   frozen prefix. Otherwise the job fails. Every check and trace row reports downstream_change_max_abs. The
   shortcut-column lineage check now applies a freeze schedule's prefix only when the job freezes that column.
9. The wave-24 registry (`--contrasts wave24`, 30 contrasts), value = err(B) - err(A):
   - at 2U: dsfrozen vs ordinary trajectory, each trajectory vs its compact control, and dsfrozen compact vs
     compact;
   - endpoints: dsfrozen vs ordinary expansion (removal, keep), each expansion vs its matched compact control, the
     compact hold vs none, and the compact reset schedules;
   - within job: repaired vs abrupt, for each lineage.
   The new kind `cross_measure` pairs two named measures of two arms. The extraction rule (code 0-1-1-1-1 on the
   abrupt state), for each lineage, is compared with:
   - the repaired native endpoint;
   - the expanded network with its additions;
   - f0;
   - the compact control's extraction at 2U;
   - the compact C1_phase endpoint;
   - the two oracle-tuned rescaling controls (causal, and causal + shortcut, scales chosen on val_indep).
10. The compact fork audit groups by what the frozen prefix holds (`prefix_freeze`), not only whether it holds
    something. Variant pairs add fixed vs fixed_dsfrozen and compact vs compact_dsfrozen_lift. Displacement
    summaries are grouped by freeze_backbone too.
11. Launcher:
    - preflight23 checks the v43 panel before training;
    - reversal24 runs `--codes all --trace --trace-codes auto --codes-at-2u --implant-codes --decompose --cross
      --scale-controls --displacement --contrasts wave24`;
    - reanalysis23 runs the same options on the v43 panel with its wave-23 registry;
    - the implants-present tables are required evidence;
    - the v41 and v36 reanalyses are dropped.

## Tests

tests/test_v44.py:
- a miniature wave 24 end to end:
  - training: the hold keeps layers 2..K at f0 through the expansion and the frozen prefix, releases after it,
    and the lifted removal moves them;
  - the analysis passes strict coverage with every wave-24 contrast;
  - all 32 codes, with the extraction equal to the branch-deleted state in the held lineage;
  - downstream changes zero where held;
  - all codes at 2U and the auto codes elsewhere;
  - the codes with the additions present (zero code = native endpoint), and their contrasts;
  - 11 rescaling controls with the residual fraction;
  - cross_measure arithmetic from the named rows;
  - the held compact prefix's own fork-audit group, equal at 2U;
- a held lineage passes the downstream check, and the same configs trained with the hold disabled fail it;
- resume equality for the held trajectory and the held-then-released compact control;
- the config rules;
- code sets and the residual split analytically;
- cross_measure pairing and missing sides;
- the wave-24 structure;
- a CUDA test of the new training path.

tests/test_v44_launcher.py replaces test_v43_launcher.py. test_v39 and test_v41 count the new residual control.

Expected wave-24 inventory (derived in the tool):
- 108 analysed jobs and 156 named states;
- 4,992 code rows, and 2,304 rows with the additions present (72 states);
- 2,496 decomposition rows and 1,716 rescaling rows;
- 48 cross endpoints (384 rows).
