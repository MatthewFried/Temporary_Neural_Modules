# v44 -> v45: the freezing factorial

Semantics `cop-7.21.0`. Run `scripts/45_v45_panel.sh` from the v45 folder; results `~/cop_results_v45`. It reads
`~/cop_results_v44` and `~/cop_results_v43` read only (preflight before training, reanalysis after).
`scripts/44_v44_panel.sh` now refuses to run. The corrected v44 write-up is RESULTS_v44.md.

## Training jobs

1. `train.audit_batches` (bool): the trainer keeps the ordered minibatch example ids as a hash chain in its state
   (resume-safe). It uses the same construction as the v43 compact fork audit and the v31 removal audit, so chains
   of jobs that start from the same trainer state can be compared. A job with it set does not also hash through the
   older wrappers, so nothing is counted twice. It is rejected with stream=fresh.
2. Training cost by part. On every update the trainer adds the backward-aware MAC estimate split into:
   - forward;
   - input gradient;
   - parameter gradient computed;
   - the parameter-gradient work a hold discards.
   A hold keeps requires_grad on and zeroes the gradient after backward, so the held gradients are computed. The
   parts are stored as `mac_parts` in the trainer state. Checkpoints without trainer state (at_u, path_u) carry
   them in `extra.compute`, and the results carry `compute_end`. The estimate is analytic: linear-type nodes only,
   elementwise work not counted. The trainer's older 3 x forward figure is kept beside it.
3. Fix (bookkeeping only; training unchanged): each per-segment record is written once, keyed by segment and
   starting update. This covers trainable_record, input_freeze_record (v43) and backbone_hold_record (v44). Before
   v45, a job resumed from a checkpoint written after a segment's record but before its first update recorded the
   segment twice. Found by the v45 resume test; models and streams were always equal.
4. Wave 25 (312 jobs; data draws 325 to 336, checked unused in every earlier wave at every scale; optimizer seeds 0
   and 1). Per draw and seed there is one f0 and four expansions to 2U that differ only in what they hold at f0:
   - A: nothing;
   - B: the first layer's shortcut column;
   - C: backbone layers 2 to 5, output head included;
   - D: both.
   Each condition also has:
   - a removal (`treated`) that lifts both holds at 2U, then runs the linear removal and repair (secondary);
   - a compact control (`compact_A` to `compact_D`, arm C1_phase) with the same holds for 2U, released at 2U, with
     the removal's optimizer resets at 2U and 2U + g.
   All jobs except f0 audit their minibatch stream and log update norms; the compact controls audit their fork
   points. Insertion initialization is identical across the four conditions (checked in the analysis).

## Analysis only (audit_v5/tools/selective_reversal.py, launcher, tests)

5. Wave-25 registry (`--contrasts wave25`). The primary contrasts are marked `role=primary`. One extraction is used
   throughout: at 2U, the first layer kept whole (bias included), layers 2 to 5 restored to f0, additions deleted;
   this is code 0-1-1-1-1 on the expansion's abrupt state and on the compact control's at_2U checkpoint.
   - P1 (confirmation): B's extraction against compact B's identical extraction, and against f0.
   - P2 (mechanism): the new `interaction` kind, (err(compact B) − err(B)) − (err(compact D) − err(D)), computed
     per draw and seed. Optimizer seeds are averaged within a draw; the interval is over the 12 draws; every draw is
     in `_registry_by_draw.csv`.
   - Secondary contrasts:
     - A, C and D the same way;
     - the A−C, B−A and D−C interactions;
     - each compact extraction against f0;
     - the extraction against the expanded network and against the same restored backbone with additions present;
     - the removal / repair endpoint against its compact control's endpoint (both freeze-released);
     - the extraction against the repaired endpoint;
     - the first-layer components at 2U.
6. Extraction checks:
   - Every binary keep / restore code is verified as loaded: restored layers (weights and biases) are f0's
     tensors, kept layers and every other tensor are the state's, bitwise.
   - A restored layer is now assigned f0's tensors directly, rather than 0 · state + f0. The values are the same,
     so earlier results are unchanged.
   - The deletion must leave no live addition and must not alter the first layer; otherwise the job fails.
7. `--save-extractions DIR` saves, for each expansion, the 2U extraction and the same model with its additions
   present; for each compact control, its 2U extraction. Each saved model is reloaded and must reproduce the
   evaluated predictions. They are listed in `_extractions_saved.csv`; the launcher writes them to
   `~/cop_results_v45/extractions25`, outside the archive.
8. `_extraction_2u*.csv` holds, for every expansion, the five models at 2U: expanded with additions, trained
   backbone with additions deleted, the extraction, the extraction with additions present, and f0. A compact
   control has four rows. Each row has test, in-distribution val, shifted, rare-group and counterfactual errors,
   shortcut-flip rate, and training cost since f0. (Corrected in v46: v45 marked every row privileged=False. The
   extraction operation needs no feature labels, but conditions B and D were TRAINED with knowledge of which input
   column is the shortcut. v46 replaces the flag with training_access, from the trajectory lineage, and
   extraction_access. The feature-specific rescaling and residual probes are labelled separately, as probe_access.)
9. `_compute*.csv`: training cost since f0 for every named state, and on every trace row. Columns: updates, the
   3 x forward estimate, and the backward-aware estimate with its parts, including param_grad_used (computed minus
   discarded). Bases differ by job type:
   - trajectory counters minus f0's;
   - a removal's own (fresh) counters added to its trajectory's;
   - a compact control's counters (the MAC counters restart at the continuation; f0's updates are subtracted).
10. `--paired-streams`: within one f0 and seed, the four trajectories must share the audited minibatch stream, the
   insertion initialization (hash of each round's newly inserted parameters) and their configuration apart from
   the holds. Each compact control's stream at 2U must equal the trajectories'. Any break fails the run.
   `_paired_streams.csv` lists them.
11. Residual versus magnitude. Each causal-weight row is split as w_learned = a · w0 + r (weight-space least
    squares). The reconstruction and the orthogonality of r to w0 are checked (|cos| ≤ 1e-9) and recorded on every
    row. Zero rows are counted:
    - a zero row of f0 is degenerate (a = 1);
    - in the control that scales f0's directions it stays zero;
    - a zero row of w0 + r stays unscaled.
    Two new controls, 13 in all:
    - f0_causal_dir_at_norm_of_plus_residual: f0's directions at exactly the row norms of w0 + r;
    - f0_causal_plus_residual_at_f0_norm: w0 + r at f0's row norms.
    Every rescaling row reports its assembled candidate's own causal-block norms (candidate_*), separate from the
    source model's geometry. Nothing is tuned on test.
12. Launcher:
    - preflight24 and preflight23 check the v44 and v43 panels before any training;
    - reversal25 runs `--codes all --trace --trace-codes auto --codes-at-2u --implant-codes --decompose --cross
      --scale-controls --displacement --paired-streams --save-extractions ... --contrasts wave25`;
    - reanalysis24 and reanalysis23 run only `--decompose --scale-controls` on the saved v44 and v43 checkpoints
      (the residual-versus-magnitude controls);
    - the compute, stream and 2U extraction tables are required evidence.

## Implementation checks (tests/test_v45.py)

- A miniature wave 25 end to end, checking:
  - one shared stream for all four expansions and the four compact controls at 2U, and one insertion init;
  - every wave-25 contrast present, with the primaries marked and the interaction and P1 reproduced from the named
    rows;
  - five models per expansion in the 2U table (four per compact control), with every metric and cost;
  - the saved extractions: layers 2..K bitwise f0's, the first layer bitwise the trajectory end's, no addition;
  - layers 2..K exactly f0's where held;
  - cost: 12 updates at 2U and 18 at the repaired endpoint, parts adding up, discarded gradient work only under
    holds, the expansion costing more than its compact control;
  - 13 controls, with the orthogonality recorded and the candidate norms matching their definitions.
- At every optimizer step of a both-held expansion, between the holds and the update: every held tensor equals its
  segment-start value with a zero gradient. The raw gradients reaching the first layer and the additions at the
  first update are bitwise those of the unheld expansion: the holds do not detach the computation.
- The MAC parts:
  - forward + input gradient + parameter gradient = the backward-aware estimate;
  - a downstream hold discards exactly the held layers' parameter-gradient work and changes no other part;
  - a held column discards its share;
  - the trainer's cumulative parts add up to its counter.
- Resume equality, including the stream hash, the parts and the hold records, for: the both-held trajectory, the
  both-held compact control with its release, and the lifted removal from D.
- The trainer's stream chain equals the v43 continuation chain at every segment start.
- Analytic tests of the residual-magnitude blocks (zero rows included), the paired-stream checks, and the
  interaction arithmetic with missing sides.
- The wave-25 structure, including that the draws appear in no earlier wave at any scale.
- A CUDA resume test of both holds.

tests/test_v45_launcher.py replaces test_v44_launcher.py. test_v39, test_v41 and test_v44 count the new controls.

## Not claimed

The compact controls are matched in updates and phase schedule, not in compute. v45 makes no efficiency claim;
it reports the compute difference from the run's own counters. A compute-matched compact control would be added
before any claim that the extraction recipe is an efficient training method.

## Expected wave-25 inventory

- 192 analysed jobs (96 removals, 96 compact controls).
- Named states: 3 per removal and 1 per compact control, 384 in all.
- 32 codes on every named state.
- Codes with additions present on 192 states (abrupt and after_transition).
- 13 rescaling controls per state.
