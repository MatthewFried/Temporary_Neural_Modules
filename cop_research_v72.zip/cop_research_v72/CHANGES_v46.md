# v45 -> v46: the v45 review's fixes (analysis and launcher only)

Semantics unchanged: `cop-7.21.0`. No file under `cop/` changed, so the semantic code hash is v45's
(`1f5f72b51291d08a`, pinned by a test) and the run ids are v45's.

Run `scripts/46_v46_panel.sh` from the v46 folder; results go to `~/cop_results_v46`. The wave-25 panel comes from
one of two places:
- if `~/cop_results_v45/panel25` holds every manifest job complete, with v45's semantics, it is analysed read-only
  and nothing is retrained;
- otherwise the panel is trained under `~/cop_results_v46`.

A v45 panel that exists but is incomplete stops the launcher before the tests. Wait for the v45 run to finish, or set
`PANEL_SOURCE=fresh`. `PANEL_SOURCE=v45` requires the complete v45 panel. `scripts/45_v45_panel.sh` now refuses to
run.

## Training jobs

None changed.

## Analysis only (audit_v5/tools/selective_reversal.py, launcher, tests)

1. **The evidence contract (the definite v45 failure).** v45's launcher required five tables that wave 25 never
   fills, so a successful panel would have failed its evidence step after training. They are contrasts,
   decomposition_contrasts and native_contrasts (with its by_setting and by_draw tables): legacy C1 and
   variant-pair comparisons that do not apply to wave 25's arms. Wave 25 now has its own list (`LT25_FILES`). Its
   declared comparisons are the registry tables, and the new residual, extraction and cost tables are added. The
   checker is unchanged: nothing empty is accepted, and no dummy rows are written. tests/test_v46.py runs the REAL
   analysis on a miniature wave 25, with the launcher's exact options and required list read from the launcher
   itself. It passes with the genuine outputs and fails when a registry output is missing or empty.
2. **Direct residual-versus-magnitude contrasts** (`_residual_contrasts*.csv`). Both sides come from the same run
   and checkpoint; optimizer seeds are averaged within a draw, and the interval is over draws. Each has its sign
   stated:
   - direction_at_matched_row_norms: err(f0's directions at the row norms of w0 + r) − err(w0 + r);
   - direction_at_f0_row_norms: err(f0) − err(w0 + r at f0's row norms);
   - magnitude_alone: err(f0) − err(f0's directions at the row norms of w0 + r).
   A run and state missing either side fails coverage. The tables are required evidence for the wave-25 analysis and
   both reanalyses.
3. **The paired-stream audit:**
   - groups are (cell, draw, seed), never keyed by f0, so a condition pointing at another f0 fails;
   - membership comes from the manifest: exactly one trajectory per expansion condition, exactly one compact
     control per compact condition, nothing unexpected;
   - each group needs one f0 run id and one f0 state hash (computed from the tensors);
   - each record's own update count and minibatch count must be 2U, and each compact control must have exactly one
     fork record at 2U;
   - conflicting duplicate records fail.
   Negative tests cover: another f0 (run id or state), a missing condition or compact, a wrong update or batch
   count, conflicting duplicates, an unexpected condition, two runs for one condition, and a stream that differs.
4. **Access labels.** The single `privileged` flag is replaced by `training_access` and `extraction_access`.
   - training_access is read from the trajectory lineage for an expansion, because its removal job lifts the holds,
     and from the job's own holds for a compact control. B and D used the feature layout to hold the shortcut column;
     C's downstream hold uses only the layer index.
   - extraction_access: the whole-layer extraction uses no feature labels.
   - Every rescaling and residual probe is labelled `probe_access` = feature-group labels, plus the selection
     partition for the oracle-tuned ones.
   CHANGES_v45.md is corrected.
5. **Norms from the evaluated weights.** Each rescaling control's candidate norms are now read back from the
   first-layer weights actually loaded into the evaluated model, in its dtype; the ideal float64 construction is
   kept as ideal_*. The two norm-matched residual controls are checked row by row on the evaluated weights, with a
   tolerance from the evaluated dtype; any mismatch fails the job. Rows with no direction to scale are excluded and
   counted: zero rows of f0 for the first control, zero rows of w0 + r for the second.
6. **Costs in the extraction summaries; complete membership.**
   - `_extraction_2u_by_setting`, `_by_draw` and `_summary` are long-format tables with one row per metric. They
     carry the errors and three costs: post-f0 training cost (updates and the analytic backward-aware MAC estimate
     in its parts), f0's own training and the total including it, and the model's inference MACs per example. All
     MAC figures are labelled analytic estimates, not measured runtime. f0's row carries zero post-f0 cost.
   - Output membership is derived from the manifest:
     - every expansion has exactly its five 2U models and every compact control its four, each once, with errors in
       [0, 1] and 2U post-f0 updates (0 for f0);
     - every expansion has two saved extractions and every compact control one, each reloaded and reproduced.
     Any break fails coverage. For the full design this means 24 groups, 192 stream records, 864 extraction rows and
     288 saved models.
7. **Confirmation cohort.** Registry rows and coverage record the cohort ("fresh-draw confirmation cohort: draws
   325-336, P1 and P2 fixed before the run"), apart from the jobs' `exploratory` draw role. That role stays in the
   configs because changing it would change every run id and force retraining. P1 and P2 are the prespecified
   comparisons. Coverage names everything else, including the full code map, as secondary or exploratory.
8. **Launcher.**
   - The panel source is settled first, right after the environment step: a read-only reuse of a complete v45 panel
     (`scripts/panel_state.py` checks every job's status and semantic hash), or training here.
   - The strict summary is written to `~/cop_results_v46/summary25`, never into the reused panel.
   - Wave 25 is checked against its own evidence list, and the reanalyses require the residual contrasts.
   - The tests are tests/test_v46.py and tests/test_v46_launcher.py, which replaces test_v45_launcher.py.
