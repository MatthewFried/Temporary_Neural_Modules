# v46 -> v47: coordinated reversal on the existing wave-25 checkpoints (analysis only)

Semantics unchanged: `cop-7.21.0`. No file under `cop/` changed, so the semantic code hash is still v45's
(`1f5f72b51291d08a`) and the run ids are unchanged.

Run `scripts/47_v47_coordinated_reversal.sh` from the v47 folder. It reads the complete v46 wave-25 panel
(`~/cop_results_v46/panel25`) read-only and writes only `~/cop_results_v47`. Nothing is trained. If the panel is
incomplete or has other semantics, the tests and the analysis are skipped and the launcher fails.
`scripts/46_v46_panel.sh` now refuses to run.

## Training jobs

None changed. None run.

## Analysis only (audit_v5/tools/selective_reversal.py, launcher, tests)

1. **The 2x2 at every saved expansion age** (`--trace-implants`, with `--trace`): `_reversal_2x2*.csv`.
   - For every trajectory (A, B, C, D) and every saved checkpoint that has additions (insertion of each round, age 0;
     the intermediate rounds; the end, 2U), four models with the first layer kept (weights and bias):
     - additions present, layers 2..K trained (the native state);
     - additions deleted, layers 2..K trained;
     - additions present, layers 2..K restored to f0;
     - additions deleted, layers 2..K restored to f0 (the extraction).
   - Per run and checkpoint: interaction = err(deleted, trained) + err(present, rewound) − err(present, trained) −
     err(deleted, rewound), and joint_vs_native = err(present, trained) − err(deleted, rewound). Positive means the
     joint operation beats the expanded network.
   - Seeds are averaged within a draw; intervals are over draws.
   - `rewind_is_noop` is True when layers 2..K equal f0's exactly at that checkpoint: always for C and D (held), and
     at age 0 for A and B. The rewound cells then equal the trained ones, and this is reported, not hidden.
   - Test error, test and validation cross-entropy, shift, rare and shortcut-flip metrics are recorded.
2. **The 5x5 grid at 2U** (`--reversal-grid`, with `--implant-codes`): `_reversal_grid*.csv`.
   - On each full removal job's abrupt state (the trajectory at 2U):
     - alpha multiplies every leaf addition's gate. The gates are attached by cop.graph.edits.add_gate, as the
       removal attaches them: a branch's merge coefficient times the gate, with no new parameters. The leaves are
       I2..I5, which are nested inside I1; I1 itself has no parameters.
     - beta sets layers 2..K to f0 + beta·(trained − f0), using the same mixing arithmetic as the codes.
     - The first layer is fixed throughout.
     - alpha, beta ∈ {1, .75, .5, .25, 0}, fixed in advance.
   - The four corners must reproduce the existing models bitwise (all test logits), or the job fails:
     - (1,1) the native state;
     - (0,1) the deletion (all-zero gates equal the graph-edit deletion, nested additions included);
     - (1,0) the additions with layers 2..K restored;
     - (0,0) the extraction.
   - Each point records error and cross-entropy (test and validation), shift, rare and shortcut-flip error, and
     prediction disagreement with the native state and with the extraction.
3. **Three predeclared paths** across the grid: `_reversal_paths*.csv`, `_reversal_path_contrasts*.csv`.
   - The paths are:
     - diagonal (both together, 5 points);
     - delete then rewind (9 points);
     - rewind then delete (9 points).
   - Each path reports its worst and mean test error and its worst test cross-entropy. The paired contrast is the
     sequential path's worst minus the diagonal's worst; positive means the diagonal's worst point is better.
   - No path or point is selected on test data. A sampled path describes those points only; it says nothing about
     paths not sampled, and it is not evidence of irreducibility.
4. **Raw predictions** (`--save-preds DIR`). These are test-set class indices as npz files:
   - per grid job: 25 × n_test in alpha-major order;
   - per trajectory checkpoint: 4 × n_test in the order of the cells above.
   Each file carries the run id, checkpoint, order and partition. Checkpoint ids, operation definitions
   (`intervention_access`: no feature labels used) and training access are columns of every row.
5. **Membership.**
   - Every full removal job has 25 grid points.
   - Every trajectory has a 2x2 at 2U.
   - Any gap fails coverage.
   - The analysis schema is `selective_reversal/v47`.
6. **Launcher and tests.**
   - `scripts/47_v47_coordinated_reversal.sh` runs environment, manifest, panel source (`scripts/panel_state.py`), CPU
     tests, the analysis, evidence (`REV_FILES`: every table above, none empty) and packaging. It writes
     `cop_v47_reversal_reports.zip`; the predictions stay in `~/cop_results_v47/preds25`, outside the archive.
   - tests/test_v47.py runs the REAL analysis on a miniature wave 25 with the launcher's exact options. It checks:
     - the corners against the code tables and against the trajectory's own 2x2 at 2U (gates versus graph-edit
       deletion, two code paths);
     - the gated leaves;
     - the 2x2 arithmetic and the no-op flags;
     - the paths and contrasts recomputed from the grid;
     - the saved predictions against the disagreement columns;
     - the evidence contract, positive and negative.
   - tests/test_v47_launcher.py replaces test_v46_launcher.py. tests/test_v46.py keeps v46's analysis contract
     frozen verbatim, because its launcher is retired.

## What this run can and cannot say

- It measures the existing B result's path structure (and A, C, D's) on every full removal job of the v46 panel, with no new training.
- It cannot explain why the retained first layer improved; the narrow control panel (gain-only, redrawn
  assignments, compute-matched compact) is the next step and is not part of v47.
