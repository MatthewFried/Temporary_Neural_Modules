# v47 -> v48: corrected reversal-path reporting and logit checks (analysis only)

Semantics unchanged: `cop-7.21.0`. `cop/` is untouched, so the run ids and the semantic hash are the same.

Run `scripts/48_v48_reversal_barriers.sh`. It reads the v46 wave-25 panel (`~/cop_results_v46/panel25`) read-only and
writes only `~/cop_results_v48`. `scripts/47` now refuses to run; its reports stay in `~/cop_results_v47`.
RESULTS_v47.md is the corrected write-up of the v47 run.

## Training jobs

None changed. None run.

## Analysis only (audit_v5/tools/selective_reversal.py, launcher, tests)

1. **Path summaries.**
   - The mean along a path is dropped. It weighted points by schedule: 5 points on the diagonal, 9 on each
     sequential path. In C and D it also counted the same function repeatedly wherever the rewind does nothing,
     which made the paths look different when they are identical.
   - Per path and run, the summary now reports:
     - the raw worst test error and cross-entropy;
     - the endpoint-relative barrier: worst on the path minus max(start, end), for both error and cross-entropy.
   - Aggregation is within draws first, then over draws.
   - All three paths share both ends, so a barrier contrast equals the worst-point contrast; the contrasts are
     unchanged.
2. **Cross-entropy check.** At every grid and 2x2 point, the test cross-entropy is re-derived per example from
   log_softmax in float64. If it disagrees with the reported mean, the job fails.
3. **Logit diagnostics** at every grid and 2x2 point:
   - quantiles (1, 5, 25, 50, 75, 95, 99) of the correct-class margin (label logit minus the largest other logit;
     negative = wrong);
   - the same quantiles of the per-example loss;
   - the median, 99th percentile and maximum of the largest absolute logit per example;
   - the share of examples with loss above 10 nats;
   - the share of the total loss that comes from wrong examples.

   These show whether large cross-entropies are confidently wrong predictions.
4. **Saved outputs.** The npz files now hold the test logits (float32) and labels beside the decisions.
5. **Status.** The coverage file states the run is an exploratory reanalysis of existing checkpoints, with
   sampled straight-line interpolations at steps of 0.25. The schema is `selective_reversal/v48`.
6. **Tests.**
   - tests/test_v47.py now runs with scripts/48's options. It recomputes:
     - the barriers from the grid;
     - identical paths and zero contrasts wherever the rewind is a no-op;
     - every cross-entropy, margin and loss quantile, error, maximum logit and loss share, from the saved logits
       and labels.
   - tests/test_v48_launcher.py replaces test_v47_launcher.py.
