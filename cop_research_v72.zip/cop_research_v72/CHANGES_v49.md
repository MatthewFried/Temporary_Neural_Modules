# v48 -> v49: minimal coordinated edits, rank-k restores and package transfer (analysis only)

**Superseded by v50 (CHANGES_v50.md).** The selection rule, the summaries, the rank schemes, the grouping and the interpretations below were revised after review; `scripts/49` refuses to run.

Semantics unchanged: `cop-7.21.0`. `cop/` is untouched.

Run `scripts/49_v49_coordinated_edits.sh`. It reads the v46 wave-25 panel (`~/cop_results_v46/panel25`) read-only and
writes only `~/cop_results_v49`. This is an exploratory reanalysis of existing checkpoints. `scripts/48` (the
corrected reversal analysis) is a separate analysis and still valid.

## Training jobs

None changed. None run.

## Analysis only: audit_v5/tools/coordinated_edits.py (new), launcher, tests

Every state is a trajectory's end at 2U, for A, B, C and D, 12 draws x 2 seeds. Throughout:
- the first layer (L1) is kept;
- L2..L5 are the later layers, with L5 the head;
- the leaf additions are I2 and I3 (round 1) and I4 and I5 (round 2). They sit inside I1, which has no parameters;
- an addition is deleted by setting its gate to zero, as the removal does.

1. **Minimal coordinated edits** (`--minimal-edits`).
   - Edits: every subset of the four leaf additions deleted x every subset of L2..L5 restored to f0's exact
     tensors. That is 256 edits per run.
   - Recovery: decisions agreeing with f0 (`dis_f0`) and with the native network (`dis_native`).
   - Retention: error against f0 (`gain_vs_f0`) and against the extraction (`minus_extraction`).
   - For each deleted subset, a restore set makes it removable if validation error ≤ max(validation error of
     native, of the extraction) + 1 point. The selection uses validation data only. The table reports:
     - the minimal removable sets;
     - the chosen set: the smallest, with the lowest validation error;
     - the chosen set's test error, recovery and retention.

   The v46 code tables already answer the layer level for "everything deleted": no proper subset of L2..L5 works.
   This part asks it per addition and per round.
2. **Rank-k restores** (`--rank-restores`). Every addition is deleted. Each later layer's weight change W − W0 is
   restored only along its top k singular directions (float64 SVD); the bias is restored in full.
   - k ∈ {0 (bias only), 1, 2, 4, 8, full}, all later layers at once;
   - k ∈ {0, 1, 2, 4} for one layer at a time, with the other three restored in full;
   - each row records the share of each layer's change energy that was restored.
3. **Package transfer** (`--transfer`).
   - Within a draw and seed, the four conditions share f0 (checked bitwise) and one graph structure. Each host's
     first layer gets the additions of one donor (or none) x the L2..L5 changes of one donor (or none = f0). The
     change donors are those whose later layers differ from f0, which is A and B.
   - Package labels: own, none, additions only, changes only, matched foreign, mismatched.
   - Paired contrasts against the matched foreign package (positive = matched is better):
     - foreign additions on the host's own changes;
     - host additions on foreign changes;
     - foreign additions only;
     - foreign changes only;
     - the host's extraction.
   - Separately, the matched foreign package minus the donor's native network gives the cost of a foreign first
     layer.
   - For C and D hosts, "the host's own changes" are f0's, so the first contrast equals "foreign additions only".
4. **Checks.** Any failure fails the group.
   - The gated network at gates 1 equals the checkpoint bitwise.
   - Every addition deleted with nothing restored equals a compact deletion built independently on f0's graph,
     bitwise.
   - Every addition deleted with L2..L5 restored equals the extraction built the same way, bitwise.
   - A host's own package equals its native network bitwise, and no package equals its extraction.
   - Non-leaf additions own no parameters.
   - Every run has 256 edit points and 22 rank points; every group has 4 x 5 x 3 transfer points.
5. **Saved outputs.** Test decisions and labels go to `--save-preds` (`~/cop_results_v49/preds25`).
6. **Tests.**
   - tests/test_v49.py runs the real tool on a miniature wave 25 with the launcher's options. It checks:
     - the identities as seen in the tables;
     - the validation-only choice, recomputed;
     - the rank arithmetic, plus a unit test on a known rank-2 change;
     - the transfer factorial and every contrast;
     - the saved decisions against the error columns;
     - the evidence contract, positive and negative.
   - tests/test_v49_launcher.py covers the launcher.

## What each part could show (stated before the run)

- **Per-addition map.** If single additions, or the round-1 versus round-2 pairs, become removable with small,
  different restore sets, there is a per-addition map. If every subset needs all four layers, the dependence is
  shared, not per addition.
- **Rank of the correction.** If restoring rank 1 or 2 per layer reaches the extraction's error, the correction that
  must accompany deletion is low dimensional. If only full rank works, it is spread across the layer.
- **Transfer.** If the matched foreign package beats both mismatched packages and its parts on a host's first layer,
  the transferable unit is the joint configuration of additions and changes. If it does no better than its parts,
  that view is not supported here. If a package works on its own first layer but not on a foreign one, it is tied to
  the first layer it trained with.
