# v49 -> v50: coordinated edits after the v49 review, plus the fold analysis (analysis only)

**Superseded by v51 (CHANGES_v51.md).** The CUDA test, the fold audit and the rank size labels were corrected, and several statements under "What each part could show" were too strong; CHANGES_v51.md lists the replacements. `scripts/50` refuses to run.

Semantics unchanged: `cop-7.21.0`. `cop/` is untouched.

Run `scripts/50_v50_coordinated_edits.sh`. It reads the v46 wave-25 panel (`~/cop_results_v46/panel25`) read-only and
writes only `~/cop_results_v50`. This is an exploratory reanalysis of existing checkpoints. `scripts/49` now refuses
to run. `scripts/48` (the corrected reversal analysis) is separate and still valid.

## Training jobs

None changed. None run.

## Fixes from the v49 review (audit_v5/tools/coordinated_edits.py, launcher, tests)

1. **What "removable" means.**
   - Four named criteria, each "candidate error ≤ reference error + 0.01" on a selection partition:
     - `native`: the expanded network is the reference (the removal keeps its performance);
     - `extraction`: the full delete-and-rewind is the reference;
     - `f0`: the network before expansion is the reference;
     - `legacy_worse_endpoint`: v49's rule, max(native, extraction), kept under that name.
   - Two selection partitions: `val` (source validation) and `val_indep` (validation data from the evaluation
     distribution, labelled as target-distribution access).
   - The primary is (`native`, `val`), fixed before this run. The other seven are sensitivity analyses.
   - Every selection row records the criterion, reference error, threshold, margin, selection partition, chosen
     set, its selection error and its delta to the reference.
   - Where the full rewind qualifies by construction (everything deleted under `extraction` or the legacy rule),
     the row says so.
   - Minimality is stated within the menu: inclusion-minimal and minimum-cardinality whole-layer rewinds to f0. It
     is not minimal parameter support.
   - `val_indep` error is saved in every table.
   - Task performance (errors, gain over f0, difference to native and to the extraction) and functional recovery
     (decision disagreement and logit distance to f0 and to native) are separate columns.
   - Known before the run, from v46: on source validation B's extraction is 8.24 against 7.07 native, so under the
     primary the full rewind itself is just outside the margin on average. That is the reason the other criteria
     and `val_indep` are reported beside it, not a reason to change the primary afterwards.
2. **Selection failures.**
   - `minimal_sets_counts.csv`: expected, analysed and selected runs, and draws with every, some or no seed selected.
   - `minimal_sets_summary.csv` has two populations per metric:
     - selected runs only, labelled conditional on success, with the contributing runs;
     - all runs under a declared fallback: the unedited expanded network when nothing qualifies. The share of
       fallbacks and the additions actually deleted are reported.
   - `minimal_sets_by_draw.csv` shows which seeds contributed to each draw.
3. **Grouping.**
   - Jobs are grouped by experiment, data draw and optimizer seed. The experiment id is the contrast label plus a
     hash of the data settings (without seeds), architecture, growth and cut, and the training and removal
     protocol. It excludes the variant (design.variant and the trajectory's freeze settings).
   - Every row, saved file, contrast and summary carries the experiment.
   - Layer inventory and expected point counts are per run.
   - The expected variants come from the design (`--expect-variants`, passed by the launcher) or, without it, from
     the experiment's own variants.
   - Refused explicitly: non-classification tasks, layers that are not one weight matrix with a bias, and variants
     with different structure.
4. **Checkpoint age.** The checkpoint's updates since f0 must equal the configured expansion length (rounds x
   updates per round), for every variant. f0 must match across the group in parameters and in graph. Only the
   trajectory's end is analysed.
5. **Device and manifest.**
   - The launcher passes `--device "$DEVICE"`. Coverage records the device, torch and CUDA versions, and the
     numerical policy the tool sets (TF32 off, deterministic cuDNN, float64 for SVD and fits).
   - On cuda the launcher first runs the tool's CUDA test: the miniature analysed on both devices, with errors
     within two decisions of 64 and no bitwise comparison across devices.
   - The manifest is removed before regeneration, and a failed generation skips everything after it.
6. **Rank restores.**
   - The subtraction is now in float64 (`w.double() - w0.double()`).
   - Schemes are explicit:
     - `no_edit`;
     - `all_later_topk_bias_restored` (k = 0 is labelled the bias-only edit; v49's `all_layers`);
     - `all_later_topk_bias_kept`;
     - `partial_target_layer_other_layers_full` (v49's `one_layer`; the other layers are fully rewound);
     - `head_only_full`;
     - `hidden_topk_head_full` and `hidden_topk_head_kept`.
   - Each row records per layer the weight and bias treatment, the effective rank (a two-output head is fully
     restored at rank 2) and the energy removed, plus the number of changed parameters.
   - A layer that did not change reports no energy share.
   - `rank_layers.csv` gives each layer's shape and the spectrum of its change.
   - A failed top-k restore is reported only as that: this SVD path did not recover performance at the tested
     ranks. It does not show that no low-rank correction exists.
7. **Transfer.**
   - Rows are labelled `shared_ancestor_cross_history_package`.
   - Each row records how many host parameters come from the donor, are deleted or are rewound, and what the host
     keeps. A matched foreign package keeps only the host's first layer.
   - New contrasts: the matched foreign package against the host's native network and against f0.
   - For C and D hosts, the contrast that equals another algebraically is labelled as a duplicate.
8. **Audits.**
   - Every loaded state is compared bitwise with its intended tensors.
   - The identities (gates at 1, deletion, extraction, own package, no package) are checked on every evaluated
     partition, not only test.
   - Coverage records the manifest hash and the source hashes; the checks table records checkpoint and graph hashes.
   - Saved files hold test, `val` and `val_indep` decisions with labels. Errors and the primary selection are
     reproducible from them; cross-entropy is not, since logits are not saved.

## New in v50: the fold (`--fold`)

Deleting an addition sets its output to zero. The trained later layers may depend only on that output's mean or on
its linear part, which a compact network can absorb exactly. With h the value the additions read and u(h) their
summed output at the merge:

- **zero**: u = 0. This is the deletion.
- **mean**: u replaced by its mean over the training set, folded into the bias of the layer that reads the merge.
- **affine**: u replaced by its least-squares fit M h + c on training activations, folded into that layer:
  W' = W (I + M), b' = b + W c.

Each folded network has f0's architecture: the trained first layer, the trained later layers, and one adjusted
layer (L3 in wave 25, since the cut is after layer 2).

- The fit uses training data only. Each row reports how large u is relative to h, how much of u is constant, and the
  affine fit's R² on training and validation activations.
- Each folded network is checked against the same surrogate applied inside the expanded graph (relative logit
  difference ≤ 1e-4).
- From each folded network, the later layers are moved linearly to f0's (t = 0, .25, .5, .75, 1). The path ends
  exactly at the extraction. `fold_paths.csv` gives the worst point and the endpoint-relative barrier.
- The zero fold's path is the "delete, then rewind" edge of the v47 grid.

## What each part could show (stated before the run)

- **Removal sets.** If single additions or pairs are removable under the primary with small, different rewind sets,
  there is a per-addition map. If nothing short of the full rewind qualifies under any criterion, the dependence is
  shared across the later layers at whole-layer resolution.
- **Fold.**
  - If the affine fold stays near the native error, the "catastrophic deletion" is a dependence on the additions'
    mean or linear part. A compact network keeps the expanded network's function with one adjusted layer, and the
    additions' nonlinear part is not needed at the end of expansion.
  - If it stays near the deletion's error, the later layers depend on the additions' nonlinear, input-dependent
    output.
  - If the folded network's path to the extraction has a small barrier, the bad interior of the v47 grid came from
    the additions' uncancelled output, not from the later layers sitting in a separate region.
- **Rank.** If a low-rank restore reaches the extraction's error, the correction in that scheme is low dimensional.
  Otherwise only the narrow statement in item 6 holds.
- **Transfer.** The matched foreign package is compared with the host's own expanded network and f0, not only with
  broken mismatches. It tests compatibility between histories that share f0, and replaces most of the host. It is
  not a test of moving a small piece into an independent network.

## Tests

- tests/test_v50.py runs the real tool on a miniature wave 25 with the launcher's options. It checks:
  - every table against recomputation, including the selection with all test metrics replaced by noise;
  - the primary selection rebuilt from the saved validation decisions;
  - the rank identities against the edit table;
  - the transfer accounting;
  - the fold surrogate and paths.
- It also builds a second experiment with the same seeds and the same contrast label.
- Failure cases on real panels: a corrupted checkpoint, a self-consistent checkpoint with another f0, a checkpoint
  of the wrong age, a missing variant, and a missing job.
- Unit tests cover the one-seed-fails summary, grouping, the rank arithmetic, a wrong patched layer and the fold
  algebra.
- The CUDA test runs only where CUDA is available.
- tests/test_v50_launcher.py covers device forwarding, the CUDA test gate and the stale-manifest case.
