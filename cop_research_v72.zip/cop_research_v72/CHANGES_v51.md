# v50 -> v51: fold audit, residual-removal path, corrected accounting and claims (analysis only)

Semantics unchanged: `cop-7.21.0`. `cop/` is untouched. No existing training needs to be rerun.

Run `scripts/51_v51_coordinated_edits.sh`. It reads the v46 wave-25 panel (`~/cop_results_v46/panel25`) read-only and
writes only `~/cop_results_v51`. This is an exploratory reanalysis of existing checkpoints. `scripts/49` and
`scripts/50` refuse to run. `scripts/48` is separate and still valid.

## Training jobs

None changed. None run.

## Fixes from the v50 review

1. **CUDA agreement test.**
   - v50 compared error rates, which can be equal while predictions differ. The test now compares the saved
     decision arrays (new tool `audit_v5/tools/compare_edit_runs.py`):
     - every candidate network of every table (edits, rank, transfer, fold);
     - every saved partition (test, `val`, `val_indep`);
     - sample counts taken from the saved labels.
   - Pass rule: at most max(2, ceil(0.001 n)) differing decisions per candidate and partition. There is no bitwise
     comparison across devices.
   - Error-rate differences are reported beside it as a diagnostic only.
   - Selections are compared too. A differing selection is listed with both runs' distance to the threshold
     (`nearest_threshold_distance`, new in the selection rows). It is reported, not failed.
   - The report is written to `cuda_agreement.json` in the reports.
   - Launcher:
     - `cuda:N` now counts as CUDA and is forwarded;
     - the CUDA test's junit report must show that the test ran (`scripts/junit_ran.py`). A skipped test stops the
       run.
2. **Fold audit.**
   - The folded network is compared with the in-graph surrogate on every evaluated partition. Per partition the
     table records the relative logit difference, the number of differing decisions and the largest margin among
     them.
   - The tolerance (1e-4) is numerical only. How well a surrogate approximates the additions is reported with no
     threshold.
   - The check's results are in `fold_fit.csv`, one row per run and surrogate. They are no longer copied onto path
     rows.
   - The merge must be h + u(h) with skip coefficient exactly 1, and the widths must match, or the group is refused.
   - `--inject-fold-fault transpose|bias|layer` builds a wrong fold through the real pipeline. Tests require each
     to fail. The launcher never passes it.
3. **Size labels in the rank table.** `params_changed` is gone. Reported separately:
   - `entries_changed`: tensor entries the edit actually changes (exact comparison);
   - `correction_factor_storage`: k(m+n) per rank-k matrix, mn for a full rewind, the bias length for a restored
     bias, and 0 where the layer or bias already equals f0's;
   - `correction_intrinsic_dim`: k(m+n−k);
   - `inference_params`: the final dense network's parameter count.

   A rank-1 correction can change every entry, so factor storage says nothing about sparse or local editing.
4. **Fold diagnostics** (`fold_fit.csv`):
   - the share of the additions' output energy a surrogate leaves out, on train and every held-out partition, both
     raw and after the receiving layer (|W(u − û)|² / |W u|²);
   - the affine fit's R² on every partition;
   - the design's rank, extreme singular values and condition number, the declared cutoff (1e-10), and the norms
     of M and c;
   - the fit's cost: one forward pass over the training set and one least-squares solve, no gradient steps;
   - per partition, the folded network's disagreement with the native network, logit distance, probability
     distance and error difference.

   The fit and the folded tensors are saved (`<run>__fold_fit.npz`) with what is needed to rebuild the folded
   network. A test rebuilds them from the checkpoint.
5. **The first segment of the removal path.** With s(h) the surrogate (zero, mean or affine) and u(h) the additions'
   output:
   - segment 1 replaces u by s + λ(u − s) for λ = 1, .75, .5, .25, 0 inside the expanded graph, backbone fixed.
     λ = 1 is the native network (bitwise). λ = 0 is the surrogate (bitwise equal to the surrogate applied with
     the additions deleted);
   - segment 2 is v50's path: the surrogate folded into the reading layer, later layers moved to f0's, ending at
     the extraction (bitwise).

   `fold_paths.csv` reports each segment's worst point and barrier, and the combined sampled maximum against the
   two ends (native and extraction), for error and cross-entropy separately. For the zero surrogate, segment 1 is
   the gate-scaling edge of the v47 grid.

## Claims in CHANGES_v50.md that are replaced

- "The affine fold keeps native error, so the compact network keeps the function" is wrong as stated. Equal error
  is accuracy retention on the stated distributions. Functional agreement (disagreement, logit and probability
  distance) is reported separately and decides the second claim.
- "The fold stays near the deletion's error, so the later layers need the nonlinear output" does not follow. This
  least-squares fit on training activations failed; conditioning, distribution shift, the fitting objective and
  downstream sensitivity are alternatives. The diagnostics in item 4 are there to tell them apart.
- "A small fold-to-extraction barrier means the v47 interior was not a real barrier" does not follow. It is a lower
  observed barrier along a different, sampled route. Five points per segment do not establish a continuous low-loss
  path.
- "Deletion is free" is replaced by: no gradient repair and no extra inference parameters, at the stated fit cost.
- The primary criterion (native, source validation) stays. It is still exploratory on these already inspected
  checkpoints and needs fresh draws to confirm. The average 8.24 against 7.07 does not determine per-run selection.
- Folding itself is established (ExpandNets, FuseInit, Layer Folding). A successful fold here would be an
  explanation of the dependence, not a new compression method.

## Correction to the proposed mechanism, and a first diagnostic

In the v50 notes I suggested that expansion fits "the 5% of examples where the shortcut disagrees". That was
imprecise in two ways:

- The generator has two independent mechanisms: shortcut agreement (`rho_train`) and a rare group (`rare_prevalence`)
  whose labels follow another rule. They are different examples.
- At rho = 1 the observed shortcut still carries Gaussian noise, so the effect need not vanish there. A clean
  boundary needs rho = 1 with `shortcut_noise` = 0 as a separate condition.

The mechanism is untested, and f0's stationarity under the training loss has not been shown.

`--train-diagnostics` measures the first part on existing checkpoints (`train_groups.csv`, `f0_gradients.csv`,
`first_layer_change.csv`):

- **Training error and loss by subgroup**, for f0 and each expansion end: training error, mean loss, loss share and
  margins. Subgroups: observed shortcut sign agrees or disagrees with the label, majority or rare group, their four
  combinations, and f0-correct or f0-error examples.
- **f0's training gradient by subgroup** (full batch; subgroup contributions add up to the total, which is
  checked): its norm over all parameters and on the causal and shortcut input blocks, the derivative of the loss
  with respect to a gain on each block, and its component along each variant's actual causal-block change.
- **Each variant's first-layer change**: causal and shortcut norm ratios, and how much of the causal change is pure
  scaling.

Limits: "agrees" uses the observed shortcut sign, since the generator's latent variable is not stored. The
gradients are f0's only. Gradients of expanded checkpoints need the branch masks and are not computed here. A
small total gradient can hide opposing subgroup gradients, which is why they are reported separately.

## Tests

- tests/test_v51.py on real miniature outputs:
  - both segments and their bitwise ends;
  - the per-partition implementation check;
  - the fit diagnostics;
  - the saved fit rebuilt into the folded tensors;
  - each wrong fold failing through the real pipeline;
  - the three size measures;
  - the training diagnostics recomputed independently from the checkpoint.
- Unit tests: a dense rank-1 change (every entry changed, small factor storage), zero change, the fold algebra
  including a residual the receiving layer cannot see, an unsupported merge, and the decision comparison where equal
  error with different predictions must fail.
- tests/test_v51_launcher.py: `cuda` and `cuda:0`, a skipped CUDA test stopping the run, and the report in the
  archive.
