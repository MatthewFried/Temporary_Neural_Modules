# v51 -> v52: gain scan, the expansion's time course, aligned paths (analysis only)

Semantics unchanged: `cop-7.21.0`. `cop/` is untouched.

Run `scripts/52_v52_channel_course.sh`. It reads the v46 wave-25 panel (`~/cop_results_v46/panel25`) read-only and
writes only `~/cop_results_v52`. This is an exploratory reanalysis of existing checkpoints. `scripts/51` stays
valid and its tables are not recomputed. RESULTS_v51.md is the write-up of the v51 run. It withdraws the
"expansion fits f0's remaining errors" explanation.

## Training jobs

None changed. None run.

## New parts of audit_v5/tools/coordinated_edits.py

1. **Gain scan** (`--gain-scan`), on f0 only. One input block of the first layer (causal, or the shortcut column)
   is multiplied by each gain in a declared grid: 0.9, 0.95, 1, 1.05, 1.1, 1.25, 1.5, 1.75, 2, 3, 4.
   - `f0_gain_scan.csv`: training loss and error, each subgroup's contribution to the loss, and every evaluated
     error, at each gain.
   - `f0_gain_fd.csv`: the autograd derivative of the loss with respect to the log-gain against a central finite
     difference (gains exp(∓0.01)), per subgroup. Disagreement of the total beyond 10% (or 5e-5) is listed in the
     coverage file and does not stop the run.
   - `f0_gain_optimum.csv`: the grid point with the lowest training loss and with the lowest errors. Descriptive
     only: nothing is selected for use.

   This shows how far the training loss falls along the gain direction and what the errors are there, before any
   gain-only training is run.
2. **Time course** (`--age-course`): every saved trajectory state with additions (each round at insertion, the
   configured snapshots, the end). Each checkpoint is validated and its age checked against the configuration.
   Per state:
   - expanded network: errors, training loss, training error and median margin;
   - deletion and extraction errors;
   - the additions' output: size relative to what it reads, constant share, affine R² and nonlinear share on held-out
     partitions, and the fitted map's largest singular value and top-1 and top-2 energy shares;
   - the affine fold: error, difference to the expanded network, disagreement, and the implementation check;
   - the fold with the map cut to rank 1, 2 and 4, with the constant refitted to keep the training mean;
   - the top direction the map reads, as one number per example: its correlation with the label, its error as a
     one-threshold classifier (threshold from training class means), and its correlation with the expanded
     network's margin, f0's margin and the shortcut feature;
   - first-layer causal and shortcut norm ratios, and each later layer's change relative to f0 with its top-1 share.

   At the first insertion the additions' output is exactly zero and nothing is fitted.
3. **Aligned paths** (`--aligned-paths`): the folded network's later layers moved to f0's after aligning its hidden
   units to the extraction's.
   - Modes: none, positive rescaling (each unit scaled to the matched unit's RMS activation), permutation (optimal
     assignment on activation correlation), and both.
   - Alignment uses training activations and applies to layers after the shared first layer.
   - Both transforms preserve a ReLU chain's function in exact arithmetic. The aligned start is checked against the
     folded network (relative logit difference ≤ 1e-4, every partition), and the end is the extraction bitwise.
   - The tool first checks that the compact network is the plain ReLU chain these transforms assume.
   - Reported per mode: the sampled barrier, the units moved, the matched correlations and the scale factors.

## Launcher and tests

- `scripts/52` runs only these parts. On a CUDA device the CUDA test for these parts must run and pass first
  (decisions compared with the CPU analysis).
- tests/test_v52.py on real miniature outputs:
  - the gain scan against f0 scaled by hand, and the derivative recomputed;
  - the time course's ends against the v51 fold, training and first-layer tables;
  - the rank folds and the readout rebuilt from the saved fit;
  - the unaligned path equal to v51's fold path;
  - saved decisions;
  - a wrong-age and a missing intermediate checkpoint failing the group.
- Unit tests: the alignment recovers a hidden permutation and scaling and preserves the function.

## What each part could show (stated before the run)

- **Gain scan.** If the training loss keeps falling to gains near what the expansions reached (1.6 to 2), compact
  gain-only training has somewhere to go and its result is informative either way. If the loss minimum sits near 1,
  the local derivative overstates how far a gain can move under the training loss.
- **Time course.**
  - When the additions become nearly affine and high gain, and when folding starts to preserve performance. If
    they are affine from the earliest snapshot, the nonlinearity was not used at any saved time.
  - Whether training loss rises early or late, and whether the extraction's gain tracks the causal norm ratio.
  - Whether a rank-1 fold is enough, and whether the single number it reads already separates the classes.
- **Aligned paths.** If the barrier largely disappears under rescaling or permutation, it was a coordinate
  effect. If it persists under these specific alignments, the path result is narrower but stands for them. Other
  alignments and curved paths remain untested.
