# v52 -> v53: the wave-26 panel (what drives the expansion's drift)

Semantics unchanged: `cop-7.21.0`. No file under `cop/` outside the manifest builders (`cop/orchestration/`) changed,
so the semantic code hash is still v45's (`1f5f72b51291d08a`, pinned by a test) and every earlier run id is
unchanged. `scripts/48`, `scripts/51` and `scripts/52` stay valid.

Run `scripts/53_v53_drift_panel.sh` from the v53 folder. It trains the panel and analyses it, and writes only
`~/cop_results_v53`. A stopped run continues when the same command is run again. RESULTS_v52.md is the write-up
of the v52 run.

The question: in wave 25 the additions' output grew to many times the activations it joins, the training loss
rose about twentyfold and the first layer's causal columns grew (RESULTS_v52.md). Routed gradients, the
nonlinearity, the learning rate and the number of updates were confounded there. Wave 26 varies them one at a
time from the same f0.

## Training jobs (the job system; configurations only, no training code changed)

Wave 26: 600 jobs. Data draws 337 to 348 (checked unused in every earlier wave at every scale), optimizer seeds 0
and 1. Per draw and seed there is one f0 and, from it:

1. **Ten expansions to 2U** (2 rounds of 2000 updates, the wave-25 schedule, snapshots and audits). They share
   the minibatch stream and the insertion initialization (checked in the analysis).
   - Hold: A holds nothing; B holds the first layer's shortcut column at f0 (`train.freeze_inputs=shortcut`).
   - Gradient route: `routed` is wave 25's (each addition receives the gradient of its own fixed random part of
     the examples, `growth.spec_partition=random_matched`); `all` gives every addition every example's gradient
     (`spec_partition=all_examples`: the same graph, masks all ones).
   - Additions: `relu` is wave 25's; `affine` sets their activation to the identity (`growth.act=identity`), so
     each addition is B(A h + a) + b with the same widths, parameters and initialization.
   - The eight combinations, plus the routed relu arm of each hold at 0.3 times the learning rate
     (`A_routed_relu_lr0.3`, `B_routed_relu_lr0.3`).
   - `B_routed_relu` has wave 25's B configuration exactly (asserted by a test), on new draws.
2. **Ten removals**, one per expansion: wave 25's linear removal with the hold lifted (secondary; the analysis
   tools reach an expansion's end state through its removal job).
3. **Four compact controls**: f0 continued for 4U updates with the hold kept throughout, the optimizer carried,
   one minibatch stream, states saved at the expansions' snapshot times, at 2U and every U/2 after it.
   `compact_A`, `compact_B`, and both at 0.3 times the learning rate. 4U is twice the expansion's updates and at
   least its training compute (about 1.03 times, backward-aware analytic estimate; the analysis reads the ratio
   from the run's counters and fails if it is below 1).

Not in wave 26: wave 25's C and D holds, the phase-matched compact control (the removal's reset schedule), a
gradient-clipping arm (no gradient scale is known from which to set a threshold).

## Training outside the job system (new: audit_v5/tools/gain_training.py)

Gain-only training of f0. f0's first-layer weight is W0 with its input columns multiplied by gains; the gains start
at 1 and only they are trained, for 2U updates, with the f0 job's optimizer settings (AdamW, learning rate 0.001,
batch 128; no weight decay on a gain). Every other tensor stays f0's.

- The minibatches are the expansions': the trainer is cop's own, started from f0's saved trainer state, and its
  hash chain of example ids must equal every expansion's, or that f0 fails.
- Three modes, each a separate training:
  - `causal_scalar`: one gain on the causal block (uses the feature layout). The v52 scan is this mode's loss curve.
  - `per_column`: one gain per input column (no feature labels).
  - `per_column_shortcut_held`: the same with the shortcut column's gain held at 1 (the B arms' access).
- Gains of 1 must reproduce f0 on every evaluated partition. Each evaluated network is a compact network of f0's
  architecture and is checked against the forward pass used in training.
- Float32 training depends on the device. Gains trained on the CPU and on the GPU are not required equal.

## Analysis only

1. **audit_v5/tools/selective_reversal.py** (schema `selective_reversal/v53`).
   - `--paired-vary section.key,...` (with `--paired-streams`): the settings in which a design's trajectories
     differ on purpose are left out of the configuration that must be equal across the trajectories of one f0 and
     seed. The stream, the insertion initialization and f0 must still be equal. Without it wave 25 is unchanged.
   - Compact controls are grouped for the fork-equality audit by their training settings too (apart from the
     holds). Controls at different learning rates share f0 and the stream, not their states.
   - Registry `wave26` (85 contrasts, none primary). One extraction throughout (first layer kept, layers 2 to 5
     f0's, additions deleted): on an expansion at 2U, on a compact control at 2U and at its end (4U).
     - per arm: the extraction against f0, against its matched compact control's extraction at 2U and at 4U,
       against the expanded network and against the repaired endpoint;
     - the factors: affine against relu given each route, all against routed given each activation, on the
       extraction and on the expanded network, and their interaction;
     - the lower rate: against the base rate, and the difference in the excess over the matched compact control;
     - B against A within each arm; each compact control's extraction against f0 and at 4U against 2U.
   - `--contrasts` no longer needs `--decompose` when the registry holds only code-table contrasts.
2. **audit_v5/tools/coordinated_edits.py**: unchanged. Without `--expect-variants` the design's variants come from
   the manifest. Wave 26 forms five experiments (route x activation, and the lower rate), each with A and B.
3. **audit_v5/tools/panel26_tables.py** (new). It reads the other tools' per-run tables and the manifest, and
   evaluates nothing. The design comes from the configurations, not from names.
   - `arm_contrasts`: every pair of arms that differ in exactly one factor (15 pairs), at every checkpoint, for 16
     quantities (errors of the expanded network, the deletion and the extraction, training loss, error and margin,
     the additions' size, the map's largest singular value and top-1 share, the affine share, the fold's cost, the
     first layer's norm ratios, layer 2's change).
   - `course`: every expansion checkpoint and every compact state on the update clock, with the training cost.
   - `excess`: an expansion's extraction minus its matched compact control's at the same update, and at 2U
     against the compact control at the first saved update with at least the expansion's compute.
   - `gain_contrasts`: the gain-trained f0 against f0, every expansion's extraction and every compact control's.
   - A pair the design holds with a value missing on one side fails the run.

## Launcher and tests

- `scripts/53_v53_drift_panel.sh`: environment, manifest, validation, CPU tests; on a CUDA device the suite's CUDA
  tests and the wave-26 tools' agreement test, each checked to have run; the panel; status, result checks, fresh
  reload, strict summary, timing; the four analyses (`reversal26` on the CPU, `edits26` and `gains26` on DEVICE,
  `tables26`); evidence; packaging. The trace evaluates three codes away from 2U (the state, the extraction, f0).
- tests/test_v53.py, on a real miniature wave 26 run through the launcher's own command lines:
  - the manifest's structure, the unused draws, the unchanged semantic hash;
  - one stream and one insertion initialization for all ten arms and the four compact controls; the audit failing
    without the declared factors; the fork groups by learning rate;
  - every registry contrast recomputed from the code tables;
  - affine additions fitted exactly by an affine map at every checkpoint; all-example masks leaving every addition
    gradient unmasked;
  - gain training against an independent implementation (plain forward pass, torch's AdamW), its stream check,
    and its failure when an expansion drew other minibatches;
  - the paired tables recomputed from their inputs, and their failure on a missing partner;
  - the CUDA analyses against the CPU's, decision by decision.
- tests/test_v53_launcher.py: the launcher's order, device forwarding, the CUDA tests before any training, and its
  failure paths (manifest, tests, an unfinished panel, a failed analysis, an empty required table, stale outputs).
- Also run here: the whole pipeline on a two-draw smoke-scale panel built by the real manifest builder (strict
  summary, result checks, reload and the four analyses).

## What each comparison could show

- **Affine against relu.** (Reworded in v54.) v52 found the additions' outputs approximately affine in their
  input on the sampled activations at every saved time. If the affine arms reproduce the relu arms' training-loss
  rise, gain growth and extraction, nonlinear additions are unnecessary for those measured outcomes. A difference
  shows the nonlinearity mattered during training.
- **All against routed.** (Reworded in v54.) If only the routed arms show the drift or B's extraction gain, the
  result belongs to routed expansion and has to be stated that way. The two arms differ in which gradients reach
  the additions and the backbone: with all examples, each example's gradient reaches both additions of a round
  instead of one. Twice as many example-to-addition paths does not mean twice the gradient norm (per-example
  gradients can add or cancel). Routing and the amount of gradient are not separated here.
- **Lower learning rate.** If the loss rise shrinks while the extraction's excess over the matched compact control
  stays, the loss rise is not needed for the gain. If both shrink together, this arm does not separate them.
- **Compact controls at 4U.** If compact B's extraction at 4U reaches expansion B's at 2U, the expansion adds
  nothing beyond more training.
- **Gain-only training.** The scan predicts the causal scalar stops near 1.04 with test error near 24.0. The
  per-column modes test whether more freedom along the input gains changes that.
- **B_routed_relu** on new draws is a third replication of the B extraction (24.74 to 19.62 in wave 25). Its
  extraction against f0 and against compact B at 2U are the panel's two primary contrasts (named in v54 before
  any wave-26 result was read; DEVIATIONS 289).
- **Reading an extraction** (added in v54). An extraction that beats f0 is a useful change in an original
  component. It is not evidence of a newly learned feature: a change of strength in weights f0 already had can
  do the same. v54's `component_change.py` separates the two.
