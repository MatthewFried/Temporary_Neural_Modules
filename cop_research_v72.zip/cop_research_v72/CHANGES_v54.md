# v53 -> v54: what changed in the original first layer (analysis only)

**Superseded by v55 (CHANGES_v55.md).** `scripts/54` is retired: its environment step ran a CUDA check, and its tables lacked comparisons its conclusions needed. Run `scripts/55` instead.

Semantics unchanged: `cop-7.21.0`, semantic code hash `1f5f72b51291d08a`. No file under `cop/` changed. No network
is trained. `scripts/48`, `51`, `52` and `53` stay valid, and a v53 run in progress is not affected (it runs from
its own folder; v54 writes only `~/cop_results_v54` and reads the two panels read-only).

Run, while v53 trains (wave 25 only, CPU):

    cd ~/research/cop_research_v54 && WAVES=25 COP_VENV=~/fsc/.venv nohup bash scripts/54_v54_component_change.sh > ~/v54_w25.log 2>&1 &

and after v53 has finished, the same with `WAVES=26` (log `~/v54_w26.log`). Archives:
`cop_v54_change_reports_w25.zip` and `cop_v54_change_reports_w26.zip`. Each choice of `WAVES` has its own reports
folder and archive, so the second run leaves the first alone.

## Why

The working question is what an insertion changes in the original network's own components, and which of those
changes stay useful without the insertion. An extraction that beats f0 answers "useful, in an original component".
It does not say whether the component learned something new or changed the strength of what it had.

Wave 25 already holds a strong hint, from v46's scale controls (12 draws, test error, f0 = 24.74%):

| first layer placed in f0 | A (nothing held) | B (shortcut column held) |
|---|---|---|
| the state's causal block, rest of f0 | 17.46 | 18.27 |
| f0's own causal block at the state's block norm | 18.50 | 17.99 |
| the state's causal directions at f0's row norms | 23.86 | 24.09 |
| f0's causal block times one scalar chosen on val_indep | 10.27 | 10.27 |

f0's own causal weights at the state's norm do as well as the state's causal block, and the state's directions at
f0's norms do about as well as f0. One scalar chosen with target-distribution labels does much better than either
arm. Arm A's whole first layer in f0 gives 24.36.

(Corrected in v56. This section used to conclude that the useful change is a change of strength. The v55 analysis
shows that holds for B's extraction benefit, which is largely reproduced by block scaling, and not in general: A
contains a useful change that is exposed by restoring f0's norms, and both arms improve first-layer decoding
beyond what block scaling gives. See RESULTS_v55.md.)

These were side tables. v54 makes the measurement the main one, adds the two things they lack, and repeats it on
wave 26 when that panel is done.

## Changes that alter training

None.

## Analysis-only changes

1. **`audit_v5/tools/component_change.py`** (new; schema `component_change/v54`). For every f0, the states are f0,
   every expansion at 2U and every compact control at 2U (wave 26: also at 4U). Each state enters only through its
   first layer, placed in f0 with f0's later layers, no repair.
   - `_states`: errors and training loss of each state's first layer in f0; norm ratios and cosines to f0's layer
     for the whole layer and for the causal, shortcut and other input blocks.
   - `_edits`: first layers built with no training, each with its information access written in the row.
     `f0_shortcut_x{0, 0.25, 0.5, 0.75}`: f0 with its shortcut column shrunk. This uses the same knowledge as the B
     arms' hold (which input is the shortcut) and nothing else, so it is B's equal-access baseline. It was missing.
     `f0_at_state_layer_norm`, `f0_at_state_block_norms`: do gains alone reproduce the state?
     `state_at_f0_layer_norm`, `state_at_f0_block_norms`: what is left of the state once the gains are removed?
   - `_probes`: the same linear probe on every state. Features: the first layer's activations, and the
     activations f0's head reads. Targets: the label, and the sign of the shortcut input. Fitted on the training
     set (the readout-only control) or on val_indep (target-distribution labels, marked as such). Raw and
     standardised features (standardising removes per-unit scale). Two penalties. Binary logistic regression
     solved to its optimum in float64; a probe that does not converge fails the run. The raw input is probed once
     per f0 as a reference.
   - `_contrasts`: within f0, an expansion against f0 and against its matched compact control at the same update;
     a compact control against f0; each edit against the state it mirrors; f0 with a shrunk shortcut column
     against every state. Seeds are averaged within a draw; intervals are over draws.
2. **Primary contrasts of wave 26.** The arm that repeats wave 25's B arm (`B_routed_relu`): its extraction's test
   error against f0 and against compact B at 2U. Named in `selective_reversal.py` (`REGISTRY_PRIMARY["wave26"]`,
   schema `selective_reversal/v54`) and marked `role = primary` in `component_change`'s contrasts. They were named
   after the v53 panel was launched and before any wave-26 result was read. If you looked at wave-26 numbers
   before unpacking v54, treat them as exploratory. The v53 run's own registry table will show every role as
   "declared"; the values are the same.
3. **`scripts/54_v54_component_change.sh`** (new). `WAVES` picks the panels (25, 26 or both). Per wave: regenerate
   the manifest, check the panel is complete and of the same semantics, run the CPU tests once, run the tool on the
   CPU, check the evidence, package. An unfinished panel skips the tests and the analysis.
4. **Wording corrections** (the reviewer's five points). RESULTS_v52.md: the AdamW paragraph (the v53 text claimed
   only the gradient's direction matters, which does not follow) and "nonlinearity unused" (the fits show
   approximately affine outputs on sampled activations). CHANGES_v53.md: "plays no part" is now "unnecessary for
   those measured outcomes"; the routing paragraph no longer equates more paths with more gradient; an extraction
   is described as a useful change in an original component. DEVIATIONS 282 reworded.
5. **Tests.** `tests/test_v54.py`: the probe solver against an independent gradient of its objective, separable
   data, scale invariance of standardised probes; the edits' arithmetic; the whole tool on a miniature wave 26 and
   a miniature wave 25 through the launcher's own options, with states, edits, one probe per kind and every
   contrast recomputed independently; failure on a missing compact state. `tests/test_v54_launcher.py`: the real
   script in a mock home (wave selection, separate folders per selection, unfinished or foreign panel, stale
   manifest, failed analysis, empty table, failed tests, nothing written to a panel). `tests/test_v53.py`: the
   registry's roles.

## What each part could show

Withdrawn in v55. The rules that stood here read limited controls as complete explanations (equal errors as
"gains reproduce the state", no gain after normalisation as "nothing useful is left", no probe difference as
"only compatibility", and a shortcut-shrink baseline beating B as "B cannot carry a claim about learning"). The
replacement is "How to read each outcome" in CHANGES_v55.md.

## What was executed here

`tests/test_v54.py` and `tests/test_v54_launcher.py` once (33 tests, passed), and the four `tests/test_v53.py`
tests whose assertions changed (passed). The full suite was not run; no panel was analysed; nothing was trained.
The launcher runs the full CPU suite before it analyses anything.

## Next (not in v54)

The image pilot should wait for wave 26, which says which intervention to carry over (routed or not, ReLU or not).
It needs a semantics bump (a new dataset is semantic code), so it is its own version and cannot share a code
version with analyses of the v46 and v53 panels. Planned shape:

- Data: a CIFAR-MNIST composite (the digit as the competing cue, correlated with the class in training,
  independent in a target split), and the same CIFAR images without the digit as the paired boundary condition.
- Networks: the existing small CNN and CIFAR ResNet builders, same architectures in both conditions.
- Primary arm: no knowledge of which inputs are causal (the analogue of A). Holding a first-layer input weight
  does not isolate a shortcut in a convolution. In the MLP, A's extraction shows no net gain, so the image
  endpoints have to be the internal measures of this version (prefix in f0, equal probes, gains), not accuracy.
- Measure: predefined prefixes (stem; first stage; first two stages) placed in f0, batch-norm running statistics
  travelling with their weights; the same probes on f0, compact continuation and expansion.
- Open risk: routed additions have never been run on convolutional graphs with batch norm. A miniature run is
  needed before any panel, and torchvision data on the lab machine.
