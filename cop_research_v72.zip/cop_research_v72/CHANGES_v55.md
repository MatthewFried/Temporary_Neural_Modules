# v54 -> v55: the component-change analysis, corrected and completed (analysis only)

Semantics unchanged: `cop-7.21.0`, semantic code hash `1f5f72b51291d08a`. No file under `cop/` changed. No network
is trained. `scripts/54` is retired (it refuses to run); `scripts/48`, `51`, `52` and `53` stay valid. v55 writes
only `~/cop_results_v55` and reads the two panels read-only. A v54 run's reports in `~/cop_results_v54` are left
alone; do not use them for conclusions (see "What was wrong in v54").

Run, while v53 trains (wave 25 only):

    cd ~/research/cop_research_v55 && WAVES=25 COP_VENV=~/fsc/.venv nohup bash scripts/55_v55_component_change.sh > ~/v55_w25.log 2>&1 &

and after v53 has finished, the same with `WAVES=26` (log `~/v55_w26.log`). Archives:
`cop_v55_change_reports_w25.zip`, `cop_v55_change_reports_w26.zip`. The fitted probes stay in
`~/cop_results_v55/probes_<tag>` and are not in the archive.

## What was wrong in v54

1. **The launcher was not CPU-only.** Its environment step ran the CUDA training check and a GPU benchmark while
   v53 was meant to have the GPU. Nothing it produced is wrong because of that, but it did not do what it said.
2. **The norm edits were read as a decomposition.** "The state at f0's block norms" keeps the state's bias and its
   spread of norm over units, and removing a gain can remove a useful interaction between gain and direction.
3. **The edits were not probed.** Standardising activations does not undo a gain on input weights (it changes
   which units are active), so "standardised probes beat the compact control" did not yet mean "beyond gains".
4. **One context only.** "Penultimate" meant f0's later layers on the changed first layer. The state's actual
   network was not measured.
5. **Validation gaps.** A compact checkpoint's recorded update was not checked; an expansion without a matched
   compact control dropped out silently; the longer compact control was loaded but not compared; summaries were
   grouped by a short label only.
6. **Outcome rules that claimed too much**, including mine that a shortcut-shrink baseline beating B would mean
   "B cannot carry a claim about learning". That mixed two questions. Whether expansion is needed to reach an
   accuracy is one. What expanded training makes the original layer learn is another, and a cheaper edit that
   reaches the accuracy leaves it open.

## Changes that alter training

None.

## Analysis-only changes

1. **Launcher** `scripts/55_v55_component_change.sh`. `CUDA_VISIBLE_DEVICES=""` and `DEVICE=cpu` are exported
   before anything runs and again after the shared settings; the environment report runs with `--no-cuda`. Passes
   `--save-probes`. Same wave selection and separate folders per selection as before.
2. **Controls** (`_edits`), each row with its control family, information access and construction:
   - `shortcut_shrink`: f0's shortcut column times 0, 0.25, 0.5, 0.75. Construction `training_free`: it needs f0
     and the feature layout only. The baseline is the factor 0 (the known shortcut column removed), fixed in the
     code and not chosen from any result. The other factors are descriptive.
   - `layer_norm`, `block_norm`: as in v54, now named controls.
   - `block_row_norm` (new): one scalar per unit and input block, so unequal changes across units are matched too.
   - `bias` (new): the state's weights with f0's bias, and f0's weights with the state's bias.
   - Construction `needs_trained_state` for everything but the shrink: no optimisation, but a trained expansion
     or control has to exist to read its norms, weights or bias. Only the shrink is a training-free alternative.
   - A norm that cannot be matched (a zero block or row asked to take a positive norm) is counted
     (`n_unmatched`, `norm_match_exact`); v54 reported a ratio of 1 there.
3. **Two representation contexts**, column `representation_context`, never pooled:
   `extracted` (f0 with the state's first layer, f0's later layers) and `native` (the state's actual network: an
   expansion with its additions, a compact control as it is). States get `native_*` errors next to the extracted
   ones. Native probes are on the activations the state's own output layer reads. First-layer activations are the
   same function in both contexts and are probed once.
4. **Probes on the controls.** The same probes are fitted on f0 at each state's block norms, on each state at
   f0's block norms, and on the shortcut-shrink baseline, and contrasted with the state and with f0.
5. **Comparisons.** An expansion against its matched compact control at the same update
   (`expansion_minus_matched_compact`, `matching = same_updates`) and, separately named, against that control
   trained longer (`expansion_minus_matched_compact_longer`, `matching = compact_at_2x_updates`; wave 26). Every
   edit against its state and against f0. Every error difference comes with decision disagreement on test and
   val_indep. The contrast summary records a declared equivalence margin (0.01) and whether the 95% interval lies
   inside it.
6. **Validation.** A compact checkpoint must record the requested update. Every expansion must have exactly one
   compact control with its hold and learning rate, else nothing is analysed. Non-finite features, coefficients
   or scores fail the run. Tables are grouped by `design_id` (data without seeds, architecture, f0's training,
   the arm set) as well as the label.
7. **Saved probes.** Per f0: coefficients, intercept, fit-set mean and scale, decisions on every evaluated
   partition, with an index (network, context, target, penalty, source checkpoint, first-layer hash, split
   hashes). The file is read back and checked against the tables before the f0 counts.
8. **Wording.** A probe is "fitted until max |gradient| is at most 1e-6", not "solved to its optimum".
   CHANGES_v54.md's outcome rules are replaced by the ones below.
9. **Tests.** `tests/test_v55.py` and `tests/test_v55_launcher.py` replace the v54 files. New cases: a compact
   checkpoint recording another update; a missing and an ambiguous matched control; native and extracted
   contexts kept apart (features, probe rows, summaries); a bias-only change; a pure input gain under
   standardised probes; saved probes applied to features rebuilt from the checkpoints; two experiments sharing a
   label; the real wave-25 and wave-26 manifests (one design identity, every arm matched); the launcher with a
   shell and settings that ask for CUDA.

## How to read each outcome

| Observation | What it supports |
|---|---|
| f0 at the state's norms has the state's error | Gains reproduce its error rate on that partition. Check the disagreement column: predictions and internal computation can still differ. Equivalence needs the interval inside the margin. |
| The state at f0's norms is no better than f0 | No benefit was detected under this normalisation and this evaluation. The control also keeps the state's bias; see the bias controls. |
| Probes on the state match probes on f0 at the state's norms | These probes detect no accessibility beyond what the norm control gives. Other explanations remain. |
| Probes on the state beat probes on f0 at the state's norms | Evidence of a change these gains do not reproduce, in the named context only. |
| The shortcut-shrink baseline matches or beats B's extraction | With knowledge of the shortcut input, this accuracy does not need an expansion. What expanded training changes in the layer is still a separate question. |
| Extracted and native probes disagree | The original later layers and the trained later layers express the first-layer change differently. Report both. |
| Expansion beats the compact control at the same update but not the longer one | The difference is not separable from more training on this measure. |

A reweighting of existing features is a legitimate finding about learning. The open question it leaves is why
this intervention produces it when the compact model's training loss does not favour moving that way.

## What was executed here

`tests/test_v55.py` and `tests/test_v55_launcher.py` once (44 tests, passed), because the launcher refuses to
analyse when a test fails. One timing of a single probe fit at the panel's size (about 10 to 20 ms; wave 26 has
about 50,000 fits). The full suite was not run; no panel was analysed; nothing was trained.

## Next

The image pilot, as its own version (a new dataset is semantic code). Carried over: the original routed treatment
as a fixed replication arm, an ordinary-gradient expansion beside it, compact continuation matched by updates and
by compute, the same contexts and probes as here. Outcomes fixed in advance: feature measurements as the central
ones, with native, extraction and contraction accuracy always reported. It needs torchvision data on the lab
machine and one miniature run, since routed additions have not been run on convolutional graphs with batch norm.
