# v55 -> v56: complete controls, the layer and age course, the update diagnostics (analysis only)

Semantics unchanged: `cop-7.21.0`, semantic code hash `1f5f72b51291d08a`. No file under `cop/` changed. No network
is trained. `scripts/54` and `scripts/55` are retired; `scripts/48`, `51`, `52` and `53` stay valid. v56 writes only
`~/cop_results_v56` and reads the two panels read-only. Earlier reports are left alone.

Run (both panels are complete now):

    cd ~/research/cop_research_v56 && COP_VENV=~/fsc/.venv nohup bash scripts/56_v56_backbone_change.sh > ~/v56.log 2>&1 &

Archive: `cop_v56_reports_w25_26.zip`. `WAVES=25` or `WAVES=26` runs one panel into its own folder and archive.
Expect the CPU test suite first, then roughly 30 minutes for wave 25 and 70 for wave 26.

Results so far are in **RESULTS_v55.md** (wave 26's extraction result and wave 25's component analysis).

## Changes that alter training

None.

## Analysis-only changes

1. **Norm controls with f0's bias** (`component_change.py`, schema `component_change/v56`).
   `state_at_f0_block_norms_f0_bias` and `state_at_f0_block_row_norms_f0_bias`: the state's weights at f0's norms
   with f0's bias, so scale and bias are both controlled. Each is contrasted with its state-bias twin
   (`f0_bias_minus_state_bias`), with f0 and with the state.
2. **More controls probed.** The block-row norm controls in both directions and the two f0-bias controls are now
   probed, next to the block-norm controls and the shortcut-shrink baseline.
3. **`audit_v5/tools/layer_course.py`** (new, schema `layer_course/v56`). The same probe (fitted on val_indep,
   standardised, both penalties, label and shortcut sign) at every backbone layer below the output layer, at every
   saved state: f0, each expansion at each insertion, each snapshot and its end, each compact control at its saved
   updates. Three contexts, never pooled:
   - `extracted`: f0's layers on the state's first layer.
   - `native`: the state's own network. At the merge there are two values: `layer2` is what the additions read,
     `layer2_post_merge` is what the next backbone layer reads.
   - `folded`: expansions only, the additions replaced by their affine fit and folded into the next layer; layers
     after the merge.
   Contrasts: a state against f0; an expansion against its matched compact control at the same update; native
   against extracted at the same layer; after the merge against before it.
4. **`audit_v5/tools/routing_updates.py`** (new, schema `routing_updates/v56`). At every snapshot and at the end of
   every expansion:
   - the last AdamW step, recomputed exactly from the saved optimizer state, with the trainer's holds applied
     (the optimizer keeps momentum for a held column; the trainer restores it after every step);
   - the ordinary full-batch gradient and the routed full-batch gradient at the parameters before that step;
   - per parameter group (first layer and its causal, shortcut and other columns; backbone up to the merge;
     backbone after it; additions; all): norms, the cosine between the two gradients, the cosine of the step with
     each, each group's share of the first-order change in the ordinary training loss, the weight norm before and
     after, and whether the step and the gradients point along the weights;
   - per state: the ordinary training loss before and after the step, the first-order prediction and the
     remainder.
   Built-in checks: routing leaves the forward value and the gradients after the merge unchanged; masks of ones
   give the ordinary gradient; an all-examples arm's routed gradient is its ordinary gradient.
   Compact controls are not included (their saved states carry no optimizer state). The all-examples arms are the
   ordinary-gradient expansions.
5. **`audit_v5/tools/f0_panel.py`** (new): the shared, validated view of a panel that the two new tools use.
6. **Launcher** `scripts/56_v56_backbone_change.sh`: the three tools per wave, CPU only. The per-row probe and
   contrast tables are checked as evidence and stay on disk; their per-draw and summary tables are archived.
7. **Write-up.** RESULTS_v55.md states the results in the corrected form. CHANGES_v54.md's "Why" no longer says the
   useful change is a change of strength. DEVIATIONS 289 now says the wave-26 primaries were named before the
   panel ran (it ran from the v55 folder).
8. **Tests.** `tests/test_v56.py` (component analysis, extended), `tests/test_v56_course.py` (new: the course's
   probes refitted from the checkpoints in every context; the reconstructed step against a real optimizer and
   against two consecutive saved updates; the routed gradient rederived from per-example sums; the held column),
   `tests/test_v56_launcher.py`.

## The earlier routing comparison

The reviewer asked to recover the parameter-only against full-path comparison before adding experiments. The code
is here: `growth.spec_mask_route = parameter` (v26, wave 20, `scripts/26_v26_panel.sh`), where only the additions'
parameters are masked and every example's gradient still reaches the backbone through both additions. No v26
result archive is among the files this analysis has seen, so nothing is recovered yet. If `~/cop_results_v26`
exists on the lab machine, its reports are the place to look. Two limits apply to them: they were run under
earlier semantics, and they have no extraction or probe endpoints.

(v57: checked on the lab machine. `~/cop_results_v26` does not exist and no result folder holds a parameter-route
run, so there was nothing to recover. The sentence that stood here, that the parameter route needs affine
additions, was wrong: it needs the additions' parametric nodes to be linear layers, which relu additions have.
The comparison is the wave-27 panel, CHANGES_v57.md.)

## What each new part could show

- **f0-bias controls.** If A at f0's norms with f0's bias is still better than f0, the useful residual change is in
  the weights. If the gain disappears, it was carried by the bias.
- **Layer course.** At which layer the native label probe turns from better than f0 to worse, whether that
  happens at the merge (after against before), and at which age. If the folded network matches the native one,
  the additions' nonlinearity is not what changes the later layers.
- **Update diagnostics.** Whether the step lowers the ordinary loss to first order (negative prediction) while
  the loss still rises (positive remainder: step size and curvature), or is misaligned with the ordinary gradient
  to begin with; which parameter group carries that; whether the first layer's growth is along its own weights
  and whether the routed gradient asks for it more than the ordinary one.

Each outcome is informative. None is the wanted one.

## What was executed here

`tests/test_v56.py`, `tests/test_v56_course.py` and `tests/test_v56_launcher.py` (57 tests, passed), because the
launcher refuses to analyse when a test fails. Running them found a real error before delivery: the optimizer
keeps momentum for a held column, so the reconstructed step was non-zero where the trainer restores the weights.
The full suite was not run; no panel was analysed; nothing was trained.

## Next

1. Run v56 on both panels and read: the A norm-restoration result and the early-against-late probe separation on
   wave 26's new draws, by arm (routed or not, ReLU or affine).
2. Decide from the update diagnostics which small continuation experiment the routing question needs.
3. The image pilot (composite task, small CNN then a residual network, routed and ordinary-gradient expansions
   together, internal measures and extraction next to accuracy), as its own version with a semantics bump.
