# v56 -> v57: the parameter-route panel (wave 27)

Semantics unchanged: `cop-7.21.0`, semantic code hash `1f5f72b51291d08a` (a manifest builder is not semantic code;
the parameter route itself has been in the code since v26). `scripts/56` stays valid and a v56 run in progress is
not affected. v57 writes only `~/cop_results_v57`.

Run (it can run while v56 uses the CPU; this one needs the GPU):

    cd ~/research/cop_research_v57 && WORKERS=3 COP_VENV=~/fsc/.venv nohup bash scripts/57_v57_route_panel.sh > ~/v57.log 2>&1 &

Archive: `cop_v57_panel_reports.zip`. A stopped run is continued by the same command.

## Why

Routing, as run in waves 25 and 26, does two things at once. A masked example's gradient stays out of an addition,
so (1) each addition's parameters are trained on its own part of the examples, and (2) the backbone below the
additions receives each example's gradient through one addition only. Wave 26 shows the large first-layer change
needs routing. It does not say which of the two.

The parameter route (`growth.spec_mask_route = parameter`, v26) keeps (1) and drops (2): only the additions'
parameters are masked, and every example's gradient reaches the backbone through both additions. No results for it
existed: `~/cop_results_v26` was never produced, and no result folder on the lab machine holds a parameter-route
run. So this is a new panel.

## Changes that alter training

1. **Wave 27** (`wave27_v57_panel`): wave 26's draws (337 to 348), seeds (0, 1), f0, protocol and split; relu
   additions; per f0 six expansions:

   | arm | route | new? |
   |---|---|---|
   | A_routed_relu, B_routed_relu | gradient route (waves 25, 26) | wave 26's jobs |
   | A_param_relu, B_param_relu | parameter route | new |
   | A_all_relu, B_all_relu | no routing | wave 26's jobs |

   A: nothing held. B: the first layer's shortcut column held. Plus compact_A and compact_B (wave 26's jobs).
   360 jobs; 96 are new (48 expansions and their removals).
2. **264 jobs are wave 26's own jobs**, in the manifest with their configuration unchanged, so they have the same
   run ids and their checkpoints' lineage holds. `scripts/seed_panel.py` copies those finished runs from
   `~/cop_results_v53/panel26` into this panel's folder. The v53 folder is only read. A run is copied only if it
   is complete, valid, written by code of the same semantics and has exactly the manifest's configuration.
   `SEED=0` trains all 360 instead. Without the v53 folder, all 360 are trained.

Correction to what I said before the build: the parameter route does not need affine additions. It needs the
additions' parametric nodes to be linear layers, which they are with relu additions too. So the panel uses the
original relu treatment.

## Analysis-only changes

1. **Registry `wave27`** in `selective_reversal.py` (schema `selective_reversal/v57`): each arm's extraction
   against f0, against its compact control at 2U and 4U and against its own expanded network; the three route
   contrasts (param against routed, param against all, routed against all) on the extraction and on the expanded
   network, per hold; B against A per route. Two primary contrasts, named before any wave-27 job ran:
   `S_B_param_relu_extraction_vs_f0` and `R_B_param_vs_routed_extraction`.
2. **`routing_updates.py`** (schema `routing_updates/v57`) handles the parameter route and checks its meaning on
   every state: the backbone's routed gradient must equal its ordinary gradient. New columns `mask_route` and
   `routed_vs_ordinary_backbone_grad_diff`.
3. **`component_change.py`** (schema `component_change/v57`): `--primary-variants` names a panel's own primary arm.
   Here it is `B_param_relu`; the repeated wave-26 arms are not marked primary a second time.
4. **Launcher** `scripts/57_v57_route_panel.sh`: tests, seed, train, status, checks and fresh reload of every job
   (copied or new), then four analyses on the CPU: the reversal tool with the registry, the component analysis,
   the layer course, the update diagnostics.
5. **Tests**: `tests/test_v57.py` (the builder; the registry; a trained miniature with all six arms through the
   launcher's own options; the parameter route rederived from per-example sums; the seeding script, including
   that a seeded copy is analysed with identical output) and `tests/test_v57_launcher.py`.

## What each outcome would show

On B's extraction (wave 26: routed 5.71 points better than f0, all-examples 0.38):

- **param is like routed**: training the additions' parameters on separate parts is enough. Which gradient the
  backbone receives through the additions is not what matters.
- **param is like all**: what matters is that the backbone receives each example's gradient through one addition
  only.
- **param is in between**: both contribute.

The same reading applies to the first-layer norm growth, the training-loss rise (0.64 routed, 0.00 all) and the
probe results, which the three CPU tools report for all six arms.

Limits: one task and architecture; the routed and all arms here are wave 26's runs, so only the param arms are new
evidence; relu additions and the base learning rate only.

## What was executed here

`tests/test_v57.py` and `tests/test_v57_launcher.py` (31 tests), the v56 test files again after the tool changes
(57 tests) and the four `tests/test_v53.py` tests touched: all passed. The real wave-27 manifest was generated and
validated (360 jobs, 264 identical to wave 26's). The full suite was not run; no real panel job was trained.

## Runtime and disk

96 new jobs should take about an hour with `WORKERS=3`. Around that: the test suite, copying 264 run folders (a few
GB; the size is printed in `seed27.txt`), the reload check of all 360 jobs, and the four analyses. Expect three to
four hours in total, more while v56 is using the CPU.
