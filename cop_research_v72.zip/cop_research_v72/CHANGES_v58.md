# v57 -> v58: forks from identical networks (wave 28) and the merge geometry

Semantics unchanged: `cop-7.21.0`, semantic code hash `1f5f72b51291d08a`. `scripts/56` and `scripts/57` stay valid;
a v57 run in progress is not affected. v58 writes only `~/cop_results_v58`; it reads the v53 panel only.

Run it after v57 has finished (both train on the GPU):

    cd ~/research/cop_research_v58 && WORKERS=3 COP_VENV=~/fsc/.venv nohup bash scripts/58_v58_fork_panel.sh > ~/v58.log 2>&1 &

Archive: `cop_v58_panel_reports.zip`. Expect about four hours (tests, copying 72 wave-26 runs, about two hours of
training, checks, two CPU analyses).

Results of v56 are written up in **RESULTS_v56.md**, with the reviewer's corrections.

## Changes that alter training

1. **Wave 28** (`wave28_v58_panel`). From wave 26's routed affine trajectories (A and B), at snap_1000 and snap_2500,
   four continuations of the same network to 2U (keep forks, an existing removal kind; same minibatch stream):

   | continuation | additions | gradient below the merge | optimizer |
   |---|---|---|---|
   | routed_reset | trained | routed | fresh |
   | ordinary_reset | trained | ordinary (masks released) | fresh |
   | frozen_reset | frozen at the fork | ordinary | fresh |
   | routed_carry | trained | routed | carried from the parent |

   B keeps its held column. 456 jobs: 24 f0 and 48 trajectories are wave 26's own jobs (copied from the v53 panel
   by `scripts/seed_panel.py`), 384 forks are new.

   **Exact folding followed by compact training was asked for and is not in this panel.** The fold refuses the
   additions' gradient-mask nodes (forward identity, but not in the code's list of affine operations), and changing
   that list is a change to the training code's semantics, which would give every job a new run id and stop the
   reuse of wave 26. `frozen_reset` is a frozen affine scaffold with ordinary gradients: the additions are a fixed
   map h -> A h + c between layers 2 and 3. It computes the folded network's function at the fork, but it does not
   train as the compact network: layer 3 trains through the fixed map (with SGD its effective weight moves by
   -lr (G A^T A + gb c^T A) instead of -lr G; Adam differs too), and a singular A restricts the weights it can
   reach. (Corrected in v59, which adds the folded continuation: CHANGES_v59.md.)

## Analysis-only changes

1. **`audit_v5/tools/fork_continuation.py`** (schema `fork_continuation/v58`). Per f0, parent and fork point: the
   start, each continuation's end, the trajectory's own end, and f0. For each: the network's own errors and training
   loss; its first layer in f0; the same with f0's norms per unit and block and f0's bias, and with f0's block norms
   and f0's bias; norm ratios and cosines; label probes (val_indep fit, both penalties, standardised and whitened) on
   the first layer, on the normalised first layer, and on the network's own layer 2, after the merge, layer 3 and
   layer 4. Contrasts: each continuation against the start and against routed_reset; routed_carry against
   routed_reset; the trajectory's end against routed_carry.
2. **`audit_v5/tools/merge_geometry.py`** (schema `merge_geometry/v58`), run on the v53 wave-26 panel. For every
   expansion state:
   - the whole pre- to post-merge map A = I + M, fitted on the training set (exact for affine additions, checked
     on test): singular values, condition number, rank, and the same on the span of the activations;
   - for affine additions: every pre-merge probe carried through A^-1 to the post-merge features, with the largest
     score difference against the pre-merge probe and its test error next to the probe fitted on the post-merge
     features directly;
   - probes with whitened features (principal axes of the fit set at unit variance; fitted on val_indep only). An L2
     probe on whitened features does not see any invertible linear map of them, so pre- and post-merge whitened
     probes of an affine merge should agree. Standardised probes are kept beside them.
   Plus f0 and the compact controls at 2U; contrasts after against before the merge, fitted against transported,
   whitened against standardised, against f0, and expansion against its matched compact control.
3. **`routing_updates.py`**: its description now states that the update is the historical last step, reconstructed
   from the optimizer state (to verified numerical tolerance, not exactly: corrected in v59), and that the gradients
   and the loss change are full-batch diagnostics at the parameters before that step. No output changed.
4. **Launcher** `scripts/58_v58_fork_panel.sh`: tests, seed, train, then the wave-26 panel check and the geometry
   analysis, then status, checks, fresh reload, strict summary and timing of wave 28, then the fork analysis. Both
   analyses on the CPU.
5. **Tests**: `tests/test_v58.py` (the builder; a trained miniature of all 16 fork kinds: masks, optimizer, frozen
   additions, held column, one minibatch stream; the result checker, fresh reload and strict summary on it; the fork
   analysis recomputed; the whitening invariance on random data; the merge geometry on a miniature wave 26 with
   affine and ReLU arms, transport checked and recomputed) and `tests/test_v58_launcher.py`.

## What each part could show

(Wording corrected in v59.)

- **Fork continuations.** If the first-layer measures (normalised extraction, first-layer probe) keep improving under
  ordinary_reset as much as under routed_reset, continued routing is not needed after the fork, for these
  checkpoints, budgets and optimizer settings. If only routed_reset continues, continued routing matters under those
  same conditions; that is not a general statement about routing. An improvement under frozen_reset does not show
  that the backbone alone carries what is needed: the frozen additions stay in the forward pass and shape its
  updates (v59 adds the folded continuation for that). routed_carry against routed_reset shows how much the
  optimizer state matters. The two fork points show whether that depends on how far the change has gone.
- **Merge geometry.** If the transported pre-merge probe keeps the pre-merge error while the probe fitted after the
  merge is worse, the merge makes the same information harder for the fitted probe to find: a geometry effect. A
  rank loss of the map, or worse probes after the merge, does not by itself show that task-relevant information is
  lost: a lost direction may carry nothing about the label, and a worse probe may come from the fit (penalty,
  conditioning, finite samples). The v58 map was a least-squares fit, which cannot certify the implemented map's
  rank; v59 takes it from the graph. Whitened probes compare only under the conditions v59 records. Later layers
  (ReLU) can add a deficit the merge itself does not.

## What was executed here

`tests/test_v58.py` and `tests/test_v58_launcher.py` (32 tests) passed; one miniature run of the four fork kinds
from a snapshot while building (which is how the fold limitation was found). The real wave-28 manifest was generated
and validated (456 jobs, 72 identical to wave 26's). The full suite was not run; no real job was trained.

## Next

The image pilot as v59, with a semantics bump: CIFAR-MNIST composite and the same CIFAR without the digit, a small CNN
then a residual network, the unrestricted routed arm with ordinary-gradient expansion and compact controls, the
feature measures (early-layer probes, normalised extraction where it can be defined without known coordinates)
next to native, extraction and contraction accuracy. The exact fold of mask nodes goes in at the same time.
