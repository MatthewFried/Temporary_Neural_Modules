# v58 -> v59: the folded continuation, audited reuse, and corrected geometry

(The v59 launcher is replaced by `scripts/60`: CHANGES_v60.md. A v59 panel is reused by v60, folded forks excepted.)

Semantics version `cop-7.21.0` (run ids unchanged). Semantic code hash `1f5f72b51291d08a` -> `c50b0c740e212700`:
one new child intervention (dissipation method `fold_unrouted`). `scripts/58` is retired; `scripts/59` runs the
whole wave-28 panel and reuses whatever v58 already trained. v59 writes only `~/cop_results_v59`; it reads the v53
and v58 results folders only.

If v58 is running, let it finish first (its 384 forks are copied, not retrained). If v58 never ran, run v59 instead.

    cd ~/research/cop_research_v59 && WORKERS=3 COP_VENV=~/fsc/.venv nohup bash scripts/59_v59_fork_panel.sh > ~/v59.log 2>&1 &

Archive: `cop_v59_panel_reports.zip`. With v58 finished: tests, copying, the reproduction sample, 96 folded forks and
the analyses, about two hours. Without v58: about four and a half hours.

## Changes that alter training

1. **`fold_unrouted`** (cop/graph/edits.py, cop/experiments/dissipation.py, cop/config.py). The affine additions,
   gradient-mask nodes included, are folded exactly into the layer that reads the merge (float64, evaluated on zero
   and the unit vectors) and removed; the export is the compact network with f0's architecture. The forward function
   is unchanged (the run records the after-fold KL and drift); from there the compact network trains directly on
   every example with a fresh optimizer. The masks are dropped only by this method and are recorded
   (`grad_masks_removed`); `mask_grad` is not added to the list of affine operations, since the operation keeps the
   function and deliberately replaces routed training by compact training. The ordinary `fold` still refuses masks.
2. **Wave 28** gains `folded_reset` (block `V59_folded`, 96 jobs) beside v58's four keep forks (384, unchanged run
   ids). 552 jobs in all.

   | continuation | additions | what trains | optimizer |
   |---|---|---|---|
   | routed_reset | trained, masks kept | backbone and additions, routed | fresh |
   | ordinary_reset | trained, masks released | backbone and additions | fresh |
   | frozen_reset | frozen at the fork | backbone through the fixed map | fresh |
   | folded_reset | folded and removed | the compact network directly | fresh |
   | routed_carry | trained, masks kept | backbone and additions, routed | carried |

   frozen_reset is a **frozen affine scaffold with ordinary gradients**, not compact training. With the additions a
   fixed map h -> A h + c, layer 3's gradient is G A^T + gb c^T (G, gb: the compact layer's weight and bias
   gradients), so under SGD its effective weight moves by -lr (G A^T A + gb c^T A), against -lr G for the folded
   network; Adam differs too, and a singular A restricts what the effective weight can reach. The v58 text that said
   otherwise is corrected (CHANGES_v58.md, DEVIATIONS 319 and 323).

## Cross-version reuse

`configs/reuse_audits.json` holds one audit: runs produced by `1f5f72b51291d08a` may be reused by `c50b0c740e212700`
for the kinds baseline, trajectory, dissipation (every method but fold_unrouted) and continue. The reason: the
semantic diff is the new method's code, an optional argument whose default runs the old path, a config choice and a
label, so those jobs execute the same code. No configuration default changed, so their run ids are the same.

- `scripts/seed_panel.py --audited` copies a run of other semantics only when the audit covers its produced-by hash
  and kind, it is complete and valid, its saved configuration equals the manifest's and hashes to its run id, and the
  copy is byte-identical (SHA-256 of every file). The copy gets one `reuse_accepted.jsonl` record (audit id, reason,
  audit file hash, source, verification); provenance is not touched; the source is not written. Anything else is
  trained.
- `scripts/panel_state.py --audited` accepts such runs for read-only analysis (the v53 wave-26 panel for the
  geometry); nothing is written there.
- `scripts/reuse_reproduce.py`: after seeding, one f0, its first trajectory and that trajectory's copied forks at its
  latest fork point are retrained from scratch in `~/cop_results_v59/reuse_check`, and every saved model state must
  equal the copy's bit for bit (training is deterministic). A difference fails the launcher; the panel still runs.
- An audit file whose accepted-for hash is not this code's accepts nothing, so any later change to `cop/` needs a new
  audit.

## Analysis-only changes

1. **`fork_continuation.py`** (schema `fork_continuation/v59`).
   - The folded fork is measured in f0's layout (the same weights, checked to compute the same logits).
   - **Named contrasts** (first minus second, within f0, parent and fork point): routed_minus_ordinary (continuing
     gradient routing), ordinary_minus_frozen (continuing to learn the additions), frozen_minus_folded (keeping a
     fixed affine parametrisation), carry_minus_reset (optimizer-state dependence), each continuation minus the start,
     the start minus f0, and trajectory_end minus routed_carry.
   - **Per-fork audit** (`_audits.csv`, every real run): starts from the snapshot (recorded parent state hash equal
     to the snapshot's), update count, minibatch stream (one batch-id hash per fork point, as many batches as
     updates), optimizer policy, mask membership (routed: retained, eligibility equal to the parent's split),
     parameters (frozen unchanged and not trainable; routed and ordinary changed; folded: no additions, masks
     recorded as removed, f0's architecture), the fold's function change (the run's record and a refold of the
     snapshot here), the held column (B), learning rate and schedule. Any failure fails the analysis.
   - `trajectory_end` is labelled a reference, not an exact replay control.
   - Coverage reports analysis completion and audit failures apart.
2. **`merge_geometry.py`** (schema `merge_geometry/v59`).
   - **Affine maps from the graph**: the subgraph from layer 2 to the merge evaluated in float64; sampled activations
     check it (residual on train and test, which must be below 1e-4). ReLU maps stay least-squares fits, labelled
     `least_squares_affine_approximation`.
   - **Whitening records** on every whitened probe: total and retained dimensions, discarded variance, retained
     conditioning, the largest off-span fraction of the evaluation partitions. **Comparability** of the whitened
     before/after probes: on the fit set (invertible exact map, equal retained dimensions, the map carrying one
     retained span onto the other) and on the evaluation partitions (also the points inside both spans). The whitened
     post-minus-pre contrast is recorded for fit and test error with `comparable` and its reason; rows that are not
     comparable are left out of the summaries. Under these conditions the whitened difference of an affine merge is
     zero by construction, so it checks the conditions; transport is the primary test.
   - **Transport certificate**: for every affine state with an invertible exact map, each pre-merge probe carried
     through a linear solve of A h = post - c, on the fit partition and test, val, shift: solve residual,
     reconstruction residual, score difference, disagreement fraction, smallest margins. A state passes when every
     probe on every partition has solve residual <= 1e-9, score difference <= 1e-4 and no decision change outside
     the margin band. Coverage: expected, eligible, checked, passed, failed, skipped with reasons; `valid` (nothing
     failed, every eligible state checked) and `complete` (every expected state eligible) apart from analysis
     completion. `--strict` fails on an incomplete analysis or an invalid certificate. fitted_minus_transported uses
     certified states only.
3. **`routing_updates.py`** description: the historical step is reconstructed to verified numerical tolerance, not
   exactly; the Taylor remainder is curvature plus numerical and reconstruction error (the measured change and its
   prediction use the same full-batch loss and the same update; minibatch sampling sets the update's direction and
   is not a separate term). No output changed.
4. **Launcher** `scripts/59_v59_fork_panel.sh`: tests; seeding from v58 then v53 under the audit; the reproduction
   sample; training; the geometry on the v53 panel; status, checks, fresh reload, strict summary, timing; the fork
   analysis. Reports include both seed records, the sample and the reproduction record.
5. **Tests**: `tests/test_v59.py` (the unrouted fold with four branches and nonzero offsets: exact function and equal
   upstream gradients with masks released; frozen and folded training diverge after one SGD step, with the update
   formula checked; config rules; a corrupted transport fails; an anisotropic invertible map truncates whitening
   unequally while transport still certifies; rank-deficient activations under a known invertible map; the audit
   file, audited copies and their ledger, runner acceptance, read-only panel state, the reproduction check),
   `tests/test_v58.py` updated (five continuations, the audit and a broken-record failure, the new geometry outputs),
   `tests/test_v59_launcher.py`. Tests that pinned the old semantic hash now require the audit instead.

## What each part could show

These hold for these checkpoints, budgets and optimizer settings only.

- routed_minus_ordinary: whether continued routing adds to the first-layer change after the fork.
- ordinary_minus_frozen: whether the additions still learning matters.
- frozen_minus_folded: whether a fixed affine scaffold, which changes the backbone's updates, matters against
  training the same function directly. If folded_reset improves as much as the others, the state reached carries
  what drives the change without any additions.
- carry_minus_reset: optimizer-state dependence.
- Geometry: a certified transport at the pre-merge error with a worse fitted post-merge probe points to the fit, not
  the information. A rank loss or a worse probe alone does not establish loss of task-relevant information.

## What was executed here

The full CPU suite passed (967 passed, 29 skipped: CUDA-only tests). The wave-28 manifest was generated: 552 jobs, the 456 of v58 with identical run ids.
No real job was trained and no real panel was analysed.
