# v59 -> v60: verification before training, the fold's saved start, tighter audits

Semantics version `cop-7.21.0` (run ids unchanged). Semantic code hash `c50b0c740e212700` -> `09850974bb32663f`: the
fold now saves its starting checkpoint. `scripts/59` is retired; `scripts/60` runs the same five-arm wave-28 panel
(552 jobs) and reuses what v59 and v58 trained, except v59's folded forks, which are retrained.

If v59 is still running, stop it first (`pkill -f 59_v59_fork_panel; pkill -f "cop run"`). Its finished keep forks
are copied; nothing in its folder is changed.

    cd ~/research/cop_research_v60 && WORKERS=3 COP_VENV=~/fsc/.venv nohup bash scripts/60_v60_fork_panel.sh > ~/v60.log 2>&1 &

Archive: `cop_v60_panel_reports.zip`. With v58's forks available: about two hours. Without: about four and a half.

## Changes that alter training

1. **The fold's start is saved.** `fold_unrouted` saves the compact network it starts training from as a permanent
   checkpoint (`event_after_fold`) before the first update, and records its graph, parameter and architecture hashes
   (`fold_start`, and a `fold_unrouted` event). The result fields `grad_masks_removed` and `fold_start` are written
   for this method only.

## Cross-version reuse

- **Training waits for the verification.** After copying, every audited copy in the panel (this attempt's or an
  earlier one's) is verified before anything trains. `run28` runs only when the verification passed or the panel holds
  no audited copy. If selection, the retraining or the comparison fails, the diagnostics are packaged and nothing is
  trained.
- **The comparison covers the whole checkpoint.** Each checkpoint of each sampled job is compared section by section:
  the graph specification (operations, connections, merge coefficients, gates, outputs) with every tensor's value,
  dtype and shape; the optimizer state by parameter name (moments, step counters) and its hyperparameters; the trainer
  and generator state (sampler position and permutation, batch-id hash, exposure records); the lineage; the extra and
  numerics records. Excluded, explicitly: the lineage's code hash and wall-clock fields. Two identical miniature runs
  agree on every section here; the tests change one merge coefficient, one gate, one dtype, one Adam moment, one step
  counter or the parameter names and each fails its section.
- **The sample covers every class.** One f0, its first trajectory and that trajectory's forks at its latest fork point,
  then the first audited run of every class not yet covered (kind, dissipation method, design arm), each with its
  ancestors. "Nothing to verify" means no audited run at all; an audited run whose ancestor is missing from the
  manifest is a coverage error.
- **Sources**, newest first: the v59 panel, the v58 panel, the v53 panel; all only read. Two audits in
  `configs/reuse_audits.json`: runs of v45 to v58 (`1f5f72b51291d08a`) and of v59 (`c50b0c740e212700`), every kind
  but `fold_unrouted`.
- **SEED=0** copies nothing in that attempt. It does not remove copies an earlier attempt made: they stay, are verified
  and are used, because the runner resumes. A fresh panel needs a fresh results folder
  (`COP_RESULTS=~/cop_results_v60_fresh SEED=0 ...`). Nothing deletes earlier results.

## Analysis-only changes

1. **`fork_continuation.py`** (schema `fork_continuation/v60`).
   - **The saved after-fold checkpoint is audited**: its hashes are the recorded ones; no addition or gradient mask is
     left; its architecture is f0's; layer 3 equals W3 A and b3 + W3 c within 1e-5 relative, for the exact map h -> A
     h + c of the snapshot's merge in float64; every other backbone layer is the snapshot's exactly; it computes the
     snapshot's function within 1e-5 on every partition; the optimizer held the compact network's tensors.
   - **frozen_reset**: the trainable set must equal the backbone's exactly (a subset fails).
   - **Optimizer membership**: at the first update the optimizer holds every tensor, and every trainable tensor got a
     step (all of them; the backbone's only for frozen_reset).
   - **routed_carry**: the carried digest and step range must equal the parent checkpoint's optimizer state by
     parameter name, recomputed here.
   - **Interventions, not outcomes**: routed and ordinary arms are checked for additions present, trainable and in the
     optimizer. Whether their tensors moved is recorded as `outcome_additions_moved` and never fails an arm.
   - **Interpretation rule** in the tool and its coverage: folding moves the additions' computation into layer 3 by
     algebra, so a successful folded continuation does not by itself show that the original backbone learned to
     replace the additions. Learning in the original components is read from the first layer's change, its
     extraction into f0's unchanged downstream network, the norm-and-bias restoration diagnostic, and the paired
     comparisons.
2. **`merge_geometry.py`** (schema `merge_geometry/v60`).
   - Whitening comparability is described as a numerical check under stated tolerances; the off-span test bounds
     aggregate energy, not each point.
   - `_whitening_coverage.csv`: per variant, stage, metric and penalty, the planned and comparable draws and draw-seed
     pairs, and the draws left with fewer seeds than planned.
   - Transport rows carry `err_diff` (transported minus pre-merge error). The certificate reports the largest
     disagreement fraction and error difference over passed rows and how many passed rows flip a decision. A pass
     allows flips inside the margin band, so it does not mean identical predictions.
3. **Launcher** `scripts/60_v60_fork_panel.sh`: the gating above; seeding from v59, v58, v53; the reuse check record is
   packaged whether or not it passed.
4. **Tests**: `tests/test_v60.py`, with:
   - An acceptance test of `fold_unrouted` on the training device, named for the launcher's CUDA selection. Its CPU
     case runs everywhere and passed here; the CUDA case runs on the GPU machine. It covers both parent arms (the held
     column included) and both fork ages. It checks the saved start against W3 A, b3 + W3 c in float64, the function
     in float32 on the device, compact training steps, an interrupted run against an uninterrupted one, and a fresh
     reload. CPU and GPU runs are not required to agree bit for bit.
   - The comparison's negative cases and the sample's coverage.

   Also updated: `tests/test_v58.py` (each broken record fails exactly its check: start, trainable subset, carried
   digest, a corrupted after-fold checkpoint), `tests/test_v59.py` and `tests/test_v60_launcher.py`.

## What was executed here

The full CPU suite passed (975 passed, 31 skipped: CUDA-only tests, including the CUDA cases of the new acceptance test). Two identical miniature chains compared section by section. No real
job was trained.
