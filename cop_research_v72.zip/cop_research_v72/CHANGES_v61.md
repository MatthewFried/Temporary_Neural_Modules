# v60 -> v61: reanalysis of the v60 panel (analysis only)

Nothing in `cop/` changed (semantic code hash `09850974bb32663f`, as v60), and v61 trains nothing. It reads
`~/cop_results_v60/panel28` and `~/cop_results_v53/panel26` (both only read) and writes `~/cop_results_v61`.

    cd ~/research/cop_research_v61 && COP_VENV=~/fsc/.venv nohup bash scripts/61_v61_reanalysis.sh > ~/v61.log 2>&1 &

Archive: `cop_v61_reanalysis_reports.zip`. About an hour and a quarter: the CPU tests (about 20 minutes), the fork
analysis, the geometry (now twice the transport work).

## Why

v60's training, checks and reloads passed. Two analysis checks failed:
- One folded fork (B, snap_2500, draw 348, seed 1) exceeded the float32 fold tolerance: 1.23e-5 against 1e-5.
- The transport certificate failed for 303 of 1,056 affine states, all of them routed, where the merge is
  ill-conditioned (median condition number about 3,000 at the end of the expansion).
v61 finds the source of each failure from the existing checkpoints, keeps the original failures visible, and adds
the paired summaries the interpretation needs.

## Changes

1. **The fold check, algebra and rounding apart** (`fork_continuation.py`, schema `fork_continuation/v61`). For
   every folded fork:
   - algebra: the fold rebuilt in float64 from the snapshot, against the snapshot in float64
     (decisive, 1e-10);
   - storage: the saved float32 fold evaluated in float64, against the snapshot in float64 (decisive, 1e-5);
   - forward: both in float32 here, and on a CUDA machine on the device the runs were trained on (reported);
   - the run's own KL (decisive, 1e-8) and drift (reported).
   v60's float32 rule stays as a column (`outcome_fold_float32_rule_v60_passed`), and its failures are listed in the
   coverage.
2. **Sensitivity**: `fork28_contrasts_summary_sensitivity.csv` repeats every contrast summary without every draw
   that holds a flagged fork (any failed check, or v60's float32 rule). The excluded draws are named in each row.
3. **The central paired table** (`fork28_central.csv`). Per parent, fork and state:
   - the complete network's error, the raw extraction, both normalised extractions, the training loss, the
     first-layer shape and the first-layer label probes at both penalties;
   - each against f0 (now every state, not only the start) and each continuation against the fork start;
   - `gain_points` (positive: lower error), its interval, and the draw and draw-seed counts behind each row.
4. **Transport in two precisions** (`merge_geometry.py`, schema `merge_geometry/v61`). The pre-merge activations
   are held fixed.
   - float64, decisive: the post-merge activations are the merge subgraph evaluated in float64 on those
     activations, checked against A h + c within 1e-10.
   - float32, v60's certificate: the network's own float32 post-merge activations. Reported with its counts and its
     largest score difference, disagreement and error difference.
   - `geometry26_precision.csv`, per state and partition: the float32 forward residual |post32 - (A h + c)|, the
     error it gives back through the solve, the amplification between the two, and the condition number.
   `--strict` requires the float64 certificate.
5. **Status record** (`scripts/panel_status.py`, `panel_status.json`): training completion, fork validity,
   transport validity (float64 and float32) and analysis completion, each on its own. A passing evidence step does
   not override any of them.
6. **Launcher** `scripts/61_v61_reanalysis.sh`. `scripts/60` stays the training launcher. Tests:
   - `tests/test_v61.py`: a controlled ill-conditioned case where the float32 certificate fails and the float64 one
     passes, and the amplification is bounded by the conditioning;
   - `tests/test_v61_launcher.py`;
   - `tests/test_v58.py` now uses the v61 command lines and checks the new outputs.

## Reading rules carried forward

- Keep apart what made the backbone change develop and what is needed to keep or extend it. v57 shows a smaller
  useful change under parameter-only routing, so direct modification of the backbone gradient is not necessary for
  every benefit.
- Read native performance beside the raw and normalised extraction. In A the routed advantage appears after the
  norm-and-bias restoration, not in the raw transplant. In B the raw advantage is large and does not survive
  restoration. A and B are different kinds of benefit and are not merged into one claim.
- Folding writes the additions' computation into layer 3. A folded fork's native performance does not show the
  backbone absorbed the additions. Its first layer, extracted into f0, is evidence about the original component.
- The two fork ages differ in insertion history and remaining budget, so retention against development is not yet a
  maturation threshold.
- For eligible affine merge maps, the analysis transports the tested linear readouts through the float64-evaluated
  merge within the stated tolerances. Actual float32 discrepancies are reported separately: the network's own
  precision perturbs the readouts, through the ill-conditioned merge, by the reported amounts, and those differences
  are not harmless. If the map is invertible, preservation in ideal arithmetic follows from the algebra; a passed
  transport check is a numerical confirmation, not a finding. (Wording narrowed in v63.)
- v61's fitted-minus-transported contrast compared a probe fitted on the float32 merge outputs with one transported
  through the float64 merge, so it changed the representation as well as the probe. v63 replaces it with
  matched-precision comparisons and keeps this one only as the labelled mixed comparison.

## What was executed here

The full CPU suite passed (983 passed, 31 skipped: CUDA-only tests). The fork tool was run on a miniature panel with --recorded-device cpu: algebra about 5e-16, storage about 5e-8, float32 forward about 2e-7. No real panel was analysed.
