# v61 -> v62: v60's design in a second setting (wave 29)

Nothing in `cop/` changed (semantic code hash `09850974bb32663f`, as v60 and v61). Every job kind, method and
setting is v60's; only the setting and the draws are new. v62 writes `~/cop_results_v62` only.

    cd ~/research/cop_research_v62 && WORKERS=3 COP_VENV=~/fsc/.venv nohup bash scripts/62_v62_replication.sh > ~/v62.log 2>&1 &

Archive: `cop_v62_panel_reports.zip`. About 5 to 7 hours (744 jobs on a larger network, then both analyses).

## The question

v60 found that continued routing improves the first layer's normalised extraction while the complete network gets
worse, and that most of the developed change survives folding and compact training but erodes a little. v61 found
that, for eligible affine merge maps, the tested linear readouts transport through the float64-evaluated merge within
the stated tolerances; actual float32 discrepancies are reported separately. Does the v60 observation hold under a
joint change in network size, depth, cut location and input dimensionality within the same task family? (Wording
narrowed in v63.)

This is a replication in the same task family: the generator keeps its group-dependent linear rule and its shortcut
mechanism, and changes only the causal and noise dimensions. It is stronger evidence than another seed on the old
setting. It is not a separate data domain or a different causal task.

## The setting (wave 29)

- **Network**: width 128 and six hidden layers (v60: width 64, four). The middle cut, and so the additions' merge,
  sits after layer 3 (v60: after layer 2); a folded fork composes the additions into layer 4.
- **Task**: the shortcut generator with 12 causal and 12 noise inputs (v60: 8 and 8), rho 0.95, 4,096 training
  examples, the same training settings (AdamW, base learning rate, U = 2,000 updates per round).
- **Draws**: 12 data draws never used before (349 to 360; the test checks every earlier wave), optimizer seeds 0
  and 1.

## The panel (744 jobs)

Per draw and seed, one f0 and:
- the four affine arms of wave 26, {A, B} x {routed, all} (A: nothing held; B: the shortcut column held), to 2U with
  the same schedule and snapshots, each with wave 26's linear removal;
- the two compact controls (f0 continued for 4U with the same hold);
- from each routed affine arm at snap_1000 and snap_2500, wave 28's five continuations: routed_reset, ordinary_reset,
  frozen_reset, folded_reset, routed_carry.
The merge geometry reads the affine arms and controls; the fork analysis reads the forks. Both run on this one panel.

## Analysis changes

- `fork_continuation.py` and `merge_geometry.py` find the merge in the graph at any depth (layer<k>_post_merge)
  instead of assuming layer 2. Probes run on every hidden layer. The fold audit composes into backbone layer k + 1.
  On the v60 panel (k = 2) the features, their names and every output are as before.
- `merge_geometry.py`: the float64 merge evaluation runs without gradients.

## The measures

The measures and contrasts are v61's, unchanged: the central paired table (complete network, raw extraction,
normalised extraction, training loss, first-layer shape and first-layer probes, each against f0 and against the fork
start), the named fork contrasts, the merge geometry with the float64 transport certificate and the precision
diagnostic. Nothing new is chosen after seeing these results.

The replication hypotheses, with their exact favourable contrasts, the metric, the aggregation, the primaries and
the multiplicity rule, are in `configs/v62_replication_registry.json`, written in v63 (see CHANGES_v63.md). Earlier
wording here ("at or below zero") did not say which way the stored error differences point; the registry replaces
it.

## Launcher and tests

- `scripts/62_v62_replication.sh`: environment, manifest, validation, CPU and CUDA tests, training, status, checks,
  fresh reload, strict summary, timing, fork29, geometry29, the status record, evidence, packaging.
- `tests/test_v62.py`: the wave's composition (744 jobs, unused draws, the settings, every fork's continuation and
  hold), and a miniature of the second setting (six layers, 12 + 12 inputs) run through the launcher's own command
  lines: the merge found after layer 3, every fork audit passing with the fold composed into layer 4, probes on
  layers 3 to 6 and the merge, the geometry's exact maps, certificate and outputs.
- `tests/test_v62_launcher.py`.

## What was executed here

The full CPU suite passed (992 passed, 31 skipped: CUDA-only tests). No real job was trained.
