# v62 -> v63: analysis corrections for the v62 panel (analysis only)

Nothing in `cop/` changed (semantic code hash `09850974bb32663f`, as v60 to v62). No run id changes and nothing is
trained. v62's training and its own outputs are kept as they are: v63 reads `~/cop_results_v62/panel29` and
`~/cop_results_v53/panel26` and writes `~/cop_results_v63` only. Run it after v62 has finished.

    cd ~/research/cop_research_v63 && COP_VENV=~/fsc/.venv nohup bash scripts/63_v63_reanalysis.sh > ~/v63.log 2>&1 &

Archive: `cop_v63_reanalysis_reports.zip`. About 1 to 2 hours (CPU tests, then the three analyses).

## 1. Fitted against transported probes at matched precision (`merge_geometry.py`, schema `merge_geometry/v63`)

v61's `fitted_minus_transported` compared a probe fitted on the float32 merge outputs with the pre-merge probe
transported through the float64 merge. It changed the representation as well as the probe, so it does not estimate
fitting against transport. Now, per affine state that is eligible for transport:

- the post-merge preprocessing and probes are also fitted on the float64-evaluated merge outputs (feature
  `layer<k>_post_merge@float64` in `_probes.csv`);
- `fitted_minus_transported_float32`: the probe fitted on the float32 outputs against the probe transported through
  the same float32 outputs (the network's actual precision);
- `fitted_minus_transported_float64`: the same with the float64 outputs (a diagnostic; certified states only);
- `fitted_minus_transported_mixed_precision`: v61's comparison, kept and labelled. Its whitened rows are marked not
  comparable and stay out of the summaries.

Transport rows carry `fitted_post_merge_err` (the matched one) and both precisions' fitted errors.

## 2. Whitening comparability on those comparisons

Each whitened fitted-minus-transported row carries the comparability of its own representation (float32: the
float32 whiteners; float64: the whitener refitted on the float64 outputs, recorded in `_maps.csv` as
`whitening64_comparable`). Raw rows are all kept with the reason. Summaries use only comparable rows, and every
summary row now reports `planned_pairs`, `included_pairs`, `planned_draws` and `included_draws`.
`_whitening_coverage.csv` covers `post_merge_minus_pre_merge` and both matched fitted-minus-transported comparisons.
A whitening result is described only together with how many draw-seed pairs support it.

## 3. The compact controls in the fork analysis (`fork_continuation.py`, schema `fork_continuation/v63`)

The compact controls of wave 29 (f0 continued for 4U with the parent arm's hold) are now measured exactly like every
other state, from the saved checkpoints: native error, raw first-layer extraction, the per-block, per-row norm and
f0-bias restoration, and the other extraction variants. Each is checked to start from this f0 and to hold the
parent's input hold and learning rate.

- `compact_2U`: the control at 2U, update-matched to the fork endpoints.
- `compact_4U`: the control at its end, 4U.
- Contrasts `fork_minus_compact_2U` and `fork_minus_compact_4U` for every fork endpoint (A against compact_A, B
  against compact_B), also in the central table.
- `_compute.csv`: the training MACs since f0 of every fork (trajectory to the fork point plus the fork) and of each
  compact state, with the ratios. The 4U control's actual compute is reported rather than an assumed ratio.

The compact controls continue with the optimizer state f0 ended with. An optimizer-reset-matched compact control is
a separate follow-up; this control does not stand in for it.

## 4. Audit completeness separate from audit success (`scripts/panel_status.py`)

Fork validity records expected, audited, passed and failed forks and whether the audit is complete. Its state is
`valid` only with complete coverage and no failure, `invalid` with a failure, `incomplete` when forks are missing,
`unknown` without an audit record (then `valid` is null, never true). Transport validity keeps two statements apart:
valid among eligible states, and complete across all planned affine states (a skipped singular or ill-conditioned
map makes it incomplete; with no eligible state it says so).

## 5. The replication registry (`configs/v62_replication_registry.json`, `scripts/replication_registry.py`)

Written in v63 while v62 was training, before any v62 result was seen. It specifies which existing contrasts answer
the replication question and how they are read. It changes no run and is not a preregistration.

Primary (A, nothing held; metric `state_at_f0_block_row_norms_f0_bias_test_err` unless stated):

| Hypothesis | Favourable value |
|---|---|
| Early routing improves normalised extraction (snap_1000) | ordinary error - routed error > 0 |
| Early routing worsens the complete network (snap_1000, `native_test_err`) | routed error - ordinary error > 0 |
| Late folding retains a component advantage (snap_2500) | f0 error - folded error > 0 |
| Expansion history beats compact continuation (snap_2500) | compact_2U error - folded error > 0 |

Secondary: the same for B (normalised and raw extraction), and the 4U compact comparison. Seeds are averaged within
each of the 12 draws, then a Student t interval over draws. The four primaries share a familywise 95% level by
Bonferroni (each read at its 98.75% interval). Replicated: the interval lies above zero. Contrary: below zero.
Inconclusive: it contains zero, which is not evidence of no effect. The registry is read only from a fork analysis
that passed.

## 6. Defensive checks

- Both analyses require exactly one merge site in the graph for this panel and fail otherwise.
- `scripts/62_v62_replication.sh` and `scripts/63_v63_reanalysis.sh` refuse any SCALE other than `full` (the fork
  points 1000 and 2500 are defined for the full budget).

## 7. Wording

- v62 is a replication under a joint change in network size, depth, cut location and input dimensionality within
  the same task family. It is not a separate data domain or a different causal task.
- "The routed merge loses no label information in exact arithmetic" is replaced by: for eligible affine merge maps,
  the analysis transports the tested linear readouts through the float64-evaluated merge within the stated
  tolerances; actual float32 discrepancies are reported separately. If the map is invertible, preservation in ideal
  arithmetic follows from the algebra; a passed check is not itself a finding.
- CHANGES_v61 and CHANGES_v62 carry the narrowed wording; CHANGES_v62's sign-ambiguous criteria point to the
  registry.

## Launcher and tests

- `scripts/63_v63_reanalysis.sh`: environment, both manifests and their validation, CPU tests, the v62 panel and the
  v53 panel (reuse audit) checked, fork29 (with the fold also evaluated on the training device on a CUDA machine),
  geometry29, geometry26, registry29, status, evidence, packaging.
- `tests/test_v63.py`: an ill-conditioned eligible map where float32 rounding changes the comparison while float64
  transport holds; whitening comparability rejecting unequal retained dimensions and off-span evaluation points;
  summaries over comparable rows with planned and included pairs; the v62 launcher's scale guard.
- `tests/test_v62.py` (miniature of the second setting): the compact controls measured at 2U and 4U and the forks
  compared with them, the compute table, every matched comparison reading the same representation, the registry on
  the miniature's contrasts with its signs; negative cases: a fold left uncomposed in the receiving layer fails
  `fold_start` and `fold_function`, and a manifest missing one fork fails.
- `tests/test_v63_status.py`: an empty audit, a partial panel, and transport with no eligible state.
- `tests/test_v63_launcher.py`.

## What was executed here

The full CPU suite passed (1008 passed, 31 skipped: CUDA-only tests). No real panel was analysed and no job was trained.
