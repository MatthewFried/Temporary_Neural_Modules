# v63 -> v64: the second-setting replication in one run

v62 (training) and v63 (corrected analyses) were never run. v64 runs them together with one launcher,
`scripts/64_v64_panel.sh`. Nothing in `cop/` or in the analysis tools changed from v63 (semantic code hash
`09850974bb32663f`); the design, the analyses and the registry are those of CHANGES_v62.md and CHANGES_v63.md.

    cd ~/research/cop_research_v64 && WORKERS=3 COP_VENV=~/fsc/.venv nohup bash scripts/64_v64_panel.sh > ~/v64.log 2>&1 &

Archive: `cop_v64_panel_reports.zip`. About 6 to 9 hours. A stopped run is continued by running the same command
again. It writes `~/cop_results_v64` only and reads `~/cop_results_v53/panel26` without changing it.

## Steps

environment, manifest29, validate29, CPU tests, CUDA tests (on the GPU: they must run, none skipped), run29 (744
jobs), status29, checks29, reload29, summary29, rates29, fork29, geometry29, registry29 (only after a passed fork29),
manifest26, validate26, panel_source26, geometry26, status, evidence, manifest copies, packaging.

The wave-26 geometry runs after the training and independently of it: a missing or incomplete v53 panel skips
geometry26 only, and wave 29 is trained, analysed and packaged regardless (the verdict then reports that step).

`scripts/62_v62_replication.sh` and `scripts/63_v63_reanalysis.sh` remain for reference; use `scripts/64` only.

## Tests

`tests/test_v64_launcher.py`: the order of the steps, the panel trained before any analysis, the registry reading only
a passed fork analysis, an unfinished panel analysing nothing of wave 29, failed tests training nothing, a missing v53
panel leaving wave 29 unaffected, the scale guard, CUDA tests and the fold evaluated on the device on a GPU machine,
the archive's contents.

## What was executed here

The full CPU suite passed under v63 (1008 passed, 31 skipped: CUDA-only); v64 adds only the launcher and its test (7 passed). The launcher runs the full suite again before training. No real job was trained.
