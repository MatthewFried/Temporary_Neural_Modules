# v64 -> v65: the image replication (wave 30) and the mechanism forks (wave 31)

Semantics version `cop-7.21.0` (run ids of earlier jobs unchanged: no configuration default changed). Semantic code
hash `09850974bb32663f` -> `1f7856b2695b98dc`. The audit `v65_from_v60` in `configs/reuse_audits.json` accepts the
runs of v60 to v64 under the new code (every kind, fold_unrouted included); `v65_from_v58` and `v65_from_v59` carry
the earlier two audits over. Run after v64 has finished: wave 31 copies v64's wave-29 runs.

    cd ~/research/cop_research_v65 && WORKERS=3 COP_VENV=~/fsc/.venv nohup bash scripts/65_v65_panels.sh > ~/v65.log 2>&1 &

Archive: `cop_v65_panel_reports.zip`. About 7 to 10 hours (tests about 30 minutes; wave 31 about 2 to 3 hours;
wave 30 about 3 to 5 hours; the analyses about 1 to 2 hours). It writes `~/cop_results_v65` only; v64's panel is
only read. CIFAR-10 is used from the data root (`~/cop_data`), downloaded there once if missing.

## Wave 30: the v60 design on images

**Task** (`image_shortcut`, new dataset). CIFAR-10, label 1 for airplane, automobile, ship, truck and 0 for cat, deer,
dog, horse (balanced). The network sees four channels: the colour channels (standardised on the training subset) and
a shortcut plane, constant over the image, of value `strength x (2a - 1) + noise x N(0, 1)` per image. In training
and val, a = y with probability 0.95; in test and val_indep a is independent of y; in shift and val_reversed the
correlation is reversed; cf_base / cf_shortcut are the first 2000 test images with the plane agreeing with the label
and flipped (`shortcut_flip_rate`). 8192 training images; validation partitions come from the official train split,
test and shift from the official test images (8000). Each image keeps its plane for every training-set size. The
feature layout names input channels: causal = the colour channels, shortcut = channel 3.

**Network** (`cnn_cut`, new model family). conv3x3-relu, conv3x3-relu, maxpool, [middle cut], a 1x1 receiving layer
(linear, present in every network), relu, conv3x3-relu, maxpool, global average pooling, [penultimate cut], linear
head. No normalisation layers; every layer has a bias. Additions at the middle cut are read by the 1x1 layer with no
activation in between, so an affine addition h -> A h + c folds into it exactly at every position (W A, b + W c).

**Arms** (per f0; 12 new draws 361 to 372 x optimizer seeds 0 and 1): the four affine arms of wave 29 at the middle
cut ({A, B} x {routed, all}; the routed split puts 95% of the examples in branch a, as the shortcut data's group-0
share does in wave 29), each with the linear removal; the late head `A_head_all_relu` (ReLU additions on the pooled
features before the classifier, every example's gradient, with the linear removal): a temporary head on the
representation, the projection-head comparison; the compact controls compact_A, compact_B (f0 continued for 4U); and
from each routed arm at snap_1000 and snap_2500 the five forks of wave 28. U = 2000 (budgets: `image_shortcut`), so
the fork points are the same ages as before. B holds the first layer's shortcut-channel kernels (the input hold now
reads a convolution's input channels). 792 jobs.

**Fold.** `fold_unrouted` now refuses, before training, a merge that is not read by one backbone linear layer: a
padded spatial convolution cannot absorb an affine offset exactly, because fewer offset terms reach its border
positions (`fold_receiver_problems`; the test shows the naive composition wrong at a corner and right in the
interior). Every earlier fold meets the condition.

**Analysis** (`audit_v5/tools/image_forks.py`, new). States: f0; each arm's trajectory end (2U) and removal end;
each fork's start and continuations; compact_2U and compact_4U per hold. Measures: native errors, training loss and
shortcut_flip_rate; first-layer extraction (the state's first convolution in f0); the normalised extraction with the
kernels at f0's norm per output channel and input block and f0's bias (`state_at_f0_block_row_norms_f0_bias`, the
registry's metric) and per output channel over all inputs (`state_at_f0_row_norms_f0_bias`, needing no layout);
first-layer shape. Fork audits are fork_continuation's; for folded_reset the saved start is checked against
W A, b + W c on the 1x1 layer with every other tensor unchanged, and the fold's function in float64. Contrasts: the
fork family as wave 28 (with the compact controls), `arm_minus_arm` (routed against all, routed against the late
head, all against the late head; B routed against all) at the trajectory ends and the removal ends, each arm against
f0 and its compact control.

**Registry** (`configs/v65_image_registry.json`, written before any wave-30 result existed; not a preregistration).
Five primaries in A, Bonferroni 99% intervals: early routing improves normalised extraction (snap_1000), early routing
worsens the complete network, late folding retains a component advantage over f0 (snap_2500), expansion history beats
the update-matched compact control, and the routed expansion's normalised extraction beats the late head's at 2U.
Secondaries: the layout-free metric, routed against ordinary expansion, the late head against compact, B, and the 4U
control.

## Wave 31: what the additions compute against how they teach

At a fork point the expansion is z = h + sum of branch terms (a and b branch per round, gradient masks spec_a and
spec_b), read by the receiving layer W z + b. Two edits keep the network's function exactly and change how its
computation is split (`cop/graph/redistribute.py`):

- **swap**: the a and b branches' parameters are exchanged. The sum is unchanged; under routing, the examples of
  split a now reach the backbone through the map learned on split b, and the other way round.
- **shift t**: every branch's output is scaled by s = 1 - t and the receiving layer becomes
  W' = W (I + M) (I + s M)^-1, b' = b + W m - s W' m, for the exact float64 map z = (I + M) h + m. t = 1 leaves the
  additions in place with zero output.

Under ordinary gradients the gradient that reaches h is the same at the edit for every split (W' (I + s M) =
W (I + M)); under routing it is not. So with the forward function fixed, a difference between the routed edit and
the routed fork that is absent between the ordinary edit and the ordinary fork says the additions affect the backbone
through the maps each example's gradient passes, beyond what they compute.

**Forks** (new dissipation methods `keep_swap`, `keep_shift50`, `keep_shift100`: the keep fork from the edited start,
fresh optimizer, the parent's hold): routed_swap, ordinary_swap, routed_shift50, routed_shift100, ordinary_shift100,
from wave 29's A and B routed affine trajectories at snap_1000 and snap_2500. The edited start is saved
(`event_after_redistribute`) with its hashes and its float32 change. Wave 31 includes wave 29's f0s, routed
trajectories and their twenty forks unchanged (same run ids: copied from v64), 480 new jobs.

**Analysis** (`fork_continuation.py`, schema `fork_continuation/v65`). The mechanism forks are measured and audited
like the others, plus a `redistribution` check: the saved start is the snapshot with exactly the declared edit (swap:
every tensor exchanged with its partner exactly, nothing else changed; shift: the branches' last layers the
snapshot's times s exactly, the receiving layer the formula within COMPOSE_TOL, nothing else changed) and the edit
rebuilt in float64 from the snapshot computes the snapshot's function within ALGEBRA_TOL. The saved float32 start's
change (storage) and the run's own change are reported; a storage change above STORAGE_TOL flags the draw for the
sensitivity summary. Contrasts: each edit against the unedited fork of its routing, and the interactions
`swap_interaction` and `shift100_interaction` = (routed edit - routed_reset) - (ordinary edit - ordinary_reset).

**Registry** (`configs/v65_mechanism_registry.json`, two-sided). Primaries: the swap and shift100 interactions in
normalised extraction, A, snap_1000, Bonferroni 97.5%. Read as nonzero (positive), nonzero (negative) or
inconclusive; an interval containing zero is not evidence of no effect. `scripts/replication_registry.py` reads
two-sided hypotheses.

## Launcher (`scripts/65_v65_panels.sh`)

environment, both manifests and their validation, CPU tests (and CUDA tests on the GPU); wave 31: v64's panel copied
under the audit, a sample retrained and compared section by section before anything that descends from the copies
trains, then the panel; wave 30: the image data checked (`scripts/check_image_data.py`), then the panel; per panel:
status, checks, fresh reload, strict summary, timing, the analysis (image_forks on the training device, fork
continuation on the CPU) and its registry (only after a passed analysis); a status record per panel, evidence,
packaging. A failed verification skips wave 31 only; missing image data skips wave 30 only. Only `SCALE=full`.

## Tests

`tests/test_v65.py`: the image task (partitions, the plane, the counterfactual pair, a plane kept across training-set
sizes); the network (the receiving layer, the two cuts, additions in the right layout); the image fold exact in
float64 on zero inputs with offsets, corner, edge and interior impulses, rectangular images and unequal channel
counts, float32 differences on the CPU and (cuda) on the GPU apart; a padded 3x3 receiver refused and shown inexact
at the border; both redistributions keeping the function in float64, leaving the ordinary first-layer gradient
unchanged and changing the routed one, in the MLP and the CNN; exact tensor moves and scaling; refusals;
configuration rules; an interrupted redistribution fork resuming bitwise; both waves as designed (wave 31 sharing
wave 29's run ids, new draws); miniatures of both waves built from their own manifests (one f0, every count scaled),
trained, analysed and read by the registries; negative cases (a fold left uncomposed, a fork missing, a swap undone)
failing. `tests/test_v65_launcher.py`. Updated: `tests/test_v58.py`, `tests/test_v59.py`, `tests/test_v62.py` (the
schema and audit names).

## What was executed here

The full CPU suite passed (1047 passed, 32 skipped: CUDA-only tests, including the GPU case of the image fold).
Both miniatures trained and analysed on the CPU. No real job was trained.
