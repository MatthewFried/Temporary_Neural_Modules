# v65 -> v66: re-audit of the saved v64 / v65 runs, and the reset-matched compact controls (wave 32)

Semantics version `cop-7.21.0`. Semantic code hash `1f7856b2695b98dc`, unchanged: nothing under `cop/` that the hash
covers changed, so no earlier run id changes and no earlier run needs retraining. Run after v65 has finished: v66
reads `~/cop_results_v64` and `~/cop_results_v65` and writes `~/cop_results_v66` only.

    cd ~/research/cop_research_v66 && WORKERS=3 COP_VENV=~/fsc/.venv nohup bash scripts/66_v66_reaudit.sh > ~/v66.log 2>&1 &

Archive: `cop_v66_reaudit_reports.zip`. About 5 to 7 hours (tests about 40 minutes; wave 32 about 1.5 to 2 hours; the
four analyses about 3 to 4 hours). Progress: `grep "^===" ~/v66.log`.

## Training-semantic changes

None in the code that trains. The only new jobs are wave 32 (192), built in `cop/orchestration/wave13.py` (outside the
semantic hash) from an existing job kind: a `continue` job from f0 with segments `[u, 2U - u]`, `segment_reset
[False, True]` (the optimizer carried to update u, reset there), evaluation and saved checkpoints at u and 2U, and
the fork audit. Its 144 parent jobs (f0s, routed trajectories, their removal references) are wave 29's and wave 30's,
with the same run ids, copied from v64's and v65's panels.

## What the review found and what changed (analysis code only)

1. **Saved redistributed start is a required certificate** (`fork_continuation.py`, `redistribution_audit`). The
   saved float32 start evaluated in float64 must compute the snapshot's function within `STORAGE_TOL` (1e-5,
   relative logits), as for the fold; a failure fails the fork's audit (`redistribution_storage`), where v65 only
   flagged the draw for a sensitivity summary. Algebra (the edit rebuilt in float64), storage (the saved start in
   float64) and the deployed float32 forward (here and, with `--recorded-device`, on the training GPU) are separate
   columns; only algebra and storage decide.
2. **Non-finite values cannot pass.** `func_compare` (replacing `rel_logit_change`'s running max) returns an infinite
   discrepancy for any non-finite logit, empty partition or shape mismatch; every tolerance test uses `within(x, tol)`,
   false for NaN and infinity. The merge map, the solve and its residual, and the fold's map are checked finite before
   any comparison.
3. **The registry is bound to its evidence** (`scripts/replication_registry.py`, rewritten). Each registry carries a
   contract (analysis schema, data draws, optimizer seeds, design). The reader needs `--coverage` and `--manifest`
   (the coverage's schema and design must be the contract's and its manifest digest the manifest's, otherwise every
   hypothesis is `unbound`), and per hypothesis exactly one finite row per draw x seed from one design (otherwise
   `incomplete`, with expected / found / unique / finite counts). `--audits`: rows that depend on a run whose audit
   failed (the two states compared, and for an interaction also routed_reset and ordinary_reset) are dropped and the
   reading is `conditional`. A failed coverage or `--prerequisite-failed` makes it `diagnostic`. Exit 0 only when every
   hypothesis is `validated`; 3 when all were read but some are not; 1 when one is unbound or incomplete.
4. **Edit-event checkpoints go through `check_ckpt`** before any numerical test: `event_after_fold` (both analyses) and
   `event_after_redistribute` (recomputed tensor hash, finite tensors, run, stage, configuration, data hashes). The
   result leads each fold / redistribution detail (`integrity: ...`).
5. **The launcher no longer turns a failed prerequisite into a positive reading.** Analyses and registries still run
   after a failure (diagnostic output is kept and packaged), but each registry receives every failed scientific
   prerequisite of its panel (v64's / v65's run, checks, fresh reload, strict summary, reuse verification from their
   `verdict.json`; v66's tests and wave 32) and labels its readings diagnostic. Runtime estimates and packaging are
   operational and not prerequisites.
6. **Normalisation eligibility.** A normalised first layer must attain its target norms within `NORM_TOL` (1e-5) with
   no unmatched zero row; otherwise its normalised errors are withheld (empty) and the state is listed in
   `normalised_ineligible`. `*_norm_miss` and `*_eligible` are in the states table (both analyses).
7. **Analysis batch size.** `--eval-batch` sets the evaluation batch of an analysis (recorded in the coverage); the
   job configurations are not touched. A test shows the states unchanged within 1e-6 at another batch size.

## Re-audit of the saved runs (no retraining)

`fork29` (v64's panel29, plus wave 32's MLP controls), `image30` (v65's panel30, plus wave 32's image controls) and
`fork31` (v65's panel31) are recomputed by the v66 analyses through read-only views (`scripts/make_view.py`:
symbolic links, a merged manifest; nothing is copied or written in v64 / v65). Per analysis:
- `<an>_validity.csv` (`scripts/validity_table.py`): one row per fork run and control state: audit passed and the
  failed checks, integrity of the edit's saved start, algebra64, storage64, forward32, recorded-device forward32,
  finite, and the eligibility of each normalised metric.
- `registry29/30/31.{json,csv}`: per hypothesis status, expected / found / unique / finite pairs, excluded rows, and
  the reading; `changes_registry29/30/31.csv`: each against v64's or v65's reading, `changed` marking a different
  verdict word, a new or dropped key, or a different mean. Every changed verdict is explained from these tables.
- `prereq29/30/31_failed.txt`: the prerequisites passed to the registry.

## Mechanism diagnostics (`audit_v5/tools/mechanism_diagnostics.py`, `mech31_*`)

At the real saved snapshots of wave 31 (verified by `check_ckpt`), on four fixed training batches:
- `mech31_gradients.csv`: per edit (swap, shift50, shift100), mode (ordinary, routed) and precision (float32, float64),
  the change of the first layer's gradient and of its first AdamW update (fresh state, the trainer's settings)
  between the edited start and the snapshot, their cosine and the share of update signs kept. The ordinary rows
  measure rounding (zero in exact arithmetic); the routed rows how much the edit changes what the backbone is first
  taught.
- `mech31_regrowth.csv`: for routed_shift100, ordinary_shift100 and the unedited routed_reset / ordinary_reset, the
  branches' output relative to the merge's backbone input, and the largest output-layer weight, at the start, every
  saved path checkpoint and the end: whether and how fast zeroed branches grow back.

## Wording corrected (registries `configs/v66_*`, analysis definitions; the v63 / v65 registries are kept as written)

- **shift100** is "map moved into the receiver; zeroed trainable additions retained". The additions stay trainable
  and can grow back from the first update; it is not a removal. folded_reset is the compact continuation.
- **swap**: the tensors are exchanged exactly; the logits can differ by floating-point summation order (measured:
  `redistribution_forward32`). The docstring of `cop/graph/redistribute.py` still says "exact in any precision"; it is
  left as is because changing it changes the semantic code hash.
- **The mechanism interaction** tests whether routing changes the effect of a forward-equivalent reallocation of
  computation on learning. The edit also changes the parameters the optimizer trains (receiving layer, branch output
  factors), so it does not by itself identify one gradient pathway into the backbone. Routed edit, ordinary edit and
  interaction are reported together (`shift_under_ordinary_gradients` added beside the existing swap rows); a
  nonsignificant ordinary edit does not establish equality.
- **The late-head comparison** is between two complete interventions (cut location, activation, routing, size and
  compute all differ), reported beside routed against ordinary expansion at the same cut.
- **Image scope**: a binary task from eight CIFAR-10 classes plus a constructed shortcut channel; "causal" in the code
  names the image-content block; intervals over draws are conditional on this image corpus (shared test images and
  validation split), not twelve independent datasets.
- **Compact controls**: `expansion_history_beats_compact_continuation` compares a reset fork with a carried-state
  control; it supports "this protocol beats this compact continuation", not expansion history alone.
- **Fresh reload** checks the named endpoint, witness and transplant artifacts; it is not a check of every edit-event
  checkpoint (those are checked by the analyses, item 4).
- **Protocol effects and interpretation apart**: the registries report what each protocol does; the mechanism reading
  (routing x reallocation) is stated only in the mechanism registry's interpretation block.

## Wave 32: the reset-matched compact controls

For every f0 of waves 29 (MLP) and 30 (images), each compact control (compact_A, compact_B: the holds of the A and B
arms) at each fork age u in {1000, 2500}: f0 trained to u with the control's optimizer state carried, the optimizer
reset there, trained to 2U (the fork's remaining updates), its state at 2U measured as `compact_reset` at
(parent, fork). Contrasts `fork_minus_compact_reset` for every continuation. Registry rows (secondary, marked
`added_in_v66`, written after the v64 results were seen): `expansion_history_beats_reset_matched_compact` (folded_reset
against compact_reset at snap_2500, and at snap_1000 for the MLP), `routed_fork_against_reset_matched_compact`.
24 f0s x 2 controls x 2 fork ages x 2 settings = 192 jobs.

## Launcher (`scripts/66_v66_reaudit.sh`)

environment, four manifests (29 to 32) and their validation, CPU (and CUDA) tests, the image data; wave 32: parents
copied (v64's panel29 under the reuse audit, v65's panel30), a sample retrained and compared, then trained; its
status, checks, fresh reload, strict summary; the views (wave 32's controls only when it finished); fork29, image30,
fork31 (CPU, recorded device on CUDA), mech31; validity tables; prerequisites; registries and their comparison with
the earlier readings; panel state, evidence, packaging. A failed test run trains nothing and labels every registry.

## Tests

`tests/test_v66.py`: the registry reader on synthetic rows (validated; missing seed, missing draw, duplicate, extra
draw, cross-design, NaN, infinity, missing arm: not read; wrong manifest, schema, design, no contract: unbound;
failed audits: conditional, including an interaction's unedited forks; failed prerequisite or coverage: diagnostic;
no evidence: usage error); the registry comparison and prerequisite scripts; the v66 registries (primaries identical
to v63's / v65's, contracts, wording); `func_compare` and `within` against NaN and infinity; wave 32 as designed;
miniatures of waves 31 + 32 and 30 + 32 trained and analysed (reset-matched controls, integrity, storage, eligibility,
the mechanism diagnostics, the validity table, the bound registries validated); one copy with four tampered starts
(a shift's receiving layer moved within COMPOSE_TOL with every hash re-signed: structure passes, storage fails; a
swap's start changed by one ulp without a new hash: integrity fails; a NaN with re-signed hashes: integrity fails, no
zero discrepancy; a fold's start changed by one ulp: integrity fails), the other forks passing and the bound registry
not validating the affected hypothesis; an analysis batch size leaving the states; the read-only view.
`tests/test_v66_launcher.py`: the full sequence; failed wave-32 checks, failed v64 / v65 checks, reloads, summaries
and reuse verification, a missing earlier verdict, failed tests, an unfinished wave 32, a failed reuse verification,
a failed analysis (still read, labelled). Updated: `tests/test_v58.py`, `tests/test_v62.py`, `tests/test_v65.py`
(the schema and the bound registry call).

## Deferred (not needed for the current panels)

- A storage check before the first training step inside the training code (it would change the semantic hash).
- `affine_map` choosing its probe shape from the entry node's layout (needed only for a late affine fold after
  global pooling, which no panel has).
- Refusing duplicate branch slots and unequal branch structures in redistribution (the manifests never build them).
- A narrowly matched late affine all-gradient image arm (only if location-specific attribution becomes necessary).
- A full CNN training-to-analysis CUDA smoke test: the real wave-30 runs are reused by this re-audit on the GPU.

## What was executed here

The full CPU suite passed (1093 passed, 32 skipped: CUDA-only tests), with test_v58's fold-detail check updated for
the integrity prefix. Both v66 miniatures trained and analysed on the CPU (about 3 minutes together). No real job was
trained and no real run was re-audited here.

Negative tests (all fail as intended):

| case | v66 result |
|---|---|
| shift100 start, receiving layer moved by 9e-6 (inside COMPOSE_TOL), hashes re-signed | structure passes (v65 would have passed it and only flagged the draw); storage 8.3e-5 > 1e-5: `redistribution_storage` False, audit fails |
| swap start changed by one ulp, hash not re-signed | `check_ckpt`: saved tensors do not match the recorded hash, audit fails |
| NaN in a shift start, hashes re-signed | `check_ckpt`: non-finite tensors, audit fails, no storage value recorded |
| fold start changed by one ulp, hash not re-signed | `check_ckpt` fails, `fold_start` False |
| NaN / inf in a network compared by `func_compare` | infinite discrepancy, `within` False (v65's running max could report 0) |
| registry: missing seed, missing draw, duplicate, extra draw, cross-design, NaN, inf, missing arm | `incomplete`, not read, exit 1 (v65 averaged what it found) |
| registry: other manifest, schema or design; no contract | `unbound`, exit 1 |
| registry: a run's audit failed | `conditional` over the remaining pairs, exit 3 |
| registry: failed checks / reload / summary / reuse verification / tests | `diagnostic`, exit 3 (v65 wrote a plain reading) |
| real miniature: wave-29 registry on a panel without carried-state compacts | those two hypotheses `incomplete` with 0 rows, the rest validated |

The one-ulp cases would also have been caught in v65 by the exact unchanged-tensor checks, since the changed tensor
was one the edit must leave alone; the integrity check now catches them first and also covers tensors the edit
writes, where the formula checks allow tolerance.

In the tamper run every other fork passed, and the bound mechanism registry did not validate the hypothesis whose
fork failed.
