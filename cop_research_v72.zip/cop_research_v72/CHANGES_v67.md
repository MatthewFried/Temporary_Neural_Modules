# v66 -> v67: the registry localises a failed run audit

Semantic code hash `1f7856b2695b98dc`, unchanged. Only `scripts/replication_registry.py` and its tests changed. The
launcher, results folder and archive keep the v66 names (`scripts/66_v66_reaudit.sh`, `~/cop_results_v66`,
`cop_v66_reaudit_reports.zip`). Use this instead of v66.

    cd ~/research/cop_research_v67 && WORKERS=3 COP_VENV=~/fsc/.venv nohup bash scripts/66_v66_reaudit.sh > ~/v66.log 2>&1 &

Expect about 10 to 14 hours (v65 took about twice its estimate).

**Why.** v65's fork31 shows one redistributed start above the v66 storage certificate: B_routed_affine, snap_1000,
routed_shift50, draw 349 seed 0, storage 1.22e-5 (limit 1e-5; condition number of I + sM about 1e5; float32 forward
change 1.4e-3, no flipped prediction). Under v66 that run fails its audit, which fails the analysis coverage, and the
v66 reader then labelled every mechanism hypothesis diagnostic, although no registry hypothesis reads that run.

**Change.** A failed run audit is handled only through the audit table: rows that depend on that run make their
hypothesis conditional. The whole reading is diagnostic only when the analysis did not complete (an f0 failed, a run
or measure is missing), when audits failed and no audit table was given, or when a scientific prerequisite failed.
The analysis step itself still exits 1 and the launcher verdict still records it.

Test added: an audit failure elsewhere leaves unaffected hypotheses validated; without the audit table every reading
is diagnostic; an incomplete analysis is diagnostic. `tests/test_v66.py` and `tests/test_v66_launcher.py` pass (47),
and the earlier registry tests in `tests/test_v62.py` and `tests/test_v65.py` pass.
