# v67 -> v68: corrected analyses, an independent reference check, re-analysis of the saved runs

Trains nothing. Run after v67 has finished: v68 reads `~/cop_results_v64`, `~/cop_results_v65` and v67's
`~/cop_results_v66` (only through read-only views) and writes `~/cop_results_v68`.

    cd ~/research/cop_research_v68 && COP_VENV=~/fsc/.venv nohup bash scripts/68_v68_reanalysis.sh > ~/v68.log 2>&1 &

Archive: `cop_v68_reanalysis_reports.zip`. About 6 to 9 hours (tests about 45 minutes, the four analyses about 5 to
7 hours, the reference recompute and registries under an hour).

## Training semantics

No executable line under `cop/` changed. The semantic code hash moves from `1f7856b2695b98dc` to `bc8b176bcef7c906`
only because the docstring of `cop/graph/redistribute.py` was corrected (below). Four reuse audits
(`v68_from_v58`, `v68_from_v59`, `v68_from_v60`, `v68_from_v65` in `configs/reuse_audits.json`) accept every earlier
run for the new hash; run ids are unchanged. The review found no training defect, and the independent reference
(below) agrees with the training code in float64 to 1e-10.

## Fixes (from the v67 review)

1. **Mechanism first-update diagnostic** (`audit_v5/tools/mechanism_diagnostics.py`, rewritten). Each update is now
   one update of the actual trainer (`cop.train.Trainer`, the fork job's own configuration, a fresh optimizer
   configured as the fork configures it, the fork's masks and input hold), on a copy, on fixed batches. It reports
   the raw loss gradient, the gradient the optimizer used (held entries zeroed) and the actual displacement (held
   entries restored), with trainable and held coordinates apart. A held coordinate that moves fails the f0.
   Unsupported recipes (another precision, a backbone hold, a schedule whose first rate depends on the segment
   length) are refused. The numerical policy is applied and recorded.
2. **Registry evidence binding** (`scripts/replication_registry.py`). The analyses record the SHA-256 of their
   contrasts, audits and states tables in the coverage, every contrast row names the state records it was computed
   from (`depends_on`), and the coverage lists its design ids and failed runs. The reader needs `--audits` and
   `--states` and checks the table digests, unique audit keys, the audited count, that the failed runs match the
   coverage, that each design id is the coverage's, that each f0 is the manifest's f0 of its draw and seed, and
   that every dependency has a record (an audited fork or a measured state). A failed fork makes only its own rows
   conditional.
3. **Mechanism diagnostic completeness.** The design is fixed (both parents, the declared fork points, all seven
   continuations); anything missing fails the f0, never a smaller design. Rows of an f0 are kept only after the
   whole f0 passed. A non-finite gradient, update or comparison fails; a zero reference is reported as null with a
   status (`zero_reference`, `both_zero`). Summaries average seeds within draws, then draws.
4. **CUDA prerequisites.** Each registry receives the failed CPU tests, CUDA tests and "CUDA tests actually ran"
   checks of every run whose evidence it reads (v64, v65, v67 and this run). On a CPU-only run the CUDA steps are
   recorded as not applicable.
5. **Normalisation eligibility per row.** A normalised layer is eligible only when every row (per block) satisfies
   |achieved - target| <= 1e-8 + 1e-5 x |target|. The states table reports the largest per-row relative error, the
   largest absolute error and the failed-row count. The normalised-layer probe is no longer fitted for an
   ineligible layer.
6. **Branch regrowth** reads the merge input at the group's entry node (no subtraction), reports each branch's
   output rms, their aggregate, the net output, the cancellation ratio, and the largest output weight and bias.
   Every path checkpoint, the ordinary edited start, the start and the end pass `check_ckpt`; updates must increase;
   the saved split must equal the split recomputed from its definition and every routed fork's recorded hash.
7. **Registry comparison** (`scripts/compare_registries.py`) reports status, reading, estimate, interval,
   membership and key changes separately.
8. **Deployed computation.** A fold or redistributed start that is not finite in float32 on the analysis device or
   on the training device fails its audit. `func_compare` checks every derived statistic before accumulating.
9. **Views** are marked and swapped in only after the new view is built; a directory that is not a view, a view
   overlapping a source, or a configuration conflict is refused with the old view untouched.
10. **Docstring of `cop/graph/redistribute.py`**: the swap moves tensors exactly but its forward sum can differ by
   summation order; shift100 keeps zeroed, trainable output layers (not a removal).

## The independent reference (`audit_v5/tools/reference_impl.py`)

Raw `torch.nn.functional`, no graph or trainer code: the MLP and `cnn_cut` networks read from a saved model dict,
the routed merge (forward with every branch; gradient through branch j times its mask, the skip never masked),
cross entropy written out, AdamW written from its definition with the input hold, and the fold, swap and shift.
`tests/test_v68_reference.py` checks against the implementation: logits, h, every branch output and the merge
(1e-12); every parameter gradient and the gradient at h, ordinary and routed with mixed, all-a and all-b batches,
and batch permutation (1e-10); the ordinary rule against finite differences and the routed rule shown to differ
from them; four trainer updates (one fresh, three carried) against the written AdamW in parameters and both
moments, with and without the hold, with weight decay, the held entries exactly unchanged; the fold, swap and
shift; and (on CUDA) float32 on the GPU against the float64 reference.

`audit_v5/tools/reference_recompute.py` (run by the launcher as ref29, ref30, ref31) recomputes real checkpoints:
the most harmful f0 (by the A arm's normalised extraction at the trajectory end) and the median one; f0, the fork
start, the trajectory end, routed_reset, ordinary_reset and folded_reset ends of both arms: native error, the
transplanted first layer, the normalised layers built independently, and the fold of the snapshot against the saved
fold. Each is compared example by example with the implementation (a decision may differ only at a near tie) and
with the analysis's states table.

## Re-analysis outputs

`fork29`, `image30`, `fork31` (analysis schemas `/v68`), `mech31`, validity tables, `ref29/30/31`,
`registry29/30/31` with `changes_v67_*` (against v67's re-audit) and `changes_orig_*` (against v64's / v65's
readings), and the prerequisites passed to each registry. The registries `configs/v66_*` keep their hypotheses; their
contracts now read the `/v68` analysis schemas.

## Tests

`tests/test_v68.py`: the reader against bound tables (validated; 14 incomplete cases; 12 unbound cases including an
empty audit table, a missing failed row, a duplicate audit key, another analysis's audits or states, a contrast
changed after the coverage, a coverage hiding a failure; a failed fork making only its rows conditional, a failed
fork no hypothesis reads leaving the others validated, an interaction depending on four forks; diagnostic cases);
the comparison flags; prerequisites with CUDA steps; the per-row norm check; overflowing derived statistics; the
diagnostic's null statuses and refusals; view safety; a waves 31 + 32 miniature (bound outputs and dependencies, the
diagnostic with the hold and its five refusals: a dropped edit, a dropped regrowth fork, a tampered path checkpoint,
a renamed path checkpoint, a stale split; nothing of a failed f0 kept), the reference recompute on the miniature.
`tests/test_v68_reference.py` as above. `tests/test_v68_launcher.py`: the full sequence without training, wave 32
in the views only when v67 trained it, failed or empty CUDA runs, a passing CUDA run, failed source prerequisites
(v64, v65, v67, CUDA included) labelling exactly the registries that read those runs, failed tests, a failed
analysis. Updated: `tests/test_v58.py`, `tests/test_v59.py`, `tests/test_v62.py`, `tests/test_v65.py`,
`tests/test_v65_launcher.py`, `tests/test_v66.py` (schemas, audit ids, the bound registry call; the synthetic reader
tests moved to test_v68).

## What was executed here

The full CPU suite passed (1149 passed, 34 skipped: CUDA-only tests, including the two GPU reference cases, which
run on your machine in the launcher's CUDA step). Miniatures of waves 31 + 32 and 30 + 32 were trained and analysed on
the CPU. No real run was analysed here.

On the miniatures: the reference matched the implementation to 1e-12 in the forward pass and 1e-10 in every
gradient and in four trainer updates (parameters and both Adam moments), MLP and CNN, ordinary and routed; the
recomputed checkpoints (47 rows per miniature) agreed example by example with no disagreement outside a near tie and
matched the states tables exactly; the diagnostic's held coordinates moved by exactly zero, the ordinary edits
changed the first update by rounding only (1e-7 in float32, 1e-16 for the swap in float64), and the routed edits by
6 to 16 percent of the gradient.
