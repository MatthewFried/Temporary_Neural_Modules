# v68 -> v69: a strict reference, bound to the registries; a design that cannot shrink

Trains nothing. Run instead of v68 (v68 does not need to have run). Reads `~/cop_results_v64`, `~/cop_results_v65`
and v67's `~/cop_results_v66` (only through read-only views) and writes `~/cop_results_v69`.

    cd ~/research/cop_research_v69 && COP_VENV=~/fsc/.venv nohup bash scripts/69_v69_reanalysis.sh > ~/v69.log 2>&1 &

Archive: `cop_v69_reanalysis_reports.zip`. About 7 to 10 hours (tests about 50 minutes, the reference preflight
under an hour, the four analyses 5 to 7 hours, the final reference and registries about an hour).

**`package_final exit 0` means the archive was written. It is not a scientific pass.** The outcome is
`verdict.json` and the status of each registry.

## Training semantics

No line under `cop/` changed. Semantic code hash `bc8b176bcef7c906` (unchanged from v68); the v68 reuse audits apply.

## Fixes (from the v68 review)

1. **Separate certificates** (`audit_v5/tools/reference_recompute.py`, schema `reference_recompute/v69`). Every row
   must pass each of these, recorded separately:
   - `function64`: the implementation in float64 against the reference on the same stored tensors, every logit,
     |dz| <= 1e-9 (1 + |z_ref|);
   - `deployed`: the implementation as deployed (the analysis device, float32, `cop.train.trainer.predict`, the
     evaluation batch) against the float64 reference, every logit, |dz| <= 1e-4 (1 + |z_ref|), and the decisions (2);
     `deployed_extra` the same on a second device (`--extra-device`, the GPU on your machine);
   - `params`: the normalised layers built here against the implementation's (1e-9 + 1e-6 |W|); the fold against
     the saved fold with a float32 product bound; the swap and shift edits against the saved starts;
   - `eligibility`: an ineligible normalisation must be ineligible in both and have no table value;
   - `table`: the states table's error times n equals the implementation's wrong count exactly. A missing,
     non-finite or off value fails; a missing or duplicate states row makes the reference incomplete.
2. **Per-example decision bounds.** Example i is decided when its reference margin exceeds 2 b_i, with
   b_i = 1e-4 (1 + max |z_ref[i]|), its own allowed perturbation. A decided example that differs fails. An undecided
   one may differ only within the logit bound, and at most 0.1 percent of the examples may be undecided and differ.
   No dataset-wide scale, no allowance from the number of ties. (v68's rule used the observed perturbation, so a
   decided disagreement was impossible by construction.)
3. **The reference reaches the registries.** `registry29` needs `ref29` complete, `registry30` needs `ref30`,
   `registry31` needs `ref29`, `ref31` and `mech31`. A complete reference with failed rows lists the states
   (`ref*_failed_states.txt`); the registry is given them with `--exclude-states` and the rows that depend on them
   become conditional (`reference_exclusions` in the record). An incomplete reference makes the registry
   diagnostic. The coverage binds the states table (SHA-256), the manifest, the parameter hash of every checkpoint
   read, the numerical policy, and expected, checked and missing case counts.
4. **A bounded plan of real checkpoints** (`*_plan.json`), declared before checking: the most harmful f0 and the
   median one (`--n-f0`, 1 or 2; fewer selectable f0 fail), both fork points, every continuation, the fork start,
   the trajectory end, the fold start (later fork included), f0 itself; for wave 31 the five mechanism ends, the
   saved swap and shift starts, and the f0 of the most ill-conditioned redistribution (required: without the
   audits' conditioning the plan fails). Wave 30 (the image case, including the most harmful f0) is recomputed on
   the GPU; waves 29 and 31 in float64 on the CPU with the GPU as the extra device.
   **Preflight:** the launcher runs this plan first on v67's states (no table check). A failed or incomplete
   preflight stops the analyses (`FORCE=1` continues) and the reports are packaged for diagnosis. The same plan
   then runs again with table checks on the new states tables.
5. **Mechanism diagnostic completeness** (`mechanism_diagnostics.py`, schema `/v69`). The expected f0 come from the
   design (every f0 with parents), not from the mechanism entries present; `--expect-f0 N` (24 in the launcher)
   must match. The path checkpoints must be exactly the updates promised by the run's own path record (beyond the
   start), each with its update in its metadata; a missing intermediate, a missing update or only the end fails.
6. **Optimizer tests** (`tests/test_v68_reference.py`). Three trainer updates, each compared with AdamW recomputed
   from the trainer's state before it: every parameter's displacement (sensitive coordinates bounded by
   (1 - b1) / sqrt(1 - b2) lr), both moments, and the per-tensor step counters; with and without the hold, with
   weight decay. The GPU test (four named cases, MLP and CNN, A and B hold, with and without weight decay, TF32 off)
   compares logits, the gradient at h, every gradient, and three updates in float32 against float64 with mixed
   tolerances. `junit_ran.py --require` makes the launcher fail unless the four named CUDA cases ran. A grown
   network keeps per-tensor ages (old tensors at step 3, new at 1); an interrupted segment resumes bit for bit; a
   1 percent gradient error fails the stepwise check. `tests/test_v69.py`: AdamW imported from a real saved
   trajectory state (backbone tensors at step 50, branch tensors at 10) gives the trainer's next update.
7. **Reference architecture contract** (`reference_impl.py`). The chain is walked back from the output and must be
   exactly an MLP (input, (linear, relu)*, head) or `cnn_cut`; kernel, stride, pooling, gates, side outputs, frozen
   batch norm and unused or reused parameters are refused (14 mutated networks). The fold, swap and shift build
   on the network's device.
8. **Views.** A view path that is itself a symlink is refused before it is resolved.

## Tests

`tests/test_v69.py`: the strict reference passes on a waves 31 + 32 miniature (standard and mechanism plans, both
fork points); fails with doubled logits (decisions unchanged), 0.1 percent off normalised weights, two examples
swapping correctness (the same error rate), a dropped or duplicated states row (incomplete), a missing,
non-finite or off-by-one table value; a plan shortfall (two f0 requested, one present; mechanism plan without
audits) fails; per-example decision bounds; `--exclude-states`; mechanism design shrinkage (an f0 without its
mechanism forks, `--expect-f0`, a dropped path checkpoint, a path checkpoint without its update, only the end); a
real carried optimizer state; `junit_ran --require`; a symlinked view path. `tests/test_v69_launcher.py`: order,
a failed preflight stops the analyses, `FORCE=1`, missing v67 tables, reference exclusions, an incomplete reference
labelling exactly its registries, the named CUDA gate. Updated: `tests/test_v68.py` (v69 names and plan).

## What was executed here

The full CPU suite: 1205 passed, 36 skipped (CUDA-only, including the four GPU reference cases, and one data test). test_v69 22 passed, test_v69_launcher 13, test_v68 46, test_v68_reference 37 passed and 4 skipped (CUDA), test_v68_launcher 14. The CUDA cases run on your machine in the launcher's `cuda_tests`
step and are required by name. On the miniatures the strict reference passed every certificate: MLP standard plan
117 rows, mechanism plan 100 rows, CNN 117 rows (at most 1 undecided example of 240, no differing decision). No
real run was analysed here.
