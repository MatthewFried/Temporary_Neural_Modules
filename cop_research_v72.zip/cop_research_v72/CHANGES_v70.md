# v69 -> v70: a tolerance that follows the network's conditioning, every f0, values recomputed, a retrained sample

**v71 correction.** Where this file says "bound" for the rounding check, read "first-order estimate": it neglects second-order terms and activation changes (ReLU signs, max-pool winners), assumes direct summation, and for wave 30 is computed in float32. It is an empirical consistency check, not a rigorous upper bound (CHANGES_v71.md).

v69's preflight stopped its run: on 44 of 768 rows the deployed float32 logits missed the fixed tolerance
1e-4 (1 + |z|) (worst 70 times over). In float64 every row matched the reference to 1e-9 and every parameter
certificate passed; only one state changed decisions (wave 31, f0 `base-e992...`, B, snap_1000, the shift50 edited
start, the most ill-conditioned edit; 3 clearly decided examples). The fixed tolerance was the error: float32 rounding
grows with the size of the intermediate sums, not of the output, and these networks (and especially the shift edits,
which put W (I + M)(I + M/2)^-1 into the receiving layer) cancel large terms.

Run after v69 has finished (with or without `FORCE=1`):

    cd ~/research/cop_research_v70 && COP_VENV=~/fsc/.venv nohup bash scripts/70_v70_reanalysis.sh > ~/v70.log 2>&1 &

Archive: `cop_v70_reanalysis_reports.zip`. `package_final exit 0` means the archive was written; the outcome is
`verdict.json` and each registry's statuses. The launcher exits 1 whenever any step is not 0, which includes fork31's
known audit failure.

## Training semantics

No line under `cop/` changed. Semantic code hash `bc8b176bcef7c906` (unchanged). The only training is the retrained
sample (4 below), written under `~/cop_results_v70`.

## Changes

1. **The deployed check uses a rounding bound per example and logit** (`reference_impl.rounding_bound`,
   `reference_recompute.py`, schema `reference_recompute/v70`). Each rounding operation's local error is bounded by
   Higham's gamma_n = n u / (1 - n u) (affine layer or convolution over n inputs: gamma_{n+1} (|W| |h| + |b|); the
   merge sum; the global average), u = 2^-24, for any summation order. These local errors are carried to the logits by
   the network's own signed Jacobian (autograd, one backward pass per logit): E_c = sum |dz_c / dy| d. This is the
   standard first-order bound: terms of order u^2 and ReLU units within rounding distance of zero are neglected, and it
   assumes direct summation in each dot product (not Winograd or FFT convolution). The deployed logits must satisfy
   |z32 - z| <= E; an example is decided when every other class trails the top class by more than the sum of their
   two bounds; a decided example may not change, and at most 0.1 percent of the examples may be undecided and change.
   A fully rigorous bound (propagating |W| through every layer) was tried first and is useless here: it grows about
   4.5 times per layer and reached half the logits' size.
   Also recorded per row: v69's fixed-tolerance numbers (`fixed1e4_*`, not a criterion), the reference's own error
   count (`exact_wrong`) and float32's (`deployed_wrong`), and the bound's size (`bound_rel_max`).
2. **The reference covers every f0** of waves 29 and 31 (`--n-f0 all`) and, by default, of wave 30 (`N30=all`;
   `N30=6` takes 6 f0 evenly spaced over the harm ranking). Wave 30's float64 reference runs on the GPU
   (`--ref-device`), its bound's Jacobians in float32 (`--bound-dtype float32`).
3. **The registry recomputes every value from the states table** (`replication_registry.py`), with rules written
   from the comparisons' definitions (first minus second; against f0, the fork start, the matched compact or the
   reset-matched compact; arm against arm; the interactions (first - routed_reset) - (second - ordinary_reset)). Each
   must equal the contrasts table's value exactly (both are differences of the same stored floats); otherwise the
   hypothesis is incomplete. The summary is computed from the recomputed values. On the three miniature analyses the
   rules reproduce all 41,056 contrast rows exactly.
4. **A retrained sample** (`scripts/retrain_sample.py`). Per wave, runs retrained from scratch and compared with the
   saved ones value by value: every tensor element (torch.equal), every number and record, optimizer and trainer
   state; no hashes. Wave 29: the most harmful f0, its A trajectory and baseline, routed_reset and ordinary_reset at
   snap_1000, folded_reset at snap_2500. Wave 31: the ill-conditioned f0, B snap_1000 routed_shift50 (the flagged
   start) and A snap_1000 routed_swap and ordinary_swap, with their trajectories and baseline. Wave 30: the most
   harmful f0, A snap_1000 routed_reset and ordinary_reset. A sample that does not reproduce makes its registry
   diagnostic. `RETRAIN=0` skips it (the verdict then shows the skipped steps).
5. **v69's analyses are reused when nothing they depend on changed** (`scripts/reuse_v69.py`): every file of the v69
   and v70 code folders is compared byte for byte (filecmp), apart from v70's declared changes; v69's verdict.json
   must exist and be newer than every file taken, record the analysis and view steps, and the analysis coverage must
   say complete. Otherwise the analysis runs here. The archive holds v69's step logs (`*_v69.txt`).
6. The CUDA gate also requires `test_cuda_float32_within_the_rounding_bound` (MLP and CNN) by name.

## Tests

`tests/test_v70.py`: the bound holds on random MLP and CNN networks (3 seeds each; largest observed ratio 0.026)
and on shift edits with I + M/2 nearly singular (the bound grows with the conditioning while the observed error stays
below 5 percent of it; the fixed 1e-4 tolerance fails there exactly as on the real runs, worst 20 times over);
logits moved by twice the bound, a decided example that changes, and too many changing ties fail; the reference
passes every f0 of the miniature in both plans; `--n-f0` is validated; nudged deployed logits fail; the registry's
rules reproduce every miniature contrast, and a tampered contrasts or states value (1e-12) makes the hypothesis
incomplete; a comparison without a rule is not read; the value-by-value comparison finds one changed unit in the last
place, a changed record or a missing checkpoint; a retrained miniature sample reproduces element for element; reuse
of v69 is refused for a changed or new code file, a missing verdict, an incomplete analysis, a failed view, or a file
newer than the verdict. `tests/test_v70_launcher.py`: order, full and partial reuse, exact registry labelling for
each missing piece of evidence, `RETRAIN=0`, `N30`, the CUDA gate. Updated: `tests/test_v68.py` (synthetic states
tables now hold the values), `tests/test_v69.py` (decisions take a bound).

## Time

With v69's analyses reused: tests about 45 minutes, the wave 29 and 31 references about 15 minutes, the wave 30
reference about 4 to 6 hours on the GPU (an estimate: its float64 speed on the A4500 was not measured), the
retrained sample about 1 to 2 hours. About 6 to 9 hours in all; `N30=6` saves about 3 hours. Without reuse, add
v69's analyses (5 to 7 hours).

## What was executed here

The full CPU suite: 1243 passed, 38 skipped (CUDA-only and one data test); test_v70 25 passed and 2 skipped (CUDA), test_v70_launcher 13 passed. The v70 reference on the miniatures: MLP standard plan 117 rows and
mechanism plan 100 rows, every f0, all passed (largest observed error 5 percent of the bound); CNN 117 rows passed
(0.3 percent). No real run was analysed here.
