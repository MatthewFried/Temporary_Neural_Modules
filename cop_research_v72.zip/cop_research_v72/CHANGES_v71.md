# v70 -> v71: the close-out

Report-only. Trains nothing, re-analyses nothing. Reads v70's reports (`~/cop_results_v70/v70_reports`, never
written) and writes `~/cop_results_v71/v71_reports`.

    cd ~/research/cop_research_v71 && COP_VENV=~/fsc/.venv nohup bash scripts/71_v71_closeout.sh > ~/v71.log 2>&1 &

Archive: `cop_v71_closeout.zip`. `CKPT=0` leaves checkpoint hashes out of the release manifest; `DIAG=0` skips the
diagnosis.

## Training semantics

No line under `cop/` changed. Semantic code hash `bc8b176bcef7c906` (unchanged). `replication_registry.py` was
refactored (its comparison rules split into `operands` and `combine`, used by the exports); on the three miniature
analyses it reproduces all 41,056 contrast rows exactly, as before. v70's registries are not recomputed.

## Changes

1. **Terminology.** v70's rounding check is a first-order rounding-error estimate and an empirical consistency
   check, not a rigorous bound. It neglects second-order terms and changes of activation pattern (ReLU signs, max-pool
   winners), assumes direct summation (no Winograd or FFT convolution), and for wave 30 its Jacobians are computed in
   float32. Docstrings and documents are corrected; the code names are kept for compatibility, and the reference's
   coverage records `estimate_kind` and `estimate_assumptions`. The separate checks stay separate: float64
   implementation agreement, parameter edits, deployed decisions, the table, and this estimate.
2. **Registered pairs** (`scripts/export_registered_pairs.py`). One row per hypothesis, data draw and optimizer seed:
   the f0, the operand states and their values, the contrast, its favourable value, eligibility and the exclusion
   reason (excluded pairs stay as rows). Each hypothesis's mean, 95% interval, its own interval, pairs, draws and
   draws favourable are recomputed from these rows and must equal the registry to 1e-12 (`registry*_check.csv`).
   On the v70 reports: 36 of 36 hypotheses reproduce, with differences of exactly 0.
3. **Float64 sensitivity** (`scripts/float64_sensitivity.py`). Every hypothesis whose operands the reference evaluated
   is recomputed from the reference's exact (float64) error counts. On the v70 reports: 24 hypotheses covered,
   including the 8 primaries named in the review; no reading changes; the largest change of a mean is 5.6e-17. The
   registered float32 operand values match the reference's deployed counts exactly. Compact and late-head contrasts
   are listed as not covered, with no float64 number.
4. **Diagnosis of the one estimate exceedance** (`scripts/diagnose_estimate_failure.py`, no training). For the
   failing ref29 state: the offending example and logit, float64, CPU and GPU float32 logits, the same example
   evaluated alone, the estimate, the margin, and per graph node how many float32 pre-activations change sign against
   float64. It records; it changes no status. The exception stays whatever it finds.
5. **FINAL_FINDINGS.md** (`scripts/final_findings.py`): (a) supported findings, (b) contrary and inconclusive
   findings, (c) the two validation exceptions, (d) numerical assumptions and checks, a validation record, the
   mechanism diagnostics, and the final status. Every number is read from a file and printed with its source.
6. **Paper figures** (`scripts/paper_figures.py`, PDF and PNG with captions): component effects (synthetic and
   image), late folding against f0 and the compact controls, the swap interaction with the first-update diagnostics,
   and (supplementary) regrowth with per-f0 curves and medians. Every extraction caption says the measure places the
   first layer in f0 with the specified norms and bias restored, and is not native accuracy.
7. **Release manifest** (`scripts/release_manifest.py`): SHA-256 of the code, the v70 and v71 report files and every
   checkpoint file of the three panels (a view's symlinks are followed and the real path recorded), and the final
   local v70 verdict with the statement: completed with two localized validation exceptions, not all checks passed.
   The hashes identify what was released; the evidence is the recomputation recorded elsewhere.

## Kept as they are

The fork31 storage certificate failure (1.218e-5 against 1e-5) and the ref29 estimate exceedance; the two late
mechanism secondaries stay conditional (23 of 24 pairs). The experiment phase is closed (DEVIATIONS 375 to 378).

## Tests

`tests/test_v71.py`: the export reproduces the registry, keeps excluded pairs (audit and reference) as rows and
fails when the registry differs by 1e-9; float64 sensitivity uses the f0 native row, reports nothing for an
uncovered operand, moves by exactly the changed count, and counts a deployed count that disagrees; the findings and
figures run on a fabricated complete input set and cite sources (no em dashes); the release manifest follows a view
to the real run folder and fails on a missing run; the diagnosis runs on the miniature; the reference's coverage
names the check an estimate. The launcher ran here end to end on the real v70 reports (without checkpoints and the
diagnosis, which need your machine).

## What was executed here

The full CPU suite (1252 passed, 38 skipped: CUDA-only and one data test; test_v71 9 passed) and the close-out on the real v70 reports, which reproduced every
registry exactly. No training and no analysis of checkpoints.
