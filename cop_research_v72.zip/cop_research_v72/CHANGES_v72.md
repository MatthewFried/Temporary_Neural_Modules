# v71 -> v72: release-integrity and reporting safeguards for the close-out

Report-only. Trains nothing, re-analyses nothing, and changes no result, threshold or exclusion. Reads v70's reports
(`~/cop_results_v70/v70_reports`, never written) and writes `~/cop_results_v72/v72_reports`.

    cd ~/research/cop_research_v72 && COP_VENV=~/fsc/.venv nohup bash scripts/72_v72_closeout.sh > ~/v72.log 2>&1 &

Archive: `cop_v72_closeout.zip`. It replaces v71's close-out (v71's launcher is removed; its scripts' interfaces
changed).

## Training semantics

No line under `cop/` changed. Semantic code hash `bc8b176bcef7c906` (unchanged).

## Fixes (from the review of v71)

1. **Release manifest.** v71 hashed `release_manifest.txt` while it was still empty, so the delivered log did not
   match its listed hash. Files still being written when the manifest is made (the manifest itself, its step's log,
   `verdict.json`, `verdict_steps.txt`, the packaging and verification logs) are no longer listed; they are recorded
   under `excluded_mutable` with their reasons (`--exclude`). New `release_manifest.py verify`: re-hashes every listed
   code and report file on disk and checks every file the archive delivers: a delivered file must be listed with the
   same hash or be a declared exclusion, and a listed file not delivered must be in `skipped_large_files.json`. The
   launcher runs it after packaging (`verify_release`, logged inside the archive) and again on the final archive
   (`verify_final`, in the local verdict).
2. **Reporting stops on inconsistent evidence.**
   - `float64_sensitivity.py` exits 1 when a registered float32 operand disagrees with the reference's deployed count.
     A float64 change in a mean or a reading is still reported, not treated as a failure.
   - `final_findings.py` derives every statement about checks from an explicit release check, lists all of them in
     the document (`## Release checks`), and writes a release-ready document only when all pass: the per-pair export
     reproduces every registry; the registries' recomputation from the states tables found no mismatch and covered
     every row; every status is validated or conditional and every exclusion refers to a declared exception; no
     float64 operand mismatch; every float64 function, parameter, eligibility and table certificate passed; the failed
     reference rows and fork audits are exactly the declared exceptions (and the declared reference row failed only
     the certificate its declaration allows); every retrained run reproduced; the mechanism diagnostic is complete; no
     test failed; the verdict's nonzero steps are the declared ones. Otherwise the document opens with
     `NOT RELEASE-READY` and the failed checks, and the step exits 1. A missing input does the same.
   - The two exceptions are declared once, in `configs/v72_declared_exceptions.json`, and kept as recorded.
3. **Missing audits.** `export_registered_pairs.py` (now with `--coverage`) requires a passing validation record of
   the operand's kind: a fork continuation needs its row in the audits table with `audit_passed` True (a missing row
   now excludes the pair); f0 needs every expected f0 analysed and itself not failed; a matched compact needs its
   (parent or hold, label) in the coverage's `compact_controls`; a reset-matched compact its (parent or hold, fork) in
   `compact_reset_controls`; a trajectory end its arm in the coverage's design. On the v70 reports every operand has
   its record, and all 36 hypotheses still reproduce exactly.
4. **Descriptions.**
   - Raw extraction places the state's first layer, weights and bias, in f0 unchanged; normalised extraction rescales
     the weights per unit and input block to f0's norms and uses f0's first-layer bias. Only the latter restores f0's
     norms and bias. Figures, captions and FINAL_FINDINGS.md say so.
   - The rounding estimate uses the activation pattern of its own evaluation, in its dtype (float64 for waves 29 and
     31, float32 for wave 30); the documents state the dtype per wave from the reference coverage.
   - The diagnosis records that the excess depends on the evaluation batch and that one activation sign changes; it
     does not establish which caused the excess.

## Tests

`tests/test_v72.py` (28): the manifest declares mutable files and verifies a delivered archive; a file changed on
disk, changed in the archive, delivered but unlisted, listed but not delivered, or a changed code file fails
verification; fourteen kinds of corrupted evidence each give NOT RELEASE-READY with the named check; four kinds of
missing evidence do the same; the declared exceptions alone are release-ready; a fork operand without an audit row
is excluded; f0, compacts and trajectory ends are judged by their own records; the corrected wording. Updated:
`tests/test_v71.py` (new interfaces; the sensitivity mismatch now fails).

## What was executed here

The full CPU suite (1280 passed, 38 skipped: CUDA-only and one data test) and the v72 close-out end to end on the real v70 reports (without
the checkpoint hashes and the diagnosis, which need your machine): every step 0, the findings release-ready, and the
archive verified against the manifest (1,823 files on disk, 31 in the archive, no mismatch).
