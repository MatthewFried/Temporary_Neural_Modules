# Coverage of the twenty work packages

Status vocabulary: **implemented** (code exists and has a runnable configuration), **exercised** (ran end to end in the sandbox at smoke scale on CPU, so the code path works; these are not results), **analysed** and **confirmed** (none yet: no full-budget or GPU runs exist). Job counts are for `--scale full`; `python -m cop.cli generate-manifest --wave 0,1,2,3,4,5 --dry-run -v` prints them.

| WP | Implementation | Manifest blocks | Status |
|---|---|---|---|
| E1 layered expansion | `experiments/growth.py` `Grower._t_layered` (shapes chain / wide / alternating / separated, linear vs nonlinear), `compute_schedule` per_round / total | W1_core, W1_* breadth, W2_*, W3_E1_*, W3_I1_compute_*, W3_hard_fixed_matrix | implemented, exercised |
| E2 branched expansion | `graph/edits.py` `insert_group`, `add_branch` (sum / concat-projection / routing merges, tied or untied, channel subsets, input bridges, gradient-mask specialisation, aux heads), `insert_dup_branch`, `insert_cancel_pair`; programs `_t_parallel`, `_t_dup_branch`, `_t_cancel_pair`, `_t_complementary`, `_t_specialized` | W1_core (parallel), W3_E2_*, W3_I4_competition_sharing_* | implemented, exercised |
| E3 recursive expansion | inner cutpoints of every implant; `_t_recursive`, `_t_recursive_branch`, `_t_tree_depth2` (breadth-first vs depth-first, same final graph), `_t_hard_submodule`, `_t_recursive_descendants`, `_t_chain_in_branch`; schedules incremental / all_at_once / from_scratch | W1_core, W3_E3_*, W3_E3_order_*, W3_schedules_*, W3_cross_* | implemented, exercised |
| E4 cut location and granularity | cutpoint kinds per family, `cut_where`, `channels` (nested first-k or random), `cut_subset` (edge cuts), `positions` (token / spatial), permutation control | W3_E4_* | implemented, exercised (MLP; ResNet/Transformer edge and token cuts exercised in Wave-0 controls and tests) |
| E5 how dependence begins | constructions A-F x freeze policies (`train/trainer.py` `trainable_pkeys`), SGD/AdamW, weight decay, optimizer-state preserve/reset; known computations `growth.make_known_module` (poly, pretrained, random matched) | W0_controls_*, W3_E5_* | implemented, exercised |
| R1 deletion | `experiments/deletion.py` `family`, `evaluate_family` (exhaustive <= 10 atoms, structured otherwise, certificates, J(A,B)); single deletions every round | every trajectory, W4_R1_deletion | implemented, exercised |
| R2 repair region and budget | `experiments/repair.py` (8 regions x 3 targets x budget ladder x seeds, censored reach table, extension) | W4_R2_R4_repair | implemented, exercised |
| R3 finite certificates | `finite/` (boolean classes, rank, message, piecewise) with independent `finite/checker.py`; linear-rank data block | W0_finite_validation, W4_R3_*, W1_linear_rank | implemented, exercised |
| R4 what must be preserved | every repair evaluation records task, expanded, original, rare/shift distances; deletion certificates for task and expanded criteria; group metrics | W4_R2_R4_repair, W1_shortcut_rare, W1_delayed_query | implemented, exercised |
| R5 paths back | `experiments/dissipation.py` (abrupt, linear, cosine, residual penalty, inverse restore, branch merge, group removal, peg-style replacement; joint / ancestor-first / descendant-first; speed) | W4_R5_paths | implemented, exercised |
| I1 longer histories | rounds 1-32 (64 on a small case), constant per-round vs total compute, all-at-once and from-scratch | W3_E1_*, W3_I1_*, W3_hard_fixed_matrix | implemented, exercised |
| I2 what drives the history | drivers fixed / fresh / changing_target / output_constrained / neutral_mutation / stationary_self | W1_fresh_vs_fixed, W1_sample_size_matching, W3_I2_* | implemented, exercised |
| I3 insertion policy | `Trajectory.choose_cut` (random, dependence-seeking, removability-preserving; equal candidates and probe budgets; training data only) | W3_I3_* | implemented, exercised |
| I4 switches | communication-limited implants (`insert_residual_peg`), stable pegs, aligned / antagonistic aux, replacement pressure, routing competition, sharing, noise | W1_noise, W3_I4_*, W3_cross_* | implemented, exercised |
| I5 finite transition systems | `finite/transition.py` (BFS with cap, SCC, closed classes, absorption, return labels) | W0_finite_validation, W4_I5_transition | implemented, exercised |
| P1 where pegs belong | `cop_pegs/chain.py` placement regular / random / known / adaptive, edits move / split / merge, branch pegs shared / separate, bypass audit | W5_P1_* | implemented, exercised |
| P2 what a peg transmits | `cop_pegs/pegs.py` (continuous widths, uniform bits, codebooks, multiple messages, temporary channel retired and removed), `graph/accounting.py` | W5_P2_* | implemented, exercised |
| P3 alternatives | `cop_pegs/alternatives.py` (reference + mlp / lowrank / linear / sparse / table / attention / conv alternatives; five training modes; enforced finite interfaces; held-out assemblies and inputs; local matching; aligned adapters; saved modules + fresh-process reload) | W5_P3_* | implemented, exercised |
| P4 recursive splitting | `cop_pegs/split.py` (hard pearl by validation, 2/4/8 sub-pearls, shared recurrent variant, matched and unconstrained budgets, sub-pearl re-fit) | W5_P4_* | implemented, exercised (vector) |
| P5 expand-narrow-replace cycles | `cop_pegs/cycles.py` (four orders, fixed / relearned / no pegs, reopen; measured work by phase) and the section-10 baselines, with matched endpoint controls (direct_small, distill) for every history variant | W5_P5_*, W5_P5_matched_*, W5_baselines_* | implemented, exercised |

Factorial products: Wave 1 core 3 x 3 x 2 x 5 x 3 x 3 = 810 trajectories (162 shared baselines; the 'none' topology is the continued baseline of its cell); Wave 2 images 3 x 3 x 2 x 5 x 3 = 270 trajectories. `validate-manifest` recomputes both from the manifest and checks that every cell is distinct.

## v2 smoke sample: status and validity per work package

Frozen v2 code (semantic hash `5f0fc17a02584937`), CPU, `--scale smoke`: the first job of every block of waves 0-5 and the wave-9 pilot, plus prerequisites (`sandbox_checks/sampled_runs/`). These counts show that the code paths run and pass their contracts. They are not results. A job counts towards every work package it is tagged with.

| WP | complete, valid | other |
|---|---|---|
| E1 | 54 | |
| E2 | 11 | |
| E3 | 22 | 1 CIFAR-10 job stopped by hand (CPU time) |
| E4 | 16 | |
| E5 | 2 | CUDA controls run on the GPU machine |
| R1 | 24 | |
| R2 | 2 | |
| R3 | 7 | |
| R4 | 3 | |
| R5 | 1 | |
| I1 | 19 | 1 CIFAR-10 job timed out at the 900 s CPU limit; 1 stopped by hand |
| I2 | 6 | |
| I3 | 3 | |
| I4 | 10 | |
| I5 | 4 | |
| P1 | 19 | |
| P2 | 21 | |
| P3 | 10 | all 7 sampled alternatives runs reload bitwise in a fresh process |
| P4 | 3 | all 3 sampled split runs reload bitwise |
| P5 | 9 | 3 matched controls, each equal to its parent endpoint |

No sampled job is `invalid`, `unverified` or `failed`. The remaining CIFAR-10 jobs (29) were not sampled on this CPU; the wave-9 pilot covers CIFAR-10 on the GPU.

## v3 strengthening extension (wave 7)

Every one of the 50 registry variants F01a-F10e has at least one applicable cell. The cells, with their blocks and smoke statuses, are listed in `configs/strengthening_registry_status.json`; the variant-to-config map is in docs/STRENGTHENING.md. Mechanisms A-H and the five mandatory crosses (X1-X5) have their own blocks. Inapplicable cells and their reasons are listed under `strengthening.inapplicable` in `manifests/wave7_*.coverage.json`.

Smoke check: frozen v3 code (semantic hash `5342339672822033`), CPU, `--scale smoke`. All 1,098 wave-7 jobs ran: 38 baselines, 149 trajectories, 181 dissipations, 44 repairs, 628 continuation controls, 45 CoP jobs, 12 transplants and 1 deletion. All are `complete` and `valid` (`sandbox_checks/v3/wave7_smoke_status.json`). The smoke-scale tables and figures 1-7 are in `sandbox_checks/v3/wave7_smoke_summary/`. They show that the pipeline runs end to end; they are not results.

Resume: `audit_v3/tools/resume_comparisons_v3.py` interrupts and resumes 16 new job paths. These are grow/contract cycles (gate, abrupt with a moving cut, nested), freeze release with snapshots, alternating helpers, dissipation (fold, stochastic bypass, newest first), repair (fresh data with preserved optimizer state; readout), continuation controls (C2, distillation, prune and regrow, perturbation), and CoP (bridge with route erasure; repetition pegs). All 16 are bitwise equal to the uninterrupted runs on CPU (`sandbox_checks/v3/resume_comparisons_v3.json`). `scripts/11` repeats the comparison on the GPU.

## v4 audit corrections

Smoke check on v4 (semantic hash `932d3eadcd8c26ac`), CPU, `--scale smoke`: all 1,201 wave-7 jobs are `complete` and `valid` (710 s wall, 3 workers on 2 cores). The v4 grid adds the matched-factor cells (M_F at matched frequency, F06e every-2 and replay, F07c 2 x 2, X3 at constant width), the M1 / M2 endpoint-matched CoP controls and the F08e teacher-target access arm. Full scale is 3,603 jobs, pilot 1,201. In the smoke summary 1,019 of 1,033 design jobs are eligible; the other 14 are multi-model jobs (12 transplants, 2 CoP alternatives), reported per row. The paired tables have 809 fixed-architecture, 109 matched-endpoint and 165 cost-frontier rows for test risk.

Reload: a fresh process reproduced the saved test predictions of all 1,232 endpoint and transplant checkpoints bitwise (`sandbox_checks/v4/fresh_reload.json`). Resume: 21 job paths are bitwise equal after interruption (`sandbox_checks/v4/resume_comparisons_v4.json`). The CUDA tests and GPU jobs did not run here; `scripts/12_v4_gpu_gates.sh` (v5: `scripts/12_v5_gpu_gates.sh`) runs them.

Runtime (deliverable G): `audit_v4/tools/runtime_estimate.py` predicted 687 s for the smoke grid from its own measured jobs (measured 710 s). A pilot-scale sample, one job per stratum plus prerequisites (279 jobs), ran on this CPU with the pre-review v4 draft (same job sizes): 278 completed in 2,700 s, every stratum measured. The resulting CPU estimate for the full pilot is 15,700 serial seconds, about 2.2 h with 2 workers (`sandbox_checks/v4/runtime_pilot_cpu.json`). The GPU estimate comes from the same sample, which `scripts/11` runs first on the GPU; it prints the estimate and pauses (`PAUSE`, default 20 s) before the pilot.

Tests: 274 passed, 9 skipped on CPU (7 CUDA, CIFAR-10 and CIFAR-100 not downloadable here). See TEST_MATRIX.md.

## v5 review corrections

Smoke check on v5 (semantic hash `4a2a4a3e2d634443`), CPU, `--scale smoke`: all 1,359 wave-7 jobs are `complete` and `valid` (651 s wall, 2 workers). The new blocks are `W7_v5_witness`, `W7_v5_witness_targets_T0/T1`, `W7_v5_fold_frozen_backbone`, `W7_v5_finite_interfaces` (FIN_A, FIN_B), `W7_v5_locality` (LOC) and `W7_v5_transplant_grid` (M_C grid, with BN recalibration on the image cell and a work-matched C1 arm). Full scale is 4,077 jobs, pilot 1,359. The static dependence game adds no jobs.

In the smoke summary: 200 gain-retention rows (50 defined, 150 undefined because the expansion gain is at or below DELTA, which is expected at smoke budgets), 432 contraction-diagnostic rows (every record `state_unchanged`), 62 finite-interface rows (47 applicable; the others are the permanent-bridge diagnostics and continuous bottlenecks, each with its reason; no protocol violation), 45 locality rows, 383 exact dependence games of 396 landscapes, 186 transplant-grid rows and 21 witness records.

Reload: 1,546 endpoint and transplant checkpoints and both realisable witnesses reproduce in a fresh process (`sandbox_checks/v5/fresh_reload.json`). Resume: 8 new v5 paths and 21 v4 paths are bitwise equal after interruption (`sandbox_checks/v5/`). The CUDA tests and GPU jobs did not run here; `scripts/12_v5_gpu_gates.sh` runs them.

Tests: 312 passed, 11 skipped on CPU (9 CUDA, CIFAR-10 and CIFAR-100 not downloadable here). See TEST_MATRIX.md.
