# Coverage of the v14 review (CoP_v15_review_and_Claude_instructions) in code v16

Done = implemented and tested. Partial = part of the request is in the code; the rest is listed. Not done =
nothing in the code yet. "Wave 15" is the exploratory control-development panel (discovery draw 0); "wave 14" is
the confirmation draft (draws 101-105, optimizer seeds 1 and 2 on 101 and 102).

## Priority 0

| Request | Status | Where / what is missing |
|---|---|---|
| 1. Later-query pairing, identity fields, reject missing / duplicate, architecture check, treated_lr0.3 labelled | Done | `history_ingredients_table`, `later_query_retention`; tests over all orderings |
| 1. Validate every paired summary with a two-replication fixture | Done | compact_gain, tuned_gain, selected_gain (v16), finite_recipe_gain (v16), later-query (v15 + v16 pooled summary), locality matching |
| 2. Launcher: per-stage exit codes, verdict, non-zero exit, diagnostics still packaged | Done | scripts/16; `tests/test_v15_launcher.py` (success, run / checks / reload / summary / packaging failures) |
| 2. Summary success in the verdict | Done in v16 | `cop summarize --strict` exits 3 when a table-level analysis failed; before v16 a crash inside the v13 / v15 tables was only written to `v13_tables_ERROR.txt` and the stage passed |
| 2. Freeze analysis / protocol version, amendments recorded | Done | protocol hash; `PROTOCOL_AMENDMENT`, `REFREEZE_REASON` |
| 3. Removal export by event identity; start and cut at update 0 kept apart; missing flagged | Done | `removal_path_table`; the review's .3 / .9 fixture |
| 3. All partitions immediately after EACH cut / fold | Done in v16 | v15 gave a full evaluation to the first cut only |
| 3. Logit norm and drift at events (new runs) | Done | dissipation key events |
| 3. Rebuild v13 summaries from the full lab logs | Ready | scripts/17 step `rebuild_v13` (read-only `--historical`); needs the lab folder, not the slim zip |
| 3. Sampled vs continuous peak | Done | `peak_kind` |
| 4. Draw-level primary (5 draws, opt seed 0), crossed panel secondary, draw weighting | Done | `draw_level` in every paired summary; v16 adds pooled summaries for the recipe panel and M_E retention, which v15 only reported per replication |
| 4. Tuning cost: all candidates, baseline once, selected vs procedure cost | Done | `tuning_cost` |
| 4. Selector named; best-val tables separate; never select on test / rare / shift | Done | |

## Priority 1

| Request | Status | Where / what is missing |
|---|---|---|
| 5. Strict scratch arm kept | Done | `fixed` recipe |
| 5. Train-only adaptive global range OR learned clipping, bounded LR sweep | Done (adaptive range) | `quant_range=ema`; LR 1 / 0.3 / 0.1 in wave 15, 1 / 0.3 in wave 14. Learned clipping (PACT / LSQ) not implemented |
| 5. Continuous warm-up then quantisation, labelled capacity relaxation | Done | `quant_warmup_updates`; never in a best-of selection |
| 5. Same quantiser options for treatment and control | Done | treated fixed / ema and scratch fixed / ema / warm-up |
| 5. Bits as dimension x bits | Done | `message_bits_per_peg` |
| 5. Clipping, active messages, entropy, code drift, calibration at fixed and selected checkpoints | Done | quantiser audit at start, end, selected, export |
| 5. Gradient norms at fixed and selected checkpoints | Done in v16 | v15 had the start only; now start, end and selected |
| 5. Known learnable small tasks as positive controls | Partial | finite enumeration tasks (n = 3..5) give exact optima; no separate "finite channel provably sufficient" positive control in the recipe panel |
| 6. Readout naming, decoder class, training-message coverage, unseen rate | Done | `readout_<peg>_*` |
| 6. Probe-fit budget | Done in v16 | `readout_<peg>_fit_examples`, `_code_dim` |
| 6. Compare like decoder families | Done in v16 | `same_decoder_class` per pair; pooled readout retention uses like-class pairs only |
| 6. Exact finite-domain oracle labelled with its distribution | Done | finite_interface tables |
| 6. Warm-start abrupt interfaces | Done | M_E `abrupt_calibrated_interfaces` |
| 6. Gradual no-bridge in M_E | Partial | the M_E treated arm is the default gradual history; no separate bridge / no-bridge split in M_E (C4i has it) |
| 6. f0 readout at the corresponding cut | Not done | f0 has no peg at the cut; a probe on its full activation would not have the same readout budget |
| 7. Task risk, function agreement, code + canonical agreement, separately | Done | locality three outcomes |
| 7. First passage, final, sustained, lost | Done | |
| 7. Representation matching renamed; certificate coverage stated | Done | |
| 7. Reference risk beside scope; performance-matched comparison; right-censoring | Done | within one replication |

## Corrections to the pasted summary

All are recorded in REPILOT_v13_RESULTS.md (v15 corrections section). Two need code, both present: empirical
exposure (`spec_exposure`) and intact vs instantly removed at identical weights (frozen-weight sweep).

## What deserves confirmation (A-F) in wave 14

| | Status |
|---|---|
| A. F09 query timing | In (treated, treated_lr0.3, matched controls) |
| B. M_E later-query readout | In, with the warm-start abrupt arm; like-decoder pooling (v16) |
| C. X4 partition / removal dynamics | In at rho 0.95 |
| D. Continuous F07 | In (dims 2, 32; dim 8 is the C4i cell, not run twice) |
| E. Locality | In (five interfaces, widths 4 and 16, one repair budget, primary draws); v16 also puts this cell in wave 15 so its new outcomes are seen once before the freeze |
| F. Finite enumeration | In (block_finite, small) |

## Targeted families

| Family | Status |
|---|---|
| 1. Frozen-weight dependence: intact, single deletion, joint deletion | Done (frozen sweep at every removal start) |
| 1. Pair deletion, exact fold, affine replacement in the frozen sweep | Not done |
| 1. Three co-adaptation durations; serial vs reconvergent topology | Not done |
| 1. Affine residual vs induced downstream error | Not done |
| 2. all examples / fixed random / redrawn / observed label / true group, shares .5 and matched (~.95) | Done (wave 15, seven partitions) |
| 2. Branch-only deletion vs both-branch deletion | Done in v16 (the v15 sweep deleted only the removal targets, i.e. the whole group) |
| 2. Gradient-scale / update-frequency compensation with measured norms | Not done (empirical exposure is logged; per-branch gradient norms are not) |
| 3. Widths 4 / 16, learned vs stabilised pegs, no-peg, exact controls | Done |
| 3. Interface relabelling (P, Q permutations) | Not done |
| 3. Reachable code map enumeration, progressively richer replacement classes | Partial (frozen-code lookup and original pearl; no replacement-class ladder) |
| 4. Abrupt / fast / slow at equal work; frozen sweep and trained paths | Partial (abrupt, linear, MAC-matched; no adaptive schedule) |
| 4. A-then-B vs B-then-A vs joint; inverse-pair control | Not done as a panel (inverse-pair metadata and joint deletion exist) |
| 4. Expand / contract cycles vs matched no-edit | Not done |
| 5. F09, M_E, n = 3..5 decoder gap and code-quality gap | Done (block_finite, finite_refit) |

The not-done items are the next staged experiments; none is in wave 14, so the confirmation does not claim them.
