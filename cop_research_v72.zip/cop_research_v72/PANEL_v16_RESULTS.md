# Wave 15 control panel (run with code v16, lab, 30 October 2026): results and what changed

Exploratory: discovery draw 0 only, one partition realisation, one optimizer seed. Nothing here is confirmation
evidence. 94 / 94 jobs complete and valid; checks passed; every endpoint reloaded bitwise in a fresh process.

## Gradient partitions (X4 shortcut task, rho 0.95, same specialised graph, one linear removal, C1 = 23.5% test error)

| Partition | Final compact test error | Expanded model before removal | Frozen removal of all additions |
|---|---|---|---|
| every example to both branches | 23.9% | 23.8% | 24.0% |
| random 95/5, redrawn every batch | 23.4% | 23.2% | 33.9% |
| random 95/5, fixed | **19.5%** | 24.6% | 49.5% |
| random 50/50, redrawn | 23.6% | 23.6% | 24.8% |
| random 50/50, fixed | 22.9% | 30.3% | 51.7% |
| observed label | 20.6% | 48.5% | 49.5% |
| true group | **14.6%** | 50.5% (chance) | 49.5% |

* Measured exposure is the same for the fixed and redrawn 95/5 splits (0.949 / 0.051), so the difference is the
  persistence of the assignment, not the share of updates.
* Fixed splits create dependence that redrawn splits do not: with weights frozen, removing the additions takes
  the fixed 95/5 model from 24.6% to 49.5% error; repair then reaches 19.5%, below the original compact model.
  This is acquired dependence followed by a better compact solution; it is not irreversibility.
* Under true-group, observed-label and fixed 50/50 splits the expanded model is already at or near chance before
  removal. Cross-entropy after deleting an addition rises into the tens to thousands, but error stays near 50%:
  those are confidence changes of a classifier that was already poor, not an accuracy collapse.
* One draw and one partition realisation. Wave 14 (v17) repeats it on five fresh draws with three partition seeds.

## Finite-peg recipes (teacher, depth 6, normalised MSE; about 1.0 = predicting the mean)

| Cell | Treated, tuned | Scratch, fixed range | Scratch, adaptive range | Scratch, warm-up |
|---|---|---|---|---|
| 4 bits | 0.667 | 1.001 at every LR | 0.686 | 0.693 |
| 16 bits | 0.684 | 1.001 (base LR), 0.741 (0.3x) | 0.83 to 0.99 | 0.80 |
| 1 bit | 0.82 | 1.001 | 0.93 | 1.001 |

* At 4 bits the earlier history gain was almost entirely the fixed-range scratch collapse; with the adaptive range
  the gap is 0.02 (selected checkpoints 0.6726 vs 0.6669).
* These comparisons match updates, not computation: the treated procedure costs about 1.5 to 1.6 times a scratch
  candidate. v17 adds compute-matched scratch arms.
* 1-bit scratch arms, even with the adaptive range, end with every training input outside the clipping range and
  six modules with exactly zero gradient, and 65% clipping right after calibration. Candidate cause (not yet
  confirmed on the GPU): a peg input that sits exactly at the range's edge (discrete inputs, e.g. behind another
  finite peg) lands one rounding step outside it when recomputed in a different batch, and `clamp` gives it zero
  straight-through gradient. v17 adds a read-only probe and a margin recipe (forward unchanged).
* Later-query readouts on the 2-bit M_E cell, base LR: with fixed ranges treated led at the second peg (63.6% vs
  61.0%); with adaptive ranges scratch leads (64.6% vs 60.9%) and the first peg is level (68.3% vs 68.9%). The
  general statement that CoP history keeps more future information does not hold; the recipe interacts with it.
  These are probe accuracies of the fixed endpoint, not certified information.

## Locality (five interfaces, widths 4 and 16, repair budget 2 x upr)

* No-peg and continuous pegs recover in scope 1 at every tolerance; finite pegs fail or need scope 4 at the tight
  tolerances.
* Some repairs succeed and then fail: width 16, finite-learned, last checkpoint, tolerance 1e-4: first passage at
  1,000 updates, failed at the 4,000-update end. A feasible repair existed, so the end failure is about stability
  and checkpoint choice, not irreducibility.
* Task recovery is not recovery of the same computation: the repaired pearl reproduces 1% to 18% of the old
  integer codes; representation matching 3% to 32%.
* The no-peg reference is worse (0.463 vs 0.37). The nearest-reference table did not match references within any
  stated tolerance (gaps 0.036 to 0.163); v17 adds an explicit 5% rule and marks unmatched pairs.

## v13 rebuild

All 60 start rows and 20 immediate-cut rows of the removal export now carry full test and rare-group risk (before:
all blank). The re-pilot folder was not modified.

# Wave 16 follow-up (code v17, lab, 30 October 2026)

106 / 106 jobs complete and valid; checks and fresh reload passed. Exploratory, discovery draw 0.

**The rounding explanation for 1-bit clipping is wrong.** The probe found at most 1.4% of peg inputs outside the
range by rounding (v16 panel and wave 16 alike). The clipping is real. At 1 bit the second peg's input takes only
2 to 6 distinct values (it is a function of the first peg's single bit), and in most arms, treated included, every
input sits outside that peg's range, so six modules get exactly zero gradient. The margin recipe changes this only
in some compute-matched scratch arms. The margin variants are therefore not carried into the confirmation.

**With fair controls the finite-peg history advantage is small or absent** (risk at each arm's validation-selected
checkpoint; LR chosen on validation on each side; scratch with the adaptive range):

| Cell | Treated | Scratch, update-matched | Scratch, compute-matched | Gap (compute-matched) |
|---|---|---|---|---|
| 1 bit | 0.827 | 0.915 | 0.825 | -0.003 |
| 4 bits | 0.667 | 0.673 | 0.668 | +0.001 |
| 16 bits | 0.680 | 0.706 | 0.709 | +0.029 |

* Fixed-endpoint and selected-checkpoint gaps differ a lot at 16 bits (fixed endpoint +0.17 to +0.25 for the
  adaptive range): scratch reaches about 0.71 and then degrades with more training. Most of the fixed-endpoint gap
  is late-training degradation of scratch, not an unreachable solution.
* The fixed range still collapses scratch at 1 and 4 bits under the update budget; compute matching alone rescues
  it at 4 bits (0.703).
* M_E later-query readouts move by about 3 points between the fixed endpoint and the selected checkpoint of the
  same run (treated adaptive range, second peg: 60.9% fixed, 64.2% selected; scratch 64.6% fixed, 61.7% selected),
  which is the size of the treated-vs-scratch differences. With one draw these readout differences cannot be read
  as an effect; the confirmation reports both checkpoints over five draws.
