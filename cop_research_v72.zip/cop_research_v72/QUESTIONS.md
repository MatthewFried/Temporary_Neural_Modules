# Questions and issues for the independent review

These are places where the specification left a scientific definition open, or where the implementation made a choice that changes what a measurement means. Each should be confirmed or corrected before results are interpreted.

1. **Risk used for Delta_A.** `R` is cross-entropy for classification and MSE for regression, measured on validation (selection) and test (reporting). Accuracy deltas are logged alongside. Should the primary deletion endpoint for classification be cross-entropy or error rate?
2. **Preservation tolerances.** Defaults: accuracy drop {0.1, 0.5, 1.0} percentage points, normalised MSE {1e-4, 1e-3, 1e-2}, Jensen-Shannon {1e-3, 1e-2}. Each deletion row stores the per-example paired difference (correctness, loss or squared error) against the undeleted model with its standard error (`paired_delta`; sequences are the clustered unit); tolerances below that resolution are visible in those rows. Is a formal equivalence margin wanted for the primary contrasts?
3. **Continued baseline exposure.** fc continues with the baseline's optimizer state and minibatch stream for rounds x updates_per_round updates. Growth topologies after insertion use 'preserve' optimizer state by default. Is 'preserve' the right default for the primary contrast, with 'reset' as the factor (current design), or the reverse?
4. **"Same final graph"** is checked by the id-independent structural hash, which includes sharing classes, dimensions, coefficients and gate values but not parameter values. Construction-order comparisons (tree_depth2 breadth-first vs depth-first) and all-at-once/from-scratch controls should report equal structural hashes; the summary table contains `graph_hash` per run so this can be audited.
5. **Recursive insertion parent rule.** A node cut on an implant's entry is placed BEFORE that implant (the implant's entry is re-pointed), not inside it; an edge cut into an implant's internal node is inside. Please check this matches the intended meaning of "inside a prior implant".
6. **Dependence summary.** The tables report max and min single-deletion delta per run. Exhaustive landscapes and interactions are in `deletions_final.json`. Is a different scalar (for example the minimum over atoms, or the delta of deleting all implants) the intended headline?
7. **Repair budgets** are multiples of the parent's total growth updates (rounds x updates_per_round). 'fresh_original' and 'fresh_smaller' therefore train from scratch with a budget designed for repairs, which makes them weak by construction at small multiples; the 4x rung partly addresses this. Should fresh models also get a from-scratch budget rung?
8. **Wave-4 parent selection** uses validation single-deletion effects, tertiles within (block, topology) and hash order. The rule is fixed before Wave 4 runs. Please confirm the number per cell (default 2).
9. **CoP 'known' placement** gives the model access to teacher intermediates through training-only readouts. Results with 'known' must be compared against 'regular' with the same budget and are not a test of unsupervised interface discovery.
10. **P3 'independent' mode** has no assembly-level training, so its "seen" and "held-out" assemblies differ only by the random split (both are unseen as assemblies). The held-out contrast is meaningful for joint and shared_interface modes.
11. **Communication accounting for continuous pegs** charges 32 bits per coordinate. If a different fixed precision should be the reference for continuous codes, set `peg.float_bits`.
12. **I5 transition systems** are small (hundreds to a few thousand states by default). The v2 checker re-explores the whole space from the specification (no sampling) up to 300,000 states and re-solves exact hitting systems up to 200 unknowns; above that the verdict is `partially_checked` or `unchecked`, never `verified`. Are these limits acceptable for the planned I5 sizes?
13. **Training budgets** in `configs/budgets.yaml` are starting values. They must be set from validation curves after `scripts/02_gpu_calibration.sh`; changing them changes run ids, so decide before the long queues.
14. **Shared-module propagation** of insertions to every invocation is not automatic (DEVIATIONS 12). Is this needed for the first round of results?
15. **Route-merge growth (v2).** Growing a routed group next to trained experts is made exact by splitting the most recent expert with router weights s / (1 - s), `growth.route_split = 0.3`. The new expert therefore starts as a copy of an existing one, not at zero output. Is this the intended "routing" expansion, or should routing growth be analysed as an approximate (zero-expert) construction instead?
16. **Repair extension criterion (v2).** An inconclusive repair is extended when the configured target's criterion (task risk, distance to ft, or distance to f0) is unmet at its loosest tolerance (`repair.extend_on = target`). `task` and `both` are available. Which should be primary?
17. **Matched-control exposure (v2).** direct_small trains for the parent history's measured training updates plus the baseline's updates; distill for the parent's measured updates only. Should equal wall-time or equal FLOPs be an additional control? Measured work by phase is recorded for every method, so either can be computed later.
18. **Enforced interfaces in P3 / P4 (v2).** Replacement modules are trained through the destination quantiser with a straight-through estimator. Alternatives (soft relaxations, Gumbel-softmax for codebooks) are not implemented. Is straight-through acceptable for the P3 finite-interface conditions?

## Strengthening extension (v3)

17. **Primary control for G.** Every contrast reports G against C0 (f0), C1 (equal updates) and C2 (equal training MACs), and the full set against C3 to C8. Which one is the primary endpoint for the screening table? C2 is the strictest compute match, but it gives the compact control more updates than the treated history.
18. **C3 exposure.** `growth.schedule = from_scratch` trains the expanded graph with the trajectory's from-scratch exposure, which includes the f0 budget, before the same contraction. Its post-f0 compute is therefore larger than the treated chain's. Should C3 instead be capped at the treated chain's MACs?
19. **C5 form.** Self-distillation continues f0 with f0 as the teacher (alpha 0.5). Is a born-again student trained from re-initialisation at the same budget wanted as well?
20. **Contraction defaults.** Histories without a contraction variant of their own use a linear gate anneal (speed = post = updates_per_round / 2). Should the default instead be the contraction that is cheapest for each topology (fold when affine, abrupt plus repair otherwise)?
21. **Screening budget.** Wave 7 has 3,603 jobs at full scale with three seeds (1,201 at pilot scale with one seed; v3 had 3,294 / 1,098 before the v4 matched-factor cells and M1 / M2 controls). Should Phase 1 be cut further, for example to core controls only outside the primary cell of each family, before the full run?

## Audit corrections (v4)

22. **Primary contrasts.** With hundreds of screened contrasts and three seeds, wave-7 intervals are exploratory. Which contrasts (family, cell, control arm, estimand) are primary for the confirmation wave? The proposal is to pick them on validation from the pilot and confirm on new seeds and held-out tests.
23. **Which compute estimate drives C2?** v4 keeps the dense 3 x forward estimate for budgets and records the backward-aware estimate beside it. Should C2 switch to the backward-aware estimate (it gives frozen-history treatments a smaller budget), or should both panels be built?
24. **Matched-endpoint controls for CoP chains.** M1 / M2 train the treated export's architecture from re-initialisation with f0's budget added. Should they also inherit the treated chain's quantiser calibration, or is a fresh calibration (current) the intended control?
25. **Gradient checks.** The numerical boundary checks updated parameters, not gradients (DEVIATIONS 83). Is a separate gradient check wanted for optimizers that could skip non-finite gradients?


## Review corrections (v5)

26. **DELTA.** Gain retention and gap closure are undefined when their denominator is at or below 1e-3 in headline-risk units. Should DELTA instead be relative (for example a fraction of R_C1, or of the target variance for regression), or set per cell from the paired seed spread?
27. **Locality success.** Success is task-risk recovery against the checkpoint's own exported model. Should recovery of the checkpoint's function (drift, recorded) be a second, separately reported success criterion?
28. **Locality topology.** Only a serial chain with the middle pearl replaced is tested. Is a branched topology screen needed before the pilot, or after the serial result?
29. **Predictor screen split.** The first replication is the discovery set and the other two are held out (sign check only). Would a different split, or a pre-registered predictor list from the v5 smoke, be preferred?
30. **Finite-cell grid.** n = 3, 4, 5 and K = 1 to 3, with bridges at one K per n. Should larger n be added with the codebook solver (n = 6 is exact for K <= 2 under the current cap), or stay at these sizes for the pilot?

## Audit corrections (v8)

31. **Stability bound.** An insertion counts as exact only when the post-edit model's execution round-off (float32 against float64, relative to the mean output) is at most 1e-4. On the digits MLP it is about 1e-5. Is 1e-4 the right bound, or should it be set per architecture from the Wave-0 controls?
32. **Diagnostic attention kernel.** The JVP uses the math attention kernel while training uses the fused one. The two agree to floating-point precision, but the JVP is then the derivative of the math-kernel function. Is that acceptable for a first-order sensitivity diagnostic?
33. **Reusing v7 results.** Run ids are unchanged, so a v7 run can be reused under v8 with `cop accept-stale` and a reason. Should every `reusable_unchanged` run be accepted, or should the next pilot start fresh under v8 (cleaner provenance, roughly the same compute)?
