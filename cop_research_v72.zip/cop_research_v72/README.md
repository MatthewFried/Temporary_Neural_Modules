# Cut, Expand, Remove, and Replace / Chain of Pearls: research framework

Implementation of specification 1.0 (20 October 2026), version 72 (semantics `cop-7.21.0`; code v72).

* v2 corrected the v1 code after the independent audit. **AUDIT_RESPONSE.md** lists every finding, its fix, where it is and which test covers it.
* v3 adds the strengthening extension: the 50 registry variants F01a-F10e, controls C0-C8, target regimes T0/T1, budget panels, mechanisms A-H, the section-7 calibrations as tests, and wave 7. See **docs/STRENGTHENING.md**.
* v4 corrects v3 after the second independent audit (V3-01 ... V3-12): endpoint records from reloaded checkpoints, divergence checks after every update, explicit estimands and contract keys, sharing-aware architecture identity, device policy, persistent C8 pruning, peg switches, saved transplant models, compute completeness and matched-factor cells. **AUDIT_RESPONSE_v3.md** lists each fix, its test and what remains limited; **TEST_MATRIX.md** says which tests ran on which device. v3 outputs are not reused: the code version and semantic hash changed, and the provenance check refuses stale parents.
* v72 (**CHANGES_v72.md**): release-integrity and reporting safeguards for the close-out: the manifest declares files still being written and is verified against the delivered archive; the findings refuse a release-ready document on inconsistent or missing evidence; every export operand needs a validation record of its kind; corrected descriptions; `scripts/72_v72_closeout.sh`.
* v71 (**CHANGES_v71.md**): the close-out (report-only): registered pairs, float64 sensitivity, FINAL_FINDINGS.md, paper figures, the release manifest; the rounding check renamed a first-order estimate (its launcher is superseded by v72's).
* v70 (**CHANGES_v70.md**): the deployed check against a float32 rounding bound per example and logit, the reference on every f0, registry values recomputed from the states table, a retrained sample compared value by value, v69's analyses reused when the code is the same; `scripts/70_v70_reanalysis.sh`.
* v69 (**CHANGES_v69.md**): a strict independent reference (separate certificates, per-example bounds) bound to the registries, a preflight on real checkpoints, a mechanism design that cannot shrink; `scripts/69_v69_reanalysis.sh` replaces v68's launcher (trains nothing).
* v68 (**CHANGES_v68.md**): corrected analyses and an independent reference implementation; `scripts/68_v68_reanalysis.sh` re-analyses the saved v64, v65 and v67 runs (trains nothing).
* v67 (**CHANGES_v67.md**): the registry treats a failed run audit per row; run the v66 re-audit from this folder.
* v66 (**CHANGES_v66.md**) re-audits the saved v64 and v65 runs under corrected acceptance logic (the saved redistributed start as a required storage certificate, non-finite values never passing, edit-event checkpoints through check_ckpt, registries bound to their coverage, manifest, audits and prerequisites, normalisation eligibility) and adds the reset-matched compact controls (wave 32, the only training). Run `scripts/66_v66_reaudit.sh` after v65; results go to `~/cop_results_v66`; v64 and v65 are only read.
* v65 (**CHANGES_v65.md**) adds the two follow-ups: the v60 design on images (wave 30: a CIFAR-10 task with a shortcut channel, a CNN with a 1x1 receiving layer, and a late temporary head as the projection-head comparison) and the mechanism forks (wave 31: function-preserving redistributions of the additions' computation from wave 29's routed trajectories). Run `scripts/65_v65_panels.sh` after v64; results go to `~/cop_results_v65`.
* v64 (**CHANGES_v64.md**) runs v62's training and v63's corrected analyses in one launcher. Run `scripts/64_v64_panel.sh`; results go to `~/cop_results_v64`.
* v63 (**CHANGES_v63.md**) is analysis only, after v62: fitted-versus-transported probes at matched precision, whitening comparability on those summaries with planned and included pairs, the compact controls (2U and 4U) in the fork analysis with compute, audit completeness kept apart from success, and the replication registry (`configs/v62_replication_registry.json`). Run `scripts/63_v63_reanalysis.sh` after v62 finishes; results go to `~/cop_results_v63`.
* v62 (**CHANGES_v62.md**) runs v60's design in a second setting (wave 29: width 128, six hidden layers, 12 causal and 12 noise inputs, draws 349-360) with v61's analyses, which now find the merge at any depth. Run `scripts/62_v62_replication.sh`; results go to `~/cop_results_v62`.
* v61 (**CHANGES_v61.md**) is analysis only: it reanalyses the v60 panel with the fold check and the transport certificate decided in float64 (the float32 results kept and reported), a precision diagnostic, a central paired table and a status record that keeps training, fork validity, transport validity and analysis completion apart. Run `scripts/61_v61_reanalysis.sh`; it reads `~/cop_results_v60` and `~/cop_results_v53` and writes `~/cop_results_v61`.
* v60 (**CHANGES_v60.md**) gates training on the reuse verification (a sample covering every class of reused run, compared checkpoint by checkpoint: graph, tensors and dtypes, optimizer state by name, trainer and generator state), saves the fold's starting checkpoint and audits it against W3 A, b3 + W3 c, tightens the fork audits (exact trainable sets, optimizer membership, the carried state against the parent's; whether the additions moved is an outcome, not a check), adds an acceptance test of the fold on the training device, and makes the geometry's reporting more precise. Run `scripts/60_v60_fork_panel.sh`; results go to `~/cop_results_v60`.
* v59 (**CHANGES_v59.md**) replaces v58's launcher: wave 28 gains the folded continuation (dissipation method `fold_unrouted`, the additions folded exactly into layer 3 and the compact network trained directly), earlier runs are reused under an explicit audit (`configs/reuse_audits.json`) with a bit-for-bit reproduction check of a sample, every fork is audited, and `merge_geometry.py` takes affine maps from the graph, qualifies whitening and certifies probe transport. Its launcher is replaced by `scripts/60`; a v59 panel is reused by v60 (folded forks excepted).
* v58 (**CHANGES_v58.md**; v56 results in **RESULTS_v56.md**) adds wave 28: four keep forks (routed, ordinary, frozen additions, carried optimizer) of wave 26's routed affine trajectories from snap_1000 and snap_2500, analysed by `fork_continuation.py`; and `merge_geometry.py` on the v53 wave-26 panel (the merge map's spectrum, probes carried through it, whitened probes). Its launcher is replaced by `scripts/59`; a v58 panel already trained is reused by v59.
* v57 (**CHANGES_v57.md**) adds a training panel, wave 27: wave 26's draws and f0 with relu additions under three routes (the gradient route of waves 25 and 26, the parameter-only route, no routing), with and without the shortcut hold. 96 of its 360 jobs are new; the rest are wave 26's own jobs and are copied from the finished v53 panel (`scripts/seed_panel.py`). Run `scripts/57_v57_route_panel.sh`; results go to `~/cop_results_v57`.
* v56 (**CHANGES_v56.md**, results so far in **RESULTS_v55.md**) is analysis only and replaces `scripts/55`: the component analysis with f0-bias norm controls and more probed controls; `layer_course.py` (the same probes at every backbone layer and every saved age, in the extracted, native and folded contexts); `routing_updates.py` (the last optimizer step against the ordinary and the routed gradient, by parameter group). Run `scripts/56_v56_backbone_change.sh`; results go to `~/cop_results_v56`.
* v55 (**CHANGES_v55.md**) (superseded by v56) corrects and completes v54's analysis; `scripts/54` is retired. The launcher is CPU only from its first step. `component_change.py` now keeps two representation contexts apart (f0 with the state's first layer; the state's actual network), treats the norm and bias edits as controls with their access and construction recorded, probes those controls, compares an expansion with its matched compact control at the same update and trained longer under separate names, reports decision disagreement and a declared equivalence margin, validates compact checkpoint ages and matched controls, groups by an experiment identity, and saves every fitted probe. Run `scripts/55_v55_component_change.sh` with `WAVES=25`, `WAVES=26` or both; results go to `~/cop_results_v55`.
* v54 (**CHANGES_v54.md**) (superseded by v55) is analysis only: `audit_v5/tools/component_change.py` asks whether the useful change in the original first layer is a new feature or a change of strength (every state's first layer in f0; f0 with its shortcut column shrunk, the equal-access baseline of the held-shortcut arms; f0 at the state's norms and the state at f0's norms; the same linear probes on every state, raw and standardised), on the v46 wave-25 panel and the v53 wave-26 panel, read-only. Wave 26 gets two primary contrasts (DEVIATIONS 289). Run `scripts/54_v54_component_change.sh` with `WAVES=25`, `WAVES=26` or both; results go to `~/cop_results_v54`. `scripts/48`, `51`, `52` and `53` stay valid.
* v53 (**CHANGES_v53.md**) adds the wave-26 training panel (600 jobs, draws 337-348; no training code changed): from one f0, expansions that cross the hold (nothing, or the first layer's shortcut column), the gradient route (routed, or every example to every addition) and the additions' activation (relu, or identity), the routed relu arm at 0.3 times the learning rate, and compact controls trained for twice the expansion's updates. New tools: gain-only training of f0 on the expansions' minibatches (`audit_v5/tools/gain_training.py`) and the panel's paired tables (`audit_v5/tools/panel26_tables.py`); `selective_reversal.py` gains the wave-26 registry. RESULTS_v52.md is the write-up of the v52 run. Run `scripts/53_v53_drift_panel.sh`; results go to `~/cop_results_v53`. `scripts/48`, `51` and `52` stay valid.
* v52 (**CHANGES_v52.md**) adds three analysis-only parts on the same v46 checkpoints: a gain scan of f0 (training loss and errors along a gain on the causal or shortcut input block, with the gain derivative checked by finite differences), the expansion's time course at every saved trajectory state (training loss, deletion, extraction, the additions' size and affine share, the affine fold and its rank-1/2/4 truncations, first-layer norms), and the folded network's path to the extraction after function-preserving alignment of hidden units. RESULTS_v51.md is the write-up of the v51 run. Run `scripts/52_v52_channel_course.sh`; results go to `~/cop_results_v52`. `scripts/51` stays valid.
* v51 (**CHANGES_v51.md**) revises the v50 analysis after its review: the CUDA test compares saved decisions (and must actually run), the fold is audited on every partition with fit diagnostics and a saved fit, the removal path gains its first segment (the additions' residual scaled away with the backbone fixed), the rank table separates changed entries from factor storage, and v50's over-strong interpretations are replaced. It adds training diagnostics of f0 by subgroup. Analysis only, on the same v46 checkpoints. Run `scripts/51_v51_coordinated_edits.sh`; results go to `~/cop_results_v51`.
* v50 (**CHANGES_v50.md**) revises the v49 analysis after its review (named removal criteria with a fixed primary, success counts with conditional and all-run summaries, grouping by experiment, checkpoint-age checks, explicit device, explicit rank schemes, labelled shared-ancestor transfer with contrasts against the host and f0) and adds the fold: the additions' output replaced by its training mean or affine fit and absorbed into the layer that reads it. Analysis only, on the same v46 checkpoints. Superseded by v51.
* v49 (**CHANGES_v49.md**) is analysis only, on the existing v46 wave-25 checkpoints: minimal coordinated edits (every subset of the leaf additions deleted x every subset of layers 2..5 restored, with validation-only removal sets), rank-k restores of each later layer's change, and transfer of additions and later-layer changes between conditions that share f0. Superseded by v50.
* v48 (**CHANGES_v48.md**) corrects the v47 path reporting (endpoint-relative barriers and raw worst points instead of a schedule-weighted mean), checks every test cross-entropy per example, adds margin and logit-size quantiles, and saves the test logits; analysis only, on the same v46 checkpoints. RESULTS_v47.md is the corrected v47 write-up. Run `scripts/48_v48_reversal_barriers.sh`; results go to `~/cop_results_v48`.
* v47 (**CHANGES_v47.md**) is analysis only, on the existing v46 wave-25 checkpoints (nothing trains): the 2x2 of additions present / deleted x layers 2..K trained / restored to f0 at every saved expansion age, the 5x5 grid of addition gates x interpolation of layers 2..K toward f0 at 2U with bitwise corner checks, three predeclared reversal paths, and saved test predictions. Its reports are in `~/cop_results_v47` (read only from v48 on).
* v46 (**CHANGES_v46.md**) fixes the v45 review's findings without changing training. These are: wave 25's own evidence list (v45's would have failed a successful panel), direct residual-versus-magnitude contrasts, the paired-stream audit's manifest membership, training and extraction access labels, norms from the evaluated weights, costs in the extraction summaries with complete output membership, and the confirmation cohort. A complete v45 panel is analysed read-only (same semantics, same run ids); otherwise the panel is trained here. Its panel and reports are in `~/cop_results_v46` (read only from v47 on).
* v45 (**CHANGES_v45.md**) is the freezing factorial (wave 25, draws 325-336): expansions holding nothing, the first layer's shortcut column, backbone layers 2 to 5, or both, each with its own matched compact control; the primary questions are the fresh-draw confirmation of the v43 shortcut-frozen extraction against its identically extracted compact control, and the interaction (B expansion - compact B) - (D expansion - compact D). It adds the minibatch-stream audit, training cost by part under parameter holds, extraction checks and saved extractions, the paired-stream audit, the residual-versus-magnitude controls, and re-reads the v44 and v43 panels for those controls. The corrected v44 write-up is RESULTS_v44.md. Its launcher is superseded by scripts/46; a complete panel in `~/cop_results_v45` is reused read-only.
* v44 (**CHANGES_v44.md**) follows the v43 results: train.freeze_backbone=downstream (backbone layers 2 to 5 held at f0 while the additions and the first layer train) and wave 24 (draws 319-324: the downstream-frozen expansion with its removal and keep fork, the hold lifted, beside the ordinary expansion and compact controls with the same hold, freeze schedule and resets), and, analysis only, every keep / restore code (2^K) on the named states and at 2U, the codes with the additions present, the split of the learned causal block into per-row scaling of f0 plus a residual, a downstream lineage check, and the wave-24 registry with the extraction rule against removal and repair, the compact controls and the rescaling controls; it re-reads the v43 panel. Its results are in `~/cop_results_v44` (read only from v45 on).
* v43 (**CHANGES_v43.md**) implements the v42 review: one C1 matcher per reference variant (the v42 code contrasts could take the frozen C1 as the reference), strict manifest-derived pair coverage, a declared wave-23 contrast registry, compact controls matched to every freeze and reset schedule (continue.freeze_segments, C1_reset) with a fork audit at 2U, logged update norms (path length) beside net movement, rescaling metrics summarised with nonnegative and held-out fits, and integrity-checked preflights. Its results are in `~/cop_results_v43` (read only from v44 on).
* v42 (**CHANGES_v42.md**) adds train.freeze_inputs (the first layer's shortcut column held at f0) and wave 23 (draws 313-318: the fixed expansion with and without that freeze, the freeze lifted or kept through the removal, the keep fork, C1 with and without it, C1_phase), denser repair checkpoints, and, analysis only, parameter displacement, fitted rescalings with agreement metrics, a causal grid to 16, and variant-pair contrasts; it re-reads the v41 and v36 panels. (superseded by v43 before it ran.)
* v41 implements the v40 static review (**CHANGES_v41.md**, with separate lists for training jobs and analysis): the component trace over the trajectory and repair checkpoints, the paired 2x2 continuation factorial with a fork audit, optimizer and gradient-routing audits, one arithmetic path with exact identities for the decomposition, cross and rescaling rows, strict per-job inventories, a preflight of the v36 panel before training, and the wave-22 label. Its results are in `~/cop_results_v41` (read only from v42 on).
* v40 fixes two details found reading v39 (carried optimizer `step` placement on CUDA; the parent's mask route for retained masks; **CHANGES_v40.md**). (superseded by v41 before it ran.)
* v39 follows the v36 first-layer decomposition (**CHANGES_v39.md**): the keep fork with retained masks and with the trajectory's optimizer state (wave 22, draws 307-312), and the cross of the causal and shortcut changes and the rescaling controls in selective_reversal, also re-run on the v36 panel. (superseded by v41.)
* v38 fixes the report packager, which silently skipped files of 8 MB or more, required ones included (**CHANGES_v38.md**). The panel is still `scripts/36_v36_panel.sh`.
* v37 fixes a flaky CUDA test (TF32 and an unseeded input in the CPU/GPU equivalence check; **CHANGES_v37.md**). The panel is still `scripts/36_v36_panel.sh`.
* v36 runs the disturbance control matched on validation error and on validation risk on every draw, and treats an unreachable error match as a declared outcome listed by the launcher and the analyses (**CHANGES_v36.md**). Run `scripts/36_v36_panel.sh`; results go to `~/cop_results_v36`.
* v35 fixes the v34 CPU test failures (a resume-dependent ledger note, the age tool's per-pair draw role, a stale test, skipped steps after a skipped panel; **CHANGES_v35.md**).
* v34 fixes the static review of v33 (**CHANGES_v34.md**, with separate training-changing and analysis-only lists): the age analysis's manifest-driven inventory, recipient baselines, alignment status with saved and re-verified maps, checkpoint integrity, declared pairing and per-cohort reporting; a phase-matched disturbance control with a declared estimand and tolerance; explicit segment_reset; the f0 + fresh rebuild corner; strict provenance and a config-derived trace in the transplant analysis; promised recipients in the cross transplant; an evidence step in the launcher. Its panel ran from v35 into `~/cop_results_v34` (superseded by v36).
* v33 adds portability against the additions' age (**CHANGES_v33.md**): age checkpoints on the replication trajectories and an analysis of what the host keeps, what the additions carry into an independent host, and what the first layer carries, at every age. Run `scripts/33_v33_panel.sh`; results go to `~/cop_results_v33`. (superseded by v34 before it ran.)
* v32 adds the reusability tests (**CHANGES_v32.md**): coupling-time holds (trained or frozen additions), rebuilt starts and a matched-damage control in wave 21, and a cross-recipient first-layer transplant with fixed interfaces. (superseded by v33 before it ran.)
* v31 fixes the static review of v30 (**CHANGES_v31.md**): phase-matched removal forks, schedule and event audits, a manifest-driven strict transplant analysis with same-function audits, unique-draw aggregation and stronger tests. (superseded by v32 before it ran.)
* v30 extends wave 21 (**CHANGES_v30.md**): balanced seeds, forks from the same expanded state (abrupt, keep, keep_frozen), first-layer repair with the other layers kept or reset to f0, early / late cuts, rotated / nonlinear / no-shortcut task variants, and the transplant tool's update decomposition and intervention checks. (superseded by v31 before it ran.)
* v29 adds wave 21 (**CHANGES_v29.md**): replication of the first-layer transplant lead on new draws, first-layer-only repair and compact control, an expanded continuation, and a rewritten transplant tool. (superseded by v30 before it ran.)
* v27 adds `audit_v5/tools/selective_reversal.py` (analysis only, **CHANGES_v27.md**): backbone layers restored to f0 after deleting the additions, no retraining. The panel is still `scripts/26_v26_panel.sh`.
* v26 adds wave 20 (**CHANGES_v26.md**): every v25 block plus a parameter-only mask route (every example's gradient reaches the backbone through the branches) crossed with persistence, contraction variants (imitation of the expanded model, stochastic bypass, LR warmup at each removal phase) and repair from limited data. Run `scripts/26_v26_panel.sh`; results go to `~/cop_results_v26`.
* v25 adds wave 19 (**CHANGES_v25.md**): forward-masked routing, repair scope after immediate deletion, a phase-matched compact control, fresh optimizer seeds, label noise, branch width and a second task (covertype), a per-stratum sink profile in every removal; and two fixes: integer exactness for recoding fits and fresh reload on each run's recorded device. (superseded by v26 before it ran.)
* v24 fixes the pristine certificate (it refused the group's pass-through node; **CHANGES_v24.md**). Run `scripts/24_v24_panel.sh`; results go to `~/cop_results_v24`. (superseded by v25.)
* v23 fixes the static review of v22 (**CHANGES_v23.md**): exposure matched on the actual sampled stream per growth round and physical branch (matched_quota), ETD selection inside its repair phase and its cost accounting, native / selected endpoint reload, a structural pristine certificate, complete recode symmetry accounting and a stricter recode audit. (superseded by v24.)
* v22 adds wave 18 (**CHANGES_v22.md**): exposure-matched persistence (cyclic gradient assignments with equal per-example exposure and different stay lengths) and rebuilt start states (untouched f0 backbone with fresh or trained branches, trained backbone with fresh branches) with dense early repair evaluation, on the discovery draws and three fresh draws, with a compute-matched compact control, two more partition draws of the fixed / redrawn contrast and an example-tied dropout comparator (Maini et al. 2023); plus realised per-example exposure, decision-level imitation measures, the disjoint-player dependence game, a parameter-level recode symmetry check and alignment cost counts. (superseded by v23.)
* v21 runs the recode fits in float64 (the v20 panel's recode symmetry control failed on float32 rounding drift; **CHANGES_v21.md**). Run `scripts/21_v21_mechanism_panel.sh`; results go to `~/cop_results_v21`.
* v20 fixes the v19 review (**CHANGES_v20.md**, with separate lists of training-changing and analysis-only fixes): recode validity checks that stop an invalid job, numerical guards, saved and resumable fits with a fresh-reload check, stage and donor cost accounting, explicit removal mask / gate / optimizer policies with a crossing and matched compact controls, the 16-subset frozen swap scan with affine alignment and repair curves, reassignment dose exports, matched recode recipes, scale-aware recode grids and timing, and a launcher that fails when packaging fails. scripts/19 is retired. The v18 confirmation is untouched.
* v19 adds the mechanism panel (wave 17, exploratory, **CHANGES_v19.md**): swaps of implants between ages and between a fixed-split and a redrawn-split lineage, gradual reassignment of branch responsibilities, and exact recoding of finite-peg interfaces. (superseded by v20.) The confirmation keeps running from the v18 folder.
* v18 adds the recipe comparison at selected checkpoints and fixes the confirmation's finite recipes after wave 16 (analysis only; run ids unchanged from v17). Next: `scripts/16_v13_confirmation.sh freeze`, then `run`.
* v17 follows the wave-15 panel and its review (**PANEL_v16_RESULTS.md**, **CHANGES_v17.md**): separate partition seeds and the fixed-vs-redrawn partition contrast in the confirmation, compute-matched finite scratch arms, a straight-through margin recipe for edge-clipped finite pegs with a read-only probe, selected-checkpoint diagnostics for treated chains, labelled readout checkpoints, and explicit locality matching. Run `scripts/18_v17_followup.sh` next (tests, probe, wave 16, runtime); results go to `~/cop_results_v17`.
* v16 is a multi-pass review of v15: branch-only deletion in the frozen sweep, a full evaluation at every cut, gradient audits at end and selected checkpoints, pooled draw-level summaries for the recipe panel and M_E, `summarize --strict` in the launchers, and the locality cell in wave 15 (94 jobs, about 1.6 h). **COVERAGE_v15_review.md** says which review requests are done, partial or not done; **CHANGES_v16.md** lists the changes. Results go to `~/cop_results_v16`.
* v15 follows the v14 review (CoP_v15_review_and_Claude_instructions): pairing that keeps replications apart, a confirmation launcher that fails on any failed stage and guards the frozen protocol, removal-path events exported by event identity with a frozen-weight sweep, draw-level summaries, finite-peg recipes (adaptive range, warm-up), gradient-partition modes with empirical exposure, and three separate locality outcomes. **AUDIT_RESPONSE_v14.md** has the fix table, DEVIATIONS 138-142 the details. Run `scripts/17_v15_rebuild_and_panel.sh` next (tests, read-only v13 rebuild, the wave-15 control panel, runtime); the confirmation (scripts/16) waits for its review.
* v13 follows the v12 audit (CoP_v12_Audit_and_v13_Claude_Handoff): the identity gate measures how the edit changes the execution error (d_edit), baseline training work is recorded and reported once in total procedure cost, fixed-budget and validation-selected endpoints are kept apart, and the re-pilot (wave 13) and confirmation (wave 14) manifests carry information-access and budget metadata. **AUDIT_RESPONSE_v12.md** has the fix table, **CLAIMS_v13.md** the per-claim table, DEVIATIONS 126-136 the details. Run `scripts/15_v13_repilot.sh` (tests, CUDA tests, audit probes, historical costs, re-pilot, runtime) before anything else; `scripts/16_v13_confirmation.sh` is never launched automatically. All run ids changed; v9 results are read-only.
* v12: an insertion's stability check judges the round-off the edit adds, not round-off the network already had (a full-scale shortcut trajectory was quarantined although its edit was bitwise exact); semantic change, so v9 results are stale (DEVIATIONS 125).
* v11: the gates treat a child of a parent that its own job recorded as numerically invalid (the v9 pilot's one diverged X1 trajectory) by that record: its diagnostic row is listed as excluded, its endpoint must reproduce exactly (non-finite values included) and is listed apart; analysis code only, v9 results stay current (DEVIATIONS 124).
* v10 makes the summary robust to non-finite values from diverged runs (the v9 lab pilot's summary step crashed in Fig 7) and moves the pilot's analysis and packaging tail into scripts/14, which can finish an existing pilot; analysis code only, so v9 results are not stale (DEVIATIONS 123).
* v9 fixes three CPU/GPU device mismatches found when the lab GPU ran the MLP Wave-0 controls (fold probe, probe-selected cuts, task-aligned known module); see DEVIATIONS 122.
* v8 corrects v7 after the independent audit (V7-01 ... V7-07): diagnostics with consistent dtypes, a scoped derivative-capable attention kernel and per-measurement statuses; per-assembly transplant eligibility; gate helpers and scripts/12 that fail on failed checks; a three-claim identity check that cannot relax its own tolerance; finite-checked static games; an evidence-complete review archive; and recovery tooling for existing results. **AUDIT_RESPONSE_v7.md** has the fix table, **RECOVERY_v8.md** the recovery plan and commands. Run ids are unchanged from v7.
* v5 follows the review of v4 (CoP_v5_Review_and_Claude_Handoff): gain retention with raw numerator and denominator (no absorption interpretation), constructive compact witnesses, non-mutating contraction diagnostics, exact finite-interface cells with a codebook solver, a paired interface-locality experiment, the static dependence game, and the full transplant grid. **AUDIT_RESPONSE_v4.md** lists each item, its fix, its test and what remains limited; docs/STRENGTHENING.md ("v5 additions") describes the new blocks. v4 outputs are not reused (new code version).

The code builds, edits, trains, deletes from, repairs and exports explicit computation graphs, runs the finite certificates and transition systems, and runs the Chain of Pearls experiments. It has resumable manifests for Waves 0 to 7 and a GPU integration pilot (wave 9).

**Nothing here is a result yet.** In the sandbox where it was written, the code ran only on CPU at smoke scale to check the pipeline. See DEVIATIONS.md item 1. Do not start the sweeps before the integration pilot (`scripts/10`) has been run and reviewed.

## Layout

```
cop/
  utils.py            hashing, named RNG streams, atomic IO, locks
  config.py           job schema, strict validation, run ids
  env.py              inspect_environment, real CUDA forward/backward/update check
  data/               D01-D08 (synthetic, finite, shortcut, digits/covertype/california, FMNIST/CIFAR, sequences)
  graph/              GraphNet, builders (MLP, CNN, ResNet, Transformer, GRU), edits (cuts, constructions A-F,
                      groups, deletion, folding), export, accounting
  train/              trainer (streams, freeze policies, optimizer-state policy, targets, exact resume), metrics
  experiments/        baseline/trajectory (E1-E5, I1-I4, grow/contract cycles), deletion (R1), repair (R2/R4),
                      dissipation (R5), continuation controls C1-C8 (continuation.py), transplants
                      (transplant_job.py), probes, Wave-0 controls
  calibration/        section-7 boundary checks of the strengthening addendum (byte-identical port)
  finite/             R3 certificates, I5 transition systems, independent checker, codebook (exact
                      delayed-query and retention optima)
  cop_pegs/           pegs (bridges, repetition routes, later-query decoders), pearl alternatives, P1-P5,
                      section-10 baselines, cut alignments (transplant.py)
  orchestration/      manifests (waves 0-7; wave7.py = strengthening), runner (claims, statuses, attempts,
                      resume), calibration
  analysis/           summarize (tables, paired contrasts, coverage, 12 figures), strengthening (compact gain,
                      figures 1-7), v5_tables (gain retention, diagnostics, finite interfaces, locality,
                      transplant grid, figures 8-9), dependence_game, review packaging
  cli.py              all commands
tests/                acceptance tests T01-T24, data tests, finite tests, audit regression tests (test_v2_audit.py),
                      strengthening tests (test_strengthening.py: section 7; test_strengthening_v3.py: v3 features),
                      v3-audit gates (test_v3_audit_supplied.py: the audit's own; test_v4_audit.py: v4),
                      v5 review checks (test_v5_review.py: section 10 of the review),
                      job-level resume harness (resume_harness.py)
audit_v2/             the audit's probes re-run against v2 (results v1 / v2), second-pass review
                      reproductions, and the tools that produced sandbox_checks/
audit_v3/             resume comparisons of the v3 job paths (tools/resume_comparisons_v3.py)
audit_v4/             v4 tools: resume comparisons, fresh-process reload, contract collisions, rejection
                      examples, runtime estimate; evidence/ (collisions, the audit's probes against v4)
audit_v5/             v5 tools: exact optimum table, resume comparisons of the v5 paths, fresh reload with
                      witnesses and grid transplants
scripts/              setup and launch scripts
configs/              budgets.yaml (training budgets), confirmation.yaml (Wave 6 selection),
                      finite_interface_optima.json (exact finite optima with cross-checks)
docs/                 SEMANTICS.md (exact definitions), CERTIFICATES.md (finite certificates)
COVERAGE.md  DEVIATIONS.md  QUESTIONS.md  AUDIT_RESPONSE.md  AUDIT_RESPONSE_v3.md  AUDIT_RESPONSE_v4.md  REVIEW_v4.md
REVIEW_v5.md  TEST_MATRIX.md(.json)  PATCH_v1_to_v2.diff  PATCH_v3_to_v4.diff  PATCH_v4_to_v5.diff
```

## Setup on the WSL machine

Keep the project on the Linux side (for example `~/research/cop_research_v12`), not under `/mnt/c`. If you already have a working venv (e.g. `~/fsc/.venv`), skip `setup_env.sh` and set `COP_VENV` to it; the scripts activate it. For v12 on a machine that already ran v7, follow RECOVERY_v8.md instead of this section.

```bash
cd ~/research && unzip cop_research_v12.zip && cd cop_research_v12     # next to v1 ... v11, which stay untouched
sudo apt install -y python3-venv     # Ubuntu 24.04 needs this once for `python3 -m venv`
bash scripts/setup_env.sh            # isolated .venv, torch 2.14.1 + cu126 wheels, environment report
bash scripts/00_fetch_data.sh        # FMNIST, CIFAR-10/100, Covertype, California -> ~/cop_data
```

`setup_env.sh` uses the official PyTorch wheel index (`TORCH_INDEX=cu126` by default; `cu130` also exists for 2.14.1 if the Windows driver supports CUDA 13). It does not install any NVIDIA driver inside WSL. It writes `requirements-lock.txt` and `~/cop_results_v5/environment.json` (Python, torch, CUDA build, driver line, GPU name and memory, CPU, RAM, pip freeze, code hash, and a real CUDA training check). If `cuda_smoke.ok` is false, stop and fix the environment first.

Environment variables used by every script: `COP_RESULTS` (default `~/cop_results_v5`, so earlier results are never mixed in), `COP_DATA_ROOT` (`~/cop_data`), `DEVICE` (`cuda`), `WORKERS` (1), `THREADS` (4), `SCALE` (`full`, or `pilot` / `smoke`).

## Order of work

```bash
bash scripts/01_cpu_exact_tests.sh      # full pytest suite + Wave-0 CPU controls and finite validation; GATED
bash scripts/02_gpu_calibration.sh      # CUDA training + reload check, Wave-0 CUDA controls (GATED), timings, estimates
bash scripts/10_wsl_gpu_pilot.sh        # integration pilot on the GPU -> ~/cop_wsl_pilot_v5.zip; send it for review
bash scripts/12_v5_gpu_gates.sh         # all CUDA tests (a skip fails), GPU resume, GPU smoke + every v8 check + reload -> ~/cop_v5_gpu_gates.zip (exit 1 on any failed step)
bash scripts/13_v8_recovery_and_validation.sh   # v8: scan / recover existing results, then the v8 validation pilot (RECOVERY_v8.md)
bash scripts/11_strengthening_pilot.sh  # runtime sample + estimate, then wave 7 at pilot scale -> ~/cop_strengthening_pilot_v5.zip
# after the pilot review, adjust configs/budgets.yaml from VALIDATION curves only, then:
bash scripts/03_wave1_sweeps.sh         # 810-trajectory core + breadth blocks
bash scripts/04_wave2_real_data.sh      # 270-trajectory image block + tabular + sequences
bash scripts/05_wave3_topology_history.sh
bash scripts/06_wave4_deletion_repair.sh   # uses completed trajectories in $COP_RESULTS (balanced rule)
bash scripts/07_wave5_cop.sh
bash scripts/09_summarize_package.sh    # tables, figures, review archive ~/cop_review_v5.zip
# after freezing configs/confirmation.yaml:
bash scripts/08_wave6_confirmation.sh
```

Every script is resumable: re-running skips completed jobs and continues interrupted ones from their checkpoints (update-level for training, step-level for local fits). `MAX_JOBS=200 bash scripts/run_all.sh` runs everything in chunks; it stops after the pilot until `PILOT_REVIEWED=1`. Ctrl-C checkpoints the running job and leaves it `pending`. Pass `--time-limit SECONDS` through a wave script to cap each job (it is then `timed_out` and resumable).

**Gates.** `cop run` exits non-zero when any job ends `failed`, `invalid`, `timed_out` or `stale`, and the wave scripts stop there (set `ALLOW_FAILED_JOBS=1` to continue past failed jobs of a research wave after inspecting them). `cop gate` checks that every device-applicable job of a manifest is complete and valid; scripts 01 and 02 gate on the Wave-0 controls.

**Statuses.** `complete` (with `validity` = `valid` or `unverified` in status.json), `invalid` (a claimed contract was violated: diagnostics in `invalid.json`, dependants skipped, never analysed), `stale` (produced by different result-determining code: rerun with `--rerun-stale`, or record a reasoned reuse with `cop accept-stale`), plus `pending`, `running`, `failed`, `timed_out`, `unsupported`, `skipped_with_reason`.

Start with one GPU worker. Small MLP jobs leave the GPU mostly idle, so after `scripts/02` you can try `WORKERS=2` or `3` (each worker is a separate process; job claims prevent duplicates). Image and Transformer blocks should stay at one or two workers.

## Commands

```
python -m cop.cli inspect-environment --out env.json
python -m cop.cli generate-manifest --wave 1 --scale full [--dry-run -v]
python -m cop.cli validate-manifest --manifest manifests/wave1_full.jsonl
python -m cop.cli run --manifest M --device cuda --resume [--workers N] [--only RUN_IDS] [--kinds K] [--max-jobs N]
                       [--rerun-stale] [--allow-code-change]
python -m cop.cli status --manifest M
python -m cop.cli gate --manifest M --device cuda [--kinds control] [--allow-unverified]
python -m cop.cli accept-stale --run-id ID --reason "only analysis code changed"
python -m cop.cli verify-reload --run-dir ~/cop_results_v5/runs/<P3 or P4 run>
python -m cop.cli evaluate-deletions --run TRAJ_RUN_ID --family structured
python -m cop.cli repair --parent TRAJ_RUN_ID --deletion max_single --region incident_adapters --budget 0.5 --target expanded
python -m cop.cli export-compact --checkpoint ~/cop_results_v5/runs/<id>/ckpt/final.pt
python -m cop.cli verify-certificate --certificate ~/cop_results_v5/runs/<id>/finite/certificate_rank_0.json
python -m cop.cli calibrate --device cuda ; python -m cop.cli estimate --manifest M --timing T --workers N
python -m cop.cli summarize --manifest manifests/wave1_full.jsonl ...
python -m cop.cli package-for-review --out ~/cop_review_v5.zip
python -m cop.analysis.pilot_report --results R --manifest M --data-root D --device cuda --out pilot_report.json
```

## Job counts (scale full)

| Wave | Jobs | Content |
|---|---|---|
| 0 | 27 | 7 control jobs per backend (CPU and CUDA) on MLP, digits, CNN, ResNet, CIFAR ResNet, Transformer, GRU; 13 finite validation certificates |
| 1 | 1,631 | core 810 trajectories (162 baselines), frequency/composition 200, noise 90, sample-size matching 63, fresh vs fixed 9, parity 60 (20 input bits) + 30 (10 bits, complete-domain evaluation), multiplexer 15, delayed query 30, shortcut/rare 45, linear rank 16 |
| 2 | 630 | images 270, plain CNN on CIFAR-10 30, digits 45, covertype 60, california 30, sequences 90 |
| 3 | 1,908 | E1-E5, I1-I4 on four settings, the explicit recursion x granularity x pegs cross, the hard fixed matrix, known modules, 64-event histories |
| 4 | 2,111 | deletion 14, repair 1,446 (incl. repairs over a 32-round history), paths 558, finite 61 (standalone parents; with completed results the balanced rule selects parents) |
| 5 | 1,046 | P1 187, P2 277, P3 196, P4 54, P5 486 jobs (incl. matched endpoint controls for every P5 history variant of seed 0 and for the section-10 baselines), plus reference chains and baselines |
| 7 | 4,077 (1,359 at pilot scale, seed 0) | strengthening extension: 50 registry variants, controls C1-C8 (C0 is f0), mechanisms A-H, T0/T1 panel, size x complexity panel, five mandatory crosses, and the v5 blocks: witness cells, backbone-frozen fold, finite interfaces, locality, transplant grid (docs/STRENGTHENING.md) |
| 9 | 44 (pilot scale) | GPU integration pilot: one small case per model family and job kind (not a scientific wave) |

Counts include prerequisites and are de-duplicated by run id across blocks. They are job counts, not independent replications, and not runtime promises; `scripts/02` measures per-update cost on this machine and prints hour and disk estimates.

## Outputs

Each run directory `~/cop_results_v5/runs/<run_id>/` contains `config.json` (resolved, immutable), `status.json`, `attempts/` (one record per attempt with exec settings, code and environment hashes, errors and restart commands), `metrics.jsonl` (long-format rows with every required field: run, attempt, parent, work package, config/code/environment hashes, split hashes, seeds, stage, graph hash, metric, value, partition, updates, examples, elapsed, peak memory, status), `log.jsonl`, `ckpt/` (baseline reference, post-insertion and per-round states with optimizer and generator states and lineage), `graphs/` (machine-readable JSON and Graphviz DOT per stage), `preds/` (raw predictions at baseline and final), and job-specific results (`deletions_final.json`, `repair_result.json`, `dissipation_result.json`, `cop_chain_result.json`, `assemblies.json`, `alternatives_result.json`, `split_result.json`, `cycles_result.json`, `finite/certificate_*.json`).

Every run also writes `provenance.json` (semantic code hash), and quarantined runs `invalid.json`. P3 / P4 runs save every trained module, interface, adapter and assembly prediction (`alternatives_modules.pt`, `alternatives_predictions.pt`, `split_modules.pt`, `split_predictions.pt`, `ckpt/reference_exported.pt`); `cop verify-reload` reproduces the predictions in a fresh process. Summaries carry the measured work by phase (`work`).

`summarize` writes `trajectories.csv`, `paired_contrasts.csv/json` (topology minus its validated continued baseline, ONE contrast per condition id = full config minus replication seeds and lineage; hierarchical bootstrap over data/teacher seeds then optimizer seeds), `conditions.json`, `analysis_errors.json` (pairing mismatches, duplicate replications, runs excluded for validity), `validity_quarantine.csv/json`, `repairs.csv`, `dissipation.csv`, `cop_*.csv`, `finite.csv`, `coverage.json` (every expected job with its status, including failed, unsupported, skipped and missing) and the twelve figures required by section 14.

## Specification map

| Spec section | Where |
|---|---|
| 2 machine and environment | `cop/env.py`, `scripts/setup_env.sh`, `scripts/02_gpu_calibration.sh` |
| 3 definitions and claim levels | `docs/SEMANTICS.md` sections 3-5 |
| 5 data | `cop/data/`, `tests/test_data.py` |
| 6 models, cuts, insertion contracts | `cop/graph/builders.py`, `cop/graph/edits.py` |
| 7 E1-E5 | `cop/experiments/growth.py`, `trajectory.py` |
| 8 R1-R5 | `cop/experiments/deletion.py`, `repair.py`, `dissipation.py`, `cop/finite/` |
| 9 I1-I5 | `trajectory.py` (drivers, policies, conditions), `cop/finite/transition.py` |
| 10 P1-P5 and baselines | `cop/cop_pegs/` |
| 11 waves | `cop/orchestration/manifest.py` |
| 12 training and matching | `cop/train/trainer.py`, `trajectory.py` |
| 13 measurements | `cop/train/metrics.py`, `cop/graph/accounting.py`, `probes.py`, `trajectory.crossover` |
| 14 statistics and figures | `cop/analysis/summarize.py` |
| 15 engineering contract | `cop/cli.py`, `cop/orchestration/runner.py`, `cop/config.py`, `cop/experiments/context.py` |
| 16 acceptance tests | `tests/test_acceptance.py` (+ `test_data.py`, `test_finite.py`, `test_v2_audit.py`) |
| 19 review archive | `cop/analysis/package.py`, `scripts/09_summarize_package.sh` |
