# v13 reuse and remeasurement of earlier results

v13 changes semantic code (`cop-6.0.0`), so every earlier run is stale to the runner. Stale does not mean
scientifically invalid: earlier measurements stay valid for the code that produced them. v13 reuses earlier
results only by explicit, checkpoint-based remeasurement with both code versions recorded, never by resuming
training under a code-change bypass.

## What is remeasured, what is rerun

| Quantity | v9 pilot (read-only) | Action in v13 |
|---|---|---|
| baseline and total-procedure costs | baseline work missing from the ledger (reported as zero) | recomputed from `ckpt/baseline.pt` / `baseline_ref` trainer counters, `provenance: checkpoint_counters`; missing evidence is incomplete |
| all tables and figures | v9 analysis code | recomputed by the current analysis code over the saved files |
| insertion identity verdicts | v12 rule (u_post - u_pre) | not recomputed; the v13 gate applies to v13 runs. A v9 insertion can be rechecked with `cop recheck-insertions` (writes separate records) |
| training, endpoints, diagnostics, selection | v9 code, no selection | rerun in v13 (waves 13 / 14, new results folder); never resumed |

## Commands (scripts/15 runs the first one)

```
cop summarize --historical --results ~/cop_results_v9/strengthening_pilot \
    --manifest ~/cop_results_v9/strengthening_pilot/wave7_pilot.jsonl \
    --out ~/cop_results_v13/historical_v9_pilot
```

The output folder holds `historical_provenance.json` (the producing semantic hash, the current analysis hash,
what was and was not recomputed) next to the rebuilt tables: `strengthening/s_endpoints.csv` and the pair tables
carry `baseline_macs`, `post_f0_macs`, `total_procedure_macs`, `total_procedure_complete` and
`f0_cost_provenance`. scripts/15 checks that no file under `~/cop_results_v9` changed.
