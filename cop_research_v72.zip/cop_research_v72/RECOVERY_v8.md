# Recovering v7 results and validating v8

Your current pilot runs on v7 code in `~/research/cop_research_v7` and writes to `~/cop_results_v5`. Let it finish. v8 goes into its own folder, `~/research/cop_research_v12`; nothing below edits, deletes or resumes a v7 run.

## Status on the lab machine (25 Oct 2026)

The v7 night run stopped in Wave 0: 7/7 CPU controls and 13/13 finite validation jobs passed, 5/7 GPU controls passed, and the two MLP GPU controls failed with a CPU/GPU device mismatch in the fold check (the same failure on v8; fixed in v9). No smoke or pilot job ran, so there are no v7 pilot results to recover. Phases A and B below are only needed for results folders that hold pilot runs. For the lab machine now: run phase C with v9 (step 3, `PHASES="C"`), then the pilot.

## What can be reused

Run ids are the same in v7 and v8, so every v7 run maps to the same v8 job. The training code did not change; v8 changes measurement, validation and analysis. To the runner a v7 run is "stale" (different semantic code hash) until you accept it with a reason, so nothing is reused silently.

| category (recovery manifest) | meaning | action |
|---|---|---|
| `reusable_unchanged` | complete, no flagged measurement | keep; accept the reuse with `cop accept-stale --run-id ID --reason "..."` if a v8 job should depend on it |
| `needs_diagnostic_recompute` | a dissipation / repair diagnostic row is incomplete and its parent checkpoint exists | `recompute-diagnostics` (from the parent checkpoint; no training) |
| `needs_cycle_replay` | an incomplete diagnostic of a grow/contract cycle; v7 saved no pre-contraction state (`round_<r>` is saved after the contraction and is not used as a substitute) | `replay-cycles`: reruns the trajectory in a scratch folder from copies of its parents, checks that every replayed `round_<r>` has the original parameter hash, and only then recomputes the diagnostics from the replayed pre-contraction state |
| `needs_adapter_refit` | a grid transplant with an ineligible (diverged / failed / non-finite) assembly | rerun that transplant job under v8; its parents are reused, only the adapters are fitted |
| `needs_identity_recheck` | an insertion passed under the v7 relaxed tolerance (above 1e-5) | `recheck-insertions` (pre-edit `round_<r-1>` or `baseline_ref` against `post_insert_r<r>`, high precision); a review flag, not proof of an invalid insertion; if the recheck says `changed`, exclude that trajectory from the exact-expansion population and rerun it and its dependants |
| `analysis_only` | a deletion landscape with non-finite values | nothing to rerun; v8 reports that landscape as invalid |
| `unverifiable` | not complete, a missing source checkpoint, or a source that does not reproduce its recorded state | listed with the reason |

Wave-0 controls judged by the v7 relaxed rule are listed as `needs_identity_recheck` with the action "rerun this control job"; they are cheap and nothing trains on them. Runs that completed as `unverified` are listed as `unverified_run` with their reasons.

Recomputed diagnostics are written only to `<results>/recomputed_diagnostics/<run>.json`, with the source run, stage, checkpoint path, recorded and loaded parameter hashes, the hash of the original record, the diagnostic version (`diag-8.0`) and the code hash. The original `contraction_diagnostics.json` is never changed. The v8 analysis uses a recomputed row only where the original was incomplete, and says so in the `diagnostic_source` column.

## Commands (lab machine)

1. Unpack v8 next to v7 (the pilot keeps running on v7):

```bash
cd ~/research
unzip -q -o "/mnt/c/Users/Matthew Fried/Downloads/cop_research_v12.zip"
```

2. Read-only scan, safe while the pilot runs (the scanner exits 1 when it finds flags; that is intended):

```bash
cd ~/research/cop_research_v12
source ~/fsc/.venv/bin/activate
PHASES="A" COP_VENV=~/fsc/.venv bash scripts/13_v8_recovery_and_validation.sh
```

3. After the pilot has finished (`ps -p <pid>` shows nothing), recompute and replay, then validate v8 in its own results folder:

```bash
cd ~/research/cop_research_v12
nohup env PHASES="B C" COP_VENV=~/fsc/.venv WORKERS=1 THREADS=8 \
    bash scripts/13_v8_recovery_and_validation.sh > ~/research/run_v8_recovery.log 2>&1 &
```

Phase B refuses to start while any `cop run` process is active. Replays run only in `~/cop_v8_replay` (must be outside the results folder; the tool refuses otherwise). A recomputation that is still incomplete is recorded as `incomplete` and rerunning phase B retries it. Phase C runs 01, 02 and 12 with v8 into `~/cop_results_v8_validation`: the full CPU suite, Wave 0, every CUDA test (a skip fails), resume checks, a GPU wave-7 smoke with every v8 check, and the reload check. This is the small validation pilot. It does not start the large wave-7 pilot.

4. Send `~/cop_v8_recovery_validation.zip`. It holds the scanner reports, the recovery manifests (before and after), the recompute / recheck / replay reports, the checks, the step exit codes and the validation gate verdict with its zip.

## Before the next large sweep

Only after phase C passes: decide per category above. The next pilot command is the same as before, run from the v8 folder into a fresh results folder so v7 and v8 outputs never mix:

```bash
cd ~/research/cop_research_v12
nohup env COP_VENV=~/fsc/.venv COP_RESULTS=~/cop_results_v8 WORKERS=1 THREADS=8 PAUSE=0 RUN_FULL_SAMPLE=1 \
    bash scripts/11_strengthening_pilot.sh > ~/research/run_v8_pilot.log 2>&1 &
```
