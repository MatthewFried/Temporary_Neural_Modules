# v13 re-pilot on the lab GPU (wave 13, 28-29 October 2026)

RTX A4500, torch 2.14.1+cu126. Wave 13 ran at FULL scale (one round = 2000 updates; see DEVIATIONS 137), one
discovery seed (data / teacher / optimizer seed 0). Exploratory: these numbers guide the confirmation protocol.

## Checks

* 288 / 288 jobs complete and valid; 268 / 268 endpoints reload bitwise in a fresh process on CUDA.
* CUDA tests 14 passed, 0 skipped. CPU suite 401 passed, 1 failed (a resume-helper test run with CUDA hidden but
  `DEVICE=cuda` exported; a script fault, fixed in v14).
* Audit probes: identity counterexample `execution_changed` (d_edit 6.0); baseline cost reported.
* Numeric validity: 0 invalid endpoints, 0 invalid descendants, 60 / 60 complete diagnostic rows.
* v9 results untouched. Rebuilt v9 cost tables: 1137 of 1163 endpoint rows costed from checkpoint counters.
  The audit's M_H bridge_all M2 example: treated total 12.88e9 MACs (was reported as 4.52e9) vs control 12.88e9.
* Positive controls: exact local replacement 180 / 180, frozen-code lookup 72 / 72 (finite pegs); predictions
  independent of group metadata in every specialization job; no trained tensor survived any scratch reset;
  finite-code MAC matching 1.000 x the reference.

## X4 (shortcut, n 4096; test error, fixed-budget endpoints; f0 is the validation-selected baseline)

| rho 0.95 | test err | shift err | rare err |
|---|---|---|---|
| f0 | 0.238 | 0.438 | 0.515 |
| compact C1 / C1 0.3x / restart / cosine / C2 | 0.234-0.236 | 0.430-0.433 | 0.514-0.516 |
| compact C1 group-balanced | 0.243 | 0.447 | 0.509 |
| parallel expansion | 0.238 | 0.426 | 0.514 |
| specialized, true group | 0.146 | 0.263 | 0.503 |
| specialized, random partition (same proportion) | 0.195 | 0.368 | 0.482 |
| specialized, observed label | 0.206 | 0.368 | 0.510 |
| specialized, true group + group-balanced sampling | 0.366 | 0.674 | 0.406 |

rho 0.7 has the same ordering (f0 0.095; true group 0.051; random 0.082; label 0.081; parallel 0.099; C1 0.100).

Removal protocol, specialized by true group, rho 0.95 (removal + repair updates): 200 + 2800 (treated) 0.146,
abrupt + 3000 0.140, 2000 + 1000 0.123, MAC-matched abrupt 0.147, 200 + 1000 (historical, fewer updates) 0.100.
During removal of the true-group branches the validation risk sits at chance (0.69) for much of the removal phase; the
random-partition branches remove without that collapse.

Validation-selected endpoints (in-distribution val) are worse on the shifted tests for the specialized arms
(true group: 0.171 selected vs 0.146 fixed), as expected when val shares the training correlation.

## Matched architectures (teacher depth 3, n 2048, MLP depth 6; MSE; f0 0.340)

History ingredients (fixed endpoint; tuned = better of base / 0.3x LR by validation):

| | dim 4 | dim 8 |
|---|---|---|
| direct scratch M1 tuned | 0.358 | 0.416 |
| warm start, abrupt calibrated interfaces | 0.298 | 0.321 |
| gradual, no bridge (treated; tuned) | 0.285 (0.279) | 0.327 (0.295) |
| gradual, bridge on all pegs | 0.286 | 0.321 |
| gradual, local bridge | 0.284 | 0.308 |

F07 replication (treated tuned vs M1 tuned): dim 2 0.460 vs 0.548; dim 8 0.295 vs 0.416; dim 32 0.394 vs 0.560;
bits 1 0.838 vs 1.001; bits 4 0.687 vs 1.001; bits 16 0.696 vs 0.741. Scratch M1 / M2 with 1- and 4-bit pegs stay
at MSE ~1.0 (the target variance) at both learning rates; the 1-bit scratch quantiser clips 65% of values at start.

F09: query after encoding, treated beats M1 tuned for bit (+0.054), two_bits (+0.125), xor_next (+0.059); query
before encoding, M1 wins all three (-0.006, -0.014, -0.042). In the query-after cells every compact model is far
worse than f0.

M_E (task error 0 for every arm): later-query oracle accuracy, treated vs M1 / M2 (chance 0.49): continuous pegs
I1 0.72 vs 0.68, I2 0.71 vs 0.64; 2-bit pegs I1 0.71 vs 0.65, I2 0.64 vs 0.61.

X3 boundary: treated loses to the scratch control in both cells (0.526 vs 0.200; 0.451 vs 0.405).

## Finite codes (errors on the complete domain)

Family A (delayed query): code oracle error / optimum. n 3: gradual bridge 4 / 4, abrupt bridge 4, no bridge 5,
MAC-matched no bridge 4. n 4: 18, 18, 19, 18 / 12. n 5: 45, 44, 45, 48 / 36. A decoder-only refit with the
encoder frozen brings model error to the oracle error in every case it was tried (gap closed 75-100%).
Family B (later query, task preserved): identical across all arms (later oracle 6 / 19 / 42 vs task-preserving
optimum 4 / 12 / 40).

## Locality (5 interfaces x width {4, 16} x repair {1000, 4000}; 3 checkpoints, 3 tolerances)

No-peg control: scope 1 everywhere. Pegged arms at width 4: mostly scope 3-4 or censored; width 16: finite pegs
mostly scope 1. Longer repair is not uniformly better. Code matching rarely succeeds at width 4 and often at
width 16 for finite pegs at tolerance 0.01. Positive controls pass everywhere, so failures are failures of the
fitted replacement, not leakage around the interface.

## Corrections after the v14 review (v15)

These replace the corresponding statements above. The training results are unchanged; scripts/17 rebuilds the
full tables from the lab results with the v15 analysis code.

* X4, true-group specialization, rho 0.95: the EXPANDED model is already at chance before any removal (validation
  risk 0.693, accuracy 0.477 at the path start; the observed-label expansion 0.54 accuracy; the random-partition
  expansion 0.94). Chance-level loss during removal therefore shows nothing about removal damage, and the compact
  gain of this arm arises during removal and repair of a collapsed expanded model, not from absorbing an expanded
  gain. The intact-versus-immediately-deleted comparison on the same weights is now recorded for every new run
  (frozen-weight sweep; start and post-cut events exported separately).
* The random-partition result is not a causal "45% specialization / 55% group information" decomposition:
  membership stability, gradient exposure and scale, and group information all differ, and the masks act on
  gradients only. Wave 15 separates fixed from redrawn membership and the 0.95 from the 0.5 share.
* Rare-group error is not near chance in every arm: group-balanced specialization has 0.406 rare error with ordinary
  test error 0.366, a trade-off.
* Selected endpoints weaken the history-ingredient story: dim 4 abrupt warm start 0.281 vs gradual 0.279; dim 8
  abrupt 0.284 vs gradual 0.291. Warm starting with calibrated interfaces takes most of the credit; no bridge
  benefit. C4 dim 8 and F07 dim 8 are the same runs, not independent evidence.
* Finite scratch controls: several 1- and 4-bit (and some base-LR 16-bit) scratch runs collapse to a single
  downstream message with near-total clipping; the lower learning rate rescues some. This is an optimization /
  calibration confound, not evidence that history is necessary. Message size is dimension x bits (d 4, b 2 is an
  8-bit message).
* Decoder refit does not close every gap: n 5 no-bridge leaves model 46 vs code oracle 45. Bridge differences
  depend on the comparator (n 5: abrupt bridge 44, no bridge 45, MAC-matched no bridge 48).
* M_E: task error is zero for the default arms only (finite M1 0.3x LR 0.00098, finite treated 0.3x LR 0.0029).
  The later-query numbers are held-out READOUT accuracies of training-fitted probes (least squares for continuous
  pegs, a majority table per message for finite pegs), not information oracles.
* F09: the winner depends on metric and endpoint policy (fixed-endpoint tuned xor_next after encoding wins on
  cross-entropy but can lose on error); always name both.
