# v44 results (wave 24), corrected write-up

Test error in % (f0 = 24.39), mean over 6 data draws (two optimizer seeds averaged within each draw), 95% CI over
draws, and the number of draws in the favoured direction.  All of wave 24 is exploratory.

## Expansion with layers 2 to 5 held at f0 (downstream frozen)

- At 2U, the extraction from the downstream-frozen expansion (first layer kept, layers 2 to 5 f0's, additions
  deleted) gave 27.97: 3.58 [−8.16, +1.00] worse than f0, with 1 of 6 draws better than f0.  The ordinary
  expansion's extraction gave 23.78 (+0.61 [−0.90, +2.12] vs f0).
- At the endpoints the downstream-frozen lineage (holds lifted for removal and keep) was worse than the ordinary
  lineage: 1.93 [0.90, 2.95] (removal) and 1.51 [0.52, 2.50] (keep), 0 of 6 draws in its favour.
- The expansion's advantage over its matched compact control was substantially reduced, with no clear remaining
  advantage over the matched compact control: +0.40 [−0.30, +1.11] (removal), −0.13 [−0.55, +0.29] (keep).  The
  ordinary expansion's advantage was +2.72 [1.60, 3.84] and +1.94 [0.71, 3.17], 6 of 6 draws each.  The interval
  for the downstream-frozen lineage does not establish a zero effect.

## Extraction

Extraction did not show a clear benefit in the tested ordinary and downstream-frozen lineages.  The successful v43
shortcut-frozen extraction rule was not included, so its fresh-draw confirmation remains outstanding.

- Ordinary lineage: 23.78 against removal and repair 20.75 (repair better by 3.03 [2.24, 3.82], 0 of 6), compact
  extraction at 2U +0.16 [−1.31, +1.63], compact endpoint −0.31 [−1.79, +1.18].
- The privileged reference (f0's causal columns scaled by factors chosen on val_indep, which uses the
  feature-group labels): 10.22.  It is a privileged reference, not a ceiling or bound; its scale search is still
  limited by the grid boundary in most grids.

## Keep / restore codes: scoped by lineage, checkpoint and addition status

A native keep model includes its additions; a code evaluated after deleting them is a different model.  These are
listed separately.

| Lineage, checkpoint | Additions present: native | Additions deleted: best code |
|---|---|---|
| ordinary, abrupt (2U) | 23.96 | 0-1-1-1-1, 23.78 |
| ordinary, kept_end | 21.74 | 0-1-1-1-1, 22.87 |
| ordinary, repaired | (deleted by the removal) | 0-0-0-0-0 (native), 20.75 |
| downstream frozen, abrupt (2U) | 25.21 | 1-0-0-0-0 (= f0 here), 24.39 |
| downstream frozen, kept_end | 23.25 | 1-1-1-0-1, 24.34 |
| downstream frozen, repaired | (deleted) | 0-0-0-0-0 (native), 22.68 |

The compact controls' 32-code maps are much flatter than the expansion deletion landscapes, but not uniformly
within half a point: ordinary C1_phase spans about 23.47 to 24.47; the downstream-frozen-then-released C1_phase
spans 23.08 to 24.56.  The expansion deletion landscapes span up to about 29 points (ordinary abrupt, 23.78 to
51.83).

## Learned causal block against rescalings of f0's causal weights

Per row, w_learned = a · w0 + r (a the weight-space least-squares scale).  In the ordinary lineage at 2U:

- the complete learned block 16.55; f0 + residual alone 18.71; scaling alone 21.02.  Both component interventions
  improve on f0, and the complete learned block outperforms either tested component alone (by 2.16 [1.60, 2.72]
  and 4.48 [1.70, 7.25]).  This does not show that both are necessary for equivalent performance.
- against f0's block rescaled to the learned block's norm the complete block was ahead by 1.82 [−0.38, +4.03],
  not resolved.  The learned change includes changes outside the family of per-row scalings of f0's causal
  weights; this is not a claim about the full feature span or about indispensable new features.
- the residual is about a third of the learned block's energy (0.36 [0.26, 0.47]).
- f0 + r is also larger in row norm than f0, so the residual result above does not separate direction from
  magnitude; v45 adds the controls that do (f0's directions at the norm of w0 + r; w0 + r at f0's norm).

## Controls and compute

The compact controls are matched in updates and phase schedule (optimizer resets), not in compute.  By the review's
accounting the ordinary removal procedure costs about 77.6 billion MACs against 57.5 billion for the compact
continuation; v45 records the training cost of every state (forward, input gradient, parameter gradient, and the
part a parameter hold discards) so the comparison can be stated from the run's own counters.
