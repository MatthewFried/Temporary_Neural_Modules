# v47 results: coordinated reversal on the v46 wave-25 checkpoints

Status: exploratory reanalysis of existing checkpoints. Nothing was retrained. The checkpoints are the v46 panel:
12 fresh draws (325 to 336), 2 optimizer seeds averaged within each draw, intervals over draws. All 192 jobs
were analysed with no exclusions. In all 96 removal jobs, the grid's four corners reproduced the existing models
bitwise (every test logit). Test error is in percent; the task has two classes, so chance is about 50.

The path summaries below are worst points only. v47 also reported a mean along each path. That mean is not a
comparison of removal quality: it weights points by schedule (5 points on the diagonal, 9 on each sequential path)
and counts identical functions repeatedly wherever the rewind does nothing (C and D). v48 drops it and adds
endpoint-relative barriers (CHANGES_v48.md).

## 1. Direct coordinated extraction works; the tested gradual paths do not

B (shortcut column frozen during expansion), the first layer fixed throughout. alpha scales the additions' gates;
beta places layers 2..K at f0 + beta (trained - f0).

| alpha \ beta | 1 | .75 | .5 | .25 | 0 |
|---|---|---|---|---|---|
| 1 | 22.14 | 47.11 | 47.95 | 49.17 | 48.78 |
| .75 | 22.51 | 46.87 | 47.93 | 49.02 | 48.27 |
| .5 | 23.50 | 46.31 | 47.75 | 48.71 | 47.28 |
| .25 | 26.76 | 44.10 | 45.59 | 47.69 | 43.74 |
| 0 | 48.48 | 45.04 | 40.75 | 33.49 | 19.62 |

- The two working endpoints are the expanded network (22.14) and the extraction (19.62).
- The diagonal's interior points are near chance (46.87, 47.75, 47.69), and so are most sampled mixtures.
- The worst point on each run's path, averaged over runs: delete then rewind 49.30, diagonal 52.21, rewind then
  delete 54.57.
- On worst error, the diagonal is not distinguishable from delete-first: −2.90 [−9.16, 3.35], 6/12 draws.
- On worst cross-entropy, delete-first is lower than the diagonal (−58.6 nats [−103.1, −14.0]).
- A behaves the same way.
- Two edges are benign:
  - with layers 2..K trained, the gates can be halved at little cost (23.50);
  - with the additions deleted, each step of the rewind lowers error.

Conclusion: both changes can be undone together in one discrete edit, but not gradually at the same rate along a
straight line. This does not show an unavoidable barrier, disconnected solutions or irreversibility. Straight
interpolations between good networks are known to cross bad regions (mode-connectivity work). Only straight lines
at steps of 0.25 were sampled.

The cross-entropies at the interior points are large (tens to hundreds of nats). v47 computed them stably from
logits (cross_entropy in float64). v48 re-derives them per example and reports margin and logit-size quantiles to
show whether they are confidently wrong predictions.

## 2. Time course: dependence forms early, the retained change forms slowly

2x2 at every saved checkpoint (additions present/deleted x layers 2..K trained/restored), first layer kept.

| Updates after f0 | 250 | 500 | 1000 | 2000 | 3000 | 4000 |
|---|---|---|---|---|---|---|
| B: delete only | 42.47 | 47.77 | 48.49 | 47.02 | 47.80 | 48.48 |
| B: extraction (delete + restore) | 24.29 | 23.40 | 22.21 | 20.79 | 20.07 | 19.62 |
| A: extraction | 24.42 | 24.29 | 24.21 | 24.15 | 24.24 | 24.36 |
| B interaction | 28.9 | 38.0 | 40.2 | 42.8 | 52.9 | 55.5 |
| A interaction | 30.7 | 37.8 | 41.0 | 42.7 | 46.5 | 50.1 |

- f0 is 24.74.
- In both A and B, the dependence on the additions is large by 250 updates (interaction intervals exclude 0
  at every age after insertion, 12/12 draws).
- Only B's extraction improves. From 2000 to 4000 updates it gains 1.16 points [0.74, 1.59], 12/12 draws.
- B's extraction beats its own native network at every age after insertion (+0.66 at 250, +2.52 at 4000).
- The gain after the second insertion (2000 updates) is not attributable to the insertion: more training and
  more capacity changed together. A matched fork (next insertion versus continuing the existing additions) is
  needed for that claim.

## 3. C and D (layers 2..K held at f0)

The rewind is a no-op and is flagged. Deleting the additions with the trained first layer gets worse as training
goes on: C goes from 24.38 at 250 updates to 34.81 at 4000, and D from 24.67 to 34.73. With the later layers
held, the first layer comes to depend on the additions.

## What this does not answer

It does not explain why the retained first layer improves prediction:
- it may learn new directions or reweight existing features;
- the gain may come from the larger training budget (expansion used about 1.94 times the post-f0 MACs);
- repeated insertion may or may not add anything beyond continued training.

The gain-only, redrawn-assignment, compute-matched and insertion-versus-continuation controls address these.
