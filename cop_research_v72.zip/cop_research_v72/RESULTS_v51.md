# v51 results: what removing the additions requires (wave-25 checkpoints)

Status: exploratory reanalysis of the v46 checkpoints, not fresh confirmation. 96 states (A, B, C, D; 12 draws x 2
seeds), no failures or exclusions. Seeds are averaged within a draw; intervals are over the 12 draws. Errors are on
the shortcut-independent test set, in percent. The CPU and CUDA analyses of the miniature agreed on every saved
decision.

## 1. The additions' final contribution is almost affine, and a fitted change to one layer removes them

| At the expansion end | A (free) | B (shortcut column frozen) |
|---|---|---|
| Expanded network | 24.15 | 22.14 |
| Additions deleted | 49.90 | 48.48 |
| Output replaced by its training mean | 51.17 | 50.66 |
| Output replaced by its affine fit, folded into L3 | 24.43 | 22.76 |
| Additions deleted and L2..L5 rewound (extraction) | 24.36 | 19.62 |

- The affine fold costs B 0.62 points [0.10, 1.14], A 0.28, C 0.27 and D −0.04.
- The affine fit explains 99.7 to 99.9% of the output's centered variation on every held-out partition.
- The output is large: about 20 times the size of the activations it reads in A and B, and about 70 times in C
  and D. The fitted map's largest singular value is about 200 in A and B and about 100 in C and D.
- The folded network disagrees with the expanded one on about 3% of test examples (1 to 1.5% on source validation,
  4 to 5% under shift). This is close performance, not the same function.
- Scaling the nonlinear remainder from 1 to 0 with the backbone fixed shows no barrier at the sampled points.

So deletion is catastrophic only when the receiving layer is left unchanged. The additions are not needed as
nonlinear architecture at these endpoints. Whether they were needed during learning is not addressed by this.

## 2. The straight path from the folded network to the extraction is still bad

For B: 22.76, 45.04, 47.13, 45.70, 19.62 at 0, 25, 50, 75 and 100% of the rewind.

- The combined sampled barrier is 25.78 points [21.63, 29.93], 12/12 draws. A is the same.
- In C and D only L3 differs from f0, and there is no barrier: error holds through 75% and jumps to the
  extraction's 34.8 at the last step.

Two compact networks that share a first layer both work, and the sampled straight line between their later layers
does not. This is not evidence of disconnected solutions: unit permutations, rescalings or other paths are untested
here (v52 tests alignment).

## 3. The correction spans layers but is low-rank within them

B, additions deleted:

| Correction | Test error |
|---|---|
| none | 48.48 |
| head only | 46.11 |
| rank 2 per layer | 26.41 |
| rank 4 per layer | 22.31 |
| rank 8 per layer | 20.27 |
| full rewind | 19.62 |

- Rank 8 is within 0.65 points of the full rewind, at about 27% of its storage.
- It is not sparse: all 12,610 later-layer entries change.
- With the head left trained, rank 8 gives 34.79, so the layers must be corrected together.
- Layer 2's own change has twice f0's norm, and 81% of it is rank one.
- No per-addition map exists at whole-layer resolution: deleting any single addition gives 37 to 57%.
- Under the primary rule (native reference, source validation) B's full deletion is removable in 5 of 24 runs. It
  is 22 of 24 when selected on `val_indep`.

## 4. Training diagnostics: the residual-error explanation is withdrawn

| Model | Training error | Training loss | Median margin |
|---|---|---|---|
| f0 | 0.92 | 0.034 | 7.8 |
| A expanded | 4.43 | 0.749 | 33.8 |
| B expanded | 6.21 | 0.677 | 20.6 |

- The expanded networks fit the training set worse than f0. B still misclassifies 80.6% of the examples f0 got
  wrong, and loses some that f0 had right.
- So "extra capacity fits f0's remaining training errors" is not supported at these endpoints. Transient behaviour
  earlier in training is not excluded by endpoint data (v52 adds the time course).
- At f0, a gain on the causal input block lowers total training loss to first order in 12/12 draws
  (d loss / d log-gain = −0.012). Subgroups pull in opposite directions:
  - majority −0.029, rare +0.017;
  - shortcut sign disagrees −0.023, agrees +0.011.
- So "compact training has no reason to increase the causal scale" was wrong locally, and the compact gain-only
  arm is a substantive control.
- First layer: the causal block's norm grows 1.62x (A), 1.71x (B), 2.02x (C) and 2.09x (D). Under 10% of that
  change is pure scaling in A and B. A's shortcut column grows 2.04x; B's is frozen.
- These trajectories train with routed gradients (each addition receives gradient from a fixed part of the
  examples). They are not ordinary training with more parameters; capacity and routing are not separated here.

## 5. Transfer

- A's additions with A's later layers on B's first layer give 19.22: better than B's own expanded network by 2.92
  [1.00, 4.84], and not distinguishable from B's extraction (0.40 [−1.63, 2.43]).
- Mismatched additions and later layers give roughly chance.
- This is supporting evidence of co-adapted packages between histories that share f0. A matched package replaces
  most of the recipient.

## Open after v51

- Why training with the additions produced this state.
- Whether the nonlinearity mattered during learning.
- Whether the path result survives alignment.
- Whether the compact gain arises from a specific mechanism or from norm growth with one column frozen. The second
  is my reading and is untested.
