# v52 results: the gain direction, the expansion's time course, aligned paths (wave-25 checkpoints)

Status: exploratory reanalysis of the v46 checkpoints, not fresh confirmation. 96 states (A, B, C, D; 12 draws x 2
seeds), 24 groups, no failures or exclusions. Seeds are averaged within a draw; intervals are over the 12 draws.
Errors are on the shortcut-independent test set, in percent. The CPU and CUDA analyses of the miniature agreed on
every saved decision. Six small gain-derivative mismatches are listed in the coverage file and do not fail the
run; the mean causal derivative agrees (−0.01187 autograd, −0.01177 finite difference).

## 1. Along the causal gain, the training loss has its minimum next to f0

f0 with its causal input block scaled, nothing else changed:

| Gain | 1.0 | 1.05 | 1.25 | 1.5 | 1.75 | 2 | 3 | 4 |
|---|---|---|---|---|---|---|---|---|
| Training loss | 0.0341 | 0.0340 | 0.0401 | 0.0571 | 0.0799 | 0.106 | 0.227 | 0.362 |
| Test error | 24.74 | 24.02 | 21.62 | 19.34 | 17.62 | 16.33 | 13.40 | 12.10 |

- The lowest training loss on the grid is at gain 1.05 in 17 groups and at 1.0 in 7.
- Test error falls at every step of the grid. Source validation error stays between 4.9 and 5.2 up to gain 2 and is
  6.25 at gain 4.
- The loss increase sits in two overlapping subgroups. From gain 1 to 2 the rare group's contribution to the mean
  loss goes from 0.012 to 0.073, and that of the examples whose shortcut agrees with the label from 0.018 to 0.087.
  The majority group's goes from 0.022 to 0.033 and the shortcut-disagreeing examples' from 0.017 to 0.019.
- On the shortcut column, the lowest training loss is at gain 1.0 in 17 groups (1.05 in 5); test error is lower
  below 1 (23.29 at 0.9) and higher above (35.37 at 2).

This table is the loss curve a single trained causal gain would descend with everything else held. Its minimum is
between 1.0 and 1.05, where test error is about 24.0. The scale that helps the test set (1.6 to 2, what the
expansions reached) costs two to three times f0's training loss. The negative derivative reported in v51 is real
and leads almost nowhere under the training loss.

## 2. Time course

Updates after f0: 250, 500, 1000, 1500, 2000 (second insertion), 2250, 2500, 3000, 3500, 4000.

| | 250 | 500 | 1000 | 2000 | 3000 | 4000 |
|---|---|---|---|---|---|---|
| A: map's largest singular value | 1.7 | 4.8 | 15.6 | 61.5 | 117.6 | 206.6 |
| B: causal norm ratio | 1.02 | 1.07 | 1.18 | 1.38 | 1.55 | 1.71 |
| B: extraction | 24.29 | 23.40 | 22.21 | 20.79 | 20.07 | 19.62 |

- **Affine from the start.** The affine fit explains 98 to 99% of the additions' output on the test set at 250
  updates and 99.6% or more afterwards. The nonlinear share is at most 0.2% in A and B (0.9% at 250 in C and D).
- **The gain grows steadily.** The map's largest singular value rises at every checkpoint (B reaches 232; C and D
  about 99). The output reaches 19 to 21 times the activations it joins in A and B, and 69 times in C and D. There
  is no jump at the second insertion.
- **Training gets worse over the run.** Training loss goes from 0.03 (f0) to 0.05 at 250 updates, 0.10 to 0.12 at
  500, 0.3 to 0.4 at 1500 to 2000, then varies between 0.4 and 1.2 in A and B and is about 0.7 at the end in all
  four. It is not monotone from checkpoint to checkpoint. Training error goes from 0.9% to 1.5 to 1.8% at 250 and
  is 4.4 to 6.2% at the end. The median margin grows from 7.8 to between 20 and 41.
- **Deletion fails early.** In A and B it gives 43.8 and 42.5 at 250 updates and between 46 and 50 from 500 on.
- **The affine fold holds at every age**, within 0.62 point of the expanded network.
- **Low-rank folds fail in A and B.** Rank 1 gives 26.5 at 250 updates, 33 at 500, 43 to 47 at 1000 and 53 to 54
  at the end. Rank 2 gives 25 at 500 and 45 to 47 at the end. In D rank 2 works (24.99) and in C nearly (29.12).
  One direction carries 80 to 90% of the map's energy in A and B (about 60% in C and D), but the map is not that
  one direction.
- **B's extraction tracks the causal norm.** Both move at every checkpoint (table above). In A the shortcut
  column grows faster than the causal block (2.04 against 1.62) and the extraction stays between 24.2 and 24.4.
- **Later layers.** Layer 2's change reaches 2.06 (A) and 2.24 (B) times f0's norm with about 80% of it in one
  direction; layer 3's is about 0.44.
- **The top direction is not a classifier in A and B** (39 to 43% error as a one-threshold readout on the test
  set). In C and D it tracks the decision early (correlation 0.84 to 0.88 with the expanded network's margin, 9 to
  13% validation error at 250 to 500 updates) and less later.
- **C and D.** Their deletion equals their extraction and worsens steadily, from 24.4 to 34.8.

## 3. The folded network's path to the extraction after alignment

Sampled barrier in test error (points; the worst of five points minus the worse end), with 95% intervals:

| | None | Rescale | Permute | Permute + rescale |
|---|---|---|---|---|
| A | 24.4 [20.7, 28.1] | 23.2 [18.1, 28.2] | 13.8 [10.3, 17.3] | 18.5 [14.7, 22.3] |
| B | 25.2 [21.1, 29.3] | 23.7 [19.9, 27.4] | 17.2 [11.8, 22.5] | 20.7 [17.2, 24.2] |
| C | 0.1 | 13.1 | 10.1 | 6.6 |
| D | 0.0 | 12.0 | 11.9 | 6.6 |

- In A and B the barrier is present under every alignment in 12 of 12 draws. Permutation roughly halves it.
- The alignment is weak. Matched units correlate at about 0.2 in the later layers (0.03 before matching; 0.45 to
  0.49 at layer 2), about 61 of 64 units move in layers 3 and 4, and the scale factors span 0.001 to over 300. The
  folded network and the extraction do not share unit-level features in their later layers.
- So these alignments do not connect the two networks. This rules out a simple relabelling or rescaling of units.
  Other alignments and curved paths remain untested.
- In C and D only one layer differs and there is no barrier without alignment (error holds, then jumps at the
  last step to the extraction's 34.8). Alignment only adds one.

## What follows

- The expanded networks do not fit the training set better than f0 at any saved time. They move to a state the
  training loss penalises about twentyfold, and during that movement the first layer's causal columns grow.
- A single causal gain cannot be learned from the training loss: the scan is that experiment's loss curve.
- Not addressed by these checkpoints: what drives the drift. Routed gradients (each addition sees a fixed part of
  the examples), the nonlinearity (at every saved time the additions' outputs are fitted by an affine map of their
  input on the sampled activations; that does not show the nonlinearity had no effect during training), the
  learning rate and the number of updates are confounded in wave 25. v53 varies them one at a time
  (CHANGES_v53.md).
- A caution on one reading (reworded in v54; the v53 text went too far). The optimizer is AdamW. If a parameter's
  whole gradient history is multiplied by one constant, its steps stay nearly the same. That is all the
  invariance says. It does not make the gradient's size irrelevant here: the scale changes while training runs,
  the two moment estimates remember different lengths of history, and how much a step of a given size changes
  the function depends on the scale of the weights around it. So "the gain amplifies the step size" does not
  follow, and "only the gradient's direction changes" does not follow either. These checkpoints do not decide
  between them.
