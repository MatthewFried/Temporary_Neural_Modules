# Results: wave 26 (v53 panel) and the component analysis of wave 25 (v55)

Sources: `cop_v53_panel_reports.zip` (600 jobs complete, every step passed) and `cop_v55_change_reports_w25.zip`
(24 f0, 23,808 probes fitted and saved, every step passed). Test error in %, 12 data draws, two optimizer seeds
averaged within a draw, 95% t intervals over draws. Wave 26 uses draws 337 to 348, unused before. The wave-25
component analysis is a reanalysis of the v46 checkpoints, not a new replication.

## Wave 26: the extraction result on new draws

"Extraction" is the trained first layer placed in the original f0, nothing else changed. f0 = 23.72.

| First layer from | Test error | Gain over f0 |
|---|---|---|
| B routed ReLU (repeats wave 25's B arm) | 18.01 | 5.71 (4.61 to 6.80) |
| B routed affine | 18.13 | 5.60 (4.48 to 6.71) |
| B all-examples ReLU | 23.34 | 0.38 (0.27 to 0.50) |
| B all-examples affine | 22.43 | 1.29 (1.07 to 1.50) |
| B routed ReLU, 0.3x learning rate | 22.54 | 1.18 (0.56 to 1.79) |
| compact B at 2U | 23.25 | 0.47 (0.30 to 0.65) |
| A routed ReLU | 23.36 | 0.36 (-0.65 to 1.38) |

- Primary contrasts (named before the panel ran): B routed ReLU against f0, 5.71; against compact B at 2U, 5.23
  (4.21 to 6.25). Both positive in all 12 draws.
- Against compact B at 4U (about the expansion's compute): 5.17 (4.15 to 6.19).
- Affine additions reproduce the size of the effect: nonlinear additions are unnecessary for this outcome.
- Without routing the large effect is absent. The all-examples arms also differ in which gradients reach the
  additions, so this does not isolate routing from the amount of gradient.
- The first layer barely moves without routing. Causal-block norm ratio to f0: 1.72 (B routed ReLU), 1.68 (B
  routed affine), 1.15 (0.3x learning rate), 1.02 (both all-examples arms).

## Wave 26: routed training makes the training loss worse

Training cross-entropy of the actual network. f0: 0.031.

| Arm | at 2U |
|---|---|
| A routed ReLU | 0.394 |
| B routed ReLU | 0.643 |
| A routed affine | 5.04 |
| B routed affine | 2.43 |
| every all-examples arm | 0.000 |
| routed ReLU at 0.3x learning rate (A / B) | 0.127 / 0.174 |

The routed update is not the gradient of the displayed loss: the masks keep the forward value and block backward
paths. "The additions fit what is left and so teach the backbone" is not supported as stated. v56's
`routing_updates.py` measures how the update taken relates to the ordinary and the routed gradient.

## Wave 25: what reproduces B's extraction gain

f0 = 24.74. B's first layer in f0: 19.62 (5.12 better than f0, 4.55 to 5.69; 4.66 better than compact B).

| First layer placed in f0 | Test error |
|---|---|
| f0 at B's block norms | 18.49 |
| B at f0's block norms | 24.73 |
| f0 at B's whole-layer norm | 24.79 |
| B at f0's whole-layer norm | 19.83 |
| B's weights with f0's bias | 19.70 |
| f0's weights with B's bias | 24.81 |
| f0 with the shortcut column x 0.5 / x 0.75 | 17.12 / 21.03 |
| f0 with the shortcut column removed | 12.60 |

- B's extraction benefit is largely reproduced by block scaling: f0 at B's block norms is 1.13 better than B
  (0.65 to 1.61), and B at f0's block norms equals f0 (difference -0.01, inside the declared margin of 0.01).
- The block norm ratios are 1.71 (causal), 1.55 (other) and 1.00 (shortcut, held): the shortcut is down-weighted
  relative to the rest by about 0.6.
- Equal error rate is not equal function: f0 at B's block norms and B disagree on 12.2% of test examples.
- With knowledge of the shortcut input, removing f0's shortcut column gives 12.60, which is 7.03 better than B's
  extraction (5.98 to 8.07). That bears on whether an expansion is needed for this accuracy. It does not bear on
  what expanded training changes in the layer.

## Wave 25: A contains a useful change that its change of scale hides

A's first layer in f0: 24.36 (no gain over f0).

| First layer placed in f0 | Test error | against f0 |
|---|---|---|
| f0 at A's block norms | 28.00 | 3.25 worse (1.76 to 4.75) |
| A at f0's block norms | 21.91 | 2.83 better (1.61 to 4.05), 11 of 12 draws |
| A at f0's per-unit block norms | 21.68 | 3.07 better (1.89 to 4.24), 12 of 12 draws |

A's shortcut column grew 2.04x against 1.62x for the causal block. The norm controls keep A's bias and do not
isolate weight directions; v56 adds the f0-bias versions. A and B need separate explanations.

## Wave 25: probes

The same linear probe on every network, fitted on val_indep (target-distribution labels: a measurement, not a
method), standardised features, test error. Penalty 0.01; the pattern is the same at 0.0001.

First-layer activations, label:

| Network | Probe error |
|---|---|
| f0 | 9.34 |
| compact A / compact B | 9.04 / 9.07 |
| A / B | 7.78 / 7.73 |
| f0 at A's / B's block norms | 9.16 / 8.99 |
| A / B at f0's block norms | 7.51 / 7.62 |
| f0 with the shortcut column removed | 8.69 |

- A and B both improve on the matched compact control: A by 1.26 (0.92 to 1.59), B by 1.34 (1.01 to 1.68), all
  12 draws.
- Block scaling of f0 does not reproduce it (1.38 and 1.26 worse than the state, all 12 draws).

Activations the output layer reads, label, by context:

| Network | extracted (f0's later layers) | native (its own network) |
|---|---|---|
| f0 | 15.06 | 15.06 |
| A | 13.91 | 20.47 |
| B | 12.94 | 18.69 |
| compact A / B | 14.61 / 14.67 | 13.91 / 13.97 |

In their own networks the expansions' last hidden layer supports this probe worse than f0's: A by 5.41 (3.50 to
7.32), B by 3.62 (2.16 to 5.09), all 12 draws. The early layer becomes easier to read for the target task and the
expanded network's later processing does not keep that in equally accessible form.

Limits: this is linear accessibility, not information. It does not show later layers destroy anything; they may
encode it differently. A linear probe on the raw input reaches 5.14, so nothing here was absent from the inputs.

## What is and is not supported

- Supported: the extraction effect of the held-shortcut routed arm replicates on new draws, does not need
  nonlinear additions, and is absent without routing or at a third of the learning rate.
- Supported for wave 25, awaiting wave 26: B's extraction benefit is largely block scaling; A holds a useful
  change exposed by restoring norms; first-layer decoding improves in both arms beyond compact continuation and
  beyond block scaling; last-layer decoding in the expanded network gets worse.
- Not supported: "expansion creates better features" as a general statement; "the useful change is just strength".
- Open: why routed updates raise the training loss and move the first layer so far, and where along the network
  the early improvement stops being accessible.
