# Results: the v56 analyses (component change, layer course, update diagnostics) on waves 25 and 26

Source: `cop_v56_reports_w25_26.zip` (every step passed; 24 f0 per wave; no failed or non-converged probe).
Test error in %, 12 data draws, seeds averaged within a draw, 95% t intervals over draws. Wave 26 uses new draws
(337 to 348); wave 25 is the v46 panel reanalysed. Figures below were recomputed from the per-draw tables. The
reviewer's figures (ChatGPT, 11 November) agree with them.

## 1. A useful change in A's first layer survives restoring its norms and its bias

A (nothing held). Its first layer placed in f0 at f0's norm per unit and input block, with f0's bias
(`state_at_f0_block_row_norms_f0_bias`), f0's later layers unchanged:

| Cohort | f0 | edited extraction | improvement |
|---|---|---|---|
| wave 25 | 24.74 | 22.03 | 2.72 (1.41 to 4.02) |
| wave 26 | 23.72 | 20.94 | 2.78 (1.85 to 3.71) |

On wave 26 the same edit of the compute-matched compact control (compact A at 4U) is 2.61 worse (1.67 to 3.54, 11 of
12 draws). The edit keeps the learned weight directions and removes the measured changes of block magnitude per unit
and of bias. The benefit is therefore not explained by those changes alone. Constructing the edit uses the known
input blocks: it is a diagnostic, not an extraction method.

The cost: on the source distribution's validation set the edited extraction is worse than f0 (6.76 against 4.96);
the rare group does not improve (48.5 against 48.8).

B (shortcut column held) behaves differently: the same edit gives 23.65, essentially f0 (23.72). B's large direct
extraction benefit (18.01) depends on its learned relative scales: f0 at B's block norms gives 17.72.

## 2. The size of that change depends on routing, not on nonlinear additions

Wave 26, the same edited extraction against the equally edited compact A at 4U:

| expansion | advantage |
|---|---|
| routed ReLU | 2.61 (1.67 to 3.54) |
| routed affine | 2.30 (1.54 to 3.05) |
| all-examples ReLU | 0.03 (-0.07 to 0.13) |
| all-examples affine | 0.82 (0.64 to 1.01) |

Routed expansion produces a much larger change in the original first layer than ordinary-gradient expansion here,
and the change does not need nonlinear additions. Ordinary-gradient affine expansion gives a smaller benefit, so
"routing is needed for any benefit" would be too strong.

## 3. Probes: the early layers improve, the layers after the merge get worse, and the penalty matters

Label probe, fitted on val_indep, standardised, in each network's own layers (wave 26, at 2U):

| layer | f0 | A routed ReLU | B routed ReLU |
|---|---|---|---|
| 1 | 9.77 / 9.48 | 8.20 / 8.04 | 8.01 / 7.71 |
| 2, before the merge | 11.83 / 11.63 | 8.77 / 11.42 | 8.40 / 11.03 |
| 2, after the merge | | 12.20 / 18.82 | 11.24 / 15.68 |
| 3 | 13.44 / 13.25 | 17.04 / 20.19 | 14.90 / 17.17 |
| 4 | 14.49 / 14.53 | 19.04 / 20.49 | 16.24 / 17.69 |

(penalty 1e-4 / 1e-2.) The worsening at the merge holds at both penalties (A: 3.43, 2.51 to 4.35, at 1e-4; 7.40,
5.75 to 9.05, at 1e-2; every draw). Its size does not: at layer 2 before the merge the two penalties disagree by
2.7 points. Per-coordinate standardising does not remove correlations or general linear distortions, so a fitted
probe can do worse on features that hold the same information. v58's `merge_geometry.py` tests this directly.

Over training (A routed ReLU, penalty 1e-2), layer 1 improves steadily (9.48 to 8.04) while the last hidden layer,
slightly better than f0's at 500 updates, gets worse from about 1000 updates on (20.49 at 2U).

Not shown by these probes: that information is lost. They measure linear accessibility under one fitting procedure.

## 4. The bias carries much of the first-layer probe improvement

A routed ReLU, first-layer label probe (penalty 1e-4): f0 9.77; the learned layer 8.20; at f0's norms per unit and
block with f0's bias 9.15. What remains, 0.62 (0.31 to 0.93), survives the equally edited compact control, by less.
Restoring the bias alone costs about 1.1 points at penalty 1e-2, in every draw. The probe improvement is therefore
not all in new weight directions. Being easy for a newly fitted probe to read and being useful to f0's own later
layers are different measurements: the normalised layer helps f0's downstream network by 2.8 points while its probe
advantage is 0.6.

## 5. Routing changes the learning signal before the merge

At 2U the routed and the ordinary full-batch gradients of the first layer have cosine about 0.36 (A and B). After
the merge they match exactly, and masks of ones reproduce the ordinary gradient, as intended: routing changes credit
assignment below the merge and leaves forward values alone. The last update follows the routed gradient (cosine 0.31)
more than the ordinary one (0.06).

What the step diagnostics are: the update is the historical last step before each saved state, recovered exactly
from the optimizer state; the gradients are full-batch diagnostics at the parameters before that step; the loss
change is that one step's effect on the full-batch training loss. Single steps at nine saved states: the predicted
and measured changes often differ, so they do not establish that the routed updates drive the ordinary loss up.

## What this supports

- A replicated finding: expansion leaves a useful change in the original first layer that survives restoring both
  its norms and its bias (A), on new draws, beyond the equally edited compute-matched control.
- Its size depends on routing and not on nonlinear additions.
- A and B differ: A's useful change is hidden by its scale changes; B's benefit is mostly its relative scales.
- Early and late layers move in opposite directions under the probe; whether that is information or geometry is
  open (v58).
