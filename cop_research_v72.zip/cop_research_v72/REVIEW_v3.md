# Independent review of the v3 extension

A separate review pass read the v3 diff before packaging. Each finding is listed here with its fix. Tests are in `tests/test_strengthening_v3.py`.

| # | Finding | Fix |
|---|---|---|
| 1 | C1/C2 budgets and post-f0 compute charged the whole trajectory when a child starts from `snap_<u>` (X2 short, M_B) | `chain_work_dir` charges the trajectory's trainer counters up to the snapshot (`test_snapshot_child_is_charged_...`) |
| 2 | F03 equal-cost panel matched per insertion: chunked added n_chunks x the budget, and the diamond bridge was unmatched | Matching is per round (chunks share the round budget; the diamond's round 1 splits it between branch and bridge). All F03 variants use three rounds. A MACs panel was added |
| 3 | Removal orders were not at matched cost: every phase got the full post budget, and ancestor_first had empty later phases | The total budget is split over the phases. Descendants scheduled after their ancestor are dropped, and a read branch moves to its reader's phase (`test_removal_order_...`) |
| 4 | Budgets included the F07e repaired clone; C2 omitted teacher MACs, pretraining MACs and probe MACs | `diagnostic:*` phases are excluded. C2 includes teacher forward MACs. Pretraining and trigger probes are charged. CoP cycles/alternatives (local fits without MACs) get no C2 |
| 5 | Under T0, the task term of C5 (and of C4 with alpha < 1) used the noisy labels | That term now follows `train.target` (teacher_star) |
| 6 | BN recalibration in transplants also updated the upstream BN statistics | Only the selected BN modules run in train mode (`test_bn_recalibration_...`) |
| 7 | The C6 `branch_merge` control for F03b is plain deletion, not an exact fold | Removed and declared inapplicable |
| 8 | F08e calibration access equalled train access in the main cell and used labels | Uses 256 retained inputs with a label-free target (enforced by validation). A train-plus-teacher arm was added for comparison |
| 9 | The M_A random helper assignment was identical across replications | Wave-7 histories set `seeds.insertion` per replication. Analysis pairs on data/teacher/optimizer seed |
| 10 | Classification disagreement key mismatch in the endpoint table | Fixed |
| 11 | Teacher forwards were undercounted after a resume | Counted from the trainer's step counter |
| 12 | `post_f0_macs_incl_teacher` omitted teacher forward MACs | Included |
| 13 | The endpoint table omitted retained-adapter bits (mechanism H) | `bits_per_example_with_adapters` added |

Plausible concerns, also fixed:

* Held-out teacher-imitation error was empty for regression. It is now computed on the clean val/test targets.
* A diverged endpoint made G NaN. Non-finite endpoints are now listed separately (`s_nonfinite_endpoints.csv`).
* The `peg`/`pegs` arms of mechanism H reset optimizer state. Frozen tensors now stay in the optimizer with no gradient (`Segment.trainable`).

Design questions, resolved in wave 7 or recorded in DEVIATIONS 72-80:

* F04b now trains the implant before freezing it.
* The F04e snapshots now fall after the last release.
* A weight-decay panel (none / uniform / composite) was added on `node_factorization`.
* A learning-rate sweep (C1 at 0.3x and 3x) was added to the full control set.
* The M_F durability contrast gets no C0.
* The C7 perturbation size, F05d cycle > 0, the F10e input access and the freeze policy of cycle contractions are recorded as deviations.

Found by the smoke run before review, and also fixed:

* Gating stacked series implants left the lower implant alive. This bug was already in v2 (DEVIATIONS 70).
* Conv fold after pruning failed (DEVIATIONS 71).
* Diamond removal orders deleted a branch before the bridge that reads it.
* CoP refused query-before-peg (F09e). It now places pegs as in an ordinary chain and reports `query_reaches_encoder`.
