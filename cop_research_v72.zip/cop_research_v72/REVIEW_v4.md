# Independent review of the v4 draft

A separate agent that had not written the fixes reviewed the v4 draft against the v3 audit (V3-01 ... V3-12), AUDIT_RESPONSE_v3.md and the v3-to-v4 diff, ran targeted tests and wrote its own probes. Findings and what was done:

| # | finding | severity | resolution | test |
|---|---|---|---|---|
| 1 | CoP chains, cycles and `direct_small` exports never recorded training divergence; `LocalOpt` had no numerical check | bug | run-context divergence flag, carried in checkpoints and inherited by `record_endpoint`; `LocalOpt` raises `NumericalDivergence` | `test_cop_chain_divergence_reaches_the_endpoint_and_work_counts_actual_updates`, `test_local_loop_divergence_fails_the_job_instead_of_completing` |
| 2 | work records (chain, cycles, dissipation) used requested updates after a divergence | bug (minor) | `Trainer.run` returns the actual segment updates; callers count those | `test_dissipation_work_counts_actual_updates_after_divergence`, and the CoP test above |
| 3 | sharing classes as Merkle-key tuples collide for crossed ties between symmetric nodes | doc-claim mismatch | canonical serialisation with sharing as canonical positions | `test_crossed_ties_between_symmetric_nodes_change_identity` |
| 4 | figures 2, 4, 6 (bits panel) and 7 mixed tasks on one axis | minor | faceted by task; invalid endpoints left out and counted | figures regenerated |
| 5 | the route-repair diagnostic checkpoint lacked the erasure fill values | minor | fill values saved in the checkpoint | n/a |
| 6 | the constant-schedule guard missed `warmup` in the treated config | minor (latent) | guard reads the treated config, the overrides and the control config | `test_controls_refuse_a_non_constant_schedule` |
| 7 | CoP chains logged two models under stage `endpoint` | minor | pre-export stage renamed `chain_trained` | suite |
| 8 | figure 1 compared M1 / M2 (budgets include f0) against the treated chain without f0 | minor | `treated_cost_matched` adds f0's training cost for those controls | figure regenerated |

The reviewer found the rest correct: `record_endpoint` for baseline, trajectory, dissipation, repair and continue; the trainer's numerical boundary; `backward_aware_macs`; the trainable-state record; `compact_gain` pairing, duplicates, contract fields, estimands and denominators; `_PruneRegrow`; the alignment and later-query device policy; the matched CoP controls; and the factor cells. CUDA paths could not be checked (no GPU).
