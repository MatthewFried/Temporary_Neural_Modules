# Independent review of the v5 draft

A separate agent that had not written the v5 changes reviewed them against the review handoff (`CoP_v5_Review_and_Claude_Handoff`), its independent checks and the v4-to-v5 diff. It ran its own probes on CPU. Findings and what was done:

| # | finding | severity | resolution | test |
|---|---|---|---|---|
| 1 | gain retention was silently missing (row still `ok`) for every contraction that starts from a snapshot: the parent logs no metrics at `snap_<u>`, so R_expanded was None (X2 short arm, M_B repairs) | medium | R_expanded is read from the job's own pre-contraction diagnostics (the model it actually started from), with the parent's stage metrics as fallback; a missing reference gives `undefined: no expanded-model risk (...)` | `test_expanded_reference_exists_for_snapshot_starts_and_matches_the_parent_at_final`, `test_gain_retention_without_expanded_risk_is_explicitly_undefined` |
| 2 | the incoming-table certificate never applied in the wave-7 locality block: 8 x 2 bits = 65,536 incoming codes exceeded the 4,096 cap and no observed set was passed | medium | full table up to 65,536 codes; above that the calibration codes are passed and the result is labelled coverage-conditional | `test_locality_certificate_covers_the_full_table_of_the_wave7_peg_and_scopes_are_nested` |
| 3 | capacity was 2^ceil(log2 alphabet) for VQ / multi pegs (a looser bound than the exact model), and all coordinates for repetition pegs | low (no wave-7 cell affected) | the optimum uses the exact alphabet size; repetition pegs are labelled as an upper bound | `test_alphabets_that_are_not_a_power_of_two_get_their_exact_optimum` |
| 4 | the virtual affine map was built in float32 before the cast, losing precision in float64 models (up to 1.6e-7) | low | built and copied in the model's dtype | identity / fold tests at float64 |
| 5 | duplicate checkpoint fractions could make the reported fractions and update counts differ in length | low (reporting) | realised fractions reported per checkpoint, requested ones separately | locality test above |
| 6 | scope 3 in pegged arms left the far halves of the incident pegs frozen, so scope 3 covered a different stretch than in the no-interface arm | design | scope 3 is the contiguous region from pearl p-1 to pearl p+1 in every arm | nesting checked in the locality test |
| 7 | the transplant grid compares f0 with the post-cycle model, which trained longer | design | added arm `grid_vs_C1`: model A is f0 continued for the cycle's measured updates | smoke run |
| 8 | sibling jobs of one parent share identical diagnostics in the predictor screen | design | `n_distinct_predictor` reported beside n; the screen stays exploratory | `test_predictor_screen_uses_a_discovery_replication_and_held_out_replications` |

Not changed, recorded as limitations: the locality screen is serial only (no branched topology), and the counterfactual / invariance probes for transplants are not implemented (AUDIT_RESPONSE_v4.md, QUESTIONS 28).

The reviewer found the rest correct:

* the virtual affine clone wiring for series, branch and group implants (clone output equals a value-patch replacement);
* the JVP residual (agrees with a central finite difference to about 1e-10);
* the non-mutating guarantees and the train / val split of the diagnostics;
* the eta rules;
* Shapley, Shapley interaction, the min-max path and the minimum batch, checked against Moebius identities and brute force on 200 random games;
* incomplete-game rejection and `same_graph_as` handling;
* `retention_optimum` against brute force for bit and parity tasks, n = 2 to 4;
* gate-aware bypass detection, bridge-phase applicability and the static plus empirical query-blind checks;
* the locality schedule, scope-2 handling, censoring and diverged-fork exclusion;
* the transplant contrast signs and equal adapter budgets;
* the resume equality of the v5 paths.

CUDA paths could not be checked (no GPU).

## After delivery (archive v6)

The first run on the lab GPU (RTX A4500) failed `test_cuda_diagnostics_fit_virtual_jvp_and_reload`: the fitted map stayed on the CPU while the activations were on the GPU, so every diagnostic row recorded a device error. Fixed in `diagnostics._apply` (DEVIATIONS 110). The other CUDA tests, including the v5 job test, passed on that run, but that test did not check for per-row errors; it does now.

## After delivery (archive v7)

Wave 0 on the lab CPU marked the digits MLP control invalid: the float32 node-factorisation check exceeded the fixed 1e-5 by round-off (1.03e-5, with the network's own float32 round-off at 9.2e-6). The float32 identity gates now scale with the network's measured round-off (DEVIATIONS 111); rerun here, all seven Wave-0 CPU controls pass apart from CIFAR-10, whose data is not available in the sandbox.
