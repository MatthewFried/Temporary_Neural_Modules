# Test matrix

2 CPU cores, no GPU, Python 3.13, torch 2.14.1+cpu, code cop-5.0.0 (v12)

| device | passed | failed | error | skipped |
|---|---|---|---|---|
| cpu | 370 | 0 | 0 | 1 |
| cuda | 0 | 0 | 0 | 12 |

A skipped CUDA test is not validated. `scripts/12_v5_gpu_gates.sh` runs them on the GPU and fails on a skip.

## Not passed here

| file | test | device | status | reason |
|---|---|---|---|---|
| tests/test_acceptance.py | test_T22_cpu_gpu_equivalence_if_available | cuda | skipped | no CUDA here; the Wave-0 control job records cpu_vs_gpu_fp32 on the GPU machine |
| tests/test_data.py | test_real_datasets[cifar100-1000] | cpu | skipped | cifar100 not downloaded under COP_DATA_ROOT |
| tests/test_v3_audit_supplied.py | test_cuda_affine_alignment | cuda | skipped | CUDA device required; CPU suite cannot validate this path |
| tests/test_v3_audit_supplied.py | test_cuda_symbol_alignment | cuda | skipped | CUDA device required; CPU suite cannot validate this path |
| tests/test_v3_audit_supplied.py | test_cuda_prune_regrow | cuda | skipped | CUDA device required; CPU suite cannot validate this path |
| tests/test_v3_audit_supplied.py | test_cuda_later_query_mixed_seen_unseen_codes | cuda | skipped | CUDA device required; CPU suite cannot validate this path |
| tests/test_v4_audit.py | test_cuda_affine_and_symbol_alignment | cuda | skipped | CUDA device required (run scripts/12 on the GPU) |
| tests/test_v4_audit.py | test_cuda_end_to_end_jobs_and_resume | cuda | skipped | CUDA device required (run scripts/12 on the GPU) |
| tests/test_v5_review.py | test_cuda_diagnostics_fit_virtual_jvp_and_reload | cuda | skipped | CUDA device required (run scripts/12 on the GPU) |
| tests/test_v5_review.py | test_cuda_v5_jobs | cuda | skipped | CUDA device required (run scripts/12 on the GPU) |
| tests/test_v8_audit.py | test_cuda_transformer_and_fp64_diagnostics | cuda | skipped | CUDA device required (run scripts/12 on the GPU) |
| tests/test_v8_audit.py | test_cuda_mlp_fold_is_exact | cuda | skipped | CUDA device required (run scripts/12 on the GPU) |
| tests/test_v8_audit.py | test_cuda_probe_cut_and_mixing_aligned | cuda | skipped | CUDA device required (run scripts/12 on the GPU) |

## Per file

| file | cpu passed | cuda tests | dtypes beyond float32 |
|---|---|---|---|
| tests/test_acceptance.py | 26 / 26 | 1 | float64 |
| tests/test_data.py | 59 / 60 | 0 | float64 |
| tests/test_finite.py | 20 / 20 | 0 |  |
| tests/test_strengthening.py | 12 / 12 | 0 | float64 |
| tests/test_strengthening_v3.py | 43 / 43 | 0 | float64 |
| tests/test_v2_audit.py | 85 / 85 | 0 | float64 |
| tests/test_v3_audit_supplied.py | 6 / 6 | 4 |  |
| tests/test_v4_audit.py | 24 / 24 | 2 |  |
| tests/test_v5_review.py | 39 / 39 | 2 | float64 |
| tests/test_v8_audit.py | 56 / 56 | 3 | float64 |

Full per-test rows (device, dtype, data, status, seconds): `TEST_MATRIX.json`.
