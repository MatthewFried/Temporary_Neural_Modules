"""Independent audit probes for the unmodified cop_research_v1 upload.

ADAPTED FOR v2 (cop_research_v2/audit_v2/audit_reproductions_v2.py).  The probe
logic is unchanged except where v2 deliberately rejects the probe's harness;
every adaptation is marked "# v2 adaptation:" and keeps the probe's intent:
  * hand-made parents also write provenance.json (v2 refuses parents without
    a provenance record: finding 17);
  * the table probe builds the table from the incoming quantiser (the only
    supported constructor; an unconfigured table now refuses to index) and
    also records that the unconfigured path raises;
  * the matched-control probe gives direct_small its parent cycles run (v2
    rejects direct_small without one) and compares the two exported endpoints;
  * the exact-insertion probe runs the job through the runner and reports the
    resulting status (v2 raises ScientificInvalid -> status 'invalid').
defect_confirmed=false means the v1 defect no longer occurs.

Run: python audit_reproductions.py /absolute/path/to/cop_research_v1
These are defect reproductions, not acceptance tests: confirmed means the
uploaded implementation exhibits the defect. No research conclusion is inferred.
"""
import copy
import dataclasses
import json
import sys
import tempfile
import time
from collections import Counter
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(ROOT))
import torch
torch.set_num_threads(1)
from cop.config import resolve, GROWTH_DEFAULTS
from cop.utils import torch_gen, atomic_write_json
from cop.graph.builders import build_mlp
from cop.graph.graph import GraphNet
from cop.graph import edits as E
from cop.experiments.trajectory import Trajectory, spec_masks
from cop.experiments.context import RunContext
from cop.experiments import common as C
from cop.experiments.repair import run_repair, reach_table
from cop.train.trainer import Trainer

OUT = Path(__file__).resolve().parent
RESULTS = []
def probe(name, fn):
    try:
        details = fn()
        RESULTS.append(dict(probe=name, completed=True, **details))
    except Exception as exc:
        import traceback
        RESULTS.append(dict(probe=name, completed=False, error=repr(exc), traceback=traceback.format_exc()))

def mlp():
    return build_mlp(4, [4,4,4,4], 2, torch_gen(0, 'init'))

def random_cut():
    t = Trajectory.__new__(Trajectory)
    t.g = dict(GROWTH_DEFAULTS, policy='random', policy_candidates=4)
    picks=[]
    for seed in range(100):
        t.cfg={'seeds': {'policy':seed}}
        picks.append(t.choose_cut(mlp(), 1)['chosen'])
    return dict(defect_confirmed=len(set(picks))==1, counts=dict(Counter(picks)), trials=100,
                cutpoints=4, expected='Uniform selection across four cutpoints')

def dtype_roundtrip():
    g=mlp().double()
    with torch.no_grad():
        next(g.parameters()).view(-1)[0] = 1.0000000001
    h=GraphNet.from_checkpoint(g.checkpoint())
    err=max((a-b.double()).abs().max().item() for a,b in zip(g.parameters(),h.parameters()))
    try:
        h({'x':torch.ones(2,4,dtype=torch.float64)})
        failure=None
    except RuntimeError as e:
        failure=str(e)
    return dict(defect_confirmed=next(h.parameters()).dtype!=torch.float64,
                original_dtype=str(next(g.parameters()).dtype), restored_dtype=str(next(h.parameters()).dtype),
                max_parameter_change=err, double_forward_error=failure)

def clean_label_leak():
    fn=spec_masks(SimpleNamespace(task='classification',out_dim=4))
    b=SimpleNamespace(groups=None,y=torch.tensor([0,0,3,3]),y_clean=torch.tensor([0,1,2,3]))
    a=fn(b)['grad_masks']['spec_a'].tolist()
    b.y_clean=3-b.y_clean
    changed=fn(b)['grad_masks']['spec_a'].tolist()
    return dict(defect_confirmed=a!=changed, observed_labels=b.y.tolist(), mask_before=a, mask_after=changed,
                intervention='Only inaccessible clean labels changed')

def regression_units():
    criteria={'nmse':[0.05],'acc_drop_pp':[1.0],'js':[0.01]}
    # Same normalized excess risk .01 under two target scales.
    outputs=[]
    for scale in [1.,10.]:
        raw=.01*scale**2
        curve=[{'update':1,'val.mse_increase_vs_ft':raw,'val.dist_expanded':.01,'val.dist_original':.01}]
        outputs.append({'target_scale':scale,'normalized_excess_mse':.01,'raw_mse_increase':raw,
                        'reach':reach_table(curve,criteria,'regression')['task']})
    return dict(defect_confirmed=outputs[0]['reach']!=outputs[1]['reach'], results=outputs)

DATA={'name':'teacher','n_train':64,'n_val':32,'n_test':32,
      'params':{'d_in':4,'out_dim':2,'teacher_depth':1,'teacher_width':8,'task':'regression'}}
def parent_ctx(temp, inverse=False):
    cfg=resolve({'kind':'trajectory','data':DATA,'model':{'family':'mlp','widths':[4,4,4,4]},
      'train':{'baseline_updates':0,'batch_size':8,'checkpoint_every':1},
      'growth':{'topology':'inverse_pair' if inverse else 'layered','rounds':1,'updates_per_round':3,
                'evaluate_deletions':False,'crossover':False,'probes':False}})
    p=RunContext(cfg,temp,{'device':'cpu'},'audit','audit-code','audit-env')
    b=C.setup_data(p)
    f0=C.new_model(cfg,b,'cpu'); ft=f0.clone(share_params=False)
    cut=E.cut_at(ft,'post_act',1)
    if inverse:
        E.insert_inverse_pair(ft,cut,torch_gen(4,'init'),kind='linear',tie='untied')
    else:
        E.insert_residual_zero(ft,cut,torch_gen(4,'init'),width=4)
    p.save_ckpt('baseline_ref',f0);p.save_ckpt('final',ft)
    atomic_write_json(p.dir/'status.json',{'status':'complete'})
    from cop.utils import semantic_code_hash  # v2 adaptation: provenance record of the hand-made parent
    atomic_write_json(p.dir/'provenance.json',{'semantic_hash':semantic_code_hash()})
    return p,b

def repair_resume():
    with tempfile.TemporaryDirectory(prefix='cop_audit_') as temp:
        p,b=parent_ctx(temp)
        cfg=resolve({'kind':'repair','data':p.cfg['data'],'model':p.cfg['model'],'train':p.cfg['train'],
          'growth':p.cfg['growth'],'parents':{'trajectory':p.run_id},
          'repair':{'deletion':'all','extend_if_inconclusive':False,'eval_points':3}})
        c=RunContext(cfg,temp,{'device':'cpu'},'audit','audit-code','audit-env')
        original=Trainer.run
        def stop_after_one(tr,seg,checkpoint_cb=None):
            original(tr,dataclasses.replace(seg,updates=1),checkpoint_cb)
            checkpoint_cb()
            raise KeyboardInterrupt('audit interruption after one update')
        try:
            with patch.object(Trainer,'run',stop_after_one):run_repair(c)
        except KeyboardInterrupt:pass
        saved=c.load_ckpt('partial')['trainer']['state']['global_step']
        starts=[]
        def spy(tr,seg,checkpoint_cb=None):
            starts.append({'segment':seg.name,'global_step_at_entry':tr.state['global_step'],
                           'seg_step_at_entry':tr.state['seg_step']})
            return original(tr,seg,checkpoint_cb)
        with patch.object(Trainer,'run',spy):
            r=run_repair(c)
        metrics=[json.loads(x) for x in (c.dir/'metrics.jsonl').read_text().splitlines()]
        return dict(defect_confirmed=starts[0]['global_step_at_entry']==0, saved_partial_global_step=saved,
          resumed_segment_entries=starts, reported_updates=r['updates_done'],
          metric_training_updates=sorted(set(x['training_updates'] for x in metrics)),
          metric_examples_seen=sorted(set(x['examples_seen'] for x in metrics)))

def unnecessary_extension():
    with tempfile.TemporaryDirectory(prefix='cop_audit_') as temp:
        p,b=parent_ctx(temp)
        cfg=resolve({'kind':'repair','data':p.cfg['data'],'model':p.cfg['model'],'train':p.cfg['train'],
          'growth':p.cfg['growth'],'parents':{'trajectory':p.run_id},
          'repair':{'deletion':'all','extend_if_inconclusive':True,'eval_points':3}})
        c=RunContext(cfg,temp,{'device':'cpu'},'audit','audit-code','audit-env')
        r=run_repair(c)
        return dict(defect_confirmed=r['extended'] and 0 in r['reach']['task'].values(),
                    budget=r['budget'],updates_done=r['updates_done'],extended=r['extended'],reach=r['reach'])

def inverse_penalty():
    from cop.experiments.dissipation import run_dissipation
    with tempfile.TemporaryDirectory(prefix='cop_audit_') as temp:
        p,b=parent_ctx(temp,True)
        cfg=resolve({'kind':'dissipation','data':p.cfg['data'],'model':p.cfg['model'],'train':p.cfg['train'],
          'growth':p.cfg['growth'],'parents':{'trajectory':p.run_id},'dissipation':{'method':'inverse_restore'}})
        c=RunContext(cfg,temp,{'device':'cpu'},'audit','audit-code','audit-env')
        vals={}
        class Captured(Exception): pass
        def capture(tr,seg,checkpoint_cb=None):
            if seg.extra_loss is not None:
                loss=seg.extra_loss(tr.model,{},None,0)
                vals['penalty_at_initial_exact_inverse_pair']=float(loss)
                group=next(i for i in tr.model.implants.values() if i.construction=='inverse_pair')
                kids=tr.model.implant_children(group.id)
                mats=[]
                for typ in ['inverse_T','inverse_Tinv']:
                    child=next(tr.model.implants[k] for k in kids if tr.model.implants[k].construction==typ)
                    pk=next(tr.model.nodes[n].pkey for n in child.nodes if tr.model.nodes[n].pkey)
                    mats.append(tr.model.mods[pk].weight)
                vals['matrix_inverse_error']=float(((mats[1]@mats[0]-torch.eye(4))**2).sum())
                loss.backward()
                vals['max_weight_gradient']=max(float(m.grad.abs().max()) for m in mats)
                raise Captured()
        try:
            with patch.object(Trainer,'run',capture):run_dissipation(c)
        except Captured:pass
        return dict(defect_confirmed=vals.get('penalty_at_initial_exact_inverse_pair',0)>1e-6,**vals)

def finite_checker():
    from cop.finite import _transition, FINITE_DEFAULTS
    from cop.finite.checker import verify_certificate
    from cop.finite.transition import absorbing_toy
    args=copy.deepcopy(FINITE_DEFAULTS['transition'])
    args.update(system='absorbing_toy',params={'with_good_closed_class':True})
    cert=_transition(args,time.time()+60)[0]
    original=verify_certificate(cert)
    tm=copy.deepcopy(cert)
    tm['data']['initial'][0]['expected_time_to_simple']='-999'
    invalid_time=verify_certificate(tm)
    # Build consistent graph/labels from a wrong complexity map, then restore
    # the TRUE system specification. Checker must recompute complexity from it.
    spec=copy.deepcopy(cert['data']['system'])
    badspec=copy.deepcopy(spec)
    badspec['complexity']={k:2 for k in spec['complexity']}
    table_args=copy.deepcopy(FINITE_DEFAULTS['transition'])
    table_args.update(system='table',params={k:v for k,v in badspec.items() if k!='kind'})
    forged=_transition(table_args,time.time()+60)[0]
    for destination,key in [(forged['data'],'system'),(forged['class'],'system'),(forged,'edit_rules')]:
        destination[key]=copy.deepcopy(spec)
    false_inevitability=verify_certificate(forged)
    before=[x['entrenchment_inevitable'] for x in cert['data']['initial']]
    after=[x['entrenchment_inevitable'] for x in forged['data']['initial']]
    (OUT/'tampered_transition_certificate.json').write_text(json.dumps(forged,indent=2))
    return dict(defect_confirmed=false_inevitability['ok'] and before!=after, original=original,
      accepted_negative_expected_time=invalid_time, accepted_false_complexity_claim=false_inevitability,
      true_inevitability=before,forged_inevitability=after)

def finite_interface():
    from cop.cop_pegs.pegs import insert_peg
    from cop.cop_pegs.alternatives import Assembly,code_nodes
    g=mlp()
    for i in [0,2]:
        iid=insert_peg(g,E.cut_at(g,'post_act',i),torch_gen(i,'init'),k=2,mode='uniform',bits=2)
        g.gate_vals[g.implants[iid].meta['peg']['alpha']]=0.
    from cop.graph.export import export_compact
    g=export_compact(g,fold_linear=False)[0]
    codes=code_nodes(g)
    m=torch.nn.Linear(2,2)
    with torch.no_grad():m.weight.zero_();m.bias.fill_(0.123)
    a=Assembly(g,codes,[1],{1:m})
    _,cs=a({'x':torch.randn(8,4)},return_codes=True)
    q=g.mods[g.nodes[codes[1]].pkey]
    with torch.no_grad():err=float((cs[1]-q(cs[1])).abs().max())
    return dict(defect_confirmed=err>1e-6, output_code=cs[1][0].tolist(),
      max_distance_to_declared_quantizer=err, finite_levels=[-1,-1/3,1/3,1])

def table_range():
    from cop.graph.ops import Quantizer,TableModule
    q=Quantizer(1,'uniform',bits=2)
    q.lo.fill_(-5);q.hi.fill_(5)
    values=torch.linspace(-5,5,4).view(-1,1)
    try:  # v2 adaptation: the unconfigured constructor must refuse to index
        TableModule(1,4,1).index(values); unconfigured='indexed silently'
    except RuntimeError as e:
        unconfigured='raises: '+str(e)
    tab=TableModule.from_quantizer(q,1)
    ids=tab.index(q(values)).tolist()
    return dict(defect_confirmed=len(set(ids))<4, unconfigured_table=unconfigured, valid_distinct_codes=values.flatten().tolist(),
                assigned_table_indices=ids, table_range=[float(tab.lo[0]),float(tab.hi[0])],
                peg_range=[float(q.lo[0]),float(q.hi[0])])

def cop_cfg(**cop):
    return resolve({'kind':'cop','data':DATA,'model':{'family':'mlp','widths':[8]*6},
      'train':{'baseline_updates':0,'batch_size':8},'eval':{'calib_size':32},
      'peg':{'dim':2,'anneal_updates':1},
      'cop':{'n_pearls':4,'cycles':3,'local_updates':1,'global_updates':1,
             'pearl_width':8,'grow_width':4,'replace_width':2,**cop}})

def cycle_final_graph():
    # v2 adaptation: direct_small must name the cycles history it matches (parents.cycles); both jobs run
    # through the runner so the parent has status + provenance.  Same pearls / cycles as the v1 probe.
    from cop.orchestration.runner import run_job
    from cop.config import run_id as _rid
    records=[]
    with tempfile.TemporaryDirectory(prefix='cop_audit_') as temp:
        cyc=cop_cfg(task_kind='cycles',baseline='expand_peg_replace')
        base=resolve({'kind':'baseline','data':DATA,'model':cyc['model'],'train':cyc['train']})
        cyc=resolve({**cyc,'parents':{'baseline':_rid(base)}})
        assert run_job(base,temp,{'device':'cpu'})=='complete'
        assert run_job(cyc,temp,{'device':'cpu'})=='complete'
        ctl=resolve({'kind':'cop','data':DATA,'model':{'family':'mlp','widths':[8]*6},
          'train':{'baseline_updates':0,'batch_size':8},'eval':{'calib_size':32},
          'peg':{'dim':2,'anneal_updates':1},
          'cop':{'n_pearls':4,'cycles':3,'local_updates':1,'global_updates':1,
                 'pearl_width':8,'grow_width':4,'replace_width':2,'task_kind':'baseline','baseline':'direct_small'},
          'parents':{'baseline':_rid(base),'cycles':_rid(cyc)}})
        st=run_job(ctl,temp,{'device':'cpu'})
        for task,c,name in [('cycles',cyc,'cycles_result.json'),('baseline',ctl,'baseline_result.json')]:
            d=json.loads((Path(temp)/'runs'/_rid(c)/name).read_text())
            records.append({'task':task,'params':d['export']['params'],'route':d.get('route'),
                            'n_pearls':4,'cycles':3,'exposure_updates':d['exposure_updates'],
                            'export_structural_hash':d.get('export_structural_hash')})
    return dict(defect_confirmed=records[0]['params']!=records[1]['params'], control_status=st, results=records)

def alt_optimizer_and_artifacts():
    from cop.cop_pegs.alternatives import run_alternatives
    records=[]
    with tempfile.TemporaryDirectory(prefix='cop_audit_') as temp:
        cfg=cop_cfg(task_kind='alternatives',alt_kinds=['linear'])
        cfg['train'].update(optimizer='sgd',momentum=.9,weight_decay=0.)
        c=RunContext(cfg,temp,{'device':'cpu'},'audit','audit-code','audit-env')
        original=torch.optim.AdamW
        def spy(*args,**kw):
            opt=original(*args,**kw)
            records.append({'type':'AdamW','weight_decay':opt.defaults['weight_decay'],
                            'betas':opt.defaults['betas']})
            return opt
        with patch.object(torch.optim,'AdamW',spy):
            run_alternatives(c)
        files=[str(p.relative_to(c.dir)) for p in c.dir.rglob('*') if p.is_file() and p.suffix in ('.pt','.pth')]
        return dict(defect_confirmed=bool(records),requested_optimizer='sgd',requested_weight_decay=0,
                    observed_optimizers=records,saved_tensor_files=sorted(files))

def instance_hash_collision():
    g=build_mlp(2,[2],2,torch_gen(0,'init'),act='identity')
    linears=[n for n in g.nodes.values() if n.op=='linear']
    with torch.no_grad():
        a,b=[g.mods[n.pkey] for n in linears]
        a.weight.copy_(torch.tensor([[1.,2.],[0.,1.]]));a.bias.zero_()
        b.weight.copy_(torch.tensor([[2.,0.],[1.,1.]]));b.bias.zero_()
    h=g.clone(share_params=True)
    x,y=[h.nodes[n.id] for n in linears]
    x.pkey,y.pkey=y.pkey,x.pkey
    inp={'x':torch.tensor([[1.,1.]])}
    yg,yh=g(inp),h(inp)
    return dict(defect_confirmed=g.instance_hash()==h.instance_hash() and not torch.equal(yg,yh),
                same_instance_hash=g.instance_hash()==h.instance_hash(),output_original=yg.tolist(),
                output_swapped=yh.tolist(),scope='Hash API counterexample; not proof existing deletion results collide')

def exact_failure_is_not_gated():
    from cop.experiments.growth import Grower
    with tempfile.TemporaryDirectory(prefix='cop_audit_') as temp:
        cfg=resolve({'kind':'trajectory','data':DATA,'model':{'family':'mlp','widths':[4]*4},
          'train':{'baseline_updates':0,'batch_size':8},'eval':{'calib_size':32},
          'growth':{'topology':'layered','rounds':1,'updates_per_round':1,
                    'evaluate_deletions':False,'crossover':False,'probes':False}})
        c=RunContext(cfg,temp,{'device':'cpu'},'audit','audit-code','audit-env')
        original=Grower.round
        def corrupt(self,g,r,R):
            ids=original(self,g,r,R)
            with torch.no_grad():
                g.mods[g.nodes[g.output].pkey].bias.add_(1.)
            return ids
        # Deliberate fault injection to test the failure-handling contract.
        from cop.orchestration.runner import run_job, status_of  # v2 adaptation: run through the runner
        from cop.config import run_id as _rid
        with patch.object(Grower,'round',corrupt):
            st=run_job(cfg,temp,{'device':'cpu'})
        d=Path(temp)/'runs'/_rid(cfg)
        metrics=[json.loads(l) for l in (d/'metrics.jsonl').read_text().splitlines()]
        labels=[m['metric_value'] for m in metrics if m['metric_name']=='insertion_label']
        final=(d/'ckpt'/'final.pt').exists()
        return dict(defect_confirmed='L0_failed_exact_insertion' in labels and final,
          labels=labels, final_checkpoint_written=final, job_status=st,
          reason=status_of(temp,_rid(cfg)).get('reason'),
          method='Injected +1 output bias during nominally exact insertion')

def mixed_statistical_cells():
    from cop.analysis.summarize import trajectory_table,paired_contrasts
    entries=[json.loads(l) for l in (ROOT/'manifests/wave1_full.jsonl').read_text().splitlines()]
    configs={e['run_id']:e['cfg'] for e in entries}
    chosen=[e for e in entries if e['cfg']['kind']=='trajectory' and e['cfg']['data']['name']=='frequency'
      and e['cfg']['growth']['topology']=='layered' and e['cfg']['data']['teacher_seed']==0
      and e['cfg']['data']['data_seed']==0 and e['cfg']['seeds']['optimizer']==0]
    # One pair of conditions differing in omega, with otherwise same analysis key.
    by_size={}
    for e in chosen:by_size.setdefault(e['cfg']['data']['n_train'],[]).append(e)
    selected=next(v for v in by_size.values() if len(v)>=2)[:2]
    ids={e['run_id'] for e in selected}|{e['cfg']['parents']['continued'] for e in selected}
    fake={rid:{'cfg':configs[rid],'status':{'status':'pending'}} for rid in ids}
    table=trajectory_table(fake)
    for row in table:
        row['status']='complete';row['test_mse']=1. if row['topology']=='layered' else 0.
    contrasts=paired_contrasts(table,n_boot=20)  # v2: cells are condition ids (unchanged call)
    return dict(defect_confirmed=len(contrasts)==1 and contrasts[0]['n_pairs']==2,
      input_conditions=[{'omega':e['cfg']['data']['params']['omega'],'optimizer_seed':0,'teacher_seed':0} for e in selected],
      output_contrast_count=len(contrasts),reported_n_pairs=[r['n_pairs'] for r in contrasts],
      scope='Synthetic metric values on real manifest identities; tests grouping, not model performance')

for name,fn in [('random_cut_bias',random_cut),('checkpoint_dtype',dtype_roundtrip),
 ('clean_label_specialization',clean_label_leak),('repair_tolerance_units',regression_units),
 ('repair_resume_and_counters',repair_resume),('repair_unneeded_extension',unnecessary_extension),
 ('linear_inverse_restore_penalty',inverse_penalty),('transition_checker_false_claim',finite_checker),
 ('alternative_finite_interface',finite_interface),('lookup_table_quantizer_range',table_range),
 ('cycle_vs_direct_architecture',cycle_final_graph),('alternative_optimizer_and_artifacts',alt_optimizer_and_artifacts),
 ('instance_hash_parameter_binding',instance_hash_collision),('exact_insertion_failure_gate',exact_failure_is_not_gated),
 ('aggregation_mixes_conditions',mixed_statistical_cells)]:
    probe(name,fn)
path=OUT/'audit_results.json'
path.write_text(json.dumps(RESULTS,indent=2))
print(json.dumps(RESULTS,indent=2))
