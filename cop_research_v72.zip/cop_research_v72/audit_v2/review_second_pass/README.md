# Second-pass review reproductions

These scripts come from an independent reviewer that read the v1-to-v2 diff before the code freeze and tried to break the fixes. Run each from the repository root (`python audit_v2/review_second_pass/<script>`). AUDIT_RESPONSE.md, "Second pass", lists the findings (R1-R11) and what was done about each.

`rerun_on_frozen_v2.log` is the output of every script on the frozen v2 code (semantic hash `5f0fc17a02584937`).

| Script | Finding | Result on frozen v2 |
|---|---|---|
| `r1_checker.py` | R1, R2: forged complete and incomplete transition certificates | every forgery `rejected`; genuine certificates `verified` |
| `r1b.py` | R1: fully forged initial report of an incomplete certificate | `rejected` |
| `r2_resume.py CASE FRACTIONS` | R3: late interruption of a chain with a peg edit (and other cases) | `chain_edit 0.9`: `equal: true` (0 metrics differ, work equal) |
| `r2b.py` | R3: prints the first differing metric | ends with `IndexError` because no metric differs any more |
| `r3_stale.py` | R4: stale runs in the analysis | effective status `stale`; 0 contrasts; listed under `excluded_stale` |
| `r4_num.py`, `r4b.py PARAMS` | R5: checker cost on float64 hitting systems | `verified`; 3,618 states checked in under 5 s |

The tests that now guard each finding are listed in AUDIT_RESPONSE.md.
