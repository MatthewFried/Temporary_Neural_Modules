import copy, time, json, sys
sys.path.insert(0, '.')
from cop.finite import _transition, FINITE_DEFAULTS
from cop.finite.checker import verify_certificate as V
def cert(system, params=None, **kw):
    a = copy.deepcopy(FINITE_DEFAULTS["transition"]); a.update(system=system, params=params or {}, **kw)
    return _transition(a, time.time()+60)[0]
b = cert("absorbing_toy")
print("base", V(b)["verdict"])
for r in b["data"]["initial"]: print({k: r.get(k) for k in ("state","expected_time_to_simple","long_expected_time")})
# B: drop long_time_threshold, flip long flag
c = copy.deepcopy(b); del c["data"]["long_time_threshold"]
for r in c["data"]["initial"]:
    if "long_expected_time" in r: r["long_expected_time"] = not r["long_expected_time"]
print("B long flag flipped, thr removed:", V(c)["verdict"])
c = copy.deepcopy(b); c["data"]["long_time_threshold"] = 0.5
for r in c["data"]["initial"]:
    if "long_expected_time" in r: r["long_expected_time"] = True
print("B2 threshold changed in data only (config had 1000):", V(c)["verdict"])
# C: duplicated domain / precision / coverage fields
c = copy.deepcopy(b); c["domain"]["n_states"] = 3; c["domain"]["state_cap"] = 7
c["precision"] = "exact_rational graph; hitting=exact_rational; time=exact_rational"; c["coverage"]["incomplete_reason"]="state_cap"
c["data"]["state_cap"] = 1
print("C domain.n_states/state_cap/precision/incomplete_reason forged:", V(c)["verdict"])
# A: incomplete cert, forged edges from unexpanded states
ic = cert("permutation_chain", {}, state_cap=5, simple_threshold=1)
g = ic["data"]["graph"]
print("incomplete base", V(ic)["verdict"], "expanded", g["expanded"], "labels", g["labels"], "init", ic["data"]["initial"])
c = copy.deepcopy(ic); g = c["data"]["graph"]
un = [i for i,e in enumerate(g["expanded"]) if not e]
print("unexpanded", un)
c["data"]["initial"][0]["return_label"] = "in_simple_set"; c["data"]["return_label_counts"] = {"bogus": 1}
c["data"]["n_states"] = 999; c["data"]["simple_threshold"] = 42; c["data"]["n_simple"] = 99; c["data"]["n_edges"]=-1
print("A1 incomplete: initial label/counts/n_states/threshold/n_simple forged:", V(c)["verdict"])
c = copy.deepcopy(ic); g = c["data"]["graph"]
# mark everything unexpanded and add a fabricated edge to... first find a simple state
simple = [i for i in range(len(g["states"])) if g["complexity"][i] <= 1]
print("simple", simple)
# fabricate a new simple state reachable from initial
g["states"].append([[0,1,2]]); g["complexity"].append(1); g["loss"].append("3"); g["expanded"].append(False); g["labels"].append("in_simple_set")
new = len(g["states"])-1
g["expanded"] = [False]*len(g["expanded"])
g["edges"] = [[i, new, "1"] for i in range(new)]
for i in range(new):
    g["labels"][i] = "in_simple_set" if g["complexity"][i] <= 1 else "return_possible_witnessed_incomplete"
for r, j in zip(c["data"]["initial"], g["initial"]): r["return_label"] = g["labels"][j]
print("A2 incomplete: all states unexpanded, fabricated edges to fabricated state:", V(c))
