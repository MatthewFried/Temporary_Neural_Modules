import copy, time, sys
sys.path.insert(0, '.')
from cop.finite import _transition, FINITE_DEFAULTS
from cop.finite.checker import verify_certificate as V
a = copy.deepcopy(FINITE_DEFAULTS["transition"]); a.update(system="permutation_chain", params={}, state_cap=5, simple_threshold=1)
ic = _transition(a, time.time()+60)[0]
c = copy.deepcopy(ic)
c["data"]["initial"][0].update(return_label="return_possible_witnessed_incomplete", complexity=7, loss="5", state=[[0,1,2]])
print("A1 initial report fully forged:", V(c)["verdict"])
# genuine partial edges of the cap-hit state: drop/alter them
c = copy.deepcopy(ic); g=c["data"]["graph"]
print(g["edges"][:6])
