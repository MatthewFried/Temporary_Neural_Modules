import sys, json, tempfile, time
from pathlib import Path
import torch
torch.set_num_threads(1)
sys.path.insert(0, 'tests'); sys.path.insert(0, '.')
import tiny_configs as T
from resume_harness import compare_interrupted
TR = {**T.TRAIN, "checkpoint_every": 7}
which = sys.argv[1]
fr = tuple(float(x) for x in sys.argv[2].split(","))
cases = {
 "chain_edit": lambda: T.cop({"task_kind": "chain", "n_pearls": 3, "peg_edit": "split"}, train=TR),
 "cycles_fixed_revisit": lambda: T.cop({"task_kind": "cycles", "cycle_pegs": "fixed", "cycles": 4, "n_pearls": 3}, train=TR),
 "cycles_relearned": lambda: T.cop({"task_kind": "cycles", "cycle_pegs": "relearned", "cycles": 4, "n_pearls": 3}, train=TR),
 "alt_independent_onpolicy": lambda: T.cop({"task_kind": "alternatives", "alt_kinds": ["mlp_small", "sparse"], "local_inputs": "on_policy", "n_pearls": 4}, train=TR),
 "alt_aligned": lambda: T.cop({"task_kind": "alternatives", "code_kind": "aligned", "alt_kinds": ["mlp_small", "linear"], "n_pearls": 4}, train=TR),
}
_p = T.traj({"topology": "recursive_branch"}, train=TR)
for _m in ("abrupt", "residual_penalty", "cosine", "group_removal", "branch_merge"):
    cases["diss_"+_m] = (lambda m=_m: _p + [T.child("dissipation", _p[-1], {"dissipation": {"method": m, "speed_updates": 10, "post_updates": 10, "path_eval_points": 4}})])
cases["repair_full_ext"] = lambda: _p + [T.child("repair", _p[-1], {"repair": {"region": "full", "budget_multiplier": 0.3, "eval_points": 2, "extension_factor": 3.0}, "criteria": {"acc_drop_pp": [0.0], "js": [0.0], "nmse": [0.0]}})]
cases["traj_mut_aux"] = lambda: T.traj({"topology": "layered", "driver": "neutral_mutation", "driver_strength": 1e-3, "rounds": 3}, train=TR)
t0 = time.time()
with tempfile.TemporaryDirectory() as d:
    r = compare_interrupted(cases[which](), Path(d), fractions=fr)
print(which, fr, json.dumps(r, default=str)[:3000], "secs", round(time.time()-t0,1))
