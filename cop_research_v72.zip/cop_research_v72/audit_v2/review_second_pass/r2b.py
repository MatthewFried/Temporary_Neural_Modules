import sys, json, tempfile
from pathlib import Path
import torch
torch.set_num_threads(1)
sys.path.insert(0, 'tests'); sys.path.insert(0, '.')
import tiny_configs as T
import resume_harness as H
from cop.config import run_id
from cop.utils import read_json
TR = {**T.TRAIN, "checkpoint_every": 7}
cfgs = T.cop({"task_kind": "chain", "n_pearls": 3, "peg_edit": "split"}, train=TR)
d = Path(tempfile.mkdtemp())
H.compare_interrupted(cfgs, d, fractions=(0.9,))
ra, rb = d/"A"/"runs"/run_id(cfgs[-1]), d/"B"/"runs"/run_id(cfgs[-1])
ma, mb = H._metrics(ra), H._metrics(rb)
k = [k for k in ma if ma[k] != mb.get(k)][0]
print(k, ma[k], mb[k])
print("work A", read_json(ra/"summary.json")["work"])
print("work B", read_json(rb/"summary.json")["work"])
