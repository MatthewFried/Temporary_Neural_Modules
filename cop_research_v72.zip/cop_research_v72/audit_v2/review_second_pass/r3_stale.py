import sys, json, tempfile
from pathlib import Path
import torch
torch.set_num_threads(1)
sys.path.insert(0, 'tests'); sys.path.insert(0, '.')
import tiny_configs as T
from cop.config import run_id
from cop.orchestration.runner import run_job, effective_status
from cop.utils import read_json, atomic_write_json, semantic_code_hash
from cop.analysis.summarize import load_runs, trajectory_table, paired_contrasts_report
d = Path(tempfile.mkdtemp())
cfgs = T.traj({"topology": "layered"})
for c in cfgs: print(run_job(c, d, {"device": "cpu"}))
for c in cfgs:
    p = d/"runs"/run_id(c)/"provenance.json"; pr = read_json(p); pr["semantic_hash"] = "OLDCODE"; atomic_write_json(p, pr)
sem = semantic_code_hash()
print("effective:", [effective_status(d, run_id(c), sem) for c in cfgs])
runs = load_runs(d); Tt = trajectory_table(runs)
print("table statuses:", [(r["status"], r["validity"]) for r in Tt])
rep = paired_contrasts_report(Tt, runs=runs)
print("n contrasts from stale runs:", len(rep["contrasts"]), rep["errors"])
