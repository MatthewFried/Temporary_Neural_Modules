import copy, time, sys
sys.path.insert(0, '.')
from cop.finite import _transition, FINITE_DEFAULTS
from cop.finite.checker import verify_certificate as V
for sysname, params in [("quantized_chain", {"K": 1, "rule": "metropolis", "metropolis_r": "1/1000", "target": "xor"}),
                        ("quantized_chain", {"K": 1, "rule": "nonincreasing", "target": "xor"}),
                        ("permutation_chain", {"m": 4, "K": 2})]:
    a = copy.deepcopy(FINITE_DEFAULTS["transition"]); a.update(system=sysname, params=params)
    t=time.time(); c = _transition(a, time.time()+120)[0]; t1=time.time()-t
    d = c["data"]
    t=time.time(); v = V(c); t2=time.time()-t
    print(sysname, params, "n", d["n_states"], d.get("hitting_arithmetic"), d.get("time_arithmetic"), v["verdict"], v["reasons"][:1], "gen %.1fs check %.1fs"%(t1,t2))
    print("  init", [(r.get("p_hit_simple"), r.get("expected_time_to_simple")) for r in d["initial"]])
