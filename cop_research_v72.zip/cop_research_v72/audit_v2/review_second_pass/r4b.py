import copy, time, sys
sys.path.insert(0, '.')
from cop.finite import _transition, FINITE_DEFAULTS
from cop.finite.checker import verify_certificate as V
params = eval(sys.argv[1])
a = copy.deepcopy(FINITE_DEFAULTS["transition"]); a.update(system="quantized_chain", params=params)
t=time.time(); c = _transition(a, time.time()+200)[0]; t1=time.time()-t
d = c["data"]
import numpy as np
print("n", d["n_states"], d["complete"], d.get("hitting_arithmetic"), d.get("time_arithmetic"), "graph" , d["graph"] is not None, "gen %.1fs"%t1, flush=True)
t=time.time(); v = V(c); print(v["verdict"], v["reasons"][:1], v["checks"], "check %.1fs"%(time.time()-t))
