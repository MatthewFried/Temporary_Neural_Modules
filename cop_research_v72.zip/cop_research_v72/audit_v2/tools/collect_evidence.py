"""Usage: python audit_v2/tools/collect_evidence.py ROOT[,ROOT...] OUT_DIR DATA_ROOT
Collect the v2 sandbox evidence from finished sample runs into sandbox_checks/."""
import json, sys, subprocess, collections
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from cop.utils import read_json, semantic_code_hash
from cop.orchestration.runner import effective_status
roots = [Path(p) for p in sys.argv[1].split(",")]
out = Path(sys.argv[2]); out.mkdir(parents=True, exist_ok=True)
data_root = sys.argv[3]
sem = semantic_code_hash()
status = collections.Counter(); validity = collections.Counter(); rows = []
reload_rep, matched = {}, []
for root in roots:
    for d in sorted((root / "runs").glob("*")):
        if not (d / "config.json").exists():
            continue
        c = read_json(d / "config.json")
        st = read_json(d / "status.json") if (d / "status.json").exists() else {"status": "missing"}
        eff = effective_status(root, d.name, sem)
        status[eff] += 1
        validity[str(st.get("validity"))] += 1
        rows.append({"root": root.name, "run_id": d.name, "kind": c["kind"], "block": c.get("block"),
                     "status": eff, "validity": st.get("validity"), "reason": st.get("reason")})
        tk = (c.get("cop") or {}).get("task_kind")
        if eff == "complete" and tk in ("alternatives", "split"):
            r = subprocess.run([sys.executable, "-m", "cop.cli", "verify-reload", "--run-dir", str(d), "--data-root",
                                data_root], cwd=str(ROOT), capture_output=True, text=True)
            try:
                j = json.loads(r.stdout)
                reload_rep[d.name] = {"task": tk, "block": c.get("block"), "data": c["data"]["name"],
                                      "ok": j["ok"], "all_bitwise_equal": j["all_bitwise_equal"],
                                      "max_abs_diff": j["max_abs_diff"], "fresh_process": True}
            except Exception:
                reload_rep[d.name] = {"task": tk, "ok": False, "stdout": r.stdout[-500:], "stderr": r.stderr[-1500:]}
        if eff == "complete" and tk == "baseline" and (c.get("parents") or {}).get("cycles"):
            b = read_json(d / "baseline_result.json")
            p = read_json(root / "runs" / c["parents"]["cycles"] / "cycles_result.json")
            matched.append({"control": d.name, "baseline": c["cop"]["baseline"], "parent": c["parents"]["cycles"],
                            "block": c.get("block"), "data": c["data"]["name"],
                            "parent_variant": p["variant"], "parent_route": p["route"],
                            "parent_export_params": p["export"]["params"], "control_export_params": b["export"]["params"],
                            "parent_hash": p["export_structural_hash"], "control_hash": b["export_structural_hash"],
                            "equal": p["export"]["params"] == b["export"]["params"] and
                                     p["export_structural_hash"] == b["export_structural_hash"],
                            "parent_work_updates": p["work_total"]["updates"], "control_updates": b["exposure_updates"],
                            "exposure_basis": b["control"]["exposure_basis"],
                            "quantizer_recalibration_at_updates": b["control"].get("quantizer_recalibration_at_updates")})
json.dump({"status_counts": status, "validity_counts": validity, "runs": rows}, open(out / "status_counts.json", "w"), indent=1)
json.dump(reload_rep, open(out / "reload_checks.json", "w"), indent=1)
json.dump(matched, open(out / "matched_controls.json", "w"), indent=1)
print("status", dict(status), "validity", dict(validity))
print("reload", len(reload_rep), sum(v["ok"] for v in reload_rep.values()))
print("matched", len(matched), sum(m["equal"] for m in matched))
for r in rows:
    if r["status"] != "complete":
        print("NOT COMPLETE", r)
