"""Job-level interrupted-vs-uninterrupted comparisons (sandbox_checks/resume_comparisons.json).
Usage: python audit_v2/tools/resume_comparisons.py OUT_DIR [case,case,...]"""
import sys, json, shutil, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / "tests"))
import torch; torch.set_num_threads(2)
import tiny_configs as T
from resume_harness import compare_interrupted
from cop.config import run_id
root = Path(sys.argv[1]); shutil.rmtree(root, ignore_errors=True)
TR = {**T.TRAIN, "checkpoint_every": 7}
cases = {}
p = T.traj({"topology": "recursive_branch"}, train=TR)
cases["baseline"] = [T.base(train=TR)]
cases["trajectory_incremental"] = p
cases["trajectory_mutation"] = T.traj({"topology": "layered", "driver": "neutral_mutation", "driver_strength": 1e-3}, train=TR)
cases["trajectory_all_at_once"] = T.traj({"topology": "tree_depth2", "schedule": "all_at_once"}, train=TR)
cases["trajectory_policy"] = T.traj({"topology": "layered", "policy": "dependence_seeking", "policy_probe_updates": 3}, train=TR)
cases["repair_full"] = p + [T.child("repair", p[-1], {"repair": {"region": "full", "budget_multiplier": 1.0, "eval_points": 3}})]
cases["repair_adapters_ext"] = p + [T.child("repair", p[-1], {"repair": {"region": "incident_adapters", "budget_multiplier": 0.3, "eval_points": 2, "extension_factor": 3.0}})]
for m in ["abrupt", "linear", "residual_penalty", "peg_replacement"]:
    cases[f"dissipation_{m}"] = p + [T.child("dissipation", p[-1], {"dissipation": {"method": m, "speed_updates": 10, "post_updates": 10, "path_eval_points": 4}})]
pi = T.traj({"topology": "inverse_pair", "inverse_kind": "linear", "tie": "untied"}, train=TR)
cases["dissipation_inverse_linear"] = pi + [T.child("dissipation", pi[-1], {"dissipation": {"method": "inverse_restore", "speed_updates": 10, "post_updates": 10}})]
cases["cop_chain"] = T.cop({"task_kind": "chain", "n_pearls": 3}, train=TR)
cases["cop_chain_known"] = T.cop({"task_kind": "chain", "n_pearls": 3, "placement": "known"}, data={"name": "compose", "n_train": 256, "n_val": 128, "n_test": 128}, train=TR)
for mode, ck in [("independent", "fixed_teacher"), ("joint", "learned"), ("independent", "aligned")]:
    cases[f"cop_alt_{mode}_{ck}"] = T.cop({"task_kind": "alternatives", "alt_training": mode, "code_kind": ck, "alt_kinds": ["mlp_small", "linear", "sparse"]}, train=TR)
cases["cop_split"] = T.cop({"task_kind": "split", "split_into": 2}, train=TR)
cy = T.cop({"task_kind": "cycles", "cycle_pegs": "relearned", "cycles": 3, "n_pearls": 3}, train=TR)
cases["cop_cycles"] = cy
cases["cop_direct_small"] = cy + [T.cop({"task_kind": "baseline", "baseline": "direct_small", "cycle_pegs": "relearned", "cycles": 3, "n_pearls": 3}, train=TR, parents={"cycles": run_id(cy[-1])})[-1]]
cases["cop_theseus"] = T.cop({"task_kind": "baseline", "baseline": "replace_no_expand"}, train=TR)
cases["cop_shared_fold"] = T.cop({"task_kind": "baseline", "baseline": "shared_fold"}, train=TR)
for m in ["cosine", "group_removal", "branch_merge"]:
    cases[f"dissipation_{m}"] = p + [T.child("dissipation", p[-1], {"dissipation": {"method": m, "speed_updates": 10, "post_updates": 10, "path_eval_points": 4}})]
cases["trajectory_from_scratch"] = T.traj({"topology": "tree_depth2", "schedule": "from_scratch"}, train=TR)
cases["trajectory_known_pretrained"] = T.traj({"topology": "known_module", "known_module": "pretrained", "pretrain_updates": 20}, train=TR)
cases["cop_chain_peg_edit"] = T.cop({"task_kind": "chain", "n_pearls": 3, "peg_edit": "split"}, train=TR)
cases["cop_cycles_fixed_revisit"] = T.cop({"task_kind": "cycles", "cycle_pegs": "fixed", "cycles": 4, "n_pearls": 3}, train=TR)
cases["cop_alt_on_policy"] = T.cop({"task_kind": "alternatives", "alt_kinds": ["mlp_small", "sparse"], "local_inputs": "on_policy", "n_pearls": 4}, train=TR)
FRACTIONS = {"trajectory_known_pretrained": (0.3, 0.9), "cop_chain_peg_edit": (0.3, 0.9)}
only = sys.argv[2].split(",") if len(sys.argv) > 2 else None
rep = {}
for name, cfgs in cases.items():
    if only and name not in only: continue
    t = time.time()
    try:
        r = compare_interrupted(cfgs, root / name, fractions=FRACTIONS.get(name, (0.3, 0.7)))
    except Exception as e:
        import traceback; traceback.print_exc(); r = {"error": repr(e)}
    rep[name] = r
    print(name, round(time.time()-t,1), {k: r.get(k) for k in ("equal", "attempts", "interrupted_at_polls", "polls_uninterrupted", "checkpoints_differing", "n_metrics_differing", "metrics_differing", "results_differing", "work_equal", "error")}, flush=True)
json.dump(rep, open(root / "report.json", "w"), indent=1, default=str)
