"""Usage: python audit_v2/tools/sample_waves.py WAVES K OUT_ROOT DATA_ROOT [TIME_LIMIT_S] [EXCLUDE_DATA,...]
Jobs on an excluded dataset that are not already complete are recorded as not_sampled (e.g. cifar10 on a CPU-only machine).
Run a per-block sample of smoke-scale manifest entries (with prerequisites) on CPU (v2).
No allow_code_change.  Per-job wall-time limit; every non-complete outcome is printed."""
import json, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import torch; torch.set_num_threads(2)
from cop.orchestration.manifest import generate
from cop.orchestration.runner import run_job, status_of
from cop.utils import INTERRUPT
waves = [int(w) for w in sys.argv[1].split(",")]
k = int(sys.argv[2]); root = Path(sys.argv[3]); data_root = sys.argv[4]
limit = float(sys.argv[5]) if len(sys.argv) > 5 else 900
exclude = set(sys.argv[6].split(",")) if len(sys.argv) > 6 else set()
B = generate(waves, "smoke")
ents = {e["run_id"]: e for e in B.entries_list()}
chosen = []
for b, v in sorted(B.blocks.items()):
    if b in ("baselines", "continued_baselines", "cop_reference_chains"):
        continue
    chosen += v["jobs"][:k]
need = set()
def add(r):
    if r in need: return
    for d in ents[r]["deps"]: add(d)
    need.add(r)
for r in chosen: add(r)
order = [e["run_id"] for e in B.entries_list() if e["run_id"] in need]
print(len(order), "jobs", flush=True)
ex = {"device": "cpu", "data_root": data_root, "torch_threads": 2}
res = {}
rows = []
for rid in order:
    e = ents[rid]
    if e["cfg"].get("control", {}).get("device", "cpu") != "cpu":
        continue
    dname = (e["cfg"].get("data") or {}).get("name")
    if dname in exclude and status_of(root, rid)["status"] != "complete":
        res["not_sampled"] = res.get("not_sampled", 0) + 1
        rows.append({"run_id": rid, "blocks": e["blocks"], "kind": e["cfg"]["kind"], "status": "not_sampled",
                     "validity": None, "reason": f"dataset {dname} excluded from this CPU sample", "seconds": 0})
        print("NOTSAMPLED", e["blocks"], e["cfg"]["kind"], dname, flush=True)
        continue
    if any(status_of(root, d)["status"] != "complete" for d in e["deps"]):
        res["skipped_dep"] = res.get("skipped_dep", 0) + 1
        rows.append({"run_id": rid, "blocks": e["blocks"], "kind": e["cfg"]["kind"], "status": "skipped_dep",
                     "validity": None, "reason": "a prerequisite is not complete in this sample", "seconds": 0})
        print("SKIPDEP", e["blocks"], e["cfg"]["kind"], flush=True)
        continue
    t = time.time()
    INTERRUPT["flag"] = False
    st = run_job(e["cfg"], root, ex, time_limit=limit)
    res[st] = res.get(st, 0) + 1
    s = status_of(root, rid)
    rows.append({"run_id": rid, "blocks": e["blocks"], "kind": e["cfg"]["kind"], "status": st,
                 "validity": s.get("validity"), "reason": s.get("reason"), "seconds": round(time.time() - t, 1)})
    if st != "complete":
        print("NOTCOMPLETE", st, e["blocks"], e["cfg"]["kind"], s.get("reason"), flush=True)
    else:
        print("ok", round(time.time() - t, 1), e["blocks"][0], e["cfg"]["kind"], s.get("validity"), flush=True)
json.dump({"counts": res, "jobs": rows}, open(root / f"sample_w{'_'.join(map(str, waves))}.json", "w"), indent=1)
print(res)
