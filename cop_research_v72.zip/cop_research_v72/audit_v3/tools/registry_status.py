"""Per-variant status of the strengthening registry from a wave-7 manifest and a results root.
Usage: python audit_v3/tools/registry_status.py MANIFEST.jsonl RESULTS_ROOT REGISTRY.json OUT.json"""
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

man, res, reg, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]), Path(sys.argv[4])
cov = json.load(open(man.with_suffix(".coverage.json")))["strengthening"]
entries = [json.loads(l) for l in open(man)]
by_variant = defaultdict(list)
for e in entries:
    d = e["cfg"].get("design") or {}
    if d.get("variant"):
        by_variant[d["variant"]].append(e["run_id"])


def status(rid):
    p = res / "runs" / rid / "status.json"
    return json.load(open(p))["status"] if p.exists() else "missing"


registry = json.load(open(reg))
rows = {}
for fam in registry["families"]:
    for v in fam["variants"]:
        vid = v["id"]
        st = Counter(status(r) for r in by_variant.get(vid, []))
        rows[vid] = {"family": fam["family"], "intervention": v["intervention"],
                     "blocks": cov["variants"].get(vid, []), "design_jobs": len(by_variant.get(vid, [])),
                     "smoke_status": dict(st),
                     "status": "implemented, exercised at smoke scale (CPU)" if st.get("complete") else
                     "implemented, not exercised"}
extra = {k: {"blocks": cov["variants"][k], "design_jobs": len(by_variant.get(k, [])),
             "smoke_status": dict(Counter(status(r) for r in by_variant.get(k, [])))}
         for k in cov["variants"] if k not in rows}
json.dump({"registry_schema": registry["schema"], "variants": rows, "mechanisms_and_crosses": extra,
           "inapplicable": cov["inapplicable"], "manifest": man.name, "results_note":
           "smoke-scale CPU statuses show that code paths run; they are not results"}, open(out, "w"), indent=1)
print("wrote", out, {k: v["smoke_status"] for k, v in list(rows.items())[:3]})
