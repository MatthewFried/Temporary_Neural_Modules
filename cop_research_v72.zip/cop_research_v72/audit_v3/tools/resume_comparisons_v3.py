"""v3 job-level interrupted-vs-uninterrupted comparisons for the strengthening
extension (cycles, dissipation methods, repair ladder, continuation arms,
transplants, peg bridges and route erasure).
Usage: python audit_v3/tools/resume_comparisons_v3.py OUT_DIR [case,case,...]"""
import os, sys, json, shutil, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / "tests"))
import torch; torch.set_num_threads(2)
import tiny_configs as T
from resume_harness import compare_interrupted
from cop.config import resolve, run_id
root = Path(sys.argv[1]); shutil.rmtree(root, ignore_errors=True); root.mkdir(parents=True)
TR = {**T.TRAIN, "checkpoint_every": 7}
b = T.base(train=TR)
P = {"baseline": run_id(b)}
rb = T.traj({"topology": "recursive_branch"}, train=TR)
dis = rb + [T.child("dissipation", rb[-1], {"dissipation": {"method": "abrupt", "post_updates": 12}})]


def D(p, sec):
    return p + [T.child("dissipation", p[-1], {"dissipation": {"speed_updates": 10, "post_updates": 10,
                                                                "path_eval_points": 3, **sec}})]


def R(p, sec):
    return p + [T.child("repair", p[-1], {"repair": {"budget_multiplier": 0.5, "eval_points": 2, **sec}})]


def Cn(sec, parents, pre):
    return pre + [resolve({"kind": "continue", "data": T.DATA, "model": T.MODEL, "train": TR, "seeds": {"optimizer": 0},
                           "parents": parents, "continue": sec})]


cases = {
    "cycles_gate": T.traj({"topology": "layered", "rounds": 2, "contract_every": 1, "contract_updates": 8}, train=TR),
    "cycles_abrupt_moving": T.traj({"topology": "layered", "rounds": 2, "contract_every": 1, "contract_updates": 8,
                                    "contract_method": "abrupt", "cycle_cut": "moving"}, train=TR),
    "cycles_nested": T.traj({"topology": "recursive", "rounds": 2, "contract_every": 2, "contract_updates": 8}, train=TR),
    "traj_freeze_release_snap": T.traj({"topology": "layered", "rounds": 2}, train={**TR, "freeze_schedule": "release",
                                       "release_after": 5, "snapshot_at": [3, 20]}),
    "traj_twin_alternate": T.traj({"topology": "twin_helpers", "rounds": 1, "helper_schedule": "alternate",
                                   "helper_period": 5}, train=TR),
    "diss_fold": D(T.traj({"topology": "node_split", "rounds": 1}, train=TR), {"method": "fold"}),
    "diss_stochastic_bypass": D(rb, {"method": "stochastic_bypass", "bypass_keep": 0.5, "bypass_rescale": True}),
    "diss_newest_first": D(T.traj({"topology": "tree_depth2", "rounds": 3}, train=TR), {"method": "linear",
                                                                                         "order": "newest_first"}),
    "repair_fresh_preserve": R(rb, {"region": "full", "data_access": "fresh", "opt_state": "preserve"}),
    "repair_readout": R(rb, {"region": "readout", "deletion": "all"}),
    "continue_C2": Cn({"budget": "parent_compute", "budget_parent": "treated", "segments": [15, 15, 6]},
                      {**P, "treated": run_id(dis[-1])}, [b] + dis),
    "continue_distill": Cn({"updates": 20, "arm": "distill", "teacher": "teacher", "teacher_stage": "final",
                            "distill_alpha": 0.5}, {**P, "teacher": run_id(rb[-1])}, [b] + rb),
    "continue_prune_regrow": Cn({"updates": 30, "arm": "prune_regrow", "prune_period": 10, "prune_duration": 4}, P, [b]),
    "continue_perturb": Cn({"updates": 20, "segments": [10, 10], "arm": "perturb", "perturb_rel": 0.05}, P, [b]),
    "cop_bridge_route_erasure": T.cop({"route_blocks": 2, "route_repair_updates": 6},
                                      {"temp_channel": 4, "temp_open_updates": 5, "temp_on": "middle",
                                       "temp_target": "peg", "route_dropout": 0.5, "mode": "uniform", "bits": 3},
                                      train=TR),
    "cop_repetition": T.cop({}, {"redundancy": 2, "mode": "uniform", "bits": 3, "route_dropout": 0.5}, train=TR),
}
only = sys.argv[2].split(",") if len(sys.argv) > 2 else None
rep = {}
for name, cfgs in cases.items():
    if only and name not in only:
        continue
    t = time.time()
    try:
        r = compare_interrupted(cfgs, root / name, ex={"device": os.environ.get("DEVICE", "cpu"),
                                                       "data_root": os.environ.get("COP_DATA_ROOT")})
    except Exception as e:
        import traceback; traceback.print_exc(); r = {"error": repr(e)}
    rep[name] = r
    print(name, round(time.time() - t, 1), {k: r.get(k) for k in ("equal", "attempts", "interrupted_at_polls",
          "polls_uninterrupted", "checkpoints_differing", "n_metrics_differing", "results_differing", "work_equal",
          "error")}, flush=True)
json.dump(rep, open(root / "report.json", "w"), indent=1, default=str)
