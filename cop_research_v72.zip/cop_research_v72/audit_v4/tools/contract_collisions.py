"""Pairing-key collisions when full- and pilot-scale wave-7 results share one results root, under the
v4 contract key (contrast, f0 run, arm, replication, budget panel) and under the v3 label-only key.
Usage: python audit_v4/tools/contract_collisions.py OUT.json"""
import json
import sys
from collections import defaultdict
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from cop.orchestration.manifest import generate
from cop.analysis.strengthening import _rk


def f0_of(entries, rid):
    c = entries[rid]["cfg"]
    if c["kind"] == "baseline":
        return rid
    par = c.get("parents") or {}
    for role in ("baseline", "trajectory", "start", "treated", "upstream", "downstream"):
        if role in par and par[role] in entries:
            r = f0_of(entries, par[role])
            if r:
                return r
    return None


v3, v4 = defaultdict(list), defaultdict(list)
for scale in ("full", "pilot"):
    B = generate([7], scale)
    for rid, e in B.entries.items():
        d = e["cfg"].get("design") or {}
        if not d.get("contrast"):
            continue
        v3[(d["contrast"], d["arm"], _rk(e["cfg"]))].append([scale, rid])
        v4[(d["contrast"], f0_of(B.entries, rid), d["arm"], _rk(e["cfg"]), d.get("budget_panel", ""))].append([scale, rid])
out = {"v3_label_key_collisions": sum(len(v) > 1 for v in v3.values()),
       "v4_contract_key_collisions": sum(len(v) > 1 for v in v4.values()),
       "v4_examples": [[list(map(str, k)), v] for k, v in v4.items() if len(v) > 1][:5],
       "n_design_entries": sum(len(v) for v in v4.values())}
json.dump(out, open(sys.argv[1], "w"), indent=1)
print(out)
