"""Fresh-process checkpoint round trip (V3-10, deliverable D): for every run under RESULTS with an
endpoint.json, reload the named endpoint checkpoint in THIS process (not the one that trained it),
predict the test partition and compare with the predictions saved at the endpoint evaluation; the same
for every saved transplant model.  Usage:
  python audit_v4/tools/fresh_reload.py RESULTS OUT.json [--device cpu] [--data-root DIR] [--limit N]"""
import argparse
import json
import sys
from collections import Counter
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import torch
from cop.graph.graph import GraphNet
from cop.graph.accounting import architecture_hash
from cop.data.registry import load_bundle
from cop.train.trainer import predict

ap = argparse.ArgumentParser()
ap.add_argument("results")
ap.add_argument("out")
ap.add_argument("--device", default="cpu")
ap.add_argument("--data-root", default=None)
ap.add_argument("--limit", type=int, default=0)
a = ap.parse_args()
bundles = {}
rows = []


def check(rd, cfg, ckpt, preds, expect_arch=None):
    key = json.dumps(cfg["data"], sort_keys=True)
    if key not in bundles:
        bundles[key] = load_bundle(cfg["data"], a.data_root, device="cpu").to(a.device)
    b = bundles[key]
    ck = torch.load(rd / "ckpt" / f"{ckpt}.pt", map_location="cpu", weights_only=False)
    g = GraphNet.from_checkpoint(ck["model"], a.device)
    y = predict(g, b.partitions()["test"], cfg.get("train", {}).get("eval_batch", 4096)).detach()
    y = (y.float() if y.is_floating_point() else y).cpu()
    ref = torch.load(preds, map_location="cpu", weights_only=False)
    same = bool(torch.equal(y, ref)) if y.shape == ref.shape else False
    finite = bool(torch.isfinite(ref).all()) if ref.is_floating_point() else True
    r = {"run": rd.name, "kind": cfg["kind"], "checkpoint": ckpt, "bitwise_equal": same,
         "max_abs_diff": float((y - ref).abs().max()) if (y.shape == ref.shape and finite) else None,
         "saved_predictions_finite": finite}
    if expect_arch is not None:
        r["architecture_hash_equal"] = architecture_hash(g) == expect_arch
    return r


runs = sorted((Path(a.results) / "runs").glob("*"))
n = 0
for rd in runs:
    if a.limit and n >= a.limit:
        break
    ep_p = rd / "endpoint.json"
    if not ep_p.exists():
        continue
    cfg = json.load(open(rd / "config.json"))
    ep = json.load(open(ep_p))
    pp = rd / "preds" / "endpoint__test.pt"
    if pp.exists():
        rows.append(check(rd, cfg, ep["checkpoint"], pp, ep["architecture_hash"]))
        n += 1
for rd in runs:
    tr = rd / "transplant_result.json"
    if not tr.exists():
        continue
    cfg = json.load(open(rd / "config.json"))
    for name, s in json.load(open(tr))["info"].get("saved_models", {}).items():
        pp = rd / "preds" / f"{name}__test.pt"
        if pp.exists():
            rows.append(check(rd, cfg, s["checkpoint"], pp))
summary = {"n_checked": len(rows), "bitwise_equal": sum(r["bitwise_equal"] for r in rows),
           "architecture_equal": sum(bool(r.get("architecture_hash_equal", True)) for r in rows),
           "by_kind": dict(Counter(r["kind"] for r in rows)),
           "not_equal": [r for r in rows if not r["bitwise_equal"]][:50], "device": a.device,
           "note": "non-finite saved predictions (diverged endpoints) compare as NaN != NaN and are listed"}
json.dump({"summary": summary, "rows": rows}, open(a.out, "w"), indent=1)
print(json.dumps(summary, indent=1)[:2000])
