"""Independent v3 audit probes (v4 adapter: analysis_contract only; see the comment there). Supply an unchanged source tree and output directory.
These probes record behavior, including defects; they are not a passing acceptance suite.
Usage: python independent_probes.py SOURCE OUTPUT
"""
import sys, json, copy, traceback, hashlib
from pathlib import Path
from collections import defaultdict, Counter
SRC, OUT = map(lambda x: Path(x).resolve(), sys.argv[1:3])
OUT.mkdir(parents=True, exist_ok=True)
sys.path[:0] = [str(SRC), str(SRC / 'tests')]
import torch
torch.set_num_threads(1)
import tiny_configs as T
from cop.analysis.strengthening import compact_gain, endpoint_table, _rk
from cop.analysis.summarize import load_runs
from cop.orchestration.manifest import generate
from cop.orchestration.runner import run_job, status_of
from cop.config import resolve, run_id, TRAIN_DEFAULTS
from cop.utils import read_json, torch_gen
from cop.graph.graph import GraphNet
from cop.graph.accounting import architecture_hash, count_params
from cop.graph.builders import build_mlp
from cop.cop_pegs.transplant import fit_affine_alignment
from cop.train.trainer import Trainer, Segment
from cop.data.registry import load_bundle
R = {'torch': torch.__version__, 'cuda_available': torch.cuda.is_available()}

def probe(name, fn):
    try: R[name] = fn()
    except Exception as e: R[name] = {'probe_error': repr(e), 'traceback': traceback.format_exc()}
    (OUT / 'independent_results.json').write_text(json.dumps(R, indent=2, default=str))
    print(name, json.dumps(R[name], default=str)[:1600], flush=True)

def row(rid, arm, risk, **extra):
    return dict(run_id=rid, kind='dissipation', status='complete', validity='valid',
                test_risk=risk, design_contrast='same-label', design_arm=arm,
                design_budget_panel='updates', replication='data0_teacher0_opt0',
                compact=True, condition_id='condition-A', data='teacher', model='mlp', **extra)

def analysis_contract():
    t, c = row('treated', 'treated', .2), row('control', 'C1', .5)
    bad = copy.deepcopy(t); bad['compact'] = False
    mismatch = copy.deepcopy(c); mismatch.update(data='fashion_mnist', model='cnn', condition_id='B',
                                                 design_target_regime='T0')
    dup = copy.deepcopy(c); dup.update(run_id='other-control', test_risk=2.0, condition_id='C')
    # v4 adapter: compact_gain raises ValueError on duplicated pairing keys by default (the supplied
    # gate test_duplicate_pairs_must_be_rejected requires it); the non-strict mode excludes every entry
    # of a duplicated key and records it, so both orders give the same (empty) result
    try:
        compact_gain([t, c, dup]); strict = 'accepted'
    except ValueError as e:
        strict = 'ValueError: ' + str(e)
    return {'noncompact_accepted': compact_gain([bad,c])[1],
            'incompatible_accepted': compact_gain([t,mismatch])[1],
            'duplicate_strict': strict,
            'duplicate_forward': compact_gain([t,c,dup], strict=False)[1],
            'duplicate_reverse': compact_gain([t,dup,c], strict=False)[1]}
probe('analysis_contract', analysis_contract)

def manifest_audit():
    B = generate([7], 'full')
    keys=defaultdict(list); kinds=Counter(); cop_controls=[]; missing=[]
    for rid,e in B.entries.items():
        c=e['cfg']; d=c.get('design') or {}; kinds[c['kind']]+=1
        if d.get('contrast'): keys[(d['contrast'], d['arm'], _rk(c))].append(rid)
        for dep in e['deps']:
            if dep not in B.entries: missing.append([rid,dep])
        if c['kind']=='continue' and d.get('arm')=='C1' and 'treated' in c['parents']:
            tc=B.entries[c['parents']['treated']]['cfg']
            if tc['kind']=='cop':
                cop_controls.append({'variant':d['variant'],'contrast':d['contrast'],
                                     'cop_task':tc['cop']['task_kind'], 'start':c['continue']['start'],
                                     'start_kind': B.entries[c['parents']['baseline']]['cfg']['kind']})
    P=generate([7], 'pilot'); combined=defaultdict(list)
    for scale, builder in [('full',B),('pilot',P)]:
        for rid,e in builder.entries.items():
            d=e['cfg'].get('design') or {}
            if d.get('contrast'): combined[(d['contrast'],d['arm'],_rk(e['cfg']))].append([scale,rid])
    collision={str(k):v for k,v in combined.items() if len(v)>1}
    return {'jobs':len(B.entries),'kinds':dict(kinds),
            'duplicate_pair_keys':{str(k):v for k,v in keys.items() if len(v)>1},
            'full_plus_pilot_duplicate_pair_keys':len(collision),'full_plus_pilot_examples':dict(list(collision.items())[:3]),
            'missing_dependencies':missing,'cop_C1_count':len(cop_controls),
            'cop_C1_examples':cop_controls[:6],
            'all_continue_plain_segments':dict(Counter(str(e['cfg']['continue']['segments']) for e in B.entries.values()
                                                    if e['cfg']['kind']=='continue' and e['cfg']['continue']['arm']=='plain'))}
probe('manifest_audit', manifest_audit)

def alignment_devices():
    x=torch.randn(20,4); y=x@torch.randn(4,4)+1
    _,cpu=fit_affine_alignment(x,y)
    try:
        fit_affine_alignment(torch.empty(20,4,device='meta'),torch.empty(20,4,device='meta'))
        meta='unexpected success'
    except Exception as e: meta=str(e)
    return {'cpu':cpu,'meta_device_check_error':meta,'note':'Meta checks factory placement, not a CUDA execution test.'}
probe('alignment_devices', alignment_devices)

ROOT=OUT/'runs_smoke'
def run(c):
    s=run_job(c,ROOT,{'device':'cpu'})
    if s!='complete': raise RuntimeError((s,status_of(ROOT,run_id(c))))
    return ROOT/'runs'/run_id(c)

def actual_cop_comparison():
    cfgs=T.cop({}, {'dim':4})
    d={'family':'audit','variant':'audit','arm':'treated','contrast':'audit_real_cop','budget_panel':'','target_regime':'T1'}
    cfgs[-1]=resolve({**cfgs[-1],'design':d})
    for c in cfgs: run(c)
    b,c=cfgs
    ctl=resolve({'kind':'continue','data':c['data'],'model':c['model'],'train':c['train'],
                 'parents':{'baseline':run_id(b),'treated':run_id(c)},
                 'continue':{'budget':'parent_updates','budget_parent':'treated'},
                 'design':{**d,'arm':'C1','budget_panel':'updates'}})
    run(ctl)
    runs=load_runs(ROOT); endpoints=endpoint_table(runs); pairs=compact_gain(endpoints)[1]
    bm=GraphNet.from_checkpoint(torch.load(ROOT/'runs'/run_id(b)/'ckpt'/'baseline.pt',weights_only=False)['model'],'cpu')
    cm=GraphNet.from_checkpoint(torch.load(ROOT/'runs'/run_id(c)/'ckpt'/'export.pt',weights_only=False)['model'],'cpu')
    return {'f0_params':count_params(bm),'cop_params':count_params(cm),
            'same_architecture':architecture_hash(bm)==architecture_hash(cm),
            'endpoints':endpoints,'computed_pairs':pairs}
probe('actual_cop_comparison', actual_cop_comparison)

def fixed_relearned():
    out={}
    for mode in ['fixed','relearned']:
        cfgs=T.cop({'task_kind':'cycles','cycles':2,'n_pearls':3,'cycle_pegs':mode},
                   {'dim':4,'mode':'uniform','bits':2})
        for c in cfgs: rd=run(c)
        ck=torch.load(rd/'ckpt'/'export.pt',weights_only=False)
        g=GraphNet.from_checkpoint(ck['model'],'cpu')
        out[mode]={'quantizer_dims':[g.mods[g.nodes[n].pkey].k for n in g.topo_order(g.live_nodes()) if g.nodes[n].op=='quant'],
                   'params':count_params(g),'result':read_json(rd/'cycles_result.json')}
    return out
probe('fixed_relearned', fixed_relearned)

def transplant_saved():
    b=T.base(); run(b)
    tp=resolve({'kind':'transplant','data':b['data'],'model':b['model'],'train':b['train'],
                'parents':{'upstream':run_id(b),'downstream':run_id(b)},
                'transplant':{'upstream_stage':'baseline','downstream_stage':'baseline','align':'affine'}})
    rd=run(tp)
    return {'result':read_json(rd/'transplant_result.json'),
            'checkpoint_files':[str(p.relative_to(rd)) for p in rd.rglob('*.pt')]}
probe('transplant_saved', transplant_saved)

def train_counts_and_last_step():
    bundle=load_bundle(T.DATA)
    out={}
    for policy in ['none','original_frozen']:
        from cop.graph import edits as E
        g=build_mlp(8,[16,16],3,torch_gen(0,'init'))
        iid=E.insert_residual_zero(g,E.cut_at(g,'post_act',0),torch_gen(0,'insertion'),width=4)
        tc=dict(TRAIN_DEFAULTS,batch_size=32,freeze=policy)
        tr=Trainer(g,bundle,tc,{'minibatch':0,'augmentation':0},'cpu')
        tr.configure(policy,iid); tr.run(Segment('audit',1))
        out[policy]={'train_macs':tr.state['train_macs'],'trainable_params':sum(p.numel() for p in g.parameters() if p.requires_grad)}
    # Finite loss, overflowing final optimizer update; does the trainer mark divergence?
    g=build_mlp(8,[4],3,torch_gen(0,'init'))
    tc=dict(TRAIN_DEFAULTS,batch_size=32,optimizer='sgd',lr=1e38,grad_clip=0.)
    tr=Trainer(g,bundle,tc,{'minibatch':0,'augmentation':0},'cpu');tr.configure('none',None)
    def huge_finite(out,batch,X): return out.sum()*1e10
    tr.run(Segment('last_step',1,target='custom',target_fn=huge_finite))
    out['overflow']={'diverged':tr.state.get('diverged'),
                      'all_params_finite':all(bool(torch.isfinite(p).all()) for p in g.parameters()),
                      'step':tr.state['global_step']}
    return out
probe('train_counts_and_last_step',train_counts_and_last_step)

def repair_divergence_endpoint():
    cfgs=T.traj({'topology':'layered','rounds':1,'updates_per_round':5})
    for c in cfgs: run(c)
    c=T.child('repair',cfgs[-1],{'repair':{'region':'full','deletion':'all','budget_multiplier':4.,
                                        'eval_points':2,'extension_factor':1.}})
    c=resolve({**c,'train':{**c['train'],'optimizer':'sgd','lr':1e38,'grad_clip':0.},
               'design':{'family':'audit','variant':'divergence','arm':'treated','contrast':'audit_divergence'}})
    rd=run(c)
    result=read_json(rd/'repair_result.json')
    ck=torch.load(rd/'ckpt'/'after_repair.pt',weights_only=False)
    g=GraphNet.from_checkpoint(ck['model'],'cpu')
    endpoints=endpoint_table(load_runs(ROOT)); row_=next(e for e in endpoints if e['run_id']==run_id(c))
    from cop.train.trainer import evaluate
    actual=evaluate(g,load_bundle(c['data']),['test'],128)[0]['test']
    return {'status':status_of(ROOT,run_id(c)), 'repair_diverged':result['diverged'],
            'updates_done':result['updates_done'],'curve_updates':[x['update'] for x in result['curve']],
            'checkpoint_all_finite':all(bool(torch.isfinite(p).all()) for p in g.parameters()),
            'checkpoint_actual_test_metrics':actual,
            'reported_endpoint':row_, 'gain_pairs_including_diverged':compact_gain([row_])[1]}
probe('repair_divergence_endpoint',repair_divergence_endpoint)

def architecture_sharing():
    g=build_mlp(8,[8,8,8],3,torch_gen(0,'init')); h=g.clone(share_params=False)
    hidden=[n for n in h.topo_order() if h.nodes[n].op=='linear' and n!=h.output]
    old=h.nodes[hidden[1]].pkey
    h.nodes[hidden[1]].pkey=h.nodes[hidden[0]].pkey
    del h.mods[old]
    h._plan=None
    return {'equal_hashes':architecture_hash(g)==architecture_hash(h),
            'independent_params':count_params(g)['total'],'tied_params':count_params(h)['total']}
probe('architecture_sharing',architecture_sharing)
print('WROTE',OUT/'independent_results.json')
