"""Deliverable E: machine-readable rejected examples built from a real results root.  Takes the
endpoint table of RESULTS and injects (a) a duplicated control row, (b) a control row with another
data identity, (c) a treated endpoint flagged diverged, then reports what compact_gain does with them
(strict mode raises; non-strict excludes and records), plus how a real CoP export is classified
against its f0-built C1 control and its endpoint-matched M1 control.
Usage: python audit_v4/tools/rejection_examples.py RESULTS OUT.json"""
import copy
import json
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from cop.analysis.summarize import load_runs
from cop.analysis.strengthening import endpoint_table, compact_gain, classify_pair

runs = load_runs(Path(sys.argv[1]))
E = [e for e in endpoint_table(runs) if e["eligible"]]
out = {"n_endpoints_eligible": len(E)}
# pick a fixed-architecture contrast with a treated row and a C1 control in one replication
by = {}
for e in E:
    by.setdefault((e["design_contrast"], e["f0_run"], e["replication"]), {})[e["design_arm"]] = e
grp = next(v for k, v in sorted(by.items(), key=lambda kv: str(kv[0]))
           if "treated" in v and "C1" in v and classify_pair(v["treated"], v["C1"])[0] == "fixed_architecture")
t, c1 = grp["treated"], grp["C1"]
dupe = dict(copy.deepcopy(c1), run_id=c1["run_id"] + "_duplicate", test_risk=(c1["test_risk"] or 0) + 1.0)
inc_t = dict(copy.deepcopy(t), design_contrast=t["design_contrast"] + "#incompat", run_id=t["run_id"] + "_t2")
inc_c = dict(copy.deepcopy(c1), design_contrast=t["design_contrast"] + "#incompat", run_id=c1["run_id"] + "_otherdata",
             data_identity=c1["data_identity"].replace("}", ', "n_train": 999999}'))
div_t = dict(copy.deepcopy(t), design_contrast=t["design_contrast"] + "#div", run_id=t["run_id"] + "_diverged",
             diverged=True, diverged_reason="non-finite parameters after update 1 (injected)")
div_c = dict(copy.deepcopy(c1), design_contrast=t["design_contrast"] + "#div")
E2 = E + [dupe, inc_t, inc_c, div_t, div_c]
try:
    compact_gain(E2, "test_risk", "fixed_architecture", strict=True)
    out["strict"] = "no error (unexpected)"
except ValueError as ex:
    out["strict"] = f"ValueError: {ex}"
rej = []
summ, pairs = compact_gain(E2, "test_risk", "fixed_architecture", strict=False, rejected=rej)
names = {t["design_contrast"], t["design_contrast"] + "#incompat", t["design_contrast"] + "#div"}
out["injected"] = {"duplicate_of": c1["run_id"], "incompatible_data_control": inc_c["run_id"],
                   "diverged_treated": div_t["run_id"]}
out["rejected"] = [r for r in rej if any(x in (r.get("run_id") or "") or x in (r.get("treated_run") or "")
                                         for x in (c1["run_id"], t["run_id"]))]
out["summary_rows_for_injected_contrasts"] = [s for s in summ if s["contrast"] in names]
# real CoP export: C1 from f0 versus endpoint-matched M1
ex = []
for k, v in sorted(by.items(), key=lambda kv: str(kv[0])):
    tt = v.get("treated")
    if tt and tt["kind"] == "cop":
        for arm in ("C1", "M1", "M2"):
            if arm in v:
                est, why = classify_pair(tt, v[arm])
                ex.append({"contrast": k[0], "treated_run": tt["run_id"], "control_arm": arm,
                           "control_run": v[arm]["run_id"], "treated_arch": tt["architecture_hash"],
                           "control_arch": v[arm]["architecture_hash"], "f0_arch": tt["f0_architecture_hash"],
                           "treated_params": tt.get("endpoint_params"), "control_params": v[arm].get("endpoint_params"),
                           "estimand": est, "why": why})
    if len(ex) >= 12:
        break
out["cop_export_classification"] = ex
json.dump(out, open(sys.argv[2], "w"), indent=1, default=str)
print(out["strict"]); print(json.dumps(out["rejected"], indent=1, default=str)[:2500])
print(json.dumps(ex[:6], indent=1)[:2500])
