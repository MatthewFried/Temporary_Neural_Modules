"""v4 job-level interrupted-vs-uninterrupted comparisons: every v3 case, rerun on v4 code (endpoint.json
is now compared as well), plus the v4 paths: C8 ending inside a prune window, an endpoint-matched CoP
control (M1), the replay contraction schedule, an aligned transplant, the cycle peg switches and a
repair whose final evaluation is forced at the endpoint.
Usage: python audit_v4/tools/resume_comparisons_v4.py OUT_DIR [case,case,...]   (DEVICE=cuda for the GPU)"""
import os, sys, json, shutil, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / "tests"))
import torch; torch.set_num_threads(2)
import tiny_configs as T
from resume_harness import compare_interrupted
from cop.config import resolve, run_id
root = Path(sys.argv[1]); shutil.rmtree(root, ignore_errors=True); root.mkdir(parents=True)
TR = {**T.TRAIN, "checkpoint_every": 7}
b = T.base(train=TR)
P = {"baseline": run_id(b)}
rb = T.traj({"topology": "recursive_branch"}, train=TR)
dis = rb + [T.child("dissipation", rb[-1], {"dissipation": {"method": "abrupt", "post_updates": 12}})]


def D(p, sec):
    return p + [T.child("dissipation", p[-1], {"dissipation": {"speed_updates": 10, "post_updates": 10,
                                                                "path_eval_points": 3, **sec}})]


def R(p, sec):
    return p + [T.child("repair", p[-1], {"repair": {"budget_multiplier": 0.5, "eval_points": 2, **sec}})]


def Cn(sec, parents, pre):
    return pre + [resolve({"kind": "continue", "data": T.DATA, "model": T.MODEL, "train": TR, "seeds": {"optimizer": 0},
                           "parents": parents, "continue": sec})]


cases = {
    "cycles_gate": T.traj({"topology": "layered", "rounds": 2, "contract_every": 1, "contract_updates": 8}, train=TR),
    "cycles_abrupt_moving": T.traj({"topology": "layered", "rounds": 2, "contract_every": 1, "contract_updates": 8,
                                    "contract_method": "abrupt", "cycle_cut": "moving"}, train=TR),
    "cycles_nested": T.traj({"topology": "recursive", "rounds": 2, "contract_every": 2, "contract_updates": 8}, train=TR),
    "traj_freeze_release_snap": T.traj({"topology": "layered", "rounds": 2}, train={**TR, "freeze_schedule": "release",
                                       "release_after": 5, "snapshot_at": [3, 20]}),
    "traj_twin_alternate": T.traj({"topology": "twin_helpers", "rounds": 1, "helper_schedule": "alternate",
                                   "helper_period": 5}, train=TR),
    "diss_fold": D(T.traj({"topology": "node_split", "rounds": 1}, train=TR), {"method": "fold"}),
    "diss_stochastic_bypass": D(rb, {"method": "stochastic_bypass", "bypass_keep": 0.5, "bypass_rescale": True}),
    "diss_newest_first": D(T.traj({"topology": "tree_depth2", "rounds": 3}, train=TR), {"method": "linear",
                                                                                         "order": "newest_first"}),
    "repair_fresh_preserve": R(rb, {"region": "full", "data_access": "fresh", "opt_state": "preserve"}),
    "repair_readout": R(rb, {"region": "readout", "deletion": "all"}),
    "continue_C2": Cn({"budget": "parent_compute", "budget_parent": "treated", "segments": [15, 15, 6]},
                      {**P, "treated": run_id(dis[-1])}, [b] + dis),
    "continue_distill": Cn({"updates": 20, "arm": "distill", "teacher": "teacher", "teacher_stage": "final",
                            "distill_alpha": 0.5}, {**P, "teacher": run_id(rb[-1])}, [b] + rb),
    "continue_prune_regrow": Cn({"updates": 30, "arm": "prune_regrow", "prune_period": 10, "prune_duration": 4}, P, [b]),
    "continue_perturb": Cn({"updates": 20, "segments": [10, 10], "arm": "perturb", "perturb_rel": 0.05}, P, [b]),
    "cop_bridge_route_erasure": T.cop({"route_blocks": 2, "route_repair_updates": 6},
                                      {"temp_channel": 4, "temp_open_updates": 5, "temp_on": "middle",
                                       "temp_target": "peg", "route_dropout": 0.5, "mode": "uniform", "bits": 3},
                                      train=TR),
    "cop_repetition": T.cop({}, {"redundancy": 2, "mode": "uniform", "bits": 3, "route_dropout": 0.5}, train=TR),
}

cop_tr = T.cop({}, {"dim": 4, "mode": "uniform", "bits": 2}, train=TR)
cases.update({
    "continue_C8_end_mid_prune": Cn({"updates": 13, "arm": "prune_regrow", "prune_period": 10, "prune_duration": 5},
                                    P, [b]),
    "continue_M1_endpoint_matched": [cop_tr[0], cop_tr[1], resolve({
        "kind": "continue", "data": cop_tr[1]["data"], "model": cop_tr[1]["model"], "train": TR,
        "seeds": {"optimizer": 0}, "parents": {"baseline": run_id(cop_tr[0]), "treated": run_id(cop_tr[1])},
        "continue": {"start": "treated", "start_stage": "export", "reinit": True, "budget": "parent_updates",
                     "budget_parent": "treated", "budget_add_f0": True}})],
    "cop_cycles_learned_constant": T.cop({"task_kind": "cycles", "cycles": 2, "n_pearls": 3, "cycle_pegs": "relearned",
                                          "cycle_peg_maps": "learned", "cycle_peg_width": "constant",
                                          "cycle_peg_recalibrate": "yes"}, {"dim": 4, "mode": "uniform", "bits": 2},
                                         train=TR),
    "repair_final_endpoint_eval": R(rb, {"region": "full", "eval_points": 1}),
})
_g = {"topology": "layered", "rounds": 4, "contract_every": 2, "updates_per_round": 6, "contract_updates": 3}
_src = T.traj({**_g, "contract_trigger": "damage", "contract_threshold": -1.0}, train=TR)
cases["traj_replay_schedule"] = _src + [resolve({
    "kind": "trajectory", "data": T.DATA, "model": T.MODEL, "train": TR, "growth": {"width": 8, **_g, "contract_trigger": "replay"},
    "seeds": {"optimizer": 0}, "parents": {"baseline": run_id(_src[0]), "schedule": run_id(_src[-1])}})]
_lay = T.traj({"topology": "layered", "rounds": 2, "contract_every": 1, "contract_updates": 4}, train=TR)
cases["transplant_affine"] = _lay + [resolve({
    "kind": "transplant", "data": T.DATA, "model": T.MODEL, "train": TR, "seeds": {"optimizer": 0},
    "parents": {"upstream": run_id(_lay[0]), "downstream": run_id(_lay[-1])},
    "transplant": {"upstream_stage": "baseline", "downstream_stage": "final", "align": "affine"}})]
only = sys.argv[2].split(",") if len(sys.argv) > 2 else None
unknown = sorted(set(only or []) - set(cases))
rep = {}
for name, cfgs in cases.items():
    if only and name not in only:
        continue
    t = time.time()
    try:
        r = compare_interrupted(cfgs, root / name, ex={"device": os.environ.get("DEVICE", "cpu"),
                                                       "data_root": os.environ.get("COP_DATA_ROOT")})
    except Exception as e:
        import traceback; traceback.print_exc(); r = {"error": repr(e)}
    if r.get("polls_uninterrupted") == 0:
        # no training loop to interrupt (e.g. a transplant): rerun determinism is what can be checked
        r["not_interruptible"] = True
        r["outputs_equal"] = not r["checkpoints_differing"] and not r["n_metrics_differing"] and \
            not r["results_differing"] and r["work_equal"]
    rep[name] = r
    print(name, round(time.time() - t, 1), {k: r.get(k) for k in ("equal", "attempts", "interrupted_at_polls",
          "polls_uninterrupted", "checkpoints_differing", "n_metrics_differing", "results_differing", "work_equal",
          "not_interruptible", "outputs_equal", "error")}, flush=True)
# v8: the verdict is part of the report and decides the exit status (1 on any failure, unknown case or
# empty check set).  Cases without a training loop pass only their documented repeatability check.
from cop.analysis.gates import resume_verdict, write_and_exit
verdict = resume_verdict(rep, allow_not_interruptible={"transplant_affine"})
if unknown:
    verdict["passed"] = False
    verdict["failures"].append({"case": unknown, "reason": "requested cases do not exist"})
write_and_exit(root / "report.json", rep, verdict)
