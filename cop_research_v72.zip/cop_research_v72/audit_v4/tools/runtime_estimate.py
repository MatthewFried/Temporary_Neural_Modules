"""Deliverable G: measured runtime estimate before the full wave-7 grid.

  sample   MANIFEST OUT.jsonl [--per K]   one or K jobs per stratum (kind, block, data, model family),
                                          plus their prerequisite closure, as a runnable sub-manifest
  estimate MANIFEST RESULTS [--workers N] extrapolate: every manifest job gets the mean measured
                                          elapsed seconds of completed jobs of its stratum in RESULTS
                                          (falling back to (kind, data, model), then kind); reports
                                          serial seconds, a wall-clock estimate for N workers (serial/N,
                                          bounded below by the longest dependency chain) and the
                                          coverage of the fallbacks.
Elapsed seconds are summed over a run's attempt records (attempts/*.json), so resumed jobs count fully.
The estimate is only as good as the sample: run the sample on the same device and worker count as
the grid (scripts/11 does this)."""
import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from cop.utils import read_jsonl, read_json


def strata(cfg):
    return ((cfg["kind"], cfg.get("block"), cfg["data"]["name"], cfg["model"]["family"]),
            (cfg["kind"], cfg["data"]["name"], cfg["model"]["family"]), (cfg["kind"],))


def cmd_sample(a):
    ents = {e["run_id"]: e for e in read_jsonl(a.manifest)}
    by = defaultdict(list)
    for rid in sorted(ents):
        by[strata(ents[rid]["cfg"])[0]].append(rid)
    pick = set()
    for k, v in by.items():
        pick |= set(v[:a.per])
    closure, todo = set(), list(pick)
    while todo:
        r = todo.pop()
        if r in closure:
            continue
        closure.add(r)
        todo += [d for d in ents[r]["deps"] if d in ents]
    order = [e for e in read_jsonl(a.manifest) if e["run_id"] in closure]   # manifest order respects deps
    with open(a.out, "w") as f:
        for e in order:
            f.write(json.dumps(e) + "\n")
    print(json.dumps({"strata": len(by), "sampled": len(pick), "with_prerequisites": len(order),
                      "manifest_jobs": len(ents)}))


def _seconds(rd: Path):
    s = 0.0
    att = sorted((rd / "attempts").glob("*.json")) if (rd / "attempts").exists() else []
    for p in att:
        s += float(read_json(p).get("elapsed_seconds") or 0)
    if not att and (rd / "summary.json").exists():
        s = float(read_json(rd / "summary.json").get("elapsed_seconds") or 0)
    return s


def cmd_estimate(a):
    ents = read_jsonl(a.manifest)
    meas = [defaultdict(list) for _ in range(3)]
    for rd in sorted((Path(a.results) / "runs").glob("*")):
        st = rd / "status.json"
        if not st.exists() or read_json(st).get("status") != "complete":
            continue
        cfg = read_json(rd / "config.json")
        sec = _seconds(rd)
        for i, k in enumerate(strata(cfg)):
            meas[i][k].append(sec)
    mean = [{k: sum(v) / len(v) for k, v in m.items()} for m in meas]
    est, level, per_kind = {}, defaultdict(int), defaultdict(float)
    missing = set()
    for e in ents:
        ks = strata(e["cfg"])
        for i, k in enumerate(ks):
            if k in mean[i]:
                est[e["run_id"]] = mean[i][k]
                level[("stratum", "kind_data_model", "kind")[i]] += 1
                break
        else:
            est[e["run_id"]] = 0.0
            level["unmeasured"] += 1
            missing.add(ks[0])
        per_kind[e["cfg"]["kind"]] += est[e["run_id"]]
    # longest dependency chain (critical path) in estimated seconds
    cp = {}
    for e in ents:                                    # manifest order is a topological order
        cp[e["run_id"]] = est[e["run_id"]] + max([cp.get(d, 0.0) for d in e["deps"]] or [0.0])
    serial = sum(est.values())
    res = {"manifest_jobs": len(ents), "measured_runs": sum(len(v) for v in meas[2].values()),
           "estimate_level_counts": dict(level), "unmeasured_strata": sorted(map(list, missing))[:50],
           "serial_seconds": round(serial, 1), "critical_path_seconds": round(max(cp.values() or [0]), 1),
           "workers": a.workers,
           "wall_seconds_estimate": round(max(serial / a.workers, max(cp.values() or [0])), 1),
           "wall_hours_estimate": round(max(serial / a.workers, max(cp.values() or [0])) / 3600, 2),
           "serial_seconds_by_kind": {k: round(v, 1) for k, v in sorted(per_kind.items())},
           "note": "mean of measured jobs per stratum; jobs within a stratum differ in size, so treat this as a "
                   "planning estimate, not a bound"}
    if a.out:
        json.dump(res, open(a.out, "w"), indent=1)
    print(json.dumps(res, indent=1))


ap = argparse.ArgumentParser()
sub = ap.add_subparsers(dest="cmd", required=True)
s = sub.add_parser("sample")
s.add_argument("manifest")
s.add_argument("out")
s.add_argument("--per", type=int, default=1)
s.set_defaults(f=cmd_sample)
s = sub.add_parser("estimate")
s.add_argument("manifest")
s.add_argument("results")
s.add_argument("--workers", type=int, default=1)
s.add_argument("--out", default=None)
s.set_defaults(f=cmd_estimate)
a = ap.parse_args()
a.f(a)
