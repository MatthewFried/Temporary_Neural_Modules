"""Deliverable C: CPU / GPU test matrix from a pytest junit file.
Usage: python audit_v4/tools/test_matrix.py JUNIT.xml OUT_PREFIX [--host-note TEXT]
Writes OUT_PREFIX.json and OUT_PREFIX.md.  Device: a test whose name mentions cuda / gpu needs a CUDA
device; every other test runs on CPU.  dtype notes come from the test source (float64 / bf16 / fp16)."""
import ast
import json
import re
import sys
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
junit, prefix = Path(sys.argv[1]), Path(sys.argv[2])
note = sys.argv[sys.argv.index("--host-note") + 1] if "--host-note" in sys.argv else ""
src_cache = {}


def source_of(file, name):
    if file not in src_cache:
        p = ROOT / file
        src_cache[file] = {}
        if p.exists():
            txt = p.read_text()
            for n in ast.walk(ast.parse(txt)):
                if isinstance(n, ast.FunctionDef):
                    src_cache[file][n.name] = ast.get_source_segment(txt, n) or ""
    return src_cache[file].get(name.split("[")[0], "")


rows = []
for tc in ET.parse(junit).getroot().iter("testcase"):
    cls, name = tc.get("classname", ""), tc.get("name", "")
    file = cls.replace(".", "/") + ".py"
    st, reason = "passed", ""
    for tag in ("failure", "error", "skipped"):
        el = tc.find(tag)
        if el is not None:
            st = {"failure": "failed", "error": "error", "skipped": "skipped"}[tag]
            reason = (el.get("message") or "")[:200]
    src = source_of(file, name)
    gpu = bool(re.search(r"cuda|gpu", name, re.I))
    dt = sorted({d for d, pat in (("float64", r"float64|double\(\)|fp64"), ("bf16", r"bfloat16|bf16"),
                                   ("fp16", r"float16|fp16")) if re.search(pat, src)}) or ["float32"]
    data = "downloaded dataset" if re.search(r"cifar|fashion_mnist|covertype|california", src, re.I) else "synthetic"
    rows.append({"file": file, "test": name, "device": "cuda" if gpu else "cpu", "dtype": dt, "data": data,
                 "status": st, "reason": reason, "seconds": round(float(tc.get("time", 0)), 2)})
cnt = Counter((r["device"], r["status"]) for r in rows)
out = {"junit": junit.name, "host_note": note, "n_tests": len(rows),
       "by_device_status": {f"{d}:{s}": n for (d, s), n in sorted(cnt.items())}, "tests": rows}
json.dump(out, open(prefix.with_suffix(".json"), "w"), indent=1)
L = [f"# Test matrix\n", f"{note}\n" if note else "",
     "| device | passed | failed | error | skipped |", "|---|---|---|---|---|"]
for d in ("cpu", "cuda"):
    L.append(f"| {d} | " + " | ".join(str(cnt.get((d, s), 0)) for s in ("passed", "failed", "error", "skipped")) + " |")
L += ["", "A skipped CUDA test is not validated. `scripts/12_v5_gpu_gates.sh` runs them on the GPU and fails on a skip.",
      "", "## Not passed here", "", "| file | test | device | status | reason |", "|---|---|---|---|---|"]
for r in rows:
    if r["status"] != "passed":
        L.append(f"| {r['file']} | {r['test']} | {r['device']} | {r['status']} | {r['reason']} |")
L += ["", "## Per file", "", "| file | cpu passed | cuda tests | dtypes beyond float32 |", "|---|---|---|---|"]
for f in sorted({r["file"] for r in rows}):
    rr = [r for r in rows if r["file"] == f]
    extra = sorted({d for r in rr for d in r["dtype"] if d != "float32"})
    L.append(f"| {f} | {sum(r['device'] == 'cpu' and r['status'] == 'passed' for r in rr)} / "
             f"{sum(r['device'] == 'cpu' for r in rr)} | {sum(r['device'] == 'cuda' for r in rr)} | {', '.join(extra)} |")
L += ["", f"Full per-test rows (device, dtype, data, status, seconds): `{prefix.with_suffix('.json').name}`.", ""]
open(prefix.with_suffix(".md"), "w").write("\n".join(L))
print(json.dumps(out["by_device_status"]))
