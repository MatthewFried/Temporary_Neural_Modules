"""v34: integrity checks shared by the read-only analysis tools (selective_reversal, cross_transplant,
portability_age).  Every check raises Fail (the one failure type of all three tools) with a reason; nothing here
trains or writes.  This module imports none of the tools.

  job_config        the job folder's config.json, its status complete, and (with a manifest entry) the same config
                    by content hash; the folder name is the manifest's run id
  check_ckpt        a checkpoint's recorded lineage (run id, stage, config hash), its parameter hash recomputed from
                    the saved tensors, its graph hash recomputed from the rebuilt graph, finite floating tensors, no
                    recorded divergence, and the recorded data split hashes equal to the regenerated ones for every
                    partition the analysis uses (missing = failure)
  job_update        updates of a job's own training at a checkpoint (trainer global step minus the start's)
  check_logged_data the job's logged split hashes (log.jsonl 'data' event) equal to the regenerated ones for every
                    partition the analysis uses (missing = failure)
  finite_eval       errors on the requested partitions and the shortcut flip rate; non-finite predictions fail"""
from __future__ import annotations

import json
from pathlib import Path

import torch

from cop.graph.graph import GraphNet
from cop.train.trainer import evaluate
from cop.utils import stable_hash, tensor_hash

EXTRA_PARTS = ("cf_shortcut", "cf_causal", "shift", "rare")


class Fail(Exception):
    """a required analysis of one job failed (the job's rows are not committed)."""


def rj(p: Path) -> dict:
    return json.load(open(p))


def logged_split_hashes(d: Path):
    p = d / "log.jsonl"
    if not p.exists():
        return None
    last = None
    for line in open(p):
        try:
            r = json.loads(line)
        except ValueError:
            continue
        if r.get("event") == "data" and r.get("split_hashes"):
            last = r["split_hashes"]
    return last


def job_config(runs: Path, rid: str, manifest_cfg: dict | None = None) -> dict:
    d = runs / rid
    if not (d / "config.json").exists():
        raise Fail(f"{rid}: job folder or config missing")
    cfg = rj(d / "config.json")
    if manifest_cfg is not None and stable_hash(cfg) != stable_hash(manifest_cfg):
        raise Fail(f"{rid}: config on disk differs from the manifest entry")
    st = rj(d / "status.json") if (d / "status.json").exists() else {}
    if st.get("status") != "complete":
        raise Fail(f"{rid}: status {st.get('status')}")
    return cfg


from declared import DECLARED_PERTURB_OUTCOMES, declared_invalid  # noqa: E402,F401  (v36: json only)


def param_hash_of(ck: dict) -> str:
    return stable_hash({k: tensor_hash(v) for k, v in ck["model"]["state"].items()})


def check_ckpt(ck, label: str, *, run_id: str | None = None, stage: str | None = None, cfg: dict | None = None,
               hashes: dict | None = None, need=()) -> GraphNet:
    """-> the rebuilt graph (CPU, eval mode).  See the module docstring."""
    if ck is None:
        raise Fail(f"{label}: checkpoint missing")
    lin = ck.get("lineage") or {}
    if not lin:
        raise Fail(f"{label}: checkpoint has no lineage record")
    if run_id is not None and lin.get("run_id") != run_id:
        raise Fail(f"{label}: checkpoint belongs to {lin.get('run_id')}, not {run_id}")
    if stage is not None and lin.get("stage") != stage:
        raise Fail(f"{label}: checkpoint stage {lin.get('stage')!r}, expected {stage!r}")
    if cfg is not None and lin.get("cfg_hash") != stable_hash(cfg):
        raise Fail(f"{label}: checkpoint config hash differs from the job's config")
    if not lin.get("param_hash") or param_hash_of(ck) != lin["param_hash"]:
        raise Fail(f"{label}: saved tensors do not match the recorded parameter hash")
    bad = [k for k, v in ck["model"]["state"].items() if v.is_floating_point() and not bool(torch.isfinite(v).all())]
    if bad:
        raise Fail(f"{label}: non-finite tensors {bad[:3]}")
    if (ck.get("numerics") or {}).get("diverged"):
        raise Fail(f"{label}: checkpoint records divergence")
    g = GraphNet.from_checkpoint(ck["model"], "cpu").eval()
    if lin.get("graph_hash") and g.structural_hash() != lin["graph_hash"]:
        raise Fail(f"{label}: rebuilt graph hash differs from the recorded one")
    if hashes is not None:
        sh = lin.get("split_hashes") or {}
        miss = sorted(k for k in need if k not in sh)
        if miss:
            raise Fail(f"{label}: no recorded data hash for {miss}")
        diff = sorted(k for k in need if sh[k] != hashes.get(k))
        if diff:
            raise Fail(f"{label}: regenerated data {diff} differ from the checkpoint's recorded split hashes")
    return g


def trainer_state(ck: dict) -> dict:
    tr = ck.get("trainer") or (ck.get("extra") or {}).get("trainer") or {}
    return tr.get("state") or {}


def job_update(ck: dict, base_ck: dict, label: str) -> int:
    s, b = trainer_state(ck), trainer_state(base_ck)
    if "global_step" not in s or "global_step" not in b:
        raise Fail(f"{label}: no trainer step counter in the checkpoint or its start")
    return int(s["global_step"]) - int(b["global_step"])


def check_logged_data(d: Path, hashes: dict, need, label: str) -> None:
    lg = logged_split_hashes(d)
    if lg is None:
        raise Fail(f"{label}: no logged split hashes (data provenance)")
    miss = sorted(k for k in need if k not in lg)
    if miss:
        raise Fail(f"{label}: no logged data hash for {miss}")
    diff = sorted(k for k in need if lg[k] != hashes.get(k))
    if diff:
        raise Fail(f"{label}: regenerated {diff} differ from the job's logged split hashes")


def eval_partitions(b) -> list[str]:
    parts = b.partitions()
    selp = "val_indep" if "val_indep" in parts else "val"
    return sorted({"val", "test", selp, *[p for p in EXTRA_PARTS if p in parts]} |
                  ({"cf_base"} if "cf_base" in parts and "cf_shortcut" in parts else set()))


def finite_eval(m, b, ps, batch: int, label: str):
    """-> (errors and flip rate, predictions by partition)."""
    r, pr = evaluate(m, b, ps, batch, return_preds=True)
    bad = [p for p, v in pr.items() if v.is_floating_point() and not bool(torch.isfinite(v).all())]
    if bad:
        raise Fail(f"{label}: non-finite predictions on {bad}")
    o = {f"{p}_err": 1.0 - r[p]["acc"] for p in ps}
    if "cf_base" in pr and "cf_shortcut" in pr:
        o["shortcut_flip_rate"] = float((pr["cf_base"].argmax(-1) != pr["cf_shortcut"].argmax(-1)).double().mean())
    return o, pr


def same_function(ref: torch.Tensor, got: torch.Tensor, rel: float = 1e-5) -> tuple[bool, float]:
    """identical decisions and max |diff| <= rel x max(1, max |ref|)."""
    ref, got = ref.detach().double().cpu(), got.detach().double().cpu()
    if ref.shape != got.shape:
        return False, float("inf")
    diff = float((ref - got).abs().max()) if ref.numel() else 0.0
    ok = diff <= rel * max(1.0, float(ref.abs().max()) if ref.numel() else 1.0)
    if ref.dim() == 2:
        ok = ok and bool(torch.equal(ref.argmax(-1), got.argmax(-1)))
    return ok, diff


def manifest_entries(path: str) -> list[dict]:
    ents = [json.loads(l) for l in open(path) if l.strip()]
    ids = [e["run_id"] for e in ents]
    dup = sorted({x for x in ids if ids.count(x) > 1})
    if dup:
        raise Fail(f"manifest has duplicated run ids {dup[:3]}")
    return ents
