#!/usr/bin/env python3
"""v51: two coordinated_edits analyses of the same panel compared decision by decision (e.g. CPU against CUDA).

Equal error rates do not show equal predictions, so the saved decision arrays themselves are compared: for every
saved file (run x table), every candidate network in it and every saved partition (test and the selection
partitions), the number of examples on which the two analyses decide differently.  The pass rule is declared:
at most max(MIN_DECISIONS, ceil(FRACTION x n)) differing decisions per candidate and partition, n taken from the
saved labels.  Aggregate error differences are reported beside it as a separate diagnostic, never as the test.

A backend difference of one decision can move a validation error across a selection threshold, so the selections
(minimal_sets) are compared too and every difference is listed with both analyses' distance to the threshold; a
differing selection is REPORTED (selection_identical false), it does not fail the comparison.

usage: compare_edit_runs.py PREFIX_A PREDS_A PREFIX_B PREDS_B [--out report.json]
exit 0 = within the declared tolerance, 1 = not (or files / candidates / labels do not line up).
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

MIN_DECISIONS = 2
FRACTION = 1e-3
SEL_KEY = ("run_id", "deleted", "criterion", "selection_partition")
SEL_VALUE = ("removable", "chosen", "inclusion_minimal_sets")


def tolerance(n: int) -> int:
    return max(MIN_DECISIONS, math.ceil(FRACTION * n))


def decision_files(d) -> dict:
    return {p.name: p for p in sorted(Path(d).glob("*.npz")) if not p.name.endswith("__fold_fit.npz")}


def compare(prefix_a, preds_a, prefix_b, preds_b) -> dict:
    fa, fb = decision_files(preds_a), decision_files(preds_b)
    fails = []
    if set(fa) != set(fb) or not fa:
        fails.append(f"the saved decision files differ or are missing: {sorted(set(fa) ^ set(fb))[:6]}")
    dec = defaultdict(lambda: defaultdict(lambda: {"candidates": 0, "examples": None, "tolerance": None,
                                                   "max_disagreements": 0, "total_disagreements": 0,
                                                   "candidates_with_any": 0, "max_abs_error_diff": 0.0}))
    for name in sorted(set(fa) & set(fb)):
        table = name[:-4].split("__")[-1]
        za, zb = np.load(fa[name], allow_pickle=False), np.load(fb[name], allow_pickle=False)
        ma, mb = json.loads(str(za["meta"])), json.loads(str(zb["meta"]))
        if ma["order"] != mb["order"] or ma["partitions"] != mb["partitions"]:
            fails.append(f"{name}: the candidates or partitions do not line up")
            continue
        for p in ma["partitions"]:
            pa, pb = za[f"preds_{p}"], zb[f"preds_{p}"]
            ya, yb = za[f"labels_{p}"], zb[f"labels_{p}"]
            if pa.shape != pb.shape or not np.array_equal(ya, yb):
                fails.append(f"{name} {p}: shapes or labels differ")
                continue
            n = int(ya.shape[0])
            dis = (pa != pb).sum(1)
            ed = np.abs((pa != ya).mean(1) - (pb != yb).mean(1))
            r = dec[table][p]
            r["candidates"] += int(pa.shape[0])
            r["examples"], r["tolerance"] = n, tolerance(n)
            r["max_disagreements"] = max(r["max_disagreements"], int(dis.max()))
            r["total_disagreements"] += int(dis.sum())
            r["candidates_with_any"] += int((dis > 0).sum())
            r["max_abs_error_diff"] = max(r["max_abs_error_diff"], float(ed.max()))
            if int(dis.max()) > tolerance(n):
                i = int(dis.argmax())
                fails.append(f"{name} {p}: candidate {ma['order'][i]} differs on {int(dis.max())} of {n} decisions "
                             f"(tolerance {tolerance(n)}; error difference {float(ed[i]):.4f})")
    sel = {"compared": False}
    sa, sb = Path(f"{prefix_a}_minimal_sets.csv"), Path(f"{prefix_b}_minimal_sets.csv")
    if sa.exists() and sb.exists():
        ra = {tuple(r[k] for k in SEL_KEY): r for r in csv.DictReader(open(sa))}
        rb = {tuple(r[k] for k in SEL_KEY): r for r in csv.DictReader(open(sb))}
        if set(ra) != set(rb):
            fails.append("the selection tables hold different rows")
        diff = [k for k in sorted(set(ra) & set(rb)) if any(ra[k][c] != rb[k][c] for c in SEL_VALUE)]
        dist = [float(r["nearest_threshold_distance"]) for r in ra.values() if r.get("nearest_threshold_distance")]
        sel = {"compared": True, "rows": len(ra), "rows_differing": len(diff),
               "selection_identical": not diff,
               "smallest_threshold_distance": min(dist) if dist else None,
               "note": "a differing selection is reported, not failed: one decision can move an error across a "
                       "threshold",
               "differing": [{**dict(zip(SEL_KEY, k)),
                              **{f"{c}_a": ra[k][c] for c in SEL_VALUE}, **{f"{c}_b": rb[k][c] for c in SEL_VALUE},
                              "threshold_distance_a": ra[k].get("nearest_threshold_distance"),
                              "threshold_distance_b": rb[k].get("nearest_threshold_distance")}
                             for k in diff[:50]]}
    return {"tool": "compare_edit_runs", "a": {"prefix": str(prefix_a), "preds": str(preds_a)},
            "b": {"prefix": str(prefix_b), "preds": str(preds_b)},
            "rule": f"per candidate and partition at most max({MIN_DECISIONS}, ceil({FRACTION:g} n)) differing "
                    f"decisions; no bitwise comparison across backends",
            "files": len(set(fa) & set(fb)), "decisions": {t: dict(v) for t, v in dec.items()},
            "selection": sel, "failures": fails, "passed": not fails}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("prefix_a")
    ap.add_argument("preds_a")
    ap.add_argument("prefix_b")
    ap.add_argument("preds_b")
    ap.add_argument("--out", default=None)
    a = ap.parse_args(argv)
    rep = compare(a.prefix_a, a.preds_a, a.prefix_b, a.preds_b)
    if a.out:
        Path(a.out).write_text(json.dumps(rep, indent=1))
    print(json.dumps({"passed": rep["passed"], "files": rep["files"], "failures": rep["failures"][:5],
                      "selection_identical": rep["selection"].get("selection_identical")}, indent=1))
    return 0 if rep["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
