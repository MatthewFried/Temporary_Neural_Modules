#!/usr/bin/env python3
"""v56 (v55 plus bias-controlled norm controls and more probed controls): how does an original first layer
differ after expanded training, after compact
continuation, and at f0, and which simple controls reproduce which of its measured properties?

Analysis only: reads a finished panel (wave 25 or wave 26), trains no network.  The only fitting is of linear probes
(regularised binary logistic regression, iterated in float64 until a numerical stationarity tolerance is met).

For every f0 of the manifest the STATES are f0 itself, every expansion at its end (2U) and every compact control at
the declared multiples of 2U (--compact-multiples; its at_<update> checkpoints, whose recorded update is checked).
Two representation contexts are kept apart everywhere (column representation_context, never pooled):
  extracted  f0 with the state's first layer (weight and bias) and f0's own later layers, no repair: the fixed
             original downstream network evaluates the changed component
  native     the state's actual trained network (an expansion with its additions, a compact control as it is)

  _states   each state's first layer in f0 (extracted errors, training loss) and its actual network's errors
            (native_*); how the layer differs from f0's (norm ratios of the layer and of its causal / shortcut /
            other input blocks, cosines to f0's weight, the bias change, the spread of per-unit norm changes)
  _edits    first layers built without further optimisation, evaluated in f0.  Each row records its information
            access, its control family and how it is constructed:
              construction = training_free          needs f0 and the feature layout only
              construction = needs_trained_state    reads a trained state's norms, weights or bias
            shortcut_shrink   f0_shortcut_x<s>: f0's shortcut column times s in SHRINK.  The prespecified baseline
                              is s = PRESPECIFIED_SHRINK (the known shortcut column removed), fixed here and not
                              chosen from any result; the other factors are descriptive
            layer_norm        f0_at_state_layer_norm / state_at_f0_layer_norm: one scalar on the whole weight
            block_norm        f0_at_state_block_norms / state_at_f0_block_norms: one scalar per input block
            block_row_norm    f0_at_state_block_row_norms / state_at_f0_block_row_norms: one scalar per unit and
                              input block (a gain per unit, so unequal changes across units are matched too)
            bias              state_weights_f0_bias / f0_weights_state_bias
            block_norm_f0_bias, block_row_norm_f0_bias (v56)
                              state_at_f0_block_norms_f0_bias / state_at_f0_block_row_norms_f0_bias: the state's
                              weights at f0's norms with f0's bias, so scale and bias are both controlled; each
                              is also contrasted with its state-bias twin (f0_bias_minus_state_bias)
            The norm controls are CONTROLS, not a decomposition of what was learned: "state at f0's norms" keeps the
            state's bias and (for the layer and block families) its distribution of norm over units, and removing a
            gain can also remove a useful interaction between gain and direction.  A norm that cannot be matched (a
            zero block or row scaled to a positive norm) is counted in n_unmatched and norm_match_exact is False.
  _probes   the same linear probe on every probed network: FEATURES x TARGETS x FITS x {raw, standardised} x LAMBDAS.
              probed networks: every state in both contexts; the edits PROBED_EDITS of every state (the block
                         and block-row norm controls in both directions and their f0-bias versions) and the
                         prespecified shortcut-shrink baseline (extracted context); the raw input once per f0
              features   layer1: the first layer's activations (extracted context only: with the first layer
                         reading the input, they are the same function in both contexts); penultimate: the
                         activations the output layer reads, in the named context
              targets    label; shortcut_sign (the sign of the shortcut input as the network receives it)
              fits       train (the readout-only control) or val_indep (target-distribution labels: a
                         measurement, labelled as such)
              standardised: each feature centred and scaled by the fit set's statistics.  This removes per-unit
                         affine rescaling of the ACTIVATIONS; it does not remove the effect of scaling input
                         weights, which changes which units are active.  That is why the edits are probed too.
            Errors on test, val, shift and (when not the fit set) val_indep.
  _contrasts  paired within f0: an expansion against f0, against its matched compact control at the same update
            (matching = same_updates) and against that control trained longer (matching = compact_at_<m>x_updates,
            a separate comparison name); a compact control against f0; every edit against the state it is built
            from and against f0; an f0-bias control against its state-bias twin; f0 with a shrunk shortcut
            column against every state; the same for probes
            (quantity probe / edit_probe).  Error differences come with decision disagreement (the share of
            examples on which the two networks decide differently): equal error rates do not mean equal predictions.
            role = primary on two rows per f0 (PRIMARY_VARIANTS); every other row is exploratory.
Tables carry _by_draw and _summary (optimizer seeds averaged within a draw, 95% t intervals over draws), grouped by
design_id (data without seeds, architecture, f0's training and the arm set) as well as the cell label, so two
experiments that share a label are not pooled.  For error differences the summary records the declared equivalence
margin and whether the interval lies inside it; without that, a small or non-significant difference is not evidence
of equivalence.

--save-probes DIR writes, per f0, every fitted probe (coefficients, intercept, fit-set mean and scale, its
decisions on every evaluated partition) with an index (network, context, target, penalty, source checkpoint, first
layer hash, split hashes); the file is reloaded and checked against the tables before the f0 counts as analysed.

The networks must be plain ReLU chains of weight matrices with biases and two classes; the feature layout must be
the generator's unrotated one (causal block, one shortcut column).  A probe that does not meet the tolerance, a
non-finite feature, coefficient or score, a compact checkpoint whose recorded update is not the requested one, or
an expansion without exactly one matched compact control fails the run.

usage: component_change.py RESULTS OUT_PREFIX --manifest M [--data-root D] [--device cpu|cuda]
                           [--compact-multiples 1[,2]] [--save-probes DIR] [--strict]
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import coordinated_edits as CE  # noqa: E402
import panel26_tables as PT  # noqa: E402
import selective_reversal as SR  # noqa: E402

torch = SR.torch
AC = SR.AC
Fail = SR.Fail
GraphNet = SR.GraphNet

ANALYSIS_SCHEMA = "component_change/v57"
STATUS = ("reanalysis of existing checkpoints (no network is trained; linear probes are fitted); exploratory apart "
          "from the contrasts with role = primary")
SHRINK = (0.0, 0.25, 0.5, 0.75)
PRESPECIFIED_SHRINK = 0.0     # the shortcut-shrink baseline: the known shortcut column removed (declared, not selected)
FEATURES = ("layer1", "penultimate")
TARGETS = ("label", "shortcut_sign")
FITS = ("train", "val_indep")
STANDARDISE = (False, True)
LAMBDAS = (1e-4, 1e-2)
PROBE_EVAL = ("test", "val", "shift", "val_indep")
CONTEXTS = ("extracted", "native")
NATIVE_FEATURES = ("penultimate",)
PROBED_EDITS = ("f0_at_state_block_norms", "state_at_f0_block_norms", "f0_at_state_block_row_norms",
                "state_at_f0_block_row_norms", "state_at_f0_block_norms_f0_bias",
                "state_at_f0_block_row_norms_f0_bias")
F0_BIAS_TWINS = {"state_at_f0_block_norms_f0_bias": "state_at_f0_block_norms",
                 "state_at_f0_block_row_norms_f0_bias": "state_at_f0_block_row_norms"}
DISAGREE_PARTS = ("test", "val_indep")
ERR_METRICS = ("test_err", "val_err", "val_indep_err", "shift_err")
NATIVE_METRICS = ("test_err", "val_err", "val_indep_err", "shift_err", "train_loss", "train_err")
EQUIVALENCE_MARGIN = 0.01     # declared: an error difference whose 95% interval lies inside +-0.01 (one point)
NEWTON_MAX_ITER = 500
NEWTON_TOL = 1e-9             # the iteration stops at this max |gradient|
CONVERGED_TOL = 1e-6          # a probe counts as fitted below this max |gradient| (numerical stationarity)
LOSS_RESOLUTION = 1e-12       # relative loss decrease below which a Newton step is judged by the gradient instead
CHAIN_TOL = 1e-4
BLOCKS = ("causal", "shortcut", "other")
NET_METRICS = ("train_loss", "train_err") + CE.BASE_METRICS
# The primary contrasts: on the arm that holds the shortcut column under routed ReLU additions at the baseline's
# learning rate (wave 25's B arm; wave 26 repeats it on new draws), the extraction's test error against f0 and
# against the matched compact control at the same update.  Wave 25's were fixed before its run (v46's P1) and are
# recomputed here; wave 26's were named in v54, after the panel was launched and before any wave-26 result was read.
# Every other row of every table is exploratory.
PRIMARY_VARIANTS = {"B_scfrozen": "wave 25 (v46's P1, recomputed)", "B_routed_relu": "wave 26 (named in v54)"}
PRIMARY_COMPARISONS = ("expansion_minus_f0", "expansion_minus_matched_compact")
LAYOUT = "feature layout (causal / shortcut / other columns)"
# edit -> (control family, information access)
EDITS = {
    "f0_at_state_layer_norm": ("layer_norm", "the state's first-layer norm (one scalar); no feature labels"),
    "state_at_f0_layer_norm": ("layer_norm", "the state's first layer and f0's first-layer norm (one scalar)"),
    "f0_at_state_block_norms": ("block_norm", f"{LAYOUT} and the state's block norms"),
    "state_at_f0_block_norms": ("block_norm", f"{LAYOUT}, the state's first layer and f0's block norms"),
    "f0_at_state_block_row_norms": ("block_row_norm", f"{LAYOUT} and the state's norm per unit and block"),
    "state_at_f0_block_row_norms": ("block_row_norm", f"{LAYOUT}, the state's first layer and f0's norm per unit "
                                                      f"and block"),
    "state_at_f0_block_norms_f0_bias": ("block_norm_f0_bias", f"{LAYOUT}, the state's first-layer weight and f0's "
                                                              f"block norms; f0's bias"),
    "state_at_f0_block_row_norms_f0_bias": ("block_row_norm_f0_bias", f"{LAYOUT}, the state's first-layer weight "
                                                                      f"and f0's norm per unit and block; f0's bias"),
    "state_weights_f0_bias": ("bias", "the state's first-layer weight; f0's bias"),
    "f0_weights_state_bias": ("bias", "the state's first-layer bias; f0's weight"),
}
CONSTRUCTION = {"training_free": "built from f0 and the feature layout alone: no trained expansion or control needed",
                "needs_trained_state": "no further optimisation, but it reads a trained state's norms, weights or bias"}
ACCESS = {
    "state": "none beyond the state's own training (its first layer placed in f0)",
    "f0_shortcut": "feature layout: which input column is the shortcut (as the B arms' hold); no training",
    "probe_fit_train": "training set labels (the readout-only control when the features are the penultimate ones)",
    "probe_fit_val_indep": "target-distribution labels (val_indep: shortcut independent of the label)",
}
STATE_KEYS = ("design_id", "cell", "state", "kind", "variant", "updates_since_f0")
EDIT_KEYS = STATE_KEYS + ("edit", "control_family", "construction", "baseline", "access")
PROBE_KEYS = ("design_id", "cell", "net", "net_kind", "state", "edit", "representation_context", "kind", "variant",
              "updates_since_f0", "spec", "access")
CONTRAST_KEYS = ("design_id", "cell", "role", "comparison", "matching", "quantity", "representation_context", "edit",
                 "spec", "metric", "variant", "kind", "updates_since_f0", "second", "sign")


def role_of(quantity: str, metric: str, comparison: str, variant, primary=None) -> str:
    """primary: the variants whose two extraction contrasts are primary (default PRIMARY_VARIANTS)."""
    return "primary" if (quantity == "extraction" and metric == "test_err" and comparison in PRIMARY_COMPARISONS
                         and variant in (PRIMARY_VARIANTS if primary is None else primary)) else "exploratory"


# ----------------------------------------------------------------------------- the linear probe

def fit_logistic(X, y, lam: float, max_iter: int = NEWTON_MAX_ITER, tol: float = NEWTON_TOL):
    """Binary logistic regression with an unpenalised intercept: minimise  mean_i [softplus(z_i) - y_i z_i]
    + lam / 2 |w|^2,  z = X w + b,  by Newton's method with a backtracking (Armijo) line search, in X's dtype
    (float64 here).  Strictly convex in w for lam > 0, so the minimiser does not depend on the start (zero).  Near
    it, where the loss value can no longer resolve a step, a full Newton step is taken while it at least halves
    max |gradient|.  The result is the iterate reached; info["grad_inf"] says how stationary it is.
    -> (w, b, info): info has the iterations, the final loss and max |gradient|."""
    if lam <= 0:
        raise Fail("fit_logistic: the penalty must be positive")
    n, d = X.shape
    Xa = torch.cat([X, torch.ones(n, 1, dtype=X.dtype, device=X.device)], 1)
    reg = torch.full((d + 1,), float(lam), dtype=X.dtype, device=X.device)
    reg[-1] = 0.0
    yd = y.to(X.dtype)
    eye = torch.eye(d + 1, dtype=X.dtype, device=X.device)

    def loss_of(th):
        z = Xa @ th
        return float((torch.nn.functional.softplus(z) - yd * z).mean() + 0.5 * (reg * th * th).sum())

    def grad_of(th):
        p = torch.sigmoid(Xa @ th)
        return Xa.T @ (p - yd) / n + reg * th, p
    th = torch.zeros(d + 1, dtype=X.dtype, device=X.device)
    cur = loss_of(th)
    it = 0
    for it in range(1, max_iter + 1):
        g, p = grad_of(th)
        gi = float(g.abs().max())
        if gi <= tol:
            break
        H = (Xa * (p * (1.0 - p))[:, None]).T @ Xa / n + torch.diag(reg) + 1e-10 * eye
        try:
            step = torch.linalg.solve(H, g)
        except RuntimeError:                            # a singular system: reported through grad_inf
            break
        slope = float(g @ step)                         # > 0: H is positive definite
        if slope <= LOSS_RESOLUTION * max(1.0, abs(cur)):
            # the predicted decrease is below what the loss value can resolve: judge the full step by the gradient
            new = th - step
            if float(grad_of(new)[0].abs().max()) <= 0.5 * gi:
                th, cur = new, loss_of(new)
                continue
            break
        t, moved = 1.0, False
        while t >= 1e-12:
            new = th - t * step
            nl = loss_of(new)
            if nl <= cur - 1e-4 * t * slope:
                th, cur, moved = new, nl, True
                break
            t *= 0.5
        if not moved:
            break
    g, _ = grad_of(th)
    return th[:-1], float(th[-1]), {"iterations": it, "loss": cur, "grad_inf": float(g.abs().max())}


def standardiser(F):
    """-> (mean, scale) of the fit set's features; a constant feature keeps scale 1 (it becomes exactly zero)."""
    mu = F.mean(0)
    sd = F.std(0, unbiased=False)
    return mu, torch.where(sd > 1e-12, sd, torch.ones_like(sd))


def probe_scores(F, w, b):
    return F @ w + b


def probe_error(F, y, w, b) -> float:
    return float(((probe_scores(F, w, b) > 0).long() != y.long()).double().mean())


def finite(t, what: str) -> None:
    if not bool(torch.isfinite(t).all()):
        raise Fail(f"{what}: non-finite values")


# ----------------------------------------------------------------------------- first-layer edits

def blocks_of(lay: dict, n_in: int):
    """-> {block: column index tensor} for the generator's unrotated layout, else None."""
    if "input_rotation" in lay or "shortcut" not in lay or "causal" not in lay:
        return None
    c0, c1 = (int(x) for x in lay["causal"])
    sc = int(lay["shortcut"])
    if not (0 <= c0 < c1 <= n_in and 0 <= sc < n_in and not c0 <= sc < c1):
        raise Fail(f"feature layout {lay} does not fit {n_in} input columns")
    oth = [j for j in range(n_in) if not c0 <= j < c1 and j != sc]
    return {"causal": torch.arange(c0, c1), "shortcut": torch.tensor([sc]),
            "other": torch.tensor(oth, dtype=torch.long)}


def fro(t) -> float:
    return float(t.double().norm())


def norm_ratio(a: float, b: float):
    """a / b; 1 when both are zero; None when b is zero and a is not (no ratio exists)."""
    return a / b if b > 0 else (1.0 if a == 0 else None)


def scale_to(src, target: float) -> tuple:
    """src scaled to Frobenius norm `target` -> (tensor, matched).  A zero src cannot reach a positive norm: it is
    returned unchanged with matched False."""
    s = fro(src)
    if s > 0:
        return src * (target / s), True
    return src, target == 0


def scale_rows_to(src, target_rows) -> tuple:
    """each row of src scaled to its target norm -> (tensor, rows that could not be matched)."""
    s = src.double().norm(dim=1)
    t = target_rows.double().to(s.device)
    f = torch.where(s > 0, t / s.clamp_min(1e-300), torch.ones_like(s))
    return (src.double() * f[:, None]).to(src.dtype), int(((s == 0) & (t > 0)).sum())


def layer_summary(W, W0, b_, b0, blk) -> dict:
    """how a first layer differs from f0's: norm ratios of the layer and of each input block, cosines to f0, the
    bias change, and how unequally the norm change is spread over units (sd of the log per-unit norm ratio).  A ratio
    that does not exist (f0's norm zero) is None."""
    Wd, W0d = W.double(), W0.double()

    def cos(a, c):
        den = fro(a) * fro(c)
        return float((a * c).sum() / den) if den > 0 else None

    def spread(a, c):
        ra, rc = a.norm(dim=1), c.norm(dim=1)
        if bool((ra <= 0).any()) or bool((rc <= 0).any()):
            return None
        return float((ra / rc).log().std(unbiased=False))
    o = {"layer_norm_ratio": norm_ratio(fro(W), fro(W0)), "layer_cos_to_f0": cos(Wd, W0d),
         "bias_norm_ratio": norm_ratio(fro(b_), fro(b0)),
         "bias_change_over_f0_norm": norm_ratio(fro(b_.double() - b0.double()), fro(b0)),
         "change_over_f0_norm": norm_ratio(fro(Wd - W0d), fro(W0)),
         "layer_unit_log_norm_ratio_sd": spread(Wd, W0d)}
    for name, idx in (blk or {}).items():
        i = idx.to(W.device)
        a, c = Wd[:, i], W0d[:, i]
        o[f"{name}_norm_ratio"] = norm_ratio(fro(a), fro(c))
        o[f"{name}_cos_to_f0"] = cos(a, c)
        o[f"{name}_unit_log_norm_ratio_sd"] = spread(a, c)
    return o


def edit_layers(W, b_, W0, b0, blk) -> dict:
    """the mirrored edits of one state: {edit name: (weight, bias, info)}; info = {"scales": {...}, "unmatched": n}
    (n = norms that could not be matched: a zero layer, block or row asked to take a positive norm).  Weights keep
    W0's dtype.  Without a feature layout (blk None) only the layer-norm and bias edits exist."""
    r = norm_ratio(fro(W), fro(W0))
    up, ok_u = scale_to(W0, fro(W))
    dn, ok_d = scale_to(W, fro(W0))
    out = {"f0_at_state_layer_norm": (up, b0, {"scales": {"layer": r}, "unmatched": int(not ok_u)}),
           "state_at_f0_layer_norm": (dn, b_, {"scales": {"layer": r}, "unmatched": int(not ok_d)})}
    if blk is not None:
        up, dn, used, bad_u, bad_d = W0.clone(), W.clone(), {}, 0, 0
        upr, dnr, rbad_u, rbad_d = W0.clone(), W.clone(), 0, 0
        for name, idx in blk.items():
            i = idx.to(W.device)
            used[name] = norm_ratio(fro(W[:, i]), fro(W0[:, i]))
            seg, ok = scale_to(W0[:, i], fro(W[:, i]))
            up[:, i] = seg
            bad_u += int(not ok)
            seg, ok = scale_to(W[:, i], fro(W0[:, i]))
            dn[:, i] = seg
            bad_d += int(not ok)
            seg, nb = scale_rows_to(W0[:, i], W[:, i].double().norm(dim=1))
            upr[:, i] = seg
            rbad_u += nb
            seg, nb = scale_rows_to(W[:, i], W0[:, i].double().norm(dim=1))
            dnr[:, i] = seg
            rbad_d += nb
        out["f0_at_state_block_norms"] = (up, b0, {"scales": used, "unmatched": bad_u})
        out["state_at_f0_block_norms"] = (dn, b_, {"scales": used, "unmatched": bad_d})
        out["f0_at_state_block_row_norms"] = (upr, b0, {"scales": {}, "unmatched": rbad_u})
        out["state_at_f0_block_row_norms"] = (dnr, b_, {"scales": {}, "unmatched": rbad_d})
        out["state_at_f0_block_norms_f0_bias"] = (dn, b0, {"scales": used, "unmatched": bad_d})
        out["state_at_f0_block_row_norms_f0_bias"] = (dnr, b0, {"scales": {}, "unmatched": rbad_d})
    out["state_weights_f0_bias"] = (W, b0, {"scales": {}, "unmatched": 0})
    out["f0_weights_state_bias"] = (W0, b_, {"scales": {}, "unmatched": 0})
    return out


def held_through(cfg: dict, u: int) -> bool:
    """does this job hold the first layer's shortcut column from f0 through update u?  A trajectory or removal holds
    it for its whole length; a compact control through its frozen prefix when it has a freeze schedule."""
    if (cfg.get("train") or {}).get("freeze_inputs", "none") != "shortcut":
        return False
    cc = cfg.get("continue") or {}
    fs = cc.get("freeze_segments") or []
    if not fs:
        return True
    upto = 0
    for n_, f_ in zip(cc["segments"], fs):
        if not f_:
            break
        upto += int(n_)
    return u <= upto


# ----------------------------------------------------------------------------- the design

def f0_jobs(mcfg: dict) -> dict:
    """-> {f0 run id: {"exp": {variant: (removal id, trajectory id)}, "comp": {variant: control id}}}."""
    out = defaultdict(lambda: {"exp": {}, "comp": {}})
    for rid, c in mcfg.items():
        el = SR.eligible(c)
        v = (c.get("design") or {}).get("variant")
        if el == ("removal", "full"):
            tid = (c.get("parents") or {}).get("trajectory")
            if tid not in mcfg:
                raise Fail(f"{rid}: its trajectory is not in the manifest")
            bid = (mcfg[tid].get("parents") or {}).get("baseline")
            if v in out[bid]["exp"]:
                raise Fail(f"f0 {bid}: two full removal jobs carry the variant {v!r}")
            out[bid]["exp"][v] = (rid, tid)
        elif el is not None and el[0] == "control":
            bid = (c.get("parents") or {}).get("baseline")
            if v in out[bid]["comp"]:
                raise Fail(f"f0 {bid}: two control jobs carry the variant {v!r} (several control arms of one "
                           f"variant are not supported)")
            out[bid]["comp"][v] = rid
    return {k: v for k, v in out.items() if v["exp"]}


def require_matched(exp_lev: dict, comp_lev: dict) -> dict:
    """-> {expansion variant: its one compact control with the same hold and learning rate}; a missing or an
    ambiguous match fails (a comparison must not disappear silently)."""
    out, bad = {}, []
    for v, lev in sorted(exp_lev.items()):
        m = sorted(c for c, cl in comp_lev.items() if cl["hold"] == lev["hold"] and cl["lr"] == lev["lr"])
        if len(m) != 1:
            bad.append(f"{v} (hold {lev['hold']}, lr {lev['lr']:g}): {m or 'none'}")
        else:
            out[v] = m[0]
    if bad:
        raise Fail("no single matched compact control (same hold and learning rate) for " + "; ".join(bad))
    return out


def design_id(bcfg: dict, contrast: str, exp_lev: dict, comp_lev: dict) -> str:
    """the identity of the experiment an f0 belongs to: the contrast label plus a hash of the data (without its
    seeds), the architecture, f0's training settings and the arm set.  Draw and optimizer seed are not part of it."""
    h = SR.stable_hash({"data": CE._no_seeds(bcfg.get("data")), "model": bcfg.get("model"),
                        "train": bcfg.get("train"), "expansions": exp_lev, "compact_controls": comp_lev})
    return f"{contrast or 'experiment'}#{h[:8]}"


def head_input_node(g, head_key: str) -> str:
    """the node whose value the output layer reads in this graph."""
    ns = [g.nodes[n] for n in g.live_nodes() if g.nodes[n].pkey == head_key and g.nodes[n].owner is None]
    if len(ns) != 1 or ns[0].op != "linear" or len(ns[0].inputs) != 1:
        raise Fail("native context: the output layer is not one backbone linear node with one input")
    return ns[0].inputs[0]


def native_features(g, part, node: str, batch: int) -> tuple:
    """-> (the value of `node`, the logits) of the actual graph on one partition, float64."""
    dt = next(g.parameters()).dtype
    fs, zs = [], []
    with torch.no_grad():
        for i0 in range(0, len(part), batch):
            X = {k: (t[i0:i0 + batch].to(dt) if t.is_floating_point() else t[i0:i0 + batch])
                 for k, t in part.X.items()}
            z, nv = g.forward(X, return_nodes=[node])
            fs.append(nv[node].double())
            zs.append(z.double())
    return torch.cat(fs), torch.cat(zs)


# ----------------------------------------------------------------------------- saved probes

class ProbeStore:
    """every fitted probe of one f0: coefficients, intercept, fit-set mean and scale (zeros and ones for raw
    features), and its decisions on every evaluated partition (bit-packed).  decision = ((features - mean) / scale)
    @ coef + intercept > 0."""

    def __init__(self):
        self.index, self.arr = [], defaultdict(list)

    def add(self, rec: dict, w, b: float, mu, sd, preds: dict) -> int:
        d = int(w.shape[0])
        pid = len(self.index)
        row = len(self.arr[f"coef_d{d}"])
        self.arr[f"coef_d{d}"].append(w.detach().cpu().numpy().astype(np.float64))
        self.arr[f"mean_d{d}"].append(mu.detach().cpu().numpy().astype(np.float64))
        self.arr[f"scale_d{d}"].append(sd.detach().cpu().numpy().astype(np.float64))
        self.arr[f"intercept_d{d}"].append(np.float64(b))
        rows = {}
        for p, pred in preds.items():
            rows[p] = len(self.arr[f"pred_{p}"])
            self.arr[f"pred_{p}"].append(np.packbits(pred.detach().cpu().numpy().astype(bool)))
        self.index.append({**rec, "probe_id": pid, "n_features": d, "coef_row": row, "pred_rows": rows})
        return pid

    def arrays(self) -> dict:
        return {k: np.stack(v) for k, v in self.arr.items()}

    def save(self, folder: Path, name: str, header: dict) -> tuple:
        folder.mkdir(parents=True, exist_ok=True)
        tmp = folder / f"{name}.partial.npz"
        np.savez_compressed(tmp, **self.arrays())
        os.replace(tmp, folder / f"{name}.npz")
        SR.atomic_json(str(folder / f"{name}.json"), {**header, "probes": self.index})
        return folder / f"{name}.npz", folder / f"{name}.json"


def reload_check(npz: Path, jsn: Path, store: ProbeStore, targets: dict, rows: dict) -> int:
    """the saved file read back: every array equals what was fitted, and the errors recomputed from the saved
    decisions equal the table's.  rows: probe_id -> table row.  -> number of probes checked."""
    idx = json.loads(Path(jsn).read_text())["probes"]
    if [x["probe_id"] for x in idx] != list(range(len(store.index))):
        raise Fail(f"{jsn}: the saved probe index is not the fitted one")
    with np.load(npz) as z:
        mem = store.arrays()
        if set(z.files) != set(mem):
            raise Fail(f"{npz}: saved arrays differ from the fitted ones")
        for k, v in mem.items():
            if not np.array_equal(z[k], v):
                raise Fail(f"{npz}: saved array {k} differs from the fitted one")
        for x in idx:
            r = rows[x["probe_id"]]
            for p, row in x["pred_rows"].items():
                y = targets[p][x["target"]]
                pred = np.unpackbits(z[f"pred_{p}"][row])[:len(y)].astype(bool)
                err = float((pred != y.astype(bool)).mean())
                if abs(err - r[f"{p}_err"]) > 1e-12:
                    raise Fail(f"{npz}: probe {x['probe_id']} on {p}: saved decisions give error {err}, the table "
                               f"{r[f'{p}_err']}")
    return len(idx)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("results")
    ap.add_argument("out")
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--compact-multiples", default="1",
                    help="comma-separated multiples of the expansion length 2U at which every compact control is "
                         "read (its at_<update> checkpoint); 1 is required (the matched comparison)")
    ap.add_argument("--save-probes", default=None, help="folder for the fitted probes (one .npz and .json per f0)")
    ap.add_argument("--primary-variants", default=None,
                    help="comma-separated expansion arms whose extraction contrasts against f0 and against the "
                         "matched compact control are primary (default: wave 25's and wave 26's held-shortcut "
                         "routed arm); a panel that repeats those arms names its own here")
    ap.add_argument("--strict", action="store_true", help="exit 1 unless every f0 is analysed and every probe fitted")
    a = ap.parse_args(argv)
    try:
        mult = sorted({int(x) for x in a.compact_multiples.split(",") if x})
    except ValueError:
        ap.error("--compact-multiples takes integers")
    if 1 not in mult or min(mult) < 1:
        ap.error("--compact-multiples must be positive integers that include 1")
    primary = dict(PRIMARY_VARIANTS) if a.primary_variants is None else \
        {v: "named on the command line" for v in a.primary_variants.split(",") if v}
    dev = torch.device(a.device)
    if dev.type == "cuda" and not torch.cuda.is_available():
        print("--device cuda requested but CUDA is not available", file=sys.stderr)
        return 2
    numerics = CE.numerics_policy(dev)
    runs = Path(a.results) / "runs"
    mcfg = {e["run_id"]: e["cfg"] for e in AC.manifest_entries(a.manifest)}
    cov = {"tool": "component_change", "analysis_schema": ANALYSIS_SCHEMA, "status": STATUS,
           "results": str(Path(a.results).resolve()), "manifest": a.manifest,
           "manifest_sha256": CE.sha256_file(a.manifest),
           "source_sha256": {p.name: CE.sha256_file(p) for p in (Path(__file__), Path(CE.__file__), Path(PT.__file__),
                                                                 Path(SR.__file__), Path(AC.__file__))},
           "numerics": {**numerics, "probes": "float64 Newton with line search, zero start"},
           "options": {"compact_multiples": mult, "save_probes": a.save_probes},
           "definitions": {"shrink": list(SHRINK), "prespecified_shrink": PRESPECIFIED_SHRINK,
                           "features": list(FEATURES) + ["input (once per f0)"], "contexts": list(CONTEXTS),
                           "native_features": list(NATIVE_FEATURES), "probed_edits": list(PROBED_EDITS),
                           "targets": list(TARGETS), "fits": list(FITS), "lambdas": list(LAMBDAS),
                           "probe_eval": list(PROBE_EVAL), "access": ACCESS,
                           "edits": {k: {"control_family": f, "access": acc} for k, (f, acc) in EDITS.items()},
                           "construction": CONSTRUCTION,
                           "probe": "binary logistic regression, unpenalised intercept, penalty lam / 2 |w|^2 on "
                                    "the mean loss; standardised = fit-set mean and standard deviation per feature",
                           "stationarity_tolerance_max_abs_gradient": CONVERGED_TOL,
                           "equivalence_margin": EQUIVALENCE_MARGIN,
                           "disagreement_partitions": list(DISAGREE_PARTS)},
           "primary": {"variants": primary, "comparisons": list(PRIMARY_COMPARISONS),
                       "quantity": "extraction", "metric": "test_err",
                       "sign": "first - second: negative = the expansion's first layer in f0 has the lower error"},
           "expected_f0": 0, "analysed_f0": 0, "failed": [], "probe_not_converged": [], "probes_saved": 0}
    out = defaultdict(list)
    want = {}
    try:
        exp_lev, comp_lev, _, fork_u = PT.design(mcfg)
        matched = require_matched(exp_lev, comp_lev)
        jobs = f0_jobs(mcfg)
    except Fail as ex_:
        cov["failed"].append({"f0": None, "reason": str(ex_)})
        print(f"FAIL: {ex_}", file=sys.stderr)
        exp_lev, comp_lev, matched, jobs, fork_u = {}, {}, {}, {}, None
    cov["expected_f0"] = len(jobs)
    cov["design"] = {"expansions": exp_lev, "compact_controls": comp_lev, "matched_compact": matched,
                     "expansion_updates": fork_u}
    bundles = {}
    for n_done, bid in enumerate(sorted(jobs), 1):
        staged = defaultdict(list)
        try:
            J = jobs[bid]
            if set(J["exp"]) != set(exp_lev) or set(J["comp"]) != set(comp_lev):
                raise Fail(f"f0 {bid}: its arms {sorted(J['exp'])} / controls {sorted(J['comp'])} are not the "
                           f"design's {sorted(exp_lev)} / {sorted(comp_lev)}")
            cfgs = {}
            for v, (rid, tid) in J["exp"].items():
                why = AC.declared_invalid(runs / rid, mcfg[rid])
                if why:
                    raise Fail(f"{rid}: declared invalid ({why})")
                cfgs[rid] = AC.job_config(runs, rid, mcfg[rid])
                cfgs[tid] = AC.job_config(runs, tid, mcfg[tid])
                if (cfgs[rid].get("tags") or {}).get("parent_stage", "final") != "final":
                    raise Fail(f"{rid}: does not start from its trajectory's end")
            for v, rid in J["comp"].items():
                cfgs[rid] = AC.job_config(runs, rid, mcfg[rid])
            bcfg = AC.job_config(runs, bid, mcfg.get(bid))
            dkeys = {json.dumps(c["data"], sort_keys=True) for c in cfgs.values()}
            if len(dkeys) != 1:
                raise Fail(f"f0 {bid}: its jobs differ in data")
            dk = dkeys.pop()
            if dk not in bundles:
                b0 = SR.load_bundle(json.loads(dk), a.data_root, device="cpu")
                bundles[dk] = (b0.to(dev), b0.hashes())
            b, hashes = bundles[dk]
            parts = b.partitions()
            if b.task != "classification" or int(b.out_dim) != 2:
                raise Fail(f"f0 {bid}: needs a two-class classification task")
            if any(p not in parts for p in ("train", "val", "test", "val_indep")):
                raise Fail(f"f0 {bid}: the data has no val_indep partition")
            ps = AC.eval_partitions(b)
            need = {"train", *ps}
            any_cfg = cfgs[next(iter(J["exp"].values()))[0]]
            batch = int((any_cfg.get("train") or {}).get("eval_batch", 4096))
            ytr = parts["train"].y.to(dev).long()
            ytest = parts["test"].y.to(dev).long()

            def measure(m):
                o, pr = AC.finite_eval(m, b, ps, batch, "component change")
                o["test_ce"] = float(torch.nn.functional.cross_entropy(pr["test"].double(), ytest))
                _, ptr = AC.finite_eval(m, b, ["train"], batch, "component change")
                z = ptr["train"].double()
                o["train_loss"] = float(torch.nn.functional.cross_entropy(z, ytr))
                o["train_err"] = float((z.argmax(-1) != ytr).double().mean())
                return o, pr
            # ---- f0: every expansion's own reference copy and every control's start must be one network
            f0k, f0_ids = None, set()
            raw = {}                     # state name -> (checkpoint, kind, variant, updates, config, run id, stage)
            for v, (rid, tid) in sorted(J["exp"].items()):
                AC.check_logged_data(runs / tid, hashes, need, f"{tid} data provenance")
                k = SR.ckp(runs / tid, "baseline_ref")
                gk = AC.check_ckpt(k, f"{v} f0", run_id=tid, stage="baseline_ref", cfg=cfgs[tid], hashes=hashes,
                                   need=need)
                f0_ids.add((AC.param_hash_of(k), gk.structural_hash()))
                f0k = f0k or k
                end = SR.ckp(runs / tid, "final")
                AC.check_ckpt(end, f"{v} end", run_id=tid, stage="final", cfg=cfgs[tid], hashes=hashes, need=need)
                CE.check_age(AC.job_update(end, k, f"{v} end"), fork_u, tid)
                raw[v] = (end, "expansion", v, fork_u, cfgs[tid], tid, "final")
            for v, rid in sorted(J["comp"].items()):
                cc = cfgs[rid].get("continue") or {}
                if cfgs[rid]["parents"]["baseline"] != bid:
                    raise Fail(f"{rid}: its baseline is not {bid}")
                stg = cc.get("start_stage", "best_val")
                k = SR.ckp(runs / bid, stg)
                gk = AC.check_ckpt(k, f"{v} f0", run_id=bid, stage=stg, cfg=bcfg, hashes=hashes, need=need)
                f0_ids.add((AC.param_hash_of(k), gk.structural_hash()))
                AC.check_logged_data(runs / rid, hashes, need, f"{rid} data provenance")
                for m_ in mult:
                    u = m_ * fork_u
                    ck = SR.ckp(runs / rid, f"at_{u}")
                    if ck is None:
                        raise Fail(f"{rid}: no saved state at update {u} (at_{u})")
                    AC.check_ckpt(ck, f"{v} at {u}", run_id=rid, stage=f"at_{u}", cfg=cfgs[rid], hashes=hashes,
                                  need=need)
                    # the checkpoint's own record of its age (these snapshots carry no trainer state)
                    rec_u = (ck.get("extra") or {}).get("update")
                    if rec_u is None or int(rec_u) != u:
                        raise Fail(f"{rid}: the checkpoint at_{u} records update {rec_u}, not {u}")
                    raw[f"{v}@{m_}x"] = (ck, "compact", v, u, cfgs[rid], rid, f"at_{u}")
            if len(f0_ids) != 1:
                raise Fail(f"f0 {bid}: its expansions and controls do not start from one network")
            f0 = GraphNet.from_checkpoint(f0k["model"], dev).eval()
            f0_sd = {k: t.clone() for k, t in f0.state_dict().items()}
            L = SR.backbone_layers(f0)
            wk, bk = [], []
            for Lk in L:
                keys = [k for k in f0_sd if k.startswith(f"mods.{Lk}.")]
                ws = [k for k in keys if f0_sd[k].dim() == 2]
                bs = [k for k in keys if f0_sd[k].dim() == 1]
                if len(ws) != 1 or len(bs) != 1 or len(keys) != 2:
                    raise Fail(f"f0 {bid}: a backbone layer is not one weight matrix with a bias")
                wk.append(ws[0])
                bk.append(bs[0])
            if len(L) < 3 or set(parts["train"].X) != {"x"}:
                raise Fail(f"f0 {bid}: needs one input tensor and at least two hidden layers")
            W0, b0 = f0_sd[wk[0]], f0_sd[bk[0]]
            n_in = int(W0.shape[1])
            lay = (b.meta or {}).get("feature_layout") or {}
            blk = blocks_of(lay, n_in)
            if blk is None:
                raise Fail(f"f0 {bid}: needs the generator's unrotated feature layout")
            sc = int(blk["shortcut"][0])

            def compact(W, bias):
                """f0's graph with this first layer (an independent build of a compact network)."""
                m_ = GraphNet.from_checkpoint(f0k["model"], dev).eval()
                want_ = dict(m_.state_dict())
                want_[wk[0]] = W.to(want_[wk[0]].device, want_[wk[0]].dtype)
                want_[bk[0]] = bias.to(want_[bk[0]].device, want_[bk[0]].dtype)
                m_.load_state_dict(want_)
                m_._plan = None
                CE.verify_patch(m_.state_dict(), want_, "component change: compact build")
                return m_
            f0e, f0p = measure(f0)
            # f0 must be the plain ReLU chain the feature computation assumes
            _, zt = CE.mlp_forward(f0_sd, parts["test"].X["x"].to(dev), wk, bk)
            ref = f0p["test"].double()
            if float((zt - ref).abs().max()) > CHAIN_TOL * max(1.0, float(ref.abs().max())):
                raise Fail(f"f0 {bid}: the network is not a plain ReLU chain of its layers")
            _, p_same = measure(compact(W0, b0))
            if not CE.same_everywhere(p_same, f0p):
                raise Fail(f"f0 {bid}: rebuilding f0 from its own first layer does not reproduce it")
            contrast = ((any_cfg.get("design") or {}).get("contrast") or "")
            meta = {"f0": bid, "design_id": design_id(bcfg, contrast, exp_lev, comp_lev),
                    "f0_param_hash": next(iter(f0_ids))[0], "cell": contrast.split("|")[-1],
                    "draw_set": SR.draw_role(any_cfg), "data_draw": (bcfg.get("data") or {}).get("data_seed"),
                    "optimizer_seed": (bcfg.get("seeds") or {}).get("optimizer")}
            # ---- the states: first layer, actual graph, source
            layers = {"f0": (W0, b0, "f0", "f0", 0)}
            graphs = {"f0": f0}
            source = {"f0": {"run_id": sorted(J["exp"].items())[0][1][1], "stage": "baseline_ref"}}
            for name, (ck, kind, v, u, cfg_, rid_, stage_) in raw.items():
                g_ = GraphNet.from_checkpoint(ck["model"], dev).eval()
                sd = g_.state_dict()
                if wk[0] not in sd or sd[wk[0]].shape != W0.shape or sd[bk[0]].shape != b0.shape:
                    raise Fail(f"{name}: its first layer does not have f0's shape")
                if wk[-1] not in sd or sd[wk[-1]].shape != f0_sd[wk[-1]].shape:
                    raise Fail(f"{name}: its output layer does not have f0's shape")
                W, bias = sd[wk[0]].clone(), sd[bk[0]].clone()
                if held_through(cfg_, u) and not torch.equal(W[:, sc], W0[:, sc]):
                    raise Fail(f"{name}: its lineage holds the shortcut column, which differs from f0's")
                layers[name] = (W, bias, kind, v, u)
                graphs[name] = g_
                source[name] = {"run_id": rid_, "stage": stage_}
            want[bid] = len(layers)
            xs = {p: parts[p].X["x"].to(dev) for p in ("train", "val_indep", *PROBE_EVAL) if p in parts}
            targets = {p: {"label": parts[p].y.to(dev).long(), "shortcut_sign": (xs[p][:, sc] > 0).long()}
                       for p in xs}
            targets_np = {p: {t: y.cpu().numpy() for t, y in d.items()} for p, d in targets.items()}
            st_rows, pr_rows, ed_rows, dec = {}, defaultdict(dict), defaultdict(dict), {}
            store = ProbeStore()
            by_pid, nets = {}, {}

            def lev_of(kind, v):
                lv = exp_lev[v] if kind == "expansion" else comp_lev[v] if kind == "compact" else {}
                return {"hold": lv.get("hold"), "route": lv.get("route"), "act": lv.get("act"), "lr": lv.get("lr")}

            def decisions(pr):
                return {p: pr[p].argmax(-1).cpu() for p in DISAGREE_PARTS if p in pr}

            def extracted_features(name, W, bias, pr):
                """layer-1 and penultimate activations of f0 with this first layer, checked against the evaluated
                network's logits."""
                tens = {**f0_sd, wk[0]: W, bk[0]: bias}
                feats = {"layer1": {}, "penultimate": {}}
                for p, x in xs.items():
                    acts, z = CE.mlp_forward(tens, x, wk, bk)
                    feats["layer1"][p], feats["penultimate"][p] = acts[0], acts[-1]
                    if p == "test":
                        rf = pr["test"].double()
                        if float((z - rf).abs().max()) > CHAIN_TOL * max(1.0, float(rf.abs().max())):
                            raise Fail(f"{name}: the feature computation differs from the evaluated network")
                return feats

            def probes(net, net_kind, state, edit, context, feats: dict, smeta: dict):
                """every probe on one network's features: feats = {feature set: {partition: activations}}."""
                for fs, F in feats.items():
                    for p_, t_ in F.items():
                        finite(t_, f"{net} ({context}) {fs} features on {p_}")
                    for tg in TARGETS:
                        for fit in FITS:
                            for std in STANDARDISE:
                                if std:
                                    mu, sdv = standardiser(F[fit])
                                    Z = {p_: (t_ - mu) / sdv for p_, t_ in F.items()}
                                else:
                                    mu, sdv = torch.zeros_like(F[fit][0]), torch.ones_like(F[fit][0])
                                    Z = F
                                for lam in LAMBDAS:
                                    w, bb, info = fit_logistic(Z[fit], targets[fit][tg], lam)
                                    spec = f"{fs}|{tg}|fit={fit}|{'standardised' if std else 'raw'}|lam={lam:g}"
                                    what = f"{net} ({context}) {spec}"
                                    finite(w, f"{what}: coefficients")
                                    finite(torch.tensor(bb), f"{what}: intercept")
                                    sc_fit = probe_scores(Z[fit], w, bb)
                                    finite(sc_fit, f"{what}: scores on {fit}")
                                    r = {**meta, **smeta, "net": net, "net_kind": net_kind, "state": state,
                                         "edit": edit, "representation_context": context, "features": fs,
                                         "target": tg, "fit": fit, "standardised": std, "lam": lam, "spec": spec,
                                         "n_features": int(Z[fit].shape[1]), "access": ACCESS[f"probe_fit_{fit}"],
                                         "fit_n": int(Z[fit].shape[0]),
                                         "fit_err": float(((sc_fit > 0).long() != targets[fit][tg]).double().mean()),
                                         "fit_loss": info["loss"], "iterations": info["iterations"],
                                         "grad_inf": info["grad_inf"],
                                         "converged": info["grad_inf"] <= CONVERGED_TOL,
                                         "w_norm": float(w.norm())}
                                    preds = {}
                                    for p in PROBE_EVAL:
                                        if p == fit or p not in Z:
                                            r[f"{p}_err"] = None
                                            continue
                                        s_ = probe_scores(Z[p], w, bb)
                                        finite(s_, f"{what}: scores on {p}")
                                        preds[p] = s_ > 0
                                        r[f"{p}_err"] = float((preds[p].long() != targets[p][tg]).double().mean())
                                    if not r["converged"]:
                                        cov["probe_not_converged"].append({"f0": bid, "net": net, "context": context,
                                                                           "spec": spec, "grad_inf": info["grad_inf"]})
                                    r["probe_id"] = store.add(
                                        {"net": net, "net_kind": net_kind, "state": state, "edit": edit,
                                         "representation_context": context, "spec": spec, "features": fs,
                                         "target": tg, "fit": fit, "standardised": std, "lam": lam},
                                        w, bb, mu, sdv, preds)
                                    by_pid[r["probe_id"]] = r
                                    staged["probes"].append(r)
                                    pr_rows[(net, context)][spec] = r
            probes("input", "input", "input", "", "input", {"input": {p: x.double() for p, x in xs.items()}},
                   {"kind": "input", "variant": "input", "updates_since_f0": 0, **lev_of("input", None)})
            for name, (W, bias, kind, v, u) in layers.items():
                smeta = {"kind": kind, "variant": v, "updates_since_f0": u, **lev_of(kind, v)}
                e, pr = measure(compact(W, bias))
                if name == "f0" and not CE.same_everywhere(pr, f0p):
                    raise Fail(f"f0 {bid}: the f0 state does not reproduce f0")
                dec[name] = decisions(pr)
                nets[name] = {**source[name], "first_layer_hash": AC.tensor_hash(torch.cat([W.flatten().cpu(),
                                                                                            bias.flatten().cpu()]))}
                feats = extracted_features(name, W, bias, pr)
                # the state's actual network: its errors and the activations its own output layer reads
                g_ = graphs[name]
                ne, npr = measure(g_)
                node = head_input_node(g_, L[-1])
                gsd = g_.state_dict()
                nat = {}
                for p in xs:
                    nat[p], z = native_features(g_, parts[p], node, batch)
                    if p == "test":
                        rf = npr["test"].double()
                        tol_ = CHAIN_TOL * max(1.0, float(rf.abs().max()))
                        zr = nat[p] @ gsd[wk[-1]].double().T + gsd[bk[-1]].double()
                        if float((z - rf).abs().max()) > tol_ or float((zr - rf).abs().max()) > tol_:
                            raise Fail(f"{name}: the native features are not what its output layer reads")
                r = {**meta, **smeta, "state": name, "access": ACCESS["state"],
                     **{k: e.get(k) for k in NET_METRICS}, "test_gain_vs_f0": f0e["test_err"] - e["test_err"],
                     **{f"native_{k}": ne.get(k) for k in NATIVE_METRICS},
                     **layer_summary(W, W0, bias, b0, blk),
                     "shortcut_column_held": bool(torch.equal(W[:, sc], W0[:, sc]))}
                staged["states"].append(r)
                st_rows[name] = r
                probes(name, "state", name, "", "extracted", feats, smeta)
                probes(name, "state", name, "", "native", {k: nat for k in NATIVE_FEATURES}, smeta)
                del feats, nat
                if name == "f0":
                    for s_ in SHRINK:
                        Ws = W0.clone()
                        Ws[:, sc] = W0[:, sc] * s_
                        ename = f"f0_shortcut_x{s_:g}"
                        ee, epr = measure(compact(Ws, b0))
                        dec[ename] = decisions(epr)
                        pre = s_ == PRESPECIFIED_SHRINK
                        er = {**meta, **smeta, "state": "f0", "edit": ename, "net": ename, "shortcut_scale": s_,
                              "control_family": "shortcut_shrink", "construction": "training_free",
                              "baseline": "prespecified" if pre else "descriptive", "access": ACCESS["f0_shortcut"],
                              "norm_match_exact": True, "n_unmatched": 0, "probed": pre,
                              **{k: ee.get(k) for k in NET_METRICS},
                              "test_gain_vs_f0": f0e["test_err"] - ee["test_err"]}
                        staged["edits"].append(er)
                        ed_rows["f0"][ename] = er
                        if pre:
                            nets[ename] = {"built_from": "f0", "first_layer_hash": AC.tensor_hash(
                                torch.cat([Ws.flatten().cpu(), b0.flatten().cpu()]))}
                            probes(ename, "edit", "f0", ename, "extracted",
                                   extracted_features(ename, Ws, b0, epr), smeta)
                    continue
                for ename, (We, be, info) in edit_layers(W, bias, W0, b0, blk).items():
                    net = f"{ename}({name})"
                    ee, epr = measure(compact(We, be))
                    dec[net] = decisions(epr)
                    fam, acc = EDITS[ename]
                    er = {**meta, **smeta, "state": name, "edit": ename, "net": net, "control_family": fam,
                          "construction": "needs_trained_state", "baseline": "", "access": acc,
                          "norm_match_exact": info["unmatched"] == 0, "n_unmatched": info["unmatched"],
                          "probed": ename in PROBED_EDITS,
                          **{f"scale_{k_}": v_ for k_, v_ in info["scales"].items()},
                          **{k: ee.get(k) for k in NET_METRICS},
                          "test_gain_vs_f0": f0e["test_err"] - ee["test_err"]}
                    staged["edits"].append(er)
                    ed_rows[name][ename] = er
                    if ename in PROBED_EDITS:
                        nets[net] = {"built_from": name, "first_layer_hash": AC.tensor_hash(
                            torch.cat([We.flatten().cpu(), be.flatten().cpu()]))}
                        probes(net, "edit", name, ename, "extracted", extracted_features(net, We, be, epr), smeta)
            # ---- paired contrasts within this f0
            base = {"matching": "", "representation_context": "", "edit": ""}

            def con(quantity, spec, metric, first, second, x1, x2, **extra):
                if x1 is None or x2 is None:
                    return
                staged["contrasts"].append({**meta, **base, "quantity": quantity, "spec": spec, "metric": metric,
                                            "first": first, "second": second, "first_value": x1, "second_value": x2,
                                            "value": x1 - x2, "sign": "first - second",
                                            "role": role_of(quantity, metric, extra["comparison"],
                                                            extra["variant"], primary),
                                            **extra})

            def dis(quantity, spec, first, second, **extra):
                """decision disagreement between two evaluated networks (extracted context)."""
                for p in DISAGREE_PARTS:
                    if p in dec[first] and p in dec[second]:
                        staged["contrasts"].append({
                            **meta, **base, "quantity": quantity, "spec": spec, "metric": f"{p}_disagreement",
                            "first": first, "second": second, "first_value": None, "second_value": None,
                            "value": float((dec[first][p] != dec[second][p]).double().mean()),
                            "sign": "share of examples on which the two networks decide differently",
                            "role": "exploratory", **extra})

            def probe_cons(quantity, first, second, ctx_, **extra):
                for spec, r in pr_rows[(first, ctx_)].items():
                    for m_ in ("test_err", "val_err"):
                        con(quantity, spec, m_, first, second, r.get(m_), pr_rows[(second, ctx_)][spec].get(m_),
                            **{**extra, "representation_context": ctx_})
            f0x = {"variant": "f0", "kind": "f0", "updates_since_f0": 0, **lev_of("f0", None)}
            pre_name = f"f0_shortcut_x{PRESPECIFIED_SHRINK:g}"
            for ename, er in ed_rows["f0"].items():          # f0 with a shrunk shortcut column against f0
                ex = {**f0x, "comparison": "edit_minus_f0", "edit": ename, "representation_context": "extracted"}
                for m_ in ERR_METRICS:
                    con("edit", ename, m_, ename, "f0", er.get(m_), st_rows["f0"].get(m_), **ex)
                dis("edit", ename, ename, "f0", **ex)
                if er["probed"]:
                    probe_cons("edit_probe", ename, "f0", "extracted", **ex)
            for name, (_, _, kind, v, u) in layers.items():
                if kind == "f0":
                    continue
                sx = {"variant": v, "kind": kind, "updates_since_f0": u, **lev_of(kind, v)}
                pairs = [("minus_f0", "f0", "")]
                if kind == "expansion":
                    for m_ in mult:
                        pairs.append(("minus_matched_compact" if m_ == 1 else "minus_matched_compact_longer",
                                      f"{matched[v]}@{m_}x",
                                      "same_updates" if m_ == 1 else f"compact_at_{m_}x_updates"))
                for cname, other, matching in pairs:
                    ex = {**sx, "comparison": f"{kind}_{cname}", "matching": matching}
                    for m_ in (*ERR_METRICS, "train_loss"):
                        con("extraction", "first layer in f0", m_, name, other, st_rows[name].get(m_),
                            st_rows[other].get(m_), **{**ex, "representation_context": "extracted"})
                    dis("extraction", "first layer in f0", name, other,
                        **{**ex, "representation_context": "extracted"})
                    for m_ in ("test_err", "val_err", "val_indep_err", "shift_err"):
                        con("native", "the state's actual network", m_, name, other,
                            st_rows[name].get(f"native_{m_}"), st_rows[other].get(f"native_{m_}"),
                            **{**ex, "representation_context": "native"})
                    for ctx_ in CONTEXTS:
                        probe_cons("probe", name, other, ctx_, **ex)
                for ename, er in ed_rows[name].items():      # each edit against its state and against f0
                    net = er["net"]
                    for ref, cmp_ in ((name, "edit_minus_state"), ("f0", "edit_minus_f0")):
                        ex = {**sx, "comparison": cmp_, "edit": ename, "representation_context": "extracted"}
                        for m_ in ERR_METRICS:
                            con("edit", ename, m_, net, ref, er.get(m_), st_rows[ref].get(m_), **ex)
                        dis("edit", ename, net, ref, **ex)
                        if er["probed"]:
                            probe_cons("edit_probe", net, ref, "extracted", **ex)
                for e1n, e2n in F0_BIAS_TWINS.items():       # the same weights with f0's bias and with the state's
                    e1, e2 = ed_rows[name][e1n], ed_rows[name][e2n]
                    ex = {**sx, "comparison": "f0_bias_minus_state_bias", "edit": e1n,
                          "representation_context": "extracted"}
                    for m_ in ERR_METRICS:
                        con("edit", e1n, m_, e1["net"], e2["net"], e1.get(m_), e2.get(m_), **ex)
                    dis("edit", e1n, e1["net"], e2["net"], **ex)
                    probe_cons("edit_probe", e1["net"], e2["net"], "extracted", **ex)
                for ename, er in ed_rows["f0"].items():      # f0 with a shrunk shortcut column against the state
                    ex = {**sx, "comparison": "f0_shortcut_shrunk_minus_state", "edit": ename,
                          "representation_context": "extracted"}
                    for m_ in ERR_METRICS:
                        con("edit", ename, m_, ename, name, er.get(m_), st_rows[name].get(m_), **ex)
                    dis("edit", ename, ename, name, **ex)
                    if ename == pre_name:
                        probe_cons("edit_probe", ename, name, "extracted", **ex)
            # ---- the fitted probes, saved and read back
            if a.save_probes:
                npz, jsn = store.save(Path(a.save_probes), bid, {
                    "analysis_schema": ANALYSIS_SCHEMA, "f0": bid, "design_id": meta["design_id"],
                    "data_draw": meta["data_draw"], "optimizer_seed": meta["optimizer_seed"],
                    "split_hashes": {p: hashes.get(p) for p in xs}, "n_examples": {p: int(x.shape[0])
                                                                                  for p, x in xs.items()},
                    "decision_rule": "((features - mean) / scale) @ coef + intercept > 0; arrays are indexed by "
                                     "n_features (coef_d<d>[coef_row]) and decisions are bit-packed per partition "
                                     "(pred_<partition>[pred_rows[partition]], first n_examples bits)",
                    "nets": nets})
                cov["probes_saved"] += reload_check(npz, jsn, store, targets_np, by_pid)
            for k_, rows_ in staged.items():
                out[k_].extend(rows_)
            cov["analysed_f0"] += 1
            print(f"f0 {n_done}/{len(jobs)} analysed ({len(staged['probes'])} probes)", flush=True)
        except Fail as ex_:
            cov["failed"].append({"f0": bid, "reason": str(ex_)})
            cov["probe_not_converged"] = [x for x in cov["probe_not_converged"] if x["f0"] != bid]
            print(f"FAIL f0 {bid}: {ex_}", file=sys.stderr)

    P = a.out
    for t_ in ("states", "edits", "probes", "contrasts"):
        SR.atomic_csv(f"{P}_{t_}.csv", out.get(t_, []))

    def long(rows, keys, metrics):
        return [{**{k: r.get(k) for k in keys + ("data_draw", "optimizer_seed")}, "metric": m, "v": float(r[m])}
                for r in rows for m in metrics if r.get(m) is not None]
    shape = ("layer_norm_ratio", "layer_cos_to_f0", "change_over_f0_norm", "bias_norm_ratio",
             "bias_change_over_f0_norm", "layer_unit_log_norm_ratio_sd") + tuple(
        f"{b_}_{s_}" for b_ in BLOCKS for s_ in ("norm_ratio", "cos_to_f0", "unit_log_norm_ratio_sd"))
    for name, rows, keys, metrics in (
            ("states", out["states"], STATE_KEYS,
             NET_METRICS + ("test_gain_vs_f0",) + tuple(f"native_{k}" for k in NATIVE_METRICS) + shape),
            ("edits", out["edits"], EDIT_KEYS, NET_METRICS + ("test_gain_vs_f0", "n_unmatched")),
            ("probes", out["probes"], PROBE_KEYS,
             tuple(f"{p}_err" for p in PROBE_EVAL) + ("fit_err", "fit_loss", "w_norm"))):
        bd, sm = SR.two_stage(long(rows, keys, metrics), keys + ("metric",), "v")
        SR.atomic_csv(f"{P}_{name}_by_draw.csv", bd)
        SR.atomic_csv(f"{P}_{name}_summary.csv", sm)
    bd, sm = SR.two_stage(out["contrasts"], CONTRAST_KEYS, "value")
    for r in sm:                                             # equivalence is a declared margin, never "not different"
        if str(r["metric"]).endswith("_err"):
            lo, hi = r.get("ci95_low"), r.get("ci95_high")
            r["equivalence_margin"] = EQUIVALENCE_MARGIN
            r["ci95_within_margin"] = None if lo is None or hi is None else \
                bool(-EQUIVALENCE_MARGIN < lo and hi < EQUIVALENCE_MARGIN)
    SR.atomic_csv(f"{P}_contrasts_by_draw.csv", bd)
    SR.atomic_csv(f"{P}_contrasts_summary.csv", sm)
    # ---- membership: per analysed f0, one row per state, every probe on every probed network, every edit
    n_probe = len(FEATURES) * len(TARGETS) * len(FITS) * len(STANDARDISE) * len(LAMBDAS)
    n_one = n_probe // len(FEATURES)                         # the probes of one feature set
    cnt = defaultdict(lambda: defaultdict(int))
    for t_ in ("states", "probes", "edits"):
        for r in out[t_]:
            cnt[r["f0"]][t_] += 1
    miss = []
    for bid, n in want.items():
        if bid not in cnt:
            continue
        exp_n = {"states": n, "edits": len(SHRINK) + len(EDITS) * (n - 1),
                 "probes": n_one + n * n_probe + n * n_one * len(NATIVE_FEATURES)
                 + (len(PROBED_EDITS) * (n - 1) + 1) * n_probe}
        got = {t_: cnt[bid][t_] for t_ in exp_n}
        if got != exp_n:
            miss.append(f"{bid}: rows {got}, expected {exp_n}")
    # the primary contrasts: two per analysed f0 for each primary variant the design holds
    n_prim = sum(r["role"] == "primary" for r in out["contrasts"])
    want_prim = len(PRIMARY_COMPARISONS) * len(set(exp_lev) & set(primary)) * len(cnt)
    if n_prim != want_prim:
        miss.append(f"primary contrasts: {n_prim} rows, expected {want_prim}")
    if a.save_probes and cov["probes_saved"] != len(out["probes"]):
        miss.append(f"saved probes: {cov['probes_saved']}, table rows {len(out['probes'])}")
    cov["primary"]["rows"] = n_prim
    cov["design_ids"] = sorted({r["design_id"] for r in out["states"]})
    cov["unmatched_norm_edits"] = sum(1 for r in out["edits"] if not r["norm_match_exact"])
    cov["output_membership_failures"] = miss
    cov["n_failed"] = len(cov["failed"])
    cov["n_probe_not_converged"] = len(cov["probe_not_converged"])
    cov["passed"] = cov["n_failed"] == 0 and cov["analysed_f0"] > 0 and not miss and \
        cov["analysed_f0"] == cov["expected_f0"] and not cov["probe_not_converged"]
    Path(f"{P}_coverage.json").write_text(json.dumps(cov, indent=1, default=str))
    print(json.dumps({k: cov[k] for k in ("expected_f0", "analysed_f0", "n_failed", "n_probe_not_converged",
                                          "probes_saved", "passed")}))
    return 1 if (a.strict and not cov["passed"]) else 0


if __name__ == "__main__":
    sys.exit(main())
