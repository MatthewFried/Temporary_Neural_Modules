#!/usr/bin/env python3
"""v50: coordinated edits on existing expansion checkpoints (analysis only; v49's tool with its review fixed).

Every state is a trajectory's END (its configured expansion length, checked) of a full removal job.  Jobs are
grouped by EXPERIMENT (task / data settings, architecture, cut, growth and removal protocol; not the variant), data
draw and optimizer seed; the variants of one group (wave 25: A free, B shortcut column frozen, C layers 2..K frozen,
D both) must share f0 (parameters and graph) and one graph structure.  Layers are named as in the code tables: L1
is the first layer (never changed here), L2..LK the later backbone layers (LK the head).  The leaf additions are
switched off by their gates, attached as the removal attaches them.  Classification tasks and layers that are one
weight matrix with a bias only; anything else is refused.

--minimal-edits  every subset of the leaf additions deleted x every subset of L2..LK rewound to f0 (WHOLE-LAYER
                 rewinds, f0's tensors bitwise).  Task performance (errors, gain over f0, difference to the native
                 network and to the extraction) and functional recovery (decision disagreement and logit distance
                 to f0 and to the native network) are separate columns.  Per deleted subset the rewind sets that make
                 it REMOVABLE are selected on a validation partition only, under four named criteria
                 (candidate error <= reference error + MARGIN; reference = native | extraction | f0 |
                 legacy_worse_endpoint = v49's max(native, extraction)) and each selection partition (val = source
                 validation; val_indep = validation data from the evaluation distribution, labelled as that access).
                 PRIMARY = (native, val), fixed before the run.  Minimality is within this menu: inclusion-minimal
                 and minimum-cardinality whole-layer rewinds, not minimal parameter support.  Summaries give the
                 success counts, the chosen set's metrics over the selected runs only (conditional on success) and
                 an all-run policy whose fallback is the unedited expanded network.
--rank-restores  every addition deleted; later layers' weight changes W - W0 removed along their top-k singular
                 directions (float64 SVD of W - W0, subtraction in float64), with explicit schemes: no edit; all
                 later layers with the bias restored (k = 0 is the BIAS-ONLY edit) or kept; one target layer at rank
                 k with the OTHER layers fully rewound; the head alone; hidden layers at rank k with the head fully
                 rewound or kept.  Shapes, effective ranks, the change's spectrum and the number of changed
                 parameters are recorded.  A failed top-k restore does not rule out another low-rank correction.
--transfer       shared-ancestor cross-history packages: for each host's first layer, the additions of one variant
                 (or none) x the L2..LK changes of one variant (or none = f0).  A matched foreign package replaces
                 every addition and every later layer (the share of replaced parameters is recorded); contrasts
                 against mismatched packages, the parts alone, the donor's and the host's native networks and f0.
--fold           the additions' output u(h) at their merge (h = the value they read) replaced by nothing (zero =
                 the deletion), its training mean, or its least-squares affine fit M h + c on TRAINING activations,
                 folded exactly into the one layer that reads the merge (W' = W (I + M), b' = b + W c): a compact
                 network of f0's architecture.  Then that network's later layers moved linearly to f0's
                 (t in FOLD_PATH), ending at the extraction.  The folded network is checked against the same
                 surrogate applied inside the expanded graph.

Checks (any failure fails the group): every loaded state equals its intended tensors bitwise; gates at 1 reproduce
the checkpoint, every addition deleted reproduces a compact deletion and the extraction built independently on f0's
graph, a host's own package and no package reproduce its native network and its extraction, on EVERY evaluated
partition; the checkpoint's age equals the configured expansion length; the variants share f0 and structure.
Nothing is selected on test data.  Exploratory reanalysis of existing checkpoints.

usage: coordinated_edits.py RESULTS OUT_PREFIX --manifest M [--data-root D] [--device cpu|cuda] [--strict]
                            [--expect-variants A,B,..] [--minimal-edits] [--rank-restores] [--transfer] [--fold]
                            [--save-preds DIR]
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import sys
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import selective_reversal as SR  # noqa: E402

torch = SR.torch
AC = SR.AC
Fail = SR.Fail
E = SR.E
GraphNet = SR.GraphNet

ANALYSIS_SCHEMA = "coordinated_edits/v52"
STATUS = "exploratory reanalysis of existing checkpoints (no new training)"
MARGIN = 0.01
CRITERIA = {
    "native": "candidate error <= the expanded (native) network's + margin: the removal keeps its performance",
    "extraction": "candidate error <= the extraction's + margin: as good as deleting everything and rewinding every "
                  "later layer",
    "f0": "candidate error <= f0's + margin: no worse than the network before expansion",
    "legacy_worse_endpoint": "v49's rule: candidate error <= max(native, extraction) + margin (permissive: the "
                             "worse endpoint)",
}
PRIMARY = ("native", "val")
SELECTION_ACCESS = {
    "val": "source-distribution validation (the panel's declared selection partition)",
    "val_indep": "validation data from the shortcut-independent evaluation distribution (target-distribution "
                 "access)",
}
FALLBACK = "the unedited expanded network (nothing deleted, nothing rewound)"
VARIANT_TRAIN_KEYS = ("freeze_inputs", "freeze_backbone")     # trajectory settings that define a variant, not a cell
RANKS = (0, 1, 2, 4, 8, "full")
ONE_LAYER_RANKS = (0, 1, 2, 4)
SPECTRUM_KS = (1, 2, 4, 8)
FOLDS = ("zero", "mean", "affine")
FOLD_PATH = (0.0, 0.25, 0.5, 0.75, 1.0)          # segment 2: the folded network's later layers moved to f0's
LAMBDAS = (1.0, 0.75, 0.5, 0.25, 0.0)            # segment 1: the additions' residual u - surrogate scaled by lambda
SEGMENTS = ("1_residual_removal", "2_fold_to_extraction")
# NUMERICAL tolerance of the fold's implementation: the folded compact network against the same surrogate applied
# inside the expanded graph (max |logit difference| relative to max(1, max |logit|), every evaluated partition).
# It says nothing about how well a surrogate approximates the additions; that is reported, with no threshold.
FOLD_TOL = 1e-4
LSTSQ_RCOND = 1e-10           # the affine fit's singular-value cutoff (relative to the largest), declared
FOLD_FAULTS = ("transpose", "bias", "layer")     # self-test only: a deliberately wrong fold must fail the run
# v52
GAINS = (0.9, 0.95, 1.0, 1.05, 1.1, 1.25, 1.5, 1.75, 2.0, 3.0, 4.0)     # f0's input block scaled by these, declared
GAIN_BLOCKS = ("causal", "shortcut")
FD_EPS = 0.01                 # central finite difference in the log-gain: gains exp(-eps), exp(+eps)
FD_TOL = (0.10, 5e-5)         # the autograd gain derivative against it: relative, or absolute for tiny values
FOLD_RANKS = (1, 2, 4)        # the affine map truncated to its top singular directions before folding
ALIGN_MODES = ("none", "rescale", "permute", "permute_rescale")
ALIGN_NOTE = ("hidden units of the folded network matched to the extraction's (activation correlation on training "
              "data, optimal assignment) and / or positively rescaled to the matched unit's RMS activation; both "
              "preserve a ReLU chain's function in exact arithmetic")
SUBGROUPS = ("all", "shortcut_sign_agrees", "shortcut_sign_disagrees", "majority", "rare", "majority_agrees",
             "majority_disagrees", "rare_agrees", "rare_disagrees", "f0_correct", "f0_error")
TRANSFER_KIND = "shared_ancestor_cross_history_package"
BASE_METRICS = ("test_err", "test_ce", "val_err", "val_indep_err", "shift_err", "rare_err", "shortcut_flip_rate")
DERIVED = ("gain_vs_f0", "minus_native", "minus_extraction", "dis_native", "dis_f0", "dis_extraction",
           "logit_rms_native", "logit_rms_f0")
METRICS = BASE_METRICS + DERIVED
CHOSEN = ("test_err", "val_err", "val_indep_err", "shift_err", "gain_vs_f0", "minus_native", "minus_extraction",
          "dis_f0", "dis_native", "n_restored")
POPULATIONS = {"chosen": "selected runs only (conditional on success)",
               "policy": f"all runs (fallback: {FALLBACK})"}


def subsets(xs):
    return [tuple(c) for r in range(len(xs) + 1) for c in itertools.combinations(xs, r)]


def label(xs) -> str:
    return "+".join(xs) if xs else "none"


def sha256_file(p) -> str:
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()[:16]


# ----------------------------------------------------------------------------- design: experiments and groups

def _no_seeds(d: dict) -> dict:
    return {k: v for k, v in (d or {}).items() if not k.endswith("_seed")}


def experiment_id(rcfg: dict, tcfg: dict) -> str:
    """The experiment (cell) a full removal job belongs to: its contrast label plus a hash of everything that
    defines the setting (data without its seeds, architecture, growth and cut, training and removal protocol)
    EXCEPT the variant: the removal's design.variant and the trajectory's VARIANT_TRAIN_KEYS.  Draw and optimizer
    seed are appended by the caller for the group identity."""
    r = json.loads(json.dumps(rcfg))
    (r.get("design") or {}).pop("variant", None)
    r.pop("parents", None)
    r.pop("seeds", None)
    r["data"] = _no_seeds(r.get("data"))
    t = {"data": _no_seeds(tcfg.get("data")), "model": tcfg.get("model"), "growth": tcfg.get("growth"),
         "train": {k: v for k, v in (tcfg.get("train") or {}).items() if k not in VARIANT_TRAIN_KEYS}}
    name = (rcfg.get("design") or {}).get("contrast") or "experiment"
    return f"{name}#{SR.stable_hash({'removal': r, 'trajectory': t})[:8]}"


def group_jobs(mcfg: dict, expect=None) -> tuple:
    """-> (groups {(experiment, data draw, optimizer seed): {variant: run id}}, declared {experiment: variants}).
    The declared variants are `expect` when given (the design), else every variant the experiment has anywhere."""
    groups, cells = defaultdict(dict), defaultdict(set)
    for rid, c in mcfg.items():
        if SR.eligible(c) != ("removal", "full"):
            continue
        tid = (c.get("parents") or {}).get("trajectory")
        if tid not in mcfg:
            raise Fail(f"{rid}: its trajectory {tid} is not in the manifest")
        ex = experiment_id(c, mcfg[tid])
        v = (c.get("design") or {}).get("variant")
        k = (ex, (c.get("data") or {}).get("data_seed"), (c.get("seeds") or {}).get("optimizer"))
        if v in groups[k]:
            raise Fail(f"two full removal jobs for variant {v} in group {k}")
        groups[k][v] = rid
        cells[ex].add(v)
    return dict(groups), {ex: (set(expect) if expect else set(vs)) for ex, vs in cells.items()}


def expected_age(tcfg: dict) -> int:
    """the configured expansion length in updates (per-round schedules only)."""
    g = tcfg.get("growth") or {}
    if g.get("compute_schedule", "per_round") != "per_round" or int(g.get("total_updates", 0) or 0):
        raise Fail("the expected checkpoint age is defined for per-round growth schedules only")
    return int(g["updates_per_round"]) * int(g.get("rounds", 1))


def check_age(actual: int, expected: int, what: str) -> None:
    if int(actual) != int(expected):
        raise Fail(f"{what}: the checkpoint is {actual} updates after f0, its configured age is {expected}")


# ----------------------------------------------------------------------------- edits: tensors and their checks

def edit_tensors(f0_sd: dict, lkeys: dict, rewound) -> dict:
    """the tensors an edit sets: f0's own tensors for every layer in `rewound` (whole-layer rewind)."""
    return {k: f0_sd[k] for Lk in rewound for k in lkeys[Lk]}


def verify_patch(sd: dict, want: dict, what: str) -> None:
    """a loaded state equals its intended tensors: same keys, every tensor bitwise; else the group fails."""
    if set(sd) != set(want):
        raise Fail(f"{what}: the loaded state's parameter set differs from the intended one")
    for k, v in sd.items():
        w = want[k]
        if v.shape != w.shape or not torch.equal(v.cpu(), w.to(v.dtype).cpu()):
            raise Fail(f"{what}: {k} is not the intended tensor")


def same_everywhere(pa: dict, pb: dict) -> bool:
    """two models' outputs are bitwise equal on every evaluated partition."""
    return set(pa) == set(pb) and all(torch.equal(pa[p], pb[p]) for p in pa)


def minimal_sets(points: dict, thr: float) -> tuple:
    """Selection from one partition's errors only (no test argument).  points: rewind-set tuple -> error on the
    selection partition, for one deleted subset.  -> (candidates, minimal, chosen): candidates meet the threshold;
    minimal ones have no candidate proper subset (inclusion-minimal); chosen = the smallest candidate with the
    lowest error (minimum cardinality; ties by name)."""
    cand = [r for r, v in points.items() if v <= thr]
    cs = set(cand)
    mins = [r for r in cand if not any(set(o) < set(r) for o in cs)]
    chosen = min(cand, key=lambda r: (len(r), points[r], label(r))) if cand else None
    return sorted(cand, key=lambda r: (len(r), label(r))), sorted(mins, key=lambda r: (len(r), label(r))), chosen


def selection_rows(meta: dict, rows: dict, refs: dict, sel_parts, leaves, n_later: int) -> list:
    """One row per deleted subset x criterion x selection partition.  rows: {(deleted tuple, rewound tuple): metric
    row}; refs: {'native' | 'extraction' | 'f0': {'<partition>_err': ..}}.  The chosen set's metrics are None when
    nothing qualifies (conditional on success); the policy metrics always exist: the chosen edit, or the fallback
    (the unedited expanded network, rows[((), ())])."""
    out = []
    fb = rows[((), ())]
    allS = tuple(leaves)
    for S in subsets(leaves)[1:]:
        mine = {R: r for (S_, R), r in rows.items() if S_ == S}
        for sp in sel_parts:
            ek = f"{sp}_err"
            ref = {c: refs[c][ek] for c in ("native", "extraction", "f0")}
            ref["legacy_worse_endpoint"] = max(ref["native"], ref["extraction"])
            for crit in CRITERIA:
                thr = ref[crit] + MARGIN
                cand, mins, ch = minimal_sets({R: r[ek] for R, r in mine.items()}, thr)
                cr = mine[ch] if ch is not None else None
                pol = cr if cr is not None else fb
                byc = S == allS and crit in ("extraction", "legacy_worse_endpoint")
                out.append({
                    **meta, "deleted": label(S), "n_deleted": len(S), "criterion": crit,
                    "selection_partition": sp, "selection_access": SELECTION_ACCESS.get(sp, sp),
                    "is_primary": (crit, sp) == PRIMARY, "margin": MARGIN,
                    "reference_model": crit, "reference_sel_err": ref[crit], "threshold": thr,
                    "edit_menu": f"whole-layer rewinds of L2..L{n_later + 1} to f0 ({2 ** n_later} sets)",
                    "qualifies_by_construction": "the full rewind (it defines the reference)" if byc else "",
                    "removable": ch is not None, "n_candidates": len(cand),
                    # how close the selection is to changing: the smallest |error - threshold| over the menu
                    "nearest_threshold_distance": min(abs(r[ek] - thr) for r in mine.values()),
                    "inclusion_minimal_sets": "|".join(label(m) for m in mins),
                    "min_size": len(ch) if ch is not None else None,
                    "chosen": label(ch) if ch is not None else None,
                    "chosen_sel_err": cr[ek] if cr else None,
                    "chosen_sel_delta": cr[ek] - ref[crit] if cr else None,
                    **{f"chosen_{m}": (cr.get(m) if cr else None) for m in CHOSEN},
                    "policy_is_fallback": cr is None, "policy_fallback": FALLBACK,
                    "policy_additions_deleted": len(S) if cr else 0,
                    "policy_additions_remaining": len(leaves) - (len(S) if cr else 0),
                    **{f"policy_{m}": pol.get(m) for m in CHOSEN}})
    return out


SEL_KEYS = ("experiment", "cell", "variant", "deleted", "n_deleted", "criterion", "selection_partition",
            "selection_access", "is_primary", "margin")


def selection_summary(sel_rows: list, expected_runs: dict) -> tuple:
    """-> (counts, by_draw, summary).  counts: per setting the expected, analysed and selected runs, the draws with
    every / some / no optimizer seed selected.  The summary is long: metric x population, where 'chosen' metrics
    average the selected runs only (conditional on success; a draw may contribute fewer seeds, see by_draw's
    optimizer_settings and the counts) and 'policy' metrics average every analysed run with the fallback."""
    per = defaultdict(list)
    for r in sel_rows:
        per[tuple(r[k] for k in SEL_KEYS)].append(r)
    counts, long_ = [], []
    cmap = {}
    for k, rs in sorted(per.items(), key=lambda t: tuple(map(str, t[0]))):
        draws = defaultdict(list)
        for r in rs:
            draws[r["data_draw"]].append(bool(r["removable"]))
        kd = dict(zip(SEL_KEYS, k))
        c = {**kd, "runs_expected": expected_runs.get((kd["experiment"], kd["variant"])),
             "runs_analysed": len(rs), "runs_selected": sum(bool(r["removable"]) for r in rs),
             "success_rate_runs": sum(bool(r["removable"]) for r in rs) / len(rs),
             "draws": len(draws), "draws_every_seed_selected": sum(all(v) for v in draws.values()),
             "draws_partially_selected": sum(any(v) and not all(v) for v in draws.values()),
             "draws_no_seed_selected": sum(not any(v) for v in draws.values()),
             "fallback": FALLBACK}
        counts.append(c)
        cmap[k] = c
        for r in rs:
            base = {**kd, "data_draw": r["data_draw"], "optimizer_seed": r["optimizer_seed"]}
            for pop in POPULATIONS:
                if pop == "chosen" and not r["removable"]:
                    continue
                for m in CHOSEN + (("additions_deleted", "is_fallback") if pop == "policy" else ()):
                    v = r.get(f"{pop}_{m}")
                    if v is not None:
                        long_.append({**base, "metric": m, "population": POPULATIONS[pop], "v": float(v)})
    bd, sm = SR.two_stage(long_, SEL_KEYS + ("metric", "population"), "v")
    for r in sm:
        c = cmap[tuple(r[k] for k in SEL_KEYS)]
        cond = r["population"] == POPULATIONS["chosen"]
        r.update({"runs_contributing": c["runs_selected"] if cond else c["runs_analysed"],
                  "runs_analysed": c["runs_analysed"], "runs_expected": c["runs_expected"],
                  "draws_partially_selected": c["draws_partially_selected"] if cond else 0})
    return counts, bd, sm


# ----------------------------------------------------------------------------- rank-k restores

def rank_k_restore(w, w0, k) -> tuple:
    """w minus the best rank-k approximation of (w - w0), the subtraction and the SVD in float64; k = 'full' -> w0's
    own tensor.  -> (tensor, info): effective rank used, the share of the change's energy removed (None when the
    layer did not change at all: a convention would not be evidence), zero_change."""
    d = w.double() - w0.double()
    tot = float((d * d).sum())
    cap = min(d.shape)
    if k == "full":
        return w0.clone(), {"eff_rank": cap, "energy": None if tot == 0.0 else 1.0, "zero_change": tot == 0.0}
    kk = min(int(k), cap)
    if kk == 0 or tot == 0.0:
        return w.clone(), {"eff_rank": 0, "energy": None if tot == 0.0 else 0.0, "zero_change": tot == 0.0}
    U, S, Vh = torch.linalg.svd(d, full_matrices=False)
    ak = (U[:, :kk] * S[:kk]) @ Vh[:kk]
    return (w.double() - ak).to(w.dtype), {"eff_rank": kk, "energy": float((S[:kk] ** 2).sum() / tot),
                                           "zero_change": False}


def change_spectrum(w, w0) -> dict:
    d = w.double() - w0.double()
    tot = float((d * d).sum())
    o = {"shape_out": d.shape[0], "shape_in": d.shape[1], "max_rank": min(d.shape), "change_fro": tot ** 0.5,
         "f0_fro": float((w0.double() ** 2).sum()) ** 0.5, "zero_change": tot == 0.0}
    if tot == 0.0:
        return {**o, "numerical_rank": 0, **{f"energy_top{k}": None for k in SPECTRUM_KS}}
    S = torch.linalg.svdvals(d)
    # singular values above the weights' own precision (their dtype's epsilon x the largest x the larger dimension)
    o["numerical_rank"] = int((S > S.max() * max(d.shape) * torch.finfo(w.dtype).eps).sum())
    o.update({f"energy_top{k}": float((S[:k] ** 2).sum() / tot) for k in SPECTRUM_KS})
    return o


STORAGE_CONVENTION = ("factor storage of a rank-k correction = k (m + n) numbers (two factors, singular values "
                      "absorbed), a full rewind = m n, a restored bias = its length; a layer or bias that already "
                      "equals f0's needs none.  intrinsic dimension = k (m + n - k).  Neither is the number of "
                      "changed entries: a rank-1 correction can change every entry")


def rank_storage(shape, eff_rank: int, full: bool, zero_change: bool) -> tuple:
    """-> (factor storage, intrinsic dimension) of one weight matrix's correction, by STORAGE_CONVENTION."""
    m, n = int(shape[0]), int(shape[1])
    if zero_change:
        return 0, 0
    if full:
        return m * n, m * n
    k = int(eff_rank)
    return k * (m + n), k * (m + n - k)


def entries_changed(before: dict, after: dict) -> int:
    """the number of tensor entries an edit actually changes (exact comparison), over the tensors in `after`."""
    return sum(int((after[k].to(before[k].dtype).cpu() != before[k].cpu()).sum()) for k in after)


def rank_plans(names: list) -> list:
    """The declared rank schemes for later layers `names` (the last is the head).  Each plan maps a layer to
    (weight, bias): weight in 'keep' | k | 'full', bias True = restored to f0's.  v49_scheme names the v49 rows a
    plan reproduces."""
    head, hidden = names[-1], names[:-1]
    P = []

    def add(scheme, v49, target, k, spec, note=""):
        P.append({"scheme": scheme, "v49_scheme": v49, "target_layer": target, "rank": str(k), "spec": spec,
                  "note": note})
    add("no_edit", "", "none", "none", {n: ("keep", False) for n in names}, "every addition deleted, nothing restored")
    for k in RANKS:
        add("all_later_topk_bias_restored", "all_layers", "all", k, {n: (k, True) for n in names},
            "BIAS-ONLY edit" if k == 0 else "")
    for k in RANKS[1:]:
        add("all_later_topk_bias_kept", "", "all", k, {n: (k, False) for n in names})
    for t in names:
        for k in ONE_LAYER_RANKS:
            add("partial_target_layer_other_layers_full", "one_layer", t, k,
                {n: ((k if n == t else "full"), True) for n in names},
                "the OTHER later layers are fully rewound; not a correction confined to one layer")
    if hidden:
        add("head_only_full", "", head, "full", {**{n: ("keep", False) for n in hidden}, head: ("full", True)})
        for k in RANKS[:-1]:
            add("hidden_topk_head_full", "", "hidden", k, {**{n: (k, True) for n in hidden}, head: ("full", True)},
                "hidden biases and the whole head only" if k == 0 else "")
        for k in RANKS[1:]:
            add("hidden_topk_head_kept", "", "hidden", k, {**{n: (k, True) for n in hidden}, head: ("keep", False)})
    return P


# ----------------------------------------------------------------------------- fold

def fold_site(g, leaves, L) -> tuple:
    """Where the additions merge: -> (the node whose value they read and that the merge skips, the merge node, the
    one backbone layer that reads the merge).  Refused unless every leaf is a term of one 'add' merge whose first
    term is the skip and whose value reaches exactly one backbone linear layer (through identity nodes)."""
    ms = {g.implants[t].merge for t in leaves}
    if len(ms) != 1 or None in ms:
        raise Fail("fold: the additions do not share one merge node")
    mid = ms.pop()
    m = g.nodes[mid]
    terms = m.attrs.get("terms") or []
    if m.op != "add" or not terms or terms[0] != "skip" or set(terms[1:]) != set(leaves):
        raise Fail("fold: the merge is not skip + the leaf additions")
    coefs, gates = m.attrs.get("coefs") or [], m.attrs.get("gates") or [None] * len(terms)
    if len(coefs) != len(terms) or float(coefs[0]) != 1.0 or gates[0] is not None:
        raise Fail("fold: the skip term's coefficient is not 1 (or it is gated); W (I + M) assumes h + u(h)")
    cur = mid
    while True:
        cons = g.consumers(cur)
        if len(cons) != 1:
            raise Fail("fold: the merge does not feed exactly one node")
        n = g.nodes[cons[0][0]]
        if n.op == "identity":
            cur = n.id
            continue
        if n.op != "linear" or n.pkey not in L or n.owner is not None:
            raise Fail("fold: the merge is not read by one backbone linear layer")
        return m.inputs[0], mid, n.pkey


def affine_fit(H, U) -> tuple:
    """least squares U ~ H M^T + 1 c^T in float64 on the CPU (minimum-norm solution, singular values below
    LSTSQ_RCOND x the largest dropped).  -> (M, c, info): the augmented design's conditioning."""
    H, U = H.double().cpu(), U.double().cpu()
    A = torch.cat([H, torch.ones(H.shape[0], 1, dtype=torch.float64)], 1)
    Th = torch.linalg.lstsq(A, U, rcond=LSTSQ_RCOND, driver="gelsd").solution
    sv = torch.linalg.svdvals(A)
    info = {"design_rows": int(A.shape[0]), "design_cols": int(A.shape[1]), "design_sv_max": float(sv.max()),
            "design_sv_min": float(sv.min()), "design_rank": int((sv > LSTSQ_RCOND * sv.max()).sum()),
            "design_cond": float(sv.max() / sv.min()) if float(sv.min()) > 0 else None, "lstsq_rcond": LSTSQ_RCOND}
    return Th[:-1].T.contiguous(), Th[-1].contiguous(), info


def surrogate_value(h, M, c):
    """h + s(h) with s(h) = M h + c (M None: the constant c), in float64, cast back: the surrogate at the merge."""
    hd = h.double()
    return (hd + ((hd @ M.T + c) if M is not None else c)).to(h.dtype)


def fold_into(W, b, M, c, fault=None) -> tuple:
    """the layer reading h + (M h + c) written as one layer on h: W' = W (I + M), b' = b + W c (float64, cast back).
    `fault` (self-test only) builds a deliberately wrong fold: M transposed, or the bias term's sign flipped."""
    Wd, bd = W.double().cpu(), b.double().cpu()
    if M is not None and fault == "transpose":
        M = M.T
    Wn = Wd if M is None else Wd @ (torch.eye(Wd.shape[1], dtype=torch.float64) + M)
    bn = bd - Wd @ c if fault == "bias" else bd + Wd @ c
    return Wn.to(W.dtype).to(W.device), bn.to(b.dtype).to(b.device)


def r2(U, F) -> float:
    """1 - |U - F|^2 / |U - mean(U)|^2 (None when U is constant)."""
    U, F = U.double().cpu(), F.double().cpu()
    den = float(((U - U.mean(0)) ** 2).sum())
    return None if den == 0.0 else 1.0 - float(((U - F) ** 2).sum()) / den


def residual_share(U, F, W=None) -> float:
    """|U - F|^2 / |U|^2: the share of the additions' output energy a surrogate F leaves out; with W, both are
    first passed through the receiving layer (|W (U - F)|^2 / |W U|^2).  None when U is zero."""
    U, F = U.double().cpu(), F.double().cpu()
    if W is not None:
        Wd = W.double().cpu()
        U, F = U @ Wd.T, F @ Wd.T
    den = float((U ** 2).sum())
    return None if den == 0.0 else float(((U - F) ** 2).sum()) / den


def implementation_check(p_fold: dict, p_surr: dict, what: str) -> dict:
    """The folded compact network against the same surrogate inside the expanded graph, on EVERY evaluated
    partition: relative max |logit difference| within FOLD_TOL, else the group fails.  Decisions that differ are
    counted per partition with the surrogate's largest margin among them: within the tolerance a decision can only
    differ where that margin is at most twice the logit difference (a near-tie), which is asserted."""
    if set(p_fold) != set(p_surr):
        raise Fail(f"{what}: the folded network and the surrogate were evaluated on different partitions")
    o, worst, ndiff = {}, 0.0, 0
    for p in sorted(p_fold):
        a_, b_ = p_fold[p].double(), p_surr[p].double()
        scale = max(1.0, float(b_.abs().max()))
        rel = float((a_ - b_).abs().max()) / scale
        differ = a_.argmax(-1) != b_.argmax(-1)
        top2 = b_.topk(2, -1).values
        mg = float((top2[:, 0] - top2[:, 1])[differ].max()) if bool(differ.any()) else 0.0
        o[f"impl_rel_diff_{p}"], o[f"impl_decisions_differ_{p}"] = rel, int(differ.sum())
        o[f"impl_max_margin_of_differing_{p}"] = mg
        worst, ndiff = max(worst, rel), ndiff + int(differ.sum())
        if rel > FOLD_TOL:
            raise Fail(f"{what}: the folded network differs from the surrogate inside the expanded graph on {p} "
                       f"(relative {rel:.3g} > {FOLD_TOL:g})")
        if mg > 2 * FOLD_TOL * scale:
            raise Fail(f"{what}: a decision differs from the surrogate's on {p} at margin {mg:.3g}, more than the "
                       f"logit difference explains")
    return {"impl_max_rel_diff": worst, "impl_decisions_differ_total": ndiff, "impl_tolerance": FOLD_TOL,
            "impl_check_applies_to": "segment 2 at rewind_t = 0 (the folded network vs the in-graph surrogate)", **o}


def subgroup_masks(x_shortcut, y, groups, f0_correct) -> dict:
    """Training subgroups.  shortcut_sign_agrees: the OBSERVED shortcut's sign points at the label (the generator's
    latent agreement variable is not stored; with shortcut noise the observed sign can differ from it).  rare: the
    generator's group whose labels follow another rule.  The two are independent mechanisms."""
    agree = (x_shortcut > 0) == (y == 1)
    rare = groups == 1
    m = {"all": torch.ones_like(agree), "shortcut_sign_agrees": agree, "shortcut_sign_disagrees": ~agree,
         "majority": ~rare, "rare": rare, "majority_agrees": ~rare & agree, "majority_disagrees": ~rare & ~agree,
         "rare_agrees": rare & agree, "rare_disagrees": rare & ~agree, "f0_correct": f0_correct,
         "f0_error": ~f0_correct}
    assert tuple(m) == SUBGROUPS
    return m


# ----------------------------------------------------------------------------- v52: chain, alignment, channel

def mlp_forward(tensors: dict, x, wkeys: list, bkeys: list) -> tuple:
    """a plain ReLU chain evaluated from its tensors in float64: -> (post-activations of each hidden layer, logits)."""
    h, acts, z = x.double(), [], None
    for i, (wk, bk) in enumerate(zip(wkeys, bkeys)):
        z = h @ tensors[wk].double().T + tensors[bk].double()
        if i < len(wkeys) - 1:
            h = z.clamp_min(0.0)
            acts.append(h)
    return acts, z


def unit_alignment(AF, AX, permute: bool, rescale: bool) -> tuple:
    """Hidden units of F matched to X's from their activations on the same inputs.  permute: the assignment that
    maximises the summed activation correlation (else identity).  rescale: each F unit scaled to its matched X
    unit's RMS activation (1 where either is dead).  -> (order, alpha, info): position p of the aligned layer holds
    F's unit order[p], scaled by alpha[order[p]]."""
    AF, AX = AF.double().cpu(), AX.double().cpu()
    m = AF.shape[1]

    def std(A):
        A = A - A.mean(0)
        n_ = A.norm(dim=0)
        return torch.where(n_ > 0, A / n_.clamp_min(1e-300), torch.zeros_like(A))
    C = std(AF).T @ std(AX)                                   # C[i, j]: F's unit i against X's unit j
    ar = torch.arange(m)
    if permute:
        from scipy.optimize import linear_sum_assignment
        ri, cj = linear_sum_assignment(-C.numpy())
        pi = torch.empty(m, dtype=torch.long)
        pi[torch.as_tensor(ri)] = torch.as_tensor(cj)
    else:
        pi = ar.clone()
    rF, rX = (AF ** 2).mean(0).sqrt(), (AX ** 2).mean(0).sqrt()[pi]
    alpha = torch.where((rF > 0) & (rX > 0), rX / rF.clamp_min(1e-300), torch.ones_like(rF)) if rescale \
        else torch.ones(m, dtype=torch.float64)
    info = {"units_moved": int((pi != ar).sum()), "matched_corr_mean": float(C[ar, pi].mean()),
            "identity_corr_mean": float(C[ar, ar].mean()), "alpha_median": float(alpha.median()),
            "alpha_min": float(alpha.min()), "alpha_max": float(alpha.max())}
    return torch.argsort(pi), alpha, info


def apply_alignment(W, b, Wn, order, alpha) -> tuple:
    """One hidden layer's units scaled (row and bias x alpha, the next layer's column / alpha) and reordered; float64,
    cast back.  -> (W, b, next layer's W)."""
    Wd = (W.double().cpu() * alpha[:, None])[order]
    bd = (b.double().cpu() * alpha)[order]
    Wnd = (Wn.double().cpu() / alpha[None, :])[:, order]
    return Wd.to(W.dtype).to(W.device), bd.to(b.dtype).to(b.device), Wnd.to(Wn.dtype).to(Wn.device)


def rank_r_map(M, r: int, hbar, ubar) -> tuple:
    """the affine map's linear part truncated to its top r singular directions, the constant refitted so the
    surrogate keeps the training mean (c = mean u - M_r mean h).  -> (M_r, c_r)."""
    U, S, Vh = torch.linalg.svd(M.double().cpu(), full_matrices=False)
    k = min(int(r), S.numel())
    Mr = (U[:, :k] * S[:k]) @ Vh[:k]
    return Mr, ubar.double().cpu() - Mr @ hbar.double().cpu()


def corr(a_, b_) -> float:
    a_, b_ = a_.double().cpu().flatten(), b_.double().cpu().flatten()
    a_, b_ = a_ - a_.mean(), b_ - b_.mean()
    d = float(a_.norm() * b_.norm())
    return None if d == 0.0 else float((a_ * b_).sum()) / d


def trajectory_checkpoints(td, tcfg: dict) -> list:
    """the trajectory's saved states with additions, from its configuration: [(stage, declared updates since
    f0)], in order of age: each round at insertion, the configured snapshots, the end."""
    g = tcfg.get("growth") or {}
    U, R = int(g["updates_per_round"]), int(g.get("rounds", 1))
    out = [(f"post_insert_r{r}", (r - 1) * U) for r in range(1, R + 1)]
    out += [(f"snap_{u}", u) for u in sorted({int(u) for u in (tcfg.get("train") or {}).get("snapshot_at") or []
                                             if 0 < int(u) < R * U})]
    out.append(("final", R * U))
    return sorted(out, key=lambda t: (t[1], t[0] != "final", not t[0].startswith("snap_")))


def numerics_policy(dev) -> dict:
    """the declared numerical policy of this analysis, applied and recorded."""
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    return {"device": str(dev), "torch": torch.__version__, "cuda": torch.version.cuda,
            "gpu": torch.cuda.get_device_name(dev) if dev.type == "cuda" else None,
            "tf32": False, "cudnn_deterministic": True, "cudnn_benchmark": False,
            "evaluation_dtype": "each model's own parameter dtype", "svd_and_fits": "float64",
            "identities": "bitwise on this device; outputs of different devices are not compared bitwise"}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("results")
    ap.add_argument("out")
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--strict", action="store_true", help="exit 1 unless every group is analysed")
    ap.add_argument("--expect-variants", default=None, help="the design's variants, comma separated: every group "
                                                            "must hold exactly these")
    ap.add_argument("--minimal-edits", action="store_true")
    ap.add_argument("--rank-restores", action="store_true")
    ap.add_argument("--transfer", action="store_true")
    ap.add_argument("--fold", action="store_true")
    ap.add_argument("--train-diagnostics", action="store_true")
    ap.add_argument("--gain-scan", action="store_true")
    ap.add_argument("--age-course", action="store_true")
    ap.add_argument("--aligned-paths", action="store_true")
    ap.add_argument("--inject-fold-fault", default=None, choices=FOLD_FAULTS,
                    help="self-test only: build a deliberately wrong fold; the run must fail")
    ap.add_argument("--save-preds", default=None, metavar="DIR")
    a = ap.parse_args(argv)
    if not (a.minimal_edits or a.rank_restores or a.transfer or a.fold or a.train_diagnostics or a.gain_scan
            or a.age_course or a.aligned_paths):
        ap.error("nothing to do: give --minimal-edits, --rank-restores, --transfer, --fold, --train-diagnostics, "
                 "--gain-scan, --age-course and / or --aligned-paths")
    dev = torch.device(a.device)
    if dev.type == "cuda" and not torch.cuda.is_available():
        print("--device cuda requested but CUDA is not available", file=sys.stderr)
        return 2
    numerics = numerics_policy(dev)
    runs = Path(a.results) / "runs"
    mcfg = {e["run_id"]: e["cfg"] for e in AC.manifest_entries(a.manifest)}
    expect = [v for v in a.expect_variants.split(",") if v] if a.expect_variants else None
    groups, declared = group_jobs(mcfg, expect)
    expected_runs = defaultdict(int)
    for (ex, _, _), mem in groups.items():
        for v in declared[ex]:
            expected_runs[(ex, v)] += 1
    cov = {"tool": "coordinated_edits", "analysis_schema": ANALYSIS_SCHEMA, "status": STATUS,
           "results": str(Path(a.results).resolve()), "manifest": a.manifest,
           "manifest_sha256": sha256_file(a.manifest),
           "source_sha256": {p.name: sha256_file(p) for p in (Path(__file__), Path(SR.__file__),
                                                              Path(AC.__file__))},
           "numerics": numerics,
           "options": {k: getattr(a, k) for k in ("minimal_edits", "rank_restores", "transfer", "fold",
                                                  "train_diagnostics", "gain_scan", "age_course",
                                                  "aligned_paths", "inject_fold_fault", "device", "strict",
                                                  "expect_variants")},
           "selection": {"margin": MARGIN, "criteria": CRITERIA, "primary": list(PRIMARY),
                         "selection_access": SELECTION_ACCESS, "fallback": FALLBACK,
                         "menu": "whole-layer rewinds of the later layers to f0"},
           "ranks": [str(r) for r in RANKS], "transfer_kind": TRANSFER_KIND,
           "fold": {"implementation_tolerance": FOLD_TOL, "lstsq_rcond": LSTSQ_RCOND, "lambdas": list(LAMBDAS),
                    "rewind_t": list(FOLD_PATH), "fit_data": "train",
                    "note": "the tolerance is numerical (folded network vs in-graph surrogate); how well a "
                            "surrogate approximates the additions is reported without a threshold; paths are "
                            "sampled points"},
           "storage_convention": STORAGE_CONVENTION,
           "experiments": {ex: sorted(vs) for ex, vs in declared.items()},
           "expected_groups": len(groups),
           "expected_runs": sum(len(declared[k[0]]) for k in groups),
           "analysed_groups": 0, "analysed_runs": 0, "failed": [], "excluded": []}
    out = defaultdict(list)
    bundles = {}
    for gk in sorted(groups, key=lambda t: tuple(map(str, t))):
        members = groups[gk]
        ex = gk[0]
        gname = f"{ex}/{gk[1]}/{gk[2]}"
        staged = defaultdict(list)
        try:
            if set(members) != declared[ex]:
                raise Fail(f"group {gname}: variants {sorted(members)}, the design declares {sorted(declared[ex])}")
            V = sorted(members)
            st = {}
            for v in V:
                rid = members[v]
                why = AC.declared_invalid(runs / rid, mcfg[rid])
                if why:
                    raise Fail(f"{rid}: declared invalid ({why})")
                cfg = AC.job_config(runs, rid, mcfg[rid])
                tid = cfg["parents"]["trajectory"]
                tcfg = AC.job_config(runs, tid, mcfg.get(tid))
                stage = (cfg.get("tags") or {}).get("parent_stage", "final")
                if stage != "final":
                    raise Fail(f"{rid}: starts from the trajectory's {stage!r}, only its end is analysed")
                st[v] = {"rid": rid, "tid": tid, "cfg": cfg, "tcfg": tcfg, "stage": stage,
                         "age": expected_age(tcfg)}
            dkeys = {json.dumps(s["cfg"]["data"], sort_keys=True) for s in st.values()}
            if len(dkeys) != 1 or len({s["age"] for s in st.values()}) != 1:
                raise Fail(f"group {gname}: the variants differ in data or in expansion length")
            dk = dkeys.pop()
            if dk not in bundles:
                b0 = SR.load_bundle(json.loads(dk), a.data_root, device="cpu")
                bundles[dk] = (b0.to(dev), b0.hashes())
            b, hashes = bundles[dk]
            if b.task != "classification":
                raise Fail(f"group {gname}: task {b.task!r}; only classification is supported")
            need = {"train", *AC.eval_partitions(b)}
            parts = b.partitions()
            ps = AC.eval_partitions(b)
            sel_parts = [p for p in SELECTION_ACCESS if p in ps]
            save_parts = ["test", *sel_parts]
            batch = int((st[V[0]]["cfg"].get("train") or {}).get("eval_batch", 4096))
            y = {p: parts[p].y.to(dev).long() for p in save_parts}

            def measure(m):
                o, pr = AC.finite_eval(m, b, ps, batch, "edit")
                o["test_ce"] = float(torch.nn.functional.cross_entropy(pr["test"].double(), y["test"]))
                return o, pr

            f0_ids = set()
            for v in V:
                s = st[v]
                AC.check_logged_data(runs / s["tid"], hashes, need, f"{s['tid']} data provenance")
                f0k = SR.ckp(runs / s["tid"], "baseline_ref")
                f0g = AC.check_ckpt(f0k, f"{v} f0", run_id=s["tid"], stage="baseline_ref", cfg=s["tcfg"],
                                    hashes=hashes, need=need)
                ck = SR.ckp(runs / s["tid"], s["stage"])
                AC.check_ckpt(ck, f"{v} end", run_id=s["tid"], stage=s["stage"], cfg=s["tcfg"], hashes=hashes,
                              need=need)
                s["f0_param_hash"], s["f0_graph_hash"] = AC.param_hash_of(f0k), f0g.structural_hash()
                f0_ids.add((s["f0_param_hash"], s["f0_graph_hash"]))
                s["f0k"], s["ck"] = f0k, ck
                s["updates_since_f0"] = AC.job_update(ck, f0k, f"{v} end")
                check_age(s["updates_since_f0"], s["age"], f"{v} ({s['tid']})")
            if len(f0_ids) != 1:
                raise Fail(f"group {gname}: the variants do not share f0 (parameters and graph)")
            f0 = GraphNet.from_checkpoint(st[V[0]]["f0k"]["model"], dev).eval()
            f0_sd = {k: t.clone() for k, t in f0.state_dict().items()}
            L = SR.backbone_layers(f0)
            K = len(L)
            names = {Lk: f"L{i + 1}" for i, Lk in enumerate(L)}
            later = L[1:]
            lnames = [names[Lk] for Lk in later]
            lkeys = {Lk: [k for k in f0_sd if k.startswith(f"mods.{Lk}.")] for Lk in L}
            wkey, bkey = {}, {}
            for Lk in later:
                ws = [k for k in lkeys[Lk] if f0_sd[k].dim() == 2]
                bs = [k for k in lkeys[Lk] if f0_sd[k].dim() == 1]
                if len(ws) != 1 or len(bs) != 1 or len(lkeys[Lk]) != 2:
                    raise Fail(f"group {gname}: layer {names[Lk]} is not one weight matrix with a bias (convolution, "
                               f"attention and normalisation layers are not supported)")
                wkey[Lk], bkey[Lk] = ws[0], bs[0]
            f0e, f0p = measure(f0)
            f0_dec = f0p["test"].argmax(-1)
            n_par = lambda keys, sd: sum(int(sd[k].numel()) for k in keys)       # noqa: E731

            def compact(tensors: dict):
                """f0's graph with the given backbone tensors (an independent build of a compact network)."""
                m_ = GraphNet.from_checkpoint(st[V[0]]["f0k"]["model"], dev).eval()
                want = dict(m_.state_dict())
                want.update({k: t.to(want[k].device, want[k].dtype) for k, t in tensors.items()})
                m_.load_state_dict(want)
                m_._plan = None
                verify_patch(m_.state_dict(), want, "compact build")
                return m_

            for v in V:
                s = st[v]
                raw = GraphNet.from_checkpoint(s["ck"]["model"], dev).eval()
                if raw.gate_vals:
                    raise Fail(f"{v}: the end state already has gates")
                _, p_raw = measure(raw)
                g = GraphNet.from_checkpoint(s["ck"]["model"], dev).eval()
                gb = {k: t.clone() for k, t in g.state_dict().items()}
                for Lk in L:
                    if any(k not in gb or gb[k].shape != f0_sd[k].shape for k in lkeys[Lk]):
                        raise Fail(f"{v}: backbone tensors of {names[Lk]} differ in shape from f0's")
                leaves = sorted([t for t, im in g.implants.items() if im.nodes and not any(
                    o.parent == t and o.nodes for o in g.implants.values())], key=lambda s_: int(s_[1:]))
                if not leaves:
                    raise Fail(f"{v}: the end state has no additions")
                for t, im in g.implants.items():
                    if t not in leaves and any(g.nodes[n].pkey is not None and any(
                            True for _ in g.mods[g.nodes[n].pkey].parameters()) for n in im.nodes
                            if n in g.nodes):
                        raise Fail(f"{v}: the non-leaf addition {t} owns parameters (gating the leaves would not "
                                   f"remove it)")
                slots = {t: g.implants[t].slot for t in leaves}
                site = fold_site(g, leaves, L) if (a.fold or a.aligned_paths) else None
                gid = {t: E.add_gate(g, t, 1.0) for t in leaves}
                if set(g.state_dict()) != set(gb):
                    raise Fail(f"{v}: gating the additions changed the parameter set")
                bk = {k for Lk in L for k in lkeys[Lk]}
                s.update({"g": g, "gb": gb, "leaves": leaves, "gid": gid, "nonbackbone": sorted(set(gb) - bk),
                          "struct": g.structural_hash(), "site": site})

                def set_point(on, tensors, s=s):
                    s["g"].gate_vals = {s["gid"][t]: (1.0 if t in on else 0.0) for t in s["leaves"]}
                    want = dict(s["gb"])
                    want.update({k: t_.to(want[k].device, want[k].dtype) for k, t_ in tensors.items()})
                    s["g"].load_state_dict(want)
                    s["g"]._plan = None
                    verify_patch(s["g"].state_dict(), want, f"{s['rid']} edit")
                    return s["g"]
                s["set_point"] = set_point
                e_n, p_n = measure(set_point(set(leaves), {}))
                if not same_everywhere(p_n, p_raw):
                    raise Fail(f"{v}: the gated network at gates 1 does not reproduce the checkpoint's")
                ext = compact({k: gb[k] for k in lkeys[L[0]]} | edit_tensors(f0_sd, lkeys, later))
                e_x, p_x = measure(ext)
                dele = compact({k: gb[k] for Lk in L for k in lkeys[Lk]})
                e_d, p_d = measure(dele)
                s.update({"native": (e_n, p_n), "extraction": (e_x, p_x), "deletion": (e_d, p_d)})
                s["later_is_f0"] = all(torch.equal(gb[k], f0_sd[k].to(gb[k].dtype)) for Lk in later
                                       for k in lkeys[Lk])
                s["meta"] = {"experiment": ex, "group": gname, "run_id": s["rid"], "trajectory": s["tid"],
                             "variant": v, "cell": ((s["cfg"].get("design") or {}).get("contrast") or "")
                             .split("|")[-1], "draw_set": SR.draw_role(s["cfg"]), "data_draw": gk[1],
                             "optimizer_seed": gk[2], "state": "expansion end",
                             "updates_since_f0": s["updates_since_f0"], "leaves": " ".join(leaves)}
                rk_n = 23 + 4 * len(later) if len(later) > 1 else 12 + 4 * len(later)
                staged["checks"].append({
                    **s["meta"], "expected_updates_since_f0": s["age"], "age_matches_configuration": True,
                    "gates_1_reproduce_checkpoint_every_partition": True,
                    "non_leaf_additions_parameter_free": True, "f0_shared_in_group": True,
                    "f0_param_hash": s["f0_param_hash"], "f0_graph_hash": s["f0_graph_hash"],
                    "state_param_hash": (s["ck"].get("lineage") or {}).get("param_hash"),
                    "state_graph_hash": (s["ck"].get("lineage") or {}).get("graph_hash"),
                    "gated_structural_hash": s["struct"], "later_layers_equal_f0": s["later_is_f0"],
                    "leaf_slots": " ".join(f"{t}={slots[t]}" for t in leaves),
                    "n_leaves": len(leaves), "n_later_layers": len(later),
                    "later_layer_shapes": " ".join(f"{names[Lk]}={tuple(f0_sd[wkey[Lk]].shape)}" for Lk in later),
                    "partitions_evaluated": " ".join(ps), "selection_partitions": " ".join(sel_parts),
                    "expected_minimal_points": 2 ** len(leaves) * 2 ** len(later) if a.minimal_edits else 0,
                    "expected_selection_rows": (2 ** len(leaves) - 1) * len(CRITERIA) * len(sel_parts)
                    if a.minimal_edits else 0,
                    "expected_rank_points": rk_n if a.rank_restores else 0,
                    "expected_fold_points": len(FOLDS) * (len(LAMBDAS) + len(FOLD_PATH)) if a.fold else 0,
                    "expected_fold_fit_rows": len(FOLDS) if a.fold else 0,
                    "expected_train_group_rows": len(SUBGROUPS) if a.train_diagnostics else 0,
                    "expected_age_rows": len(trajectory_checkpoints(None, s["tcfg"])) if a.age_course else 0,
                    "expected_aligned_points": len(ALIGN_MODES) * len(FOLD_PATH) if a.aligned_paths else 0})
            if len({st[v]["struct"] for v in V}) != 1 or len({tuple(st[v]["nonbackbone"]) for v in V}) != 1 or \
                    len({tuple(st[v]["leaves"]) for v in V}) != 1:
                raise Fail(f"group {gname}: the variants' graphs differ in structure (incompatible donors)")

            def rms(za, zb):
                return float(((za.double() - zb.double()) ** 2).mean() ** 0.5)

            def row(s, e, pr, extra):
                dec = pr["test"].argmax(-1)
                r = {**s["meta"], **extra, **{k: e.get(k) for k in BASE_METRICS}}
                r["gain_vs_f0"] = f0e["test_err"] - e["test_err"]
                r["minus_native"] = e["test_err"] - s["native"][0]["test_err"]
                r["minus_extraction"] = e["test_err"] - s["extraction"][0]["test_err"]
                r["dis_native"] = float((dec != s["native"][1]["test"].argmax(-1)).double().mean())
                r["dis_f0"] = float((dec != f0_dec).double().mean())
                r["dis_extraction"] = float((dec != s["extraction"][1]["test"].argmax(-1)).double().mean())
                r["logit_rms_native"] = rms(pr["test"], s["native"][1]["test"])
                r["logit_rms_f0"] = rms(pr["test"], f0p["test"])
                return r

            def save(name, prs, meta_):
                """the decisions on the test and selection partitions (class indices) with the labels.  Errors are
                reproducible from these; cross-entropy is not (logits are not saved)."""
                if not a.save_preds:
                    return
                import numpy as np
                od = Path(a.save_preds)
                od.mkdir(parents=True, exist_ok=True)
                arrs = {}
                for p in save_parts:
                    arrs[f"preds_{p}"] = np.stack([pr[p].argmax(-1).cpu().numpy() for pr in prs]).astype(np.int16)
                    arrs[f"labels_{p}"] = y[p].cpu().numpy().astype(np.int16)
                np.savez_compressed(od / f"{name}.npz", meta=np.asarray(json.dumps(
                    {**meta_, "experiment": ex, "group": gname, "partitions": save_parts}, default=str)), **arrs)

            # ---- minimal coordinated edits
            grid_all = {}
            if a.minimal_edits:
                for v in V:
                    s = st[v]
                    rows_, prs, order = {}, [], []
                    allS = tuple(s["leaves"])
                    for S in subsets(s["leaves"]):
                        on = set(s["leaves"]) - set(S)
                        for R in subsets(later):
                            e, pr = measure(s["set_point"](on, edit_tensors(f0_sd, lkeys, R)))
                            Rn = tuple(names[Lk] for Lk in R)
                            if not S and not R and not same_everywhere(pr, s["native"][1]):
                                raise Fail(f"{v}: nothing deleted or rewound differs from the native network")
                            if S == allS and not R and not same_everywhere(pr, s["deletion"][1]):
                                raise Fail(f"{v}: every addition deleted, nothing rewound, differs from the compact "
                                           f"deletion")
                            if S == allS and len(R) == len(later) and not same_everywhere(pr, s["extraction"][1]):
                                raise Fail(f"{v}: every addition deleted and L2..L{K} rewound differs from the "
                                           f"extraction")
                            r = row(s, e, pr, {"deleted": label(S), "n_deleted": len(S), "restored": label(Rn),
                                               "n_restored": len(R)})
                            staged["minimal_edits"].append(r)
                            rows_[(S, Rn)] = r
                            if S == allS:
                                grid_all[(v, Rn)] = pr
                            prs.append(pr)
                            order.append(f"{label(S)}|{label(Rn)}")
                    refs = {"native": s["native"][0], "extraction": s["extraction"][0], "f0": f0e}
                    staged["minimal_sets"].extend(selection_rows(s["meta"], rows_, refs, sel_parts, s["leaves"],
                                                                 len(later)))
                    save(f"{s['rid']}__minimal_edits", prs, {"run_id": s["rid"], "order": order})
            # ---- rank-k restores (every addition deleted)
            if a.rank_restores:
                plans = rank_plans(lnames)
                byname = {names[Lk]: Lk for Lk in later}
                for v in V:
                    s = st[v]
                    for Lk in later:
                        staged["rank_layers"].append({**s["meta"], "layer": names[Lk], "is_head": Lk == later[-1],
                                                      **change_spectrum(s["gb"][wkey[Lk]],
                                                                        f0_sd[wkey[Lk]].to(s["gb"][wkey[Lk]].device))})
                    prs = []
                    for pl in plans:
                        tens, info, storage, intrinsic = {}, {}, 0, 0
                        for n_, (wk, bias) in pl["spec"].items():
                            Lk = byname[n_]
                            w, w0 = s["gb"][wkey[Lk]], f0_sd[wkey[Lk]].to(s["gb"][wkey[Lk]].device)
                            if wk == "keep":
                                info[n_] = {"eff_rank": 0, "energy": 0.0 if not change_is_zero(w, w0) else None}
                            else:
                                tens[wkey[Lk]], info[n_] = rank_k_restore(w, w0, wk)
                                fs, idim = rank_storage(w.shape, info[n_]["eff_rank"], wk == "full",
                                                        info[n_]["zero_change"])
                                storage, intrinsic = storage + fs, intrinsic + idim
                            if bias:
                                tens[bkey[Lk]] = f0_sd[bkey[Lk]]
                                if not change_is_zero(s["gb"][bkey[Lk]], f0_sd[bkey[Lk]].to(s["gb"][bkey[Lk]].device)):
                                    storage, intrinsic = storage + int(f0_sd[bkey[Lk]].numel()), \
                                        intrinsic + int(f0_sd[bkey[Lk]].numel())
                        e, pr = measure(s["set_point"](set(), tens))
                        if pl["scheme"] == "no_edit" and not same_everywhere(pr, s["deletion"][1]):
                            raise Fail(f"{v}: the rank table's no-edit point differs from the compact deletion")
                        if pl["scheme"] == "all_later_topk_bias_restored" and pl["rank"] == "full" and \
                                not same_everywhere(pr, s["extraction"][1]):
                            raise Fail(f"{v}: the full restore differs from the extraction")
                        if a.minimal_edits:
                            twin = {"head_only_full": (lnames[-1],),
                                    "hidden_topk_head_kept": tuple(lnames[:-1])}.get(pl["scheme"])
                            if twin and pl["rank"] == "full" and not same_everywhere(pr, grid_all[(v, twin)]):
                                raise Fail(f"{v}: {pl['scheme']} differs from the same whole-layer rewind in the "
                                           f"edit table")
                        staged["rank_restores"].append(row(s, e, pr, {
                            "scheme": pl["scheme"], "v49_scheme": pl["v49_scheme"],
                            "target_layer": pl["target_layer"], "rank": pl["rank"], "note": pl["note"],
                            **{f"weight_{n_}": str(pl["spec"][n_][0]) for n_ in lnames},
                            **{f"bias_{n_}": "restored" if pl["spec"][n_][1] else "kept" for n_ in lnames},
                            **{f"eff_rank_{n_}": info[n_]["eff_rank"] for n_ in lnames},
                            **{f"energy_restored_{n_}": info[n_]["energy"] for n_ in lnames},
                            "entries_changed": entries_changed(s["gb"], tens),
                            "correction_factor_storage": storage, "correction_intrinsic_dim": intrinsic,
                            "later_entries_total": n_par([k for Lk in later for k in lkeys[Lk]], f0_sd),
                            "inference_params": n_par([k for Lk in L for k in lkeys[Lk]], f0_sd),
                            "storage_convention": STORAGE_CONVENTION}))
                        prs.append(pr)
                    save(f"{s['rid']}__rank_restores", prs, {"run_id": s["rid"], "order": [
                        f"{p_['scheme']}|{p_['target_layer']}|{p_['rank']}" for p_ in plans]})
            # ---- shared-ancestor cross-history packages
            if a.transfer:
                ddon = [v for v in V if not st[v]["later_is_f0"]]
                res = {}
                for h in V:
                    s = st[h]
                    prs, order = [], []
                    n_add = n_par(s["nonbackbone"], s["gb"])
                    n_lat = n_par([k for Lk in later for k in lkeys[Lk]], s["gb"])
                    n_tot = n_par(list(s["gb"]), s["gb"])
                    hd = h if h in ddon else None
                    for i in (None, *V):
                        for j in (None, *ddon):
                            tens = {k: s["gb"][k] for k in lkeys[L[0]]}
                            tens.update({k: (st[j]["gb"][k] if j else f0_sd[k]) for Lk in later for k in lkeys[Lk]})
                            if i is not None:
                                tens.update({k: st[i]["gb"][k] for k in s["nonbackbone"]})
                            on = set(s["leaves"]) if i is not None else set()
                            e, pr = measure(s["set_point"](on, tens))
                            own = i == h and j == hd
                            if own and not same_everywhere(pr, s["native"][1]):
                                raise Fail(f"host {h}: its own package does not reproduce its native network")
                            if i is None and j is None and not same_everywhere(pr, s["extraction"][1]):
                                raise Fail(f"host {h}: no package does not reproduce its extraction")
                            kind = ("own" if own else "none" if i is None and j is None
                                    else "additions_only" if j is None else "changes_only" if i is None
                                    else "matched_foreign" if i == j else "mismatched")
                            from_donor = (n_add if i not in (None, h) else 0) + (n_lat if j not in (None, h) else 0)
                            r = row(s, e, pr, {
                                "transfer_kind": TRANSFER_KIND, "host": h, "addition_donor": i or "none",
                                "change_donor": j or "none (f0)", "package": kind,
                                "host_params_total": n_tot, "params_from_donor": from_donor,
                                "share_of_host_from_donor": from_donor / n_tot,
                                "params_deleted": n_add if i is None else 0,
                                "params_rewound_to_f0": n_lat if j is None and hd is not None else 0,
                                "host_keeps": "first layer" + (" + its additions" if i == h else "")
                                + (" + its later layers" if j == hd else "")})
                            dec = pr["test"].argmax(-1)
                            for nm, dv in (("dis_addition_donor_native", i), ("dis_change_donor_native", j)):
                                r[nm] = float((dec != st[dv]["native"][1]["test"].argmax(-1)).double().mean()) \
                                    if dv else None
                            staged["transfer"].append(r)
                            res[(h, i, j)] = r
                            prs.append(pr)
                            order.append(f"{i or 'none'}|{j or 'none'}")
                    save(f"{s['rid']}__transfer", prs, {"run_id": s["rid"], "host": h, "order": order})
                for h in V:
                    hd = h if h in ddon else None
                    for d in ddon:
                        if d == h:
                            continue
                        m = res[(h, d, d)]
                        cons = [("foreign_additions_on_host_changes_minus_matched", res[(h, d, hd)],
                                 "positive = the matched foreign package is better",
                                 "foreign_additions_only_minus_matched" if hd is None else ""),
                                ("host_additions_on_foreign_changes_minus_matched", res[(h, h, d)],
                                 "positive = the matched foreign package is better", ""),
                                ("foreign_additions_only_minus_matched", res[(h, d, None)],
                                 "positive = the matched foreign package is better", ""),
                                ("foreign_changes_only_minus_matched", res[(h, None, d)],
                                 "positive = the matched foreign package is better", ""),
                                ("host_extraction_minus_matched", res[(h, None, None)],
                                 "positive = the matched foreign package is better than the host's extraction", ""),
                                ("host_native_minus_matched", res[(h, h, hd)],
                                 "positive = the matched foreign package is better than the host's own expanded "
                                 "network", ""),
                                ("f0_minus_matched", None,
                                 "positive = the matched foreign package is better than f0", ""),
                                ("matched_minus_donor_native", None,
                                 "positive = the package works worse on the host's first layer than on its own",
                                 "")]
                        for nm, other, sign, dup in cons:
                            for q in ("test_err", "val_err", "val_indep_err", "test_ce"):
                                if m.get(q) is None:
                                    continue
                                if nm == "f0_minus_matched":
                                    val = f0e[q] - m[q]
                                elif nm == "matched_minus_donor_native":
                                    val = m[q] - res[(d, d, d)][q]
                                else:
                                    val = other[q] - m[q]
                                staged["transfer_contrasts"].append({
                                    **st[h]["meta"], "transfer_kind": TRANSFER_KIND, "host": h, "donor": d,
                                    "contrast": nm, "quantity": q, "value": val, "sign": sign,
                                    "algebraic_duplicate_of": dup})
                staged["transfer_meta"].append({"group": gname, "n_variants": len(V), "n_change_donors": len(ddon)})
            # ---- fold: the additions' output replaced by a surrogate (zero, training mean, affine fit) in two
            # segments: 1 the residual u - surrogate scaled away inside the expanded graph (the backbone fixed),
            # 2 the surrogate folded into the reading layer and the later layers moved to f0's
            if a.fold:
                for v in V:
                    s = st[v]
                    hin, mid, PL = s["site"]
                    g = s["set_point"](set(s["leaves"]), {})
                    act_parts = ["train", *ps]

                    def acts(part, g=g, hin=hin, mid=mid):
                        hs, us = [], []
                        dt = next(g.parameters()).dtype
                        for i0 in range(0, len(part), batch):
                            X = {k: (t[i0:i0 + batch].to(dt) if t.is_floating_point() else t[i0:i0 + batch])
                                 for k, t in part.X.items()}
                            _, nv = g.forward(X, return_nodes=[hin, mid])
                            hs.append(nv[hin].double().cpu())
                            us.append((nv[mid].double() - nv[hin].double()).cpu())
                        return torch.cat(hs), torch.cat(us)
                    with torch.no_grad():
                        A_ = {p_: acts(parts[p_]) for p_ in act_parts}
                    Ht, Ut = A_["train"]
                    W = s["gb"][wkey[PL]]
                    if Ht.dim() != 2 or Ut.shape != Ht.shape or Ht.shape[1] != W.shape[1]:
                        raise Fail(f"{v}: fold needs vector activations at the merge of the reading layer's input "
                                   f"width ({tuple(Ht.shape)}, {tuple(Ut.shape)}, {tuple(W.shape)})")
                    ubar = Ut.mean(0)
                    M, c, design = affine_fit(Ht, Ut)
                    surr = {"zero": (None, torch.zeros_like(ubar)), "mean": (None, ubar), "affine": (M, c)}
                    tgt = PL
                    if a.inject_fold_fault == "layer":          # self-test: fold into another layer
                        i_ = later.index(PL)
                        tgt = later[i_ + 1] if i_ + 1 < len(later) - 1 else later[i_ - 1]
                    energy_t = float((Ut ** 2).sum())
                    common = {"fold_layer": names[PL], "fit_data": "train", "n_fit_examples": int(Ht.shape[0]),
                              "merge_width": int(Ht.shape[1]),
                              "u_rms_over_h_rms": (energy_t / float((Ht ** 2).sum())) ** 0.5,
                              "u_constant_energy_share": float((ubar ** 2).sum()) * Ut.shape[0] / energy_t
                              if energy_t > 0 else None,
                              "fit_cost": "one forward pass over the training set at gates 1, one least-squares "
                                          "solve (examples x (width + 1)); no gradient steps",
                              "inference_params": n_par([k for Lk in L for k in lkeys[Lk]], f0_sd)}
                    rows_f, prs, order, folded = {}, [], [], {}
                    for fd in FOLDS:
                        Mf, cf = surr[fd]
                        Md, cd = (None if Mf is None else Mf.to(dev)), cf.to(dev)
                        if fd == "zero":
                            Wf, bf = s["gb"][wkey[tgt]], s["gb"][bkey[tgt]]
                        else:
                            Wf, bf = fold_into(s["gb"][wkey[tgt]], s["gb"][bkey[tgt]], Mf, cf, a.inject_fold_fault)
                        folded[fd] = (Wf, bf)
                        # the surrogate inside the expanded graph with the additions deleted (the merge is h)
                        gs = s["set_point"](set(), {})
                        gs.value_patch = {mid: (lambda val, Md=Md, cd=cd: surrogate_value(val, Md, cd))}
                        try:
                            _, p_s = measure(gs)
                        finally:
                            gs.value_patch = None
                        if fd == "zero" and not same_everywhere(p_s, s["deletion"][1]):
                            raise Fail(f"{v}: the zero surrogate inside the graph differs from the compact deletion")
                        # segment 1: u replaced by surrogate + lambda (u - surrogate), gates 1, the backbone fixed
                        for lam in LAMBDAS:
                            box = {}

                            def rec(val, box=box):
                                box["h"] = val
                                return val

                            def mix(val, box=box, lam=lam, Md=Md, cd=cd):
                                h = box.pop("h")
                                if lam == 1.0:
                                    return val
                                if lam == 0.0:
                                    return surrogate_value(h, Md, cd)
                                hd = h.double()
                                sd = (hd @ Md.T + cd) if Md is not None else cd
                                return (hd + sd + lam * (val.double() - hd - sd)).to(val.dtype)
                            g1 = s["set_point"](set(s["leaves"]), {})
                            g1.value_patch = {hin: rec, mid: mix}
                            try:
                                e, pr = measure(g1)
                            finally:
                                g1.value_patch = None
                            if lam == 1.0 and not same_everywhere(pr, s["native"][1]):
                                raise Fail(f"{v}: the residual path at lambda 1 differs from the native network")
                            if lam == 0.0 and not same_everywhere(pr, p_s):
                                raise Fail(f"{v}: the residual path at lambda 0 differs from the {fd} surrogate "
                                           f"applied with the additions deleted")
                            r = row(s, e, pr, {"fold": fd, "segment": SEGMENTS[0], "lam": lam, "rewind_t": 0.0,
                                               "implementation": "expanded graph, the additions' output replaced "
                                                                 "by surrogate + lambda (output - surrogate)"})
                            staged["fold"].append(r)
                            rows_f[(fd, SEGMENTS[0], lam)] = r
                            prs.append(pr)
                            order.append(f"{fd}|{SEGMENTS[0]}|{lam:g}")
                        # segment 2: the surrogate folded into the reading layer, then L2..LK moved to f0's
                        Fsd = {k: s["gb"][k] for Lk in later for k in lkeys[Lk]}
                        Fsd[wkey[tgt]], Fsd[bkey[tgt]] = Wf, bf
                        for t in FOLD_PATH:
                            tens = {k: s["gb"][k] for k in lkeys[L[0]]}
                            for k, vF in Fsd.items():
                                z = f0_sd[k].to(vF.device, vF.dtype)
                                tens[k] = vF if t == 0.0 else z if t == 1.0 else ((1 - t) * vF.double()
                                                                                   + t * z.double()).to(vF.dtype)
                            e, pr = measure(compact(tens))
                            if t == 0.0:
                                if fd == "zero":
                                    if not same_everywhere(pr, s["deletion"][1]):
                                        raise Fail(f"{v}: the zero fold differs from the compact deletion")
                                    chk = {"impl_max_rel_diff": 0.0, "impl_decisions_differ_total": 0,
                                           "impl_tolerance": 0.0, "impl_check_applies_to": "bitwise the deletion"}
                                else:
                                    chk = implementation_check(pr, p_s, f"{v} {fd} fold")
                                nat = s["native"][1]
                                agree = {}
                                for p_ in ps:
                                    za, zb = pr[p_].double(), nat[p_].double()
                                    agree[f"dis_native_{p_}"] = float((za.argmax(-1) != zb.argmax(-1)).double().mean())
                                    agree[f"logit_rms_native_{p_}"] = rms(za, zb)
                                    agree[f"prob_tv_native_{p_}"] = float(
                                        0.5 * (za.softmax(-1) - zb.softmax(-1)).abs().sum(-1).mean())
                                    agree[f"err_minus_native_{p_}"] = e[f"{p_}_err"] - s["native"][0][f"{p_}_err"]
                                res = {}
                                for p_ in act_parts:
                                    Hp, Up = A_[p_]
                                    Fp = (Hp @ Mf.T + cf) if Mf is not None else cf.expand(Hp.shape[0], -1)
                                    res[f"resid_share_raw_{p_}"] = residual_share(Up, Fp)
                                    res[f"resid_share_through_layer_{p_}"] = residual_share(Up, Fp, W)
                                    res[f"affine_r2_{p_}"] = r2(Up, Fp) if fd == "affine" else None
                                staged["fold_fit"].append({
                                    **s["meta"], "fold": fd, **common,
                                    "surrogate": {"zero": "0", "mean": "the training mean of the additions' output",
                                                  "affine": "least-squares M h + c on training activations"}[fd],
                                    "M_fro": float(Mf.norm()) if Mf is not None else 0.0,
                                    "M_spectral": float(torch.linalg.matrix_norm(Mf, 2)) if Mf is not None else 0.0,
                                    "c_norm": float(cf.norm()),
                                    **({k_: design[k_] for k_ in design} if fd == "affine" else
                                       {k_: None for k_ in design}),
                                    **res, **chk, **agree})
                            if t == 1.0 and not same_everywhere(pr, s["extraction"][1]):
                                raise Fail(f"{v}: the fold path's end differs from the extraction")
                            r = row(s, e, pr, {"fold": fd, "segment": SEGMENTS[1], "lam": 0.0, "rewind_t": t,
                                               "implementation": "compact network: the surrogate folded into "
                                                                 f"{names[PL]}, later layers at (1 - t) folded + t f0"})
                            staged["fold"].append(r)
                            rows_f[(fd, SEGMENTS[1], t)] = r
                            prs.append(pr)
                            order.append(f"{fd}|{SEGMENTS[1]}|{t:g}")
                    for fd in FOLDS:
                        pr_ = {**s["meta"], "fold": fd, "n_points_segment_1": len(LAMBDAS),
                               "n_points_segment_2": len(FOLD_PATH),
                               "note": "sampled points only; a finer grid can show a higher barrier"}
                        for q in ("test_err", "test_ce"):
                            v1 = [rows_f[(fd, SEGMENTS[0], lam)][q] for lam in LAMBDAS]
                            v2 = [rows_f[(fd, SEGMENTS[1], t)][q] for t in FOLD_PATH]
                            for tag, vv in (("seg1", v1), ("seg2", v2)):
                                pr_.update({f"{tag}_start_{q}": vv[0], f"{tag}_end_{q}": vv[-1],
                                            f"{tag}_max_{q}": max(vv),
                                            f"{tag}_barrier_{q}": max(vv) - max(vv[0], vv[-1])})
                            # the whole sampled route against its two ends: the native network and the extraction
                            pr_[f"combined_max_{q}"] = max(v1 + v2)
                            pr_[f"combined_barrier_{q}"] = max(v1 + v2) - max(v1[0], v2[-1])
                            pr_[f"surrogate_minus_native_{q}"] = v1[-1] - v1[0]
                        staged["fold_paths"].append(pr_)
                    save(f"{s['rid']}__fold", prs, {"run_id": s["rid"], "order": order})
                    if a.save_preds:                              # the fit itself, to rebuild the folded networks
                        import numpy as np
                        np.savez_compressed(
                            Path(a.save_preds) / f"{s['rid']}__fold_fit.npz",
                            M=M.numpy(), c=c.numpy(), u_mean=ubar.numpy(),
                            W_fold_mean=folded["mean"][0].cpu().numpy(), b_fold_mean=folded["mean"][1].cpu().numpy(),
                            W_fold_affine=folded["affine"][0].cpu().numpy(),
                            b_fold_affine=folded["affine"][1].cpu().numpy(),
                            meta=np.asarray(json.dumps({
                                "run_id": s["rid"], "experiment": ex, "group": gname, "fold_layer": names[PL],
                                "weight_key": wkey[PL], "bias_key": bkey[PL], "merge_node": mid, "skip_node": hin,
                                "state_param_hash": (s["ck"].get("lineage") or {}).get("param_hash"),
                                "f0_param_hash": s["f0_param_hash"], "fit_data": "train",
                                "lstsq_rcond": LSTSQ_RCOND, "dtype": "float64 fit; folded tensors in the model's",
                                "rebuild": "f0's architecture with the state's first layer and later layers, the "
                                           "fold layer replaced by (W_fold, b_fold); W_fold = W (I + M), "
                                           "b_fold = b + W c"}, default=str)))
            # ---- training diagnostics: where f0's remaining training loss sits and which examples' gradients
            # would scale its causal input block (f0 only: no branch masks are involved in a compact network)
            if a.train_diagnostics:
                lay = (b.meta or {}).get("feature_layout") or {}
                if "input_rotation" in lay or "shortcut" not in lay or "causal" not in lay:
                    raise Fail(f"group {gname}: training diagnostics need the generator's unrotated feature layout")
                c0, c1 = (int(x_) for x_ in lay["causal"])
                sc = int(lay["shortcut"])
                tr = parts["train"]
                w1 = [k for k in lkeys[L[0]] if f0_sd[k].dim() == 2]
                if set(tr.X) != {"x"} or tr.groups is None or len(w1) != 1 or \
                        f0_sd[w1[0]].shape[1] != tr.X["x"].shape[1]:
                    raise Fail(f"group {gname}: training diagnostics need one input tensor read by one first-layer "
                               f"weight matrix, and generator groups")
                w1 = w1[0]
                xt, yt, grp = tr.X["x"].to(dev), tr.y.to(dev).long(), tr.groups.to(dev)
                N = int(yt.shape[0])

                def train_logits(m_):
                    _, pr_ = AC.finite_eval(m_, b, ["train"], batch, "training diagnostics")
                    return pr_["train"]
                z0 = train_logits(f0)
                masks = subgroup_masks(xt[:, sc], yt, grp, z0.argmax(-1) == yt)
                f0meta = {**st[V[0]]["meta"], "run_id": f"f0:{st[V[0]]['f0_param_hash']}", "trajectory": "",
                          "variant": "f0", "state": "f0", "updates_since_f0": 0, "leaves": ""}

                def group_rows(meta_, z):
                    zd = z.double()
                    nll = torch.nn.functional.cross_entropy(zd, yt, reduction="none")
                    zo = zd.clone().scatter_(1, yt[:, None], float("-inf"))
                    mg = zd.gather(1, yt[:, None])[:, 0] - zo.max(-1).values
                    tot = float(nll.sum())
                    o_ = []
                    for sg, mk in masks.items():
                        n_ = int(mk.sum())
                        o_.append({**meta_, "subgroup": sg, "partition": "train", "n": n_, "share": n_ / N,
                                   "err": float((mg[mk] < 0).double().mean()) if n_ else None,
                                   "mean_loss": float(nll[mk].mean()) if n_ else None,
                                   "loss_share": float(nll[mk].sum()) / tot if tot > 0 else None,
                                   "margin_q05": float(torch.quantile(mg[mk], 0.05)) if n_ else None,
                                   "margin_q50": float(torch.quantile(mg[mk], 0.5)) if n_ else None})
                    return o_
                staged["train_groups"].extend(group_rows(f0meta, z0))
                for v in V:
                    staged["train_groups"].extend(group_rows(st[v]["meta"], train_logits(
                        st[v]["set_point"](set(st[v]["leaves"]), {}))))
                # f0's full-batch training gradient, split by subgroup (each subgroup's summed loss / N, so
                # disjoint subgroups add up to 'all')
                fg = GraphNet.from_checkpoint(st[V[0]]["f0k"]["model"], dev).eval()
                pnames = [n_ for n_, p_ in fg.named_parameters() if p_.requires_grad]
                pars = [p_ for _, p_ in fg.named_parameters() if p_.requires_grad]
                if w1 not in pnames:
                    raise Fail(f"group {gname}: f0's first-layer weight is not a trainable parameter")
                dt = pars[0].dtype
                losses = torch.nn.functional.cross_entropy(fg.forward({"x": xt.to(dt)}).double(), yt,
                                                           reduction="none")
                W0 = f0_sd[w1].double()
                grads = {}
                for sg, mk in masks.items():
                    gs_ = torch.autograd.grad(losses[mk].sum() / N, pars, retain_graph=True, allow_unused=True)
                    grads[sg] = {n_: (g_.double() if g_ is not None else torch.zeros_like(p_).double())
                                 for n_, g_, p_ in zip(pnames, gs_, pars)}
                for parts_ in (("shortcut_sign_agrees", "shortcut_sign_disagrees"), ("majority", "rare"),
                               ("f0_correct", "f0_error")):
                    dsum = sum(grads[x_][w1] for x_ in parts_) - grads["all"][w1]
                    # the gradients are computed in the model's own precision: additivity up to its rounding
                    if float(dsum.abs().max()) > 1e-4 * float(grads["all"][w1].abs().max()) + 1e-9:
                        raise Fail(f"group {gname}: subgroup gradients {parts_} do not add up to the full gradient")
                dW = {v: st[v]["gb"][w1].double() - W0 for v in V}
                for sg in SUBGROUPS:
                    gW = grads[sg][w1]
                    r = {**f0meta, "subgroup": sg, "n": int(masks[sg].sum()), "share": int(masks[sg].sum()) / N,
                         "loss_contribution": float(losses.detach()[masks[sg]].sum()) / N,
                         "grad_all_params_norm": float(sum((g_ ** 2).sum() for g_ in grads[sg].values())) ** 0.5,
                         "grad_causal_norm": float(gW[:, c0:c1].norm()),
                         "grad_shortcut_norm": float(gW[:, sc].norm()),
                         # d loss / d log-gain: the first-order change of this subgroup's loss contribution when the
                         # block is scaled up (negative: scaling up lowers it)
                         "dloss_dloggain_causal": float((gW[:, c0:c1] * W0[:, c0:c1]).sum()),
                         "dloss_dloggain_shortcut": float((gW[:, sc] * W0[:, sc]).sum())}
                    for v in V:
                        dc_ = dW[v][:, c0:c1]
                        r[f"dloss_along_causal_change_{v}"] = float((gW[:, c0:c1] * dc_).sum() / dc_.norm()) \
                            if float(dc_.norm()) > 0 else None
                    staged["f0_gradients"].append(r)
                for v in V:
                    Wv = st[v]["gb"][w1].double()
                    dc_, c0_ = dW[v][:, c0:c1], W0[:, c0:c1]
                    along = float((dc_ * c0_).sum() / c0_.norm())
                    staged["first_layer_change"].append({
                        **st[v]["meta"],
                        "causal_norm_ratio": float(Wv[:, c0:c1].norm() / c0_.norm()),
                        "shortcut_norm_ratio": float(Wv[:, sc].norm() / W0[:, sc].norm()),
                        "causal_change_over_f0_norm": float(dc_.norm() / c0_.norm()),
                        "causal_change_cos_with_f0": float((dc_ * c0_).sum() / (dc_.norm() * c0_.norm()))
                        if float(dc_.norm()) > 0 else None,
                        "causal_change_energy_along_scaling": along ** 2 / float((dc_ ** 2).sum())
                        if float(dc_.norm()) > 0 else None,
                        "shortcut_change_over_f0_norm": float(dW[v][:, sc].norm() / W0[:, sc].norm())})
            # ============================== v52 ==============================
            if a.gain_scan or a.age_course or a.aligned_paths:
                wk_all, bk_all = [], []
                for Lk in L:
                    ws = [k for k in lkeys[Lk] if f0_sd[k].dim() == 2]
                    bs = [k for k in lkeys[Lk] if f0_sd[k].dim() == 1]
                    if len(ws) != 1 or len(bs) != 1 or len(lkeys[Lk]) != 2:
                        raise Fail(f"group {gname}: layer {names[Lk]} is not one weight matrix with a bias")
                    wk_all.append(ws[0])
                    bk_all.append(bs[0])
                tr = parts["train"]
                if set(tr.X) != {"x"}:
                    raise Fail(f"group {gname}: these parts need a single input tensor")
                xtr, ytr = tr.X["x"].to(dev), tr.y.to(dev).long()
                Ntr = int(ytr.shape[0])
                lay = (b.meta or {}).get("feature_layout") or {}
                has_layout = "input_rotation" not in lay and "shortcut" in lay and "causal" in lay and \
                    f0_sd[wk_all[0]].shape[1] == xtr.shape[1]
                if has_layout:
                    cz0, cz1 = (int(x_) for x_ in lay["causal"])
                    scol = int(lay["shortcut"])
                f0meta2 = {**st[V[0]]["meta"], "run_id": f"f0:{st[V[0]]['f0_param_hash']}", "trajectory": "",
                           "variant": "f0", "state": "f0", "updates_since_f0": 0, "leaves": ""}

                def train_eval(m_):
                    """-> (per-example training loss (float64), correct-class margins, logits)."""
                    _, pr_ = AC.finite_eval(m_, b, ["train"], batch, "training set")
                    zd = pr_["train"].double()
                    nll = torch.nn.functional.cross_entropy(zd, ytr, reduction="none")
                    zo = zd.clone().scatter_(1, ytr[:, None], float("-inf"))
                    return nll, zd.gather(1, ytr[:, None])[:, 0] - zo.max(-1).values, zd

                def merge_acts(g_, hin_, mid_, part):
                    """(the value the additions read, their summed output) at the merge, float64 on the CPU."""
                    hs, us = [], []
                    dt_ = next(g_.parameters()).dtype
                    with torch.no_grad():
                        for i0 in range(0, len(part), batch):
                            X = {k: (t[i0:i0 + batch].to(dt_) if t.is_floating_point() else t[i0:i0 + batch])
                                 for k, t in part.X.items()}
                            _, nv = g_.forward(X, return_nodes=[hin_, mid_])
                            hs.append(nv[hin_].double().cpu())
                            us.append((nv[mid_].double() - nv[hin_].double()).cpu())
                    return torch.cat(hs), torch.cat(us)

                def chain_check(tens, pr_, what):
                    """the compact network is the plain ReLU chain the alignment and the manual forward assume."""
                    _, zt = mlp_forward({k: t.to(dev) for k, t in tens.items()},
                                        parts["test"].X["x"].to(dev), wk_all, bk_all)
                    ref = pr_["test"].double()
                    if float((zt - ref).abs().max()) > 1e-4 * max(1.0, float(ref.abs().max())):
                        raise Fail(f"{what}: the compact network is not a plain ReLU chain of its layers")
                chain_check(f0_sd, f0p, f"group {gname} f0")
            # ---- f0's training loss along a gain on an input block: a declared scan, and the autograd gain
            # derivative checked against a central finite difference
            if a.gain_scan:
                if not has_layout or tr.groups is None:
                    raise Fail(f"group {gname}: the gain scan needs the generator's unrotated feature layout")
                cols = {"causal": slice(cz0, cz1), "shortcut": slice(scol, scol + 1)}
                w1 = wk_all[0]
                nll0, _, z0 = train_eval(f0)
                masks = subgroup_masks(xtr[:, scol], ytr, tr.groups.to(dev), z0.argmax(-1) == ytr)

                def scaled(block, gain):
                    W = f0_sd[w1].clone()
                    W[:, cols[block]] = (W[:, cols[block]].double() * gain).to(W.dtype)
                    return compact({w1: W})
                fg = GraphNet.from_checkpoint(st[V[0]]["f0k"]["model"], dev).eval()
                W1p = dict(fg.named_parameters())[w1]
                lg = torch.nn.functional.cross_entropy(fg.forward({"x": xtr.to(W1p.dtype)}).double(), ytr,
                                                       reduction="none")
                W0d = f0_sd[w1].double()
                ag = {}
                for sg, mk in masks.items():
                    (gw,) = torch.autograd.grad(lg[mk].sum() / Ntr, [W1p], retain_graph=True)
                    ag[sg] = {bl: float((gw.double()[:, cols[bl]] * W0d[:, cols[bl]]).sum()) for bl in GAIN_BLOCKS}
                import math as _m
                prs, order = [], []
                for bl in GAIN_BLOCKS:
                    fd, scan = {}, []
                    for gain, purpose in [(g_, "scan") for g_ in GAINS] + \
                            [(_m.exp(-FD_EPS), "finite difference"), (_m.exp(FD_EPS), "finite difference")]:
                        m_ = scaled(bl, gain)
                        e, pr = measure(m_)
                        if gain == 1.0 and not same_everywhere(pr, f0p):
                            raise Fail(f"group {gname}: gain 1 does not reproduce f0")
                        nll, mg, _ = train_eval(m_)
                        con = {sg: float(nll[mk].sum()) / Ntr for sg, mk in masks.items()}
                        r = {**f0meta2, "block": bl, "gain": gain, "log_gain": _m.log(gain), "purpose": purpose,
                             "train_loss": float(nll.mean()), "train_err": float((mg < 0).double().mean()),
                             **{k: e.get(k) for k in BASE_METRICS},
                             **{f"loss_contrib_{sg}": con[sg] for sg in SUBGROUPS}}
                        staged["f0_gain_scan"].append(r)
                        if purpose == "scan":
                            scan.append(r)
                            prs.append(pr)
                            order.append(f"{bl}|{gain:g}")
                        else:
                            fd[gain < 1.0] = con
                    for sg in SUBGROUPS:
                        f_ = (fd[False][sg] - fd[True][sg]) / (2 * FD_EPS)
                        a_ = ag[sg][bl]
                        ok = abs(f_ - a_) <= max(FD_TOL[0] * abs(a_), FD_TOL[1])
                        staged["f0_gain_fd"].append({
                            **f0meta2, "block": bl, "subgroup": sg, "autograd_dloss_dloggain": a_,
                            "finite_difference_dloss_dloggain": f_, "abs_diff": abs(f_ - a_),
                            "rel_diff": abs(f_ - a_) / abs(a_) if a_ != 0 else None, "eps_log_gain": FD_EPS,
                            "agrees": ok, "tolerance": f"{FD_TOL[0]:g} relative or {FD_TOL[1]:g} absolute"})
                        if sg == "all" and not ok:               # reported, not fatal: a diagnostic's diagnostic
                            cov.setdefault("gain_derivative_disagreements", []).append(
                                {"group": gname, "block": bl, "autograd": a_, "finite_difference": f_})
                    at1 = next(r_ for r_ in scan if r_["gain"] == 1.0)
                    best = {q: min(scan, key=lambda r_: (r_[q], abs(r_["log_gain"]))) for q in
                            ("train_loss", "val_err", "val_indep_err", "test_err") if at1.get(q) is not None}
                    staged["f0_gain_optimum"].append({
                        **f0meta2, "block": bl, "grid": " ".join(f"{g_:g}" for g_ in GAINS),
                        "note": "descriptive: the grid point with the lowest value of each quantity; nothing is "
                                "selected for use",
                        **{f"gain_at_min_{q}": r_["gain"] for q, r_ in best.items()},
                        **{f"min_{q}": r_[q] for q, r_ in best.items()},
                        **{f"at_gain_1_{q}": at1[q] for q in best},
                        "test_err_at_min_train_loss": best["train_loss"]["test_err"],
                        "val_err_at_min_train_loss": best["train_loss"]["val_err"]})
                save(f"f0_{st[V[0]]['f0_param_hash']}__gain_scan", prs, {"run_id": f0meta2["run_id"],
                                                                         "order": order})
            # ---- the expansion's time course: every saved trajectory state with additions
            if a.age_course:
                two_class = f0p["test"].shape[1] == 2
                for v in V:
                    s = st[v]
                    td = runs / s["tid"]
                    prs, order = [], []
                    for stage, upd in trajectory_checkpoints(td, s["tcfg"]):
                        what = f"{v} {stage}"
                        ck = SR.ckp(td, stage)
                        if ck is None:
                            raise Fail(f"{what}: the trajectory checkpoint is missing")
                        AC.check_ckpt(ck, what, run_id=s["tid"], stage=stage, cfg=s["tcfg"], hashes=hashes,
                                      need=need)
                        check_age(AC.job_update(ck, s["f0k"], what), upd, what)
                        raw = GraphNet.from_checkpoint(ck["model"], dev).eval()
                        if raw.gate_vals:
                            raise Fail(f"{what}: the state has gates")
                        gb_ = {k: t.clone() for k, t in raw.state_dict().items()}
                        for Lk in L:
                            if any(k not in gb_ or gb_[k].shape != f0_sd[k].shape for k in lkeys[Lk]):
                                raise Fail(f"{what}: backbone tensors of {names[Lk]} differ in shape from f0's")
                        lv = sorted([t for t, im in raw.implants.items() if im.nodes and not any(
                            o.parent == t and o.nodes for o in raw.implants.values())], key=lambda s_: int(s_[1:]))
                        if not lv:
                            raise Fail(f"{what}: the state has no additions")
                        hin, mid, PL = fold_site(raw, lv, L)
                        e_n, p_n = measure(raw)
                        nll, mg, _ = train_eval(raw)
                        bbone = {k: gb_[k] for Lk in L for k in lkeys[Lk]}
                        e_d, p_d = measure(compact(bbone))
                        e_x, p_x = measure(compact({k: gb_[k] for k in lkeys[L[0]]}
                                                   | edit_tensors(f0_sd, lkeys, later)))
                        nat_dec = p_n["test"].argmax(-1)
                        dis = lambda pr_: float((pr_["test"].argmax(-1) != nat_dec).double().mean())  # noqa: E731
                        r = {**s["meta"], "state": "trajectory checkpoint", "checkpoint": stage,
                             "updates_since_f0": upd, "leaves": " ".join(lv), "n_leaves": len(lv),
                             "native_test_err": e_n["test_err"], "native_val_err": e_n["val_err"],
                             "native_val_indep_err": e_n.get("val_indep_err"), "native_shift_err": e_n.get("shift_err"),
                             "native_test_ce": e_n["test_ce"],
                             "train_loss": float(nll.mean()), "train_err": float((mg < 0).double().mean()),
                             "train_margin_q50": float(torch.quantile(mg, 0.5)),
                             "deletion_test_err": e_d["test_err"], "deletion_val_err": e_d["val_err"],
                             "extraction_test_err": e_x["test_err"], "extraction_val_err": e_x["val_err"],
                             "extraction_gain_vs_f0": f0e["test_err"] - e_x["test_err"],
                             "extraction_minus_native": e_x["test_err"] - e_n["test_err"]}
                        if has_layout:
                            W1_, W10 = gb_[wk_all[0]].double(), f0_sd[wk_all[0]].double()
                            r["causal_norm_ratio"] = float(W1_[:, cz0:cz1].norm() / W10[:, cz0:cz1].norm())
                            r["shortcut_norm_ratio"] = float(W1_[:, scol].norm() / W10[:, scol].norm())
                        for Lk in later:
                            sp = change_spectrum(gb_[wkey[Lk]], f0_sd[wkey[Lk]].to(gb_[wkey[Lk]].device))
                            r[f"change_over_f0_{names[Lk]}"] = sp["change_fro"] / sp["f0_fro"] if sp["f0_fro"] else None
                            r[f"change_top1_energy_{names[Lk]}"] = sp["energy_top1"]
                        these, tags = [p_n, p_d, p_x], ["native", "deletion", "extraction"]
                        Ht, Ut = merge_acts(raw, hin, mid, tr)
                        energy = float((Ut ** 2).sum())
                        r["fold_layer"] = names[PL]
                        r["u_rms_over_h_rms"] = (energy / float((Ht ** 2).sum())) ** 0.5
                        if energy > 0.0:
                            ubar, hbar = Ut.mean(0), Ht.mean(0)
                            M, c, design = affine_fit(Ht, Ut)
                            Uv, Sv, Vh = torch.linalg.svd(M, full_matrices=False)
                            tot = float((Sv ** 2).sum())
                            r.update({"u_constant_energy_share": float((ubar ** 2).sum()) * Ut.shape[0] / energy,
                                      "affine_r2_train": r2(Ut, Ht @ M.T + c), "M_spectral": float(Sv[0]),
                                      "M_fro": tot ** 0.5,
                                      "M_top1_energy": float(Sv[0] ** 2) / tot if tot > 0 else None,
                                      "M_top2_energy": float((Sv[:2] ** 2).sum()) / tot if tot > 0 else None,
                                      "design_cond": design["design_cond"]})
                            held = {p_: merge_acts(raw, hin, mid, parts[p_]) for p_ in ("val_indep", "test", "val",
                                                                                       "shift") if p_ in ps}
                            for p_, (Hp, Up) in held.items():
                                r[f"affine_r2_{p_}"] = r2(Up, Hp @ M.T + c)
                                r[f"nonlinear_energy_share_{p_}"] = residual_share(Up, Hp @ M.T + c)
                            W_, b_ = gb_[wkey[PL]], gb_[bkey[PL]]

                            def folded(M_, c_, W_=W_, b_=b_, bbone=bbone, PL=PL):
                                Wf, bf = fold_into(W_, b_, M_, c_)
                                return measure(compact({**bbone, wkey[PL]: Wf, bkey[PL]: bf}))
                            e_f, p_f = folded(M, c)
                            box = {}

                            def rec(val, box=box):
                                box["h"] = val
                                return val
                            Md, cd = M.to(dev), c.to(dev)
                            raw.value_patch = {hin: rec, mid: (lambda val, box=box, Md=Md, cd=cd:
                                                               surrogate_value(box.pop("h"), Md, cd))}
                            try:
                                _, p_s = measure(raw)
                            finally:
                                raw.value_patch = None
                            chk = implementation_check(p_f, p_s, f"{what} affine fold")
                            r.update({"fold_test_err": e_f["test_err"], "fold_val_err": e_f["val_err"],
                                      "fold_val_indep_err": e_f.get("val_indep_err"),
                                      "fold_minus_native_test_err": e_f["test_err"] - e_n["test_err"],
                                      "fold_dis_native_test": dis(p_f),
                                      "fold_impl_max_rel_diff": chk["impl_max_rel_diff"]})
                            these.append(p_f)
                            tags.append("fold_affine")
                            for rk in FOLD_RANKS:
                                e_r, p_r = folded(*rank_r_map(M, rk, hbar, ubar))
                                r[f"fold_rank{rk}_test_err"] = e_r["test_err"]
                                r[f"fold_rank{rk}_minus_native_test_err"] = e_r["test_err"] - e_n["test_err"]
                                r[f"fold_rank{rk}_dis_native_test"] = dis(p_r)
                                these.append(p_r)
                                tags.append(f"fold_rank{rk}")
                            if two_class:
                                # the top direction the map reads: one scalar per example, s = v1 . h
                                v1 = Vh[0]
                                s_tr, y_tr = Ht @ v1, ytr.cpu()
                                cl = corr(s_tr, y_tr.double())
                                sign = -1.0 if (cl is not None and cl < 0) else 1.0
                                thr = 0.5 * float(s_tr[y_tr == 0].mean() + s_tr[y_tr == 1].mean())
                                r["channel_label_corr_train"] = None if cl is None else abs(cl)
                                for p_, (Hp, _) in held.items():
                                    sp_ = sign * (Hp @ v1 - thr)
                                    yp = parts[p_].y.cpu().long()
                                    r[f"channel_threshold_err_{p_}"] = float(((sp_ > 0).long() != yp).double().mean())
                                if "test" in held:
                                    st_ = sign * (held["test"][0] @ v1)
                                    mn = (p_n["test"][:, 1] - p_n["test"][:, 0]).double().cpu()
                                    m0 = (f0p["test"][:, 1] - f0p["test"][:, 0]).double().cpu()
                                    r["channel_corr_native_margin_test"] = corr(st_, mn)
                                    r["channel_corr_f0_margin_test"] = corr(st_, m0)
                                    if has_layout:
                                        r["channel_corr_shortcut_test"] = corr(st_, parts["test"].X["x"][:, scol])
                        else:
                            r["note"] = "the additions' output is exactly zero here (at insertion): nothing to fit"
                        staged["age_course"].append(r)
                        prs += these
                        order += [f"{stage}|{t_}" for t_ in tags]
                    save(f"{s['rid']}__age_course", prs, {"run_id": s["rid"], "order": order})
            # ---- the folded network's path to the extraction after function-preserving alignment of its hidden
            # units (permutation and / or positive rescaling), both ends unchanged as functions
            if a.aligned_paths:
                for v in V:
                    s = st[v]
                    hin, mid, PL = s["site"]
                    g = s["set_point"](set(s["leaves"]), {})
                    Ht, Ut = merge_acts(g, hin, mid, tr)
                    if float((Ut ** 2).sum()) == 0.0:
                        raise Fail(f"{v}: the additions have no output at the expansion end")
                    M, c, _ = affine_fit(Ht, Ut)
                    Wf, bf = fold_into(s["gb"][wkey[PL]], s["gb"][bkey[PL]], M, c)
                    F = {k: s["gb"][k] for Lk in L for k in lkeys[Lk]}
                    F[wkey[PL]], F[bkey[PL]] = Wf, bf
                    X = {**{k: s["gb"][k] for k in lkeys[L[0]]}, **edit_tensors(f0_sd, lkeys, later)}
                    e_F, p_F = measure(compact(F))
                    chain_check(F, p_F, f"{v} folded network")
                    chain_check(X, s["extraction"][1], f"{v} extraction")
                    with torch.no_grad():
                        aF, _ = mlp_forward({k: t.to(dev) for k, t in F.items()}, xtr, wk_all, bk_all)
                        aX, _ = mlp_forward({k: t.to(dev) for k, t in X.items()}, xtr, wk_all, bk_all)
                    for j in range(K - 1):
                        if F[wk_all[j + 1]].shape[1] != F[wk_all[j]].shape[0]:
                            raise Fail(f"{v}: layer {names[L[j + 1]]} does not read layer {names[L[j]]}'s units")
                    prs, order = [], []
                    for mode in ALIGN_MODES:
                        T_ = dict(F)
                        info = {}
                        if mode != "none":
                            for j in range(1, K - 1):               # hidden layers after the first (shared) layer
                                od, al, inf = unit_alignment(aF[j], aX[j], "permute" in mode, "rescale" in mode)
                                T_[wk_all[j]], T_[bk_all[j]], T_[wk_all[j + 1]] = apply_alignment(
                                    T_[wk_all[j]], T_[bk_all[j]], T_[wk_all[j + 1]], od, al)
                                info.update({f"{k_}_{names[L[j]]}": v_ for k_, v_ in inf.items()})
                        pts = {}
                        for t in FOLD_PATH:
                            tens = {k: s["gb"][k] for k in lkeys[L[0]]}
                            for Lk in later:
                                for k in lkeys[Lk]:
                                    vT, z = T_[k], f0_sd[k].to(T_[k].device, T_[k].dtype)
                                    tens[k] = vT if t == 0.0 else z if t == 1.0 else (
                                        (1 - t) * vT.double() + t * z.double()).to(vT.dtype)
                            e, pr = measure(compact(tens))
                            if t == 0.0:
                                if mode == "none":
                                    if not same_everywhere(pr, p_F):
                                        raise Fail(f"{v}: the unaligned start differs from the folded network")
                                    chk = {"impl_max_rel_diff": 0.0, "impl_decisions_differ_total": 0}
                                else:
                                    chk = implementation_check(pr, p_F, f"{v} alignment {mode}")
                            if t == 1.0 and not same_everywhere(pr, s["extraction"][1]):
                                raise Fail(f"{v}: the aligned path's end differs from the extraction")
                            rr = row(s, e, pr, {"mode": mode, "rewind_t": t})
                            staged["aligned_points"].append(rr)
                            pts[t] = rr
                            prs.append(pr)
                            order.append(f"{mode}|{t:g}")
                        ar_ = {**s["meta"], "mode": mode, "n_points": len(FOLD_PATH), "alignment": ALIGN_NOTE,
                               "start_preserved_max_rel_diff": chk["impl_max_rel_diff"],
                               "start_decisions_differ": chk["impl_decisions_differ_total"], **info,
                               "note": "sampled points only; other alignments or paths are not excluded"}
                        for q in ("test_err", "test_ce"):
                            vv = [pts[t][q] for t in FOLD_PATH]
                            ar_.update({f"start_{q}": vv[0], f"end_{q}": vv[-1], f"max_{q}": max(vv),
                                        f"barrier_{q}": max(vv) - max(vv[0], vv[-1])})
                        staged["aligned_paths"].append(ar_)
                    save(f"{s['rid']}__aligned_paths", prs, {"run_id": s["rid"], "order": order})
            for k_, rows_ in staged.items():
                out[k_].extend(rows_)
            cov["analysed_groups"] += 1
            cov["analysed_runs"] += len(members)
        except Fail as ex_:
            cov["failed"].append({"group": gname, "reason": str(ex_)})
            print(f"FAIL group {gname}: {ex_}", file=sys.stderr)

    P = a.out
    tables = ["checks"] + (["minimal_edits", "minimal_sets"] if a.minimal_edits else []) + \
        (["rank_restores", "rank_layers"] if a.rank_restores else []) + \
        (["transfer", "transfer_contrasts"] if a.transfer else []) + \
        (["fold", "fold_fit", "fold_paths"] if a.fold else []) + \
        (["train_groups", "f0_gradients", "first_layer_change"] if a.train_diagnostics else []) + \
        (["f0_gain_scan", "f0_gain_fd", "f0_gain_optimum"] if a.gain_scan else []) + \
        (["age_course"] if a.age_course else []) + (["aligned_points", "aligned_paths"] if a.aligned_paths else [])
    for t in tables:
        SR.atomic_csv(f"{P}_{t}.csv", out.get(t, []))
    EK = ("experiment", "cell")

    def summarise(rows, keys, ms, name):
        long_ = [{**{k: r[k] for k in EK + keys + ("data_draw", "optimizer_seed")}, "metric": m, "v": float(r[m])}
                 for r in rows for m in ms if r.get(m) is not None]
        bd, sm = SR.two_stage(long_, EK + keys + ("metric",), "v")
        SR.atomic_csv(f"{P}_{name}_by_draw.csv", bd)
        SR.atomic_csv(f"{P}_{name}_summary.csv", sm)
    if a.minimal_edits:
        summarise(out["minimal_edits"], ("variant", "deleted", "restored", "n_deleted", "n_restored"), METRICS,
                  "minimal_edits")
        counts, bd, sm = selection_summary(out["minimal_sets"], expected_runs)
        SR.atomic_csv(f"{P}_minimal_sets_counts.csv", counts)
        SR.atomic_csv(f"{P}_minimal_sets_by_draw.csv", bd)
        SR.atomic_csv(f"{P}_minimal_sets_summary.csv", sm)
        freq = defaultdict(lambda: defaultdict(int))
        for r in out["minimal_sets"]:
            freq[tuple(r[k] for k in SEL_KEYS)][r["chosen"] or "not removable"] += 1
        SR.atomic_csv(f"{P}_minimal_sets_chosen.csv", [
            {**dict(zip(SEL_KEYS, k)), "chosen": c_, "runs": n_, "of_runs": sum(f_.values())}
            for k, f_ in sorted(freq.items(), key=lambda t: tuple(map(str, t[0])))
            for c_, n_ in sorted(f_.items(), key=lambda t: (-t[1], t[0]))])
    if a.rank_restores:
        extra = tuple(sorted({k for r in out["rank_restores"] for k in r
                              if k.startswith(("energy_restored_", "eff_rank_"))})) + \
            ("entries_changed", "correction_factor_storage", "correction_intrinsic_dim", "inference_params")
        summarise(out["rank_restores"], ("variant", "scheme", "v49_scheme", "target_layer", "rank", "note"),
                  METRICS + extra, "rank_restores")
        summarise(out["rank_layers"], ("variant", "layer", "is_head", "shape_out", "shape_in"),
                  ("change_fro", "f0_fro", "numerical_rank") + tuple(f"energy_top{k}" for k in SPECTRUM_KS),
                  "rank_layers")
    if a.transfer:
        summarise(out["transfer"], ("transfer_kind", "host", "addition_donor", "change_donor", "package",
                                    "host_keeps"),
                  METRICS + ("dis_addition_donor_native", "dis_change_donor_native", "share_of_host_from_donor"),
                  "transfer")
        long_ = [{**r, "v": r["value"]} for r in out["transfer_contrasts"]]
        bd, sm = SR.two_stage(long_, EK + ("transfer_kind", "host", "donor", "contrast", "quantity", "sign",
                                           "algebraic_duplicate_of"), "v")
        SR.atomic_csv(f"{P}_transfer_contrasts_by_draw.csv", bd)
        SR.atomic_csv(f"{P}_transfer_contrasts_summary.csv", sm)
    def numeric_cols(rows, skip):
        return tuple(sorted({k for r in rows for k, v_ in r.items() if k not in skip and
                             isinstance(v_, (int, float)) and not isinstance(v_, bool)}))
    META = ("experiment", "group", "run_id", "trajectory", "variant", "cell", "draw_set", "data_draw",
            "optimizer_seed", "state", "updates_since_f0", "leaves")
    if a.fold:
        summarise(out["fold"], ("variant", "fold", "segment", "lam", "rewind_t"), METRICS, "fold")
        summarise(out["fold_fit"], ("variant", "fold", "fold_layer", "fit_data"),
                  numeric_cols(out["fold_fit"], META + ("n_fit_examples", "merge_width", "inference_params",
                                                        "design_rows", "design_cols", "lstsq_rcond",
                                                        "impl_tolerance")), "fold_fit")
        summarise(out["fold_paths"], ("variant", "fold"),
                  numeric_cols(out["fold_paths"], META + ("n_points_segment_1", "n_points_segment_2")), "fold_paths")
    if a.train_diagnostics:
        summarise(out["train_groups"], ("variant", "subgroup", "partition"),
                  ("n", "share", "err", "mean_loss", "loss_share", "margin_q05", "margin_q50"), "train_groups")
        summarise(out["f0_gradients"], ("variant", "subgroup"),
                  numeric_cols(out["f0_gradients"], META + ("n",)), "f0_gradients")
        summarise(out["first_layer_change"], ("variant",), numeric_cols(out["first_layer_change"], META),
                  "first_layer_change")
    if a.gain_scan:
        summarise(out["f0_gain_scan"], ("variant", "block", "gain", "purpose"),
                  numeric_cols(out["f0_gain_scan"], META + ("gain",)), "f0_gain_scan")
        summarise(out["f0_gain_fd"], ("variant", "block", "subgroup"),
                  ("autograd_dloss_dloggain", "finite_difference_dloss_dloggain", "abs_diff", "rel_diff"),
                  "f0_gain_fd")
        summarise(out["f0_gain_optimum"], ("variant", "block"), numeric_cols(out["f0_gain_optimum"], META),
                  "f0_gain_optimum")
    if a.age_course:
        summarise(out["age_course"], ("variant", "checkpoint", "updates_since_f0"),
                  numeric_cols(out["age_course"], META), "age_course")
    if a.aligned_paths:
        summarise(out["aligned_points"], ("variant", "mode", "rewind_t"), METRICS, "aligned_points")
        summarise(out["aligned_paths"], ("variant", "mode"), numeric_cols(out["aligned_paths"], META + ("n_points",)),
                  "aligned_paths")
    # output membership: every analysed run has its own expected number of points
    miss = []
    cnt = defaultdict(lambda: defaultdict(int))
    for t in ("minimal_edits", "minimal_sets", "rank_restores", "fold", "fold_fit", "train_groups", "age_course",
              "aligned_points"):
        for r in out.get(t, []):
            cnt[t][r["run_id"]] += 1
    for r in out["checks"]:
        for t, key in (("minimal_edits", "expected_minimal_points"), ("minimal_sets", "expected_selection_rows"),
                       ("rank_restores", "expected_rank_points"), ("fold", "expected_fold_points"),
                       ("fold_fit", "expected_fold_fit_rows"), ("train_groups", "expected_train_group_rows"),
                       ("age_course", "expected_age_rows"), ("aligned_points", "expected_aligned_points")):
            if cnt[t][r["run_id"]] != r[key]:
                miss.append(f"{r['run_id']}: {cnt[t][r['run_id']]} {t} rows, expected {r[key]}")
    if a.train_diagnostics:
        n_g = len({r["group"] for r in out["checks"]})
        for t, want in (("f0_gradients", n_g * len(SUBGROUPS)), ("first_layer_change", len(out["checks"])),
                        ("train_groups", (n_g + len(out["checks"])) * len(SUBGROUPS))):
            if len(out[t]) != want:
                miss.append(f"{t}: {len(out[t])} rows, expected {want}")
    if a.gain_scan:
        n_g = len({r["group"] for r in out["checks"]})
        for t, want in (("f0_gain_scan", n_g * len(GAIN_BLOCKS) * (len(GAINS) + 2)),
                        ("f0_gain_fd", n_g * len(GAIN_BLOCKS) * len(SUBGROUPS)),
                        ("f0_gain_optimum", n_g * len(GAIN_BLOCKS))):
            if len(out[t]) != want:
                miss.append(f"{t}: {len(out[t])} rows, expected {want}")
    if a.transfer:
        per_g = defaultdict(int)
        for r in out["transfer"]:
            per_g[r["group"]] += 1
        for tm in out["transfer_meta"]:
            want = tm["n_variants"] * (1 + tm["n_variants"]) * (1 + tm["n_change_donors"])
            if per_g[tm["group"]] != want:
                miss.append(f"group {tm['group']}: {per_g[tm['group']]} transfer points, expected {want}")
    if a.gain_scan:
        cov.setdefault("gain_derivative_disagreements", [])
    cov["output_membership_failures"] = miss
    cov["n_failed"] = len(cov["failed"])
    cov["passed"] = cov["n_failed"] == 0 and cov["analysed_groups"] > 0 and not miss and \
        cov["analysed_groups"] == cov["expected_groups"]
    Path(f"{P}_coverage.json").write_text(json.dumps(cov, indent=1, default=str))
    print(json.dumps({k: cov[k] for k in ("expected_groups", "analysed_groups", "analysed_runs", "n_failed",
                                          "passed")}))
    if a.strict and not cov["passed"]:
        return 1
    return 0


def change_is_zero(w, w0) -> bool:
    return bool(torch.equal(w, w0.to(w.dtype)))


if __name__ == "__main__":
    sys.exit(main())
