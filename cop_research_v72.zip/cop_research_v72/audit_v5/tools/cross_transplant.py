"""v32: does a history's first layer help an INDEPENDENTLY trained recipient?  Read-only; trains nothing.

  python audit_v5/tools/cross_transplant.py RESULTS OUT_PREFIX [--manifest M --strict] [--data-root DIR]
         [--device cpu]

Donors: the states of the jobs analysed by selective_reversal.py (removals and their forks, rebuilt and held
states, the controls), each donor's first backbone layer.  Recipient: f0 of the SAME data draw, model and training
recipe trained at ANOTHER optimizer seed (different initialisation and minibatch order), at the same f0 stage the
donor's own f0 uses (the lowest other seed when there are several).  v34: with --manifest the recipients are the
manifest's baselines; a donor is excluded (and listed) only when the manifest promises no such baseline.  A
promised recipient whose folder, config, status, checkpoint lineage, parameter hash, data hashes or predictions
fail a check is a coverage failure, never an exclusion.  Every evaluated partition must have a recorded hash in
the donor's log, the donor states' and the recipient's checkpoints, equal to the regenerated one.  The
donor's first layer replaces the recipient's, and a fixed interface maps the donor's first hidden layer onto the
recipient's, folded into the recipient's second layer (W2' = W2 A^T, b2' = b2 + W2 c).  The rest of the recipient
is frozen and nothing is trained.  Interfaces, all fitted on the training inputs only (no labels):
  identity      a plain swap (no fitting)
  permutation   one-to-one unit matching maximising the correlation of the two hidden layers (Hungarian)
  affine        least squares H_donor A + c = H_recipient with a ridge of 1e-6 x mean diagonal (H x H + H values)
Controls through the same interfaces: the donor's own f0 first layer (independent transfer without the history),
and a random first layer (fixed seed, the default linear initialisation): what the interface alone recovers.
Every row has the errors on val, val_indep, test, cf_shortcut, cf_causal, shift, rare, the shortcut flip rate,
the interface's fitted parameter count and its training-input R^2.  Summaries per unique data draw as in
selective_reversal.py (levels).  Strict mode: manifest-driven expected donors; any failure exits 1."""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import torch  # noqa: E402

from cop.analysis.v13_tables import draw_role  # noqa: E402
from cop.data.registry import load_bundle  # noqa: E402
from cop.graph import edits as E  # noqa: E402
from cop.graph.export import export_compact  # noqa: E402
from cop.graph.graph import GraphNet  # noqa: E402
from cop.train.trainer import evaluate  # noqa: E402
import selective_reversal as SR  # noqa: E402

INTERFACES = ("identity", "permutation", "affine")


Fail = SR.Fail          # v34: one failure type for every analysis tool


def compact_graph(mdl, dev, label):
    g = GraphNet.from_checkpoint(mdl, dev).eval()
    tops = [t for t, imp in g.implants.items() if imp.nodes and imp.parent is None]
    if not tops:
        return g
    try:
        return E.delete(g, tops, share_params=False).eval()
    except Exception as ex:                              # noqa: BLE001
        if not g.gate_vals:
            raise Fail(f"{label}: branch deletion failed ({type(ex).__name__}: {ex})")
        for gd in list(g.gate_vals):
            g.gate_vals[gd] = 0.0
        h = export_compact(g)[0].eval()
        if any(imp.nodes for imp in h.implants.values() if imp.parent is None):
            raise Fail(f"{label}: gated export still holds additions")
        return h


def first_block(g: GraphNet, L: list[str]):
    """(first linear node, the elementwise activation it feeds, the second linear node reading that activation)."""
    n1 = next(n for n in g.topo_order(g.live_nodes()) if g.nodes[n].pkey == L[0])
    acts = [n for n in g.live_nodes() if n1 in g.nodes[n].inputs]
    if len(acts) != 1 or g.nodes[acts[0]].op != "act":
        raise Fail("the first layer does not feed exactly one activation")
    n2 = [n for n in g.live_nodes() if acts[0] in g.nodes[n].inputs]
    if len(n2) != 1 or g.nodes[n2[0]].pkey != L[1] or g.nodes[n2[0]].op != "linear":
        raise Fail("the first activation does not feed exactly the second linear layer")
    return n1, acts[0], n2[0]


@torch.no_grad()
def hidden(g: GraphNet, act_node: str, X: dict) -> torch.Tensor:
    _, v = g(X, return_nodes=[act_node])
    return v[act_node].double()


def fold_first_layer(r_sd: dict, L: list[str], Wd: torch.Tensor, bd: torch.Tensor, A: torch.Tensor,
                     c: torch.Tensor) -> dict:
    """v34: the recipient's state with the donor's first layer and the interface folded into its second layer
    (W2' = W2 A^T, b2' = b2 + W2 c); shared by the fitting path and the fresh reconstruction."""
    w0, w1 = f"mods.{L[0]}.weight", f"mods.{L[1]}.weight"
    sd = dict(r_sd)
    sd[w0] = Wd.to(r_sd[w0].device, r_sd[w0].dtype)
    sd[f"mods.{L[0]}.bias"] = bd.to(r_sd[f"mods.{L[0]}.bias"].device, r_sd[f"mods.{L[0]}.bias"].dtype)
    W2, b2 = r_sd[w1].double(), r_sd[f"mods.{L[1]}.bias"].double()
    A_, c_ = A.to(W2.device, torch.float64), c.to(W2.device, torch.float64)
    sd[w1] = (W2 @ A_.T).to(r_sd[w1].dtype)
    sd[f"mods.{L[1]}.bias"] = (b2 + W2 @ c_).to(r_sd[f"mods.{L[1]}.bias"].dtype)
    return sd


def fit_checked(kind: str, Hd: torch.Tensor, Hr: torch.Tensor, label: str):
    """v34: fit_interface with explicit failures: non-finite hidden layers or a non-finite map (status
    numerical_failure) raise Fail; -> (A, c, n_params, R^2)."""
    if not (bool(torch.isfinite(Hd).all()) and bool(torch.isfinite(Hr).all())):
        raise Fail(f"{label}: non-finite hidden activations (numerical_failure)")
    try:
        A, c, n_par, r2 = fit_interface(kind, Hd, Hr)
    except (RuntimeError, ValueError) as ex:
        raise Fail(f"{label}: interface {kind} fit failed ({type(ex).__name__}: {ex}) (numerical_failure)")
    if not (bool(torch.isfinite(A).all()) and bool(torch.isfinite(c).all())) or r2 != r2:
        raise Fail(f"{label}: interface {kind} gave a non-finite map (numerical_failure)")
    return A, c, n_par, r2


def fit_interface(kind: str, Hd: torch.Tensor, Hr: torch.Tensor):
    """-> (A, c, n_params, R^2) with Hr ~ Hd A + c."""
    H = Hd.shape[1]
    if kind == "identity":
        A, c = torch.eye(H, dtype=torch.float64, device=Hd.device), torch.zeros(H, dtype=torch.float64, device=Hd.device)
        n_par = 0
    elif kind == "permutation":
        from scipy.optimize import linear_sum_assignment
        zd = (Hd - Hd.mean(0)) / (Hd.std(0) + 1e-12)
        zr = (Hr - Hr.mean(0)) / (Hr.std(0) + 1e-12)
        C = (zd.T @ zr / len(Hd)).cpu().numpy()          # C[i, j] = corr(donor unit i, recipient unit j)
        ri, ci = linear_sum_assignment(-C)
        A = torch.zeros(H, H, dtype=torch.float64, device=Hd.device)
        A[torch.as_tensor(ri), torch.as_tensor(ci)] = 1.0   # recipient unit ci reads donor unit ri
        c = torch.zeros(H, dtype=torch.float64, device=Hd.device)
        n_par = 0
    else:
        X1 = torch.cat([Hd, torch.ones(len(Hd), 1, dtype=torch.float64, device=Hd.device)], 1)
        G = X1.T @ X1
        lam = 1e-6 * float(torch.diagonal(G).mean())
        sol = torch.linalg.solve(G + lam * torch.eye(G.shape[0], dtype=torch.float64, device=Hd.device), X1.T @ Hr)
        A, c = sol[:H], sol[H]
        n_par = H * H + H
    pred = Hd @ A + c
    r2 = 1.0 - float(((pred - Hr) ** 2).sum() / ((Hr - Hr.mean(0)) ** 2).sum().clamp_min(1e-30))
    return A, c, n_par, r2


def main() -> int:
    import audit_common as AC
    ap = argparse.ArgumentParser()
    ap.add_argument("results")
    ap.add_argument("out_prefix")
    ap.add_argument("--manifest", default=None)
    ap.add_argument("--strict", action="store_true")
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--device", default="cpu")
    a = ap.parse_args()
    if a.strict and not a.manifest:
        ap.error("--strict needs --manifest")
    dev = a.device
    runs = Path(a.results) / "runs"
    cov = {"tool_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()[:16], "manifest": a.manifest,
           "expected": 0, "analysed": 0, "failed": [], "excluded": []}
    if a.manifest:
        ents = AC.manifest_entries(a.manifest)
        mcfg = {e["run_id"]: e["cfg"] for e in ents}
    else:
        mcfg = {p.name: SR.rj(p / "config.json") for p in sorted(runs.glob("*")) if (p / "config.json").exists()}
    ids = [rid for rid, c in mcfg.items() if SR.eligible(c) is not None]
    # recipients: the promised baselines by (data, model, training recipe) and optimizer seed
    rkey = lambda c: json.dumps({"data": c["data"], "model": c["model"], "train": c["train"]}, sort_keys=True)
    recips = defaultdict(dict)
    for bid, c in mcfg.items():
        if c.get("kind") == "baseline":
            os_b = (c.get("seeds") or {}).get("optimizer")
            if os_b in recips[rkey(c)]:
                raise Fail(f"two baselines {recips[rkey(c)][os_b]} and {bid} share data, model, recipe and seed")
            recips[rkey(c)][os_b] = bid
    cov["expected"] = len(ids)
    rows, partial = [], []
    bundles = {}
    for rid in ids:
        d = runs / rid
        staged = []
        why_d = AC.declared_invalid(d, mcfg[rid] if a.manifest else None) if (d / "config.json").exists() else None
        if why_d:
            cov["excluded"].append({"run_id": rid, "reason": why_d})            # v36: listed, never silently dropped
            continue
        try:
            cfg = AC.job_config(runs, rid, mcfg[rid] if a.manifest else None)
            src, kind = SR.eligible(cfg)
            des = cfg.get("design") or {}
            os_ = (cfg.get("seeds") or {}).get("optimizer")
            # the donor's own f0: its baseline parent (a removal's through its trajectory) and stage
            if src == "removal":
                tid = cfg["parents"]["trajectory"]
                tcfg = mcfg.get(tid) or AC.job_config(runs, tid)
                bid0, f0_stage = tcfg["parents"]["baseline"], (tcfg.get("tags") or {}).get("f0_stage", "baseline")
            else:
                bid0, f0_stage = cfg["parents"]["baseline"], (cfg.get("continue") or {}).get("start_stage", "best_val")
            bcfg0 = mcfg.get(bid0) or AC.job_config(runs, bid0)
            others = sorted(((o, r) for o, r in recips.get(rkey(bcfg0), {}).items() if o != os_), key=lambda t: str(t[0]))
            if not others:
                cov["excluded"].append({"run_id": rid, "reason": "no independently trained recipient promised (another "
                                                                 "optimizer seed, same data, model and recipe)"})
                continue
            r_os, rid_r = others[0]
            rdir = runs / rid_r
            rcfg = AC.job_config(runs, rid_r, mcfg.get(rid_r) if a.manifest else None)
            ep = SR.rj(d / "endpoint.json") if (d / "endpoint.json").exists() else None
            if ep is None or ep.get("diverged") or ep.get("numerically_valid") is False:
                raise Fail("endpoint missing, diverged or recorded numerically invalid")
            rep = SR.rj(rdir / "endpoint.json") if (rdir / "endpoint.json").exists() else None
            if rep is None or rep.get("diverged") or rep.get("numerically_valid") is False:
                raise Fail(f"recipient {rid_r}: endpoint missing, diverged or recorded numerically invalid")
            dkey = json.dumps(cfg["data"], sort_keys=True)
            if dkey not in bundles:
                b0 = load_bundle(cfg["data"], a.data_root, device="cpu")
                bundles[dkey] = (b0.to(dev), b0.hashes())
            b, hashes = bundles[dkey]
            ps = AC.eval_partitions(b)
            need = {"train", *ps}
            AC.check_logged_data(d, hashes, need, rid)
            AC.check_logged_data(rdir, hashes, need, f"recipient {rid_r}")
            if src == "removal":
                td = runs / cfg["parents"]["trajectory"]
                f0k = SR.ckp(td, "baseline_ref")
                AC.check_ckpt(f0k, f"{tid}/baseline_ref", run_id=tid, stage="baseline_ref", hashes=hashes, need=need)
                states = {("kept_end" if kind.startswith("keep") else "repaired"): (SR.ckp(d, ep["checkpoint"]), rid,
                                                                                    ep["checkpoint"])}
                if kind == "full":
                    states["abrupt"] = (SR.ckp(td, "final"), tid, "final")
            else:
                f0k = SR.ckp(runs / bid0, f0_stage)
                AC.check_ckpt(f0k, f"{bid0}/{f0_stage}", run_id=bid0, stage=f0_stage, hashes=hashes, need=need)
                states = {f"{des['arm']}_final": (SR.ckp(d, ep["checkpoint"]), rid, ep["checkpoint"])}
            rk = SR.ckp(rdir, f0_stage)
            AC.check_ckpt(rk, f"recipient {rid_r}/{f0_stage}", run_id=rid_r, stage=f0_stage, cfg=rcfg, hashes=hashes,
                          need=need)
            batch = int((cfg.get("train") or {}).get("eval_batch", 4096))
            Xtr = b.train.X

            def measure(m, label):
                o, _ = AC.finite_eval(m, b, ps, batch, label)
                return o
            rec = GraphNet.from_checkpoint(rk["model"], dev).eval()
            L = SR.backbone_layers(rec)
            n1, act, n2 = first_block(rec, L)
            r_sd = {k: v.clone() for k, v in rec.state_dict().items()}
            Hr = hidden(rec, act, Xtr)
            rec_e = measure(rec, "recipient")
            meta = {"run_id": rid, "source": src, "variant": des.get("variant"), "arm": des.get("arm"),
                    "removal_variant": kind, "cell": (des.get("contrast") or "").split("|")[-1],
                    "data_draw": (cfg.get("data") or {}).get("data_seed"), "optimizer_seed": os_,
                    "partition_seed": (cfg.get("seeds") or {}).get("partition"), "draw_set": draw_role(cfg),
                    "recipient_run": rid_r, "recipient_optimizer_seed": r_os, "recipient_stage": f0_stage}
            donor_f0 = GraphNet.from_checkpoint(f0k["model"], dev).eval()
            gen = torch.Generator().manual_seed(12345)
            Wr0 = r_sd[f"mods.{L[0]}.weight"]
            bound = 1.0 / Wr0.shape[1] ** 0.5
            rand_w = (torch.rand(Wr0.shape, generator=gen, dtype=torch.float64) * 2 - 1) * bound
            rand_b = (torch.rand(Wr0.shape[0], generator=gen, dtype=torch.float64) * 2 - 1) * bound
            for sname, sm in list(states.items()) + [("donor_f0", None), ("random_layer", None)]:
                if sname == "donor_f0":
                    g = donor_f0
                elif sname == "random_layer":
                    g = None
                else:
                    ck_s, owner, stg = sm
                    AC.check_ckpt(ck_s, f"{owner}/{stg}", run_id=owner, stage=stg, hashes=hashes, need=need)
                    g = compact_graph(ck_s["model"], dev, sname)
                if g is not None:
                    if SR.backbone_layers(g) != L:
                        raise Fail(f"{sname}: backbone layers differ from the recipient's")
                    gs = g.state_dict()
                    Wd, bd_ = gs[f"mods.{L[0]}.weight"].double(), gs[f"mods.{L[0]}.bias"].double()
                else:
                    Wd, bd_ = rand_w.to(dev), rand_b.to(dev)
                # the donor's first hidden layer on the recipient's graph (same activation): put the donor layer in
                probe = GraphNet.from_checkpoint(rk["model"], dev).eval()
                H = Wr0.shape[0]
                probe.load_state_dict(fold_first_layer(r_sd, L, Wd, bd_, torch.eye(H, dtype=torch.float64),
                                                       torch.zeros(H, dtype=torch.float64)))
                probe._plan = None
                Hd = hidden(probe, act, Xtr)
                for itf in INTERFACES:
                    A, c, n_par, r2 = fit_checked(itf, Hd, Hr, f"{sname}/{itf}")
                    probe.load_state_dict(fold_first_layer(r_sd, L, Wd, bd_, A, c))
                    probe._plan = None
                    e = measure(probe, f"{sname}/{itf}")
                    staged.append({**meta, "donor": sname, "interface": itf, "interface_params": n_par,
                                   "interface_train_r2": r2, **e, **{f"recipient_{k}": v for k, v in rec_e.items()},
                                   "f0_test_err": rec_e["test_err"]})
            rows += staged
            cov["analysed"] += 1
        except Exception as ex:                          # noqa: BLE001
            why = str(ex) if isinstance(ex, Fail) else f"{type(ex).__name__}: {ex}"
            cov["failed"].append({"run_id": rid, "reason": why})
            partial += [{**r, "failure": why} for r in staged]
    P = a.out_prefix
    SR.atomic_csv(f"{P}_rows.csv", rows)
    SR.atomic_csv(f"{P}_diagnostic_partial.csv", partial)
    # draw-level summaries per (donor state, interface); 'f0_test_err' is the RECIPIENT's own error
    for r in rows:
        r["state"], r["code"] = r["donor"], r["interface"]
    _, by_draw, summ = SR.levels(rows, "code")
    SR.atomic_csv(f"{P}_by_draw.csv", by_draw)
    SR.atomic_csv(f"{P}_summary.csv", summ)
    cov["n_failed"], cov["n_excluded"] = len(cov["failed"]), len(cov["excluded"])
    cov["passed"] = cov["n_failed"] == 0 and cov["analysed"] > 0 and \
        cov["analysed"] + cov["n_excluded"] == cov["expected"]
    SR.atomic_json(f"{P}_coverage.json", cov)
    print(json.dumps({k: cov[k] for k in ("expected", "analysed", "n_failed", "n_excluded", "passed")}),
          "first failures:", cov["failed"][:3])
    if a.strict:
        return 0 if cov["passed"] else 1
    return 0 if cov["analysed"] > 0 else 1


if __name__ == "__main__":
    sys.exit(main())
