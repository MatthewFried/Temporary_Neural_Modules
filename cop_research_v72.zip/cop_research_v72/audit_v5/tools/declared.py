"""v36: the DECLARED outcomes of a job's design that end it as invalid without being a failure (json only, so the
launcher can check them without torch).  Only the matched-perturbation controls have such outcomes
(cop/experiments/continuation._perturb_matched): their perturb_match.json records the failure, and its text must
be one of DECLARED_PERTURB_OUTCOMES.  Any other invalid job is a failure."""
from __future__ import annotations

import json
from pathlib import Path

DECLARED_PERTURB_OUTCOMES = ("the target is not above the unperturbed value",
                             "the target is not reached by scale 64",
                             "the achieved value is not within tolerance of the target")


def _rj(p: Path) -> dict:
    return json.load(open(p))


def declared_invalid(run_dir, cfg: dict | None = None):
    """the reason when the job ended invalid with a declared outcome of its design, else None."""
    d = Path(run_dir)
    st = _rj(d / "status.json") if (d / "status.json").exists() else {}
    if st.get("status") != "invalid":
        return None
    cfg = cfg or (_rj(d / "config.json") if (d / "config.json").exists() else {})
    if cfg.get("kind") != "continue" or (cfg.get("continue") or {}).get("perturb_match", "none") == "none":
        return None
    pm = _rj(d / "perturb_match.json") if (d / "perturb_match.json").exists() else {}
    why = str(pm.get("failure") or "")
    if not any(why.startswith(x) for x in DECLARED_PERTURB_OUTCOMES):
        return None
    return (f"declared outcome of the matched perturbation ({pm.get('metric', 'val_err')}): {why} "
            f"(target {pm.get('target_value', pm.get('target_val_err'))})")
