#!/usr/bin/env python3
"""v56: one validated view of a finished panel for the analyses that walk its saved states by age
(layer_course.py, routing_updates.py).  Nothing is trained and nothing is written.

open_panel   the manifest's design: arm and control levels, the one matched compact control of every expansion,
             the expansion length, the jobs of every f0
open_f0      one f0: its jobs' configurations, the data (hashes checked against every job's log), f0 itself
             (every expansion's reference copy and every control's start must be one network, a plain ReLU chain
             of weight matrices with biases, two classes, the generator's unrotated feature layout)
expansion_states / compact_states
             an expansion's saved states with additions (each insertion, the configured snapshots, the end) and a
             compact control's saved evaluation states, each with its lineage checked and its age verified (the
             trainer's step counter, or the checkpoint's own update record for the control snapshots)
graph helpers  the activation after each backbone layer, the merge the additions feed, node values of a graph
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import component_change as CC  # noqa: E402
import coordinated_edits as CE  # noqa: E402
import panel26_tables as PT  # noqa: E402
import selective_reversal as SR  # noqa: E402

torch = SR.torch
AC = SR.AC
Fail = SR.Fail
GraphNet = SR.GraphNet
CHAIN_TOL = CC.CHAIN_TOL


def open_panel(results, manifest) -> SimpleNamespace:
    runs = Path(results) / "runs"
    mcfg = {e["run_id"]: e["cfg"] for e in AC.manifest_entries(manifest)}
    exp_lev, comp_lev, _, fork_u = PT.design(mcfg)
    return SimpleNamespace(runs=runs, mcfg=mcfg, exp_lev=exp_lev, comp_lev=comp_lev, fork_u=int(fork_u),
                           matched=CC.require_matched(exp_lev, comp_lev), jobs=CC.f0_jobs(mcfg))


def open_f0(P, bid: str, data_root, dev, bundles: dict) -> SimpleNamespace:
    runs, mcfg, J = P.runs, P.mcfg, P.jobs[bid]
    if set(J["exp"]) != set(P.exp_lev) or set(J["comp"]) != set(P.comp_lev):
        raise Fail(f"f0 {bid}: its arms {sorted(J['exp'])} / controls {sorted(J['comp'])} are not the design's "
                   f"{sorted(P.exp_lev)} / {sorted(P.comp_lev)}")
    cfgs = {}
    for v, (rid, tid) in J["exp"].items():
        why = AC.declared_invalid(runs / rid, mcfg[rid])
        if why:
            raise Fail(f"{rid}: declared invalid ({why})")
        cfgs[rid] = AC.job_config(runs, rid, mcfg[rid])
        cfgs[tid] = AC.job_config(runs, tid, mcfg[tid])
    for v, rid in J["comp"].items():
        cfgs[rid] = AC.job_config(runs, rid, mcfg[rid])
        if cfgs[rid]["parents"]["baseline"] != bid:
            raise Fail(f"{rid}: its baseline is not {bid}")
    bcfg = AC.job_config(runs, bid, mcfg.get(bid))
    dkeys = {json.dumps(c["data"], sort_keys=True) for c in cfgs.values()}
    if len(dkeys) != 1:
        raise Fail(f"f0 {bid}: its jobs differ in data")
    dk = dkeys.pop()
    if dk not in bundles:
        b0 = SR.load_bundle(json.loads(dk), data_root, device="cpu")
        bundles[dk] = (b0.to(dev), b0.hashes())
    b, hashes = bundles[dk]
    parts = b.partitions()
    if b.task != "classification" or int(b.out_dim) != 2:
        raise Fail(f"f0 {bid}: needs a two-class classification task")
    if any(p not in parts for p in ("train", "val", "test", "val_indep")):
        raise Fail(f"f0 {bid}: the data has no val_indep partition")
    ps = AC.eval_partitions(b)
    need = {"train", *ps}
    any_cfg = cfgs[sorted(J["exp"].items())[0][1][0]]
    batch = int((any_cfg.get("train") or {}).get("eval_batch", 4096))
    f0k, f0_ids, ref = None, set(), {}
    for v, (rid, tid) in sorted(J["exp"].items()):
        AC.check_logged_data(runs / tid, hashes, need, f"{tid} data provenance")
        k = SR.ckp(runs / tid, "baseline_ref")
        gk = AC.check_ckpt(k, f"{v} f0", run_id=tid, stage="baseline_ref", cfg=cfgs[tid], hashes=hashes, need=need)
        f0_ids.add((AC.param_hash_of(k), gk.structural_hash()))
        ref[v] = k
        f0k = f0k or k
    for v, rid in sorted(J["comp"].items()):
        stg = (cfgs[rid].get("continue") or {}).get("start_stage", "best_val")
        k = SR.ckp(runs / bid, stg)
        gk = AC.check_ckpt(k, f"{v} f0", run_id=bid, stage=stg, cfg=bcfg, hashes=hashes, need=need)
        f0_ids.add((AC.param_hash_of(k), gk.structural_hash()))
        AC.check_logged_data(runs / rid, hashes, need, f"{rid} data provenance")
    if len(f0_ids) != 1:
        raise Fail(f"f0 {bid}: its expansions and controls do not start from one network")
    f0 = GraphNet.from_checkpoint(f0k["model"], dev).eval()
    f0_sd = {k: t.clone() for k, t in f0.state_dict().items()}
    L = SR.backbone_layers(f0)
    wk, bk = [], []
    for Lk in L:
        keys = [k for k in f0_sd if k.startswith(f"mods.{Lk}.")]
        ws = [k for k in keys if f0_sd[k].dim() == 2]
        bs = [k for k in keys if f0_sd[k].dim() == 1]
        if len(ws) != 1 or len(bs) != 1 or len(keys) != 2:
            raise Fail(f"f0 {bid}: a backbone layer is not one weight matrix with a bias")
        wk.append(ws[0])
        bk.append(bs[0])
    if len(L) < 3 or set(parts["train"].X) != {"x"}:
        raise Fail(f"f0 {bid}: needs one input tensor and at least two hidden layers")
    blk = CC.blocks_of((b.meta or {}).get("feature_layout") or {}, int(f0_sd[wk[0]].shape[1]))
    if blk is None:
        raise Fail(f"f0 {bid}: needs the generator's unrotated feature layout")
    _, zt = CE.mlp_forward(f0_sd, parts["test"].X["x"].to(dev), wk, bk)
    with torch.no_grad():
        rf = node_values(f0, parts["test"], [], batch)[1]
    if float((zt - rf).abs().max()) > CHAIN_TOL * max(1.0, float(rf.abs().max())):
        raise Fail(f"f0 {bid}: the network is not a plain ReLU chain of its layers")
    contrast = ((any_cfg.get("design") or {}).get("contrast") or "")
    meta = {"f0": bid, "design_id": CC.design_id(bcfg, contrast, P.exp_lev, P.comp_lev),
            "f0_param_hash": next(iter(f0_ids))[0], "cell": contrast.split("|")[-1],
            "draw_set": SR.draw_role(any_cfg), "data_draw": (bcfg.get("data") or {}).get("data_seed"),
            "optimizer_seed": (bcfg.get("seeds") or {}).get("optimizer")}
    return SimpleNamespace(bid=bid, J=J, cfgs=cfgs, bcfg=bcfg, b=b, hashes=hashes, parts=parts, ps=ps, need=need,
                           batch=batch, f0k=f0k, ref=ref, f0=f0, f0_sd=f0_sd, L=L, wk=wk, bk=bk, blk=blk,
                           sc=int(blk["shortcut"][0]), meta=meta, runs=runs, dev=dev)


def expansion_states(P, F, v: str) -> list:
    """-> [(stage, updates since f0, checkpoint)] of one expansion, in order of age."""
    rid, tid = F.J["exp"][v]
    out = []
    for stage, upd in CE.trajectory_checkpoints(F.runs / tid, F.cfgs[tid]):
        what = f"{v} {stage}"
        ck = SR.ckp(F.runs / tid, stage)
        if ck is None:
            raise Fail(f"{what}: the trajectory checkpoint is missing")
        AC.check_ckpt(ck, what, run_id=tid, stage=stage, cfg=F.cfgs[tid], hashes=F.hashes, need=F.need)
        CE.check_age(AC.job_update(ck, F.ref[v], what), upd, what)
        out.append((stage, int(upd), ck))
    if not out or out[-1][0] != "final" or out[-1][1] != P.fork_u:
        raise Fail(f"{v}: its last saved state is not the end of the expansion at {P.fork_u} updates")
    return out


def compact_states(P, F, v: str, max_updates: int) -> list:
    """-> [(stage, updates since f0, checkpoint)] of one compact control: its saved evaluation states up to
    max_updates.  Each must exist and record its own update."""
    rid = F.J["comp"][v]
    cc = F.cfgs[rid].get("continue") or {}
    if not cc.get("save_eval_checkpoints"):
        raise Fail(f"{rid}: the control saves no evaluation checkpoints")
    out = []
    for u in sorted({int(x) for x in cc.get("eval_at") or [] if 0 < int(x) <= max_updates}):
        ck = SR.ckp(F.runs / rid, f"at_{u}")
        if ck is None:
            raise Fail(f"{rid}: no saved state at update {u} (at_{u})")
        AC.check_ckpt(ck, f"{v} at {u}", run_id=rid, stage=f"at_{u}", cfg=F.cfgs[rid], hashes=F.hashes, need=F.need)
        rec_u = (ck.get("extra") or {}).get("update")
        if rec_u is None or int(rec_u) != u:
            raise Fail(f"{rid}: the checkpoint at_{u} records update {rec_u}, not {u}")
        out.append((f"at_{u}", u, ck))
    return out


# ----------------------------------------------------------------------------- graph helpers

def backbone_nodes(g, L: list) -> list:
    """the backbone's linear nodes in layer order."""
    out = []
    for Lk in L:
        ns = [g.nodes[n] for n in g.live_nodes() if g.nodes[n].pkey == Lk and g.nodes[n].owner is None]
        if len(ns) != 1 or ns[0].op != "linear" or len(ns[0].inputs) != 1:
            raise Fail(f"backbone layer {Lk} is not one linear node with one input")
        out.append(ns[0])
    return out


def activation_after(g, node) -> str:
    """the backbone activation node that follows one backbone linear node."""
    cons = [g.nodes[c] for c, _ in g.consumers(node.id, g.live_nodes())]
    acts = [c for c in cons if c.op == "act" and c.owner is None]
    if len(acts) != 1 or len(cons) != 1:
        raise Fail(f"backbone layer {node.pkey} is not followed by exactly one activation")
    return acts[0].id


def layer_sites(g, L: list) -> dict:
    """the nodes to read in an actual graph, by name: layer<k> = the activation after backbone layer k (k below
    the output layer), and layer<k>_post_merge = what backbone layer k+1 reads when that is another node (the
    additions' merge sits between them).  layer<k> is then the value the additions read."""
    bn = backbone_nodes(g, L)
    out = {}
    for k in range(1, len(bn)):
        a = activation_after(g, bn[k - 1])
        out[f"layer{k}"] = a
        cur = bn[k].inputs[0]
        if cur != a:
            hops, seen = cur, 0
            while g.nodes[hops].op == "identity" and seen < 8:      # the merge may be read through identity nodes
                hops, seen = g.nodes[hops].inputs[0], seen + 1
            m = g.nodes[hops]
            if m.op != "add" or m.inputs[0] != a:
                raise Fail(f"backbone layer {k + 1} does not read layer {k}'s activation or a merge on top of it")
            out[f"layer{k}_post_merge"] = cur
    return out


def node_values(g, part, nodes: list, batch: int) -> tuple:
    """-> ({node: value}, logits) of a graph on one partition, float64, without masks (the forward value)."""
    dt = next(g.parameters()).dtype
    vals, zs = {n: [] for n in nodes}, []
    with torch.no_grad():
        for i0 in range(0, len(part), batch):
            X = {k: (t[i0:i0 + batch].to(dt) if t.is_floating_point() else t[i0:i0 + batch])
                 for k, t in part.X.items()}
            if nodes:
                z, nv = g.forward(X, return_nodes=list(nodes))
                for n in nodes:
                    vals[n].append(nv[n].double())
            else:
                z = g.forward(X)
            zs.append(z.double())
    return {n: torch.cat(v) for n, v in vals.items()}, torch.cat(zs)


def leaves_of(g) -> list:
    """the leaf additions of a graph (as coordinated_edits lists them)."""
    return sorted([t for t, im in g.implants.items() if im.nodes and not any(
        o.parent == t and o.nodes for o in g.implants.values())], key=lambda s_: int(s_[1:]))
