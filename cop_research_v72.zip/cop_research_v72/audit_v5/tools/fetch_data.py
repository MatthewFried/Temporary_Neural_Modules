"""v25: fetch a dataset into the data root once, before a panel's parallel workers start (no worker then races
on a download).  Only datasets fetched from the network are handled.

  python audit_v5/tools/fetch_data.py covertype DATA_ROOT"""
import sys
from pathlib import Path


def main() -> int:
    if len(sys.argv) != 3 or sys.argv[1] not in ("covertype",):
        print(__doc__)
        return 2
    from sklearn.datasets import fetch_covtype
    d = fetch_covtype(data_home=str(Path(sys.argv[2]) / "sklearn"), download_if_missing=True)
    print("covertype", d.data.shape, "in", Path(sys.argv[2]) / "sklearn")
    return 0


if __name__ == "__main__":
    sys.exit(main())
