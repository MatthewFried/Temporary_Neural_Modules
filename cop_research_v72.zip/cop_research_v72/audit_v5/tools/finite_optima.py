"""Generate configs/finite_interface_optima.json: exact optima for the v5 finite-interface cells.
Every entry is a complete enumeration (cop.finite.codebook); small cases are cross-checked against
independent encoder enumeration (codebook.brute_force and cop.finite.message.enumerate_min_errors).
Usage: python audit_v5/tools/finite_optima.py [OUT.json]"""
import json
import sys
import time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from cop.finite import codebook as CB
from cop.finite import message

out_path = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "configs" / "finite_interface_optima.json"
KEEP = ("n", "k_bits", "messages", "errors", "answers", "accuracy", "complete", "method", "examined", "candidates",
        "seconds")
table, checks = {}, []
for n in (2, 3, 4, 5):
    for k in range(0, n + 1):
        r = CB.delayed_query_optimum(n, k)
        if not r["complete"]:
            continue                                   # too large to enumerate: left out (never approximated)
        table[f"delayed|n{n}|k{k}"] = {kk: r[kk] for kk in KEEP}
        if (2 ** k) ** (2 ** n) <= 1 << 16:
            e = message.enumerate_min_errors(n, k)
            b = CB.brute_force(n, k)
            assert e["complete"] and e["min_errors_examined"] == r["errors"] == b["min_errors"], (n, k)
            checks.append({"case": f"delayed n{n} k{k}", "codebook": r["errors"], "encoder_enum": e["min_errors_examined"],
                           "brute_force": b["min_errors"]})
for task, ns in (("bit:0", (2, 3, 4, 5)), ("parity:2", (2, 3, 4))):
    for n in ns:
        for k in range(1, n + 1):
            r = CB.retention_optimum(n, k, task)
            if not r["complete"]:
                continue
            table[f"retention|n{n}|k{k}|{task}"] = {kk: r[kk] for kk in KEEP if kk in r} | {"task": task}
            if (2 ** k) ** (2 ** n) <= 1 << 17:
                b = CB.brute_force(n, k, task, max_encoders=1 << 17)
                assert b["min_errors_zero_task_error"] == r["errors"], (task, n, k)
                checks.append({"case": f"retention {task} n{n} k{k}", "codebook": r["errors"],
                               "brute_force_zero_task_error": b["min_errors_zero_task_error"], "frontier": b["frontier"]})
table["_meta"] = {"generated": time.strftime("%Y-%m-%d"), "generator": "audit_v5/tools/finite_optima.py",
                  "model": "uniform x on {0,1}^n, uniform independent bit query, query-blind encoder, at most 2^k "
                           "messages, no bypass; retention: zero original-task error",
                  "cross_checks": checks}
out_path.write_text(json.dumps(table, indent=1) + "\n")
print(len(table) - 1, "entries;", len(checks), "cross-checks passed ->", out_path)
