#!/usr/bin/env python3
"""v58 / v59 / v60 / v61 / v63: from one network, does the first layer keep changing because of the ongoing routed additions, or does
the state reached already carry the change?  Reads the wave-28 panel (forks of wave 26's routed affine
trajectories); trains nothing; linear probes are fitted with component_change's solver.

For every f0 and parent arm (A_routed_affine, B_routed_affine) and fork point (snap_1000, snap_2500), the states:
  start           the trajectory at the fork point (the network every fork starts from)
  <continuation>  each fork's end (its exported model, the one its endpoint.json names, at 2U):
                    routed_reset    routing continues, additions trained, fresh optimizer
                    ordinary_reset  additions trained with every example's gradient (masks released)
                    frozen_reset    frozen affine scaffold, ordinary gradients: the additions fixed at the fork, the
                                    backbone trained through them (not the compact network's training)
                    folded_reset    (v59) the additions folded exactly into the layer that reads the merge (layer 3 at depth 4) and removed, the compact network
                                    trained directly
                    routed_carry    as routed_reset with the parent's optimizer state
  trajectory_end  the trajectory's own end (2U): a REFERENCE, not an exact replay control.  It continued with its own
                  optimizer state and sampler; from snap_1000 it also made the second insertion at U, which no fork
                  makes; the forks' common minibatch stream is the continuation jobs' own, not restored from the
                  parent's sampler
and f0.  Per state:
  native        the network's own errors (test, val, val_indep, shift, rare) and training loss
  extraction    its first layer in f0, the rest of f0 (component_change's construction): errors
  normalised    the same with the first layer at f0's norm per unit and input block and f0's bias
                (state_at_f0_block_row_norms_f0_bias), and at f0's block norms with f0's bias: errors
  shape         component_change.layer_summary (norm ratios, cosines to f0, bias change)
  probes        label, fitted on val_indep, both penalties, standardised and whitened (merge_geometry's
                preprocessing): on the first layer's activations, on the normalised first layer's activations
                (in f0), and in the network's own graph on every hidden layer after the first and the merge
                (layer<k>_post_merge, when the additions are there; v62: at any depth)
Per fork (v59; v60 tightened; every real run): the audit (_audits.csv) tests that each intervention was carried out
as named.  The fork starts from the saved state (the parent state hash it recorded is the snapshot's); the update
count; the minibatch stream (the same batch-id hash in every fork of a fork point, as many batches as updates); the
optimizer policy and membership (reset: fresh state, no moments; carry: the carried digest and step range equal to
the parent checkpoint's optimizer state by parameter name; at the first update the optimizer holds every tensor and
every trainable one received a step: all of them, the backbone's only for frozen_reset); the mask membership
(routed: masks retained, branch-a eligibility equal to the parent's split and branch b its complement; otherwise
released); the parameters (frozen: every addition's tensor unchanged and the trainable set EQUAL to the backbone's;
routed and ordinary: the additions present and trainable; folded: no addition left, the gradient masks recorded as
removed, f0's architecture); for folded_reset, the saved after-fold checkpoint (the network compact training started
from: its recorded hashes, no addition or mask, f0's architecture, the receiving layer = W A and b + W c (layer 3 at depth 4) for the snapshot's
exact merge map h -> A h + c within COMPOSE_TOL, every other backbone layer the snapshot's exactly) and the fold's
function change, v61: decided in float64 (the fold rebuilt in float64 against the snapshot in float64 within
ALGEBRA_TOL, the saved float32 fold evaluated in float64 within STORAGE_TOL, the run's KL), with the float32 forward
differences (here, on --recorded-device, and the run's drift) reported and v60's float32 rule kept as a column; the
held shortcut column (B); the learning rate and schedule of the parent.  Any failed check fails the analysis.  What
the training then did, whether the additions' tensors moved, is an outcome (outcome_additions_moved), never a check.
Interpretation rule: folding moves the additions' computation into the receiving layer by algebra, so a successful folded
continuation does not by itself show that the original backbone had learned to replace the additions.  Learning in
the original components is read from the first layer's change, its extraction into f0's unchanged downstream
network, the norm-and-bias restoration diagnostic, and the paired comparisons of which continuation develops or keeps
that change.
  _states      one row per state with every measure as a column (probe columns: probe|<feature>|<prep>|lam=<l>)
  _compute     (v63) per fork: the training compute to the fork point, of the fork, and in total; per compact
               control state its own; each fork's total over the compact control's at 2U and at 4U
  compact      (v63) when the manifest has wave 26's compact controls (f0 continued with the parent's hold), the states
               compact_2U (update-matched to the forks' ends) and compact_4U (the control's end, more updates: see
               _compute) are measured like every other state (parent = the arm whose hold they share, fork =
               "compact"), with the contrasts fork_minus_compact_2U and fork_minus_compact_4U for every continuation
  compact_reset (v66) when the manifest has wave 32's reset-matched controls (f0 continued with the parent's hold to
               the fork age, the optimizer reset there, trained to 2U): the state compact_reset at (parent, fork) and
               fork_minus_compact_reset for every continuation (the forks reset their optimizer; compact_2U carries it)
v66 checks: every edit's saved start (event_after_fold, event_after_redistribute) passes check_ckpt (recomputed tensor
hash, finite, run, stage, configuration, data) before any numerical test; a mechanism fork's saved start must keep the
snapshot's function in float64 within STORAGE_TOL (redistribution_storage, a certificate); non-finite values fail every
comparison (func_compare, within); a normalised first layer is measured only when its target norms are attained
per row within NORM_ATOL + NORM_RTOL x target (v68; *_norm_miss the largest per-row relative error, *_norm_max_abs,
*_norm_failed_rows, *_eligible; otherwise its errors and its probe are withheld and it is listed in normalised_ineligible).
  _central     (v61) per parent, fork and state: the complete network, the raw and normalised extraction, training
               loss, first-layer shape and first-layer label probes (both penalties), each paired against f0 and
               against the fork start, with gain_points (positive: lower error) and the draw and draw-seed counts
  _contrasts_summary_sensitivity   (v61) the contrast summaries without every draw holding a flagged fork
  _contrasts   within f0, parent and fork point, for every measure (first - second):
                 continuation_minus_start  each continuation minus the start (what the continuation changed)
                 routed_minus_ordinary     routed_reset - ordinary_reset: continuing gradient routing
                 ordinary_minus_frozen     ordinary_reset - frozen_reset: continuing to learn the additions
                 frozen_minus_folded       frozen_reset - folded_reset: keeping a fixed affine parametrisation
                 carry_minus_reset         routed_carry - routed_reset: optimizer-state dependence
                 trajectory_end_minus_routed_carry   the reference against its closest fork
                 start_minus_f0
               Each holds for these checkpoints, budgets and optimizer settings only.  An improvement under
               frozen_reset does not show the backbone alone suffices: the frozen additions stay in the forward pass.
Each with _by_draw and _summary (seeds averaged within a draw, 95% t intervals over draws).  Exploratory.

usage: fork_continuation.py RESULTS OUT_PREFIX --manifest M [--data-root D] [--device cpu|cuda] [--strict]
                            [--eval-batch N] [--recorded-device DEV]
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import component_change as CC  # noqa: E402
import coordinated_edits as CE  # noqa: E402
import f0_panel as FP  # noqa: E402
import merge_geometry as MG  # noqa: E402
import selective_reversal as SR  # noqa: E402
from cop.graph import edits as E  # noqa: E402
from cop.experiments.dissipation import parent_opt_digest  # noqa: E402
from cop.graph.export import export_compact  # noqa: E402
from cop.utils import stable_hash, tensor_hash  # noqa: E402

torch = SR.torch
AC = SR.AC
Fail = SR.Fail
GraphNet = SR.GraphNet

ANALYSIS_SCHEMA = "fork_continuation/v68"
STATUS = "exploratory reanalysis of existing checkpoints (no network is trained; linear probes are fitted)"
CONTS = ("routed_reset", "ordinary_reset", "frozen_reset", "folded_reset", "routed_carry")
# v65 (wave 31): the mechanism forks, keep forks from a function-preserving redistribution (cop.graph.redistribute)
MECH = {"routed_swap": "keep_swap", "ordinary_swap": "keep_swap", "routed_shift50": "keep_shift50",
        "routed_shift100": "keep_shift100", "ordinary_shift100": "keep_shift100"}
WITH_ADDITIONS = ("routed_reset", "ordinary_reset", "frozen_reset", "routed_carry", *MECH)
NAMED = (("routed_minus_ordinary", "routed_reset", "ordinary_reset", "continuing gradient routing"),
         ("ordinary_minus_frozen", "ordinary_reset", "frozen_reset", "continuing to learn the additions"),
         ("frozen_minus_folded", "frozen_reset", "folded_reset", "keeping a fixed affine parametrisation"),
         ("carry_minus_reset", "routed_carry", "routed_reset", "optimizer-state dependence"))
NAMED_MECH = (("swap_minus_routed", "routed_swap", "routed_reset", "the branch maps exchanged, routing kept"),
              ("swap_minus_ordinary", "ordinary_swap", "ordinary_reset", "the branch maps exchanged, ordinary gradients"),
              ("shift50_minus_routed", "routed_shift50", "routed_reset", "half the map in the receiving layer, routed"),
              ("shift100_minus_routed", "routed_shift100", "routed_reset", "the whole map in the receiving layer, routed"),
              ("shift100_minus_ordinary", "ordinary_shift100", "ordinary_reset",
               "the whole map in the receiving layer, ordinary gradients"))
# the routing-specific part of an edit: (routed edit - routed_reset) - (ordinary edit - ordinary_reset)
INTERACTIONS = (("swap_interaction", "routed_swap", "ordinary_swap"),
                ("shift100_interaction", "routed_shift100", "ordinary_shift100"))
FOLD_TOL = 1e-5                # v60's float32 rule (reported, no longer decisive: v61)
FOLD_KL_TOL = 1e-8             # mean KL from the parent at the fold (the run's own path record)
ALGEBRA_TOL = 1e-10            # v61: the fold rebuilt in float64 against the snapshot in float64 (relative logits)
STORAGE_TOL = 1e-5             # v61: the SAVED float32 fold evaluated in float64 against the snapshot in float64
CENTRAL = ("native_test_err", "extraction_test_err", "state_at_f0_block_row_norms_f0_bias_test_err",
           "state_at_f0_block_norms_f0_bias_test_err", "native_train_loss", "layer_norm_ratio", "causal_cos_to_f0")
NORMALISED = ("state_at_f0_block_row_norms_f0_bias", "state_at_f0_block_norms_f0_bias")
PARTS = ("test", "val", "val_indep", "shift", "rare")
NATIVE_FEATURES = "every hidden layer after the first and the merge (layer<k>_post_merge), as the graph has them"
SHAPE = ("layer_norm_ratio", "layer_cos_to_f0", "change_over_f0_norm", "bias_change_over_f0_norm",
         "causal_norm_ratio", "shortcut_norm_ratio", "other_norm_ratio", "causal_cos_to_f0")
CONTRAST_KEYS = ("design_id", "parent", "fork", "comparison", "first", "second", "metric", "sign")
STATE_KEYS = ("design_id", "parent", "fork", "state")
AUDIT_CHECKS = ("starts_from_snapshot", "updates", "stream_batches", "stream_shared", "optimizer_policy",
                "mask_membership", "parameters", "fold_start", "fold_function", "redistribution",
                "redistribution_storage", "held_column", "lr_schedule")
NORM_TOL = 1e-5                # v66 (kept for reference; v68 uses the per-row NORM_RTOL / NORM_ATOL criterion)
COMPOSE_TOL = 1e-5             # the saved after-fold layer against W A and b + W c (float64, relative)


def snapshot_hash(ck: dict) -> str:
    """the parent state hash a dissipation job records for the checkpoint it starts from."""
    return stable_hash({k: tensor_hash(v) for k, v in sorted(ck["model"]["state"].items())})


def addition_pkeys(g) -> set:
    return {g.nodes[n].pkey for im in g.implants.values() for n in im.nodes if g.nodes[n].pkey}


def mask_keys(g) -> list:
    return sorted({g.nodes[n].attrs["mask_key"] for n in g.live_nodes() if g.nodes[n].op == "mask_grad"})


def top_additions(g) -> list:
    return sorted([i for i, im in g.implants.items() if im.parent is None], key=lambda s_: int(s_[1:]))


def refold(g):
    """the network with every top-level addition folded exactly (gradient masks dropped) and exported compact:
    fold_unrouted's construction, rebuilt here from the snapshot."""
    m = g
    for t in top_additions(g):
        if t in m.implants:
            m = E.fold_implant(m, t, share_params=False, drop_grad_masks=True)
    return export_compact(m, fold_linear=True)[0]


def _macs(ck) -> int:
    """the trainer's cumulative training-MAC counter of a checkpoint (trainer state, or extra.trainer)"""
    t = (ck or {}).get("trainer") or ((ck or {}).get("extra") or {}).get("trainer") or {}
    return int((t.get("state") or {}).get("train_macs", 0))


def as64(g):
    """a float64 copy of a network (the same values, evaluated without float32 rounding)."""
    import copy
    m = copy.deepcopy(g)
    m.double()
    m._plan = None
    return m.eval()


def state_keys(*rows) -> str:
    """v68: the state records a contrast row was computed from ('parent/fork/state', ';'-separated): the registry
    requires each to be an explicit validated record (a fork with a passed audit, or a measured state)."""
    return ";".join(sorted({f"{r['parent']}/{r['fork']}/{r['state']}" for r in rows}))


def output_bindings(Pfx: str) -> dict:
    """v68: full SHA-256 of the row tables an analysis wrote, recorded in its coverage (which is outside the cycle),
    so a registry reads exactly these rows."""
    import hashlib
    out = {}
    for suf in ("audits.csv", "contrasts.csv", "states.csv"):
        p_ = Path(f"{Pfx}_{suf}")
        if p_.exists():
            out[suf] = hashlib.sha256(p_.read_bytes()).hexdigest()
    return out


def func_compare(ga, gb, parts: dict, names: list, batch: int) -> dict:
    """(v66) ga against gb on the partitions: rel (largest |logits(ga) - logits(gb)|, relative to max(1, largest
    |logits(gb)|)), centred (the same for logits centred over the classes), kl (largest mean KL(gb || ga) over the
    partitions), flip (largest share of decisions that differ), margin (gb's smallest logit margin among those
    examples, None without a flip).  Any non-finite logit, an empty partition or a shape mismatch makes every
    distance infinite (a failed comparison, never a zero)."""
    out = {"rel": 0.0, "centred": 0.0, "kl": 0.0, "flip": 0.0, "margin": None, "finite": True}
    bad = {"rel": math.inf, "centred": math.inf, "kl": math.inf, "flip": 1.0, "margin": None, "finite": False}
    if not names:
        return bad
    for p_ in names:
        _, za = FP.node_values(ga, parts[p_], [], batch)
        _, zb = FP.node_values(gb, parts[p_], [], batch)
        if za.shape != zb.shape or za.numel() == 0 or za.dim() != 2 or \
                not bool(torch.isfinite(za).all()) or not bool(torch.isfinite(zb).all()):
            return dict(bad)
        za, zb = za.double(), zb.double()
        sc = max(1.0, float(zb.abs().max()))
        ca, cb = za - za.mean(1, keepdim=True), zb - zb.mean(1, keepdim=True)
        lpa, lpb = torch.log_softmax(za, 1), torch.log_softmax(zb, 1)
        fl = za.argmax(1) != zb.argmax(1)
        # v68: every derived statistic is checked finite before it is accumulated (max() would drop a NaN)
        cur = {"rel": float((za - zb).abs().max()) / sc, "centred": float((ca - cb).abs().max()) / sc,
               "kl": float((lpb.exp() * (lpb - lpa)).sum(1).mean()), "flip": float(fl.double().mean())}
        if not all(math.isfinite(v) for v in (*cur.values(), sc)):
            return dict(bad)
        for k_, v_ in cur.items():
            out[k_] = max(out[k_], v_)
        if bool(fl.any()):
            top = zb.topk(2, 1).values
            mg = float((top[:, 0] - top[:, 1])[fl].min())
            out["margin"] = mg if out["margin"] is None else min(out["margin"], mg)
    if not all(math.isfinite(out[k]) for k in ("rel", "centred", "kl", "flip")):
        return dict(bad)
    return out


def rel_logit_change(ga, gb, parts: dict, names: list, batch: int) -> float:
    """largest |logits(ga) - logits(gb)| over the partitions, relative to max(1, largest |logits(gb)|); infinite
    when any logit is not finite (v66: a NaN never passes as a small change)."""
    return func_compare(ga, gb, parts, names, batch)["rel"]


def within(x, tol: float) -> bool:
    """x <= tol for a finite number; anything else (None, NaN, inf) fails."""
    return isinstance(x, (int, float)) and math.isfinite(float(x)) and float(x) <= tol


NORM_RTOL, NORM_ATOL = 1e-5, 1e-8   # v68: per row |achieved - target| <= NORM_ATOL + NORM_RTOL * |target|


def norm_check(pairs) -> dict:
    """(v68) the per-row (per-block) attainment of a normalised layer's target norms.  pairs: (achieved, target,
    source) norm vectors in float64.  Rows whose source norm is zero are left out (counted as unmatched elsewhere
    when their target is not zero; a zero target with a zero source stays zero).  A row fails when
    |achieved - target| > NORM_ATOL + NORM_RTOL * |target|.  Reports the largest per-row relative error (target > 0),
    the largest absolute error and the failed-row count; non-finite -> failed."""
    max_rel, max_abs, failed, n = 0.0, 0.0, 0, 0
    for a, t, s_ in pairs:
        if not (bool(torch.isfinite(a).all()) and bool(torch.isfinite(t).all())):
            return {"max_rel": math.inf, "max_abs": math.inf, "failed_rows": -1, "rows": -1}
        m_ = s_ > 0
        if not bool(m_.any()):
            continue
        a, t = a[m_], t[m_]
        err = (a - t).abs()
        n += int(m_.sum())
        failed += int((err > NORM_ATOL + NORM_RTOL * t.abs()).sum())
        max_abs = max(max_abs, float(err.max()))
        pos = t > 0
        if bool(pos.any()):
            max_rel = max(max_rel, float((err[pos] / t[pos]).max()))
    return {"max_rel": max_rel, "max_abs": max_abs, "failed_rows": failed, "rows": n}


def norm_attainment(name: str, We, W0, W, blk) -> dict:
    """(v66 / v68) norm_check of a normalised first layer: per output row and block (block_row_norms) or per block
    (block_norms)."""
    pairs = []
    for idx in blk.values():
        i = idx.to(We.device)
        if "block_row_norms" in name:
            pairs.append(tuple(x[:, i].double().norm(dim=1) for x in (We, W0, W)))
        else:
            pairs.append(tuple(x[:, i].double().norm().reshape(1) for x in (We, W0, W)))
    return norm_check(pairs)


def event_integrity(cks, label: str, rid: str, stage: str, cfg: dict, hashes: dict, need) -> tuple:
    """(v66) an edit's saved start through check_ckpt (its run, stage, configuration, recomputed parameter hash,
    finite tensors, graph hash, data hashes) -> (passed, detail)."""
    try:
        AC.check_ckpt(cks, label, run_id=rid, stage=stage, cfg=cfg, hashes=hashes, need=need)
        return True, "integrity: run, stage, configuration, recomputed tensor hash, finite, graph, data"
    except Fail as ex_:
        return False, f"integrity: {ex_}"


def in_f0_layout(g, f0k: dict, wk: list, bk: list, dev):
    """a compact network with f0's architecture (a folded fork: the receiving layer is a new linear node) as f0's graph with
    these weights, layer by layer in topological order; the two must compute the same function (checked by the
    caller on data)."""
    lin = [g.nodes[n] for n in g.topo_order(g.live_nodes()) if g.nodes[n].op == "linear" and g.nodes[n].owner is None]
    if g.implants or len(lin) != len(wk):
        raise Fail(f"a folded network with {len(lin)} linear layers and {len(g.implants)} additions, expected "
                   f"{len(wk)} and none")
    sd = g.state_dict()
    m = GraphNet.from_checkpoint(f0k["model"], dev).eval()
    want = dict(m.state_dict())
    for nd, w_, b_ in zip(lin, wk, bk):
        W, B = sd[f"mods.{nd.pkey}.weight"], sd.get(f"mods.{nd.pkey}.bias")
        if W.shape != want[w_].shape or B is None or B.shape != want[b_].shape:
            raise Fail(f"a folded layer {nd.pkey} does not have f0's shape at {w_}")
        want[w_], want[b_] = W.to(want[w_].device, want[w_].dtype), B.to(want[b_].device, want[b_].dtype)
    m.load_state_dict(want)
    m._plan = None
    CE.verify_patch(m.state_dict(), want, "fork continuation: folded network in f0's layout")
    return m


def backbone_pkeys(g) -> set:
    return {g.nodes[n].pkey for n in g.live_nodes() if g.nodes[n].pkey and g.nodes[n].owner is None}


def audit_fork(cn: str, res: dict, ep: dict, n_upd: int, snap_hash: str, g0, st0: dict, s1: dict, w1: str, sc: int,
               held: bool, ptrain: dict) -> tuple:
    """-> ({check: (passed, detail)}, {recorded outcome: value}): one fork against its name, from its own records
    and its checkpoints (st0: the snapshot checkpoint, s1: the fork's end state).  The checks test that the
    intervention was carried out as named; what the training then did (whether the additions moved) is an outcome,
    recorded apart and never a failure.  fold_start and fold_function are filled in by the caller for folded_reset
    (they need the data and the saved after-fold checkpoint)."""
    A, O = {}, {}
    s0 = {k: t.cpu() for k, t in st0["model"]["state"].items()}
    sa = res.get("schedule_audit") or {}
    ph = sa.get("phases") or []
    ev = sa.get("events") or []
    A["starts_from_snapshot"] = (sa.get("parent_state_hash") == snap_hash,
                                 f"recorded {sa.get('parent_state_hash')}, snapshot {snap_hash}")
    A["updates"] = (int(ep["updates"]) == n_upd and int(sa.get("updates_total", -1)) == n_upd,
                    f"endpoint {ep['updates']}, schedule {sa.get('updates_total')}, expected {n_upd}")
    A["stream_batches"] = (int(sa.get("batches_drawn", -1)) == n_upd and bool(sa.get("batch_id_hash")),
                           f"{sa.get('batches_drawn')} batches")
    carried = [e for e in ev if e.get("event") == "optimizer_carried"]
    resets = [e for e in ev if e.get("event") == "optimizer_reset"]
    imp = addition_pkeys(g0)
    bb = backbone_pkeys(g0)
    n_all = sum(1 for _ in g0.parameters())
    n_bb = sum(1 for pk in bb for _ in g0.mods[pk].parameters())
    audits = [p.get("optimizer_audit") or {} for p in ph]
    first = [a_.get("after_first_update") or {} for a_ in audits]
    start = [a_.get("start") or {} for a_ in audits]
    # optimizer membership: which tensors the optimizer holds and which received a step at the first update
    if cn == "folded_reset":
        want_n, want_state = None, None             # the compact network's own count (checked by the caller)
    elif cn == "frozen_reset":
        want_n, want_state = n_all, n_bb
    else:
        want_n, want_state = n_all, n_all
    member = bool(ph) and (want_n is None or all(f_.get("tensors") == want_n and
                                                 f_.get("tensors_with_state") == want_state for f_ in first))
    if cn == "routed_carry":
        names = list((st0.get("trainer") or {}).get("opt_param_names") or [])
        want_d = parent_opt_digest(st0, names) if names else {}
        ok = bool(carried) and bool(ph) and all(p.get("optimizer") == "carried from the parent" for p in ph) and \
            (res.get("removal_policy") or {}).get("optimizer") == "carry_from_parent" and bool(want_d) and \
            len(names) == n_all and all(e.get("digest") == want_d["digest"] and
                                        e.get("step_min") == want_d["step_min"] and
                                        e.get("step_max") == want_d["step_max"] for e in carried) and \
            all(s_.get("digest") == want_d["digest"] and s_.get("tensors_with_state") == n_all for s_ in start)
        det = (f"{len(carried)} carry events, digest {[e.get('digest') for e in carried]}, the parent's "
               f"{want_d.get('digest')} over {len(names)} named tensors")
    else:
        ok = not carried and bool(resets) and all(int(e.get("moments_present", -1)) == 0 for e in resets) and \
            bool(ph) and all(p.get("optimizer") == "fresh at phase start" for p in ph) and \
            all(s_.get("tensors_with_state") == 0 for s_ in start)
        det = f"{len(resets)} resets, {len(carried)} carry events"
    A["optimizer_policy"] = (ok and member, f"{det}; first update: {[(f_.get('tensors'), f_.get('tensors_with_state')) for f_ in first]}"
                                            f" tensors / with state, expected ({want_n}, {want_state})")
    if cn.startswith("routed"):
        ok = bool(ph) and all(p.get("grad_masks") == "retained" and isinstance(p.get("eligibility"), dict) and
                              p["eligibility"].get("a_matches_split") is True and
                              p["eligibility"].get("b_is_complement") is True for p in ph)
        det = "masks retained, eligibility equal to the parent's split"
    else:
        ok = bool(ph) and all(p.get("grad_masks") == "released" for p in ph)
        det = "masks released"
    A["mask_membership"] = (ok, det)
    ks = [k for k in s0 if k.startswith("mods.") and k.split(".")[1] in imp]
    trainable = [p.get("trainable") for p in ph]
    if cn == "folded_reset":
        ok = int(ep.get("n_implants", -1)) == 0 and ep.get("architecture_hash") == ep.get("f0_architecture_hash") \
            and res.get("grad_masks_removed") == mask_keys(g0) and bool(res.get("grad_masks_removed")) and \
            res.get("targets") == top_additions(g0) and not res.get("targets_remaining_in_export") and \
            not any(k in s1 for k in ks) and all(t == "all" for t in trainable)
        det = f"masks removed {res.get('grad_masks_removed')}, implants left {ep.get('n_implants')}"
        O["additions_moved"] = None
    else:
        same = [torch.equal(s1[k], s0[k]) for k in ks if k in s1]
        present = bool(same) and len(same) == len(ks) and int(ep.get("n_implants", 0)) > 0
        O["additions_moved"] = f"{len(same) - sum(same)} of {len(ks)}"
        if cn == "frozen_reset":
            ok = present and all(same) and all(isinstance(t, list) and set(t) == bb for t in trainable)
            det = f"{sum(same)} of {len(ks)} addition tensors unchanged; trainable {trainable}, backbone {sorted(bb)}"
        else:
            # enabled: every tensor trainable and in the optimizer (above); whether the additions moved is an outcome
            ok = present and all(t == "all" for t in trainable)
            det = f"additions present and trainable; {O['additions_moved']} addition tensors changed"
    A["parameters"] = (ok, det)
    A["fold_start"] = (True, "not a fold")
    A["fold_function"] = (True, "not a fold")
    A["redistribution"] = (True, "not a redistribution")
    A["redistribution_storage"] = (True, "not a redistribution")
    if held:
        ok = torch.equal(s1[w1][:, sc], s0[w1][:, sc])
        det = "the first layer's shortcut column held"
    else:
        ok, det = True, "no hold"
    A["held_column"] = (ok, det)
    ok = bool(ph) and all(float(p.get("lr")) == float(ptrain["lr"]) and p.get("lr_schedule") == ptrain["lr_schedule"]
                          for p in ph)
    A["lr_schedule"] = (ok, f"{[(p.get('lr'), p.get('lr_schedule')) for p in ph]} vs parent "
                            f"{(ptrain['lr'], ptrain['lr_schedule'])}")
    return A, O


def fold_start_audit(res: dict, ep: dict, ck_start: dict, g_start, g_snap, L: list, wk: list, bk: list,
                     n_opt: list) -> tuple:
    """(v60) the saved after-fold checkpoint, the compact network training started from: its hashes are the ones the
    run recorded; no addition or gradient mask is left; its architecture is f0's; the receiving layer is W A and b + W c (A, c
    the exact map of the snapshot's merge, W, b the snapshot's receiving layer) within COMPOSE_TOL; every other backbone
    layer is the snapshot's exactly; the optimizer held the compact network's tensors.  g_start: the checkpoint in
    f0's layout.  -> (passed, detail)."""
    fs = res.get("fold_start") or {}
    lin = ck_start.get("lineage") or {}
    evs = [e for e in (res.get("schedule_audit") or {}).get("events") or [] if e.get("event") == "fold_unrouted"]
    why = []
    if not fs or fs.get("checkpoint") != "event_after_fold" or int(fs.get("update", -1)) != 0:
        why.append(f"fold_start record {fs}")
    if lin.get("param_hash") != fs.get("param_hash") or lin.get("graph_hash") != fs.get("graph_hash"):
        why.append("the saved checkpoint's hashes are not the recorded ones")
    if len(evs) != 1 or evs[0].get("checkpoint") != "event_after_fold":
        why.append(f"{len(evs)} fold events")
    spec = (ck_start.get("model") or {}).get("spec") or {}
    if spec.get("implants") or any(n.get("op") == "mask_grad" for n in spec.get("nodes") or []):
        why.append("additions or gradient masks left in the saved checkpoint")
    if fs.get("architecture_hash") != ep.get("f0_architecture_hash"):
        why.append("its architecture is not f0's")
    sites = FP.layer_sites(g_snap, L)
    posts = [f for f in sites if f.endswith("_post_merge")]
    if len(posts) != 1:
        why.append(f"the snapshot has {len(posts)} merge sites, not one")
        return False, "; ".join(why)
    post = posts[0]
    pre = post[:-len("_post_merge")]
    k = int(pre[len("layer"):])                 # the merge feeds backbone layer k + 1 (index k)
    ex = MG.exact_merge_map(g_snap, sites[pre], sites[post])
    if ex is None:
        why.append("the snapshot's merge is not affine")
        return False, "; ".join(why)
    Am, c = ex
    if not (bool(torch.isfinite(Am).all()) and bool(torch.isfinite(c).all())):
        why.append("the snapshot's merge map is not finite")
        return False, "; ".join(why)
    ss = {k: t.double().cpu() for k, t in g_snap.state_dict().items()}
    sf = {k: t.double().cpu() for k, t in g_start.state_dict().items()}
    W3, b3 = ss[f"mods.{L[k]}.weight"], ss[f"mods.{L[k]}.bias"]
    Wf, bf = W3 @ Am, b3 + W3 @ c
    dW = float((sf[wk[k]] - Wf).abs().max()) / max(1.0, float(Wf.abs().max()))
    db = float((sf[bk[k]] - bf).abs().max()) / max(1.0, float(bf.abs().max()))
    if not (within(dW, COMPOSE_TOL) and within(db, COMPOSE_TOL)):
        why.append(f"layer {k + 1} is not W A, b + W c (relative {dW:.3g}, {db:.3g})")
    for i, Lk in enumerate(L):
        if i == k:
            continue
        if not (torch.equal(sf[wk[i]], ss[f"mods.{Lk}.weight"]) and torch.equal(sf[bk[i]], ss[f"mods.{Lk}.bias"])):
            why.append(f"backbone layer {Lk} changed at the fold")
    n_c = sum(1 for _ in g_start.parameters())
    if not n_opt or any(f_ != (n_c, n_c) for f_ in n_opt):
        why.append(f"optimizer tensors / with state at the first update {n_opt}, the compact network has {n_c}")
    return not why, ("; ".join(why) if why else
                     f"saved after-fold checkpoint {fs.get('param_hash')}: layer {k + 1} = W A, b + W c (relative "
                     f"{dW:.2g}, {db:.2g}), other layers unchanged, no additions or masks, f0's architecture")


def redistribution_audit(cn: str, res: dict, cks, g_snap, parts: dict, names: list, batch: int, *,
                         integrity: tuple = (True, ""), rec=None) -> tuple:
    """(v65, v66) the saved start of a mechanism fork (event_after_redistribute) against its snapshot.
    Separate statuses:
      structure   the snapshot with exactly the declared edit (swap: every addition tensor exchanged with its partner
                  exactly, nothing else; shift: the branches' last layers the snapshot's times s exactly, the
                  receiving layer W (I + M) (I + s M)^-1, b + W m - s W' m within COMPOSE_TOL, nothing else), with
                  finite maps, solve and residual, after the checkpoint's integrity (event_integrity)
      algebra     the edit rebuilt in float64 from the snapshot computes the snapshot's function within ALGEBRA_TOL
      storage     the SAVED edited start evaluated in float64 computes the snapshot's function within STORAGE_TOL
                  (v66: required, as for the fold)
      forward32   the saved start against the snapshot in float32 here and (rec: (device, partitions, snapshot model)) on the
                  recorded training device: relative and centred logits, KL, decisions that differ and the smallest
                  margin among them (reported)
    -> (structure and algebra passed, detail, storage passed, storage detail, outcomes)."""
    from cop.graph import redistribute as RD
    why, O = [], {}
    rd = res.get("redistribution") or {}
    st_rec = rd.get("start") or {}
    method = MECH[cn]
    kind, t = RD.REDISTRIBUTIONS[method]
    evs = [e for e in (res.get("schedule_audit") or {}).get("events") or [] if e.get("event") == "redistribute"]
    if rd.get("method") != method or len(evs) != 1 or evs[0].get("checkpoint") != "event_after_redistribute" or \
            int(st_rec.get("update", -1)) != 0:
        why.append(f"redistribution record {rd.get('method')}, {len(evs)} events, start {st_rec}")
    if cks is None:
        return False, "no saved start (event_after_redistribute)", False, "no saved start", O
    if not integrity[0]:
        return False, integrity[1], False, integrity[1], O
    lin = cks.get("lineage") or {}
    if lin.get("param_hash") != st_rec.get("param_hash") or lin.get("graph_hash") != st_rec.get("graph_hash"):
        why.append("the saved start's hashes are not the recorded ones")
    g_rs = GraphNet.from_checkpoint(cks["model"], next(g_snap.parameters()).device).eval()
    if g_rs.structural_hash() != g_snap.structural_hash():
        why.append("the saved start's graph is not the snapshot's")
        return False, "; ".join(why), False, "not evaluated", O
    ss = {k: v.cpu() for k, v in g_snap.state_dict().items()}
    sr = {k: v.cpu() for k, v in g_rs.state_dict().items()}
    if not all(bool(torch.isfinite(v).all()) for v in sr.values() if v.is_floating_point()):
        return False, "non-finite tensors in the saved start", False, "not evaluated", O
    G = RD.the_group(g_snap)
    pairs = RD.branch_pairs(g_snap, G)
    touched = set()

    def key(bid, role, what):
        return f"mods.{g_snap.nodes[RD._role_node(g_snap, bid, role)].pkey}.{what}"
    if kind == "swap":
        for a_, b_ in pairs:
            for role in ("A", "B"):
                for what in ("weight", "bias"):
                    ka, kb = key(a_, role, what), key(b_, role, what)
                    if ka not in ss:
                        continue
                    touched |= {ka, kb}
                    if not (torch.equal(sr[ka], ss[kb]) and torch.equal(sr[kb], ss[ka])):
                        why.append(f"{ka} and {kb} are not exchanged exactly")
        det = f"{len(pairs)} branch pairs exchanged exactly"
    else:
        sc = 1.0 - float(t)
        for a_, b_ in pairs:
            for bid in (a_, b_):
                for what in ("weight", "bias"):
                    kk = key(bid, "B", what)
                    if kk not in ss:
                        continue
                    touched.add(kk)
                    if not torch.equal(sr[kk], ss[kk] * sc):
                        why.append(f"{kk} is not the snapshot's times {sc}")
        r = RD.receiving_layer(g_snap, G)
        pk = g_snap.nodes[r].pkey
        kw, kb_ = f"mods.{pk}.weight", f"mods.{pk}.bias"
        touched |= {kw, kb_}
        Mfull, m = E.affine_map(g_snap, g_snap.implants[G].entry, g_snap.implants[G].exit, g_snap.region(G))
        Mfull, m = Mfull.double().cpu(), m.double().cpu()
        eye = torch.eye(Mfull.shape[0], dtype=torch.float64)
        K = eye + sc * (Mfull - eye)
        W, b = ss[kw].double(), ss[kb_].double()
        Wn = torch.linalg.solve(K.T, (W @ Mfull).T).T
        bn = b + W @ m - sc * (Wn @ m)
        res_ = float((Wn @ K - W @ Mfull).abs().max()) / max(1.0, float((W @ Mfull).abs().max()))
        if not all(bool(torch.isfinite(x_).all()) for x_ in (Mfull, m, Wn, bn)) or not math.isfinite(res_) or \
                res_ > 1e-8:
            why.append(f"the merge map, the solve or its residual is not finite or exact (residual {res_})")
        dW = float((sr[kw].double() - Wn).abs().max()) / max(1.0, float(Wn.abs().max()))
        db = float((sr[kb_].double() - bn).abs().max()) / max(1.0, float(bn.abs().max()))
        if not (within(dW, COMPOSE_TOL) and within(db, COMPOSE_TOL)):
            why.append(f"the receiving layer is not W (I + M) (I + s M)^-1, b + W m - s W' m (relative {dW:.3g}, "
                       f"{db:.3g})")
        sv = torch.linalg.svdvals(K)
        O["redistribution_cond"] = float(sv.max() / sv.min().clamp_min(1e-300))
        O["redistribution_solve_residual"] = res_
        det = f"branch outputs times {sc} exactly; receiving layer within {max(dW, db):.2g}"
    for k_ in ss:
        if k_ not in touched and not torch.equal(sr[k_], ss[k_]):
            why.append(f"{k_} changed")
    st64 = as64(g_snap)
    ed64 = as64(g_snap)
    RD.redistribute(ed64, method)
    alg = func_compare(ed64, st64, parts, names, batch)
    sto = func_compare(as64(g_rs), st64, parts, names, batch)
    fwd = func_compare(g_rs, g_snap, parts, names, batch)
    if not within(alg["rel"], ALGEBRA_TOL):
        why.append(f"the edit rebuilt in float64 changes the function by {alg['rel']:.3g}")
    dev_c = None
    if rec is not None:
        rdev, rparts, snap_model = rec
        dev_c = func_compare(GraphNet.from_checkpoint(cks["model"], rdev).eval(),
                             GraphNet.from_checkpoint(snap_model, rdev).eval(), rparts, names, batch)
    # v68: the deployed computation must be finite (here in float32 and on the training device); a finite
    # discrepancy is a reported measurement, not a certificate
    if not fwd["finite"]:
        why.append("the saved start is not finite in float32 on the analysis device")
    if dev_c is not None and not dev_c["finite"]:
        why.append("the saved start is not finite in float32 on the training device")
    sto_ok = within(sto["rel"], STORAGE_TOL)
    O.update({"redistribution_algebra64": alg["rel"], "redistribution_storage64": sto["rel"],
              "redistribution_storage64_kl": sto["kl"], "redistribution_storage64_flip": sto["flip"],
              "redistribution_forward32": fwd["rel"], "redistribution_forward32_centred": fwd["centred"],
              "redistribution_forward32_kl": fwd["kl"], "redistribution_forward32_flip": fwd["flip"],
              "redistribution_forward32_flip_margin": fwd["margin"],
              "redistribution_recorded_device_forward32": dev_c["rel"] if dev_c else None,
              "redistribution_recorded_device_kl": dev_c["kl"] if dev_c else None,
              "redistribution_recorded_device_flip": dev_c["flip"] if dev_c else None,
              "redistribution_run_val_change32": rd.get("val_relative_logit_change"),
              "redistribution_run_val_flip_rate": rd.get("val_flip_rate")})
    sdet = (f"storage (saved start in float64 vs snapshot in float64) {sto['rel']:.3g} (KL {sto['kl']:.3g}, flips "
            f"{sto['flip']:.3g}); {'within' if sto_ok else 'ABOVE'} {STORAGE_TOL:g}")
    return (not why, ("; ".join(why) if why else f"{integrity[1]}; {det}; algebra {alg['rel']:.2g}; float32 "
                                                  f"{fwd['rel']:.2g} (flips {fwd['flip']:.2g})"),
            sto_ok, sdet, O)


def fork_jobs(mcfg: dict) -> dict:
    """-> {f0: {parent arm: {"traj": id, "forks": {fork stage: {continuation: id}}}}} of the wave-28 design."""
    out = defaultdict(lambda: defaultdict(lambda: {"traj": None, "forks": defaultdict(dict)}))
    for rid, c in mcfg.items():
        d = c.get("design") or {}
        if c.get("kind") != "dissipation" or d.get("family") != "X28":
            continue
        tid = (c.get("parents") or {}).get("trajectory")
        if tid not in mcfg:
            raise Fail(f"{rid}: its trajectory is not in the manifest")
        parent, _, stage = str(d.get("variant")).partition("@")
        if stage != (c.get("tags") or {}).get("parent_stage") or d.get("arm") not in (*CONTS, *MECH) or \
                (d.get("arm") in MECH and (c.get("dissipation") or {}).get("method") != MECH[d["arm"]]):
            raise Fail(f"{rid}: design {d.get('variant')}/{d.get('arm')} does not match its fork point")
        bid = (mcfg[tid].get("parents") or {}).get("baseline")
        slot = out[bid][parent]
        if slot["traj"] not in (None, tid):
            raise Fail(f"f0 {bid}: two trajectories for {parent}")
        slot["traj"] = tid
        if d["arm"] in slot["forks"][stage]:
            raise Fail(f"f0 {bid}: two {d['arm']} forks of {parent} at {stage}")
        slot["forks"][stage][d["arm"]] = rid
    return {b: {p: {"traj": s["traj"], "forks": dict(s["forks"])} for p, s in v.items()} for b, v in out.items()}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("results")
    ap.add_argument("out")
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--strict", action="store_true", help="exit 1 unless every f0 is analysed and every probe fitted")
    ap.add_argument("--eval-batch", type=int, default=None,
                    help="v66: evaluation batch size for this analysis (recorded; default: each job's eval_batch)")
    ap.add_argument("--recorded-device", default=None,
                    help="v61: also evaluate each saved fold against its snapshot in float32 on this device (the "
                         "device the runs were trained on, e.g. cuda); reported, not a check")
    a = ap.parse_args(argv)
    dev = torch.device(a.device)
    if dev.type == "cuda" and not torch.cuda.is_available():
        print("--device cuda requested but CUDA is not available", file=sys.stderr)
        return 2
    rec_dev = torch.device(a.recorded_device) if a.recorded_device else None
    if rec_dev is not None and rec_dev.type == "cuda" and not torch.cuda.is_available():
        print("--recorded-device cuda requested but CUDA is not available", file=sys.stderr)
        return 2
    rec_bundles = {}
    runs = Path(a.results) / "runs"
    mcfg = {e["run_id"]: e["cfg"] for e in AC.manifest_entries(a.manifest)}
    cov = {"tool": "fork_continuation", "analysis_schema": ANALYSIS_SCHEMA, "status": STATUS,
           "results": str(Path(a.results).resolve()), "manifest": a.manifest,
           "manifest_sha256": CE.sha256_file(a.manifest),
           "source_sha256": {p.name: CE.sha256_file(p) for p in (Path(__file__), Path(MG.__file__), Path(CC.__file__),
                                                                 Path(FP.__file__), Path(SR.__file__))},
           "numerics": {**CE.numerics_policy(dev), "probes": "float64 Newton with line search, zero start"},
           "definitions": {"continuations": list(CONTS), "with_additions": list(WITH_ADDITIONS),
                           "named_contrasts": {n_: {"first": a_, "second": b_, "tests": t_} for n_, a_, b_, t_ in NAMED},
                           "trajectory_end": "a reference, not an exact replay control (own optimizer state and "
                                             "sampler; from snap_1000 also the second insertion at U)",
                           "scope": "every contrast holds for these checkpoints, budgets and optimizer settings",
                           "audit_checks": list(AUDIT_CHECKS), "fold_float32_rule_v60_tol": FOLD_TOL,
                           "fold_kl_tol": FOLD_KL_TOL, "fold_algebra_tol": ALGEBRA_TOL,
                           "fold_storage_tol": STORAGE_TOL,
                           "fold_function_rule": "v61: decisive in float64 (algebra and storage), float32 forward "
                                                 "differences reported (they are the rounding of the evaluation)",
                           "compose_tol": COMPOSE_TOL, "outcomes": ["additions_moved"],
                           "interpretation": "folding moves the additions' computation into the receiving layer by algebra: a "
                                             "successful folded continuation does not by itself show that the "
                                             "original backbone learned to replace the additions",
                           "normalised": list(NORMALISED), "parts": list(PARTS),
                           "native_features": NATIVE_FEATURES, "fit": MG.FIT, "preps": list(MG.PREPS),
                           "lambdas": list(MG.LAMBDAS), "target": "label"},
           "expected_f0": 0, "analysed_f0": 0, "failed": [], "probe_not_converged": []}
    out = defaultdict(list)
    want = {}
    try:
        jobs = fork_jobs(mcfg)
        shapes = {(p, s, tuple(sorted(c))) for v in jobs.values() for p, j in v.items() for s, c in j["forks"].items()}
        parents = sorted({p for p, _, _ in shapes})
        forks = sorted({s for _, s, _ in shapes})
        conts = tuple(CONTS) + (tuple(MECH) if any(set(c_) & set(MECH) for _, _, c_ in shapes) else ())
        if not jobs or shapes != {(p, s, tuple(sorted(conts))) for p in parents for s in forks} or \
                any(set(v) != set(parents) for v in jobs.values()):
            raise Fail("the manifest is not a complete wave-28 design (every f0: every parent, fork and continuation)")
    except Fail as ex_:
        cov["failed"].append({"f0": None, "reason": str(ex_)})
        print(f"FAIL: {ex_}", file=sys.stderr)
        jobs, parents, forks, conts = {}, [], [], tuple(CONTS)
    cov["expected_f0"] = len(jobs)
    cov["design"] = {"parents": parents, "forks": forks, "continuations": list(conts)}
    if set(conts) & set(MECH):
        cov["definitions"]["mechanism"] = {
            "continuations": dict(MECH), "named": {n_: {"first": a_, "second": b_, "tests": t_}
                                                   for n_, a_, b_, t_ in NAMED_MECH},
            "interactions": {n_: f"({a_} - routed_reset) - ({b_} - ordinary_reset)" for n_, a_, b_ in INTERACTIONS},
            "redistribution_check": "the saved start (event_after_redistribute) is the snapshot with the declared "
                                    "edit: swap, every addition tensor exchanged exactly with its partner and "
                                    "nothing else changed; shift, every branch's last layer the snapshot's times s "
                                    "(exactly) and the receiving layer W (I + M) (I + s M)^-1, b + W m - s W' m for "
                                    "the snapshot's exact float64 merge map within COMPOSE_TOL, nothing else "
                                    "changed; the edit rebuilt in float64 from the snapshot computes the snapshot's "
                                    "function within ALGEBRA_TOL.  The saved float32 start evaluated in float64 "
                                    "(storage) and the run's own float32 change are reported; a storage change "
                                    "above STORAGE_TOL fails the fork's audit (v66; v65 flagged the draw)",
            "v66_check": "the saved start must also pass check_ckpt (recomputed tensor hash, finite, run, stage, "
                         "configuration, data) and the storage certificate (saved float32 start evaluated in float64 "
                         "against the snapshot within STORAGE_TOL): a failure fails the fork's "
                         "audit (redistribution_storage), it no longer only flags the draw; the float32 forward "
                         "on the analysis device and (with --recorded-device) on the training device are reported "
                         "separately (deployed behaviour, rounding of the evaluation)",
            "interpretation": {
                "swap": "the tensors are exchanged exactly; the logits can differ by floating-point summation order "
                        "(redistribution_forward32)",
                "shift100": "map moved into the receiver; zeroed trainable additions retained (they can grow back "
                            "from the first update); not a removal: folded_reset is the compact continuation",
                "interaction": "tests whether routing changes the effect of a forward-equivalent reallocation of "
                               "computation on learning; the edit also changes the parameters the optimizer trains, "
                               "so it does not by itself identify one gradient pathway into the backbone"}}
    bundles = {}
    for n_done, bid in enumerate(sorted(jobs), 1):
        staged = defaultdict(list)
        try:
            J = jobs[bid]
            cfgs = {}
            for p_, j in J.items():
                cfgs[j["traj"]] = AC.job_config(runs, j["traj"], mcfg[j["traj"]])
                for s_, cs in j["forks"].items():
                    for c_, rid in cs.items():
                        why = AC.declared_invalid(runs / rid, mcfg[rid])
                        if why:
                            raise Fail(f"{rid}: declared invalid ({why})")
                        cfgs[rid] = AC.job_config(runs, rid, mcfg[rid])
            dkeys = {json.dumps(c["data"], sort_keys=True) for c in cfgs.values()}
            if len(dkeys) != 1:
                raise Fail(f"f0 {bid}: its jobs differ in data")
            dk = dkeys.pop()
            if dk not in bundles:
                b0 = SR.load_bundle(json.loads(dk), a.data_root, device="cpu")
                bundles[dk] = (b0.to(dev), b0.hashes())
            b, hashes = bundles[dk]
            parts = b.partitions()
            if b.task != "classification" or int(b.out_dim) != 2 or "val_indep" not in parts:
                raise Fail(f"f0 {bid}: needs a two-class task with a val_indep partition")
            ps = AC.eval_partitions(b)
            need = {"train", *ps}
            any_t = cfgs[J[parents[0]]["traj"]]
            batch = int(a.eval_batch or (any_t.get("train") or {}).get("eval_batch", 4096))
            # ---- f0: the trajectories' reference copies must be one network, a plain ReLU chain
            f0k, ids, ref = None, set(), {}
            for p_, j in sorted(J.items()):
                tid = j["traj"]
                AC.check_logged_data(runs / tid, hashes, need, f"{tid} data provenance")
                k = SR.ckp(runs / tid, "baseline_ref")
                gk = AC.check_ckpt(k, f"{p_} f0", run_id=tid, stage="baseline_ref", cfg=cfgs[tid], hashes=hashes,
                                   need=need)
                ids.add((AC.param_hash_of(k), gk.structural_hash()))
                ref[p_] = k
                f0k = f0k or k
            if len(ids) != 1:
                raise Fail(f"f0 {bid}: the trajectories do not start from one network")
            f0 = GraphNet.from_checkpoint(f0k["model"], dev).eval()
            f0_sd = {k: t.clone() for k, t in f0.state_dict().items()}
            L = SR.backbone_layers(f0)
            wk = [next(k for k in f0_sd if k.startswith(f"mods.{Lk}.") and f0_sd[k].dim() == 2) for Lk in L]
            bk = [next(k for k in f0_sd if k.startswith(f"mods.{Lk}.") and f0_sd[k].dim() == 1) for Lk in L]
            if any(len([k for k in f0_sd if k.startswith(f"mods.{Lk}.")]) != 2 for Lk in L) or len(L) < 3:
                raise Fail(f"f0 {bid}: a backbone layer is not one weight matrix with a bias")
            W0, b0 = f0_sd[wk[0]], f0_sd[bk[0]]
            blk = CC.blocks_of((b.meta or {}).get("feature_layout") or {}, int(W0.shape[1]))
            if blk is None:
                raise Fail(f"f0 {bid}: needs the generator's unrotated feature layout")
            sc = int(blk["shortcut"][0])
            _, zt = CE.mlp_forward(f0_sd, parts["test"].X["x"].to(dev), wk, bk)
            _, rf = FP.node_values(f0, parts["test"], [], batch)
            if float((zt - rf).abs().max()) > FP.CHAIN_TOL * max(1.0, float(rf.abs().max())):
                raise Fail(f"f0 {bid}: the network is not a plain ReLU chain of its layers")
            contrast = ((cfgs[next(iter(J[parents[0]]["forks"][forks[0]].values()))].get("design") or {})
                        .get("contrast") or "")
            bcfg = AC.job_config(runs, bid, mcfg.get(bid))
            meta = {"f0": bid, "design_id": CC.design_id(bcfg, contrast, {p_: {} for p_ in parents},
                                                         {s_: {} for s_ in forks}),
                    "f0_param_hash": next(iter(ids))[0], "data_draw": (bcfg.get("data") or {}).get("data_seed"),
                    "optimizer_seed": (bcfg.get("seeds") or {}).get("optimizer")}
            pp = [p for p in ("train", MG.FIT, *MG.EVAL) if p in parts]
            y = {p: parts[p].y.to(dev).long() for p in pp}
            xs = {p: parts[p].X["x"].to(dev) for p in pp}

            def build(W, bias):
                m_ = GraphNet.from_checkpoint(f0k["model"], dev).eval()
                want_ = dict(m_.state_dict())
                want_[wk[0]] = W.to(want_[wk[0]].device, want_[wk[0]].dtype)
                want_[bk[0]] = bias.to(want_[bk[0]].device, want_[bk[0]].dtype)
                m_.load_state_dict(want_)
                m_._plan = None
                CE.verify_patch(m_.state_dict(), want_, "fork continuation: compact build")
                return m_

            def errs(m, prefix):
                o, pr = AC.finite_eval(m, b, [p for p in PARTS if p in parts] + ["train"], batch, "fork continuation")
                ytr = parts["train"].y.to(dev).long()
                r = {f"{prefix}_{p}_err": o[f"{p}_err"] for p in PARTS if f"{p}_err" in o}
                r[f"{prefix}_train_loss"] = float(torch.nn.functional.cross_entropy(pr["train"].double(), ytr))
                return r

            def probes(row, name, F):
                for prep in MG.PREPS:
                    Z, _, dims = MG.preprocess(F, prep)
                    for lam in MG.LAMBDAS:
                        what = f"{row['state']} {name} {prep} lam={lam:g}"
                        _, _, r = MG.fit_probe(Z, y, lam, what)
                        if not r["converged"]:
                            cov["probe_not_converged"].append({"f0": bid, "what": what, "grad_inf": r["grad_inf"]})
                        for p in MG.EVAL:
                            row[f"probe|{name}|{prep}|lam={lam:g}|{p}_err"] = r[f"{p}_err"]

            def measure(parent, fork, state, g):
                sd = g.state_dict()
                if sd[wk[0]].shape != W0.shape or sd[bk[0]].shape != b0.shape:
                    raise Fail(f"{parent} {fork} {state}: its first layer does not have f0's shape")
                W, bias = sd[wk[0]].clone(), sd[bk[0]].clone()
                row = {**meta, "parent": parent, "fork": fork, "state": state, **errs(g, "native"),
                       **errs(build(W, bias), "extraction"), **CC.layer_summary(W, W0, bias, b0, blk)}
                ed = CC.edit_layers(W, bias, W0, b0, blk)
                elig = {}
                for e_ in NORMALISED:
                    We, be, info = ed[e_]
                    er = errs(build(We, be), e_)
                    # v66: a normalised layer is a measurement only when every target norm was attained; otherwise
                    # the row is kept with its errors withheld and the reason
                    nc = norm_attainment(e_, We, W0, W, blk)
                    ok_ = info["unmatched"] == 0 and nc["failed_rows"] == 0 and math.isfinite(nc["max_abs"])
                    row.update(er if ok_ else {k_: None for k_ in er})
                    row[f"{e_}_unmatched"] = info["unmatched"]
                    row[f"{e_}_norm_miss"] = nc["max_rel"]
                    row[f"{e_}_norm_max_abs"] = nc["max_abs"]
                    row[f"{e_}_norm_failed_rows"] = nc["failed_rows"]
                    row[f"{e_}_eligible"] = ok_
                    elig[e_] = ok_
                # probes: the first layer (in f0), the normalised first layer (in f0), the network's own layers
                tens = {**f0_sd, wk[0]: W, bk[0]: bias}
                We, be, _ = ed[NORMALISED[0]]
                tn = {**f0_sd, wk[0]: We, bk[0]: be}
                F1 = {p: CE.mlp_forward(tens, xs[p], wk, bk)[0][0] for p in pp if p != "train"}
                Fn = {p: CE.mlp_forward(tn, xs[p], wk, bk)[0][0] for p in pp if p != "train"}
                probes(row, "layer1", F1)
                if elig[NORMALISED[0]]:          # v68: no normalised-layer probe from an ineligible layer
                    probes(row, f"layer1_{NORMALISED[0]}", Fn)
                sites = FP.layer_sites(g, L)
                vals = {p: FP.node_values(g, parts[p], sorted(set(sites.values())), batch)[0] for p in pp
                        if p != "train"}
                d1 = float((vals["test"][sites["layer1"]] - F1["test"]).abs().max())
                if d1 > FP.CHAIN_TOL * max(1.0, float(F1["test"].abs().max())):
                    raise Fail(f"{parent} {fork} {state}: its first layer's activations differ between computations")
                for feat in [f for f in sites if f != "layer1"]:
                    probes(row, f"native_{feat}", {p: vals[p][sites[feat]] for p in vals})
                n_merge = sum(1 for f in sites if f.endswith("_post_merge"))
                if n_merge > 1:
                    raise Fail(f"{parent} {fork} {state}: {n_merge} merge sites; this panel has one cut")
                row["has_additions"] = n_merge == 1
                staged["states"].append(row)
                return row

            n_states = 0
            measure("f0", "f0", "f0", f0)
            n_states += 1
            for parent in parents:
                tid = J[parent]["traj"]
                tcfg = cfgs[tid]
                u2 = int(tcfg["growth"]["updates_per_round"]) * int(tcfg["growth"]["rounds"])
                end = SR.ckp(runs / tid, "final")
                AC.check_ckpt(end, f"{parent} end", run_id=tid, stage="final", cfg=tcfg, hashes=hashes, need=need)
                CE.check_age(AC.job_update(end, ref[parent], f"{parent} end"), u2, tid)
                held = (tcfg.get("train") or {}).get("freeze_inputs") == "shortcut"
                for fork in forks:
                    u = int(fork.split("_")[1])
                    st = SR.ckp(runs / tid, fork)
                    if st is None:
                        raise Fail(f"{tid}: no saved state {fork}")
                    AC.check_ckpt(st, f"{parent} {fork}", run_id=tid, stage=fork, cfg=tcfg, hashes=hashes,
                                  need=need)
                    CE.check_age(AC.job_update(st, ref[parent], f"{parent} {fork}"), u, tid)
                    g_st = GraphNet.from_checkpoint(st["model"], dev).eval()
                    measure(parent, fork, "start", g_st)
                    measure(parent, fork, "trajectory_end", GraphNet.from_checkpoint(end["model"], dev).eval())
                    n_states += 2
                    snap_h = snapshot_hash(st)
                    streams = {}
                    for cn in conts:
                        rid = J[parent]["forks"][fork][cn]
                        rd = runs / rid
                        ep = json.loads((rd / "endpoint.json").read_text()) if (rd / "endpoint.json").exists() else None
                        if ep is None or ep.get("diverged") or ep.get("numerically_valid") is False:
                            raise Fail(f"{rid}: endpoint missing, diverged or recorded numerically invalid")
                        if int(ep["updates"]) != u2 - u:
                            raise Fail(f"{rid}: {ep['updates']} updates, expected {u2 - u}")
                        AC.check_logged_data(rd, hashes, need, f"{rid} data provenance")
                        ck = SR.ckp(rd, ep["checkpoint"])
                        AC.check_ckpt(ck, f"{parent} {fork} {cn}", run_id=rid, stage=ep["checkpoint"], cfg=cfgs[rid],
                                      hashes=hashes, need=need)
                        if AC.param_hash_of(ck) != ep["checkpoint_param_hash"]:
                            raise Fail(f"{rid}: the end checkpoint is not the one endpoint.json names")
                        g = GraphNet.from_checkpoint(ck["model"], dev).eval()
                        if cn == "folded_reset":
                            g_raw, g = g, in_f0_layout(g, f0k, wk, bk, dev)
                            for p_ in [p for p in PARTS if p in parts] + ["train"]:
                                _, z0 = FP.node_values(g_raw, parts[p_], [], batch)
                                _, z1 = FP.node_values(g, parts[p_], [], batch)
                                if not torch.equal(z0, z1):
                                    raise Fail(f"{rid}: the folded network in f0's layout computes another function")
                        row = measure(parent, fork, cn, g)
                        if row["has_additions"] != (cn in WITH_ADDITIONS):
                            raise Fail(f"{rid}: {cn} {'without' if cn in WITH_ADDITIONS else 'with'} additions")
                        n_states += 1
                        # ---- the fork's audit (v59)
                        res = json.loads((rd / "dissipation_result.json").read_text())
                        s1 = {k: t.cpu() for k, t in ck["model"]["state"].items()}
                        aud, outcome = audit_fork(cn, res, ep, u2 - u, snap_h, g_st, st, s1, wk[0], sc, held,
                                                  tcfg["train"])
                        if cn == "folded_reset":
                            cks = SR.ckp(rd, "event_after_fold")
                            if cks is None:
                                aud["fold_start"] = (False, "no saved after-fold checkpoint (event_after_fold)")
                                g_fs = None
                            else:
                                integ = event_integrity(cks, f"{rid} event_after_fold", rid, "event_after_fold",
                                                        cfgs[rid], hashes, need)
                                g_fs_raw = GraphNet.from_checkpoint(cks["model"], dev).eval()
                                g_fs = in_f0_layout(g_fs_raw, f0k, wk, bk, dev)
                                n_opt = [((p.get("optimizer_audit") or {}).get("after_first_update") or {})
                                         for p in (res.get("schedule_audit") or {}).get("phases") or []]
                                fa_ = fold_start_audit(
                                    res, ep, cks, g_fs, g_st, L, wk, bk,
                                    [(f_.get("tensors"), f_.get("tensors_with_state")) for f_ in n_opt])
                                aud["fold_start"] = (integ[0] and fa_[0], f"{integ[1]}; {fa_[1]}")
                            pa = next((x for x in res.get("path") or [] if x.get("tag") == "after_fold"), None)
                            rr = (res.get("recovery_reference") or {}).get("receiver_val_out_rms")
                            drift = (float(pa["val_rms_drift_from_receiver"]) / max(float(rr), 1e-12)
                                     if pa is not None and rr else None)
                            kl = float(pa["val_kl_receiver_to_model"]) if pa is not None else None
                            names = [p for p in PARTS if p in parts] + ["train"]
                            # v61: algebra and rounding apart.  algebra: the fold rebuilt in float64 against the
                            # snapshot in float64; storage: the saved float32 fold evaluated in float64; forward:
                            # both in float32 (v60's measure), here and on the recorded device
                            st64 = as64(g_st)
                            alg = rel_logit_change(refold(st64).eval(), st64, parts, names, batch)
                            sto = rel_logit_change(as64(g_fs), st64, parts, names, batch) if g_fs is not None else None
                            fwd = rel_logit_change(g_fs, g_st, parts, names, batch) if g_fs is not None else None
                            r32 = rel_logit_change(refold(g_st).eval(), g_st, parts, names, batch)
                            dev_r = None
                            if rec_dev is not None and g_fs is not None:
                                if dk not in rec_bundles:
                                    rec_bundles[dk] = SR.load_bundle(json.loads(dk), a.data_root,
                                                                     device="cpu").to(rec_dev).partitions()
                                dev_r = rel_logit_change(GraphNet.from_checkpoint(cks["model"], rec_dev).eval(),
                                                         GraphNet.from_checkpoint(st["model"], rec_dev).eval(),
                                                         rec_bundles[dk], names, batch)
                            ok = within(kl, FOLD_KL_TOL) and within(alg, ALGEBRA_TOL) and within(sto, STORAGE_TOL) \
                                and (fwd is None or math.isfinite(fwd)) and (dev_r is None or math.isfinite(dev_r))
                            v60 = drift is not None and kl is not None and drift <= FOLD_TOL and kl <= FOLD_KL_TOL \
                                and r32 <= FOLD_TOL and fwd is not None and fwd <= FOLD_TOL
                            aud["fold_function"] = (ok, f"algebra (float64 refold vs float64 snapshot) {alg:.3g}; "
                                                        f"storage (saved fold in float64) {sto}; float32 forward "
                                                        f"(saved fold vs snapshot) {fwd}; on {rec_dev} {dev_r}; "
                                                        f"run: KL {kl}, relative drift {drift}, flips "
                                                        f"{pa.get('val_flip_rate_from_receiver') if pa else None}")
                            outcome.update({"fold_algebra64": alg, "fold_storage64": sto, "fold_forward32": fwd,
                                            "fold_refold32": r32, "fold_recorded_device_forward32": dev_r,
                                            "fold_recorded_device": str(rec_dev) if rec_dev is not None else None,
                                            "fold_run_drift32": drift, "fold_run_kl": kl,
                                            "fold_float32_rule_v60_passed": v60})
                        if cn in MECH:
                            names_ = [p for p in PARTS if p in parts] + ["train"]
                            cks_r = SR.ckp(rd, "event_after_redistribute")
                            integ = event_integrity(cks_r, f"{rid} event_after_redistribute", rid,
                                                    "event_after_redistribute", cfgs[rid], hashes, need) \
                                if cks_r is not None else (False, "no saved start")
                            rec_ = None
                            if rec_dev is not None:
                                if dk not in rec_bundles:
                                    rec_bundles[dk] = SR.load_bundle(json.loads(dk), a.data_root,
                                                                     device="cpu").to(rec_dev).partitions()
                                rec_ = (rec_dev, rec_bundles[dk], st["model"])
                            ok_, det_, sok_, sdet_, o_ = redistribution_audit(
                                cn, res, cks_r, g_st, parts, names_, batch, integrity=integ, rec=rec_)
                            aud["redistribution"] = (ok_, det_)
                            aud["redistribution_storage"] = (sok_, sdet_)
                            outcome.update(o_)
                            outcome["redistribution_recorded_device"] = str(rec_dev) if rec_dev is not None else None
                        streams[cn] = (res.get("schedule_audit") or {}).get("batch_id_hash")
                        # training MACs since f0: the trajectory's counter is cumulative from f0's (it loads
                        # f0's trainer state), a continuation's counter starts at zero
                        own = int(((res.get("compute_end") or {}).get("train_macs")) or 0)
                        before = _macs(st) - _macs(ref[parent])
                        if before <= 0 or own <= 0:
                            raise Fail(f"{rid}: training MACs not recorded (to fork {before}, fork {own})")
                        staged["compute"].append({**meta, "parent": parent, "fork": fork, "state": cn,
                                                  "run_id": rid, "updates_since_f0": u2,
                                                  "train_macs_to_fork": before, "train_macs_fork": own,
                                                  "train_macs_total": before + own})
                        arow = {**meta, "parent": parent, "fork": fork, "state": cn, "run_id": rid}
                        for k_, (ok_, det_) in aud.items():
                            arow[k_], arow[f"{k_}_detail"] = bool(ok_), det_
                        arow.update({f"outcome_{k_}": v_ for k_, v_ in outcome.items()})
                        staged["audits"].append(arow)
                    shared = len(set(streams.values())) == 1 and None not in streams.values()
                    for arow in staged["audits"][-len(conts):]:
                        arow["stream_shared"] = shared
                        arow["stream_shared_detail"] = f"{len(set(streams.values()))} batch-id hashes over the forks"
                        arow["audit_passed"] = all(arow[k_] for k_ in AUDIT_CHECKS)
            # ---- v63: the compact controls of this f0 (f0 continued with the parent's hold), when the manifest has
            # them: at 2U (update-matched to the forks' ends) and at the control's end (4U), measured exactly as
            # every other state
            comps = {r_: c_ for r_, c_ in mcfg.items() if c_.get("kind") == "continue"
                     and (c_.get("design") or {}).get("family") == "X25" and (c_.get("design") or {}).get("arm") == "C1"
                     and (c_.get("parents") or {}).get("baseline") == bid}
            if comps:
                for parent in parents:
                    tcfg = cfgs[J[parent]["traj"]]
                    hold = (tcfg.get("train") or {}).get("freeze_inputs", "none")
                    m_ = [r_ for r_, c_ in comps.items() if (c_.get("train") or {}).get("freeze_inputs", "none") == hold
                          and float(c_["train"]["lr"]) == float(tcfg["train"]["lr"])]
                    if len(m_) != 1:
                        raise Fail(f"f0 {bid}: {len(m_)} compact controls with {parent}'s hold and learning rate")
                    rid = m_[0]
                    ccfg = AC.job_config(runs, rid, mcfg[rid])
                    AC.check_logged_data(runs / rid, hashes, need, f"{rid} data provenance")
                    stg = (ccfg.get("continue") or {}).get("start_stage", "best_val")
                    kst = SR.ckp(runs / bid, stg)
                    if kst is None or AC.param_hash_of(kst) != meta["f0_param_hash"]:
                        raise Fail(f"{rid}: the compact control does not start from this f0")
                    u2c = int(tcfg["growth"]["updates_per_round"]) * int(tcfg["growth"]["rounds"])
                    ulong = int(sum((ccfg.get("continue") or {}).get("segments") or [0]))
                    for lab, uu in (("compact_2U", u2c), ("compact_4U", ulong)):
                        ck = SR.ckp(runs / rid, f"at_{uu}")
                        if ck is None:
                            raise Fail(f"{rid}: no saved state at update {uu} (at_{uu})")
                        AC.check_ckpt(ck, f"{parent} {lab}", run_id=rid, stage=f"at_{uu}", cfg=ccfg, hashes=hashes,
                                      need=need)
                        if int((ck.get("extra") or {}).get("update", -1)) != uu:
                            raise Fail(f"{rid}: at_{uu} records update {(ck.get('extra') or {}).get('update')}")
                        measure(parent, "compact", lab, GraphNet.from_checkpoint(ck["model"], dev).eval())
                        n_states += 1
                        # an at_<u> checkpoint keeps the counters (from the continuation's start) in extra
                        cmc = int(((ck.get("extra") or {}).get("compute") or {}).get("train_macs", 0))
                        if cmc <= 0:
                            raise Fail(f"{rid}: at_{uu} records no training MACs")
                        staged["compute"].append({**meta, "parent": parent, "fork": "compact", "state": lab,
                                                  "run_id": rid, "updates_since_f0": uu, "train_macs_to_fork": 0,
                                                  "train_macs_fork": cmc, "train_macs_total": cmc})
                cmac = {(r_["parent"], r_["state"]): r_["train_macs_total"] for r_ in staged["compute"]
                        if r_["fork"] == "compact"}
                for r_ in staged["compute"]:
                    if r_["fork"] != "compact":
                        for lab in ("compact_2U", "compact_4U"):
                            cm = cmac.get((r_["parent"], lab))
                            r_[f"{lab}_train_macs"] = cm
                            r_[f"fork_over_{lab}_macs"] = (r_["train_macs_total"] / cm) if cm else None
            # ---- v66: the reset-matched compact controls (wave 32): f0 continued with the parent's hold to the fork
            # point carrying f0's optimizer state, reset there (as the forks are) and continued to 2U
            compsr = {r_: c_ for r_, c_ in mcfg.items() if c_.get("kind") == "continue"
                      and (c_.get("design") or {}).get("family") == "X25"
                      and (c_.get("design") or {}).get("arm") == "C1R"
                      and (c_.get("parents") or {}).get("baseline") == bid}
            if compsr:
                for parent in parents:
                    tcfg = cfgs[J[parent]["traj"]]
                    hold = (tcfg.get("train") or {}).get("freeze_inputs", "none")
                    u2c = int(tcfg["growth"]["updates_per_round"]) * int(tcfg["growth"]["rounds"])
                    for fork in forks:
                        u = int(fork.split("_")[1])
                        m_ = [r_ for r_, c_ in compsr.items()
                              if (c_.get("train") or {}).get("freeze_inputs", "none") == hold
                              and float(c_["train"]["lr"]) == float(tcfg["train"]["lr"])
                              and str((c_.get("design") or {}).get("variant", "")).endswith(f"@{fork}")]
                        if len(m_) != 1:
                            raise Fail(f"f0 {bid}: {len(m_)} reset-matched compact controls for {parent} at {fork}")
                        rid = m_[0]
                        ccfg = AC.job_config(runs, rid, mcfg[rid])
                        cc_ = ccfg.get("continue") or {}
                        if [int(x) for x in cc_.get("segments") or []] != [u, u2c - u] or \
                                list(cc_.get("segment_reset") or []) != [False, True]:
                            raise Fail(f"{rid}: segments {cc_.get('segments')} / resets {cc_.get('segment_reset')}, "
                                       f"expected [{u}, {u2c - u}] / [False, True]")
                        AC.check_logged_data(runs / rid, hashes, need, f"{rid} data provenance")
                        kst = SR.ckp(runs / bid, cc_.get("start_stage", "best_val"))
                        if kst is None or AC.param_hash_of(kst) != meta["f0_param_hash"]:
                            raise Fail(f"{rid}: the reset-matched compact control does not start from this f0")
                        cres = json.loads((runs / rid / "continue_result.json").read_text())
                        starts = (cres.get("fork_audit") or {}).get("starts") or []
                        if [(int(x.get("segment", -1)), bool(x.get("reset_applied"))) for x in starts] != \
                                [(0, False), (1, True)] or int(starts[1].get("update", -1)) != u:
                            raise Fail(f"{rid}: the optimizer was not carried to update {u} and reset there "
                                       f"({[(x.get('segment'), x.get('update'), x.get('reset_applied')) for x in starts]})")
                        ck = SR.ckp(runs / rid, f"at_{u2c}")
                        if ck is None:
                            raise Fail(f"{rid}: no saved state at update {u2c} (at_{u2c})")
                        AC.check_ckpt(ck, f"{parent} {fork} compact_reset", run_id=rid, stage=f"at_{u2c}", cfg=ccfg,
                                      hashes=hashes, need=need)
                        if int((ck.get("extra") or {}).get("update", -1)) != u2c:
                            raise Fail(f"{rid}: at_{u2c} records update {(ck.get('extra') or {}).get('update')}")
                        measure(parent, fork, "compact_reset", GraphNet.from_checkpoint(ck["model"], dev).eval())
                        n_states += 1
                        cmc = int(((ck.get("extra") or {}).get("compute") or {}).get("train_macs", 0))
                        if cmc <= 0:
                            raise Fail(f"{rid}: at_{u2c} records no training MACs")
                        staged["compute"].append({**meta, "parent": parent, "fork": fork, "state": "compact_reset",
                                                  "run_id": rid, "updates_since_f0": u2c, "train_macs_to_fork": 0,
                                                  "train_macs_fork": cmc, "train_macs_total": cmc})
            want[bid] = n_states
            # ---- contrasts
            rows = {(r["parent"], r["fork"], r["state"]): r for r in staged["states"]}
            f0row = rows[("f0", "f0", "f0")]
            skip = set(meta) | {"parent", "fork", "state", "has_additions"}
            metrics = sorted({k for r in staged["states"] for k, v in r.items() if k not in skip
                              and isinstance(v, (int, float)) and not isinstance(v, bool)})

            def con(comparison, r1, r2):
                for m_ in metrics:
                    x1, x2 = r1.get(m_), r2.get(m_)
                    if x1 is None or x2 is None:
                        continue
                    staged["contrasts"].append({**meta, "parent": r1["parent"], "fork": r1["fork"],
                                                "comparison": comparison, "first": r1["state"],
                                                "second": r2["state"], "metric": m_, "first_value": x1,
                                                "second_value": x2, "value": x1 - x2, "sign": "first - second",
                                                "depends_on": state_keys(r1, r2)})
            for parent in parents:
                for fork in forks:
                    st0 = rows[(parent, fork, "start")]
                    con("start_minus_f0", st0, f0row)
                    for cn in conts:
                        con("continuation_minus_start", rows[(parent, fork, cn)], st0)
                        con("minus_f0", rows[(parent, fork, cn)], f0row)
                    if (parent, fork, "compact_reset") in rows:
                        # v66: against the compact network with the forks' reset schedule (same fork point, 2U)
                        cr_ = rows[(parent, fork, "compact_reset")]
                        con("minus_f0", cr_, f0row)
                        for cn in conts:
                            con("fork_minus_compact_reset", rows[(parent, fork, cn)], cr_)
                    con("minus_f0", rows[(parent, fork, "trajectory_end")], f0row)
                    for name_, first_, second_, _ in NAMED:
                        con(name_, rows[(parent, fork, first_)], rows[(parent, fork, second_)])
                    con("trajectory_end_minus_routed_carry", rows[(parent, fork, "trajectory_end")],
                        rows[(parent, fork, "routed_carry")])
                    if set(conts) & set(MECH):
                        # v65: each redistribution fork against the unedited fork of its routing, and the
                        # routing-specific part of the edit (a difference of differences, one row per metric)
                        for name_, first_, second_, _ in NAMED_MECH:
                            con(name_, rows[(parent, fork, first_)], rows[(parent, fork, second_)])
                        rr, orr = rows[(parent, fork, "routed_reset")], rows[(parent, fork, "ordinary_reset")]
                        for name_, re_, oe_ in INTERACTIONS:
                            a1, b1 = rows[(parent, fork, re_)], rows[(parent, fork, oe_)]
                            for m_ in metrics:
                                v = [x.get(m_) for x in (a1, rr, b1, orr)]
                                if any(x is None for x in v):
                                    continue
                                staged["contrasts"].append({
                                    **meta, "parent": parent, "fork": fork, "comparison": name_, "first": re_,
                                    "second": oe_, "metric": m_, "first_value": v[0] - v[1],
                                    "second_value": v[2] - v[3], "value": (v[0] - v[1]) - (v[2] - v[3]),
                                    "sign": "(first - routed_reset) - (second - ordinary_reset)",
                                    "depends_on": state_keys(a1, rr, b1, orr)})
                    # v63: each fork's end against the matched compact control (update-matched at 2U; and the
                    # control's end, 4U, which used more updates: see _compute)
                    for lab in ("compact_2U", "compact_4U"):
                        if (parent, "compact", lab) in rows:
                            for cn in conts:
                                con(f"fork_minus_{lab}", rows[(parent, fork, cn)], rows[(parent, "compact", lab)])
                for lab in ("compact_2U", "compact_4U"):
                    if (parent, "compact", lab) in rows:
                        con("minus_f0", rows[(parent, "compact", lab)], f0row)
            for k_, rows_ in staged.items():
                out[k_].extend(rows_)
            cov["analysed_f0"] += 1
            print(f"f0 {n_done}/{len(jobs)} analysed ({n_states} states)", flush=True)
        except Fail as ex_:
            cov["failed"].append({"f0": bid, "reason": str(ex_)})
            cov["probe_not_converged"] = [x for x in cov["probe_not_converged"] if x["f0"] != bid]
            print(f"FAIL f0 {bid}: {ex_}", file=sys.stderr)

    Pfx = a.out
    for t_ in ("states", "contrasts", "audits", "compute"):
        SR.atomic_csv(f"{Pfx}_{t_}.csv", out.get(t_, []))
    skip = {"f0", "design_id", "f0_param_hash", "data_draw", "optimizer_seed", "parent", "fork", "state",
            "has_additions", "run_id"}
    long_ = [{**{k: r.get(k) for k in STATE_KEYS + ("data_draw", "optimizer_seed")}, "metric": m, "v": float(v)}
             for r in out["states"] for m, v in r.items()
             if m not in skip and isinstance(v, (int, float)) and not isinstance(v, bool) and MG.finite_number(v)]
    bd, sm = SR.two_stage(long_, STATE_KEYS + ("metric",), "v")
    SR.atomic_csv(f"{Pfx}_states_by_draw.csv", bd)
    SR.atomic_csv(f"{Pfx}_states_summary.csv", sm)
    bd, sm = SR.two_stage(out["contrasts"], CONTRAST_KEYS, "value")
    SR.atomic_csv(f"{Pfx}_contrasts_by_draw.csv", bd)
    SR.atomic_csv(f"{Pfx}_contrasts_summary.csv", sm)
    # v61: the same summaries without every draw that holds a flagged fork (any failed audit check, or the v60
    # float32 fold rule failed), while such a flag is unresolved
    flagged = sorted({r["data_draw"] for r in out["audits"]
                      if not r["audit_passed"] or r.get("outcome_fold_float32_rule_v60_passed") is False
                      or (isinstance(r.get("outcome_redistribution_storage64"), float)
                          and r["outcome_redistribution_storage64"] > STORAGE_TOL)},
                     key=str)
    _, sm_s = SR.two_stage([r for r in out["contrasts"] if r["data_draw"] not in flagged], CONTRAST_KEYS, "value")
    SR.atomic_csv(f"{Pfx}_contrasts_summary_sensitivity.csv", [{**r, "excluded_draws": " ".join(map(str, flagged))}
                                                               for r in sm_s])
    # v61: the central table: per parent, fork and state, the complete network, the raw and the normalised
    # extraction (and the training loss and first-layer shape), each paired against f0 and against the fork start,
    # with the first-layer label probe at both penalties; draws and draw-seed pairs behind each row
    pairs = defaultdict(set)
    for r in out["contrasts"]:
        pairs[tuple(r.get(k) for k in CONTRAST_KEYS)].add((r["data_draw"], r["optimizer_seed"]))
    probe1 = [m for m in {r["metric"] for r in out["contrasts"]}
              if m.startswith("probe|layer1|") and m.endswith("|test_err")]
    central = []
    for r in sm:
        if r["comparison"] not in ("minus_f0", "start_minus_f0", "continuation_minus_start", "fork_minus_compact_reset",
                                   "fork_minus_compact_2U",
                                   "fork_minus_compact_4U") or \
                (r["metric"] not in CENTRAL and r["metric"] not in probe1):
            continue
        err = r["metric"].endswith("_err")
        central.append({**r, "n_draw_seed_pairs": len(pairs[tuple(r.get(k) for k in CONTRAST_KEYS)]),
                        "gain_points": (-100.0 * float(r["mean_value"])) if err else None,
                        "gain_ci95": (f"[{-100.0 * float(r['ci95_high']):.3f}, {-100.0 * float(r['ci95_low']):.3f}]"
                                      if err and r.get("ci95_low") is not None and r.get("ci95_high") is not None
                                      else None),
                        "reading": "gain_points > 0: the first state has the lower error" if err else
                                   "first minus second"})
    SR.atomic_csv(f"{Pfx}_central.csv", central)
    cnt = defaultdict(int)
    for r in out["states"]:
        cnt[r["f0"]] += 1
    miss = [f"{bid}: {cnt[bid]} states, expected {n}" for bid, n in want.items() if bid in cnt and cnt[bid] != n]
    cov["design_ids"] = sorted({r["design_id"] for r in out["states"]})
    cov["output_membership_failures"] = miss
    cov["n_failed"] = len(cov["failed"])
    cov["n_probe_not_converged"] = len(cov["probe_not_converged"])
    cov["n_states"] = len(out["states"])
    cov["n_audited_forks"] = len(out["audits"])
    cov["audit_failures"] = [{k: r[k] for k in ("f0", "parent", "fork", "state", "run_id")} |
                             {k: r[f"{k}_detail"] for k in AUDIT_CHECKS if not r[k]}
                             for r in out["audits"] if not r["audit_passed"]]
    n_forks = sum(len(J_[p_]["forks"][f_]) for b_, J_ in jobs.items() if b_ in cnt for p_ in J_ for f_ in J_[p_]["forks"])
    if len(out["audits"]) != n_forks:
        miss.append(f"{len(out['audits'])} fork audits, expected {n_forks}")
    # v63: audit coverage of the whole design, apart from the audits' outcomes
    cov["n_expected_forks"] = sum(len(J_[p_]["forks"][f_]) for J_ in jobs.values() for p_ in J_
                                  for f_ in J_[p_]["forks"])
    cov["n_passed_forks"] = sum(1 for r in out["audits"] if r["audit_passed"])
    cov["n_failed_forks"] = sum(1 for r in out["audits"] if not r["audit_passed"])
    cov["audit_complete"] = cov["n_expected_forks"] > 0 and len(out["audits"]) == cov["n_expected_forks"]
    cov["compact_controls"] = sorted({(r["parent"], r["state"]) for r in out["states"] if r["fork"] == "compact"})
    cov["compact_reset_controls"] = sorted({(r["parent"], r["fork"]) for r in out["states"]
                                            if r["state"] == "compact_reset"})
    # v66: the normalised measurements withheld because a target norm was not attained
    cov["normalised_ineligible"] = [{k: r[k] for k in ("f0", "parent", "fork", "state")} |
                                    {e_: r.get(f"{e_}_norm_miss") for e_ in NORMALISED}
                                    for r in out["states"] if any(r.get(f"{e_}_eligible") is False
                                                                  for e_ in NORMALISED)]
    cov["eval_batch"] = a.eval_batch
    cov["analysis_complete"] = cov["n_failed"] == 0 and cov["analysed_f0"] > 0 and not miss and \
        cov["analysed_f0"] == cov["expected_f0"] and not cov["probe_not_converged"]
    cov["passed"] = cov["analysis_complete"] and not cov["audit_failures"]
    cov["flagged_draws_excluded_in_sensitivity"] = flagged
    cov["fold_precision"] = {k: max([r[f"outcome_{k}"] for r in out["audits"]
                                     if isinstance(r.get(f"outcome_{k}"), (int, float))
                                     and not isinstance(r.get(f"outcome_{k}"), bool)] or [None], key=lambda x: -1
                                    if x is None else x)
                             for k in ("fold_algebra64", "fold_storage64", "fold_forward32", "fold_refold32",
                                       "fold_recorded_device_forward32", "fold_run_drift32")}
    cov["fold_float32_rule_v60_failures"] = [r["run_id"] for r in out["audits"]
                                             if r.get("outcome_fold_float32_rule_v60_passed") is False]
    # v65: the mechanism forks' edits: largest float64 algebra error, storage change and float32 change
    cov["redistribution_precision"] = {k: max([r[f"outcome_{k}"] for r in out["audits"]
                                               if isinstance(r.get(f"outcome_{k}"), float)] or [None],
                                              key=lambda x: -1 if x is None else x)
                                       for k in ("redistribution_algebra64", "redistribution_storage64",
                                                 "redistribution_forward32", "redistribution_cond")}
    cov["redistribution_storage_flags"] = [r["run_id"] for r in out["audits"]
                                           if isinstance(r.get("outcome_redistribution_storage64"), float)
                                           and r["outcome_redistribution_storage64"] > STORAGE_TOL]
    cov["audit_failure_run_ids"] = sorted(r["run_id"] for r in out["audits"] if not r["audit_passed"])
    cov["outputs_sha256"] = output_bindings(Pfx)
    Path(f"{Pfx}_coverage.json").write_text(json.dumps(cov, indent=1, default=str))
    print(json.dumps({k: cov[k] for k in ("expected_f0", "analysed_f0", "n_failed", "n_probe_not_converged",
                                          "n_states", "n_audited_forks", "analysis_complete", "passed")} |
                     {"n_audit_failures": len(cov["audit_failures"])}))
    return 1 if (a.strict and not cov["passed"]) else 0


if __name__ == "__main__":
    sys.exit(main())
