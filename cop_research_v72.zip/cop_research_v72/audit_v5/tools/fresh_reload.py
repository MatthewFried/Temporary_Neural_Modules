"""Fresh-process checkpoint round trip (v8): for every run under RESULTS with an endpoint.json, reload the
named endpoint checkpoint in THIS process (not the one that trained it), predict the test partition and
compare with the predictions saved at the endpoint evaluation; the same for every saved transplant model
(single and grid designs).  Realisable compact witnesses are re-verified against the noiseless teacher
and their test risk compared with witness.json.

Equality policy: before each comparison the run's recorded execution numerics (allow_tf32, deterministic,
cudnn_benchmark from its last attempt record) are restored; predictions must then be BITWISE equal.  A
tolerance is used only when passed explicitly (--atol, recorded in the report); non-finite values never
pass.  Coverage: every endpoint, saved transplant model and realisable witness must have its checkpoint
and saved predictions; a missing artifact is a failure, and an empty check set is a failure.  Only two
kinds of entries are excluded, each by its own record and listed: endpoints recorded as diverged
(endpoint.json diverged = true) and transplant assemblies recorded as ineligible.  An endpoint that its job
recorded as numerically invalid (endpoint.json numerically_valid = false) must reproduce exactly, NaN and inf
positions included; it is listed under recorded_numerically_invalid and never enters an estimate.  Exit status 1 on any
failure (the report is written first).
Usage:
v25: --device recorded (the default) reloads every run on the device its last complete attempt ran on, and every
recoding fit on the device recorded in its own record (a job resumed on another device has fits from both); a
recorded CUDA device that is unavailable here is a failure with that reason, never a silent CPU reload.
  python audit_v5/tools/fresh_reload.py RESULTS OUT.json [--device recorded|cpu|cuda] [--data-root DIR] [--limit N]
                                        [--atol X]"""
import argparse
import json
import os
import sys
from collections import Counter
from pathlib import Path
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")      # before CUDA initialises (deterministic GEMMs)
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import torch
from cop.graph.graph import GraphNet
from cop.graph.accounting import architecture_hash
from cop.data.registry import load_bundle
from cop.train.trainer import predict
from cop.utils import configure_torch
from cop.analysis.gates import write_and_exit

ap = argparse.ArgumentParser()
ap.add_argument("results")
ap.add_argument("out")
ap.add_argument("--device", default="recorded", help="recorded (each run's / fit's own device), cpu or cuda[:k]")
ap.add_argument("--data-root", default=None)
ap.add_argument("--limit", type=int, default=0)
ap.add_argument("--atol", type=float, default=0.0)
a = ap.parse_args()
bundles = {}
rows, failures, excluded, recorded_invalid_rows = [], [], [], []


def exec_of(rd: Path) -> dict:
    """Execution settings of the run's last complete attempt (defaults if none is recorded)."""
    best = None
    for f in sorted((rd / "attempts").glob("*.json")):
        try:
            att = json.load(open(f))
        except ValueError:
            continue
        if att.get("status") == "complete":
            best = att
    return dict((best or {}).get("exec") or {})


def dev_of(rd) -> str:
    """the device a run's endpoints are reloaded on: its last complete attempt's device under --device recorded."""
    if a.device != "recorded":
        return a.device
    d = str(exec_of(rd).get("device") or "cpu")
    if d == "cuda" or d.startswith("cuda:"):
        if not torch.cuda.is_available():
            raise RuntimeError(f"recorded training device {d} is not available here")
    return d


def bundle_on(cfg, dev):
    key = (json.dumps(cfg["data"], sort_keys=True), dev)
    if key not in bundles:
        bundles[key] = load_bundle(cfg["data"], a.data_root, device="cpu").to(dev)
    return bundles[key]


def check(rd, cfg, ckpt, preds, expect_arch=None, label="", recorded_invalid=None):
    """One comparison; an exception is recorded as a failure of this entry, never aborts the report."""
    try:
        _check(rd, cfg, ckpt, preds, expect_arch, label, recorded_invalid)
    except Exception as ex:                                     # noqa: BLE001  (recorded, gate fails)
        failures.append({"run": rd.name, "checkpoint": ckpt, "label": label,
                         "reason": f"exception during reload check: {type(ex).__name__}: {ex}"})


def _check(rd, cfg, ckpt, preds, expect_arch=None, label="", recorded_invalid=None):
    ck_path = rd / "ckpt" / f"{ckpt}.pt"
    if not ck_path.exists():
        failures.append({"run": rd.name, "checkpoint": ckpt, "reason": "missing checkpoint file"})
        return
    if not preds.exists():
        failures.append({"run": rd.name, "checkpoint": ckpt, "reason": f"missing saved predictions {preds.name}"})
        return
    ex = exec_of(rd)
    dev = dev_of(rd)
    # recorded thread count restored too (CPU reductions can depend on it); None leaves the current setting
    applied = configure_torch({**ex, "device": dev, "torch_threads": ex.get("torch_threads")})
    if not ex.get("deterministic", True):
        torch.use_deterministic_algorithms(False)
    b = bundle_on(cfg, dev)
    ck = torch.load(ck_path, map_location="cpu", weights_only=False)
    g = GraphNet.from_checkpoint(ck["model"], dev)
    y = predict(g, b.partitions()["test"], cfg.get("train", {}).get("eval_batch", 4096)).detach()
    y = (y.float() if y.is_floating_point() else y).cpu()
    ref = torch.load(preds, map_location="cpu", weights_only=False)
    finite = bool(torch.isfinite(ref).all() and torch.isfinite(y).all()) if ref.is_floating_point() else True
    same_shape = y.shape == ref.shape
    if a.atol > 0 and same_shape and finite:
        equal = bool((y - ref).abs().max() <= a.atol)
    else:
        equal = bool(torch.equal(y, ref)) if same_shape else False
    # exact reproduction including the position of every NaN (torch.equal treats NaN != NaN)
    nan_exact = same_shape and ref.is_floating_point() and bool(torch.equal(torch.isnan(y), torch.isnan(ref))) and \
        bool(torch.equal(y[~torch.isnan(y)], ref[~torch.isnan(ref)]))
    rec_invalid = recorded_invalid or None
    r = {"run": rd.name, "kind": cfg["kind"], "checkpoint": ckpt, "label": label, "device": dev,
         "equal": (equal and finite) or bool(rec_invalid and nan_exact),
         "bitwise_equal": bool(torch.equal(y, ref)) if same_shape else False, "finite": finite,
         "max_abs_diff": float((y - ref).abs().max()) if (same_shape and finite) else None,
         "numerics": applied}
    if rec_invalid:
        # the job itself recorded this endpoint as numerically invalid: the reload claim is exact reproduction
        # (non-finite values included); the endpoint is listed separately and never enters an estimate
        r["recorded_numerically_invalid"] = rec_invalid
        r["reproduced_exactly_including_nonfinite"] = bool(nan_exact)
        recorded_invalid_rows.append(r)
    if expect_arch is not None:
        r["architecture_hash_equal"] = architecture_hash(g) == expect_arch
        r["equal"] = r["equal"] and r["architecture_hash_equal"]
    rows.append(r)
    if not r["equal"]:
        failures.append({"run": rd.name, "checkpoint": ckpt, "reason": "reloaded predictions differ" if finite
                         else "non-finite predictions", **{k: r[k] for k in ("max_abs_diff", "finite")}})


runs = sorted(p for p in (Path(a.results) / "runs").glob("*") if p.is_dir()) if (Path(a.results) / "runs").is_dir() else []
n = 0
for rd in runs:
    if a.limit and n >= a.limit:
        break
    ep_p = rd / "endpoint.json"
    if not ep_p.exists():
        continue
    cfg = json.load(open(rd / "config.json"))
    ep = json.load(open(ep_p))
    if ep.get("diverged"):
        excluded.append({"run": rd.name, "checkpoint": ep.get("checkpoint"), "reason": "endpoint recorded as diverged"})
        continue
    check(rd, cfg, ep["checkpoint"], rd / "preds" / "endpoint__test.pt", ep.get("architecture_hash"), "endpoint",
          recorded_invalid=(ep.get("numerical_reasons") or ["numerically invalid"])
          if ep.get("numerically_valid") is False else None)
    n += 1
# v23: every other reported endpoint record (validation-selected: endpoint_best_val.json; example-tied dropout
# native test-time function: endpoint_etd_native.json), reloaded from its own checkpoint and prediction file
ep_cov = {}
for rd in runs:
    for ep_p in sorted(rd.glob("endpoint_*.json")):
        kind = ep_p.stem
        c = ep_cov.setdefault(kind, {"expected": 0, "checked": 0, "excluded": 0, "failed": 0})
        ep = json.load(open(ep_p))
        if ep.get("selected", "x") is None:
            c["excluded"] += 1
            excluded.append({"run": rd.name, "checkpoint": kind, "reason": ep.get("reason") or "no selected state"})
            continue
        c["expected"] += 1
        if ep.get("diverged"):
            c["excluded"] += 1
            excluded.append({"run": rd.name, "checkpoint": ep.get("checkpoint"), "reason": f"{kind} recorded as diverged"})
            continue
        cfg = json.load(open(rd / "config.json"))
        n_fail = len(failures)
        check(rd, cfg, ep.get("checkpoint", "missing"), rd / "preds" / f"{kind}__test.pt", ep.get("architecture_hash"),
              kind, recorded_invalid=(ep.get("numerical_reasons") or ["numerically invalid"])
              if ep.get("numerically_valid") is False else None)
        c["checked"] += 1
        c["failed"] += int(len(failures) > n_fail)
for rd in runs:
    tr = rd / "transplant_result.json"
    if not tr.exists():
        continue
    cfg = json.load(open(rd / "config.json"))
    res = json.load(open(tr))
    info = res.get("info") or {}
    if info.get("design") == "grid":
        sys.path.insert(0, str(ROOT))
        from cop.analysis.v5_tables import grid_assembly_eligibility
        elig = grid_assembly_eligibility(res)
    else:
        elig = {}
    for name, s in (info.get("saved_models") or {}).items():
        if elig and not elig.get(name, {}).get("eligible", False):
            excluded.append({"run": rd.name, "checkpoint": s["checkpoint"],
                             "reason": f"ineligible transplant assembly: {elig.get(name, {}).get('reasons')}"})
            continue
        check(rd, cfg, s["checkpoint"], rd / "preds" / f"{name}__test.pt", label=f"transplant:{name}")
wrows = []


def witness_check(rd, w):
    from cop.data.witness import verify_witness
    from cop.train.trainer import evaluate
    cfg = json.load(open(rd / "config.json"))
    dev = dev_of(rd)
    b = bundle_on(cfg, dev)
    ck = torch.load(rd / "ckpt" / "witness.pt", map_location="cpu", weights_only=False)
    g = GraphNet.from_checkpoint(ck["model"], dev)
    ver = verify_witness(g, b)
    res, _ = evaluate(g, b, ["test"], 4096)
    rec = (w.get("risk") or {}).get("test", {})
    k = "mse" if "mse" in rec else "acc"
    got = float(res["test"][k])
    ok = rec.get(k) is not None and abs(got - float(rec[k])) <= 1e-9 * max(1.0, abs(float(rec[k])))
    wrows.append({"run": rd.name, "verified": ver["verified"], "max_abs_err": ver["max_abs_err"], "test_metric": k,
                  "test_reloaded": got, "test_recorded": rec.get(k), "equal": ok})
    if not (ok and ver["verified"]):
        failures.append({"run": rd.name, "checkpoint": "witness", "reason": "witness does not reproduce",
                         "verified": ver["verified"], "equal": ok})


for rd in runs:
    wp = rd / "witness.json"
    if not wp.exists():
        continue
    w = json.load(open(wp))
    if not w.get("realizable"):
        continue
    if not (rd / "ckpt" / "witness.pt").exists():
        failures.append({"run": rd.name, "checkpoint": "witness", "reason": "realisable witness without checkpoint"})
        continue
    try:
        witness_check(rd, w)
    except Exception as ex:                                     # noqa: BLE001
        failures.append({"run": rd.name, "checkpoint": "witness",
                         "reason": f"exception during witness check: {type(ex).__name__}: {ex}"})
# v20: recoding fits (replacement weights, compensators, compiled tables, spliced predictions)
rc_rows = []
for rd in runs:
    if not (rd / "recode_plan.json").exists():
        continue
    st = json.load(open(rd / "status.json")) if (rd / "status.json").exists() else {}
    if st.get("status") != "complete":
        continue
    cfg = json.load(open(rd / "config.json"))
    try:
        from cop.cop_pegs.recode import reload_recode
        # fits are reloaded on their own recorded devices (--device recorded); numerics from the last attempt
        applied = configure_torch({**exec_of(rd), "device": "cpu" if a.device == "recorded" else a.device,
                                   "torch_threads": exec_of(rd).get("torch_threads")})
        rr = reload_recode(rd, bundle_on(cfg, "cpu"), a.device, atol=a.atol)
    except Exception as ex:                                     # noqa: BLE001
        rr = {"expected": None, "checked": 0, "failed": 1, "failures": [{"reason": f"{type(ex).__name__}: {ex}"}]}
    rc_rows.append({"run": rd.name, **{k: v for k, v in rr.items() if k != "failures"}})
    for f in rr.get("failures") or []:
        failures.append({"run": rd.name, "checkpoint": "recode", **f})
    if rr.get("expected") is not None and rr["checked"] + rr.get("skipped_numerical_failure", 0) != rr["expected"]:
        failures.append({"run": rd.name, "checkpoint": "recode",
                         "reason": f"recode reload coverage {rr['checked']} checked + "
                                   f"{rr.get('skipped_numerical_failure', 0)} numerical failures of {rr['expected']}"})
summary = {"n_checked": len(rows), "n_equal": sum(r["equal"] for r in rows),
           "bitwise_equal": sum(r["bitwise_equal"] for r in rows),
           "by_kind": dict(Counter(r["kind"] for r in rows)), "device": a.device,
           "equality_policy": ("bitwise after restoring recorded numerics" if a.atol == 0
                               else f"max abs difference <= {a.atol} (explicit --atol), finite only"),
           "witness_checked": len(wrows), "witness_ok": sum(r["equal"] and r["verified"] for r in wrows),
           "n_excluded": len(excluded), "n_failures": len(failures),
           "n_recorded_numerically_invalid": len(recorded_invalid_rows),
           "n_recorded_numerically_invalid_reproduced": sum(r["reproduced_exactly_including_nonfinite"]
                                                           for r in recorded_invalid_rows),
           "recode_runs": len(rc_rows), "recode_fits_expected": sum(r.get("expected") or 0 for r in rc_rows),
           "recode_fits_checked": sum(r.get("checked") or 0 for r in rc_rows),
           "recode_fits_skipped_numerical_failure": sum(r.get("skipped_numerical_failure") or 0 for r in rc_rows),
           "recode_fits_failed": sum(r.get("failed") or 0 for r in rc_rows),
           "endpoint_records": {"endpoint": sum(1 for r in rows if r["label"] == "endpoint"), **ep_cov}}
if not rows and not wrows and not rc_rows:
    failures.append({"reason": "empty check set: no endpoint, transplant model or witness was found"})
verdict = {"passed": not failures, "failures": failures, "excluded": excluded}
print(json.dumps(summary, indent=1)[:2000])
write_and_exit(Path(a.out), {"summary": summary, "rows": rows, "witness_rows": wrows, "recode_rows": rc_rows,
                             "recorded_numerically_invalid": recorded_invalid_rows}, verdict)
