#!/usr/bin/env python3
"""v53: gain-only training of f0 (the only training outside the job system; nothing under cop/ changed).

For every f0 of the manifest that has expansions, f0's first-layer weight W0 is reparameterised as W0 with its input
columns multiplied by gains, the gains start at 1 (the function is f0's exactly) and ONLY the gains are trained, on
the training loss, for as many updates as the expansions train (2U), with the panel's optimizer settings (the f0
job's: optimizer, learning rate, betas, batch size; no weight decay on a gain) and the SAME minibatches the
expansions draw: the trainer is cop's own, started from f0's saved trainer state, and its audited stream (hash chain
of the ordered example ids) must equal every expansion's, else the f0 fails.  Every other tensor stays f0's.

Modes (MODES), each a separate training from f0:
  causal_scalar             one gain on the causal input block (uses the generator's feature layout)
  per_column                one gain per input column, all trained (no feature labels)
  per_column_shortcut_held  one gain per input column, the shortcut column's held at 1 (the layout names the
                            shortcut column: the access of the B arms)
The gains are saved and evaluated at f0 (age 0: must reproduce f0 on every evaluated partition), at the expansions'
checkpoint ages and at the end.  Each evaluated network is a compact network of f0's architecture; it is checked
against the reparameterised forward pass used in training.  Tables: _gain_runs (per f0, mode and age), their
by-draw and summary tables (optimizer seeds averaged within a draw, intervals over draws), _gain_vectors (the trained
gain of every input column at the end), _gain_stream (the stream check) and _coverage.json.

Float32 training is device dependent: gains trained on different devices are not compared bitwise.

usage: gain_training.py RESULTS OUT_PREFIX --manifest M [--data-root D] [--device cpu|cuda] [--strict]
                        [--save-gains DIR]
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import coordinated_edits as CE  # noqa: E402
import selective_reversal as SR  # noqa: E402

torch = SR.torch
AC = SR.AC
Fail = SR.Fail
GraphNet = SR.GraphNet

ANALYSIS_SCHEMA = "gain_training/v53"
STATUS = ("gain-only training of f0 outside the job system (1 to n_inputs parameters); every other tensor is f0's; "
          "exploratory")
MODES = {
    "causal_scalar": "feature layout: which input columns are causal (one shared gain on them)",
    "per_column": "none: one gain per input column, no feature labels",
    "per_column_shortcut_held": "feature layout: which input column is the shortcut (its gain held at 1), as the B "
                                "arms' hold",
}
# the evaluated compact network against the training-time reparameterised forward pass: max |logit difference|
# relative to max(1, max |logit|) on the test partition; a differing decision is allowed only within twice that margin
IMPL_TOL = 1e-5
METRICS = ("train_loss", "train_err") + CE.BASE_METRICS + ("test_gain_vs_f0", "gain_causal_mean", "gain_causal_min",
                                                           "gain_causal_max", "gain_shortcut", "gain_other_mean",
                                                           "gain_log_rms")


def owners(mode: str, n_in: int, lay: dict):
    """-> (owner: for each input column the index of the gain it uses, or -1 for a column whose gain stays 1;
    the number of trained gains)."""
    has = "input_rotation" not in lay and "shortcut" in lay and "causal" in lay
    own = torch.full((n_in,), -1, dtype=torch.long)
    if mode == "per_column":
        own = torch.arange(n_in)
    elif mode == "causal_scalar":
        if not has:
            raise Fail("mode causal_scalar needs the generator's unrotated feature layout")
        c0, c1 = (int(x) for x in lay["causal"])
        own[c0:c1] = 0
    elif mode == "per_column_shortcut_held":
        if not has:
            raise Fail("mode per_column_shortcut_held needs the generator's unrotated feature layout")
        free = [j for j in range(n_in) if j != int(lay["shortcut"])]
        own[torch.tensor(free)] = torch.arange(len(free))
    else:
        raise Fail(f"unknown mode {mode!r}")
    return own, int(own.max()) + 1


def gain_vector(g, own):
    """the per-column gain: the trained gain of the columns that have one, exactly 1 elsewhere."""
    return torch.where(own >= 0, g[own.clamp_min(0)], torch.ones((), dtype=g.dtype, device=g.device))


def f0_groups(mcfg: dict) -> dict:
    """-> {f0 run id: [its trajectories' run ids]} for every baseline job that has trajectories in the manifest."""
    out = defaultdict(list)
    for rid, c in mcfg.items():
        if c.get("kind") == "trajectory" and (c.get("parents") or {}).get("baseline") in mcfg and \
                (c.get("growth") or {}).get("topology", "none") != "none":
            out[c["parents"]["baseline"]].append(rid)
    return {k: sorted(v) for k, v in out.items()}


def cell_of(mcfg: dict, tids: list) -> str:
    """the cell label the removal jobs of these trajectories carry (their design's contrast), '' when none."""
    cells = sorted({((c.get("design") or {}).get("contrast") or "").split("|")[-1] for c in mcfg.values()
                    if c.get("kind") == "dissipation" and (c.get("parents") or {}).get("trajectory") in tids})
    return cells[0] if len(cells) == 1 else ""


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("results")
    ap.add_argument("out")
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--strict", action="store_true", help="exit 1 unless every f0 is trained and checked")
    ap.add_argument("--save-gains", default=None, metavar="DIR",
                    help="save each mode's trained gains and its test decisions at every evaluated age")
    a = ap.parse_args(argv)
    dev = torch.device(a.device)
    if dev.type == "cuda" and not torch.cuda.is_available():
        print("--device cuda requested but CUDA is not available", file=sys.stderr)
        return 2
    from cop.experiments.common import seeds as cfg_seeds
    from cop.train.trainer import Trainer, make_optimizer, task_loss
    numerics = CE.numerics_policy(dev)
    runs = Path(a.results) / "runs"
    mcfg = {e["run_id"]: e["cfg"] for e in AC.manifest_entries(a.manifest)}
    groups = f0_groups(mcfg)
    cov = {"tool": "gain_training", "analysis_schema": ANALYSIS_SCHEMA, "status": STATUS,
           "results": str(Path(a.results).resolve()), "manifest": a.manifest,
           "manifest_sha256": CE.sha256_file(a.manifest),
           "source_sha256": {p.name: CE.sha256_file(p) for p in (Path(__file__), Path(CE.__file__),
                                                                 Path(SR.__file__), Path(AC.__file__))},
           "numerics": {**numerics, "training_dtype": "f0's own parameter dtype",
                        "note": "trained gains are device dependent (float32); not compared bitwise across devices"},
           "modes": MODES, "implementation_tolerance": IMPL_TOL,
           "optimizer": "the f0 job's (optimizer, learning rate, betas, batch size), weight decay 0 on the gains, "
                        "constant learning rate",
           "stream": "cop's trainer from f0's saved state; the audited hash chain must equal every expansion's",
           "expected_f0": len(groups), "analysed_f0": 0, "failed": []}
    out = defaultdict(list)
    bundles = {}
    want_rows = {}
    for bid in sorted(groups):
        tids = groups[bid]
        staged = defaultdict(list)
        try:
            bcfg = AC.job_config(runs, bid, mcfg[bid])
            tcfgs = {t: AC.job_config(runs, t, mcfg[t]) for t in tids}
            ages = {CE.expected_age(c) for c in tcfgs.values()}
            dkeys = {json.dumps(c["data"], sort_keys=True) for c in tcfgs.values()} | \
                {json.dumps(bcfg["data"], sort_keys=True)}
            if len(ages) != 1 or len(dkeys) != 1:
                raise Fail(f"{bid}: its expansions differ in length or in data")
            n_upd = ages.pop()
            dk = dkeys.pop()
            if dk not in bundles:
                b0 = SR.load_bundle(json.loads(dk), a.data_root, device="cpu")
                bundles[dk] = (b0.to(dev), b0.hashes())
            b, hashes = bundles[dk]
            if b.task != "classification":
                raise Fail(f"{bid}: task {b.task!r}; only classification is supported")
            t = dict(bcfg["train"])
            if t.get("lr_schedule", "constant") != "constant" or int(t.get("warmup", 0) or 0) or \
                    float(t.get("grad_clip", 0.0) or 0.0) or t.get("stream", "fixed") != "fixed" or \
                    t.get("precision", "fp32") != "fp32" or t.get("target", "task") != "task":
                raise Fail(f"{bid}: gain training supports a constant learning rate without warmup or clipping, a "
                           f"fixed training set, fp32 and the task target")
            ps = AC.eval_partitions(b)
            need = {"train", *ps}
            parts = b.partitions()
            batch = int(t.get("eval_batch", 4096))
            # ---- f0, as the expansions start from it (their own reference copy), shared by all of them
            f0k, f0_ids, want_stream = None, set(), {}
            for tid, tc in tcfgs.items():
                AC.check_logged_data(runs / tid, hashes, need, f"{tid} data provenance")
                k = SR.ckp(runs / tid, "baseline_ref")
                gk = AC.check_ckpt(k, f"{tid} f0", run_id=tid, stage="baseline_ref", cfg=tc, hashes=hashes, need=need)
                f0_ids.add((AC.param_hash_of(k), gk.structural_hash()))
                f0k = f0k or k
                end = SR.ckp(runs / tid, "final")
                AC.check_ckpt(end, f"{tid} end", run_id=tid, stage="final", cfg=tc, hashes=hashes, need=need)
                CE.check_age(AC.job_update(end, k, f"{tid} end"), n_upd, tid)
                st = AC.trainer_state(end)
                want_stream[tid] = (st.get("batch_id_hash"), st.get("batches_drawn"))
            if len(f0_ids) != 1:
                raise Fail(f"{bid}: its expansions do not share f0 (parameters and graph)")
            if any(h is None for h, _ in want_stream.values()):
                raise Fail(f"{bid}: an expansion has no audited minibatch stream (train.audit_batches)")
            if len(set(want_stream.values())) != 1:
                raise Fail(f"{bid}: its expansions drew different minibatch streams")
            tst = (f0k.get("extra") or {}).get("trainer")
            if not isinstance(tst, dict) or "state" not in tst:
                raise Fail(f"{bid}: f0's reference copy carries no trainer state (the stream cannot be continued)")
            f0 = GraphNet.from_checkpoint(f0k["model"], dev).eval()
            f0_sd = {k: v.clone() for k, v in f0.state_dict().items()}
            L = SR.backbone_layers(f0)
            w1 = [k for k in f0_sd if k.startswith(f"mods.{L[0]}.") and f0_sd[k].dim() == 2]
            tr_part = parts["train"]
            if set(tr_part.X) != {"x"} or len(w1) != 1 or f0_sd[w1[0]].shape[1] != tr_part.X["x"].shape[1]:
                raise Fail(f"{bid}: gain training needs one input tensor read by one first-layer weight matrix")
            w1 = w1[0]
            W0 = f0_sd[w1]
            n_in = int(W0.shape[1])
            lay = (b.meta or {}).get("feature_layout") or {}
            has_layout = "input_rotation" not in lay and "shortcut" in lay and "causal" in lay
            ytr = tr_part.y.to(dev).long()
            ytest = parts["test"].y.to(dev).long()

            def measure(m):
                o, pr = AC.finite_eval(m, b, ps, batch, "gain training")
                o["test_ce"] = float(torch.nn.functional.cross_entropy(pr["test"].double(), ytest))
                _, ptr = AC.finite_eval(m, b, ["train"], batch, "gain training")
                z = ptr["train"].double()
                o["train_loss"] = float(torch.nn.functional.cross_entropy(z, ytr))
                o["train_err"] = float((z.argmax(-1) != ytr).double().mean())
                return o, pr

            def compact(W):
                m_ = GraphNet.from_checkpoint(f0k["model"], dev).eval()
                want = dict(m_.state_dict())
                want[w1] = W.to(want[w1].device, want[w1].dtype)
                m_.load_state_dict(want)
                m_._plan = None
                CE.verify_patch(m_.state_dict(), want, "gain training: compact build")
                return m_
            f0e, f0p = measure(f0)
            eval_ages = sorted({0, n_upd, *[u for _, u in CE.trajectory_checkpoints(None, tcfgs[tids[0]])]})
            want_rows[bid] = len(eval_ages)
            meta = {"f0": bid, "f0_param_hash": next(iter(f0_ids))[0], "cell": cell_of(mcfg, tids),
                    "draw_set": SR.draw_role(tcfgs[tids[0]]),
                    "data_draw": (bcfg.get("data") or {}).get("data_seed"),
                    "optimizer_seed": (bcfg.get("seeds") or {}).get("optimizer"), "updates": n_upd,
                    "lr": float(t["lr"]), "batch_size": int(t["batch_size"]), "n_inputs": n_in,
                    "expansions": len(tids)}
            xte = parts["test"].X["x"].to(dev)
            for mode, access in MODES.items():
                own, n_g = owners(mode, n_in, lay)
                own = own.to(dev)
                model = GraphNet.from_checkpoint(f0k["model"], dev)
                trn = Trainer(model, b, {**t, "audit_batches": True}, cfg_seeds(bcfg), str(dev))
                trn.load_state_dict(tst)                     # f0's sampler position, permutation and generators
                if trn.state.get("batch_id_hash") is not None or trn.state.get("batches_drawn"):
                    raise Fail(f"{bid}: f0's trainer state already carries a stream hash")
                g = torch.nn.Parameter(torch.ones(n_g, dtype=W0.dtype, device=dev))
                opt = make_optimizer([g], {**t, "weight_decay": 0.0})
                model.train()
                prs, order = [], []
                for u in range(n_upd + 1):
                    if u in eval_ages:
                        with torch.no_grad():
                            gv = gain_vector(g, own)
                            W = (W0 * gv[None, :]).detach()
                        m_ = compact(W)
                        e, pr = measure(m_)
                        if u == 0 and not CE.same_everywhere(pr, f0p):
                            raise Fail(f"{bid} {mode}: gains of 1 do not reproduce f0")
                        # the same network through the forward pass used in training, in the evaluation's chunks
                        with torch.no_grad():
                            model.eval()
                            Wg = W0 * gain_vector(g, own)[None, :]
                            zf = torch.cat([torch.func.functional_call(
                                model, {w1: Wg}, (trn._cast({"x": xte[i0:i0 + batch]}),)).double()
                                for i0 in range(0, int(xte.shape[0]), batch)])
                            model.train()
                        ref = pr["test"].double()
                        scale = max(1.0, float(ref.abs().max()))
                        d_ = float((zf - ref).abs().max()) / scale
                        dd = zf.argmax(-1) != ref.argmax(-1)
                        top2 = ref.topk(2, -1).values
                        if d_ > IMPL_TOL or bool(((top2[:, 0] - top2[:, 1])[dd] > 2 * IMPL_TOL * scale).any()):
                            raise Fail(f"{bid} {mode} at {u}: the compact network differs from the reparameterised "
                                       f"forward pass (max relative logit difference {d_:.3g})")
                        gd = gv.double().cpu()
                        r = {**meta, "mode": mode, "access": access, "n_gains": n_g, "age": u,
                             **{k: e.get(k) for k in ("train_loss", "train_err") + CE.BASE_METRICS},
                             "test_gain_vs_f0": f0e["test_err"] - e["test_err"], "f0_test_err": f0e["test_err"],
                             "f0_val_err": f0e["val_err"], "f0_train_loss": f0e["train_loss"],
                             "gain_log_rms": float((gd.log() ** 2).mean() ** 0.5) if bool((gd > 0).all()) else None,
                             "gain_min": float(gd.min()), "gain_max": float(gd.max()),
                             "impl_max_rel_diff": d_, "impl_decisions_differ": int(dd.sum())}
                        if has_layout:
                            c0, c1 = (int(x) for x in lay["causal"])
                            sc = int(lay["shortcut"])
                            oth = [j for j in range(n_in) if not (c0 <= j < c1) and j != sc]
                            r.update({"gain_causal_mean": float(gd[c0:c1].mean()),
                                      "gain_causal_min": float(gd[c0:c1].min()),
                                      "gain_causal_max": float(gd[c0:c1].max()), "gain_shortcut": float(gd[sc]),
                                      "gain_other_mean": float(gd[oth].mean()) if oth else None})
                        staged["gain_runs"].append(r)
                        prs.append(pr)
                        order.append(f"{mode}|{u}")
                        if u == n_upd:
                            for j in range(n_in):
                                blk = "other"
                                if has_layout:
                                    blk = "causal" if c0 <= j < c1 else "shortcut" if j == sc else "other"
                                staged["gain_vectors"].append({**meta, "mode": mode, "column": j, "block": blk,
                                                               "trained": bool(own[j] >= 0), "gain": float(gd[j])})
                    if u == n_upd:
                        break
                    bt = trn.next_batch()
                    X = trn._cast(bt.X)
                    loss = task_loss(torch.func.functional_call(model, {w1: W0 * gain_vector(g, own)[None, :]},
                                                                (X,)), bt.y, trn.task)
                    if not bool(torch.isfinite(loss.detach())):
                        raise Fail(f"{bid} {mode}: non-finite loss at update {u}")
                    (gr,) = torch.autograd.grad(loss, [g])
                    opt.zero_grad(set_to_none=True)
                    g.grad = gr
                    opt.step()
                    if not bool(torch.isfinite(g.detach()).all()):
                        raise Fail(f"{bid} {mode}: non-finite gains after update {u + 1}")
                got = (trn.state.get("batch_id_hash"), trn.state.get("batches_drawn"))
                ok = all(got == w for w in want_stream.values()) and got[1] == n_upd
                staged["gain_stream"].append({**meta, "mode": mode, "batch_id_hash": got[0], "batches_drawn": got[1],
                                              "expansions_batch_id_hash": next(iter(want_stream.values()))[0],
                                              "expansions_compared": " ".join(sorted(want_stream)),
                                              "same_minibatches_as_every_expansion": ok})
                if not ok:
                    raise Fail(f"{bid} {mode}: the gain training's minibatch stream {got} differs from the "
                               f"expansions' {sorted(set(want_stream.values()))}")
                if a.save_gains:
                    import numpy as np
                    od = Path(a.save_gains)
                    od.mkdir(parents=True, exist_ok=True)
                    np.savez_compressed(
                        od / f"{bid}__gain_{mode}.npz",
                        preds_test=np.stack([p_["test"].argmax(-1).cpu().numpy() for p_ in prs]).astype(np.int16),
                        labels_test=ytest.cpu().numpy().astype(np.int16), gains=g.detach().cpu().numpy(),
                        owner=own.cpu().numpy(),
                        meta=np.asarray(json.dumps({**meta, "mode": mode, "order": order,
                                                    "note": "device-dependent float32 training"}, default=str)))
            for k_, rows_ in staged.items():
                out[k_].extend(rows_)
            cov["analysed_f0"] += 1
        except Fail as ex_:
            cov["failed"].append({"f0": bid, "reason": str(ex_)})
            print(f"FAIL f0 {bid}: {ex_}", file=sys.stderr)

    P = a.out
    for t_ in ("gain_runs", "gain_vectors", "gain_stream"):
        SR.atomic_csv(f"{P}_{t_}.csv", out.get(t_, []))
    long_ = [{**{k: r[k] for k in ("cell", "mode", "access", "age", "data_draw", "optimizer_seed")}, "metric": m,
              "v": float(r[m])} for r in out["gain_runs"] for m in METRICS if r.get(m) is not None]
    bd, sm = SR.two_stage(long_, ("cell", "mode", "access", "age", "metric"), "v")
    SR.atomic_csv(f"{P}_gain_runs_by_draw.csv", bd)
    SR.atomic_csv(f"{P}_gain_runs_summary.csv", sm)
    vl = [{**{k: r[k] for k in ("cell", "mode", "block", "trained", "data_draw", "optimizer_seed")}, "v": r["gain"]}
          for r in out["gain_vectors"]]
    # columns of one block averaged within a run first (two_stage averages repeated keys within a draw and seed)
    _, vs = SR.two_stage(vl, ("cell", "mode", "block", "trained"), "v")
    SR.atomic_csv(f"{P}_gain_vectors_summary.csv", vs)
    miss = []
    cnt, per = defaultdict(int), defaultdict(int)
    for r in out["gain_runs"]:
        cnt[(r["f0"], r["mode"])] += 1
    for r in out["gain_stream"]:
        per[r["f0"]] += 1
    for f0_ in sorted({r["f0"] for r in out["gain_runs"]}):
        if per[f0_] != len(MODES) or any(cnt[(f0_, m)] != want_rows[f0_] for m in MODES):
            miss.append(f"{f0_}: rows by mode {dict((m, cnt[(f0_, m)]) for m in MODES)} (want {want_rows[f0_]} "
                        f"each), {per[f0_]} stream checks (want {len(MODES)})")
    cov["output_membership_failures"] = miss
    cov["n_failed"] = len(cov["failed"])
    cov["passed"] = cov["n_failed"] == 0 and cov["analysed_f0"] > 0 and not miss and \
        cov["analysed_f0"] == cov["expected_f0"]
    Path(f"{P}_coverage.json").write_text(json.dumps(cov, indent=1, default=str))
    print(json.dumps({k: cov[k] for k in ("expected_f0", "analysed_f0", "n_failed", "passed")}))
    if a.strict and not cov["passed"]:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
