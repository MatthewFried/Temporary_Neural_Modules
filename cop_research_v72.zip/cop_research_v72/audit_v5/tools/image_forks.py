#!/usr/bin/env python3
"""v65: the v60 design on images (wave 30).  Reads the panel, trains nothing, fits nothing.

For every f0 (cnn_cut on image_shortcut) the STATES are
  f0
  per arm (A_routed_affine, A_all_affine, B_routed_affine, B_all_affine, A_head_all_relu; parent = the arm, fork
  "end"): trajectory_end (the expansion at 2U, its additions in place) and removal_end (the linear removal's export)
  per routed arm, fork point and continuation (as wave 28: start, routed_reset, ordinary_reset, frozen_reset,
  folded_reset, routed_carry; parent = the arm, fork = the fork point)
  the compact controls (parent = the hold, "A" or "B"; fork "compact"): compact_2U (update-matched to the forks'
  and the trajectories' ends) and compact_4U (the control's end; more updates: _compute)
Per state:
  native        the network's own errors (test, val, val_indep, shift), training loss and shortcut_flip_rate (the
                paired cf_base / cf_shortcut images: the share of decisions that follow the shortcut plane alone)
  extraction    its first layer (the first 3x3 convolution, weight and bias) in f0, the rest of f0: the same errors
  normalised    the same with the first layer's kernels at f0's norm per output channel and input block (blocks:
                the colour channels and the shortcut channel) and f0's bias (state_at_f0_block_row_norms_f0_bias,
                the registry's metric), and at f0's norm per output channel over all inputs with f0's bias
                (state_at_f0_row_norms_f0_bias: needs no feature layout)
  shape         first-layer norm ratio and cosine to f0, the colour and shortcut blocks' norm ratios, bias change
Per fork: the audit of fork_continuation (start, updates, stream, optimizer policy and membership, masks,
parameters, held channel, learning rate) and, for folded_reset, the saved after-fold start (no addition or mask,
f0's architecture, the receiving 1x1 layer = W A and b + W c for the snapshot's exact merge map within COMPOSE_TOL,
every other backbone tensor the snapshot's exactly, the optimizer's membership) and the fold's function (decisive in
float64: the refold against the snapshot within ALGEBRA_TOL and the saved fold within STORAGE_TOL, the run's KL;
float32 differences reported).  Any failed check fails the analysis.
Contrasts (first - second, paired within f0):
  the fork family    start_minus_f0, continuation_minus_start, minus_f0, routed_minus_ordinary,
                     ordinary_minus_frozen, frozen_minus_folded, carry_minus_reset, fork_minus_compact_2U / _4U
  the arms           arm_minus_arm (parent "arms", fork trajectory_end or removal_end): routed against all, routed
                     against the late head, all against the late head (A), routed against all (B); minus_f0 and
                     minus_compact_2U (trajectory ends) / minus_compact_4U (removal ends, labelled: unequal updates)
Each with _by_draw and _summary (seeds averaged within a draw, 95% t intervals over draws); _central as
fork_continuation's.  Exploratory, apart from the registry's hypotheses (configs/v65_image_registry.json, read by
v66 as configs/v66_image_registry.json).
v66: the saved after-fold start passes check_ckpt before any numerical test; non-finite values fail every comparison;
a normalised first layer is measured only when its targets are attained within NORM_TOL (otherwise withheld and
listed); wave 32's reset-matched compact controls are measured as compact_reset with fork_minus_compact_reset.

usage: image_forks.py RESULTS OUT_PREFIX --manifest M [--data-root D] [--device cpu|cuda] [--strict]
                      [--eval-batch N] [--recorded-device DEV]
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import coordinated_edits as CE  # noqa: E402
import f0_panel as FP  # noqa: E402
import fork_continuation as FC  # noqa: E402
import selective_reversal as SR  # noqa: E402
from cop.graph import edits as E  # noqa: E402
from cop.graph.accounting import architecture_hash  # noqa: E402

torch = SR.torch
AC = SR.AC
Fail = SR.Fail
GraphNet = SR.GraphNet

ANALYSIS_SCHEMA = "image_forks/v68"
STATUS = "exploratory reanalysis of existing checkpoints (no network is trained or fitted)"
PARTS = ("test", "val", "val_indep", "shift")
NORMALISED = ("state_at_f0_block_row_norms_f0_bias", "state_at_f0_row_norms_f0_bias")
CENTRAL = ("native_test_err", "extraction_test_err", "state_at_f0_block_row_norms_f0_bias_test_err",
           "state_at_f0_row_norms_f0_bias_test_err", "native_shortcut_flip_rate", "extraction_shortcut_flip_rate")
ARM_PAIRS = (("A_routed_affine", "A_all_affine"), ("A_routed_affine", "A_head_all_relu"),
             ("A_all_affine", "A_head_all_relu"), ("B_routed_affine", "B_all_affine"))
CONTRAST_KEYS = FC.CONTRAST_KEYS
STATE_KEYS = FC.STATE_KEYS


def first_conv(g):
    """(pkey, weight key, bias key) of the first backbone convolution in topological order."""
    for n in g.topo_order(g.live_nodes()):
        nd = g.nodes[n]
        if nd.pkey is not None and nd.owner is None:
            if nd.op != "conv":
                raise Fail(f"the first backbone layer is {nd.op}, not a convolution")
            return nd.pkey, f"mods.{nd.pkey}.weight", f"mods.{nd.pkey}.bias"
    raise Fail("no backbone layer")


def backbone_params(g) -> list:
    """the backbone's parametric nodes in topological order: [(op, pkey)]."""
    return [(g.nodes[n].op, g.nodes[n].pkey) for n in g.topo_order(g.live_nodes())
            if g.nodes[n].pkey is not None and g.nodes[n].owner is None]


def row_block_norms(W, idx):
    """per output channel, the norm over the input channels idx and every kernel position."""
    return W[:, idx].double().reshape(W.shape[0], -1).norm(dim=1)


def scale_rows(W, idx, target):
    """W's kernels on input channels idx scaled, per output channel, to the target norms -> (W', unmatched)."""
    s = row_block_norms(W, idx)
    f = torch.where(s > 0, target.double() / s.clamp_min(1e-300), torch.ones_like(s))
    out = W.clone()
    out[:, idx] = (W[:, idx].double() * f.view(-1, *([1] * (W.dim() - 1)))).to(W.dtype)
    return out, int(((s == 0) & (target > 0)).sum())


def norm_miss(name: str, We, W0, W, blocks) -> dict:
    """(v66 / v68) FC.norm_check of a normalised first layer, per output channel and block, or per output channel
    over all inputs."""
    groups = list(blocks.values()) if "block_row" in name else [torch.arange(W.shape[1], device=W.device)]
    return FC.norm_check([tuple(row_block_norms(x, idx) for x in (We, W0, W)) for idx in groups])


def normalised_layers(W, b, W0, b0, blocks) -> dict:
    """{name: (weight, bias, unmatched)}: the state's kernels at f0's norms per output channel and block (and over
    all inputs), with f0's bias."""
    out = {}
    Wb, nb = W.clone(), 0
    for idx in blocks.values():
        Wb, n_ = scale_rows(Wb, idx, row_block_norms(W0, idx))
        nb += n_
    out["state_at_f0_block_row_norms_f0_bias"] = (Wb, b0, nb)
    allc = torch.arange(W.shape[1], device=W.device)
    Wr, nr = scale_rows(W, allc, row_block_norms(W0, allc))
    out["state_at_f0_row_norms_f0_bias"] = (Wr, b0, nr)
    return out


def shape_summary(W, W0, b, b0, blocks) -> dict:
    def fro(x):
        return float(x.double().norm())

    def ratio(a, c):
        return (a / c) if c > 0 else None
    d = {"layer_norm_ratio": ratio(fro(W), fro(W0)),
         "layer_cos_to_f0": float((W.double() * W0.double()).sum()) / max(1e-300, fro(W) * fro(W0)),
         "change_over_f0_norm": ratio(fro(W.double() - W0.double()), fro(W0)),
         "bias_change_over_f0_norm": ratio(fro(b.double() - b0.double()), fro(b0))}
    for name, idx in blocks.items():
        d[f"{name}_norm_ratio"] = ratio(fro(W[:, idx]), fro(W0[:, idx]))
    return d


def merge_group(g):
    """the one top-level addition of a state and the backbone node reading its merge."""
    tops = FC.top_additions(g)
    if len(tops) != 1:
        raise Fail(f"{len(tops)} top-level additions; this panel has one cut")
    G = tops[0]
    cons = g.consumers(g.implants[G].exit)
    if len(cons) != 1:
        raise Fail(f"the merge has {len(cons)} readers")
    return G, cons[0][0]


def fold_start_audit_img(res, ep, cks, g_start, g_snap, n_opt) -> tuple:
    """the saved after-fold start of an image fork (see the module docstring) -> (passed, detail)."""
    fs = res.get("fold_start") or {}
    lin = cks.get("lineage") or {}
    evs = [e for e in (res.get("schedule_audit") or {}).get("events") or [] if e.get("event") == "fold_unrouted"]
    why = []
    if not fs or fs.get("checkpoint") != "event_after_fold" or int(fs.get("update", -1)) != 0:
        why.append(f"fold_start record {fs}")
    if lin.get("param_hash") != fs.get("param_hash") or lin.get("graph_hash") != fs.get("graph_hash"):
        why.append("the saved checkpoint's hashes are not the recorded ones")
    if len(evs) != 1 or evs[0].get("checkpoint") != "event_after_fold":
        why.append(f"{len(evs)} fold events")
    if any(im.nodes for im in g_start.implants.values()) or \
            any(g_start.nodes[n].op == "mask_grad" for n in g_start.live_nodes()):
        why.append("additions or gradient masks left in the saved checkpoint")
    if architecture_hash(g_start) != ep.get("f0_architecture_hash") or \
            fs.get("architecture_hash") != ep.get("f0_architecture_hash"):
        why.append("its architecture is not f0's")
    G, recv = merge_group(g_snap)
    if g_snap.nodes[recv].op != "linear":
        why.append(f"the merge is read by {g_snap.nodes[recv].op}, not a 1x1 layer")
        return False, "; ".join(why)
    region = g_snap.region(G)
    if not E.region_is_affine(g_snap, set(region) - set(E.grad_mask_nodes(g_snap, region))):
        why.append("the snapshot's merge is not affine")
        return False, "; ".join(why)
    A, c = E.affine_map(g_snap, g_snap.implants[G].entry, g_snap.implants[G].exit, region)
    A, c = A.double().cpu(), c.double().cpu()
    if not (bool(torch.isfinite(A).all()) and bool(torch.isfinite(c).all())):
        why.append("the snapshot's merge map is not finite")
        return False, "; ".join(why)
    ss = {k: t.double().cpu() for k, t in g_snap.state_dict().items()}
    sf = {k: t.double().cpu() for k, t in g_start.state_dict().items()}
    pb_snap, pb_start = backbone_params(g_snap), backbone_params(g_start)
    if [o for o, _ in pb_snap] != [o for o, _ in pb_start]:
        why.append(f"backbone layers {[o for o, _ in pb_start]}, the snapshot has {[o for o, _ in pb_snap]}")
        return False, "; ".join(why)
    rk = g_snap.nodes[recv].pkey
    k_idx = [pk for _, pk in pb_snap].index(rk)
    W, b = ss[f"mods.{rk}.weight"], ss[f"mods.{rk}.bias"]
    Wf, bf = W @ A, b + W @ c
    pk_f = pb_start[k_idx][1]
    dW = float((sf[f"mods.{pk_f}.weight"] - Wf).abs().max()) / max(1.0, float(Wf.abs().max()))
    db = float((sf[f"mods.{pk_f}.bias"] - bf).abs().max()) / max(1.0, float(bf.abs().max()))
    if not (FC.within(dW, FC.COMPOSE_TOL) and FC.within(db, FC.COMPOSE_TOL)):
        why.append(f"the receiving layer is not W A, b + W c (relative {dW:.3g}, {db:.3g})")
    for i, ((_, p_s), (_, p_f)) in enumerate(zip(pb_snap, pb_start)):
        if i == k_idx:
            continue
        for what in ("weight", "bias"):
            a_, b_ = ss.get(f"mods.{p_s}.{what}"), sf.get(f"mods.{p_f}.{what}")
            if (a_ is None) != (b_ is None) or (a_ is not None and not torch.equal(a_, b_)):
                why.append(f"backbone layer {p_s} ({what}) changed at the fold")
    n_c = sum(1 for _ in g_start.parameters())
    if not n_opt or any(f_ != (n_c, n_c) for f_ in n_opt):
        why.append(f"optimizer tensors / with state at the first update {n_opt}, the compact network has {n_c}")
    return not why, ("; ".join(why) if why else
                     f"saved after-fold checkpoint {fs.get('param_hash')}: receiving layer = W A, b + W c (relative "
                     f"{dW:.2g}, {db:.2g}), other layers unchanged, no additions or masks, f0's architecture")


def arm_jobs(mcfg: dict) -> dict:
    """{f0: {arm: {"traj": id, "removal": id}}} from the X25 treated linear removals."""
    out = defaultdict(dict)
    for rid, c in mcfg.items():
        d = c.get("design") or {}
        if c.get("kind") != "dissipation" or d.get("family") != "X25" or d.get("arm") != "treated":
            continue
        tid = (c.get("parents") or {}).get("trajectory")
        if tid not in mcfg:
            raise Fail(f"{rid}: its trajectory is not in the manifest")
        bid = (mcfg[tid].get("parents") or {}).get("baseline")
        if d["variant"] in out[bid]:
            raise Fail(f"f0 {bid}: two removals of {d['variant']}")
        out[bid][d["variant"]] = {"traj": tid, "removal": rid}
    return dict(out)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("results")
    ap.add_argument("out")
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--strict", action="store_true", help="exit 1 unless every f0 is analysed and every audit passed")
    ap.add_argument("--eval-batch", type=int, default=None,
                    help="v66: evaluation batch size for this analysis (recorded; default: each job's eval_batch)")
    ap.add_argument("--recorded-device", default=None,
                    help="also evaluate each saved fold against its snapshot in float32 on this device (reported)")
    a = ap.parse_args(argv)
    dev = torch.device(a.device)
    if dev.type == "cuda" and not torch.cuda.is_available():
        print("--device cuda requested but CUDA is not available", file=sys.stderr)
        return 2
    rec_dev = torch.device(a.recorded_device) if a.recorded_device else None
    if rec_dev is not None and rec_dev.type == "cuda" and not torch.cuda.is_available():
        print("--recorded-device cuda requested but CUDA is not available", file=sys.stderr)
        return 2
    runs = Path(a.results) / "runs"
    mcfg = {e["run_id"]: e["cfg"] for e in AC.manifest_entries(a.manifest)}
    cov = {"tool": "image_forks", "analysis_schema": ANALYSIS_SCHEMA, "status": STATUS,
           "results": str(Path(a.results).resolve()), "manifest": a.manifest,
           "manifest_sha256": CE.sha256_file(a.manifest),
           "source_sha256": {p.name: CE.sha256_file(p) for p in (Path(__file__), Path(FC.__file__),
                                                                 Path(SR.__file__))},
           "numerics": CE.numerics_policy(dev),
           "definitions": {"continuations": list(FC.CONTS), "named_contrasts": {n_: [a_, b_] for n_, a_, b_, _ in
                                                                                 FC.NAMED},
                           "arm_pairs": [list(p) for p in ARM_PAIRS], "normalised": list(NORMALISED),
                           "parts": list(PARTS), "audit_checks": list(FC.AUDIT_CHECKS),
                           "fold_algebra_tol": FC.ALGEBRA_TOL, "fold_storage_tol": FC.STORAGE_TOL,
                           "fold_kl_tol": FC.FOLD_KL_TOL, "compose_tol": FC.COMPOSE_TOL,
                           "interpretation": "folding moves the additions' computation into the receiving layer by "
                                             "algebra: a successful folded continuation does not by itself show "
                                             "that the original backbone learned to replace the additions",
                           "late_head": "A_head_all_relu: ReLU additions on the pooled features before the "
                                        "classifier, every example's gradient (a temporary head with a skip "
                                        "connection, removed by the linear removal)"},
           "expected_f0": 0, "analysed_f0": 0, "failed": []}
    out = defaultdict(list)
    want = {}
    try:
        jobs = FC.fork_jobs(mcfg)
        arms = arm_jobs(mcfg)
        shapes = {(p, s, tuple(sorted(c))) for v in jobs.values() for p, j in v.items() for s, c in j["forks"].items()}
        parents = sorted({p for p, _, _ in shapes})
        forks = sorted({s for _, s, _ in shapes}, key=lambda s_: int(s_.split("_")[1]))
        arm_names = sorted({k for v in arms.values() for k in v})
        if not jobs or shapes != {(p, s, tuple(sorted(FC.CONTS))) for p in parents for s in forks} or \
                any(set(v) != set(parents) for v in jobs.values()) or set(arms) != set(jobs) or \
                any(set(v) != set(arm_names) for v in arms.values()) or not set(parents) <= set(arm_names):
            raise Fail("the manifest is not a complete wave-30 design (every f0: every arm, parent, fork and "
                       "continuation)")
    except Fail as ex_:
        cov["failed"].append({"f0": None, "reason": str(ex_)})
        print(f"FAIL: {ex_}", file=sys.stderr)
        jobs, arms, parents, forks, arm_names = {}, {}, [], [], []
    cov["expected_f0"] = len(jobs)
    cov["design"] = {"arms": arm_names, "parents": parents, "forks": forks, "continuations": list(FC.CONTS)}
    bundles, rec_bundles = {}, {}
    for n_done, bid in enumerate(sorted(jobs), 1):
        staged = defaultdict(list)
        try:
            J, AJ = jobs[bid], arms[bid]
            cfgs = {}
            for arm, j in AJ.items():
                for rid in (j["traj"], j["removal"]):
                    why = AC.declared_invalid(runs / rid, mcfg[rid])
                    if why:
                        raise Fail(f"{rid}: declared invalid ({why})")
                    cfgs[rid] = AC.job_config(runs, rid, mcfg[rid])
            for p_, j in J.items():
                if j["traj"] != AJ[p_]["traj"]:
                    raise Fail(f"f0 {bid}: {p_}'s forks and removal descend from different trajectories")
                for s_, cs in j["forks"].items():
                    for c_, rid in cs.items():
                        why = AC.declared_invalid(runs / rid, mcfg[rid])
                        if why:
                            raise Fail(f"{rid}: declared invalid ({why})")
                        cfgs[rid] = AC.job_config(runs, rid, mcfg[rid])
            dkeys = {json.dumps(c["data"], sort_keys=True) for c in cfgs.values()}
            if len(dkeys) != 1:
                raise Fail(f"f0 {bid}: its jobs differ in data")
            dk = dkeys.pop()
            if dk not in bundles:
                # one image bundle at a time (each f0 has its own draw; several would not fit on the device)
                bundles.clear()
                rec_bundles.clear()
                if dev.type == "cuda":
                    torch.cuda.empty_cache()
                b0 = SR.load_bundle(json.loads(dk), a.data_root, device="cpu")
                bundles[dk] = (b0.to(dev), b0.hashes())
            b, hashes = bundles[dk]
            parts = b.partitions()
            if b.layout != "img" or int(b.out_dim) != 2 or "val_indep" not in parts or "cf_base" not in parts:
                raise Fail(f"f0 {bid}: needs the two-class image shortcut task")
            need = {"train", *AC.eval_partitions(b)}
            batch = int(a.eval_batch or (cfgs[AJ[arm_names[0]]["traj"]].get("train") or {}).get("eval_batch", 4096))
            # ---- f0: every trajectory's reference copy must be one network
            f0k, ids, ref = None, set(), {}
            for arm in arm_names:
                tid = AJ[arm]["traj"]
                AC.check_logged_data(runs / tid, hashes, need, f"{tid} data provenance")
                k = SR.ckp(runs / tid, "baseline_ref")
                gk = AC.check_ckpt(k, f"{arm} f0", run_id=tid, stage="baseline_ref", cfg=cfgs[tid], hashes=hashes,
                                   need=need)
                ids.add((AC.param_hash_of(k), gk.structural_hash()))
                ref[arm] = k
                f0k = f0k or k
            if len(ids) != 1:
                raise Fail(f"f0 {bid}: the trajectories do not start from one network")
            f0 = GraphNet.from_checkpoint(f0k["model"], dev).eval()
            f0_sd = {k: t.clone() for k, t in f0.state_dict().items()}
            pk0, wk0, bk0 = first_conv(f0)
            W0, b0 = f0_sd[wk0], f0_sd[bk0]
            lay = (b.meta or {}).get("feature_layout") or {}
            c0, c1 = lay["causal"]
            blocks = {"causal": torch.arange(int(c0), int(c1), device=W0.device),
                      "shortcut": torch.tensor([int(lay["shortcut"])], device=W0.device)}
            if sorted(torch.cat(list(blocks.values())).tolist()) != list(range(W0.shape[1])):
                raise Fail(f"f0 {bid}: the feature layout does not cover the first layer's input channels")
            bcfg = AC.job_config(runs, bid, mcfg.get(bid))
            contrast = ((cfgs[AJ[arm_names[0]]["removal"]].get("design") or {}).get("contrast") or "")
            meta = {"f0": bid, "design_id": f"{contrast}#" + SR.stable_hash(
                        {"data": CE._no_seeds(bcfg.get("data")), "model": bcfg.get("model"),
                         "train": bcfg.get("train"), "arms": arm_names, "forks": forks})[:8],
                    "f0_param_hash": next(iter(ids))[0], "data_draw": (bcfg.get("data") or {}).get("data_seed"),
                    "optimizer_seed": (bcfg.get("seeds") or {}).get("optimizer")}
            names_eval = [p for p in PARTS if p in parts] + ["train", "cf_base", "cf_shortcut"]

            def build(W, bias):
                m_ = GraphNet.from_checkpoint(f0k["model"], dev).eval()
                want_ = dict(m_.state_dict())
                want_[wk0] = W.to(want_[wk0].device, want_[wk0].dtype)
                want_[bk0] = bias.to(want_[bk0].device, want_[bk0].dtype)
                m_.load_state_dict(want_)
                m_._plan = None
                CE.verify_patch(m_.state_dict(), want_, "image forks: extraction build")
                return m_

            def errs(m, prefix):
                o, pr = AC.finite_eval(m, b, names_eval, batch, "image forks")
                ytr = parts["train"].y.to(dev).long()
                r = {f"{prefix}_{p}_err": o[f"{p}_err"] for p in PARTS if f"{p}_err" in o}
                r[f"{prefix}_train_loss"] = float(torch.nn.functional.cross_entropy(pr["train"].double(), ytr))
                r[f"{prefix}_shortcut_flip_rate"] = o.get("shortcut_flip_rate")
                return r

            def measure(parent, fork, state, g):
                _, wk, bkk = first_conv(g)
                sd = g.state_dict()
                W, bias = sd[wk].clone(), sd[bkk].clone()
                if W.shape != W0.shape or bias.shape != b0.shape:
                    raise Fail(f"{parent} {fork} {state}: its first layer does not have f0's shape")
                row = {**meta, "parent": parent, "fork": fork, "state": state, **errs(g, "native"),
                       **errs(build(W, bias), "extraction"), **shape_summary(W, W0, bias, b0, blocks)}
                for e_, (We, be, nu) in normalised_layers(W, bias, W0, b0, blocks).items():
                    er = errs(build(We, be), e_)
                    nc = norm_miss(e_, We, W0, W, blocks)
                    ok_ = nu == 0 and nc["failed_rows"] == 0 and math.isfinite(nc["max_abs"])   # v68: per row
                    row.update(er if ok_ else {k_: None for k_ in er})
                    row[f"{e_}_unmatched"] = nu
                    row[f"{e_}_norm_miss"] = nc["max_rel"]
                    row[f"{e_}_norm_max_abs"] = nc["max_abs"]
                    row[f"{e_}_norm_failed_rows"] = nc["failed_rows"]
                    row[f"{e_}_eligible"] = ok_
                row["has_additions"] = any(g.nodes[n].owner is not None for n in g.live_nodes())
                staged["states"].append(row)
                return row

            n_states = 0
            measure("f0", "f0", "f0", f0)
            n_states += 1
            u2 = None
            for arm in arm_names:
                tid, rid = AJ[arm]["traj"], AJ[arm]["removal"]
                tcfg = cfgs[tid]
                u2a = int(tcfg["growth"]["updates_per_round"]) * int(tcfg["growth"]["rounds"])
                if u2 not in (None, u2a):
                    raise Fail(f"f0 {bid}: arms of different lengths")
                u2 = u2a
                end = SR.ckp(runs / tid, "final")
                AC.check_ckpt(end, f"{arm} end", run_id=tid, stage="final", cfg=tcfg, hashes=hashes, need=need)
                CE.check_age(AC.job_update(end, ref[arm], f"{arm} end"), u2, tid)
                ge = GraphNet.from_checkpoint(end["model"], dev).eval()
                if not measure(arm, "end", "trajectory_end", ge)["has_additions"]:
                    raise Fail(f"{tid}: the expansion's end has no additions")
                rd = runs / rid
                ep = json.loads((rd / "endpoint.json").read_text()) if (rd / "endpoint.json").exists() else None
                if ep is None or ep.get("diverged") or ep.get("numerically_valid") is False:
                    raise Fail(f"{rid}: endpoint missing, diverged or recorded numerically invalid")
                AC.check_logged_data(rd, hashes, need, f"{rid} data provenance")
                ck = SR.ckp(rd, ep["checkpoint"])
                AC.check_ckpt(ck, f"{arm} removal", run_id=rid, stage=ep["checkpoint"], cfg=cfgs[rid],
                              hashes=hashes, need=need)
                gr = GraphNet.from_checkpoint(ck["model"], dev).eval()
                if any(im.nodes for im in gr.implants.values()) or architecture_hash(gr) != architecture_hash(f0):
                    raise Fail(f"{rid}: the removal's export is not f0's architecture")
                measure(arm, "end", "removal_end", gr)
                n_states += 2
            for parent in parents:
                tid = J[parent]["traj"]
                tcfg = cfgs[tid]
                held = (tcfg.get("train") or {}).get("freeze_inputs") == "shortcut"
                sc = int(lay["shortcut"])
                for fork in forks:
                    u = int(fork.split("_")[1])
                    st = SR.ckp(runs / tid, fork)
                    if st is None:
                        raise Fail(f"{tid}: no saved state {fork}")
                    AC.check_ckpt(st, f"{parent} {fork}", run_id=tid, stage=fork, cfg=tcfg, hashes=hashes,
                                  need=need)
                    CE.check_age(AC.job_update(st, ref[parent], f"{parent} {fork}"), u, tid)
                    g_st = GraphNet.from_checkpoint(st["model"], dev).eval()
                    measure(parent, fork, "start", g_st)
                    n_states += 1
                    snap_h = FC.snapshot_hash(st)
                    streams = {}
                    for cn in FC.CONTS:
                        rid = J[parent]["forks"][fork][cn]
                        rd = runs / rid
                        ep = json.loads((rd / "endpoint.json").read_text()) if (rd / "endpoint.json").exists() else None
                        if ep is None or ep.get("diverged") or ep.get("numerically_valid") is False:
                            raise Fail(f"{rid}: endpoint missing, diverged or recorded numerically invalid")
                        if int(ep["updates"]) != u2 - u:
                            raise Fail(f"{rid}: {ep['updates']} updates, expected {u2 - u}")
                        AC.check_logged_data(rd, hashes, need, f"{rid} data provenance")
                        ck = SR.ckp(rd, ep["checkpoint"])
                        AC.check_ckpt(ck, f"{parent} {fork} {cn}", run_id=rid, stage=ep["checkpoint"], cfg=cfgs[rid],
                                      hashes=hashes, need=need)
                        if AC.param_hash_of(ck) != ep["checkpoint_param_hash"]:
                            raise Fail(f"{rid}: the end checkpoint is not the one endpoint.json names")
                        g = GraphNet.from_checkpoint(ck["model"], dev).eval()
                        if cn == "folded_reset" and architecture_hash(g) != architecture_hash(f0):
                            raise Fail(f"{rid}: the folded network does not have f0's architecture")
                        row = measure(parent, fork, cn, g)
                        if row["has_additions"] != (cn in FC.WITH_ADDITIONS):
                            raise Fail(f"{rid}: {cn} {'without' if cn in FC.WITH_ADDITIONS else 'with'} additions")
                        n_states += 1
                        res = json.loads((rd / "dissipation_result.json").read_text())
                        s1 = {k: t.cpu() for k, t in ck["model"]["state"].items()}
                        aud, outcome = FC.audit_fork(cn, res, ep, u2 - u, snap_h, g_st, st, s1, wk0, sc, held,
                                                     tcfg["train"])
                        if cn == "folded_reset":
                            cks = SR.ckp(rd, "event_after_fold")
                            names = [p for p in PARTS if p in parts] + ["train"]
                            if cks is None:
                                aud["fold_start"] = (False, "no saved after-fold checkpoint (event_after_fold)")
                                g_fs = None
                            else:
                                integ = FC.event_integrity(cks, f"{rid} event_after_fold", rid, "event_after_fold",
                                                           cfgs[rid], hashes, need)
                                g_fs = GraphNet.from_checkpoint(cks["model"], dev).eval()
                                n_opt = [((p.get("optimizer_audit") or {}).get("after_first_update") or {})
                                         for p in (res.get("schedule_audit") or {}).get("phases") or []]
                                fa_ = fold_start_audit_img(
                                    res, ep, cks, g_fs, g_st,
                                    [(f_.get("tensors"), f_.get("tensors_with_state")) for f_ in n_opt])
                                aud["fold_start"] = (integ[0] and fa_[0], f"{integ[1]}; {fa_[1]}")
                            pa = next((x for x in res.get("path") or [] if x.get("tag") == "after_fold"), None)
                            kl = float(pa["val_kl_receiver_to_model"]) if pa is not None else None
                            st64 = FC.as64(g_st)
                            alg = FC.rel_logit_change(FC.refold(st64).eval(), st64, parts, names, batch)
                            sto = FC.rel_logit_change(FC.as64(g_fs), st64, parts, names, batch) \
                                if g_fs is not None else None
                            fwd = FC.rel_logit_change(g_fs, g_st, parts, names, batch) if g_fs is not None else None
                            dev_r = None
                            if rec_dev is not None and g_fs is not None:
                                if dk not in rec_bundles:
                                    rec_bundles[dk] = SR.load_bundle(json.loads(dk), a.data_root,
                                                                     device="cpu").to(rec_dev).partitions()
                                dev_r = FC.rel_logit_change(GraphNet.from_checkpoint(cks["model"], rec_dev).eval(),
                                                            GraphNet.from_checkpoint(st["model"], rec_dev).eval(),
                                                            rec_bundles[dk], names, batch)
                            ok = FC.within(kl, FC.FOLD_KL_TOL) and FC.within(alg, FC.ALGEBRA_TOL) and \
                                FC.within(sto, FC.STORAGE_TOL) and (fwd is None or math.isfinite(fwd)) and \
                                (dev_r is None or math.isfinite(dev_r))          # v68: deployed computation finite
                            aud["fold_function"] = (ok, f"algebra {alg:.3g}; storage {sto}; float32 {fwd}; on "
                                                        f"{rec_dev} {dev_r}; run KL {kl}")
                            outcome.update({"fold_algebra64": alg, "fold_storage64": sto, "fold_forward32": fwd,
                                            "fold_recorded_device_forward32": dev_r, "fold_run_kl": kl})
                        streams[cn] = (res.get("schedule_audit") or {}).get("batch_id_hash")
                        own = int(((res.get("compute_end") or {}).get("train_macs")) or 0)
                        before = FC._macs(st) - FC._macs(ref[parent])
                        if before <= 0 or own <= 0:
                            raise Fail(f"{rid}: training MACs not recorded (to fork {before}, fork {own})")
                        staged["compute"].append({**meta, "parent": parent, "fork": fork, "state": cn, "run_id": rid,
                                                  "updates_since_f0": u2, "train_macs_to_fork": before,
                                                  "train_macs_fork": own, "train_macs_total": before + own})
                        arow = {**meta, "parent": parent, "fork": fork, "state": cn, "run_id": rid}
                        for k_, (ok_, det_) in aud.items():
                            arow[k_], arow[f"{k_}_detail"] = bool(ok_), det_
                        arow.update({f"outcome_{k_}": v_ for k_, v_ in outcome.items()})
                        staged["audits"].append(arow)
                    shared = len(set(streams.values())) == 1 and None not in streams.values()
                    for arow in staged["audits"][-len(FC.CONTS):]:
                        arow["stream_shared"] = shared
                        arow["stream_shared_detail"] = f"{len(set(streams.values()))} batch-id hashes over the forks"
                        arow["audit_passed"] = all(arow[k_] for k_ in FC.AUDIT_CHECKS)
            # ---- the compact controls (f0 continued with each hold): at 2U and at the control's end
            comps = {r_: c_ for r_, c_ in mcfg.items() if c_.get("kind") == "continue"
                     and (c_.get("design") or {}).get("family") == "X25" and (c_.get("design") or {}).get("arm") == "C1"
                     and (c_.get("parents") or {}).get("baseline") == bid}
            holds = {}
            for arm in arm_names:
                h_ = (cfgs[AJ[arm]["traj"]].get("train") or {}).get("freeze_inputs", "none")
                holds.setdefault(h_, set()).add(arm)
            hold_label = {"none": "A", "shortcut": "B"}
            for h_ in sorted(holds):
                m_ = [r_ for r_, c_ in comps.items() if (c_.get("train") or {}).get("freeze_inputs", "none") == h_]
                if len(m_) != 1:
                    raise Fail(f"f0 {bid}: {len(m_)} compact controls with the hold {h_}")
                rid = m_[0]
                ccfg = AC.job_config(runs, rid, mcfg[rid])
                AC.check_logged_data(runs / rid, hashes, need, f"{rid} data provenance")
                kst = SR.ckp(runs / bid, (ccfg.get("continue") or {}).get("start_stage", "best_val"))
                if kst is None or AC.param_hash_of(kst) != meta["f0_param_hash"]:
                    raise Fail(f"{rid}: the compact control does not start from this f0")
                ulong = int(sum((ccfg.get("continue") or {}).get("segments") or [0]))
                for lab, uu in (("compact_2U", u2), ("compact_4U", ulong)):
                    ck = SR.ckp(runs / rid, f"at_{uu}")
                    if ck is None:
                        raise Fail(f"{rid}: no saved state at update {uu} (at_{uu})")
                    AC.check_ckpt(ck, f"{h_} {lab}", run_id=rid, stage=f"at_{uu}", cfg=ccfg, hashes=hashes,
                                  need=need)
                    if int((ck.get("extra") or {}).get("update", -1)) != uu:
                        raise Fail(f"{rid}: at_{uu} records update {(ck.get('extra') or {}).get('update')}")
                    measure(hold_label[h_], "compact", lab, GraphNet.from_checkpoint(ck["model"], dev).eval())
                    n_states += 1
                    cmc = int(((ck.get("extra") or {}).get("compute") or {}).get("train_macs", 0))
                    if cmc <= 0:
                        raise Fail(f"{rid}: at_{uu} records no training MACs")
                    staged["compute"].append({**meta, "parent": hold_label[h_], "fork": "compact", "state": lab,
                                              "run_id": rid, "updates_since_f0": uu, "train_macs_to_fork": 0,
                                              "train_macs_fork": cmc, "train_macs_total": cmc})
            # ---- v66: the reset-matched compact controls (wave 32), per hold and fork point: f0 continued to the
            # fork point carrying its optimizer state, reset there as the forks are, continued to 2U
            compsr = {r_: c_ for r_, c_ in mcfg.items() if c_.get("kind") == "continue"
                      and (c_.get("design") or {}).get("family") == "X25"
                      and (c_.get("design") or {}).get("arm") == "C1R"
                      and (c_.get("parents") or {}).get("baseline") == bid}
            if compsr:
                for h_ in sorted(holds):
                    for fork in forks:
                        u = int(fork.split("_")[1])
                        m_ = [r_ for r_, c_ in compsr.items()
                              if (c_.get("train") or {}).get("freeze_inputs", "none") == h_
                              and str((c_.get("design") or {}).get("variant", "")).endswith(f"@{fork}")]
                        if len(m_) != 1:
                            raise Fail(f"f0 {bid}: {len(m_)} reset-matched compact controls with the hold {h_} at "
                                       f"{fork}")
                        rid = m_[0]
                        ccfg = AC.job_config(runs, rid, mcfg[rid])
                        cc_ = ccfg.get("continue") or {}
                        if [int(x) for x in cc_.get("segments") or []] != [u, u2 - u] or \
                                list(cc_.get("segment_reset") or []) != [False, True]:
                            raise Fail(f"{rid}: segments {cc_.get('segments')} / resets {cc_.get('segment_reset')}")
                        AC.check_logged_data(runs / rid, hashes, need, f"{rid} data provenance")
                        kst = SR.ckp(runs / bid, cc_.get("start_stage", "best_val"))
                        if kst is None or AC.param_hash_of(kst) != meta["f0_param_hash"]:
                            raise Fail(f"{rid}: the reset-matched compact control does not start from this f0")
                        cres = json.loads((runs / rid / "continue_result.json").read_text())
                        starts = (cres.get("fork_audit") or {}).get("starts") or []
                        if [(int(x.get("segment", -1)), bool(x.get("reset_applied"))) for x in starts] != \
                                [(0, False), (1, True)] or int(starts[1].get("update", -1)) != u:
                            raise Fail(f"{rid}: the optimizer was not carried to update {u} and reset there")
                        ck = SR.ckp(runs / rid, f"at_{u2}")
                        if ck is None:
                            raise Fail(f"{rid}: no saved state at update {u2} (at_{u2})")
                        AC.check_ckpt(ck, f"{h_} {fork} compact_reset", run_id=rid, stage=f"at_{u2}", cfg=ccfg,
                                      hashes=hashes, need=need)
                        if int((ck.get("extra") or {}).get("update", -1)) != u2:
                            raise Fail(f"{rid}: at_{u2} records update {(ck.get('extra') or {}).get('update')}")
                        measure(hold_label[h_], fork, "compact_reset", GraphNet.from_checkpoint(ck["model"], dev).eval())
                        n_states += 1
                        cmc = int(((ck.get("extra") or {}).get("compute") or {}).get("train_macs", 0))
                        if cmc <= 0:
                            raise Fail(f"{rid}: at_{u2} records no training MACs")
                        staged["compute"].append({**meta, "parent": hold_label[h_], "fork": fork,
                                                  "state": "compact_reset", "run_id": rid, "updates_since_f0": u2,
                                                  "train_macs_to_fork": 0, "train_macs_fork": cmc,
                                                  "train_macs_total": cmc})
            want[bid] = n_states
            # ---- contrasts
            rows = {(r["parent"], r["fork"], r["state"]): r for r in staged["states"]}
            f0row = rows[("f0", "f0", "f0")]
            skip = set(meta) | {"parent", "fork", "state", "has_additions"}
            metrics = sorted({k for r in staged["states"] for k, v in r.items() if k not in skip
                              and isinstance(v, (int, float)) and not isinstance(v, bool)})

            def con(comparison, r1, r2, parent=None, fork=None):
                for m_ in metrics:
                    x1, x2 = r1.get(m_), r2.get(m_)
                    if x1 is None or x2 is None:
                        continue
                    staged["contrasts"].append({**meta, "parent": parent or r1["parent"], "fork": fork or r1["fork"],
                                                "comparison": comparison,
                                                "first": r1["parent"] if parent == "arms" else r1["state"],
                                                "second": r2["parent"] if parent == "arms" else r2["state"],
                                                "metric": m_, "first_value": x1, "second_value": x2,
                                                "value": x1 - x2, "sign": "first - second",
                                                "depends_on": FC.state_keys(r1, r2)})
            hold_of = {arm: hold_label[h_] for h_, s_ in holds.items() for arm in s_}
            for parent in parents:
                hl = hold_of[parent]
                for fork in forks:
                    st0 = rows[(parent, fork, "start")]
                    con("start_minus_f0", st0, f0row)
                    cr_ = rows.get((hl, fork, "compact_reset"))
                    for cn in FC.CONTS:
                        con("continuation_minus_start", rows[(parent, fork, cn)], st0)
                        con("minus_f0", rows[(parent, fork, cn)], f0row)
                        for lab in ("compact_2U", "compact_4U"):
                            con(f"fork_minus_{lab}", rows[(parent, fork, cn)], rows[(hl, "compact", lab)])
                        if cr_ is not None:
                            # v66: against the compact network with the forks' reset schedule (row parent: the arm)
                            con("fork_minus_compact_reset", rows[(parent, fork, cn)], cr_)
                    for name_, first_, second_, _ in FC.NAMED:
                        con(name_, rows[(parent, fork, first_)], rows[(parent, fork, second_)])
            for arm in arm_names:
                hl = hold_of[arm]
                te, re_ = rows[(arm, "end", "trajectory_end")], rows[(arm, "end", "removal_end")]
                con("minus_f0", te, f0row)
                con("minus_f0", re_, f0row)
                con("minus_compact_2U", te, rows[(hl, "compact", "compact_2U")])
                con("minus_compact_4U", re_, rows[(hl, "compact", "compact_4U")])
            for x_, y_ in ARM_PAIRS:
                if x_ in arm_names and y_ in arm_names:
                    for stt in ("trajectory_end", "removal_end"):
                        con("arm_minus_arm", rows[(x_, "end", stt)], rows[(y_, "end", stt)], parent="arms",
                            fork=stt)
            for hl in sorted(set(hold_of.values())):
                for lab in ("compact_2U", "compact_4U"):
                    con("minus_f0", rows[(hl, "compact", lab)], f0row)
            cmac = {(r_["parent"], r_["state"]): r_["train_macs_total"] for r_ in staged["compute"]
                    if r_["fork"] == "compact"}
            for r_ in staged["compute"]:
                if r_["fork"] != "compact" and r_["state"] != "compact_reset":
                    for lab in ("compact_2U", "compact_4U"):
                        cm = cmac.get((hold_of[r_["parent"]], lab))
                        r_[f"{lab}_train_macs"] = cm
                        r_[f"fork_over_{lab}_macs"] = (r_["train_macs_total"] / cm) if cm else None
            for k_, rows_ in staged.items():
                out[k_].extend(rows_)
            cov["analysed_f0"] += 1
            print(f"f0 {n_done}/{len(jobs)} analysed ({n_states} states)", flush=True)
        except Fail as ex_:
            cov["failed"].append({"f0": bid, "reason": str(ex_)})
            print(f"FAIL f0 {bid}: {ex_}", file=sys.stderr)

    Pfx = a.out
    for t_ in ("states", "contrasts", "audits", "compute"):
        SR.atomic_csv(f"{Pfx}_{t_}.csv", out.get(t_, []))
    skip = {"f0", "design_id", "f0_param_hash", "data_draw", "optimizer_seed", "parent", "fork", "state",
            "has_additions", "run_id"}
    long_ = [{**{k: r.get(k) for k in STATE_KEYS + ("data_draw", "optimizer_seed")}, "metric": m, "v": float(v)}
             for r in out["states"] for m, v in r.items()
             if m not in skip and isinstance(v, (int, float)) and not isinstance(v, bool)]
    bd, sm = SR.two_stage(long_, STATE_KEYS + ("metric",), "v")
    SR.atomic_csv(f"{Pfx}_states_by_draw.csv", bd)
    SR.atomic_csv(f"{Pfx}_states_summary.csv", sm)
    bd, sm = SR.two_stage(out["contrasts"], CONTRAST_KEYS, "value")
    SR.atomic_csv(f"{Pfx}_contrasts_by_draw.csv", bd)
    SR.atomic_csv(f"{Pfx}_contrasts_summary.csv", sm)
    pairs = defaultdict(set)
    for r in out["contrasts"]:
        pairs[tuple(r.get(k) for k in CONTRAST_KEYS)].add((r["data_draw"], r["optimizer_seed"]))
    central = []
    for r in sm:
        if r["comparison"] not in ("minus_f0", "start_minus_f0", "continuation_minus_start", "routed_minus_ordinary",
                                   "fork_minus_compact_2U", "fork_minus_compact_4U", "fork_minus_compact_reset",
                                   "arm_minus_arm",
                                   "minus_compact_2U", "minus_compact_4U") or r["metric"] not in CENTRAL:
            continue
        err = r["metric"].endswith("_err")
        central.append({**r, "n_draw_seed_pairs": len(pairs[tuple(r.get(k) for k in CONTRAST_KEYS)]),
                        "gain_points": (-100.0 * float(r["mean_value"])) if err else None,
                        "gain_ci95": (f"[{-100.0 * float(r['ci95_high']):.3f}, {-100.0 * float(r['ci95_low']):.3f}]"
                                      if err and r.get("ci95_low") is not None and r.get("ci95_high") is not None
                                      else None),
                        "reading": "gain_points > 0: the first state has the lower error" if err else
                                   "first minus second"})
    SR.atomic_csv(f"{Pfx}_central.csv", central)
    cnt = defaultdict(int)
    for r in out["states"]:
        cnt[r["f0"]] += 1
    miss = [f"{bid}: {cnt[bid]} states, expected {n}" for bid, n in want.items() if bid in cnt and cnt[bid] != n]
    cov["n_failed"] = len(cov["failed"])
    cov["n_states"] = len(out["states"])
    cov["n_audited_forks"] = len(out["audits"])
    cov["audit_failures"] = [{k: r[k] for k in ("f0", "parent", "fork", "state", "run_id")} |
                             {k: r[f"{k}_detail"] for k in FC.AUDIT_CHECKS if not r[k]}
                             for r in out["audits"] if not r["audit_passed"]]
    cov["n_expected_forks"] = sum(len(J_[p_]["forks"][f_]) for J_ in jobs.values() for p_ in J_
                                  for f_ in J_[p_]["forks"])
    cov["n_passed_forks"] = sum(1 for r in out["audits"] if r["audit_passed"])
    cov["n_failed_forks"] = sum(1 for r in out["audits"] if not r["audit_passed"])
    cov["audit_complete"] = cov["n_expected_forks"] > 0 and len(out["audits"]) == cov["n_expected_forks"]
    if not cov["audit_complete"] and cov["n_expected_forks"]:
        miss.append(f"{len(out['audits'])} fork audits, expected {cov['n_expected_forks']}")
    cov["output_membership_failures"] = miss
    cov["compact_controls"] = sorted({(r["parent"], r["state"]) for r in out["states"] if r["fork"] == "compact"})
    cov["compact_reset_controls"] = sorted({(r["parent"], r["fork"]) for r in out["states"]
                                            if r["state"] == "compact_reset"})
    cov["normalised_ineligible"] = [{k: r[k] for k in ("f0", "parent", "fork", "state")} |
                                    {e_: r.get(f"{e_}_norm_miss") for e_ in NORMALISED}
                                    for r in out["states"] if any(r.get(f"{e_}_eligible") is False
                                                                  for e_ in NORMALISED)]
    cov["eval_batch"] = a.eval_batch
    cov["analysis_complete"] = cov["n_failed"] == 0 and cov["analysed_f0"] > 0 and not miss and \
        cov["analysed_f0"] == cov["expected_f0"]
    cov["passed"] = cov["analysis_complete"] and not cov["audit_failures"]
    cov["fold_precision"] = {k: max([r[f"outcome_{k}"] for r in out["audits"]
                                     if isinstance(r.get(f"outcome_{k}"), float)] or [None],
                                    key=lambda x: -1 if x is None else x)
                             for k in ("fold_algebra64", "fold_storage64", "fold_forward32",
                                       "fold_recorded_device_forward32")}
    cov["design_ids"] = sorted({r["design_id"] for r in out["states"]})
    cov["audit_failure_run_ids"] = sorted(r["run_id"] for r in out["audits"] if not r["audit_passed"])
    cov["outputs_sha256"] = FC.output_bindings(Pfx)
    Path(f"{Pfx}_coverage.json").write_text(json.dumps(cov, indent=1, default=str))
    print(json.dumps({k: cov[k] for k in ("expected_f0", "analysed_f0", "n_failed", "n_states", "n_audited_forks",
                                          "analysis_complete", "passed")} |
                     {"n_audit_failures": len(cov["audit_failures"])}))
    return 1 if (a.strict and not cov["passed"]) else 0


if __name__ == "__main__":
    sys.exit(main())
