#!/usr/bin/env python3
"""v56: where and when does a change in linear accessibility appear along the network and along training?

Analysis only: reads a finished panel (wave 25 or wave 26), trains no network; linear probes are fitted with
component_change's solver and rules.  For every f0 it walks every saved state: f0, every expansion at each
insertion, each configured snapshot and its end, and every compact control at its saved evaluation updates (up to
--compact-multiples x the expansion length).  At every state the same probes are fitted on the activations after
every backbone layer below the output layer, in three representation contexts that are never pooled:

  extracted  f0 with the state's first layer and f0's own later layers (layer k = f0's layer k on that first layer)
  native     the state's actual network (an expansion with its additions).  Where the additions merge, two values
             exist: layer<c> is what the additions read (before the merge) and layer<c>_post_merge is what the
             next backbone layer reads (after it)
  folded     expansions only: the additions replaced by their least-squares affine fit on the training set and
             folded into the layer that reads the merge (coordinated_edits' fold); layers after the merge.  For
             affine additions this is the native network up to rounding

Layer 1 is the same function of the input in every context: it is probed once and written under extracted and
native (shared_with = extracted).

Probes: target label and shortcut_sign, fitted on val_indep (target-distribution labels: a measurement, not a
method), standardised features (fit-set mean and scale), both penalties of component_change; errors on test, val
and shift.  Fits on the training set and raw features are in component_change's tables at 2U; they are left out
here to keep the course to the question asked.

  _states     per state: errors of the actual network (native_*), of its first layer in f0 (extracted_*), of the
              folded network (folded_*) with the affine fit's R^2
  _probes     one row per state, context, layer, target and penalty
  _contrasts  paired within f0, same context, layer and probe: a state minus f0; an expansion minus its matched
              compact control at the same update (when the control has a saved state there); native minus extracted
              at the same layer; after the merge minus before it.  A post-merge or folded layer is compared with
              the other network's ordinary layer of the same index.
Each with _by_draw and _summary (seeds averaged within a draw, 95% t intervals over draws), grouped by design_id.
Everything here is exploratory.

usage: layer_course.py RESULTS OUT_PREFIX --manifest M [--data-root D] [--device cpu|cuda]
                       [--compact-multiples 1[,2]] [--strict]
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import component_change as CC  # noqa: E402
import coordinated_edits as CE  # noqa: E402
import f0_panel as FP  # noqa: E402
import selective_reversal as SR  # noqa: E402

torch = SR.torch
AC = SR.AC
Fail = SR.Fail
GraphNet = SR.GraphNet

ANALYSIS_SCHEMA = "layer_course/v56"
STATUS = "exploratory reanalysis of existing checkpoints (no network is trained; linear probes are fitted)"
TARGETS = CC.TARGETS
FIT = "val_indep"
LAMBDAS = CC.LAMBDAS
EVAL = ("test", "val", "shift")
CONTEXTS = ("extracted", "native", "folded")
ERR_PARTS = ("test", "val", "val_indep", "shift")
STATE_KEYS = ("design_id", "cell", "variant", "kind", "stage", "updates_since_f0")
PROBE_KEYS = STATE_KEYS + ("representation_context", "feature", "layer", "spec")
CONTRAST_KEYS = ("design_id", "cell", "comparison", "variant", "kind", "stage", "updates_since_f0",
                 "representation_context", "feature", "layer", "spec", "metric", "second", "sign")


def spec_of(feature: str, target: str, lam: float) -> str:
    return f"{feature}|{target}|fit={FIT}|standardised|lam={lam:g}"


def probe_rows(F: dict, targets: dict, what: str) -> list:
    """the probes of one feature set: F = {partition: activations}.  -> [row fields] (component_change's rules:
    fit-set standardisation, fit_logistic, decision = score > 0)."""
    for p_, t_ in F.items():
        CC.finite(t_, f"{what} features on {p_}")
    mu, sdv = CC.standardiser(F[FIT])
    Z = {p_: (t_ - mu) / sdv for p_, t_ in F.items()}
    out = []
    for tg in TARGETS:
        for lam in LAMBDAS:
            w, bb, info = CC.fit_logistic(Z[FIT], targets[FIT][tg], lam)
            CC.finite(w, f"{what}: coefficients")
            r = {"target": tg, "lam": lam, "n_features": int(Z[FIT].shape[1]), "fit_n": int(Z[FIT].shape[0]),
                 "fit_err": CC.probe_error(Z[FIT], targets[FIT][tg], w, bb), "fit_loss": info["loss"],
                 "iterations": info["iterations"], "grad_inf": info["grad_inf"],
                 "converged": info["grad_inf"] <= CC.CONVERGED_TOL, "w_norm": float(w.norm())}
            for p in EVAL:
                s_ = CC.probe_scores(Z[p], w, bb)
                CC.finite(s_, f"{what}: scores on {p}")
                r[f"{p}_err"] = float(((s_ > 0).long() != targets[p][tg]).double().mean())
            out.append(r)
    return out


def errors(z: dict, y: dict, prefix: str) -> dict:
    """classification errors from logits per partition."""
    for p, t in z.items():
        CC.finite(t, f"{prefix} logits on {p}")
    return {f"{prefix}_{p}_err": float((z[p].argmax(-1) != y[p]).double().mean()) for p in ERR_PARTS if p in z}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("results")
    ap.add_argument("out")
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--compact-multiples", default="1",
                    help="compact controls are read at every saved evaluation update up to the largest multiple "
                         "of the expansion length 2U given here")
    ap.add_argument("--strict", action="store_true", help="exit 1 unless every f0 is analysed and every probe fitted")
    a = ap.parse_args(argv)
    try:
        mult = sorted({int(x) for x in a.compact_multiples.split(",") if x})
    except ValueError:
        ap.error("--compact-multiples takes integers")
    if not mult or min(mult) < 1:
        ap.error("--compact-multiples must be positive integers")
    dev = torch.device(a.device)
    if dev.type == "cuda" and not torch.cuda.is_available():
        print("--device cuda requested but CUDA is not available", file=sys.stderr)
        return 2
    numerics = CE.numerics_policy(dev)
    cov = {"tool": "layer_course", "analysis_schema": ANALYSIS_SCHEMA, "status": STATUS,
           "results": str(Path(a.results).resolve()), "manifest": a.manifest,
           "manifest_sha256": CE.sha256_file(a.manifest),
           "source_sha256": {p.name: CE.sha256_file(p) for p in (Path(__file__), Path(FP.__file__), Path(CC.__file__),
                                                                 Path(CE.__file__), Path(SR.__file__))},
           "numerics": {**numerics, "probes": "float64 Newton with line search, zero start"},
           "options": {"compact_multiples": mult},
           "definitions": {"contexts": list(CONTEXTS), "targets": list(TARGETS), "fit": FIT,
                           "lambdas": list(LAMBDAS), "eval": list(EVAL), "standardised": True,
                           "stationarity_tolerance_max_abs_gradient": CC.CONVERGED_TOL},
           "expected_f0": 0, "analysed_f0": 0, "failed": [], "probe_not_converged": []}
    out = defaultdict(list)
    want = {}
    try:
        P = FP.open_panel(a.results, a.manifest)
    except Fail as ex_:
        cov["failed"].append({"f0": None, "reason": str(ex_)})
        print(f"FAIL: {ex_}", file=sys.stderr)
        P = None
    jobs = {} if P is None else P.jobs
    cov["expected_f0"] = len(jobs)
    if P is not None:
        cov["design"] = {"expansions": P.exp_lev, "compact_controls": P.comp_lev, "matched_compact": P.matched,
                         "expansion_updates": P.fork_u}
    bundles = {}
    for n_done, bid in enumerate(sorted(jobs), 1):
        staged = defaultdict(list)
        try:
            F = FP.open_f0(P, bid, a.data_root, dev, bundles)
            wk, bk, L = F.wk, F.bk, F.L
            K = len(L)                                       # backbone layers; layers 1..K-1 have activations
            pp = [p for p in ("train", FIT, *EVAL) if p in F.parts]
            xs = {p: F.parts[p].X["x"].to(dev) for p in pp}
            ys = {p: F.parts[p].y.to(dev).long() for p in pp}
            targets = {p: {"label": ys[p], "shortcut_sign": (xs[p][:, F.sc] > 0).long()} for p in pp}
            W0, b0 = F.f0_sd[wk[0]], F.f0_sd[bk[0]]
            rows = {}                                        # (state key, context, feature) -> {spec: row}
            n_states = 0

            def add(skey, smeta, ctx_, feature, layer, Fd, shared=""):
                """fit (or copy) the probes of one feature set and stage their rows."""
                what = f"{skey} {ctx_} {feature}"
                src = rows.get((skey, shared, feature)) if shared else None
                got = {}
                for pr in ([dict(r) for r in src.values()] if src is not None else probe_rows(Fd, targets, what)):
                    spec = spec_of(feature, pr["target"], pr["lam"])
                    r = {**F.meta, **smeta, **{k: v for k, v in pr.items() if k not in F.meta and k not in smeta},
                         "representation_context": ctx_, "feature": feature, "layer": layer, "spec": spec,
                         "shared_with": shared}
                    if not r["converged"]:
                        cov["probe_not_converged"].append({"f0": bid, "state": skey, "context": ctx_, "spec": spec,
                                                           "grad_inf": r["grad_inf"]})
                    got[spec] = r
                    staged["probes"].append(r)
                rows[(skey, ctx_, feature)] = got

            def one_state(skey, smeta, g, with_fold: bool):
                """every context of one saved state."""
                sd = g.state_dict()
                for k_ in (*wk, *bk):
                    if k_ not in sd or sd[k_].shape != F.f0_sd[k_].shape:
                        raise Fail(f"{skey}: its backbone does not have f0's shapes")
                W, bias = sd[wk[0]], sd[bk[0]]
                sites = FP.layer_sites(g, L)
                nat, zn = {}, {}
                for p in pp:
                    vals, zn[p] = FP.node_values(g, F.parts[p], sorted(set(sites.values())), F.batch)
                    nat[p] = {name: vals[node] for name, node in sites.items()}
                ext, ze = {}, {}
                tens = {**F.f0_sd, wk[0]: W, bk[0]: bias}
                for p in pp:
                    acts, ze[p] = CE.mlp_forward(tens, xs[p], wk, bk)
                    ext[p] = {f"layer{k}": acts[k - 1] for k in range(1, K)}
                d1 = float((nat["test"]["layer1"] - ext["test"]["layer1"]).abs().max())
                if d1 > FP.CHAIN_TOL * max(1.0, float(ext["test"]["layer1"].abs().max())):
                    raise Fail(f"{skey}: its first layer's activations differ between the two computations")
                srow = {**F.meta, **smeta, **errors(zn, ys, "native"), **errors(ze, ys, "extracted"),
                        "native_train_loss": float(torch.nn.functional.cross_entropy(zn["train"], ys["train"])),
                        "extracted_train_loss": float(torch.nn.functional.cross_entropy(ze["train"], ys["train"])),
                        "has_merge": any(n.endswith("_post_merge") for n in sites)}
                add(skey, smeta, "extracted", "layer1", 1, {p: ext[p]["layer1"] for p in pp})
                add(skey, smeta, "native", "layer1", 1, None, shared="extracted")
                for k in range(2, K):
                    add(skey, smeta, "extracted", f"layer{k}", k, {p: ext[p][f"layer{k}"] for p in pp})
                    add(skey, smeta, "native", f"layer{k}", k, {p: nat[p][f"layer{k}"] for p in pp})
                merges = sorted(n for n in sites if n.endswith("_post_merge"))
                if len(merges) > 1:
                    raise Fail(f"{skey}: more than one merge on the backbone")
                for name in merges:
                    c = int(name[len("layer"):-len("_post_merge")])
                    add(skey, smeta, "native", name, c, {p: nat[p][name] for p in pp})
                    if not with_fold:
                        continue
                    # the additions' summed output as an affine function of what they read, folded into the reader
                    H, U = nat["train"][f"layer{c}"], nat["train"][name] - nat["train"][f"layer{c}"]
                    M, cvec, _ = CE.affine_fit(H, U)
                    Md, cd = M.to(dev), cvec.to(dev)
                    res = U - (H @ Md.T + cd)
                    sst = float(((U - U.mean(0)) ** 2).sum())
                    srow["fold_fit_r2"] = None if sst <= 0 else 1.0 - float((res ** 2).sum()) / sst
                    Wf, bf = CE.fold_into(sd[wk[c]], sd[bk[c]], M, cvec)
                    ftens = {**{k_: sd[k_] for k_ in (*wk, *bk)}, wk[c]: Wf, bk[c]: bf}
                    fold, zf = {}, {}
                    for p in pp:
                        acts, zf[p] = CE.mlp_forward(ftens, xs[p], wk, bk)
                        fold[p] = {f"layer{k}": acts[k - 1] for k in range(1, K)}
                    srow.update(errors(zf, ys, "folded"))
                    for k in range(c + 1, K):
                        add(skey, smeta, "folded", f"layer{k}", k, {p: fold[p][f"layer{k}"] for p in pp})
                staged["states"].append(srow)

            f0meta = {"variant": "f0", "kind": "f0", "stage": "f0", "updates_since_f0": 0}
            one_state("f0", f0meta, F.f0, False)
            n_states += 1
            ages = defaultdict(dict)                         # variant -> {updates: state key}
            for v in sorted(F.J["exp"]):
                for stage, upd, ck in FP.expansion_states(P, F, v):
                    g = GraphNet.from_checkpoint(ck["model"], dev).eval()
                    if g.gate_vals:
                        raise Fail(f"{v} {stage}: the state has gates")
                    skey = f"{v}@{stage}"
                    one_state(skey, {"variant": v, "kind": "expansion", "stage": stage, "updates_since_f0": upd},
                              g, True)
                    if not staged["states"][-1]["has_merge"]:
                        raise Fail(f"{skey}: an expansion state without a merge on the backbone")
                    ages[v][upd] = skey
                    n_states += 1
            for v in sorted(F.J["comp"]):
                for stage, upd, ck in FP.compact_states(P, F, v, max(mult) * P.fork_u):
                    g = GraphNet.from_checkpoint(ck["model"], dev).eval()
                    skey = f"{v}@{stage}"
                    one_state(skey, {"variant": v, "kind": "compact", "stage": stage, "updates_since_f0": upd},
                              g, False)
                    if staged["states"][-1]["has_merge"]:
                        raise Fail(f"{skey}: a compact control with a merge")
                    ages[v][upd] = skey
                    n_states += 1
            want[bid] = n_states
            # ---- paired contrasts within this f0
            smeta_of = {}
            for (skey, ctx_, feature), got in rows.items():
                smeta_of[skey] = {k: next(iter(got.values()))[k] for k in ("variant", "kind", "stage",
                                                                             "updates_since_f0")}

            def ordinary(feature: str) -> str:
                return feature[:-len("_post_merge")] if feature.endswith("_post_merge") else feature

            def con(comparison, skey, ctx_, feature, other_key, other_ctx, other_feature):
                a_, b_ = rows.get((skey, ctx_, feature)), rows.get((other_key, other_ctx, other_feature))
                if a_ is None or b_ is None:
                    return
                for spec, r in a_.items():
                    o = b_[spec_of(other_feature, r["target"], r["lam"])]
                    for m_ in ("test_err", "val_err"):
                        staged["contrasts"].append({
                            **F.meta, **smeta_of[skey], "comparison": comparison, "representation_context": ctx_,
                            "feature": feature, "layer": r["layer"], "spec": spec, "metric": m_,
                            "first": f"{skey}|{ctx_}|{feature}", "second": f"{other_key}|{other_ctx}|{other_feature}",
                            "first_value": r[m_], "second_value": o[m_], "value": r[m_] - o[m_],
                            "sign": "first - second"})
            for (skey, ctx_, feature) in list(rows):
                if skey == "f0":
                    continue
                sm = smeta_of[skey]
                octx = "native" if ctx_ == "folded" else ctx_
                con("minus_f0", skey, ctx_, feature, "f0", octx, ordinary(feature))
                if sm["kind"] == "expansion":
                    ck_ = ages[P.matched[sm["variant"]]].get(sm["updates_since_f0"])
                    if ck_ is not None:
                        con("minus_matched_compact_same_updates", skey, ctx_, feature, ck_, octx, ordinary(feature))
                if ctx_ == "native" and not feature.endswith("_post_merge"):
                    con("native_minus_extracted", skey, "native", feature, skey, "extracted", feature)
                if ctx_ == "native" and feature.endswith("_post_merge"):
                    con("post_merge_minus_pre_merge", skey, "native", feature, skey, "native", ordinary(feature))
            for k_, rows_ in staged.items():
                out[k_].extend(rows_)
            cov["analysed_f0"] += 1
            print(f"f0 {n_done}/{len(jobs)} analysed ({n_states} states, {len(staged['probes'])} probe rows)",
                  flush=True)
        except Fail as ex_:
            cov["failed"].append({"f0": bid, "reason": str(ex_)})
            cov["probe_not_converged"] = [x for x in cov["probe_not_converged"] if x["f0"] != bid]
            print(f"FAIL f0 {bid}: {ex_}", file=sys.stderr)

    Pfx = a.out
    for t_ in ("states", "probes", "contrasts"):
        SR.atomic_csv(f"{Pfx}_{t_}.csv", out.get(t_, []))

    def long(rows_, keys, metrics):
        return [{**{k: r.get(k) for k in keys + ("data_draw", "optimizer_seed")}, "metric": m, "v": float(r[m])}
                for r in rows_ for m in metrics if r.get(m) is not None]
    smet = tuple(f"{c}_{p}_err" for c in CONTEXTS for p in ERR_PARTS) + ("native_train_loss", "extracted_train_loss",
                                                                         "fold_fit_r2")
    for name, rows_, keys, metrics in (("states", out["states"], STATE_KEYS, smet),
                                       ("probes", out["probes"], PROBE_KEYS,
                                        tuple(f"{p}_err" for p in EVAL) + ("fit_err", "fit_loss"))):
        bd, sm = SR.two_stage(long(rows_, keys, metrics), keys + ("metric",), "v")
        SR.atomic_csv(f"{Pfx}_{name}_by_draw.csv", bd)
        SR.atomic_csv(f"{Pfx}_{name}_summary.csv", sm)
    bd, sm = SR.two_stage(out["contrasts"], CONTRAST_KEYS, "value")
    SR.atomic_csv(f"{Pfx}_contrasts_by_draw.csv", bd)
    SR.atomic_csv(f"{Pfx}_contrasts_summary.csv", sm)
    cnt = defaultdict(int)
    for r in out["states"]:
        cnt[r["f0"]] += 1
    miss = [f"{bid}: {cnt[bid]} states, expected {n}" for bid, n in want.items() if bid in cnt and cnt[bid] != n]
    cov["design_ids"] = sorted({r["design_id"] for r in out["states"]})
    cov["output_membership_failures"] = miss
    cov["n_failed"] = len(cov["failed"])
    cov["n_probe_not_converged"] = len(cov["probe_not_converged"])
    cov["n_states"] = len(out["states"])
    cov["n_probe_rows"] = len(out["probes"])
    cov["passed"] = cov["n_failed"] == 0 and cov["analysed_f0"] > 0 and not miss and \
        cov["analysed_f0"] == cov["expected_f0"] and not cov["probe_not_converged"]
    Path(f"{Pfx}_coverage.json").write_text(json.dumps(cov, indent=1, default=str))
    print(json.dumps({k: cov[k] for k in ("expected_f0", "analysed_f0", "n_failed", "n_probe_not_converged",
                                          "n_states", "n_probe_rows", "passed")}))
    return 1 if (a.strict and not cov["passed"]) else 0


if __name__ == "__main__":
    sys.exit(main())
