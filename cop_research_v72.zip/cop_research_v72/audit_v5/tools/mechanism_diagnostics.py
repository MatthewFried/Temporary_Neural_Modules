"""v66 / v68: what the function-preserving edits of wave 31 change at the start of training, and whether zeroed
branches grow back.

  python audit_v5/tools/mechanism_diagnostics.py RESULTS OUT --manifest MANIFEST [--data-root R] [--device D]
         [--batches K] [--expect-forks snap_1000,snap_2500] [--expect-f0 N] [--strict]

Trains nothing that is kept.  The design it reads is fixed: every f0 of the mechanism panel has the parents
A_routed_affine and B_routed_affine, each with the same fork points (--expect-forks pins them), and at each fork the
continuations routed_reset, ordinary_reset, routed_swap, ordinary_swap, routed_shift50, routed_shift100,
ordinary_shift100.  A missing parent, fork or continuation fails the f0 (it is never read as a smaller design);
v69: every f0 with a routed parent arm is expected (--expect-f0 pins their number), and every path point a run's
own path record lists must be saved as path_u<k> with that update recorded.

Provenance.  The parent's saved split (spec_partition.pt) must equal the split recomputed from its definition
(random_matched: the partition seed's randperm, round(fraction x n) examples in branch a) and the membership hash
every routed fork recorded.  The snapshot, every edited start (routed AND ordinary: same tensors and graph), every
saved path checkpoint and every end pass check_ckpt (recomputed tensor hash, finite, run, stage, configuration, data).

first update   OUT_gradients.csv.  For each fork point, edit (swap, shift50, shift100), mode and precision: the
               snapshot and the edited start each take ONE update of the actual trainer (cop.train.Trainer, the fork
               job's own training configuration, a fresh optimizer configured as the fork configures it, the fork's
               gradient masks: ordinary = none, routed = the parent's split, and the fork's input hold) on the same
               fixed batch, on copies.  Read for the first backbone layer:
                 raw gradient        d loss / dW before any hold (the same forward, masks and loss)
                 optimizer gradient  W.grad as the optimizer used it (held entries zeroed, clipping applied)
                 displacement        W after the update minus W before (held entries restored by the trainer)
               Compared between the edited start and the snapshot: relative change (|e - s| / |s|), cosine, and for
               the displacement the share of entries with the same sign among those nonzero in either.  Trainable
               and held coordinates are reported apart: the held coordinates' displacement must be exactly zero
               (B), otherwise the f0 fails.  A comparison with a zero reference is reported as null with a status
               (zero_reference, both_zero); a non-finite gradient, update or comparison fails the f0.
               precision float32: the training precision (the fork's configuration, the trainer's dtype).
               precision float64: a counterfactual (model and trainer in float64, same everything else) that removes
               evaluation rounding; its inputs are the STORED float32 tensors, so the shift rows keep the rounding
               of the stored W'.
               Supported recipe (otherwise refused): a fresh optimizer per fork phase, the fork's lr schedule giving
               the same rate at update 0 for a one-update segment as for the fork's own length, precision fp32.
               The fixed batches are a seeded permutation of the training partition (the forks' own first
               minibatch is recorded only as a hash).
regrowth       OUT_regrowth.csv.  For routed_shift100, ordinary_shift100 and the unedited routed_reset and
               ordinary_reset, at the start (u = 0), every saved path checkpoint and the end (updates strictly
               increasing; a path point at the end's update must hold the end's tensors), on the test partition in
               float64: the merge's backbone input h read at the group's entry node (input_rms), each branch's
               output rms (branch_rms_<slot>), their aggregate (rms over all branch outputs: sqrt of the sum of
               squares, aggregate_branch_rms), the net added output (rms of the sum, net_branch_rms), the
               cancellation ratio net / aggregate, net and aggregate over input, and the largest |weight| and |bias|
               of the branches' output layers.  shift100 zeros the output weights and biases but keeps them trainable.

Summaries (OUT_coverage.json): seeds averaged within each data draw, then means over draws.  Counts of expected,
observed and failed f0s and rows.  Exit 0 when every f0 was read, 1 with --strict otherwise, 2 on wrong arguments."""
from __future__ import annotations

import argparse
import copy
import csv
import json
import math
import re
import sys
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import torch  # noqa: E402

import fork_continuation as FC  # noqa: E402
import selective_reversal as SR  # noqa: E402
from cop.config import seed_of  # noqa: E402
from cop.experiments.dissipation import retained_mask_ctx  # noqa: E402
from cop.graph import redistribute as RD  # noqa: E402
from cop.graph.graph import GraphNet  # noqa: E402
from cop.train.trainer import Segment, Trainer, lr_at  # noqa: E402
from cop.utils import tensor_hash, torch_gen  # noqa: E402

AC = SR.AC
Fail = AC.Fail
SCHEMA = "mechanism_diagnostics/v69"
PARENTS = ("A_routed_affine", "B_routed_affine")
EDITS = {"swap": ("routed_swap", "ordinary_swap"), "shift50": ("routed_shift50", None),
         "shift100": ("routed_shift100", "ordinary_shift100")}
REQUIRED = ("routed_reset", "ordinary_reset", "routed_swap", "ordinary_swap", "routed_shift50", "routed_shift100",
            "ordinary_shift100")
REGROW = ("routed_shift100", "ordinary_shift100", "routed_reset", "ordinary_reset")
MODES = ("ordinary", "routed")
PRECISIONS = ("float32", "float64")
METRICS = ("raw_grad", "opt_grad_trainable", "disp_trainable")


# ----------------------------------------------------------------------------- comparisons

def compare(e: torch.Tensor, s: torch.Tensor, sign: bool = False) -> dict:
    """edited e against snapshot s.  Non-finite input: Fail (numerical corruption).  A zero reference gives null
    values with a status, never an undifferentiated NaN."""
    if not (bool(torch.isfinite(e).all()) and bool(torch.isfinite(s).all())):
        raise Fail("non-finite gradient or update")
    e, s = e.double().flatten(), s.double().flatten()
    ns, ne = float(s.norm()), float(e.norm())
    out = {"rel": None, "cos": None, "sign": None, "status": "ok", "ref_norm": ns}
    if ns == 0.0 and ne == 0.0:
        out.update(rel=0.0, status="both_zero")
        return out
    if ns == 0.0:
        out["status"] = "zero_reference"
        return out
    out["rel"] = float((e - s).norm()) / ns
    if ne > 0:
        out["cos"] = float(e @ s) / (ne * ns)
    if sign:
        nz = (e != 0) | (s != 0)
        out["sign"] = float((torch.sign(e[nz]) == torch.sign(s[nz])).double().mean())
    for k in ("rel", "cos", "sign"):
        if out[k] is not None and not math.isfinite(out[k]):
            raise Fail(f"non-finite comparison ({k})")
    return out


def first_layer(g) -> str:
    for n in g.topo_order(g.live_nodes()):
        nd = g.nodes[n]
        if nd.pkey is not None and nd.owner is None and any(True for _ in g.mods[nd.pkey].parameters()):
            return nd.pkey
    raise Fail("no first backbone layer")


def held_columns(bundle, tcfg: dict, W: torch.Tensor) -> list:
    """the input columns (channels) the fork holds: the bundle's feature_layout shortcut entry, as the trainer."""
    if tcfg.get("freeze_inputs", "none") == "none":
        return []
    lay = (bundle.meta or {}).get("feature_layout") or {}
    if tcfg["freeze_inputs"] != "shortcut" or "shortcut" not in lay or lay.get("input_rotation"):
        raise Fail(f"unsupported input hold {tcfg['freeze_inputs']!r}")
    c = int(lay["shortcut"])
    if c >= int(W.shape[1]):
        raise Fail("the held column is outside the first layer")
    return [c]


def check_recipe(tcfg: dict, post_updates: int) -> None:
    if tcfg.get("precision") != "fp32":
        raise Fail(f"unsupported precision {tcfg.get('precision')!r} (the diagnostic reproduces fp32 training)")
    if tcfg.get("freeze_backbone", "none") != "none" or tcfg.get("freeze_schedule", "fixed") != "fixed":
        raise Fail("unsupported: a backbone hold or a freeze schedule")
    a = lr_at(0, 1, float(tcfg["lr"]), tcfg["lr_schedule"], tcfg["warmup"])
    b = lr_at(0, int(post_updates), float(tcfg["lr"]), tcfg["lr_schedule"], tcfg["warmup"])
    if a != b:
        raise Fail(f"unsupported lr schedule {tcfg['lr_schedule']!r}: update 0's rate depends on the segment length")


def one_update(g, bundle, tcfg: dict, batch, ctx_fn, dev, dtype) -> dict:
    """one update of the actual trainer on a copy of g, the fork's configuration, a fresh optimizer configured as the
    fork configures it; returns the first layer's raw gradient, optimizer gradient and displacement."""
    m = copy.deepcopy(g).to(dev).to(dtype)
    m._plan = None
    t_ = dict(tcfg)
    if dtype == torch.float64:
        t_["precision"] = "fp64"
    pk = first_layer(m)
    # raw gradient: the same forward, masks and loss, no hold
    raw_m = copy.deepcopy(m)
    raw_m._plan = None
    raw_m.train()
    X = {k: (v.to(dtype) if v.is_floating_point() else v) for k, v in batch.X.items()}
    ctx = ctx_fn(batch) if ctx_fn is not None else {}
    from cop.train.trainer import task_loss
    out = raw_m(X, ctx)
    task_loss(out, batch.y, bundle.task).backward()
    raw = raw_m.mods[pk].weight.grad.detach().clone()
    tr = Trainer(m, bundle, t_, {"minibatch": 0, "augmentation": 0}, str(dev))
    tr.configure("none", None, reset_state=True)
    if tr.opt is None or len(tr.opt.state):
        raise Fail("the optimizer was not fresh")
    tr.next_batch = lambda: batch
    W = m.mods[pk].weight
    before = W.detach().clone()
    rec = {}

    def post(trn, k):
        rec["opt_grad"] = W.grad.detach().clone() if W.grad is not None else torch.zeros_like(W)
    r = tr.run(Segment("diagnostic", 1, batch_ctx=ctx_fn, post_step=post, freeze_inputs=tcfg.get("freeze_inputs")))
    if int(r["updates"]) != 1 or r.get("diverged"):
        raise Fail("the diagnostic update did not complete")
    return {"raw": raw, "opt_grad": rec["opt_grad"], "disp": W.detach() - before}


def split_cols(t: torch.Tensor, cols: list) -> tuple:
    if not cols:
        return t, t.new_zeros(0)
    keep = [c for c in range(int(t.shape[1])) if c not in cols]
    return t[:, keep], t[:, cols]


# ----------------------------------------------------------------------------- regrowth

def branch_stats(g, X) -> dict:
    G = RD.the_group(g)
    pairs = RD.branch_pairs(g, G)
    outs = [(bid, RD._role_node(g, bid, "B")) for pr in pairs for bid in pr]
    entry = g.implants[G].entry
    with torch.no_grad():
        _, nv = g.forward({"x": X}, return_nodes=[entry, *[n for _, n in outs]])
    rms = lambda t: float(t.double().pow(2).mean().sqrt())  # noqa: E731
    h = nv[entry].double()
    per = {bid: rms(nv[n]) for bid, n in outs}
    agg = math.sqrt(sum(v * v for v in per.values()))
    net = rms(sum(nv[n].double() for _, n in outs))
    hr = rms(h)
    wmax = max(float(g.mods[g.nodes[n].pkey].weight.detach().abs().max()) for _, n in outs)
    bmax = max((float(g.mods[g.nodes[n].pkey].bias.detach().abs().max())
                for _, n in outs if getattr(g.mods[g.nodes[n].pkey], "bias", None) is not None), default=0.0)
    vals = [hr, agg, net, wmax, bmax, *per.values()]
    if not all(math.isfinite(v) for v in vals):
        raise Fail("non-finite branch statistics")
    return {"input_rms": hr, "aggregate_branch_rms": agg, "net_branch_rms": net,
            "cancellation_ratio": (net / agg) if agg > 0 else None,
            "net_over_input": net / hr if hr > 0 else None, "aggregate_over_input": agg / hr if hr > 0 else None,
            "branch_out_weight_max": wmax, "branch_out_bias_max": bmax,
            **{f"branch_rms_{bid}": v for bid, v in per.items()}}


def path_ckpts(rd: Path) -> list:
    ps = []
    for p in (rd / "ckpt").glob("path_u*.pt"):
        mm = re.fullmatch(r"path_u(\d+)\.pt", p.name)
        if mm:
            ps.append((int(mm.group(1)), p.stem))
    return sorted(ps)


def recompute_split(tcfg_full: dict, bundle) -> torch.Tensor:
    """random_matched, independently of the trajectory code: round(fraction x n) examples in branch a."""
    g_ = tcfg_full.get("growth") or {}
    tr = bundle.train
    frac = g_.get("spec_random_fraction")
    if frac is None:
        frac = 0.5 if tr.groups is None else float((tr.groups == 0).float().mean())
    n = len(tr)
    perm = torch.randperm(n, generator=torch_gen(seed_of(tcfg_full, "partition"), "insertion", "spec_random"))
    ind = torch.zeros(n, dtype=torch.long)
    ind[perm[:int(round(float(frac) * n))]] = 1
    return ind


# ----------------------------------------------------------------------------- one f0

def read_f0(bid, J, runs, mcfg, bundles, a, dev, expect_forks) -> tuple:
    """returns (gradient rows, regrowth rows) of one f0; raises Fail on anything missing or invalid."""
    grows, regs = [], []
    if set(J) != set(PARENTS):
        raise Fail(f"parents {sorted(J)}, the design has {list(PARENTS)}")
    bcfg = AC.job_config(runs, bid, mcfg.get(bid))
    meta = {"f0": bid, "data_draw": (bcfg.get("data") or {}).get("data_seed"),
            "optimizer_seed": (bcfg.get("seeds") or {}).get("optimizer")}
    stages0 = None
    for parent in PARENTS:
        j = J[parent]
        st_ = set(j["forks"])
        if stages0 is None:
            stages0 = st_
        if st_ != stages0 or not st_ or (expect_forks and st_ != set(expect_forks)):
            raise Fail(f"{parent}: fork points {sorted(st_)}")
        for stage, cs in j["forks"].items():
            miss = [c for c in REQUIRED if c not in cs]
            if miss:
                raise Fail(f"{parent} {stage}: continuations missing: {miss}")
    for parent in PARENTS:
        j = J[parent]
        tid = j["traj"]
        tcfg_full = AC.job_config(runs, tid, mcfg[tid])
        dk = json.dumps(tcfg_full["data"], sort_keys=True)
        if dk not in bundles:
            b0 = SR.load_bundle(json.loads(dk), a.data_root, device="cpu")
            bundles[dk] = (b0.to(dev), b0.hashes())
        b, hashes = bundles[dk]
        parts = b.partitions()
        need = {"train", *AC.eval_partitions(b)}
        tr_ = parts["train"]
        N = len(tr_)
        g_ = tcfg_full.get("growth") or {}
        if g_.get("spec_partition") != "random_matched" or (g_.get("spec_reassign") or {}).get("mode", "none") != "none":
            raise Fail(f"{tid}: the diagnostic reads a fixed random_matched split only")
        mpath = runs / tid / "spec_partition.pt"
        if not mpath.exists():
            raise Fail(f"{tid}: no saved split (spec_partition.pt)")
        mem_saved = torch.load(mpath, map_location="cpu", weights_only=False)
        mem_def = recompute_split(tcfg_full, b)
        if mem_saved.numel() != N or not torch.equal(mem_saved.long().cpu(), mem_def):
            raise Fail(f"{tid}: the saved split differs from its definition")
        mem = mem_def.bool()
        mhash = tensor_hash(mem.cpu())
        ctx_routed = retained_mask_ctx(b, mem.long().to(tr_.y.device), tcfg_full["growth"])   # puts the split on
        if not torch.equal(tr_.aux["_spec_random"].long().cpu(), mem.long()):                   # the training data
            raise Fail("the split on the training partition is not the parent's")
        bs = int((tcfg_full.get("train") or {}).get("batch_size", 128))
        K = max(1, min(a.batches, N // bs))
        perm = torch.randperm(N, generator=torch.Generator().manual_seed(0))[:K * bs]
        batches = [tr_.index(perm[k * bs:(k + 1) * bs].to(tr_.y.device)) for k in range(K)]
        Xt = parts["test"].X["x"].to(dev).double()
        for stage, cs in sorted(j["forks"].items()):
            cfgs = {cn: AC.job_config(runs, cs[cn], mcfg[cs[cn]]) for cn in REQUIRED}
            for cn in REQUIRED:
                if cn.startswith("routed_"):
                    res = json.loads((runs / cs[cn] / "dissipation_result.json").read_text())
                    if (res.get("removal_policy") or {}).get("membership_hash") != mhash:
                        raise Fail(f"{cs[cn]}: recorded membership hash differs from the parent's split")
            snap = SR.ckp(runs / tid, stage)
            g_snap = AC.check_ckpt(snap, f"{parent} {stage} snapshot", run_id=tid, stage=stage, cfg=tcfg_full,
                                   hashes=hashes, need=need)
            starts = {}
            for ek, (rname, oname) in EDITS.items():
                ck = SR.ckp(runs / cs[rname], "event_after_redistribute")
                ge = AC.check_ckpt(ck, f"{cs[rname]} start", run_id=cs[rname], stage="event_after_redistribute",
                                   cfg=cfgs[rname], hashes=hashes, need=need)
                if oname:
                    ck2 = SR.ckp(runs / cs[oname], "event_after_redistribute")
                    go = AC.check_ckpt(ck2, f"{cs[oname]} start", run_id=cs[oname], stage="event_after_redistribute",
                                       cfg=cfgs[oname], hashes=hashes, need=need)
                    if AC.param_hash_of(ck2) != AC.param_hash_of(ck) or go.structural_hash() != ge.structural_hash():
                        raise Fail(f"{parent} {stage} {ek}: the routed and ordinary forks start from different "
                                   f"edited networks")
                starts[ek] = ge
            # ---- first update
            tcfgs = {"routed": cfgs["routed_reset"]["train"], "ordinary": cfgs["ordinary_reset"]["train"]}
            for mode in MODES:
                pu = int(cfgs[f"{mode}_reset"]["dissipation"]["post_updates"])
                check_recipe(tcfgs[mode], pu)
                for ek, (rname, oname) in EDITS.items():
                    en = rname if mode == "routed" else (oname or "ordinary_reset")
                    if cfgs[en]["train"] != tcfgs[mode]:
                        raise Fail(f"{parent} {stage}: {en} trains differently from {mode}_reset")
            for prec, dt in (("float32", torch.float32), ("float64", torch.float64)):
                for mode in MODES:
                    tc = tcfgs[mode]
                    ctx_fn = ctx_routed if mode == "routed" else None
                    pk = first_layer(g_snap)
                    cols = held_columns(b, tc, g_snap.mods[pk].weight)
                    snap_u = [one_update(g_snap, b, tc, bt, ctx_fn, dev, dt) for bt in batches]
                    for ek, ge in starts.items():
                        acc = defaultdict(list)
                        for bt, us in zip(batches, snap_u):
                            ue = one_update(ge, b, tc, bt, ctx_fn, dev, dt)
                            for u_ in (us, ue):
                                _, held = split_cols(u_["disp"], cols)
                                if held.numel() and float(held.abs().max()) != 0.0:
                                    raise Fail(f"{parent} {stage} {ek} {mode}: a held coordinate moved")
                                _, hg = split_cols(u_["opt_grad"], cols)
                                if hg.numel() and float(hg.abs().max()) != 0.0:
                                    raise Fail(f"{parent} {stage} {ek} {mode}: a held coordinate has a gradient")
                            c_raw = compare(ue["raw"], us["raw"])
                            c_og = compare(split_cols(ue["opt_grad"], cols)[0], split_cols(us["opt_grad"], cols)[0])
                            c_d = compare(split_cols(ue["disp"], cols)[0], split_cols(us["disp"], cols)[0], sign=True)
                            c_rh = compare(split_cols(ue["raw"], cols)[1], split_cols(us["raw"], cols)[1]) \
                                if cols else None
                            for nm, c in (("raw_grad", c_raw), ("opt_grad_trainable", c_og),
                                          ("disp_trainable", c_d)):
                                acc[f"{nm}_rel_change"].append(c["rel"])
                                acc[f"{nm}_cos"].append(c["cos"])
                                acc[f"{nm}_status"].append(c["status"])
                            acc["disp_trainable_sign_agree"].append(c_d["sign"])
                            acc["raw_grad_held_rel_change"].append(c_rh["rel"] if c_rh else None)
                        row = {**meta, "parent": parent, "fork": stage, "edit": ek, "mode": mode, "precision": prec,
                               "batches": len(batches), "batch_size": bs, "held_columns": " ".join(map(str, cols)),
                               "held_displacement_max": 0.0}
                        for k, v in acc.items():
                            if k.endswith("_status"):
                                bad = sorted({s_ for s_ in v if s_ != "ok"})
                                row[k] = "ok" if not bad else "+".join(bad)
                            else:
                                ok = [x for x in v if x is not None]
                                row[k] = (sum(ok) / len(ok)) if ok else None
                                row[k + "_n"] = len(ok)
                        grows.append(row)
            # ---- regrowth
            for cn in REGROW:
                rd = runs / cs[cn]
                ep = json.loads((rd / "endpoint.json").read_text())
                pts = []
                if cn in FC.MECH:
                    pts.append((0, "event_after_redistribute", starts["shift100"]))
                else:
                    pts.append((0, f"snapshot {stage}", g_snap))
                # v69: the path points the run promised (its own path record) must all be saved, with their update
                res_ = json.loads((rd / "dissipation_result.json").read_text())
                if not (res_.get("path_sampling") or {}).get("dense_checkpoints"):
                    raise Fail(f"{cs[cn]}: its path checkpoints were not saved (dense_checkpoints off)")
                planned = sorted({int(e_["update"]) for e_ in res_.get("path") or []
                                  if e_.get("tag") not in ("start", "exported") and int(e_["update"]) > 0})
                found = path_ckpts(rd)
                if [u_ for u_, _ in found] != planned:
                    raise Fail(f"{cs[cn]}: path checkpoints at {[u_ for u_, _ in found]}, its path record has "
                               f"{planned}")
                for u_, nm in found:
                    ck_ = SR.ckp(rd, nm)
                    gg = AC.check_ckpt(ck_, f"{cs[cn]} {nm}", run_id=cs[cn], stage=nm, cfg=cfgs[cn], hashes=hashes,
                                       need=need)
                    ex_ = ck_.get("extra") or {}
                    if ex_.get("update") is None or int(ex_["update"]) != u_:
                        raise Fail(f"{cs[cn]} {nm}: records update {ex_.get('update')}, expected {u_}")
                    pts.append((u_, nm, gg))
                cke = SR.ckp(rd, ep["checkpoint"])
                ge_ = AC.check_ckpt(cke, f"{cs[cn]} end", run_id=cs[cn], stage=ep["checkpoint"], cfg=cfgs[cn],
                                    hashes=hashes, need=need)
                ue_ = int(ep["updates"])
                same = [p for p in pts if p[0] == ue_]
                if same:
                    if AC.param_hash_of(SR.ckp(rd, same[0][1])) != AC.param_hash_of(cke):
                        raise Fail(f"{cs[cn]}: the path point at the end's update holds other tensors")
                else:
                    pts.append((ue_, f"end ({ep['checkpoint']})", ge_))
                us_ = [p[0] for p in pts]
                if us_ != sorted(set(us_)):
                    raise Fail(f"{cs[cn]}: checkpoint updates not strictly increasing: {us_}")
                for u_, nm, gg in pts:
                    m64 = copy.deepcopy(gg).to(dev).double().eval()
                    m64._plan = None
                    regs.append({**meta, "parent": parent, "fork": stage, "continuation": cn, "update": u_,
                                 "checkpoint": nm, **branch_stats(m64, Xt)})
    return grows, regs


def draw_means(rows, keys, fields) -> dict:
    """seeds averaged within each data draw, then the mean over draws, per key."""
    per = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
    for r in rows:
        k = "|".join(str(r[x]) for x in keys)
        for f in fields:
            if r.get(f) is not None:
                per[k][f][str(r["data_draw"])].append(float(r[f]))
    out = {}
    for k, fs in per.items():
        out[k] = {}
        for f, dr in fs.items():
            dm = [sum(v) / len(v) for v in dr.values()]
            out[k][f] = {"mean_over_draws": sum(dm) / len(dm), "n_draws": len(dm)}
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("results")
    ap.add_argument("out")
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--batches", type=int, default=4)
    ap.add_argument("--expect-forks", default=None)
    ap.add_argument("--expect-f0", type=int, default=None)
    ap.add_argument("--strict", action="store_true")
    a = ap.parse_args(argv)
    dev = torch.device(a.device)
    if dev.type == "cuda" and not torch.cuda.is_available():
        print("CUDA requested but not available", file=sys.stderr)
        return 2
    expect_forks = [x for x in (a.expect_forks or "").split(",") if x]
    runs = Path(a.results) / "runs"
    mcfg = {e["run_id"]: e["cfg"] for e in AC.manifest_entries(a.manifest)}
    cov = {"tool": "mechanism_diagnostics", "schema": SCHEMA, "manifest": a.manifest,
           "manifest_sha256": FC.CE.sha256_file(a.manifest), "batches": a.batches,
           "numerics": FC.CE.numerics_policy(dev), "expect_forks": expect_forks,
           "design": {"parents": list(PARENTS), "continuations": list(REQUIRED), "edits": list(EDITS),
                      "modes": list(MODES), "precisions": list(PRECISIONS), "regrowth": list(REGROW)},
           "status": "diagnostic: trains nothing that is kept; describes the first update and branch regrowth",
           "expected_f0": 0, "analysed_f0": 0, "failed": []}
    grows, regs = [], []
    # every f0 of the manifest with a mechanism fork anywhere is expected (a design missing parts fails, it does not
    # shrink)
    jobs = {}
    try:
        # v69: every f0 of the design (one with a routed parent arm), whether or not its mechanism forks are in the
        # manifest: an f0 that lost them fails, it does not leave the expected set
        jobs = {b_: v for b_, v in FC.fork_jobs(mcfg).items() if set(v) & set(PARENTS)}
    except Fail as ex_:
        cov["failed"].append({"f0": None, "reason": str(ex_)})
    cov["expected_f0"] = len(jobs)
    if a.expect_f0 is not None and len(jobs) != a.expect_f0:
        cov["failed"].append({"f0": None, "reason": f"the manifest holds {len(jobs)} f0s, the design {a.expect_f0}"})
    bundles = {}
    n_stage = None
    for bid in sorted(jobs):
        try:
            g_rows, r_rows = read_f0(bid, jobs[bid], runs, mcfg, bundles, a, dev, expect_forks)
            exp = len(PARENTS) * len(jobs[bid][PARENTS[0]]["forks"]) * len(EDITS) * len(MODES) * len(PRECISIONS)
            if len(g_rows) != exp:
                raise Fail(f"{len(g_rows)} gradient rows, {exp} expected")
            keys = [(r["parent"], r["fork"], r["edit"], r["mode"], r["precision"]) for r in g_rows]
            if len(set(keys)) != len(keys):
                raise Fail("duplicate gradient rows")
            n_stage = len(jobs[bid][PARENTS[0]]["forks"])
            grows += g_rows                      # committed only after the whole f0 passed
            regs += r_rows
            cov["analysed_f0"] += 1
            print(f"f0 {bid} read", flush=True)
        except (Fail, RD.GraphError, KeyError, RuntimeError, ValueError) as ex_:
            cov["failed"].append({"f0": bid, "reason": f"{type(ex_).__name__}: {ex_}"})
            print(f"FAIL {bid}: {ex_}", file=sys.stderr, flush=True)
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    for nm, rows in (("gradients", grows), ("regrowth", regs)):
        keys_ = []
        for r in rows:
            for k in r:
                if k not in keys_:
                    keys_.append(k)
        with open(f"{out}_{nm}.csv", "w", newline="") as f:
            if rows:
                w = csv.DictWriter(f, fieldnames=keys_)
                w.writeheader()
                w.writerows(rows)
    fields = [f"{m}_{s}" for m in METRICS for s in ("rel_change", "cos")] + ["disp_trainable_sign_agree"]
    cov["gradient_summary"] = draw_means(grows, ("parent", "fork", "edit", "mode", "precision"), fields)
    cov["expected_gradient_rows_per_f0"] = (len(PARENTS) * n_stage * len(EDITS) * len(MODES) * len(PRECISIONS)
                                            if n_stage else None)
    cov["gradient_rows"] = len(grows)
    cov["regrowth_rows"] = len(regs)
    cov["undefined_comparisons"] = sum(1 for r in grows for k, v in r.items() if k.endswith("_status") and v != "ok")
    cov["passed"] = cov["analysed_f0"] == cov["expected_f0"] and not cov["failed"] and cov["expected_f0"] > 0
    Path(f"{out}_coverage.json").write_text(json.dumps(cov, indent=1))
    print(json.dumps({k: cov[k] for k in ("expected_f0", "analysed_f0", "gradient_rows", "regrowth_rows", "passed")}))
    return 0 if (cov["passed"] or not a.strict) else 1


if __name__ == "__main__":
    sys.exit(main())
