#!/usr/bin/env python3
"""v58 / v59 / v60 / v61 / v63: is the worse decoding after the additions' merge a loss of information, or only a harder geometry for
the fitted probe?

Analysis only: reads a finished panel (wave 25 or wave 26), trains no network; linear probes are fitted with
component_change's solver.  For every f0, in each network's OWN graph (the native context):

  states     f0; every expansion at every saved state (each insertion, each snapshot, its end); every compact
             control at the expansion's end (2U)
  features   every hidden layer: layer1 .. layerN (what the output layer reads), and the merge layer<k>_post_merge
             (what backbone layer k+1 reads: layer<k>, which the additions read, plus their output; expansions only).
             v62: the merge is found in the graph at any depth (k = 2 in the wave-26 network, 3 in wave 29's)
  probes     label; fitted on val_indep; two preprocessings, both fitted on the fit set only:
               standardised  each coordinate centred and scaled (component_change's rule)
               whitened      centred and rotated onto the principal axes of the fit set, each axis scaled to unit
                             variance; axes with variance below WHITEN_FLOOR x the largest are dropped.  The
                             truncation depends on the coordinates: an invertible map that stretches one direction
                             far more than another can push a direction below the floor in one representation and
                             not in the other.  So whitened probes on two representations are compared only when
                             they are comparable (below); every whitened probe records its retained dimensions,
                             the variance it discarded, the conditioning of what it kept and how far the evaluation
                             points lie outside the fit set's retained span
             both penalties of component_change; errors on test, val and shift

  the merge map (expansions), v59:
    affine additions   EXACT, from the graph: the subgraph from layer<k> to its merge (the additions, their
                       merge coefficients and the identity term) evaluated in float64 on zero and the unit vectors
                       (cop.graph.edits.affine_map; gradient-mask nodes pass their input forward).  The sampled
                       activations CHECK it (largest residual on train and test, relative), they do not define it.
                       Map source graph_exact.
    relu additions     least squares on the training set, U = M h + c with U = post - pre: an AFFINE APPROXIMATION
                       (map source least_squares_affine_approximation, with its R^2 and test residual).  Its rank
                       and singular values describe the approximation, not the nonlinear map, and say nothing about
                       information loss.
    Recorded per state: the singular values of A = I + M (largest, smallest, condition number, numerical rank at
    RANK_TOL x the largest), and the same on the span of the training activations.  A rank below full, or a worse
    probe, does not by itself show that TASK-RELEVANT information is lost: a lost direction may carry nothing about
    the label, and a worse fitted probe may be the fit (penalty, conditioning, finite samples).

  whitening comparability (v59; v60 wording): a NUMERICAL check under the stated tolerances, not an exact
    guarantee.  The whitened probes before and after an affine merge are comparable ON THE FIT SET
    only when the exact map is invertible (condition number below COND_MAX), both whiteners keep the same number of
    axes, and the map carries the pre-merge retained span onto the post-merge one (largest principal-angle sine below
    SPAN_TOL); ON THE EVALUATION PARTITIONS only when, besides, the evaluation points' aggregate centred energy
    outside both retained spans is below OFFSPAN_TOL (a bound on the total, not a statement that every point lies
    in the span).  The whitened post-minus-pre contrast is recorded
    for the fit error (comparable: the fit-set condition) and the test error (comparable: both conditions); a row
    that is not comparable stays in _contrasts with comparable False and its reason, and is left out of the
    summaries.  Under these conditions the whitened difference of an affine merge is zero up to numerical error, so
    it checks the conditions; the transport certificate is the primary test.  Relu merges are never comparable here.
    Because the summaries keep only comparable rows, a draw may be represented by one of its two seeds:
    _whitening_coverage.csv gives, per variant, stage, metric and penalty, the planned draws and draw-seed pairs
    and the comparable ones, and the draws left with one seed.

  transport certificate (v59; v61: two precisions): for every affine state whose exact map is invertible (eligible),
    each pre-merge probe is carried to the post-merge features by solving A h = post - c (a linear solve, not an explicit inverse; the
    solve residual is recorded) and applying the pre-merge preprocessing and probe.  On the fit partition and on
    test, val and shift: the largest score difference to the pre-merge probe's own scores (relative to the largest
    score), the fraction of decisions that disagree, and the smallest pre-merge margin among them.  A state passes
    when every probe on every partition has solve residual <= SOLVE_TOL, score difference <= SCORE_TOL and no
    disagreement outside the margin band (|pre-merge score| <= SCORE_TOL x the largest score).  A passed state may
    still have decisions that flip inside the margin band, so a pass does not mean identical predictions: every row
    reports the disagreement fraction and the error difference (transported minus pre-merge), and the coverage
    record their largest values over passed rows.  The coverage
    record counts expected (affine states with a merge), eligible, checked, passed, failed and skipped (with
    reasons); the certificate is valid when nothing failed and every eligible state was checked, and complete when
    every expected state was eligible.  A singular map is skipped (reported), never counted as a success.
    Analysis completion (every f0 analysed, every probe fitted) and certificate validity are reported apart.
    v61: the certificate is computed twice, with the same pre-merge activations h held fixed.  float64 (decisive):
    post = the merge subgraph evaluated in float64 on h (checked against A h + c within EXACT64_TOL).  float32
    (v60's certificate, reported and kept visible): post = the float32 post-merge activations the network computes.
    _precision gives per state and partition the float32 forward residual |post32 - (A h + c)|, the error it
    gives back through the solve (recovered_error32) and the amplification between them, beside the condition
    number.  A float32 failure with a float64 pass means the information is there in exact arithmetic and the
    network's own precision, through an ill-conditioned merge, perturbs it by the reported amounts.

  _maps       per expansion state: map source, data residuals, singular values, condition numbers, ranks
  _whitening_coverage   (v60) planned and comparable draws and draw-seed pairs behind the whitened summaries
  _transport  per eligible state, precision (float64, float32), preprocessing, penalty and partition
  _precision  (v61) per eligible state and partition: the forward residual, recovered error, amplification, cond
  _probes     per state, feature, preprocessing and penalty (whitening records on the whitened rows)
  fitted against transported (v63): the post-merge preprocessing and probes are fitted twice, on the float32 merge
    outputs the network computes (feature layer<k>_post_merge) and on the float64-evaluated merge outputs (feature
    layer<k>_post_merge@float64).  fitted_minus_transported_float32 compares the probe fitted on the float32 outputs
    with the transported pre-merge probe reading the SAME float32 outputs (the network's actual precision);
    fitted_minus_transported_float64 does the same with the float64 outputs (certified states only).  Whitened rows
    carry the whitening comparability of the matching representation, and only comparable rows enter the summaries;
    _whitening_coverage gives the planned and included draw-seed pairs.  fitted_minus_transported_mixed_precision
    (the probe fitted on float32, the transported one reading float64: v61's comparison) is kept and labelled; it
    changes the representation as well as the probe, so it does not attribute a gap to the probe alone.
    Wording: for eligible affine merges, the tested linear readouts transport through the float64-evaluated merge
    within the stated tolerances; with an invertible map, information preservation in exact arithmetic follows
    algebraically, and the empirical questions are the conditioning, finite precision, the readout's fit and what
    later training does.
  _contrasts  paired within f0: after the merge minus before it (same preprocessing and penalty; whitened rows carry
              comparable and its reason); the fitted post-merge probe minus the transported one (certified states
              only); whitened minus standardised (same feature); a state minus f0 at the same feature; an expansion
              at 2U minus its matched compact control at 2U
Each with _by_draw and _summary (seeds averaged within a draw, 95% t intervals over draws), grouped by design_id.
Everything here is exploratory.

usage: merge_geometry.py RESULTS OUT_PREFIX --manifest M [--data-root D] [--device cpu|cuda] [--strict]
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import component_change as CC  # noqa: E402
import coordinated_edits as CE  # noqa: E402
import f0_panel as FP  # noqa: E402
import selective_reversal as SR  # noqa: E402
from cop.graph import edits as E  # noqa: E402

torch = SR.torch
Fail = SR.Fail
GraphNet = SR.GraphNet

ANALYSIS_SCHEMA = "merge_geometry/v63"
STATUS = "exploratory reanalysis of existing checkpoints (no network is trained; linear probes are fitted)"
FIT = "val_indep"
EVAL = ("test", "val", "shift")
LAMBDAS = CC.LAMBDAS
PREPS = ("standardised", "whitened")
FEATURES = "every hidden layer's activation (layer1 .. layerN) and the merge (layer<k>_post_merge, expansions)"
POST = "_post_merge"
AT64 = "@float64"              # v63: a post-merge probe fitted on the float64-evaluated merge outputs
WHITEN_FLOOR = 1e-9            # principal axes with variance below this x the largest are dropped
RANK_TOL = 1e-10               # singular values below this x the largest count as zero
EXACT_TOL = 1e-4               # the exact map must reproduce the sampled activations below this relative residual
COND_MAX = 1e8                 # the map counts as invertible below this condition number
SPAN_TOL = 1e-4                # largest principal-angle sine between A (pre-merge retained span) and the post span
OFFSPAN_TOL = 1e-6             # fraction of evaluation energy outside the fit set's retained span
SOLVE_TOL = 1e-9               # relative residual of the linear solve A h = post - c
SCORE_TOL = 1e-4               # relative score difference of a transported probe; also the margin band
EXACT64_TOL = 1e-10            # v61: the merge evaluated in float64 against the exact map (relative)
MAP_EXACT = "graph_exact"
MAP_LS = "least_squares_affine_approximation"
STATE_KEYS = ("design_id", "cell", "variant", "kind", "stage", "updates_since_f0")
PROBE_KEYS = STATE_KEYS + ("feature", "prep", "lam")
CONTRAST_KEYS = ("design_id", "cell", "comparison", "variant", "kind", "stage", "updates_since_f0", "feature",
                 "prep", "lam", "metric", "second", "sign")
MAP_METRICS = ("data_residual_train", "data_residual_test", "fit_r2", "s_max", "s_min", "cond", "rank", "span_dims",
               "span_s_min", "span_cond", "span_rank")
TRANSPORT_METRICS = ("solve_residual", "reconstruction_residual", "score_diff", "disagree_frac",
                     "transported_err", "pre_merge_err", "err_diff")


# ----------------------------------------------------------------------------- preprocessing and probes

def whitener(F):
    """-> (mean, projection P, retained axes): (F - mean) @ P has identity covariance on the fit set."""
    mu, P, r, _ = whitener_full(F)
    return mu, P, r


def whitener_full(F):
    """whitener plus its record: total dimensions, retained, discarded variance fraction, retained conditioning
    and the orthonormal retained axes Q."""
    mu = F.mean(0)
    X = F - mu
    C = X.T @ X / max(1, X.shape[0])
    ev, V = torch.linalg.eigh(C)
    top = float(ev.max()) if ev.numel() else 0.0
    keep = ev > WHITEN_FLOOR * top if top > 0 else torch.zeros_like(ev, dtype=torch.bool)
    tot = float(ev.clamp_min(0).sum())
    rec = {"total_dims": int(F.shape[1]), "dims": int(keep.sum()),
           "discarded_var_frac": (float(ev[~keep].clamp_min(0).sum()) / tot) if tot > 0 else None,
           "retained_cond": (top / float(ev[keep].min())) if bool(keep.any()) else None, "Q": V[:, keep]}
    if not bool(keep.any()):
        return mu, torch.zeros(F.shape[1], 0, dtype=F.dtype, device=F.device), 0, rec
    return mu, V[:, keep] / ev[keep].sqrt(), int(keep.sum()), rec


def offspan(x, mu, Q) -> float:
    """fraction of the centred energy of x outside span(Q) (Q orthonormal columns)."""
    X = x - mu
    tot = float((X ** 2).sum())
    if tot <= 0:
        return 0.0
    R = X - (X @ Q) @ Q.T if Q.shape[1] else X
    return float((R ** 2).sum()) / tot


def preprocess(F: dict, prep: str):
    """F = {partition: features}; fitted on FIT.  -> (transformed features, apply(x), retained dimensions)."""
    Z, fn, dims, _ = preprocess_full(F, prep)
    return Z, fn, dims


def preprocess_full(F: dict, prep: str):
    """preprocess plus the whitening record (None for standardised): total and retained dimensions, discarded
    variance, retained conditioning, the largest off-span fraction over the evaluation partitions, and the
    retained axes (mean, Q) for comparability checks."""
    rec = None
    if prep == "standardised":
        mu, sd = CC.standardiser(F[FIT])
        fn = (lambda x: (x - mu) / sd)
        dims = int(F[FIT].shape[1])
    elif prep == "whitened":
        mu, P, dims, rec = whitener_full(F[FIT])
        fn = (lambda x: (x - mu) @ P)
        rec = {**rec, "mu": mu, "offspan_max": max([offspan(F[p], mu, rec["Q"]) for p in F if p != FIT] or [0.0])}
    else:
        raise Fail(f"unknown preprocessing {prep}")
    return {p: fn(x) for p, x in F.items()}, fn, dims, rec


def fit_probe(Z: dict, y: dict, lam: float, what: str):
    """the label probe on preprocessed features -> (w, b, row fields).  A probe with no retained dimension is the
    intercept alone."""
    for p_, t_ in Z.items():
        CC.finite(t_, f"{what} features on {p_}")
    if Z[FIT].shape[1] == 0:
        Zf = {p_: torch.zeros(t_.shape[0], 1, dtype=t_.dtype, device=t_.device) for p_, t_ in Z.items()}
    else:
        Zf = Z
    w, b, info = CC.fit_logistic(Zf[FIT], y[FIT], lam)
    CC.finite(w, f"{what}: coefficients")
    r = {"fit_err": CC.probe_error(Zf[FIT], y[FIT], w, b), "fit_loss": info["loss"], "iterations": info["iterations"],
         "grad_inf": info["grad_inf"], "converged": info["grad_inf"] <= CC.CONVERGED_TOL, "w_norm": float(w.norm())}
    for p in EVAL:
        if p not in Zf:
            continue
        s_ = CC.probe_scores(Zf[p], w, b)
        CC.finite(s_, f"{what}: scores on {p}")
        r[f"{p}_err"] = float(((s_ > 0).long() != y[p]).double().mean())
    return w, b, r


def probe_scores_of(x, fn, w, b, dims):
    if dims == 0:
        return torch.full((x.shape[0],), float(b), dtype=torch.float64, device=x.device)
    return CC.probe_scores(fn(x), w, b)


# ----------------------------------------------------------------------------- the merge map

def merge_region(g, a: str, cur: str) -> set:
    """the nodes strictly between the pre-merge site a and the post-merge site cur (cur excluded), every one of
    them a function of a alone."""
    region, stack = set(), [cur]
    while stack:
        n = stack.pop()
        if n == a or n in region:
            continue
        nd = g.nodes[n]
        if nd.op == "input" or not nd.inputs:
            raise Fail(f"the merge at {cur} reads the graph input, not only {a}")
        region.add(n)
        if len(region) > 10000:
            raise Fail("the merge region is unbounded")
        stack.extend(nd.inputs)
    return region - {cur}


def exact_merge_map(g, a: str, cur: str):
    """-> (A, c) with post = A pre + c, from the graph in float64, or None when the merge is not affine (apart from
    gradient-mask nodes, whose forward value is their input)."""
    region = merge_region(g, a, cur)
    allv = region | {cur}
    if not E.region_is_affine(g, allv - set(E.grad_mask_nodes(g, allv))):
        return None
    A, c = E.affine_map(g, a, cur, region)
    return A.double().cpu(), c.double().cpu()


def ls_merge_map(H, Upost):
    """the least-squares affine approximation post ~ A pre + c on the given activations (U = post - pre fitted as
    M h + c, minimum norm); -> (A = I + M, c, R^2)."""
    U = Upost - H
    M, cvec, _ = CE.affine_fit(H, U)
    M, cvec = M.double().cpu(), cvec.double().cpu()
    res = U.double().cpu() - (H.double().cpu() @ M.T + cvec)
    Uc = U.double().cpu()
    sst = float(((Uc - Uc.mean(0)) ** 2).sum())
    return torch.eye(M.shape[0], dtype=torch.float64) + M, cvec, (1.0 - float((res ** 2).sum()) / sst) if sst > 0 \
        else None


def data_residual(A, c, H, Post) -> float:
    """largest |post - (A pre + c)|, relative to the largest |post - pre| (at least 1)."""
    H, Post = H.double().cpu(), Post.double().cpu()
    return float((Post - (H @ A.T + c)).abs().max()) / max(1.0, float((Post - H).abs().max()))


def map_fields(A, H) -> dict:
    """singular values of A, globally and on the span of the activations H."""
    s = torch.linalg.svdvals(A)
    out = {"s_max": float(s.max()), "s_min": float(s.min()),
           "cond": float(s.max() / s.min()) if float(s.min()) > 0 else float("inf"),
           "rank": int((s > RANK_TOL * s.max()).sum())}
    _, _, r, rec = whitener_full(H.double().cpu())
    if r:
        ss = torch.linalg.svdvals(A @ rec["Q"])
        out.update({"span_dims": r, "span_s_min": float(ss.min()),
                    "span_cond": float(ss.max() / ss.min()) if float(ss.min()) > 0 else float("inf"),
                    "span_rank": int((ss > RANK_TOL * ss.max()).sum())})
    else:
        out.update({"span_dims": 0, "span_s_min": None, "span_cond": None, "span_rank": 0})
    return out


def merge_map(H, Upost, Htest, Ptest):
    """v58's least-squares map, kept for the relu approximation: -> (A, c, fields)."""
    A, c, r2 = ls_merge_map(H, Upost)
    return A, c, {"fit_r2": r2, "test_residual": data_residual(A, c, Htest, Ptest), **map_fields(A, H)}


def principal_sine(B1, B2) -> float:
    """sine of the largest principal angle between span(B1) and span(B2) (any column bases)."""
    if B1.shape[1] != B2.shape[1]:
        return 1.0
    if B1.shape[1] == 0:
        return 0.0
    Q1, Q2 = torch.linalg.qr(B1).Q, torch.linalg.qr(B2).Q
    return float(torch.linalg.matrix_norm(Q1 - Q2 @ (Q2.T @ Q1), ord=2))


def whitening_comparable(rec_pre: dict, rec_post: dict, A, cond: float) -> dict:
    """whether the whitened probes on pre- and post-merge features of one exact affine map A are comparable:
    fit (on the fit set: invertible map, equal retained dimensions, the map carrying the pre-merge retained span onto
    the post-merge one) and eval (also every evaluation point inside both retained spans).  -> {fit, eval, note,
    sine, offspan}."""
    off = max(rec_pre["offspan_max"], rec_post["offspan_max"])
    out = {"fit": False, "eval": False, "note": "", "sine": None, "offspan": off}
    if A is None:
        return {**out, "note": "the merge is not affine (no exact map): whitening invariance does not apply"}
    if not cond < COND_MAX:
        return {**out, "note": f"the exact map is singular or ill conditioned (condition number {cond:.3g})"}
    if rec_pre["dims"] != rec_post["dims"]:
        return {**out, "note": f"unequal retained dimensions ({rec_pre['dims']} before, {rec_post['dims']} after)"}
    sn = principal_sine(A.double().cpu() @ rec_pre["Q"].double().cpu(), rec_post["Q"].double().cpu())
    out["sine"] = sn
    if sn > SPAN_TOL:
        return {**out, "note": f"the map does not carry the retained span onto the post-merge one (sine {sn:.3g})"}
    out["fit"] = True
    if off > OFFSPAN_TOL:
        return {**out, "note": f"evaluation points outside the fit set's retained span (fraction {off:.3g}): "
                               f"comparable on the fit set only"}
    return {**out, "eval": True}


def eval_merge64(g, a: str, cur: str, region: set, H):
    """the merge subgraph from a to cur evaluated in float64 on given pre-merge activations H (n x d): the post-merge
    activations those activations give in exact-as-possible arithmetic (gradient masks pass their input)."""
    order = [n for n in g.topo_order(set(region) | {cur}) if n in region or n == cur]
    dev = next((p_.device for n in order if g.nodes[n].pkey for p_ in g.mods[g.nodes[n].pkey].parameters()),
               H.device)
    vals = {a: H.to(dev, torch.float64)}
    with torch.no_grad():
        return _eval_region(g, order, vals, cur, H.shape[0])


def _eval_region(g, order, vals, cur, n_rows):
    from cop.graph.ops import FORWARD
    import copy as _copy
    for nid in order:
        n = g.nodes[nid]
        for i in n.inputs:
            if i not in vals:
                raise Fail(f"node {nid} reads {i} from outside the merge")
        mod = g.mods[n.pkey] if n.pkey else None
        vals[nid] = FORWARD[n.op](n, [vals[i] for i in n.inputs], _copy.deepcopy(mod).double() if mod is not None
                                  else None, g, {"X": {}})
    return vals[cur].reshape(n_rows, -1).double().cpu()


def precision_record(A, c, H, P32, P64) -> dict:
    """(v61) one partition: the float64 merge against the exact map (algebra), the float32 forward post-merge
    activations against A h + c (the forward rounding), the activations that rounding gives back through the solve
    (recovered error) and its amplification (recovered relative error over forward relative error)."""
    H, P32, P64 = H.double().cpu(), P32.double().cpu(), P64.double().cpu()
    M = H @ A.T + c
    alg = float((P64 - M).abs().max()) / max(1.0, float(M.abs().max()))
    r = P32 - M
    fwd = float(r.abs().max()) / max(1.0, float(M.abs().max()))
    dlt = torch.linalg.solve(A, r.T).T
    rec = float(dlt.abs().max()) / max(1.0, float(H.abs().max()))
    return {"merge64_vs_map": alg, "forward_residual32": fwd, "recovered_error32": rec,
            "amplification": (rec / fwd) if fwd > 0 else None}


def transport_check(A, c, pre: dict, post: dict, fn, w, b, dims, y: dict) -> list:
    """the pre-merge probe (preprocessing fn, coefficients w, b) carried to the post-merge features by solving
    A h = post - c, per partition.  -> rows with the solve residual, the reconstruction residual (h against the
    sampled pre-merge activations), the score difference, decision disagreement and margins, and passed."""
    rows = []
    for p in pre:
        P = post[p].double().cpu()
        rhs = (P - c).T
        h = torch.linalg.solve(A, rhs).T
        solve_res = float((h @ A.T + c - P).abs().max()) / max(1.0, float(P.abs().max()))
        H = pre[p].double().cpu()
        recon = float((h - H).abs().max()) / max(1.0, float(H.abs().max()))
        dev = pre[p].device
        s_pre = probe_scores_of(pre[p].double(), fn, w, b, dims).double().cpu()
        s_tr = probe_scores_of(h.to(dev, torch.float64), fn, w, b, dims).double().cpu()
        CC.finite(s_tr, "transported scores")
        scale = max(1.0, float(s_pre.abs().max()))
        diff = float((s_tr - s_pre).abs().max()) / scale
        dis = (s_tr > 0) != (s_pre > 0)
        band = SCORE_TOL * scale
        outside = int((dis & (s_pre.abs() > band)).sum())
        yy = y[p].cpu()
        rows.append({"partition": p, "solve_residual": solve_res, "reconstruction_residual": recon,
                     "score_diff": diff, "disagree_frac": float(dis.double().mean()),
                     "disagree_outside_margin": outside,
                     "min_margin_disagreeing": float(s_pre[dis].abs().min()) if bool(dis.any()) else None,
                     "min_margin": float(s_pre.abs().min()),
                     "transported_err": float(((s_tr > 0).long() != yy).double().mean()),
                     "pre_merge_err": float(((s_pre > 0).long() != yy).double().mean()),
                     "err_diff": float(((s_tr > 0).long() != yy).double().mean())
                     - float(((s_pre > 0).long() != yy).double().mean()),
                     "passed": bool(solve_res <= SOLVE_TOL and diff <= SCORE_TOL and outside == 0)})
    return rows


def contrast_summaries(contrasts: list):
    """(v63) the contrasts summarised by two_stage over the rows not marked incomparable (a whitened comparison
    whose whiteners are not comparable keeps its raw row with the reason, and stays out of the summary), each summary
    with the draw-seed pairs and draws planned (every row) and included.  -> (by_draw, summary)."""
    summ = [r for r in contrasts if r.get("comparable") is not False]
    bd, sm = SR.two_stage(summ, CONTRAST_KEYS, "value")
    planned_k, incl_k = defaultdict(set), defaultdict(set)
    for r in contrasts:
        planned_k[tuple(r[k] for k in CONTRAST_KEYS)].add((r["data_draw"], r["optimizer_seed"]))
    for r in summ:
        incl_k[tuple(r[k] for k in CONTRAST_KEYS)].add((r["data_draw"], r["optimizer_seed"]))
    for r in sm:
        k = tuple(r[k_] for k_ in CONTRAST_KEYS)
        r["planned_pairs"], r["included_pairs"] = len(planned_k[k]), len(incl_k[k])
        r["planned_draws"] = len({d for d, _ in planned_k[k]})
        r["included_draws"] = len({d for d, _ in incl_k[k]})
    return bd, sm


def finite_number(x) -> bool:
    try:
        return x is not None and abs(float(x)) < float("inf")
    except (TypeError, ValueError):
        return False


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("results")
    ap.add_argument("out")
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--strict", action="store_true",
                    help="exit 1 unless the analysis is complete (every f0 analysed, every probe fitted) and the "
                         "transport certificate is valid (no state failed, every eligible state checked)")
    a = ap.parse_args(argv)
    dev = torch.device(a.device)
    if dev.type == "cuda" and not torch.cuda.is_available():
        print("--device cuda requested but CUDA is not available", file=sys.stderr)
        return 2
    cov = {"tool": "merge_geometry", "analysis_schema": ANALYSIS_SCHEMA, "status": STATUS,
           "results": str(Path(a.results).resolve()), "manifest": a.manifest,
           "manifest_sha256": CE.sha256_file(a.manifest),
           "source_sha256": {p.name: CE.sha256_file(p) for p in (Path(__file__), Path(FP.__file__), Path(CC.__file__),
                                                                 Path(CE.__file__), Path(SR.__file__),
                                                                 Path(E.__file__))},
           "numerics": {**CE.numerics_policy(dev), "probes": "float64 Newton with line search, zero start",
                        "maps": "affine: exact from the graph in float64; relu: least-squares approximation",
                        "transport": "torch.linalg.solve in float64"},
           "definitions": {"fit": FIT, "eval": list(EVAL), "lambdas": list(LAMBDAS), "preps": list(PREPS),
                           "features": FEATURES, "whiten_floor": WHITEN_FLOOR, "rank_tol": RANK_TOL,
                           "exact_tol": EXACT_TOL, "cond_max": COND_MAX, "span_tol": SPAN_TOL,
                           "offspan_tol": OFFSPAN_TOL, "solve_tol": SOLVE_TOL, "score_tol": SCORE_TOL,
                           "map_sources": {MAP_EXACT: "affine additions", MAP_LS: "relu additions (an approximation)"},
                           "target": "label", "stationarity_tolerance_max_abs_gradient": CC.CONVERGED_TOL},
           "expected_f0": 0, "analysed_f0": 0, "failed": [], "probe_not_converged": []}
    cert = {"expected": 0, "eligible": 0, "checked": 0, "passed": 0, "failed": 0, "skipped": {}, "failures": []}
    cert32 = {"checked": 0, "passed": 0, "failed": 0, "failures": []}
    out = defaultdict(list)
    want = {}
    try:
        P = FP.open_panel(a.results, a.manifest)
    except Fail as ex_:
        cov["failed"].append({"f0": None, "reason": str(ex_)})
        print(f"FAIL: {ex_}", file=sys.stderr)
        P = None
    jobs = {} if P is None else P.jobs
    cov["expected_f0"] = len(jobs)
    if P is not None:
        cov["design"] = {"expansions": P.exp_lev, "compact_controls": P.comp_lev, "matched_compact": P.matched,
                         "expansion_updates": P.fork_u}
    bundles = {}
    for n_done, bid in enumerate(sorted(jobs), 1):
        staged = defaultdict(list)
        cst = {"expected": 0, "eligible": 0, "checked": 0, "passed": 0, "failed": 0, "skipped": defaultdict(int),
               "failures": []}
        cst32 = {"checked": 0, "passed": 0, "failed": 0, "failures": []}
        try:
            F = FP.open_f0(P, bid, a.data_root, dev, bundles)
            pp = [p for p in ("train", FIT, *EVAL) if p in F.parts]
            y = {p: F.parts[p].y.to(dev).long() for p in pp}
            rows = {}                                          # (state, feature, prep, lam) -> probe row
            comparable = {}                                    # state -> whitening comparability (float32)
            comparable64 = {}                                  # state -> the same for the float64 representation
            n_states = 0

            def one_state(skey, smeta, g, affine_design: bool):
                sites = FP.layer_sites(g, F.L)
                vals = {}
                for p in pp:
                    v_, _ = FP.node_values(g, F.parts[p], sorted(set(sites.values())), F.batch)
                    vals[p] = {name: v_[node] for name, node in sites.items()}
                feats = list(sites)                    # layer1 .. the last hidden layer, the merge after its input
                posts = [f for f in sites if f.endswith(POST)]
                if len(posts) > 1:
                    raise Fail(f"{skey}: {len(posts)} merge sites ({posts}); this panel has one cut")
                post = posts[0] if posts else None
                pre = post[:-len(POST)] if post else None
                fitted, wrec = {}, {}
                for feat in feats:
                    Fd = {p: vals[p][feat] for p in pp if p != "train"}
                    for prep in PREPS:
                        Z, fn, dims, rec = preprocess_full(Fd, prep)
                        if rec is not None:
                            wrec[feat] = rec
                        for lam in LAMBDAS:
                            what = f"{skey} {feat} {prep} lam={lam:g}"
                            w, b, r = fit_probe(Z, y, lam, what)
                            row = {**F.meta, **smeta, "feature": feat, "prep": prep, "lam": lam, "dims": dims, **r}
                            if rec is not None:
                                row.update({"white_total_dims": rec["total_dims"],
                                            "white_discarded_var_frac": rec["discarded_var_frac"],
                                            "white_retained_cond": rec["retained_cond"],
                                            "white_offspan_max": rec["offspan_max"]})
                            if not r["converged"]:
                                cov["probe_not_converged"].append({"f0": bid, "state": skey, "what": what,
                                                                   "grad_inf": r["grad_inf"]})
                            staged["probes"].append(row)
                            rows[(skey, feat, prep, lam)] = row
                            fitted[(feat, prep, lam)] = (w, b, fn, dims)
                if post is None:
                    return
                ex = exact_merge_map(g, sites[pre], sites[post])
                mreg = merge_region(g, sites[pre], sites[post])
                if (ex is not None) != affine_design:
                    raise Fail(f"{skey}: the design says the additions are {'affine' if affine_design else 'relu'}, "
                               f"the graph says {'affine' if ex is not None else 'not affine'}")
                Htr, Ptr = vals["train"][pre], vals["train"][post]
                Hte, Pte = vals["test"][pre], vals["test"][post]
                if ex is not None:
                    A, cvec = ex
                    mrow = {"map_source": MAP_EXACT, "fit_r2": None}
                else:
                    A, cvec, r2 = ls_merge_map(Htr, Ptr)
                    mrow = {"map_source": MAP_LS, "fit_r2": r2}
                mrow.update({"data_residual_train": data_residual(A, cvec, Htr, Ptr),
                             "data_residual_test": data_residual(A, cvec, Hte, Pte), **map_fields(A, Htr)})
                if ex is not None and max(mrow["data_residual_train"], mrow["data_residual_test"]) > EXACT_TOL:
                    raise Fail(f"{skey}: the exact map from the graph does not reproduce the sampled activations "
                               f"(residual {max(mrow['data_residual_train'], mrow['data_residual_test']):.3g})")
                wc = whitening_comparable(wrec[pre], wrec[post], A if ex is not None else None,
                                          mrow["cond"])
                comparable[skey] = wc
                eligible = ex is not None and mrow["cond"] < COND_MAX
                note = ("" if eligible else "the additions are not affine: no exact map, no transport"
                        if ex is None else f"the exact map is singular or ill conditioned (condition number "
                                           f"{mrow['cond']:.3g}): not eligible for inverse transport")
                mrow.update({**F.meta, **smeta, "transport_eligible": eligible, "transport_note": note,
                             "whitening_comparable": wc["eval"], "whitening_comparable_fit": wc["fit"],
                             "whitening_note": wc["note"], "whitening_span_sine": wc["sine"],
                             "whitening_offspan_max": wc["offspan"],
                             "dims_pre": wrec[pre]["dims"], "dims_post": wrec[post]["dims"], "merge_after": pre})
                if ex is not None:
                    cst["expected"] += 1
                    if not eligible:
                        cst["skipped"][note] += 1
                if not eligible:
                    mrow["transport_passed"] = None
                    staged["maps"].append(mrow)
                    return
                cst["eligible"] += 1
                state_ok = {"float64": True, "float32": True}
                parts_t = [p for p in (FIT, *EVAL) if p in vals]
                pre_t = {p: vals[p][pre] for p in parts_t}
                post32 = {p: vals[p][post] for p in parts_t}
                post64 = {p: eval_merge64(g, sites[pre], sites[post], mreg, pre_t[p])
                          for p in parts_t}
                prec = {p: precision_record(A, cvec, pre_t[p], post32[p], post64[p]) for p in parts_t}
                # v63: the post-merge preprocessing and probes refitted on the float64 representation, so that each
                # fitted-versus-transported comparison has both probes read the same numbers
                F64 = {p: post64[p].to(dev) for p in parts_t}
                fit64, wrec64 = {}, None
                for prep in PREPS:
                    Z64, fn64, dims64, rec64 = preprocess_full(F64, prep)
                    if rec64 is not None:
                        wrec64 = rec64
                    for lam in LAMBDAS:
                        what = f"{skey} {post}{AT64} {prep} lam={lam:g}"
                        w64, b64, r64 = fit_probe(Z64, {p: y[p] for p in parts_t}, lam, what)
                        row = {**F.meta, **smeta, "feature": post + AT64, "prep": prep, "lam": lam, "dims": dims64,
                               **r64}
                        if rec64 is not None:
                            row.update({"white_total_dims": rec64["total_dims"],
                                        "white_discarded_var_frac": rec64["discarded_var_frac"],
                                        "white_retained_cond": rec64["retained_cond"],
                                        "white_offspan_max": rec64["offspan_max"]})
                        if not r64["converged"]:
                            cov["probe_not_converged"].append({"f0": bid, "state": skey, "what": what,
                                                               "grad_inf": r64["grad_inf"]})
                        staged["probes"].append(row)
                        rows[(skey, post + AT64, prep, lam)] = row
                wc64 = whitening_comparable(wrec[pre], wrec64, A, mrow["cond"])
                comparable64[skey] = wc64
                mrow.update({"whitening64_comparable": wc64["eval"], "whitening64_comparable_fit": wc64["fit"],
                             "whitening64_note": wc64["note"]})
                for p in parts_t:
                    staged["precision"].append({**F.meta, **smeta, "partition": p, "cond": mrow["cond"], **prec[p]})
                    if prec[p]["merge64_vs_map"] > EXACT64_TOL:
                        raise Fail(f"{skey}: the float64 merge is not the exact map on {p} "
                                   f"({prec[p]['merge64_vs_map']:.3g})")
                for prep in PREPS:
                    for lam in LAMBDAS:
                        w, b, fn, dims = fitted[(pre, prep, lam)]
                        for precision, post_v in (("float64", post64), ("float32", post32)):
                            trs = transport_check(A, cvec, pre_t, post_v, fn, w, b, dims, {p: y[p] for p in parts_t})
                            for t in trs:
                                p = t["partition"]
                                key = "fit_err" if p == FIT else f"{p}_err"
                                f32 = rows[(skey, post, prep, lam)].get(key)
                                f64 = rows[(skey, post + AT64, prep, lam)].get(key)
                                # the fitted probe that reads the same representation as the transported one
                                staged["transport"].append({**F.meta, **smeta, "feature": post,
                                                            "prep": prep, "lam": lam, "precision": precision, **t,
                                                            "fitted_post_merge_err": f64 if precision == "float64"
                                                            else f32,
                                                            "fitted_post_merge_err_float32": f32,
                                                            "fitted_post_merge_err_float64": f64})
                                if not t["passed"]:
                                    state_ok[precision] = False
                                    (cst if precision == "float64" else cst32)["failures"].append(
                                        {"f0": bid, "state": skey, "prep": prep, "lam": lam,
                                         **{k: t[k] for k in ("partition", "solve_residual", "score_diff",
                                                              "disagree_frac", "disagree_outside_margin")}})
                cst["checked"] += 1
                cst["passed" if state_ok["float64"] else "failed"] += 1
                cst32["checked"] += 1
                cst32["passed" if state_ok["float32"] else "failed"] += 1
                mrow["transport_passed"] = state_ok["float64"]
                mrow["transport_passed_float32"] = state_ok["float32"]
                staged["maps"].append(mrow)

            f0meta = {"variant": "f0", "kind": "f0", "stage": "f0", "updates_since_f0": 0}
            one_state("f0", f0meta, F.f0, False)
            n_states += 1
            at2u = {}
            for v in sorted(F.J["exp"]):
                affine = P.exp_lev[v].get("act") == "identity"
                for stage, upd, ck in FP.expansion_states(P, F, v):
                    g = GraphNet.from_checkpoint(ck["model"], dev).eval()
                    skey = f"{v}@{stage}"
                    one_state(skey, {"variant": v, "kind": "expansion", "stage": stage, "updates_since_f0": upd}, g,
                              affine)
                    n_states += 1
                    if upd == P.fork_u:
                        at2u[v] = skey
            for v in sorted(F.J["comp"]):
                st_ = FP.compact_states(P, F, v, P.fork_u)
                if not st_ or st_[-1][1] != P.fork_u:
                    raise Fail(f"{v}: no saved state at the expansion's end ({P.fork_u})")
                stage, upd, ck = st_[-1]
                g = GraphNet.from_checkpoint(ck["model"], dev).eval()
                skey = f"{v}@{stage}"
                one_state(skey, {"variant": v, "kind": "compact", "stage": stage, "updates_since_f0": upd}, g, False)
                at2u[v] = skey
                n_states += 1
            want[bid] = n_states
            # ---- contrasts
            by_state = defaultdict(dict)
            for (skey, feat, prep, lam), r in rows.items():
                by_state[skey][(feat, prep, lam)] = r

            def con(comparison, r1, r2, second, metric="test_err", **extra):
                if r1.get(metric) is None or r2.get(metric) is None:
                    return
                staged["contrasts"].append({**F.meta, **{k: r1[k] for k in ("variant", "kind", "stage",
                                                                               "updates_since_f0")},
                                            "comparison": comparison, "feature": r1["feature"], "prep": r1["prep"],
                                            "lam": r1["lam"], "metric": metric, "second": second,
                                            "first_value": r1[metric], "second_value": r2[metric],
                                            "value": r1[metric] - r2[metric], "sign": "first - second",
                                            "comparable": extra.pop("comparable", ""),
                                            "comparability_note": extra.pop("comparability_note", ""), **extra})
            for skey, d in by_state.items():
                for (feat, prep, lam), r in d.items():
                    if feat.endswith(AT64):
                        continue
                    if feat.endswith(POST):
                        pre_f = feat[:-len(POST)]
                        wc = comparable[skey]
                        if prep == "whitened":
                            con("post_merge_minus_pre_merge", r, d[(pre_f, prep, lam)], f"{skey}|{pre_f}",
                                comparable=wc["eval"], comparability_note=wc["note"])
                            con("post_merge_minus_pre_merge", r, d[(pre_f, prep, lam)], f"{skey}|{pre_f}",
                                metric="fit_err", comparable=wc["fit"], comparability_note=wc["note"])
                        else:
                            con("post_merge_minus_pre_merge", r, d[(pre_f, prep, lam)], f"{skey}|{pre_f}")
                    if prep == "whitened":
                        con("whitened_minus_standardised", r, d[(feat, "standardised", lam)],
                            f"{skey}|{feat}|standardised")
                    if skey != "f0" and not feat.endswith(POST):
                        con("minus_f0", r, by_state["f0"][(feat, prep, lam)], "f0")
            for v, skey in at2u.items():
                if v in P.matched:
                    ck_ = at2u[P.matched[v]]
                    for (feat, prep, lam), r in by_state[skey].items():
                        if not feat.endswith(POST) and not feat.endswith(AT64):
                            con("expansion_minus_matched_compact_2U", r, by_state[ck_][(feat, prep, lam)], ck_)
            certified = {m_["variant"] + "@" + m_["stage"] for m_ in staged["maps"] if m_.get("transport_passed")}
            for t in staged["transport"]:
                if t["partition"] != "test":
                    continue
                sk = f"{t['variant']}@{t['stage']}"
                prec_ = t["precision"]
                if prec_ == "float64" and sk not in certified:
                    continue
                o = {**t, "test_err": t["transported_err"]}
                wcs = comparable64.get(sk) if prec_ == "float64" else comparable.get(sk)
                extra = ({"comparable": wcs["eval"], "comparability_note": wcs["note"]}
                         if t["prep"] == "whitened" and wcs is not None else {})
                # matched: the fitted and the transported probe read the same representation
                r = {**t, "test_err": t["fitted_post_merge_err"]}
                con(f"fitted_minus_transported_{prec_}", r, o,
                    f"transported pre-merge probe, both reading the {prec_} merge outputs", **extra)
                if prec_ == "float64":
                    # labelled: the fitted probe reads float32, the transported one float64 (v61's comparison)
                    r = {**t, "test_err": t["fitted_post_merge_err_float32"]}
                    con("fitted_minus_transported_mixed_precision", r, o,
                        "fitted on float32 outputs, transported through the float64 merge (mixed: not a "
                        "comparison of fitting against transport alone)",
                        **({"comparable": False, "comparability_note": "mixed precision: not a test of whitening "
                                                                       "invariance"} if t["prep"] == "whitened"
                           else {}))
            for k_, rows_ in staged.items():
                out[k_].extend(rows_)
            for k_ in ("expected", "eligible", "checked", "passed", "failed"):
                cert[k_] += cst[k_]
            for k_ in ("checked", "passed", "failed"):
                cert32[k_] += cst32[k_]
            cert32["failures"] += cst32["failures"]
            for k_, n_ in cst["skipped"].items():
                cert["skipped"][k_] = cert["skipped"].get(k_, 0) + n_
            cert["failures"] += cst["failures"]
            cov["analysed_f0"] += 1
            print(f"f0 {n_done}/{len(jobs)} analysed ({n_states} states)", flush=True)
        except Fail as ex_:
            cov["failed"].append({"f0": bid, "reason": str(ex_)})
            cov["probe_not_converged"] = [x for x in cov["probe_not_converged"] if x["f0"] != bid]
            print(f"FAIL f0 {bid}: {ex_}", file=sys.stderr)

    Pfx = a.out
    for t_ in ("maps", "transport", "precision", "probes", "contrasts"):
        SR.atomic_csv(f"{Pfx}_{t_}.csv", out.get(t_, []))

    def long(rows_, keys, metrics):
        return [{**{k: r.get(k) for k in keys + ("data_draw", "optimizer_seed")}, "metric": m, "v": float(r[m])}
                for r in rows_ for m in metrics if finite_number(r.get(m))]
    for name, keys, metrics in (
            ("maps", STATE_KEYS + ("map_source",), MAP_METRICS),
            ("transport", STATE_KEYS + ("precision", "prep", "lam", "partition"), TRANSPORT_METRICS),
            ("precision", STATE_KEYS + ("partition",), ("forward_residual32", "recovered_error32", "amplification",
                                                         "merge64_vs_map", "cond")),
            ("probes", PROBE_KEYS, tuple(f"{p}_err" for p in EVAL) + ("fit_err", "dims"))):
        bd, sm = SR.two_stage(long(out[name], keys, metrics), keys + ("metric",), "v")
        SR.atomic_csv(f"{Pfx}_{name}_by_draw.csv", bd)
        SR.atomic_csv(f"{Pfx}_{name}_summary.csv", sm)
    bd, sm = contrast_summaries(out["contrasts"])
    SR.atomic_csv(f"{Pfx}_contrasts_by_draw.csv", bd)
    SR.atomic_csv(f"{Pfx}_contrasts_summary.csv", sm)
    cnt = defaultdict(set)
    for r in out["probes"]:
        cnt[r["f0"]].add((r["variant"], r["stage"]))
    miss = [f"{bid}: {len(cnt[bid])} states, expected {n}" for bid, n in want.items()
            if bid in cnt and len(cnt[bid]) != n]
    n_t = cert["checked"] * len(PREPS) * len(LAMBDAS) * 2
    parts_n = {r["partition"] for r in out["transport"]}
    if len(out["transport"]) != n_t * len(parts_n or {0}) and n_t:
        miss.append(f"transport rows {len(out['transport'])}, expected {n_t} x {len(parts_n)} partitions")
    cov["design_ids"] = sorted({r["design_id"] for r in out["probes"]})
    cov["n_maps"] = len(out["maps"])
    cov["maps_by_source"] = {s_: sum(1 for r in out["maps"] if r["map_source"] == s_) for s_ in (MAP_EXACT, MAP_LS)}
    cov["whitening_comparable"] = {"comparable": sum(1 for r in out["maps"] if r["whitening_comparable"]),
                                   "comparable_on_the_fit_set": sum(1 for r in out["maps"]
                                                                    if r["whitening_comparable_fit"]),
                                   "not_comparable": defaultdict(int)}
    for r in out["maps"]:
        if not r["whitening_comparable"]:
            cov["whitening_comparable"]["not_comparable"][r["whitening_note"].split(" (")[0]] += 1
    passed_rows = [r for r in out["transport"] if r["passed"] and r["precision"] == "float64"]
    cert["passed_rows"] = len(passed_rows)
    cert["passed_rows_max_disagree_frac"] = max([r["disagree_frac"] for r in passed_rows] or [None]) \
        if passed_rows else None
    cert["passed_rows_max_abs_err_diff"] = max(abs(r["err_diff"]) for r in passed_rows) if passed_rows else None
    cert["passed_rows_with_flips"] = sum(1 for r in passed_rows if r["disagree_frac"] > 0)
    # the whitened summaries' coverage: planned against comparable draws and draw-seed pairs
    wcov = defaultdict(lambda: {"planned": set(), "comparable": set()})
    for r in out["contrasts"]:
        if r["comparison"] not in ("post_merge_minus_pre_merge", "fitted_minus_transported_float32",
                                   "fitted_minus_transported_float64") or r["prep"] != "whitened":
            continue
        k = (r["design_id"], r["comparison"], r["variant"], r["stage"], r["metric"], r["lam"])
        wcov[k]["planned"].add((r["data_draw"], r["optimizer_seed"]))
        if r["comparable"] is True:
            wcov[k]["comparable"].add((r["data_draw"], r["optimizer_seed"]))
    wrows = []
    for (did, cmp_, v, stg, met, lam), d in sorted(wcov.items(), key=lambda kv: tuple(map(str, kv[0]))):
        per = defaultdict(int)
        for dr, _ in d["comparable"]:
            per[dr] += 1
        planned_per = defaultdict(int)
        for dr, _ in d["planned"]:
            planned_per[dr] += 1
        wrows.append({"design_id": did, "comparison": cmp_, "variant": v, "stage": stg, "metric": met, "lam": lam,
                      "planned_draws": len(planned_per), "planned_pairs": len(d["planned"]),
                      "comparable_draws": len(per), "comparable_pairs": len(d["comparable"]),
                      "draws_with_fewer_seeds_than_planned": sum(1 for dr, n in per.items() if n < planned_per[dr])})
    SR.atomic_csv(f"{Pfx}_whitening_coverage.csv", wrows)
    cert["valid"] = cert["failed"] == 0 and cert["checked"] == cert["eligible"]
    cert["complete"] = cert["eligible"] == cert["expected"]
    cert["note"] = ("valid: no checked state failed and every eligible state was checked; complete: every affine "
                    "state with a merge was eligible (a singular map is skipped, never a success)")
    cov["transport_certificate"] = cert
    f32 = [r for r in out["transport"] if r["precision"] == "float32"]
    cert32["valid"] = cert32["failed"] == 0
    cert32["note"] = ("v60's certificate: the probe carried through the float32 post-merge activations the network "
                      "computes.  Reported, not decisive (v61): its failures measure how the merge's conditioning "
                      "amplifies float32 forward rounding; see _precision")
    cert32["max_disagree_frac"] = max([r["disagree_frac"] for r in f32] or [None]) if f32 else None
    cert32["max_abs_err_diff"] = max(abs(r["err_diff"]) for r in f32) if f32 else None
    cert32["max_score_diff"] = max(r["score_diff"] for r in f32) if f32 else None
    cov["transport_certificate_float32"] = cert32
    pr = out.get("precision", [])
    cov["precision"] = {"max_merge64_vs_map": max([r["merge64_vs_map"] for r in pr] or [None]) if pr else None,
                        "max_forward_residual32": max([r["forward_residual32"] for r in pr] or [None]) if pr else None,
                        "max_recovered_error32": max([r["recovered_error32"] for r in pr] or [None]) if pr else None,
                        "max_amplification": max([r["amplification"] for r in pr if r["amplification"] is not None]
                                                 or [None]) if pr else None}
    cov["output_membership_failures"] = miss
    cov["n_failed"] = len(cov["failed"])
    cov["n_probe_not_converged"] = len(cov["probe_not_converged"])
    cov["analysis_complete"] = cov["n_failed"] == 0 and cov["analysed_f0"] > 0 and not miss and \
        cov["analysed_f0"] == cov["expected_f0"] and not cov["probe_not_converged"]
    cov["passed"] = cov["analysis_complete"] and cert["valid"]
    Path(f"{Pfx}_coverage.json").write_text(json.dumps(cov, indent=1, default=str))
    print(json.dumps({"expected_f0": cov["expected_f0"], "analysed_f0": cov["analysed_f0"],
                      "analysis_complete": cov["analysis_complete"], "n_maps": cov["n_maps"],
                      "transport_certificate": {k: cert[k] for k in ("expected", "eligible", "checked", "passed",
                                                                     "failed", "valid", "complete")},
                      "passed": cov["passed"]}))
    return 1 if (a.strict and not cov["passed"]) else 0


if __name__ == "__main__":
    sys.exit(main())
