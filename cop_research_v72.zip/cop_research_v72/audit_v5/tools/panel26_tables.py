#!/usr/bin/env python3
"""v53: the wave-26 panel's paired tables, from the other tools' per-run tables (reads CSV files and the manifest
only; trains nothing, evaluates nothing).

Inputs: the manifest; selective_reversal's prefix (_trace.csv: the compact controls' and the expansions' states on
one clock, with their training cost); coordinated_edits' prefix (_age_course.csv: every expansion checkpoint);
gain_training's prefix (_gain_runs.csv).  The design is read from the manifest's configurations, not from names:
an expansion arm is a removal job's variant with its trajectory's hold (train.freeze_inputs / freeze_backbone),
gradient route (growth.spec_partition), addition activation (growth.act) and learning rate; a compact control's
matched arms are those with its hold and learning rate.

Tables (each with _by_draw and _summary: optimizer seeds averaged within a draw, 95% t intervals over draws):
  _arm_contrasts       pairs of expansion arms that differ in exactly ONE factor (activation, route, learning rate
                       or hold), at every checkpoint, for each of CONTRAST_METRICS: value = first - second
  _course              every expansion checkpoint and every compact checkpoint on the update clock: native and
                       extraction errors and the training cost since f0
  _excess              an expansion's extraction error minus its matched compact control's at the same update
                       (negative = the expansion's extraction is better), and at 2U against the compact control at
                       the first saved update with at least the expansion's training compute (backward-aware
                       analytic MACs; the update and the ratio are recorded)
  _gain_contrasts      the gain-trained f0 (each mode, at the end) against f0, each expansion's extraction at 2U and
                       each compact control's extraction at 2U: value = err(gain-trained) - err(other)
A pair the design holds whose value is missing on either side is listed in the coverage and fails the run.

usage: panel26_tables.py OUT_PREFIX --manifest M --reversal PREFIX --edits PREFIX --gains PREFIX [--strict]
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
import sys
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import selective_reversal as SR  # noqa: E402

ANALYSIS_SCHEMA = "panel26_tables/v53"
FACTORS = ("hold", "route", "act", "lr")
CONTRAST_METRICS = ("native_test_err", "deletion_test_err", "extraction_test_err", "extraction_val_err", "train_loss",
                    "train_err", "train_margin_q50", "u_rms_over_h_rms", "M_spectral", "M_top1_energy",
                    "affine_r2_train", "nonlinear_energy_share_test", "fold_minus_native_test_err",
                    "causal_norm_ratio", "shortcut_norm_ratio", "change_over_f0_L2")
COURSE_METRICS = ("native_test_err", "extraction_test_err", "extraction_val_err", "macs_backward_aware")
GAIN_METRICS = ("test_err", "val_err")


def rows_of(path) -> list:
    p = Path(path)
    if not p.exists():
        raise SR.Fail(f"missing input table {p}")
    if p.read_text().strip() == "empty":
        return []
    return list(csv.DictReader(open(p)))


def num(x):
    if x is None or x == "":
        return None
    return float(x)


def design(mcfg: dict) -> tuple:
    """-> (expansions {variant: factor levels}, compacts {variant: hold and lr}, groups {(draw, seed)} as strings,
    the expansion length 2U)."""
    exp, comp, groups, ages = {}, {}, set(), set()
    for rid, c in mcfg.items():
        des = c.get("design") or {}
        k = (str((c.get("data") or {}).get("data_seed")), str((c.get("seeds") or {}).get("optimizer")))
        if SR.eligible(c) == ("removal", "full"):
            t = mcfg.get((c.get("parents") or {}).get("trajectory"))
            if t is None:
                raise SR.Fail(f"{rid}: its trajectory is not in the manifest")
            tt, tg = t.get("train") or {}, t.get("growth") or {}
            lev = {"hold": f"{tt.get('freeze_inputs', 'none')}/{tt.get('freeze_backbone', 'none')}",
                   "route": tg.get("spec_partition"), "act": tg.get("act", "relu"), "lr": float(tt["lr"])}
            if exp.setdefault(des.get("variant"), lev) != lev:
                raise SR.Fail(f"variant {des.get('variant')}: its runs differ in hold, route, activation or rate")
            ages.add(int(tg["updates_per_round"]) * int(tg.get("rounds", 1)))
            groups.add(k)
        elif SR.eligible(c) == ("control", "control"):
            ct = c.get("train") or {}
            lev = {"hold": f"{ct.get('freeze_inputs', 'none')}/{ct.get('freeze_backbone', 'none')}",
                   "lr": float(ct["lr"])}
            if comp.setdefault(des.get("variant"), lev) != lev:
                raise SR.Fail(f"compact variant {des.get('variant')}: its runs differ in hold or rate")
            groups.add(k)
    if len(ages) != 1:
        raise SR.Fail(f"the expansions have no single length (found {sorted(ages)})")
    return exp, comp, groups, ages.pop()


def one_factor_pairs(exp: dict) -> list:
    """-> [(factor, first, second)]: every pair of arms that differ in exactly one factor, ordered so that the
    first is the altered arm: identity activation, all-example gradients, the lower rate, the held column."""
    def first(f, a, b):
        la, lb = exp[a][f], exp[b][f]
        if f == "act":
            return (a, b) if la != "relu" else (b, a)
        if f == "route":
            return (a, b) if la == "all_examples" else (b, a) if lb == "all_examples" else tuple(sorted((a, b)))
        if f == "lr":
            return (a, b) if la < lb else (b, a)
        return (a, b) if la != "none/none" and lb == "none/none" else (b, a) if lb != "none/none" and \
            la == "none/none" else tuple(sorted((a, b)))
    out = []
    for a, b in itertools.combinations(sorted(exp), 2):
        d = [f for f in FACTORS if exp[a][f] != exp[b][f]]
        if len(d) == 1:
            out.append((d[0], *first(d[0], a, b)))
    return sorted(out)


def matched_compact(exp: dict, comp: dict) -> dict:
    """-> {expansion variant: its compact control (same hold and learning rate) or None}."""
    out = {}
    for v, lev in exp.items():
        m = sorted(c for c, cl in comp.items() if cl["hold"] == lev["hold"] and cl["lr"] == lev["lr"])
        out[v] = m[0] if len(m) == 1 else None
    return out


def summarise(P: str, name: str, rows: list, keys: tuple, vk: str = "value") -> None:
    SR.atomic_csv(f"{P}_{name}.csv", rows)
    bd, sm = SR.two_stage(rows, keys, vk)
    SR.atomic_csv(f"{P}_{name}_by_draw.csv", bd)
    SR.atomic_csv(f"{P}_{name}_summary.csv", sm)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("out")
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--reversal", required=True, help="selective_reversal's output prefix")
    ap.add_argument("--edits", required=True, help="coordinated_edits' output prefix")
    ap.add_argument("--gains", required=True, help="gain_training's output prefix")
    ap.add_argument("--strict", action="store_true")
    a = ap.parse_args(argv)
    P = a.out
    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()[:16]        # noqa: E731
    cov = {"tool": "panel26_tables", "analysis_schema": ANALYSIS_SCHEMA, "manifest": a.manifest,
           "manifest_sha256": sha(a.manifest), "problems": [], "status": "exploratory; no contrast is primary"}
    try:
        mcfg = {e["run_id"]: e["cfg"] for e in SR.AC.manifest_entries(a.manifest)}
        exp, comp, groups, fork_u = design(mcfg)
        if not exp or not groups:
            raise SR.Fail("the manifest holds no expansion arm")
        pairs = one_factor_pairs(exp)
        mc = matched_compact(exp, comp)
        inputs = {"trace": f"{a.reversal}_trace.csv", "age_course": f"{a.edits}_age_course.csv",
                  "gain_runs": f"{a.gains}_gain_runs.csv"}
        tabs = {k: rows_of(p) for k, p in inputs.items()}
        cov.update({"inputs": {k: {"path": p, "sha256": sha(p), "rows": len(tabs[k])} for k, p in inputs.items()},
                    "expansions": exp, "compact_controls": comp, "matched_compact": mc, "groups": len(groups),
                    "expansion_updates": fork_u, "one_factor_pairs": [list(p) for p in pairs],
                    "contrast_metrics": list(CONTRAST_METRICS)})
        gk = lambda r: (str(r["data_draw"]), str(r["optimizer_seed"]))            # noqa: E731
        prob = cov["problems"]
        # ---- the expansions' checkpoints (coordinated_edits) and the states on the update clock (the trace)
        age = defaultdict(dict)                       # (variant, group) -> {checkpoint: row}
        for r in tabs["age_course"]:
            if r["checkpoint"] in age[(r["variant"], gk(r))]:
                prob.append({"table": "age_course", "problem": "duplicate", "key": [r["variant"], *gk(r),
                                                                                     r["checkpoint"]]})
            age[(r["variant"], gk(r))][r["checkpoint"]] = r
        for v in exp:
            for g in sorted(groups):
                if "final" not in age.get((v, g), {}):
                    prob.append({"table": "age_course", "problem": "missing", "key": [v, *g]})
        tr_c, tr_t = defaultdict(dict), defaultdict(dict)     # (variant, group) -> {update: {code: row}}
        for r in tabs["trace"]:
            if r["source"] in ("control", "trajectory"):
                d = (tr_c if r["source"] == "control" else tr_t)[(r["variant"], gk(r))]
                d.setdefault(int(float(r["updates_since_f0"])), {})[r["code"]] = r

        def codes(rows_by_code):
            K = len(next(iter(rows_by_code)).split("-"))
            return rows_by_code.get("-".join(["0"] * K)), rows_by_code.get("-".join(["0"] + ["1"] * (K - 1)))
        # ---- one-factor contrasts at every checkpoint
        ac = []
        for f, v1, v2 in pairs:
            for g in sorted(groups):
                r1, r2 = age.get((v1, g), {}), age.get((v2, g), {})
                for ck in sorted(set(r1) | set(r2)):
                    if ck not in r1 or ck not in r2:
                        prob.append({"table": "arm_contrasts", "problem": "missing checkpoint",
                                     "key": [v1, v2, *g, ck]})
                        continue
                    for m in CONTRAST_METRICS:
                        x1, x2 = num(r1[ck].get(m)), num(r2[ck].get(m))
                        if x1 is None and x2 is None:
                            continue                       # e.g. no fitted map at an insertion (zero output)
                        if x1 is None or x2 is None:
                            prob.append({"table": "arm_contrasts", "problem": "one side has no value",
                                         "key": [v1, v2, *g, ck, m]})
                            continue
                        ac.append({"factor": f, "first": v1, "second": v2, "first_levels": json.dumps(exp[v1]),
                                   "second_levels": json.dumps(exp[v2]), "checkpoint": ck,
                                   "updates_since_f0": int(float(r1[ck]["updates_since_f0"])), "metric": m,
                                   "data_draw": g[0], "optimizer_seed": g[1], "first_value": x1, "second_value": x2,
                                   "value": x1 - x2, "sign": "first - second"})
        summarise(P, "arm_contrasts", ac, ("factor", "first", "second", "checkpoint", "updates_since_f0", "metric",
                                           "sign"))
        # ---- the course on one clock
        course = []
        for (v, g), cks in age.items():
            if v not in exp:
                continue
            for ck, r in cks.items():
                u = int(float(r["updates_since_f0"]))
                tr = (tr_t.get((v, g), {}).get(u) or {})
                cost = num((next(iter(tr.values())) if tr else {}).get("macs_backward_aware"))
                course.append({"name": v, "kind": "expansion", "checkpoint": ck, "updates_since_f0": u,
                               "data_draw": g[0], "optimizer_seed": g[1],
                               "native_test_err": num(r["native_test_err"]),
                               "extraction_test_err": num(r["extraction_test_err"]),
                               "extraction_val_err": num(r["extraction_val_err"]), "macs_backward_aware": cost})
        for (c, g), us in tr_c.items():
            if c not in comp:
                continue
            for u, rc in us.items():
                z, x1 = codes(rc)
                if z is None or x1 is None:
                    prob.append({"table": "course", "problem": "a compact checkpoint lacks the native or the "
                                 "extraction code", "key": [c, *g, u]})
                    continue
                course.append({"name": c, "kind": "compact", "checkpoint": f"at_{u}", "updates_since_f0": u,
                               "data_draw": g[0], "optimizer_seed": g[1], "native_test_err": num(z["test_err"]),
                               "extraction_test_err": num(x1["test_err"]), "extraction_val_err": num(x1["val_err"]),
                               "macs_backward_aware": num(z.get("macs_backward_aware"))})
        long_ = [{**{k: r[k] for k in ("name", "kind", "checkpoint", "updates_since_f0", "data_draw",
                                       "optimizer_seed")}, "metric": m, "value": r[m]}
                 for r in course for m in COURSE_METRICS if r.get(m) is not None]
        SR.atomic_csv(f"{P}_course.csv", course)
        bd, sm = SR.two_stage(long_, ("name", "kind", "checkpoint", "updates_since_f0", "metric"), "value")
        SR.atomic_csv(f"{P}_course_by_draw.csv", bd)
        SR.atomic_csv(f"{P}_course_summary.csv", sm)
        cidx = {(r["name"], r["data_draw"], r["optimizer_seed"], r["updates_since_f0"]): r for r in course
                if r["kind"] == "compact"}
        # ---- an expansion's extraction against its matched compact control's
        ex = []
        for v in sorted(exp):
            c = mc[v]
            if c is None:
                cov.setdefault("no_matched_compact", []).append(v)
                continue
            for g in sorted(groups):
                for ck, r in sorted(age.get((v, g), {}).items()):
                    u = int(float(r["updates_since_f0"]))
                    if u == 0:
                        continue                           # the first insertion: the function and first layer are f0's
                    p = cidx.get((c, g[0], g[1], u))
                    if p is None:
                        prob.append({"table": "excess", "problem": "no compact state at this update",
                                     "key": [v, c, *g, u]})
                        continue
                    for m in ("extraction_test_err", "extraction_val_err"):
                        ex.append({"expansion": v, "compact": c, "match": "same update", "checkpoint": ck,
                                   "updates_since_f0": u, "compact_updates": u, "metric": m, "data_draw": g[0],
                                   "optimizer_seed": g[1], "expansion_value": num(r[m]), "compact_value": p[m],
                                   "value": num(r[m]) - p[m], "sign": "expansion - compact (negative = the "
                                   "expansion's extraction is better)", "compact_over_expansion_macs": None})
                # at 2U: the compact control at the first saved update with at least the expansion's compute
                fin = age.get((v, g), {}).get("final")
                tr = tr_t.get((v, g), {}).get(fork_u) or {}
                need = num((next(iter(tr.values())) if tr else {}).get("macs_backward_aware"))
                cands = sorted((u, r_) for (c_, d_, s_, u), r_ in cidx.items() if (c_, d_, s_) == (c, g[0], g[1])
                               and r_["macs_backward_aware"] is not None and need is not None
                               and r_["macs_backward_aware"] >= need)
                if fin is None or need is None or not cands:
                    prob.append({"table": "excess", "problem": "no compact state with at least the expansion's "
                                 "training compute (or the cost is not recorded)", "key": [v, c, *g]})
                    continue
                u2, p = cands[0]
                for m in ("extraction_test_err", "extraction_val_err"):
                    ex.append({"expansion": v, "compact": c, "match": "at least the expansion's compute",
                               "checkpoint": "final", "updates_since_f0": fork_u, "compact_updates": u2, "metric": m,
                               "data_draw": g[0], "optimizer_seed": g[1], "expansion_value": num(fin[m]),
                               "compact_value": p[m], "value": num(fin[m]) - p[m],
                               "sign": "expansion - compact (negative = the expansion's extraction is better)",
                               "compact_over_expansion_macs": p["macs_backward_aware"] / need})
        summarise(P, "excess", ex, ("expansion", "compact", "match", "checkpoint", "updates_since_f0", "metric",
                                    "sign"))
        cu = sorted({r["compact_updates"] for r in ex if r["match"] != "same update"})
        ratios = [r["compact_over_expansion_macs"] for r in ex if r["match"] != "same update"]
        cov["compute_match"] = {"compact_updates_used": cu,
                                "compact_over_expansion_macs_min": min(ratios) if ratios else None,
                                "compact_over_expansion_macs_max": max(ratios) if ratios else None,
                                "estimate": "backward-aware analytic MACs since f0 (linear-type nodes)"}
        # ---- the gain-trained f0
        gr = defaultdict(dict)
        for r in tabs["gain_runs"]:
            gr[(r["mode"], gk(r))][int(float(r["age"]))] = r
        modes = sorted({m for m, _ in gr})
        if not modes:
            prob.append({"table": "gain_contrasts", "problem": "no gain-trained f0"})
        gc = []
        for mode in modes:
            for g in sorted(groups):
                r = gr.get((mode, g), {}).get(fork_u)
                if r is None:
                    prob.append({"table": "gain_contrasts", "problem": "missing", "key": [mode, *g]})
                    continue
                refs = [("f0", "f0", {"test_err": num(r["f0_test_err"]), "val_err": num(r["f0_val_err"])})]
                for v in sorted(exp):
                    f_ = age.get((v, g), {}).get("final")
                    if f_ is not None:
                        refs.append((f"{v} extraction at 2U", "expansion extraction",
                                     {"test_err": num(f_["extraction_test_err"]),
                                      "val_err": num(f_["extraction_val_err"])}))
                for c in sorted(comp):
                    p = cidx.get((c, g[0], g[1], fork_u))
                    if p is not None:
                        refs.append((f"{c} extraction at 2U", "compact extraction",
                                     {"test_err": p["extraction_test_err"], "val_err": p["extraction_val_err"]}))
                for name, kind, val in refs:
                    for m in GAIN_METRICS:
                        gc.append({"mode": mode, "access": r["access"], "other": name, "other_kind": kind,
                                   "metric": m, "data_draw": g[0], "optimizer_seed": g[1],
                                   "gain_trained_value": num(r[m]), "other_value": val[m],
                                   "value": num(r[m]) - val[m],
                                   "sign": "gain-trained f0 - other (negative = the gain-trained f0 is better)"})
        summarise(P, "gain_contrasts", gc, ("mode", "access", "other", "other_kind", "metric", "sign"))
        cov["rows"] = {"arm_contrasts": len(ac), "course": len(course), "excess": len(ex), "gain_contrasts": len(gc)}
        # every declared pair must be complete: one value per group, checkpoint and metric where either side has one
        want_ex = sum(1 for v in exp if mc[v] is not None) * len(groups) * 2
        got_ex = sum(1 for r in ex if r["match"] != "same update")
        if got_ex != want_ex:
            prob.append({"table": "excess", "problem": f"{got_ex} compute-matched rows, expected {want_ex}"})
        want_gc = len(modes) * len(groups) * (1 + len(exp) + len(comp)) * len(GAIN_METRICS)
        if len(gc) != want_gc:
            prob.append({"table": "gain_contrasts", "problem": f"{len(gc)} rows, expected {want_gc}"})
    except SR.Fail as ex_:
        cov["problems"].append({"problem": str(ex_)})
        print(f"FAIL: {ex_}", file=sys.stderr)
    cov["passed"] = not cov["problems"] and bool(cov.get("rows", {}).get("arm_contrasts"))
    Path(f"{P}_coverage.json").write_text(json.dumps(cov, indent=1, default=str))
    print(json.dumps({"passed": cov["passed"], "problems": len(cov["problems"]), "rows": cov.get("rows")}))
    return 1 if (a.strict and not cov["passed"]) else 0


if __name__ == "__main__":
    sys.exit(main())
