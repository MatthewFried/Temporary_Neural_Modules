"""v33 / v34: how the additions' and the first layer's portability changes over a growth history.  Read-only;
trains nothing.

  python audit_v5/tools/portability_age.py RESULTS OUT_PREFIX --manifest M [--strict] [--data-root DIR]
         [--device cpu] [--maps-dir DIR] [--no-maps]

Population (manifest-driven).  Eligible: every trajectory of the manifest with the specialised topology and
declared train.snapshot_at.  Supported layout: two rounds, incremental schedule, no contraction, snapshot ages
strictly inside (0, 2U] other than U; an eligible trajectory with another layout is a coverage failure.
Pairing policy 'independent_replicates': two eligible trajectories pair when their configs are equal except for
the parents and the seed streams optimizer / init / minibatch / augmentation / insertion / partition, and every one
of the resolved optimizer, init, minibatch, insertion and partition seeds differs between them (independent f0,
minibatch order, insertion and branch split; the same data draw, model, growth and recipe).  Each must have exactly
one partner (no partner, or several, is a failure).  Each pair gives two directions (host -> partner).  The
seeds of both are recorded.

Stages (from the config, never from the files present), with the trajectory clock trajectory_updates u (updates
of the trajectory's own training) and an explicit event order:
  post_insert_r1 (u = 0, round-1 additions at insertion: age 0), snap_<u> for u < U, round_1 (u = U, before the
  second insertion), post_insert_r2 (u = U, after it: the round-2 additions at age 0), snap_<u> for U < u < 2U,
  final (u = 2U).  Per branch slot: its cohort (r1 / r2) and age (u - (r - 1) U), checked against the checkpoint.
  round_1 and post_insert_r2 share the clock but are distinct stages; summaries never merge them.

Integrity (every loaded checkpoint): config on disk equal to the manifest's; status complete; lineage run / stage /
config hash; parameter and graph hashes recomputed; finite tensors; no recorded divergence; recorded data hashes
equal to the regenerated ones for train and every evaluated partition; the trainer's update counter (minus the
start's) equal to the stage's u; the branch players and their ages as declared; finite predictions.  At the
insertions the function must be preserved (post_insert_r1 against f0, post_insert_r2 against round_1: identical
decisions, max |diff| <= 1e-5 x max(1, max |ref|)), and at post_insert_r1 the branch-deleted backbone must equal
f0 bitwise.

Measures (val / val_indep / test / cf_shortcut / cf_causal / shift / rare errors and the shortcut flip rate):
  native, per run and stage:
    host_intact / host_without        the host, and with every addition deleted (frozen)
  per direction and stage (recipient = the partner):
    branches_raw / branches_aligned   the host's branches of a subset copied into the partner in place of the
                                      partner's own, raw and through the per-branch affine interface fitted on
                                      training inputs (dissipation.align_swapped); subsets: all players, and once
                                      round 2 exists the r1 cohort and the r2 cohort separately
    branches_self_aligned             positive control: the partner's own branches through the same fit (the raw
                                      self copy must reproduce the partner bitwise)
    first_layer_into_own_f0           the host's branch-deleted first layer in its own f0 (no interface)
    first_layer_into_partner_f0       the same layer in the partner's f0 through identity / permutation / affine
                                      interfaces (cross_transplant), folded into the partner's second layer
    compact_intact / compact_first_layer_into_own_f0 / compact_first_layer_into_partner_f0
                                      the host draw's C1_phase continuation (f0 trained on without additions) at
                                      the same u, when the manifest declares that checkpoint (eval_at with
                                      save_eval_checkpoints): the time-matched learning without additions
  per direction, stage-free controls through the same interfaces into the partner's f0:
    donor_f0_layer / random_layer / self_layer   (the host's f0 first layer; a fixed-seed default-initialised
                                      layer; the partner's own first layer: identity and permutation must
                                      reproduce the partner's f0 bitwise)
Every alignment's status is recorded per branch (fitted / identity_fallback / unsupported / numerical_failure);
any unsupported or numerical failure fails the direction.  Fitted maps are saved (MAPS_DIR/<host>__<partner>.pt,
float64, with the source run / stage / parameter hashes) and every saved map is refolded from freshly loaded
checkpoints and must reproduce the in-memory test predictions bitwise (--no-maps skips saving and the check:
exploratory only).

References and contrasts.  Each row carries its RECIPIENT's references: ref_f0_* (the recipient's f0; the host's
own f0 for native rows and first_layer_into_own_f0), ref_intact_* / ref_without_* (the recipient at the same
stage, for branch transfers and native rows), ref_donor_f0_ctrl_* / ref_random_ctrl_* (the stage-free controls
through the same interface, for first-layer rows), and gain_vs_<ref>_<metric> = reference - value (positive =
lower error).  Rows are paired within a direction before any averaging.

Outputs (atomic): _rows.csv, _by_draw.csv (directions / runs averaged within each data draw), _summary.csv (over
unique data draws: mean, draw-level t interval, draws with a positive gain, for gain_vs_f0_test_err and the other
gains), _checks.csv, _coverage.json (expected and analysed units listed by key; cost: wall time, alignment fitting
MACs, map storage), _diagnostic_partial.csv.  Only a direction whose every unit passes is committed.  These are
intervention outcomes in a co-evolving pair of networks (the recipient also learns over u), not an additive
account of where learning resides and not an isolated effect of branch age."""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import re
import sys
import time
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import torch  # noqa: E402

from cop.analysis.v13_tables import draw_role  # noqa: E402
from cop.config import seed_of  # noqa: E402
from cop.data.registry import load_bundle  # noqa: E402
from cop.experiments.dissipation import (apply_saved_alignment, branch_ages, swap_players,  # noqa: E402
                                         transfer_models)
from cop.graph.graph import GraphNet  # noqa: E402
from cop.utils import stable_hash  # noqa: E402
import audit_common as AC  # noqa: E402
import cross_transplant as CT  # noqa: E402
import selective_reversal as SR  # noqa: E402

Fail = AC.Fail
POLICY = "independent_replicates"
FREE_STREAMS = ("optimizer", "init", "minibatch", "augmentation", "insertion", "partition")
MUST_DIFFER = ("optimizer", "init", "minibatch", "insertion", "partition")
T95 = SR.T95


# ----------------------------------------------------------------------------- design

def eligible(cfg: dict) -> bool:
    return cfg.get("kind") == "trajectory" and (cfg.get("growth") or {}).get("topology") == "specialized" and \
        bool((cfg.get("train") or {}).get("snapshot_at"))


def expected_stages(cfg: dict) -> list[dict]:
    """the declared stages in event order (see the module docstring)."""
    g = cfg["growth"]
    U, R = int(g["updates_per_round"]), int(g.get("rounds", 1))
    if R != 2 or g.get("schedule", "incremental") != "incremental" or int(g.get("contract_every", 0) or 0):
        raise Fail("age layout: supported for two incremental rounds without contraction only")
    snaps = sorted({int(u) for u in cfg["train"]["snapshot_at"]})
    if any(u <= 0 or u > 2 * U or u == U for u in snaps):
        raise Fail(f"age layout: snapshot ages {snaps} must lie in (0, 2U] and differ from U = {U}")
    st = [("post_insert_r1", 0)] + [(f"snap_{u}", u) for u in snaps if u < U] + \
         [("round_1", U), ("post_insert_r2", U)] + [(f"snap_{u}", u) for u in snaps if u > U] + [("final", 2 * U)]
    out = []
    for i, (name, u) in enumerate(st):
        r2 = name == "post_insert_r2" or u > U
        out.append({"stage": name, "u": u, "event_order": i, "cohorts": ("r1", "r2") if r2 else ("r1",),
                    "ages": {"r1": u, **({"r2": u - U} if r2 else {})}})
    return out


def pair_key(cfg: dict) -> str:
    c = copy.deepcopy(cfg)
    c.pop("parents", None)
    sd = c.pop("seeds", {}) or {}
    c["_fixed_streams"] = {k: v for k, v in sd.items() if k not in FREE_STREAMS}
    return json.dumps(c, sort_keys=True, default=str)


def streams(cfg: dict) -> dict:
    return {s: seed_of(cfg, s) for s in ("optimizer", "init", "minibatch", "augmentation", "insertion", "partition")}


def pairs_from(mcfg: dict) -> tuple[list, list]:
    """-> (directions [(host id, partner id)], failures)."""
    groups, fails = defaultdict(list), []
    for rid, c in mcfg.items():
        if eligible(c):
            groups[pair_key(c)].append(rid)
    dirs = []
    for key, mem in sorted(groups.items()):
        mem = sorted(mem)
        if len(mem) != 2:
            for rid in mem:
                fails.append({"run_id": rid, "reason": f"pairing ({POLICY}): {len(mem)} eligible trajectories share "
                                                       f"this design, exactly two are required"})
            continue
        a, b = mem
        sa, sb = streams(mcfg[a]), streams(mcfg[b])
        same = [s for s in MUST_DIFFER if sa[s] == sb[s]]
        if same:
            for rid in mem:
                fails.append({"run_id": rid, "reason": f"pairing ({POLICY}): streams {same} are equal in the pair"})
            continue
        if mcfg[a]["parents"].get("baseline") == mcfg[b]["parents"].get("baseline"):
            for rid in mem:
                fails.append({"run_id": rid, "reason": f"pairing ({POLICY}): both start from the same f0"})
            continue
        dirs += [(a, b), (b, a)]
    return dirs, fails


def compact_partner(mcfg: dict, cfg: dict):
    """the C1_phase continuation of the same f0 (None when the manifest has none); -> (run id, cfg, declared u)."""
    hits = [(rid, c) for rid, c in mcfg.items() if c.get("kind") == "continue"
            and (c.get("design") or {}).get("arm") == "C1_phase"
            and (c.get("parents") or {}).get("baseline") == cfg["parents"].get("baseline")
            and c.get("data") == cfg.get("data")]
    if not hits:
        return None
    if len(hits) > 1:
        raise Fail(f"compact reference: {len(hits)} C1_phase continuations of the same f0")
    rid, c = hits[0]
    cc = c.get("continue") or {}
    if not cc.get("save_eval_checkpoints"):
        return rid, c, set()
    total = sum(int(x) for x in cc.get("segments") or []) or int(cc.get("updates", 0) or 0)
    return rid, c, {int(u) for u in cc.get("eval_at") or [] if 0 < int(u) <= total}


def plan_units(stages: list, compact_us: set) -> list[tuple]:
    """every row a direction must produce: (stage, measure, subset, interface)."""
    out = [("none", f"{k}_layer_into_partner_f0", "", itf) for k in ("donor_f0", "random", "self")
           for itf in CT.INTERFACES]
    for s in stages:
        st = s["stage"]
        out += [(st, "host_intact", "", ""), (st, "host_without", "", "")]
        subs = ["all"] + (list(s["cohorts"]) if len(s["cohorts"]) > 1 else [])
        for sub in subs:
            out += [(st, "branches_raw", sub, ""), (st, "branches_aligned", sub, "")]
        out.append((st, "branches_self_aligned", "all", ""))
        out.append((st, "first_layer_into_own_f0", "", ""))
        out += [(st, "first_layer_into_partner_f0", "", itf) for itf in CT.INTERFACES]
        if s["u"] > 0 and s["u"] in compact_us:
            out += [(st, "compact_intact", "", ""), (st, "compact_first_layer_into_own_f0", "", "")]
            out += [(st, "compact_first_layer_into_partner_f0", "", itf) for itf in CT.INTERFACES]
    return out


# ----------------------------------------------------------------------------- aggregation

def draw_levels(rows: list[dict], keys: tuple) -> tuple[list, list]:
    """directions (and runs) averaged within each data draw; the summary over unique data draws."""
    groups = defaultdict(lambda: defaultdict(list))
    for r in rows:
        groups[tuple(r.get(k) for k in keys)][r["data_draw"]].append(r)
    by_draw, summ = [], []
    for k, draws in sorted(groups.items(), key=lambda t: tuple(map(str, t[0]))):
        first = next(iter(draws.values()))[0]
        met = [x for x in first if (x.endswith("_err") or x.endswith("flip_rate")) and isinstance(first[x], float)
               or x.startswith("gain_vs_")]
        dms = []
        for ds, rr in sorted(draws.items(), key=lambda t: str(t[0])):
            m = {}
            for x in met:
                vals = [r[x] for r in rr if r.get(x) is not None]
                m[x] = sum(vals) / len(vals) if len(vals) == len(rr) else None
            dms.append(m)
            by_draw.append({**dict(zip(keys, k)), "data_draw": ds, "n_rows": len(rr),
                            "directions": " ".join(sorted(f"{r['run_id']}>{r['recipient_run']}" for r in rr)), **m})
        n = len(dms)
        rec = {**dict(zip(keys, k)), "n_unique_data_draws": n, "n_rows": sum(len(v) for v in draws.values())}
        for x in met:
            vals = [m[x] for m in dms if m[x] is not None]
            if len(vals) != n or not n:
                rec[f"mean_{x}"] = None
                continue
            mu = sum(vals) / n
            rec[f"mean_{x}"] = mu
            if x.startswith("gain_vs_"):
                sd = (sum((v - mu) ** 2 for v in vals) / (n - 1)) ** 0.5 if n > 1 else None
                t = T95.get(n - 1, 2.0) if n > 1 else None
                rec[f"{x}_ci95_low"] = mu - t * sd / n ** 0.5 if sd is not None else None
                rec[f"{x}_ci95_high"] = mu + t * sd / n ** 0.5 if sd is not None else None
                rec[f"{x}_draws_positive"] = f"{sum(v > 0 for v in vals)}/{n}"
        summ.append(rec)
    return by_draw, summ


def with_refs(row: dict, refs: dict) -> dict:
    """refs: name -> metric dict; adds ref_<name>_<metric> and gain_vs_<name>_<metric> = ref - value."""
    out = dict(row)
    for nm, ref in refs.items():
        for mk, v in ref.items():
            out[f"ref_{nm}_{mk}"] = v
            if mk in row and row[mk] is not None and v is not None:
                out[f"gain_vs_{nm}_{mk}"] = v - row[mk]
    return out


# ----------------------------------------------------------------------------- main

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("results")
    ap.add_argument("out_prefix")
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--strict", action="store_true")
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--no-maps", action="store_true", help="exploratory: do not save or re-verify fitted maps")
    ap.add_argument("--maps-dir", default=None, help="where the fitted maps go (default OUT_PREFIX_maps)")
    a = ap.parse_args()
    if a.strict and a.no_maps:
        ap.error("--no-maps is exploratory: a strict analysis saves and re-verifies every fitted map")
    dev = a.device
    runs = Path(a.results) / "runs"
    P = a.out_prefix
    mdir = Path(a.maps_dir or f"{P}_maps")
    cov = {"tool_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()[:16], "manifest": a.manifest,
           "manifest_sha256": hashlib.sha256(Path(a.manifest).read_bytes()).hexdigest()[:16],
           "pairing_policy": POLICY, "free_streams": list(FREE_STREAMS), "must_differ": list(MUST_DIFFER),
           "expected_directions": 0, "analysed_directions": 0, "expected_units": 0, "analysed_units": 0,
           "failed": [], "missing_units": [], "cost": {"directions": []}}
    t_all = time.time()
    rows, checks, partial = [], [], []
    try:
        mcfg = {e["run_id"]: e["cfg"] for e in AC.manifest_entries(a.manifest)}
        dirs, pfails = pairs_from(mcfg)
    except Fail as ex:
        mcfg, dirs, pfails = {}, [], [{"run_id": None, "reason": str(ex)}]
    cov["failed"] += pfails
    cov["eligible_trajectories"] = sorted(r for r, c in mcfg.items() if eligible(c))
    cov["expected_directions"] = len(dirs) + len({f["run_id"] for f in pfails if f["run_id"]})
    bundles = {}
    for hid, pid in dirs:
        cfg, pcfg = mcfg[hid], mcfg[pid]
        staged, staged_checks, keys_done = [], [], set()
        t0 = time.time()
        fit_macs, map_bytes, map_sha = 0, 0, None
        units = []
        try:
            stages = expected_stages(cfg)
            if [s["stage"] for s in expected_stages(pcfg)] != [s["stage"] for s in stages]:
                raise Fail("the pair's declared stages differ")
            cp = compact_partner(mcfg, cfg)
            compact_us = cp[2] if cp else set()
            units = plan_units(stages, compact_us)
            cov["expected_units"] += len(units)
            AC.job_config(runs, hid, cfg)
            AC.job_config(runs, pid, pcfg)
            if cp:
                AC.job_config(runs, cp[0], cp[1])
            d, pd = runs / hid, runs / pid
            dkey = json.dumps(cfg["data"], sort_keys=True)
            if dkey not in bundles:
                b0 = load_bundle(cfg["data"], a.data_root, device="cpu")
                bundles[dkey] = (b0.to(dev), b0.hashes())
            b, hashes = bundles[dkey]
            ps = AC.eval_partitions(b)
            need = {"train", *ps}
            for dd in (d, pd):
                AC.check_logged_data(dd, hashes, need, dd.name)
            batch = int((cfg.get("train") or {}).get("eval_batch", 4096))
            U = int(cfg["growth"]["updates_per_round"])

            def load(run_dir, stage, label, cfg_=None):
                ck = SR.ckp(run_dir, stage)
                AC.check_ckpt(ck, label, run_id=run_dir.name, stage=stage, cfg=cfg_, hashes=hashes, need=need)
                return ck

            def meas(m, label):
                return AC.finite_eval(m, b, ps, batch, label)

            bk_h = load(d, "baseline_ref", f"{hid}/baseline_ref", cfg)
            bk_p = load(pd, "baseline_ref", f"{pid}/baseline_ref", pcfg)
            f0h = GraphNet.from_checkpoint(bk_h["model"], dev).eval()
            f0p = GraphNet.from_checkpoint(bk_p["model"], dev).eval()
            f0h_e, f0h_p = meas(f0h, "host f0")
            f0p_e, f0p_p = meas(f0p, "partner f0")
            L = SR.backbone_layers(f0p)
            if SR.backbone_layers(f0h) != L:
                raise Fail("host and partner f0 have different backbone layers")
            _, act, _ = CT.first_block(f0p, L)
            _, act_h, _ = CT.first_block(f0h, L)
            r_sd = {k: v.clone() for k, v in f0p.state_dict().items()}
            h_sd = {k: v.clone() for k, v in f0h.state_dict().items()}
            Hr = CT.hidden(f0p, act, b.train.X)
            Hw = r_sd[f"mods.{L[0]}.weight"]
            H = Hw.shape[0]
            eyeA, zc = torch.eye(H, dtype=torch.float64), torch.zeros(H, dtype=torch.float64)
            ss_h, ss_p = streams(cfg), streams(pcfg)
            meta = {"run_id": hid, "recipient_run": pid, "pairing_policy": POLICY,
                    "variant": cfg["growth"].get("spec_partition"), "cell": (cfg.get("data") or {}).get("name"),
                    "data_draw": cfg["data"].get("data_seed"),
                    # one role per PAIR (the legacy rule depends on the optimizer seed, which would split the two
                    # directions of a draw into different summary groups)
                    "draw_set": "+".join(sorted({draw_role(cfg), draw_role(pcfg)})),
                    "analysis_role": "exploratory (a new analysis of the replication draws; not preregistered)",
                    "optimizer_seed": ss_h["optimizer"], "recipient_optimizer_seed": ss_p["optimizer"],
                    **{f"host_{k}_seed": v for k, v in ss_h.items()},
                    **{f"recipient_{k}_seed": v for k, v in ss_p.items()},
                    "compact_run": cp[0] if cp else None}
            maps, recon = {}, []

            def put(stage_rec, measure, subset, interface, e, refs, extra=None):
                key = (stage_rec["stage"] if stage_rec else "none", measure, subset, interface)
                if key in keys_done:
                    raise Fail(f"duplicated output key {key}")
                keys_done.add(key)
                srow = {} if stage_rec is None else {
                    "stage": stage_rec["stage"], "event_order": stage_rec["event_order"],
                    "trajectory_updates": stage_rec["u"], "cohorts_present": "+".join(stage_rec["cohorts"]),
                    "age_r1": stage_rec["ages"].get("r1"), "age_r2": stage_rec["ages"].get("r2")}
                if stage_rec is None:
                    srow = {"stage": "none", "event_order": -1, "trajectory_updates": None, "cohorts_present": "",
                            "age_r1": None, "age_r2": None}
                staged.append(with_refs({**meta, **srow, "measure": measure, "subset": subset,
                                         "interface": interface, **(extra or {}), **e}, refs))

            def first_layer_rows(stage_rec, prefix, Wd, bd_, refs_base, ctrl):
                """a first layer (Wd, bd_) into the partner's f0 through every interface; returns the fitted maps."""
                probe = GraphNet.from_checkpoint(bk_p["model"], dev).eval()
                probe.load_state_dict(CT.fold_first_layer(r_sd, L, Wd, bd_, eyeA, zc))
                probe._plan = None
                Hd = CT.hidden(probe, act, b.train.X)
                out = {}
                for itf in CT.INTERFACES:
                    lab = f"{stage_rec['stage'] if stage_rec else 'none'}/{prefix}/{itf}"
                    A, c, n_par, r2 = CT.fit_checked(itf, Hd, Hr, lab)
                    probe.load_state_dict(CT.fold_first_layer(r_sd, L, Wd, bd_, A, c))
                    probe._plan = None
                    e, pr = meas(probe, lab)
                    refs = dict(refs_base)
                    if ctrl is not None:
                        refs["donor_f0_ctrl"], refs["random_ctrl"] = ctrl["donor_f0"][itf], ctrl["random"][itf]
                    put(stage_rec, prefix, "", itf, e, refs, {"interface_params": n_par, "interface_train_r2": r2})
                    out[itf] = (e, A, c, pr["test"].detach().cpu())
                return out

            # ---- stage-free controls through the same interfaces into the partner's f0
            gen = torch.Generator().manual_seed(12345)
            bound = 1.0 / Hw.shape[1] ** 0.5
            rand_w = (torch.rand(Hw.shape, generator=gen, dtype=torch.float64) * 2 - 1) * bound
            rand_b = (torch.rand(H, generator=gen, dtype=torch.float64) * 2 - 1) * bound
            ctrl = {}
            for k, (Wd, bd_) in (("donor_f0", (h_sd[f"mods.{L[0]}.weight"].double(), h_sd[f"mods.{L[0]}.bias"].double())),
                                 ("random", (rand_w, rand_b)),
                                 ("self", (r_sd[f"mods.{L[0]}.weight"].double(), r_sd[f"mods.{L[0]}.bias"].double()))):
                res = first_layer_rows(None, f"{k}_layer_into_partner_f0", Wd.to(dev), bd_.to(dev), {"f0": f0p_e},
                                       None)
                ctrl[k] = {itf: v[0] for itf, v in res.items()}
                if k == "self":
                    # the identity interface must reproduce f0 bitwise; the permutation is recorded only (units
                    # dead or tied on the training inputs make the matching among them arbitrary)
                    for itf in ("identity", "permutation"):
                        ok = torch.equal(res[itf][3], f0p_p["test"].detach().cpu())
                        staged_checks.append({**meta, "stage": "none", "check": f"self_layer_{itf}_reproduces_f0",
                                              "passed": ok, "required": itf == "identity",
                                              "permutation_is_identity": bool(torch.equal(res[itf][1].cpu(), eyeA))})
                        if itf == "identity" and not ok:
                            raise Fail("the partner's own first layer through the identity does not reproduce its f0")
            # ---- stages
            prev_pred = {"host": None}
            for s in stages:
                st, u = s["stage"], s["u"]
                hck = load(d, st, f"{hid}/{st}", cfg)
                pck = load(pd, st, f"{pid}/{st}", pcfg)
                for nm, ck, bk, rid_ in (("host", hck, bk_h, hid), ("partner", pck, bk_p, pid)):
                    got = AC.job_update(ck, bk, f"{rid_}/{st}")
                    if got != u:
                        raise Fail(f"{rid_}/{st}: trainer counter says {got} updates, the stage is at {u}")
                host = GraphNet.from_checkpoint(hck["model"], dev).eval()
                part = GraphNet.from_checkpoint(pck["model"], dev).eval()
                for nm, m, ck, bk in (("host", host, hck, bk_h), ("partner", part, pck, bk_p)):
                    players = swap_players(m)
                    want = sorted(f"spec/{c}/{x}" for c in s["cohorts"] for x in ("a", "b"))
                    if players != want:
                        raise Fail(f"{nm}/{st}: branch players {players}, declared {want}")
                    ag = branch_ages(m, ck, bk, U)["ages"]
                    exp_ag = {sl: s["ages"][sl.split("/")[1]] for sl in want}
                    if ag != exp_ag:
                        raise Fail(f"{nm}/{st}: branch ages {ag}, declared {exp_ag}")
                hi_e, hi_p = meas(host, f"{st}/host")
                pi_e, pi_p = meas(part, f"{st}/partner")
                hc = CT.compact_graph(hck["model"], dev, f"{st}/host")
                pc = CT.compact_graph(pck["model"], dev, f"{st}/partner")
                hw_e, _ = meas(hc, f"{st}/host_without")
                pw_e, _ = meas(pc, f"{st}/partner_without")
                if SR.backbone_layers(hc) != L or SR.backbone_layers(pc) != L:
                    raise Fail(f"{st}: compact backbone layers differ from f0's")
                # function preservation at the insertions, and the age-zero backbone
                if st in ("post_insert_r1", "post_insert_r2"):
                    ref = f0h_p["test"] if st == "post_insert_r1" else prev_pred["round_1"]
                    ok, diff = AC.same_function(ref, hi_p["test"])
                    staged_checks.append({**meta, "stage": st, "check": "insertion_preserves_function", "passed": ok,
                                          "max_abs_diff": diff})
                    if not ok:
                        raise Fail(f"{st}: the insertion changed the host's function (max |diff| {diff})")
                if st == "post_insert_r1":
                    hs0 = hc.state_dict()
                    ok = all(torch.equal(hs0[k].cpu(), h_sd[k].cpu()) for k in h_sd if k.startswith("mods."))
                    staged_checks.append({**meta, "stage": st, "check": "age_zero_backbone_equals_f0", "passed": ok})
                    if not ok:
                        raise Fail("post_insert_r1: the branch-deleted backbone is not f0")
                prev_pred[st] = hi_p["test"]
                put(s, "host_intact", "", "", hi_e, {"f0": f0h_e, "intact": hi_e, "without": hw_e})
                put(s, "host_without", "", "", hw_e, {"f0": f0h_e, "intact": hi_e, "without": hw_e})
                prefs = {"f0": f0p_e, "intact": pi_e, "without": pw_e}
                # branches: all players, and each cohort once round 2 exists
                players = swap_players(part)
                subs = {"all": players}
                if len(s["cohorts"]) > 1:
                    subs.update({c: [p_ for p_ in players if p_.split("/")[1] == c] for c in s["cohorts"]})
                for sub, slots in subs.items():
                    mp = {}
                    t = transfer_models(part, host, slots, b, batch, align=True, maps=mp)
                    ad = t["adapter"]
                    fit_macs += int(ad.get("fit_macs_total", 0))
                    staged_checks.append({**meta, "stage": st, "check": f"alignment_{sub}", "passed": bool(ad["ok"]),
                                          **{f"n_{k}": v for k, v in ad["status_counts"].items()},
                                          "detail": json.dumps({k: v.get("status") for k, v in ad["branches"].items()})})
                    if not ad["ok"]:
                        raise Fail(f"{st}/{sub}: alignment failed {ad['status_counts']}")
                    e_raw, _ = meas(t["raw"], f"{st}/{sub}/raw")
                    e_al, p_al = meas(t["aligned"], f"{st}/{sub}/aligned")
                    sub_ages = "+".join(f"{sl}:{s['ages'][sl.split('/')[1]]}" for sl in slots)
                    common = {"n_branch_players": len(slots), "subset_slots": " ".join(slots), "subset_ages": sub_ages,
                              "values_copied": t["info"]["values_copied"]}
                    put(s, "branches_raw", sub, "", e_raw, prefs, common)
                    res = [v.get("train_rel_residual_aligned") for v in ad["branches"].values()]
                    put(s, "branches_aligned", sub, "", e_al, prefs,
                        {**common, "adapter_params": ad["params"], "adapter_fit_macs": ad["fit_macs_total"],
                         "adapter_fit_seconds": ad["fit_seconds"],
                         **{f"adapter_n_{k}": v for k, v in ad["status_counts"].items()},
                         "adapter_mean_train_rel_residual": sum(res) / len(res) if res else None})
                    maps[f"{st}|branches|{sub}"] = {"kind": "branches", "stage": st, "slots": slots, "maps": mp}
                    recon.append((f"{st}|branches|{sub}", p_al["test"].detach().cpu()))
                    del t
                # positive control: the partner's own branches
                t = transfer_models(part, part, players, b, batch, align=True)
                _, p_sr = meas(t["raw"], f"{st}/self/raw")
                ok = torch.equal(p_sr["test"], pi_p["test"])
                staged_checks.append({**meta, "stage": st, "check": "self_branch_copy_reproduces_partner", "passed": ok})
                if not ok:
                    raise Fail(f"{st}: copying the partner's own branches into it changed its function")
                if not t["adapter"]["ok"]:
                    raise Fail(f"{st}/self: alignment failed {t['adapter']['status_counts']}")
                e_sa, p_sa = meas(t["aligned"], f"{st}/self/aligned")
                ok_sa, diff_sa = AC.same_function(pi_p["test"], p_sa["test"], rel=1e-3)
                put(s, "branches_self_aligned", "all", "", e_sa, prefs,
                    {"n_branch_players": len(players), "self_aligned_max_abs_diff": diff_sa,
                     "self_aligned_same_decisions_within_1e-3": ok_sa})
                del t
                # the first layer: into the host's own f0, and into the partner's f0 through the interfaces
                hs = hc.state_dict()
                Wd, bd_ = hs[f"mods.{L[0]}.weight"].double(), hs[f"mods.{L[0]}.bias"].double()
                own = GraphNet.from_checkpoint(bk_h["model"], dev).eval()
                osd = dict(own.state_dict())
                osd[f"mods.{L[0]}.weight"], osd[f"mods.{L[0]}.bias"] = hs[f"mods.{L[0]}.weight"], hs[f"mods.{L[0]}.bias"]
                own.load_state_dict(osd)
                own._plan = None
                e_own, _ = meas(own, f"{st}/own_f0")
                put(s, "first_layer_into_own_f0", "", "", e_own, {"f0": f0h_e})
                res = first_layer_rows(s, "first_layer_into_partner_f0", Wd, bd_, {"f0": f0p_e}, ctrl)
                for itf, (_, A, c, pr_t) in res.items():
                    maps[f"{st}|first_layer|{itf}"] = {"kind": "first_layer", "stage": st, "source": "host",
                                                       "A": A.cpu(), "c": c.cpu()}
                    recon.append((f"{st}|first_layer|{itf}", pr_t))
                # the time-matched compact continuation (f0 trained on without additions)
                if u > 0 and u in compact_us:
                    cdir = runs / cp[0]
                    cck = load(cdir, f"at_{u}", f"{cp[0]}/at_{u}", cp[1])
                    if int((cck.get("extra") or {}).get("update", -1)) != u:
                        raise Fail(f"{cp[0]}/at_{u}: recorded update {(cck.get('extra') or {}).get('update')}")
                    cm = GraphNet.from_checkpoint(cck["model"], dev).eval()
                    if SR.backbone_layers(cm) != L or any(imp.nodes for imp in cm.implants.values()):
                        raise Fail(f"{cp[0]}/at_{u}: not a compact f0-architecture state")
                    e_c, _ = meas(cm, f"{st}/compact")
                    put(s, "compact_intact", "", "", e_c, {"f0": f0h_e})
                    cs = cm.state_dict()
                    own = GraphNet.from_checkpoint(bk_h["model"], dev).eval()
                    osd = dict(own.state_dict())
                    osd[f"mods.{L[0]}.weight"], osd[f"mods.{L[0]}.bias"] = cs[f"mods.{L[0]}.weight"], cs[f"mods.{L[0]}.bias"]
                    own.load_state_dict(osd)
                    own._plan = None
                    e_co, _ = meas(own, f"{st}/compact_own_f0")
                    put(s, "compact_first_layer_into_own_f0", "", "", e_co, {"f0": f0h_e})
                    res = first_layer_rows(s, "compact_first_layer_into_partner_f0", cs[f"mods.{L[0]}.weight"].double(),
                                           cs[f"mods.{L[0]}.bias"].double(), {"f0": f0p_e}, ctrl)
                    for itf, (_, A, c, pr_t) in res.items():
                        maps[f"{st}|compact_first_layer|{itf}"] = {"kind": "first_layer", "stage": st,
                                                                   "source": f"compact:{cp[0]}/at_{u}",
                                                                   "A": A.cpu(), "c": c.cpu()}
                        recon.append((f"{st}|compact_first_layer|{itf}", pr_t))
            # ---- every planned unit, and nothing else
            got = {(r["stage"], r["measure"], r["subset"], r["interface"]) for r in staged}
            miss, extra = sorted(set(units) - got), sorted(got - set(units))
            if miss or extra:
                cov["missing_units"] += [{"run_id": hid, "unit": list(k)} for k in miss]
                raise Fail(f"units: {len(miss)} missing, {len(extra)} unplanned (first: {(miss or extra)[:2]})")
            # ---- saved maps, refolded from freshly loaded checkpoints
            if not a.no_maps:
                mdir.mkdir(parents=True, exist_ok=True)
                mpath = mdir / f"{hid}__{pid}.pt"
                art = {"host": hid, "partner": pid, "compact": cp[0] if cp else None,
                       "param_hashes": {st_["stage"]: {"host": SR.ckp(d, st_["stage"])["lineage"]["param_hash"],
                                                      "partner": SR.ckp(pd, st_["stage"])["lineage"]["param_hash"]}
                                        for st_ in stages},
                       "f0_param_hashes": {"host": bk_h["lineage"]["param_hash"], "partner": bk_p["lineage"]["param_hash"]},
                       "maps": maps}
                tmp = mpath.with_suffix(".pt.tmp")
                torch.save(art, tmp)
                os.replace(tmp, mpath)
                map_bytes = mpath.stat().st_size
                map_sha = hashlib.sha256(mpath.read_bytes()).hexdigest()[:16]
                art2 = torch.load(mpath, map_location="cpu", weights_only=False)
                bkp_fresh = SR.ckp(pd, "baseline_ref")
                for key, want in recon:
                    ent = art2["maps"][key]
                    st = ent["stage"]
                    if ent["kind"] == "branches":
                        recv = GraphNet.from_checkpoint(SR.ckp(pd, st)["model"], dev).eval()
                        don = GraphNet.from_checkpoint(SR.ckp(d, st)["model"], dev).eval()
                        h2 = transfer_models(recv, don, ent["slots"], b, batch, align=False)["raw"]
                        apply_saved_alignment(h2, ent["maps"])
                    else:
                        if ent["source"] == "host":
                            src_g = CT.compact_graph(SR.ckp(d, st)["model"], dev, f"recon/{st}")
                        else:
                            src_g = GraphNet.from_checkpoint(SR.ckp(runs / cp[0], ent["source"].split("/")[-1])["model"],
                                                             dev).eval()
                        ss = src_g.state_dict()
                        h2 = GraphNet.from_checkpoint(bkp_fresh["model"], dev).eval()
                        r_fresh = {k_: v_.clone() for k_, v_ in h2.state_dict().items()}
                        h2.load_state_dict(CT.fold_first_layer(r_fresh, L, ss[f"mods.{L[0]}.weight"].double(),
                                                               ss[f"mods.{L[0]}.bias"].double(), ent["A"], ent["c"]))
                        h2._plan = None
                    _, pr2 = meas(h2, f"recon/{key}")
                    ok = torch.equal(pr2["test"].detach().cpu(), want)
                    staged_checks.append({**meta, "stage": st, "check": f"map_reconstruction:{key}", "passed": ok})
                    if not ok:
                        raise Fail(f"saved map {key} does not reproduce its predictions from fresh checkpoints")
            rows += staged
            checks += staged_checks
            cov["analysed_directions"] += 1
            cov["analysed_units"] += len(staged)
        except Exception as ex:                          # noqa: BLE001
            why = str(ex) if isinstance(ex, Fail) else f"{type(ex).__name__}: {ex}"
            cov["failed"].append({"run_id": hid, "partner": pid, "reason": why})
            partial += [{**r, "failure": why} for r in staged]
            checks += [{**c, "direction_failed": why} for c in staged_checks]
        cov["cost"]["directions"].append({"host": hid, "partner": pid, "wall_seconds": time.time() - t0,
                                          "alignment_fit_macs": fit_macs, "map_bytes": map_bytes,
                                          "map_file": f"{hid}__{pid}.pt" if map_sha else None, "map_sha256": map_sha})
    keys = ("cell", "variant", "draw_set", "event_order", "stage", "trajectory_updates", "cohorts_present", "measure",
            "subset", "interface")
    by_draw, summ = draw_levels(rows, keys)
    SR.atomic_csv(f"{P}_rows.csv", rows)
    SR.atomic_csv(f"{P}_by_draw.csv", by_draw)
    SR.atomic_csv(f"{P}_summary.csv", summ)
    SR.atomic_csv(f"{P}_checks.csv", checks)
    SR.atomic_csv(f"{P}_diagnostic_partial.csv", partial)
    cov["n_failed"] = len(cov["failed"])
    cov["cost"].update({"wall_seconds": time.time() - t_all,
                        "alignment_fit_macs": sum(x["alignment_fit_macs"] for x in cov["cost"]["directions"]),
                        "map_bytes": sum(x["map_bytes"] for x in cov["cost"]["directions"]),
                        "note": "analysis only (no gradient steps); separate from the panel's training cost"})
    cov["passed"] = (cov["n_failed"] == 0 and cov["analysed_directions"] > 0 and
                     cov["analysed_directions"] == cov["expected_directions"] and
                     cov["analysed_units"] == cov["expected_units"] and not cov["missing_units"])
    SR.atomic_json(f"{P}_coverage.json", cov)
    print(json.dumps({k: cov[k] for k in ("expected_directions", "analysed_directions", "expected_units",
                                          "analysed_units", "n_failed", "passed")}), cov["failed"][:3])
    if a.strict:
        return 0 if cov["passed"] else 1
    return 0 if cov["analysed_directions"] > 0 else 1


if __name__ == "__main__":
    sys.exit(main())
