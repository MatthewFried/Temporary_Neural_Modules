"""v22 / v23: read-only audit of the recoding jobs of a results folder (trains nothing, writes only OUT.json).

  python audit_v5/tools/recode_audit.py RESULTS OUT.json --manifest MANIFEST

The expected jobs come from the manifest (cop.task_kind = recode); a job with no folder is a problem.  For every
job: status and reason; the pre-fit validity checks (map vs network codes, exact table, every transformed
identity and transformed splice) and the LP controls, each failure a problem; coverage as SETS: the plan's fit
identities must be unique, equal to the records' identities, and each must have an artifact whose stored key
matches its path and record; the symmetry control (expected pairs from the plan, checked / failed /
inconclusive / unavailable, the worst loss-curve and parameter discrepancies and their cases, by regime, side and
class), an empty or failed set being a problem; and the smallest decision margin |logit| of every fit,
RECOMPUTED ON CPU from the saved replacement in its saved dtype, on its own support and on the full alphabet
(non-finite margins and unreadable artifacts are per-fit problems; the report still finishes).  Recorded
training dtypes and devices are listed separately.  Works on v21 results (fields added later are derived from
the plan and the artifacts).  Exit 1 if any job has a problem or is missing."""
from __future__ import annotations

import argparse
import json
import math
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import torch  # noqa: E402

from cop.utils import read_json, read_jsonl  # noqa: E402
from cop.cop_pegs.recode import make_replacement, index_to_bits, _fit_path, curve_exact  # noqa: E402


def margins(rd: Path, art: dict) -> dict:
    sd = art["state_dict"]
    dt = next(iter(sd.values())).dtype if sd else torch.float32
    ar = art["arch"]
    m = make_replacement(ar["class"], ar["n_in"], ar["n_out"], torch.Generator().manual_seed(0)).to(dt)
    m.load_state_dict(sd)
    mp = torch.load(rd / art["map_source"], map_location="cpu", weights_only=False)
    n_sym = int(art["P_fwd"].numel())
    pf = art["P_fwd"].long()
    sup = mp["reach"].long() if art["key"]["regime"] == "observed" else torch.arange(n_sym)
    with torch.no_grad():
        lg_s = m(index_to_bits(pf[sup], ar["n_in"]).to(dt))
        lg_a = m(index_to_bits(pf[torch.arange(n_sym)], ar["n_in"]).to(dt))
    return {"dtype": str(dt).replace("torch.", ""), "recomputed_on": "cpu",
            "min_abs_logit_support": float(lg_s.abs().min()), "min_abs_logit_full_alphabet": float(lg_a.abs().min()),
            "finite": bool(torch.isfinite(lg_s).all() and torch.isfinite(lg_a).all()),
            "bits_within_1e-6_support": int((lg_s.abs() < 1e-6).sum())}


def audit_job(rd: Path) -> dict:
    st = read_json(rd / "status.json") if (rd / "status.json").exists() else {}
    out = {"run_id": rd.name, "status": st.get("status"), "reason": st.get("reason"), "problems": []}
    P = out["problems"]
    if out["status"] != "complete":
        P.append(f"status {out['status']}: {out['reason']}")
    ch = read_json(rd / "recode_checks.json") if (rd / "recode_checks.json").exists() else None
    if ch is None:
        P.append("recode_checks.json missing")
        return out
    # ---- pre-fit validity checks and LP controls
    pearls = ch.get("pearls") or {}
    if not pearls:
        P.append("no checked pearl")
    for pi, pc in pearls.items():
        if not pc.get("map_matches_network_codes"):
            P.append(f"pearl {pi}: enumerated map differs from the network's codes")
        if not pc.get("exact_table_reproduces_predictions"):
            P.append(f"pearl {pi}: exact table does not reproduce the reference predictions")
        for tk, tv in (pc.get("transformed_identities") or {}).items():
            if not (tv.get("identity_holds") and tv.get("splice_reproduces")):
                P.append(f"pearl {pi}: transformed identity / splice failed for {tk}")
    out["prefit_checks_passed"] = not any(x.startswith("pearl ") for x in P)
    out["lp_controls_passed"] = bool((ch.get("lp_controls") or {}).get("passed"))
    if not out["lp_controls_passed"]:
        P.append("LP controls missing or failed")
    # ---- coverage as sets
    plan = read_json(rd / "recode_plan.json") if (rd / "recode_plan.json").exists() else None
    res = read_json(rd / "recode_result.json") if (rd / "recode_result.json").exists() else None
    if plan is None:
        P.append("no fit plan (the job stopped before fitting)")
        return out
    keys = list(plan.get("fits") or [])
    if len(keys) != len(set(keys)) or (plan.get("n_fits") is not None and len(keys) != plan["n_fits"]):
        P.append("fit plan identities are not unique or do not match n_fits")
    fits = [r for r in (res or {}).get("rows") or [] if "class" in r]
    rec_keys = [r["key"] for r in fits]
    if len(rec_keys) != len(set(rec_keys)):
        P.append("duplicate fit records")
    if set(rec_keys) != set(keys):
        P.append(f"fit records differ from the plan: {len(set(keys) - set(rec_keys))} missing, "
                 f"{len(set(rec_keys) - set(keys))} unexpected")
    by_key = {r["key"]: r for r in fits}
    cov = {"planned": len(keys), "records": len(fits), "artifacts_ok": 0,
           "numerical_failure": sum(r.get("status") == "numerical_failure" for r in fits),
           "exact": sum(r.get("status") == "exact" for r in fits),
           "censored": sum(r.get("status") == "censored" for r in fits),
           "exact_lost_after_first": sum(bool(r.get("exact_lost_after_first")) for r in fits)}
    # v25: status recomputed from integer counts (a float mean compared with 1.0 can miss an exact fit); listed,
    # not a problem: the tables use the integer status (v13_tables.integer_exactness)
    corr = []
    for r in fits:
        if r.get("status") in ("exact", "censored"):
            n_ = r.get("support_size")
            ok_ = any(curve_exact(c, n_) for c in (r.get("curve") or []))
            if ok_ != (r.get("status") == "exact"):
                corr.append({"case": r["key"], "recorded": r.get("status"),
                             "integer": "exact" if ok_ else "censored"})
    cov["status_corrections_integer"] = len(corr)
    out["status_corrections"] = corr[:50]
    ms, dts = [], set()
    for k in keys:
        fp = _fit_path(rd, k)
        if not fp.exists():
            P.append(f"{k}: artifact missing")
            continue
        try:
            art = torch.load(fp, map_location="cpu", weights_only=False)
        except Exception as ex:                      # noqa: BLE001
            P.append(f"{k}: artifact unreadable: {type(ex).__name__}: {ex}")
            continue
        if (art.get("key") or {}).get("key") != k or (art.get("record") or {}).get("key") != k:
            P.append(f"{k}: artifact key does not match its path / record")
            continue
        cov["artifacts_ok"] += 1
        if (by_key.get(k) or {}).get("status") == "numerical_failure":
            continue
        try:
            m = margins(rd, art)
        except Exception as ex:                      # noqa: BLE001
            P.append(f"{k}: margin recomputation failed: {type(ex).__name__}: {ex}")
            continue
        if not m["finite"] or not all(math.isfinite(m[x]) for x in ("min_abs_logit_support",
                                                                       "min_abs_logit_full_alphabet")):
            P.append(f"{k}: non-finite logits")
            continue
        dts.add(m["dtype"])
        ms.append({"case": k, **m})
    out["coverage"] = cov
    # ---- symmetry control
    sym = ch.get("symmetry_control") or {}
    rows = sym.get("rows") or []
    exp_keys = [k for k in keys if k.split("|")[2] == "bitperm_symmetric"]
    got = {r["key"] for r in rows}
    unavailable = sorted(set(exp_keys) - got)
    s_out = {"n_expected": len(exp_keys), "n_checked": len(rows),
             "n_failed": sum(r.get("verdict", "passed" if r.get("passed") else "failed") == "failed" for r in rows),
             "n_inconclusive": sum(r.get("verdict") == "inconclusive_tiny_margin" for r in rows),
             "n_unavailable": len(unavailable), "unavailable": unavailable[:20], "recorded_passed": sym.get("passed")}
    if exp_keys and not rows:
        P.append("symmetry control: no checked pair although pairs were expected")
    if sym.get("passed") is False or s_out["n_failed"]:
        P.append(f"symmetry control failed ({s_out['n_failed']} of {len(rows)} checked pairs)")
    if unavailable:
        P.append(f"symmetry control unavailable for {len(unavailable)} expected pairs")
    if rows:
        w = max(rows, key=lambda r: r.get("relative") or 0.0)
        s_out["worst_loss_relative"] = {"value": w.get("relative"), "max_abs": w.get("max_loss_diff"),
                                        "scale": w.get("loss_scale"), "case": w["key"]}
        pr = [r for r in rows if r.get("param_relative") is not None]
        if pr:
            w = max(pr, key=lambda r: r["param_relative"])
            s_out["worst_param_relative"] = {"value": w["param_relative"], "case": w["key"]}
        by = defaultdict(lambda: [0, 0])
        for r in rows:
            parts = r["key"].split("|")          # pearl|regime|relabel|relabel_seed|side|class|fit_seed
            kk = f"{parts[1]}|{parts[4]}|{parts[5]}"
            by[kk][0] += 1
            by[kk][1] += int(not r.get("passed"))
        s_out["not_passed_by_regime_side_class"] = {k: f"{v[1]}/{v[0]}" for k, v in sorted(by.items())}
    out["symmetry"] = s_out
    if ms:
        w = min(ms, key=lambda x: x["min_abs_logit_support"])
        out["margins"] = {"n": len(ms), "smallest_support": w, "recomputed_on": "cpu",
                          "fits_with_a_bit_within_1e-6": sum(x["bits_within_1e-6_support"] > 0 for x in ms)}
    out["replacement_dtypes_saved"] = sorted(dts)
    out["recorded_training_dtypes_devices"] = sorted(map(str, {(r.get("replacement_dtype"), r.get("reference_dtype"),
                                                                 r.get("device")) for r in fits}))
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("results")
    ap.add_argument("out")
    ap.add_argument("--manifest", required=True, help="the manifest the results were produced from")
    a = ap.parse_args()
    res = Path(a.results)
    ids = sorted({e["run_id"] for e in read_jsonl(a.manifest)
                  if e["cfg"].get("kind") == "cop" and (e["cfg"].get("cop") or {}).get("task_kind") == "recode"})
    jobs, missing = [], []
    for rid in ids:
        rd = res / "runs" / rid
        if not rd.is_dir():
            missing.append(rid)
            continue
        try:
            jobs.append(audit_job(rd))
        except Exception as ex:                      # noqa: BLE001
            jobs.append({"run_id": rid, "problems": [f"audit error: {type(ex).__name__}: {ex}"]})
    sy = [j["symmetry"] for j in jobs if j.get("symmetry")]
    summary = {"expected_jobs": len(ids), "jobs": len(jobs), "missing_jobs": missing,
               "jobs_with_problems": sum(bool(j["problems"]) for j in jobs),
               "fits_planned": sum((j.get("coverage") or {}).get("planned", 0) for j in jobs),
               "fits_with_valid_artifacts": sum((j.get("coverage") or {}).get("artifacts_ok", 0) for j in jobs),
               "status_corrections_integer": sum((j.get("coverage") or {}).get("status_corrections_integer", 0)
                                                 for j in jobs),
               "symmetry_pairs_expected": sum(s["n_expected"] for s in sy),
               "symmetry_pairs_checked": sum(s["n_checked"] for s in sy),
               "symmetry_pairs_failed": sum(s["n_failed"] for s in sy),
               "symmetry_pairs_inconclusive": sum(s["n_inconclusive"] for s in sy),
               "symmetry_pairs_unavailable": sum(s["n_unavailable"] for s in sy),
               "worst_symmetry_loss_relative": max((s["worst_loss_relative"]["value"] or 0.0 for s in sy
                                                   if s.get("worst_loss_relative")), default=None),
               "worst_symmetry_param_relative": max((s["worst_param_relative"]["value"] for s in sy
                                                    if s.get("worst_param_relative")), default=None),
               "smallest_margin_recomputed_on_cpu": min((j["margins"]["smallest_support"]["min_abs_logit_support"]
                                                         for j in jobs if j.get("margins")), default=None)}
    json.dump({"summary": summary, "jobs": jobs}, open(a.out, "w"), indent=1)
    print(json.dumps(summary, indent=1))
    return 0 if ids and not missing and not summary["jobs_with_problems"] else 1


if __name__ == "__main__":
    sys.exit(main())
