"""v25: read-only re-scoring of saved recoding fits with INTEGER exactness (trains nothing, writes two CSVs).

  python audit_v5/tools/recode_integer_status.py RESULTS OUT_PREFIX

v21-v24 recode jobs decided "exact" by comparing a floating mean of per-message correctness with 1.0; on some
devices a mean of ones reads 0.9999999999999999, so an exact fit could be recorded as censored.  This tool reads
every recode_result.json under RESULTS/runs directly (no semantic-hash filter: it re-scores the saved curves, it
does not pool runs as current results), recomputes each fit's status from its curve with
cop.cop_pegs.recode.curve_exact (the recorded count from v25, else the unweighted fraction rounded to a count of
wrong messages with the fit's support size), and writes
  OUT_PREFIX_fits.csv     one row per fit: recorded and integer status, first / sustained exact update
  OUT_PREFIX_rates.csv    exact rates by history, regime, relabelling, side and class, recorded vs integer"""
from __future__ import annotations

import csv
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from cop.utils import read_json  # noqa: E402
from cop.analysis.v13_tables import integer_exactness  # noqa: E402


def main() -> int:
    if len(sys.argv) != 3:
        print(__doc__)
        return 2
    res, pre = Path(sys.argv[1]), sys.argv[2]
    rows = []
    for d in sorted((res / "runs").glob("*")):
        p = d / "recode_result.json"
        if not p.exists():
            continue
        st = read_json(d / "status.json") if (d / "status.json").exists() else {}
        cfg = read_json(d / "config.json")
        des = cfg.get("design") or {}
        for x in read_json(p).get("rows") or []:
            if "class" not in x:
                continue
            ie = integer_exactness(x)
            rows.append({"run_id": d.name, "job_status": st.get("status"), "contrast": des.get("contrast"),
                         "history": str(des.get("arm", "")).replace("recode_", ""),
                         **{k: x.get(k) for k in ("key", "pearl", "regime", "relabel", "relabel_seed", "side", "class",
                                                  "fit_seed", "support_size", "status", "first_exact_update",
                                                  "sustained_exact_from", "final_exact_unweighted")},
                         **ie})
    if not rows:
        print("no recode fits found")
        return 1
    with open(f"{pre}_fits.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    agg = defaultdict(lambda: [0, 0, 0])
    for r in rows:
        if r["status"] not in ("exact", "censored"):
            continue
        k = (r["contrast"], r["history"], r["regime"], r["relabel"], r["side"], r["class"])
        agg[k][0] += 1
        agg[k][1] += int(r["status"] == "exact")
        agg[k][2] += int(r["status_integer"] == "exact")
    with open(f"{pre}_rates.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["contrast", "history", "regime", "relabel", "side", "class", "n_fits", "exact_recorded",
                    "exact_integer", "rate_recorded", "rate_integer"])
        for k, (n, a, b) in sorted(agg.items(), key=lambda t: tuple(map(str, t[0]))):
            w.writerow([*k, n, a, b, a / n, b / n])
    n_corr = sum(bool(r["status_corrected"]) for r in rows)
    print(f"{len(rows)} fits, {n_corr} with a corrected status; wrote {pre}_fits.csv and {pre}_rates.csv")
    return 0


if __name__ == "__main__":
    sys.exit(main())
