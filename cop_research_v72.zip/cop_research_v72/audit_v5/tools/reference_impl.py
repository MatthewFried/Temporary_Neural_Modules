"""v68: an independent reference implementation of the networks the panels train, written with raw
torch.nn.functional operations.  It never builds or calls cop.graph (GraphNet, its op table, its mask helper, its
fold or redistribution code) and never calls cop.train: it reads a saved model dict ({'spec', 'state'}) as data -
which backbone layer is which (the spec's roles) and which tensors the additions own - and computes everything
itself.

Supported (anything else is refused, never approximated):
  mlp      L0.lin, act, L1.lin, act, ... , head; ReLU between layers; one merge group after a backbone activation
           (cut post_act), read by the next backbone linear layer
  cnn_cut  conv3x3 (padding 1) ReLU, conv3x3 ReLU, maxpool 2, [merge], 1x1 receiving layer (S1.recv), ReLU,
           conv3x3 ReLU, maxpool 2, global average pooling, linear head; the merge group after the first pool
  merge    z = h + sum_j t_j, branch j: t_j = B_j act_j(A_j h + a_j) + b_j (act identity or relu; per position in an
           image), each branch optionally routed by an example mask m (gradient key spec_a / spec_b)

Routing.  The forward value of every branch is used for every example.  The backward rule is the intended one: the
gradient reaching branch j's output from example n is multiplied by m_j[n]; the backbone path (the skip) is never
masked.  Written as t_j.detach() + m_j (t_j - t_j.detach()), whose value is t_j and whose derivative is m_j.  So
ordinary finite differences of the forward loss are an oracle for the ordinary arm only; the routed arm is checked
against this surrogate.

Also here, independently: the AdamW update with an input-column hold (zero the held gradient before the step,
restore the held entries after it), the exact fold of affine branches into the receiving layer (W (I + M),
b + W c), the swap of a / b branches, and the shift of a share t of the map into the receiving layer
(W (I + M)(I + s M)^-1, b + W c - s W' c, branch outputs times s)."""
from __future__ import annotations

import math

import torch
import torch.nn.functional as F


class Unsupported(ValueError):
    pass


def _nodes(spec):
    return {n["id"]: n for n in spec["nodes"]}


def _topo(nodes: list) -> list:
    ids = {n["id"] for n in nodes}
    deps = {n["id"]: [i for i in n["inputs"] if i in ids] for n in nodes}
    out, done = [], set()
    while len(out) < len(nodes):
        ready = [i for i in deps if i not in done and all(d in done for d in deps[i])]
        if not ready:
            raise Unsupported("the graph has a cycle")
        for i in sorted(ready, key=lambda s: int(s[1:]) if s[1:].isdigit() else 0):
            out.append(i)
            done.add(i)
    return out


class RefNet:
    """the network of a saved model dict, as leaf tensors and a hand-written forward."""

    def __init__(self, family: str, backbone: list, recv_index: int, branches: list, P: dict, cut_after: int):
        self.family, self.backbone, self.recv_index, self.branches = family, backbone, recv_index, branches
        self.P, self.cut_after = P, cut_after

    # ------------------------------------------------------------------ construction from saved data
    @classmethod
    def from_model_dict(cls, md: dict, dtype=torch.float64, device="cpu") -> "RefNet":
        """v68 / v69: the network of a saved model dict.  Every hard-coded assumption is checked against the saved
        specification and anything else is refused (Unsupported): the exact backbone chain from the input to the
        output (each node reading the previous one; the receiving layer reading the merge's exit), its operations and
        attributes (MLP: linear + ReLU per layer, linear head; cnn_cut: 3x3 convolutions with bias that keep the
        spatial size (stride 1, padding 1), ReLU, 2x2 max pooling that halves it, a pointwise receiving layer, global
        average pooling, linear head), one merge group (unit coefficients, its exit an identity of the sum) whose
        branches are linear A, identity / ReLU, linear B, optional gradient mask, all reading the merge input; every
        gate value 1; no side outputs or frozen statistics; and every saved parameter used exactly once."""
        spec, state = md["spec"], md["state"]
        nodes = _nodes(spec)
        fam = spec["family"]
        if fam not in ("mlp", "cnn_cut"):
            raise Unsupported(f"family {fam}")
        gv = spec.get("gate_vals") or {}
        if any(float(v) != 1.0 for v in (gv.values() if isinstance(gv, dict) else gv)):
            raise Unsupported(f"gate values other than 1: {gv}")
        if spec.get("side_outputs") or spec.get("frozen_bn"):
            raise Unsupported("side outputs or frozen normalisation statistics")
        if any(not k.startswith("mods.") or not v.is_floating_point() for k, v in state.items()):
            raise Unsupported("state entries other than floating-point module parameters")
        P = {k.split(".", 1)[1]: v.detach().to(device=device, dtype=dtype).clone() for k, v in state.items()}
        out_id = spec.get("output")
        if isinstance(out_id, dict):
            out_id = next(iter(out_id.values())) if len(out_id) == 1 else None
        if out_id not in nodes:
            raise Unsupported("no single output node")
        # ---- the backbone chain, walked back from the output
        chain, exit_, cur = [], None, out_id
        while True:
            n = nodes[cur]
            if n["owner"] is not None:
                # the merge's exit: an identity of its sum, or (an exported network) the sum itself
                if exit_ is not None or not (n["op"] == "add" or (n["op"] == "identity" and len(n["inputs"]) == 1)):
                    raise Unsupported(f"{cur}: an addition node on the backbone path that is not a merge exit")
                exit_ = n
                add = n if n["op"] == "add" else nodes[n["inputs"][0]]
                if add["op"] != "add" or add["owner"] != n["owner"]:
                    raise Unsupported("a merge exit that does not read its sum")
                chain.append(("exit", n["id"]))
                cur = add["inputs"][0]
                continue
            chain.append((n["op"], n["id"]))
            if n["op"] == "input":
                break
            if len(n["inputs"]) != 1:
                raise Unsupported(f"{cur}: a backbone node with {len(n['inputs'])} inputs")
            cur = n["inputs"][0]
        chain.reverse()
        ops = [o for o, _ in chain]
        ids = [i for _, i in chain]
        bb_nodes = {i for o, i in chain if o != "exit"}
        stray = [n["id"] for n in spec["nodes"] if n["owner"] is None and n["id"] not in bb_nodes]
        if stray:
            raise Unsupported(f"backbone nodes off the chain: {stray}")

        def attrs(i):
            return nodes[i]["attrs"]

        def need(cond, why):
            if not cond:
                raise Unsupported(why)
        body = [i for o, i in chain if o != "exit"]
        if fam == "mlp":
            pat = [nodes[i]["op"] for i in body]
            need(pat[0] == "input" and pat[-1] == "linear" and len(pat) >= 4, "the MLP chain is not input ... head")
            mid = pat[1:-1]
            need(len(mid) % 2 == 0 and all(mid[k] == "linear" and mid[k + 1] == "act" for k in range(0, len(mid), 2)),
                 "the MLP chain is not (linear, activation) pairs")
            for k in range(1, len(body) - 1, 2):
                need(attrs(body[k + 1]).get("fn") == "relu", f"{body[k + 1]}: not a ReLU")
            lin = [body[k] for k in range(1, len(body) - 1, 2)]
            head = body[-1]
            backbone = [("linear", nodes[i]["pkey"]) for i in lin] + [("head", nodes[head]["pkey"])]
        else:
            pat = [o for o in ops]
            want = ["input", "conv", "act", "conv", "act", "pool", "linear", "act", "conv", "act", "pool", "gap",
                    "linear"]
            pat_b = [nodes[i]["op"] for i in body]
            need(pat_b == want, f"the cnn_cut chain is {pat_b}, expected {want}")
            if exit_ is not None:
                need(ops.index("exit") == 6, "the merge is not between the first pool and the receiving layer")
            for i in (body[1], body[3], body[8]):
                a_ = attrs(i)
                prev = attrs(nodes[i]["inputs"][0]) if nodes[nodes[i]["inputs"][0]]["op"] != "input" else \
                    attrs(nodes[i]["inputs"][0])
                need(a_.get("k") == 3 and a_.get("bias", True) and list(a_.get("hw") or []) ==
                     list(prev.get("hw") or []), f"{i}: not a 3x3 convolution with bias keeping the spatial size")
            for i in (body[2], body[4], body[7], body[9]):
                need(attrs(i).get("fn") == "relu", f"{i}: not a ReLU")
            for i in (body[5], body[10]):
                a_, pv = attrs(i), attrs(nodes[i]["inputs"][0])
                need(a_.get("kind") == "max" and a_.get("k") == 2 and
                     list(a_.get("hw") or []) == [int(x) // 2 for x in (pv.get("hw") or [])],
                     f"{i}: not a 2x2 max pooling halving the size")
            need(attrs(body[6]).get("layout") == "img" and attrs(body[12]).get("layout") == "vec",
                 "the receiving layer is not pointwise or the head not on the pooled vector")
            backbone = [("conv", nodes[body[1]]["pkey"]), ("conv", nodes[body[3]]["pkey"]), ("pool", None),
                        ("pw", nodes[body[6]]["pkey"]), ("conv", nodes[body[8]]["pkey"]), ("pool", None),
                        ("gap", None), ("head", nodes[body[12]]["pkey"])]
        # ---- the merge group
        branches, cut_after, recv_index = [], None, None
        owned = [n for n in spec["nodes"] if n.get("owner")]
        used_owned = set()
        if exit_ is None:
            need(not owned, "addition nodes that the output does not read")
        else:
            add = exit_ if exit_["op"] == "add" else nodes[exit_["inputs"][0]]
            used_owned |= {exit_["id"], add["id"]}
            skip = nodes[add["inputs"][0]]
            terms = add["attrs"].get("terms") or []
            need(terms[:1] == ["skip"] and len(terms) == len(add["inputs"]) and
                 all(float(c) == 1.0 for c in add["attrs"].get("coefs", [1.0] * len(add["inputs"]))) and
                 len(add["attrs"].get("coefs", [])) in (0, len(add["inputs"])),
                 "the merge is not skip + sum of branch terms with unit coefficients")
            if fam == "mlp":
                need(skip["op"] == "act" and skip["id"] in body, "the MLP merge does not follow a backbone activation")
                li = lin.index(skip["inputs"][0])
                cut_after, recv_index = li, li + 1
                need(nodes[lin[li + 1] if li + 1 < len(lin) else head]["inputs"] == [exit_["id"]],
                     "the layer after the merge does not read its exit")
            else:
                need(skip["id"] == body[5], "the image merge is not after the first pool")
                cut_after, recv_index = 2, 3
            for inp in add["inputs"][1:]:
                n = nodes[inp]
                mask = None
                if n["op"] == "mask_grad":
                    used_owned.add(n["id"])
                    mask = n["attrs"]["mask_key"]
                    n = nodes[n["inputs"][0]]
                need(n["op"] == "linear" and n.get("role") == "B", "a branch that does not end in its linear layer B")
                act = nodes[n["inputs"][0]]
                A = nodes[act["inputs"][0]]
                need(act["op"] == "act" and act["attrs"].get("fn") in ("identity", "relu") and A["op"] == "linear"
                     and A.get("role") == "A" and A["inputs"] == [skip["id"]] and
                     len({A["owner"], act["owner"], n["owner"]}) == 1,
                     "a branch that is not linear A, activation, linear B on the merge input")
                used_owned |= {n["id"], act["id"], A["id"]}
                branches.append({"owner": n["owner"], "A": A["pkey"], "B": n["pkey"], "act": act["attrs"]["fn"],
                                 "mask": mask})
            need(used_owned == {n["id"] for n in owned}, f"addition nodes the merge does not use: "
                                                         f"{sorted({n['id'] for n in owned} - used_owned)}")
        # ---- every parameter used once, every layer with a weight and a bias
        pks = [pk for _, pk in backbone if pk] + [b[x] for b in branches for x in ("A", "B")]
        need(len(pks) == len(set(pks)), "a parameter shared between layers")
        want_keys = {f"{pk}.{w}" for pk in pks for w in ("weight", "bias")}
        need(set(P) == want_keys, f"parameters not used by the network or missing: "
                                  f"{sorted(set(P) ^ want_keys)[:6]}")
        return cls(fam, backbone, recv_index, branches, P, cut_after)

    def params(self) -> dict:
        return self.P

    def leaf(self) -> "RefNet":
        """a copy whose tensors are fresh leaves requiring gradients."""
        P = {k: v.detach().clone().requires_grad_(True) for k, v in self.P.items()}
        return RefNet(self.family, self.backbone, self.recv_index, [dict(b) for b in self.branches], P,
                      self.cut_after)

    # ------------------------------------------------------------------ forward
    def _pw(self, pk, h):
        W, b = self.P[f"{pk}.weight"], self.P[f"{pk}.bias"]
        if h.dim() == 4:
            return torch.einsum("oc,nchw->nohw", W, h) + b[None, :, None, None]
        return h @ W.t() + b

    def forward(self, x: torch.Tensor, masks: dict | None = None, keep: bool = False):
        inter = {}
        h = x
        merged = False

        def merge(h):
            inter["h"] = h
            z = h
            for br in self.branches:
                u = self._pw(br["A"], h)
                if br["act"] == "relu":
                    u = F.relu(u)
                t = self._pw(br["B"], u)
                inter[f"t_{br['owner']}"] = t
                if masks is not None and br["mask"] is not None and masks.get(br["mask"]) is not None:
                    m = masks[br["mask"]].to(t.dtype).reshape([-1] + [1] * (t.dim() - 1))
                    t = t.detach() + m * (t - t.detach())
                z = z + t
            inter["z"] = z
            return z
        if self.family == "mlp":
            n_lin = len(self.backbone) - 1
            for i, (_, pk) in enumerate(self.backbone[:-1]):
                if self.branches and i == self.recv_index and not merged:
                    h = merge(h)
                    merged = True
                h = F.relu(self._pw(pk, h))
            if self.branches and self.recv_index == n_lin and not merged:
                h = merge(h)
            out = self._pw(self.backbone[-1][1], h)
        else:
            for i, (op, pk) in enumerate(self.backbone):
                if self.branches and i == self.recv_index:
                    h = merge(h)
                if op == "conv":
                    h = F.relu(F.conv2d(h, self.P[f"{pk}.weight"], self.P[f"{pk}.bias"], padding=1))
                elif op == "pool":
                    h = F.max_pool2d(h, 2)
                elif op == "pw":
                    h = F.relu(self._pw(pk, h))
                elif op == "gap":
                    h = h.mean(dim=(2, 3))
                elif op == "head":
                    h = self._pw(pk, h)
            out = h
        return (out, inter) if keep else out

    __call__ = forward

    # ------------------------------------------------------------------ v70: float32 rounding error
    def rounding_bound(self, x: torch.Tensor, u: float = 2.0 ** -24, dtype=None) -> torch.Tensor:
        """E: per example and logit, a FIRST-ORDER ESTIMATE of |z_fl - z| for an evaluation of this network in a
        floating-point format with unit roundoff u (float32: 2^-24), on inputs that format holds exactly.  (v71: the
        name says bound; it is an estimate, not a rigorous upper bound.)
        Each operation that rounds is given a local error of Higham's gamma_n = n u / (1 - n u) for a sum of n terms
        (any summation order, with or without fused multiply-add): an affine layer or convolution over n inputs
        d_y = gamma_{n+1} (|W| |h| + |b|); the merge h + t_1 + ... + t_k  d_z = gamma_k (|h| + sum |t_j|); a global
        average over P positions d = gamma_{P+1} mean |h|; ReLU and max pooling exact.  These local errors are carried
        to the logits by the network's Jacobian at the activation pattern of this evaluation, in the dtype it is
        computed in (float64 by default; float32 when dtype=float32, as for wave 30):
        E_c = sum over every rounding operation l and unit i of |dz_c / dy_{l,i}| d_{l,i}.
        Not covered, so not a bound: terms of order u^2; ReLU units and max-pool winners that differ between the
        evaluation above and the float32 one being estimated (the Jacobian is taken at one activation pattern); transform convolution
        algorithms (Winograd, FFT), whose error is not that of direct dot products; with dtype=float32 the Jacobian
        and local terms are themselves computed in float32.  The factor 1.01 covers the rounding of this computation
        only approximately.  Use: an empirical, conditioning-aware consistency check (CHANGES_v71.md)."""
        def gam(n):
            return n * u / (1.0 - n * u)

        P = {k: (v.detach().to(dtype) if dtype is not None else v.detach()) for k, v in self.P.items()}
        leaves, loc = [], []

        def tap(y, d):                        # a rounding point: y + 0 * leaf, its local bound d
            e = torch.zeros_like(y, requires_grad=True)
            leaves.append(e)
            loc.append(d.detach())
            return y + e

        def aff(pk, h):
            W, b = P[f"{pk}.weight"], P[f"{pk}.bias"]
            g = gam(W.shape[1] + 1)
            if h.dim() == 4:
                y = torch.einsum("oc,nchw->nohw", W, h) + b[None, :, None, None]
                d = g * (torch.einsum("oc,nchw->nohw", W.abs(), h.detach().abs()) + b.abs()[None, :, None, None])
            else:
                y = h @ W.t() + b
                d = g * (h.detach().abs() @ W.abs().t() + b.abs())
            return tap(y, d)

        def conv(pk, h):
            W, b = P[f"{pk}.weight"], P[f"{pk}.bias"]
            g = gam(W.shape[1] * W.shape[2] * W.shape[3] + 1)
            y = F.conv2d(h, W, b, padding=1)
            d = g * (F.conv2d(h.detach().abs(), W.abs(), None, padding=1) + b.abs()[None, :, None, None])
            return tap(y, d)

        def merge(h):
            z, mag = h, h.detach().abs()
            for br in self.branches:
                a_ = aff(br["A"], h)
                if br["act"] == "relu":
                    a_ = F.relu(a_)
                t = aff(br["B"], a_)
                z = z + t
                mag = mag + t.detach().abs()
            return tap(z, gam(len(self.branches)) * mag) if self.branches else z

        with torch.enable_grad():
            h = x.to(next(iter(P.values())).dtype)
            if self.family == "mlp":
                n_lin = len(self.backbone) - 1
                merged = False
                for i, (_, pk) in enumerate(self.backbone[:-1]):
                    if self.branches and i == self.recv_index and not merged:
                        h = merge(h)
                        merged = True
                    h = F.relu(aff(pk, h))
                if self.branches and self.recv_index == n_lin and not merged:
                    h = merge(h)
                z = aff(self.backbone[-1][1], h)
            else:
                for i, (op, pk) in enumerate(self.backbone):
                    if self.branches and i == self.recv_index:
                        h = merge(h)
                    if op == "conv":
                        h = F.relu(conv(pk, h))
                    elif op == "pool":
                        h = F.max_pool2d(h, 2)
                    elif op == "pw":
                        h = F.relu(aff(pk, h))
                    elif op == "gap":
                        hw = h.shape[2] * h.shape[3]
                        h = tap(h.mean(dim=(2, 3)), gam(hw + 1) * h.detach().abs().mean(dim=(2, 3)))
                    elif op == "head":
                        h = aff(pk, h)
                z = h
            E = torch.zeros(z.shape, dtype=torch.float64, device=z.device)
            for c in range(z.shape[1]):
                gs = torch.autograd.grad(z[:, c].sum(), leaves, retain_graph=c < z.shape[1] - 1)
                acc = torch.zeros(z.shape[0], dtype=z.dtype, device=z.device)
                for g_, d_ in zip(gs, loc):
                    acc = acc + (g_.abs() * d_).reshape(z.shape[0], -1).sum(dim=1)
                E[:, c] = acc.double()
        return E * 1.01

    def first_layer(self) -> str:
        return self.backbone[0][1]

    def receiver(self) -> str:
        return self.backbone[self.recv_index][1]

    # ------------------------------------------------------------------ edits (float64 algebra)
    def merge_map(self) -> tuple:
        """z = (I + M) h + c for affine (identity-activation) branches."""
        if any(b["act"] != "identity" for b in self.branches):
            raise Unsupported("the merge is not affine")
        if not self.branches:
            raise Unsupported("no merge to fold")
        d = self.P[f"{self.branches[0]['A']}.weight"].shape[1]
        dev = self.P[f"{self.branches[0]['A']}.weight"].device
        M = torch.zeros(d, d, dtype=torch.float64, device=dev)
        c = torch.zeros(d, dtype=torch.float64, device=dev)
        for b in self.branches:
            A, a = self.P[f"{b['A']}.weight"].double(), self.P[f"{b['A']}.bias"].double()
            B, bb = self.P[f"{b['B']}.weight"].double(), self.P[f"{b['B']}.bias"].double()
            M += B @ A
            c += B @ a + bb
        return M, c

    def folded(self) -> "RefNet":
        """the compact network: the receiving layer W (I + M), b + W c; no branches."""
        M, c = self.merge_map()
        r = self.receiver()
        W, b = self.P[f"{r}.weight"].double(), self.P[f"{r}.bias"].double()
        I_ = torch.eye(M.shape[0], dtype=torch.float64, device=M.device)
        P = {k: v.clone() for k, v in self.P.items() if not any(k.startswith(br[x] + ".") for br in self.branches
                                                                  for x in ("A", "B"))}
        P[f"{r}.weight"] = (W @ (I_ + M)).to(self.P[f"{r}.weight"].dtype)
        P[f"{r}.bias"] = (b + W @ c).to(self.P[f"{r}.bias"].dtype)
        return RefNet(self.family, self.backbone, self.recv_index, [], P, self.cut_after)

    def with_swap(self, pairs: list) -> "RefNet":
        P = {k: v.clone() for k, v in self.P.items()}
        own = {b["owner"]: b for b in self.branches}
        for oa, ob in pairs:
            for x in ("A", "B"):
                for s in ("weight", "bias"):
                    ka, kb = f"{own[oa][x]}.{s}", f"{own[ob][x]}.{s}"
                    P[ka], P[kb] = self.P[kb].clone(), self.P[ka].clone()
        return RefNet(self.family, self.backbone, self.recv_index, [dict(b) for b in self.branches], P,
                      self.cut_after)

    def with_shift(self, t: float) -> "RefNet":
        s = 1.0 - float(t)
        M, c = self.merge_map()
        r = self.receiver()
        W, b = self.P[f"{r}.weight"].double(), self.P[f"{r}.bias"].double()
        I_ = torch.eye(M.shape[0], dtype=torch.float64, device=M.device)
        W2 = W @ (I_ + M) @ torch.linalg.inv(I_ + s * M)
        b2 = b + W @ c - s * (W2 @ c)
        P = {k: v.clone() for k, v in self.P.items()}
        for br in self.branches:
            for x in ("weight", "bias"):
                P[f"{br['B']}.{x}"] = (self.P[f"{br['B']}.{x}"].double() * s).to(self.P[f"{br['B']}.{x}"].dtype)
        P[f"{r}.weight"] = W2.to(self.P[f"{r}.weight"].dtype)
        P[f"{r}.bias"] = b2.to(self.P[f"{r}.bias"].dtype)
        return RefNet(self.family, self.backbone, self.recv_index, [dict(b) for b in self.branches], P,
                      self.cut_after)


def swap_pairs(md: dict) -> list:
    """(a owner, b owner) per round, from the implants' slots (spec/r<k>/a, spec/r<k>/b)."""
    by = {}
    for im in md["spec"]["implants"]:
        sl = str(im.get("slot") or "")
        parts = sl.split("/")
        if len(parts) == 3 and parts[0] == "spec" and parts[2] in ("a", "b"):
            by.setdefault(parts[1], {})[parts[2]] = im["id"]
    out = []
    for r in sorted(by):
        if set(by[r]) != {"a", "b"}:
            raise Unsupported(f"round {r} has no a / b pair")
        out.append((by[r]["a"], by[r]["b"]))
    return out


# ----------------------------------------------------------------------------- loss and optimizer

def ce_loss(logits, y):
    """mean cross entropy written out (log-sum-exp), not F.cross_entropy."""
    m = logits.max(dim=1, keepdim=True).values
    lse = m.squeeze(1) + torch.log(torch.exp(logits - m).sum(dim=1))
    return (lse - logits.gather(1, y.long().view(-1, 1)).squeeze(1)).mean()


class RefAdamW:
    """AdamW written from its definition: decoupled decay, bias-corrected moments with a step counter per tensor (a
    grown network's tensors have different ages); held input columns of one tensor get no gradient and are restored
    after every step.  from_saved imports a saved optimizer state (moments and counters by parameter name)."""

    def __init__(self, P: dict, lr: float, betas=(0.9, 0.999), eps: float = 1e-8, wd: float = 0.0,
                 hold: tuple | None = None):
        self.P, self.lr, self.b1, self.b2, self.eps, self.wd = P, lr, betas[0], betas[1], eps, wd
        self.m = {k: torch.zeros_like(v) for k, v in P.items()}
        self.v = {k: torch.zeros_like(v) for k, v in P.items()}
        self.t = {k: 0 for k in P}
        self.hold = hold                      # (tensor name, [columns])
        self.held = None if hold is None else P[hold[0]].detach()[:, hold[1]].clone()

    @classmethod
    def from_saved(cls, P: dict, trainer_state: dict, hold: tuple | None = None) -> "RefAdamW":
        """P: name -> tensor ('pkey.weight'); trainer_state: a saved trainer state (its 'opt' state dict and
        'opt_param_names').  One parameter group (lr, betas, eps, weight decay read from it); moments and counters
        per name; a tensor without saved state starts fresh."""
        sd, names = trainer_state["opt"], trainer_state["opt_param_names"]
        if len(sd["param_groups"]) != 1:
            raise Unsupported("more than one optimizer parameter group")
        gp = sd["param_groups"][0]
        o = cls(P, float(gp["lr"]), tuple(gp["betas"]), float(gp["eps"]), float(gp["weight_decay"]), hold)
        idx = gp["params"]
        if len(idx) != len(names):
            raise Unsupported("optimizer state and parameter names differ in length")
        for i, nm in zip(idx, names):
            st = sd["state"].get(i)
            if nm not in P:
                raise Unsupported(f"saved optimizer state for {nm}, which the network does not have")
            if st:
                dt, dv = P[nm].dtype, P[nm].device
                o.m[nm] = st["exp_avg"].detach().to(device=dv, dtype=dt).clone()
                o.v[nm] = st["exp_avg_sq"].detach().to(device=dv, dtype=dt).clone()
                o.t[nm] = int(float(st["step"]))
        return o

    def step(self, grads: dict) -> None:
        with torch.no_grad():
            for k, p in self.P.items():
                g = grads[k].clone()
                if self.hold is not None and k == self.hold[0]:
                    g[:, self.hold[1]] = 0.0
                self.t[k] += 1
                t = self.t[k]
                self.m[k] = self.b1 * self.m[k] + (1 - self.b1) * g
                self.v[k] = self.b2 * self.v[k] + (1 - self.b2) * g * g
                mh = self.m[k] / (1 - self.b1 ** t)
                vh = self.v[k] / (1 - self.b2 ** t)
                p.mul_(1 - self.lr * self.wd)
                p.sub_(self.lr * mh / (vh.sqrt() + self.eps))
            if self.hold is not None:
                self.P[self.hold[0]][:, self.hold[1]] = self.held


def grads_of(net: RefNet, x, y, masks=None) -> tuple:
    """(loss, {name: gradient}, gradient at the merge input h or None)."""
    ln = net.leaf()
    out, inter = ln.forward(x, masks, keep=True)
    h = inter.get("h")
    if h is not None:
        h.retain_grad()
    loss = ce_loss(out, y)
    loss.backward()
    return float(loss.detach()), {k: v.grad.detach().clone() for k, v in ln.P.items()}, \
        (h.grad.detach().clone() if h is not None else None)


def predictions(net: RefNet, x, batch: int = 2048) -> torch.Tensor:
    outs = []
    with torch.no_grad():
        for i in range(0, x.shape[0], batch):
            outs.append(net.forward(x[i:i + batch]))
    return torch.cat(outs) if outs else torch.zeros(0)


def rounding_bounds(net: RefNet, x, batch: int = 1024, u: float = 2.0 ** -24, dtype=None) -> torch.Tensor:
    """v70: the first-order float rounding-error ESTIMATE per example and logit over x in batches
    (RefNet.rounding_bound; v71: an estimate, not a rigorous bound)."""
    es = [net.rounding_bound(x[i:i + batch], u, dtype) for i in range(0, x.shape[0], batch)]
    return torch.cat(es) if es else torch.zeros(0)


def finite(t) -> bool:
    return bool(torch.isfinite(t).all())


def rel(a, b) -> float:
    a, b = a.double(), b.double()
    return float((a - b).abs().max()) / max(1.0, float(b.abs().max())) if a.numel() else 0.0


__all__ = ["RefNet", "RefAdamW", "Unsupported", "ce_loss", "grads_of", "predictions", "rounding_bounds",
           "swap_pairs", "finite", "rel", "math"]
