"""v68 / v69 / v70: recompute a declared selection of real saved checkpoints with the independent reference
(reference_impl.py) and certify, row by row, what the implementation computed.

  python audit_v5/tools/reference_recompute.py RESULTS OUT --manifest MANIFEST --states STATES_CSV
         [--select-from STATES_CSV] [--audits AUDITS_CSV] [--cases standard|mechanism] [--n-f0 N|all]
         [--no-table] [--device D] [--extra-device D] [--ref-device D] [--bound-dtype float64|float32]
         [--eval-batch N] [--data-root R]

PLAN (written to OUT_plan.json before anything is computed; every key must be checked).  Selection, from the
--select-from states table (default --states) and the manifest: the f0 whose A-arm routed trajectory most worsened
the normalised extraction (trajectory end minus f0) and, with --n-f0 2, the median one; with --n-f0 N > 2, N f0
evenly spaced over that ranking (both ends included); with --n-f0 all, every f0 of the design (each must have the
harm value); with --cases mechanism also the f0 of the most ill-conditioned redistribution (largest
outcome_redistribution_cond in --audits, required).
For each selected f0, both parent arms and BOTH fork points:
  standard   f0, the fork start, the trajectory end, the ends of routed_reset, ordinary_reset, folded_reset,
             frozen_reset and routed_carry; the fold of the snapshot against the saved after-fold start
  mechanism  the ends of routed_swap, ordinary_swap, routed_shift50, routed_shift100, ordinary_shift100; each saved
             edited start against the reference's own edit (swap, shift 0.5, shift 1) of the snapshot
Measures per state: native (the network), extraction (its first layer in f0), and each normalised first layer (built
here: per row and block, per row, per block).  Every planned checkpoint must exist and pass check_ckpt.

CERTIFICATES per row (all must pass; each is a column):
  function64   the implementation (GraphNet) evaluated in float64 on the stored tensors against the reference in
               float64: |z_impl - z_ref| <= 1e-9 + 1e-9 |z_ref| for every example and logit (the computation)
  deployed     (v70) the implementation in its stored dtype on --device (the analysis's device and batch) against
               the reference: |dz| <= E for every example and logit, E the first-order float32 rounding-error
               ESTIMATE of this network on this example (reference_impl.rounding_bound: Higham's gamma_n per
               rounding operation, carried to the logits by the network's Jacobian at the activation pattern of
               its own evaluation in --bound-dtype).  v71: an estimate, not a rigorous bound (second-order terms, activation changes and
               transform convolutions are not covered); an empirical consistency check, not an arbiter of
               correctness.  The float64 certificate is the implementation-agreement check.  An example is decided when every other
               class trails the reference's top class by more than the sum of their two bounds; a decided example
               may not differ, and at most 0.1% of the examples may be undecided and differ.  v69's fixed 1e-4
               (1 + |z|) tolerance ignored the conditioning of the network and is reported only (fixed1e4_*)
  deployed_extra  the same on --extra-device (float32 on the GPU), when given, with the same bound
               Also per row: exact_wrong (the reference's own error count) and deployed_wrong (float32's), so the
               effect of float32 rounding on the error rate is recorded
  params       the independently built tensors against the implementation's stored ones (the reference's float64
               values rounded to the stored dtype): |dW| <= 1e-9 + 1e-6 |W_ref| for the normalised first layers
               (bias: f0's), the fold of the snapshot (W (I + M), b + W c; its composed receiving layer may also
               differ by the float32 product bound 2 n u |W| |I + M|, u = 2^-24) and each redistribution (swap, shift)
               of the snapshot.  function64 and deployed always evaluate the implementation's own stored tensors, so
               they certify the computation and params certifies the tensors
  eligibility  a normalised layer the analysis marked ineligible must be one the reference also cannot build at the
               target norms (an unmatched row or a per-row miss above 1e-8 + 1e-5 x target); it is then labelled
               ineligible (not a failure) and its table value must be empty
  table        (unless --no-table) the states table holds exactly one row for the state, its metric present and
               finite, and equal to the implementation's error recomputed here on the same device and batch (the
               same count of wrong examples)
Writes OUT_plan.json, OUT_rows.csv, OUT_failed_states.txt (f0|parent/fork/state of every state with a failed row,
in the states table's keys: the registry excludes rows that depend on them) and OUT_coverage.json (expected,
checked, passed, failed, ineligible and missing keys; the SHA-256 of the states table and manifest, the checkpoint
parameter hashes, the numerical policy).  Exit 0 when every planned key was checked and passed, 4 when every key
was checked but some rows failed (their states are listed for exclusion), 1 when the plan was not completed, 2 on
wrong arguments."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import torch  # noqa: E402

import fork_continuation as FC  # noqa: E402
import reference_impl as R  # noqa: E402
import selective_reversal as SR  # noqa: E402
from cop.graph.graph import GraphNet  # noqa: E402
from cop.train.trainer import predict  # noqa: E402

AC = SR.AC
Fail = AC.Fail
STANDARD = ("routed_reset", "ordinary_reset", "folded_reset", "frozen_reset", "routed_carry")
MECH = ("routed_swap", "ordinary_swap", "routed_shift50", "routed_shift100", "ordinary_shift100")
EDIT_OF = {"routed_swap": ("swap", None), "ordinary_swap": ("swap", None), "routed_shift50": ("shift", 0.5),
           "routed_shift100": ("shift", 1.0), "ordinary_shift100": ("shift", 1.0)}
F64_TOL, UNDECIDED_MAX = 1e-9, 1e-3
P_RTOL, P_ATOL = 1e-6, 1e-9


def sha(p) -> str:
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def blocks_independent(lay: dict, n_in: int) -> dict:
    c0, c1 = (int(x) for x in lay["causal"])
    sc = int(lay["shortcut"])
    out = {"causal": list(range(c0, c1)), "shortcut": [sc]}
    rest = [j for j in range(n_in) if not c0 <= j < c1 and j != sc]
    if rest:
        out["other"] = rest
    return out


def ref_normalised(W, W0, blocks: dict, how: str) -> tuple:
    """W at W0's norms, written out here -> (weights, unmatched rows or blocks, worst per-row miss ok?)."""
    W, W0 = W.double(), W0.double()
    out = W.clone()
    unmatched = 0
    groups = [list(range(W.shape[1]))] if how == "row" else list(blocks.values())
    for cols in groups:
        a = W[:, cols].reshape(W.shape[0], -1)
        t = W0[:, cols].reshape(W0.shape[0], -1)
        if how == "block":
            s, tt = a.norm(), t.norm()
            unmatched += int(s == 0 and tt > 0)
            f = (tt / s) if s > 0 else torch.tensor(1.0, dtype=torch.float64)
            out[:, cols] = W[:, cols] * f
        else:
            s, tt = a.norm(dim=1), t.norm(dim=1)
            unmatched += int(((s == 0) & (tt > 0)).sum())
            f = torch.where(s > 0, tt / torch.where(s > 0, s, torch.ones_like(s)), torch.ones_like(s))
            out[:, cols] = W[:, cols] * f.view(-1, *([1] * (W.dim() - 1)))
    return out, unmatched


def norm_miss_rows(We, W0, blocks: dict, how: str) -> int:
    """rows (blocks) of a built layer that miss their target by more than 1e-8 + 1e-5 x target (source nonzero)."""
    bad = 0
    groups = [list(range(We.shape[1]))] if how == "row" else list(blocks.values())
    for cols in groups:
        a = We[:, cols].double().reshape(We.shape[0], -1)
        t = W0[:, cols].double().reshape(W0.shape[0], -1)
        if how == "block":
            an, tn = a.norm().reshape(1), t.norm().reshape(1)
        else:
            an, tn = a.norm(dim=1), t.norm(dim=1)
        m = an > 0
        bad += int(((an - tn).abs() > 1e-8 + 1e-5 * tn)[m].sum())
    return bad


def mixed(a, b, tol) -> tuple:
    """(ok, worst |a - b| / (tol + tol |b|), per-example worst |a - b|, examples violating)."""
    a, b = a.double().cpu(), b.double().cpu()
    if not (R.finite(a) and R.finite(b)) or a.shape != b.shape:
        return False, math.inf, None, -1
    d = (a - b).abs()
    ratio = d / (tol + tol * b.abs())
    per = d.reshape(d.shape[0], -1).max(dim=1).values
    viol = int((ratio.reshape(ratio.shape[0], -1).max(dim=1).values > 1).sum())
    return viol == 0, float(ratio.max()) if ratio.numel() else 0.0, per, viol


def decisions(z_ref, z_dep, y, E) -> dict:
    """v70.  E: the first-order float32 rounding-error estimate per example and logit (reference_impl.rounding_bound;
    v71: an estimate, not a bound).  The
    deployed logits must satisfy |z_dep - z_ref| <= E for every example and logit.  Example i is decided when, for every
    other class c, z_ref[i, top] - z_ref[i, c] > E[i, top] + E[i, c]: any evaluation within the estimate must then make the
    reference's decision, so a disagreement there is an error.  An undecided example (a tie at rounding level) may
    differ, and at most UNDECIDED_MAX of the examples may be undecided and differ."""
    zr, zd, E = z_ref.double().cpu(), z_dep.double().cpu(), E.double().cpu()
    n = int(zr.shape[0])
    if not (R.finite(zr) and R.finite(zd) and R.finite(E)) or zr.shape != zd.shape or zr.shape != E.shape:
        return {"ok": False, "worst": math.inf, "violations": -1, "n": n, "undecided": n, "disagree_decided": -1,
                "disagree": -1, "disagree_undecided": -1, "wrong": None, "exact_wrong": None}
    d = (zd - zr).abs()
    ratio = d / torch.clamp(E, min=1e-300)
    viol = int((ratio > 1).any(dim=1).sum())
    top = zr.argmax(1)
    zt, Et = zr.gather(1, top[:, None]), E.gather(1, top[:, None])
    slack = (zt - zr) - (Et + E)
    slack.scatter_(1, top[:, None], math.inf)
    decided = slack.min(dim=1).values > 0
    pd = zd.argmax(1)
    dis = top != pd
    dd = int((dis & decided).sum())
    du = int((dis & ~decided).sum())
    yc = y.cpu()
    return {"ok": viol == 0 and dd == 0 and du <= UNDECIDED_MAX * n, "worst": float(ratio.max()) if n else 0.0,
            "violations": viol, "n": n, "undecided": int((~decided).sum()), "disagree_decided": dd,
            "disagree_undecided": du, "disagree": int(dis.sum()), "wrong": int((pd != yc).sum()),
            "exact_wrong": int((top != yc).sum()),
            "bound_rel_max": float((E / (1.0 + zr.abs())).max()) if n else 0.0,
            "fixed1e4_worst": float((d / (1e-4 + 1e-4 * zr.abs())).max()) if n else 0.0,
            "fixed1e4_violations": int(((d / (1e-4 + 1e-4 * zr.abs())) > 1).any(dim=1).sum())}


def on(net, d):
    """the reference network with its tensors on device d."""
    return R.RefNet(net.family, net.backbone, net.recv_index, net.branches,
                    {k: v.to(d) for k, v in net.P.items()}, net.cut_after)


def impl_pred(g, part, batch, dev, dtype=None):
    g = g.to(dev).eval()
    g._plan = None
    with torch.no_grad():
        return predict(g, part.to(dev) if hasattr(part, "to") else part, batch, dtype).double().cpu()


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("results")
    ap.add_argument("out")
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--states", required=True)
    ap.add_argument("--select-from", default=None)
    ap.add_argument("--audits", default=None)
    ap.add_argument("--cases", choices=("standard", "mechanism"), default="standard")
    ap.add_argument("--n-f0", default="2", help="1, 2, ..., or all")
    ap.add_argument("--no-table", action="store_true")
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--extra-device", default=None)
    ap.add_argument("--eval-batch", type=int, default=None)
    ap.add_argument("--ref-device", default="cpu", help="where the float64 reference and implementation run")
    ap.add_argument("--bound-dtype", choices=("float64", "float32"), default="float64",
                    help="the dtype the rounding estimate's Jacobians are computed in")
    ap.add_argument("--metric", default="state_at_f0_block_row_norms_f0_bias_test_err")
    a = ap.parse_args(argv)
    if a.n_f0 != "all" and not (a.n_f0.isdigit() and int(a.n_f0) >= 1):
        print("--n-f0 must be a positive integer or all", file=sys.stderr)
        return 2
    dev = torch.device(a.device)
    rdev = torch.device(a.ref_device)
    bdt = torch.float32 if a.bound_dtype == "float32" else torch.float64
    xdev = torch.device(a.extra_device) if a.extra_device else None
    for d_ in (dev, xdev, rdev):
        if d_ is not None and d_.type == "cuda" and not torch.cuda.is_available():
            print("CUDA requested but not available", file=sys.stderr)
            return 2
    runs = Path(a.results) / "runs"
    mcfg = {e["run_id"]: e["cfg"] for e in AC.manifest_entries(a.manifest)}
    cov = {"tool": "reference_recompute", "schema": "reference_recompute/v70", "manifest": a.manifest,
           "manifest_sha256": sha(a.manifest), "states": a.states, "states_sha256": sha(a.states),
           "select_from": a.select_from or a.states, "cases": a.cases, "table_check": not a.no_table,
           "device": str(dev), "extra_device": str(xdev) if xdev else None, "ref_device": str(rdev),
           "bound_dtype": a.bound_dtype, "n_f0": a.n_f0,
           "numerics": FC.CE.numerics_policy(dev),
           "tolerances": {"function64": F64_TOL,
                          "deployed": "first-order float32 rounding-error estimate per example and logit (gamma_n "
                                      "local errors carried by the Jacobian; reference_impl.rounding_bound)",
                          "estimate_kind": "first-order estimate, not a rigorous bound",
                          "estimate_assumptions": ["terms of order u^2 neglected",
                                                   "activation pattern (ReLU signs, max-pool winners) of its own "
                                                   "evaluation in --bound-dtype", "direct summation in each dot product (no Winograd "
                                                   "or FFT convolution)",
                                                   "Jacobian and local terms in --bound-dtype"],
                          "undecided_max": UNDECIDED_MAX, "params": [P_ATOL, P_RTOL],
                          "v69_fixed_1e-4": "reported only (fixed1e4_* columns)"},
           "failed": [], "checkpoints": {}}
    # ---- the states tables (no duplicate key)
    def load_states(p):
        out = {}
        for r in csv.DictReader(open(p)):
            k = (r["f0"], r["parent"], r["fork"], r["state"])
            if k in out:
                raise Fail(f"{p}: duplicate state row {k}")
            out[k] = r
        return out
    try:
        sk = load_states(a.states)
        sel = load_states(a.select_from) if a.select_from else sk
    except Fail as ex_:
        cov["failed"].append({"f0": None, "reason": str(ex_)})
        cov["complete"] = cov["passed"] = False
        Path(f"{a.out}_coverage.json").write_text(json.dumps(cov, indent=1))
        print(ex_, file=sys.stderr)
        return 1
    jobs = FC.fork_jobs(mcfg)
    harm = []
    for bid, J in jobs.items():
        if "A_routed_affine" not in J or not J["A_routed_affine"]["forks"]:
            continue
        fk = sorted(J["A_routed_affine"]["forks"], key=lambda s: int(s.split("_")[1]))[0]
        e = sel.get((bid, "A_routed_affine", fk, "trajectory_end")) or sel.get((bid, "A_routed_affine", "end",
                                                                                 "trajectory_end"))
        f = sel.get((bid, "f0", "f0", "f0"))
        if e and f and e.get(a.metric) not in (None, "") and f.get(a.metric) not in (None, ""):
            harm.append((float(e[a.metric]) - float(f[a.metric]), bid))
    harm.sort(reverse=True)
    pick = []
    n_a = sum(1 for J in jobs.values() if "A_routed_affine" in J and J["A_routed_affine"]["forks"])
    if a.n_f0 == "all":
        pick = [b_ for _, b_ in harm]
        want_n = n_a
    else:
        want_n = int(a.n_f0)
        if harm:
            if want_n == 1:
                idx = [0]
            elif want_n == 2:
                idx = [0, len(harm) // 2]                  # the most harmful and the median
            else:                                         # evenly spaced over the harm ranking, both ends included
                idx = sorted({round(i * (len(harm) - 1) / (want_n - 1)) for i in range(want_n)})
            pick = list(dict.fromkeys(harm[i][1] for i in idx if i < len(harm)))     # distinct f0
    if len(pick) < want_n or not pick:
        cov["failed"].append({"f0": None, "reason": f"{a.n_f0} f0 requested ({want_n}), {len(harm)} of {n_a} with the "
                                                     f"harm metric {a.metric} in the selection table"})
    if a.cases == "mechanism":   # the most ill-conditioned redistribution is part of the plan, never optional
        au = [r for r in csv.DictReader(open(a.audits))
              if r.get("outcome_redistribution_cond") not in (None, "")] if a.audits else []
        if not au:
            cov["failed"].append({"f0": None, "reason": "mechanism cases need --audits with outcome_redistribution_cond"
                                                        " (the ill-conditioned edit)"})
        else:
            worst = max(au, key=lambda r: float(r["outcome_redistribution_cond"]))
            cov["ill_conditioned"] = {k: worst.get(k) for k in ("f0", "parent", "fork", "state", "run_id",
                                                                 "outcome_redistribution_cond",
                                                                 "outcome_redistribution_storage64")}
            if worst["f0"] not in pick:
                pick.append(worst["f0"])
    # ---- the plan
    conts = STANDARD if a.cases == "standard" else MECH
    plan = []
    for bid in pick:
        J = jobs[bid]
        for parent in sorted(J):
            for fk in sorted(J[parent]["forks"], key=lambda s: int(s.split("_")[1])):
                states = (["start", "trajectory_end"] if a.cases == "standard" else []) + \
                    [c for c in conts if c in J[parent]["forks"][fk]]
                plan += [{"f0": bid, "parent": parent, "fork": fk, "state": s} for s in states]
                if a.cases == "standard" and "folded_reset" in J[parent]["forks"][fk]:
                    plan.append({"f0": bid, "parent": parent, "fork": fk, "state": "folded_start"})
                if a.cases == "mechanism":
                    plan += [{"f0": bid, "parent": parent, "fork": fk, "state": f"edit:{c}"} for c in MECH
                             if c in J[parent]["forks"][fk]]
        if a.cases == "standard":
            plan.append({"f0": bid, "parent": "f0", "fork": "f0", "state": "f0"})
    cov["selection"] = pick
    cov["harm_metric"] = a.metric
    Path(f"{a.out}_plan.json").write_text(json.dumps({"selection": pick, "cases": plan}, indent=1))
    if not plan:
        cov["failed"].append({"f0": None, "reason": "nothing selected (no harm values in the selection table)"})
    rows, failed_states, checked = [], set(), set()
    for bid in pick:
        try:
            J = jobs[bid]
            parents = sorted(J)
            tid0 = J[parents[0]]["traj"]
            tcfg0 = AC.job_config(runs, tid0, mcfg[tid0])
            b0 = SR.load_bundle(tcfg0["data"], a.data_root, device="cpu")
            hashes, need = b0.hashes(), {"train", *AC.eval_partitions(b0)}
            test = b0.partitions()["test"]
            xt, yt = test.X["x"], test.y
            lay = (b0.meta or {}).get("feature_layout") or {}
            batch = int(a.eval_batch or (tcfg0.get("train") or {}).get("eval_batch", 4096))

            def ck_of(rid, stg, cfg):
                ck = SR.ckp(runs / rid, stg)
                if ck is None:
                    raise Fail(f"{rid}: no checkpoint {stg}")
                AC.check_ckpt(ck, f"{rid} {stg}", run_id=rid, stage=stg, cfg=cfg, hashes=hashes, need=need)
                cov["checkpoints"][f"{rid}:{stg}"] = AC.param_hash_of(ck)
                return ck
            f0ck = ck_of(tid0, "baseline_ref", tcfg0)
            ref0 = R.RefNet.from_model_dict(f0ck["model"])
            first = ref0.first_layer()
            W0, b0w = ref0.P[f"{first}.weight"], ref0.P[f"{first}.bias"]
            fam = ref0.family
            blocks = blocks_independent(lay, int(W0.shape[1]))
            hows = {"state_at_f0_block_row_norms_f0_bias": "block_row"}
            hows["state_at_f0_block_norms_f0_bias" if fam == "mlp" else "state_at_f0_row_norms_f0_bias"] = \
                "block" if fam == "mlp" else "row"
            def certify(case, measure, md_impl, ref_net, table_key, srow, extra=None):
                """one row: function64, deployed (+extra) against the rounding estimate, table."""
                rn = on(ref_net, rdev)
                xr = xt.double().to(rdev)
                z_r = R.predictions(rn, xr, 1024).cpu()
                E = R.rounding_bounds(rn, xr, 512, dtype=bdt).cpu()
                g64 = GraphNet.from_checkpoint(md_impl, "cpu").double()
                # float64 evaluations in batches of 1024 (memory on the GPU); the batch does not change a float64
                # result beyond rounding.  The deployed evaluation below keeps the analysis's batch (the table).
                f_ok, f_w, _, f_v = mixed(impl_pred(g64, test, 1024, rdev, torch.float64), z_r, F64_TOL)
                dep = decisions(z_r, impl_pred(GraphNet.from_checkpoint(md_impl, "cpu"), test, batch, dev), yt, E)
                row = {**case, "measure": measure, "n": dep["n"], "function64_ok": f_ok, "function64_worst": f_w,
                       "deployed_ok": dep["ok"], "deployed_worst": dep["worst"],
                       "deployed_violations": dep["violations"], "undecided": dep["undecided"],
                       "disagree": dep.get("disagree"), "disagree_decided": dep["disagree_decided"],
                       "disagree_undecided": dep.get("disagree_undecided"), "bound_rel_max": dep.get("bound_rel_max"),
                       "exact_wrong": dep.get("exact_wrong"), "deployed_wrong": dep.get("wrong"),
                       "fixed1e4_worst": dep.get("fixed1e4_worst"),
                       "fixed1e4_violations": dep.get("fixed1e4_violations")}
                if xdev is not None:
                    dx = decisions(z_r, impl_pred(GraphNet.from_checkpoint(md_impl, "cpu"), test, batch, xdev),
                                   yt, E)
                    row.update({"deployed_extra_ok": dx["ok"], "deployed_extra_worst": dx["worst"],
                                "deployed_extra_undecided": dx["undecided"],
                                "deployed_extra_disagree_decided": dx["disagree_decided"],
                                "deployed_extra_wrong": dx.get("wrong"),
                                "fixed1e4_extra_worst": dx.get("fixed1e4_worst")})
                if not a.no_table and table_key is not None:
                    tv = None if srow is None else srow.get(table_key)
                    try:
                        tvf = float(tv) if tv not in (None, "") else None
                    except ValueError:
                        tvf = None
                    t_ok = tvf is not None and math.isfinite(tvf) and dep["wrong"] is not None and \
                        abs(tvf * dep["n"] - dep["wrong"]) < 0.5
                    row.update({"table_value": tvf, "impl_wrong": dep["wrong"], "table_ok": t_ok})
                row.update(extra or {})
                row["passed"] = all(v for k, v in row.items() if k.endswith("_ok"))
                rows.append(row)
                return row

            def with_first(md, W, bw):
                m = json.loads(json.dumps({"spec": md["spec"]}))
                st = {k: v.clone() for k, v in md["state"].items()}
                st[f"mods.{first}.weight"] = W.to(st[f"mods.{first}.weight"].dtype)
                st[f"mods.{first}.bias"] = bw.to(st[f"mods.{first}.bias"].dtype)
                return {"spec": m["spec"], "state": st, "dtypes": md.get("dtypes")}

            def state_rows(case, md, skey):
                srow = sk.get(skey)
                if srow is None and not a.no_table:
                    raise Fail(f"{skey}: no row in the states table")
                ref = R.RefNet.from_model_dict(md)
                rs = [certify(case, "native", md, ref, "native_test_err", srow)]
                if case["state"] == "f0":
                    return rs
                W, bw = ref.P[f"{first}.weight"], ref.P[f"{first}.bias"]
                rx = R.RefNet(ref0.family, ref0.backbone, ref0.recv_index, ref0.branches,
                              {**ref0.P, f"{first}.weight": W, f"{first}.bias": bw}, ref0.cut_after)
                rs.append(certify(case, "extraction", with_first(f0ck["model"], W, bw), rx, "extraction_test_err",
                                  srow))
                for name, how in hows.items():
                    Wr, unm = ref_normalised(W, W0, blocks, how)
                    Wi = impl_edit(name, W.float(), bw.float(), W0.float(), b0w.float(), lay, fam)
                    p_ok2 = bool((((Wi.double() - Wr).abs()) <= P_ATOL + P_RTOL * Wr.abs()).all())
                    ref_ineligible = unm > 0 or norm_miss_rows(Wi, W0, blocks, how) > 0
                    t_elig = None if srow is None else srow.get(f"{name}_eligible")
                    if t_elig == "False" or (t_elig is None and ref_ineligible):
                        ok = ref_ineligible and (srow is None or srow.get(f"{name}_test_err") in (None, ""))
                        rows.append({**case, "measure": name, "eligibility_ok": ok, "status": "ineligible",
                                     "unmatched": unm, "passed": ok})
                        continue
                    # function: the reference network on the implementation's stored tensors (the computation);
                    # params: those tensors against the ones built here (the edit)
                    rn = R.RefNet(ref0.family, ref0.backbone, ref0.recv_index, ref0.branches,
                                  {**ref0.P, f"{first}.weight": Wi.double(), f"{first}.bias": b0w}, ref0.cut_after)
                    rs.append(certify(case, name, with_first(f0ck["model"], Wi, b0w), rn, f"{name}_test_err", srow,
                                      {"params_ok": p_ok2 and not ref_ineligible,
                                       "params_worst": float(((Wi.double() - Wr).abs() /
                                                              (P_ATOL + P_RTOL * Wr.abs())).max()),
                                       "eligibility_ok": t_elig in (None, "True") and not ref_ineligible}))
                return rs

            for parent in parents:
                j = J[parent]
                tid = j["traj"]
                tcfg = AC.job_config(runs, tid, mcfg[tid])
                for fk in sorted(j["forks"], key=lambda s: int(s.split("_")[1])):
                    cs = j["forks"][fk]
                    snap = ck_of(tid, fk, tcfg)
                    entries = []
                    if a.cases == "standard":
                        entries += [("start", snap, (bid, parent, fk, "start")),
                                    ("trajectory_end", ck_of(tid, "final", tcfg),
                                     (bid, parent, fk, "trajectory_end") if (bid, parent, fk, "trajectory_end") in sk
                                     else (bid, parent, "end", "trajectory_end"))]
                    for cn in conts:
                        if cn in cs:
                            rid = cs[cn]
                            ccfg = AC.job_config(runs, rid, mcfg[rid])
                            ep = json.loads((runs / rid / "endpoint.json").read_text())
                            entries.append((cn, ck_of(rid, ep["checkpoint"], ccfg), (bid, parent, fk, cn)))
                    for st_name, ck, skey in entries:
                        case = {"f0": bid, "parent": parent, "fork": fk, "state": st_name,
                                "state_key": f"{skey[1]}/{skey[2]}/{skey[3]}"}
                        rs = state_rows(case, ck["model"], skey)
                        checked.add((bid, parent, fk, st_name))
                        if not all(r["passed"] for r in rows if (r["f0"], r["parent"], r["fork"], r["state"]) ==
                                   (bid, parent, fk, st_name)):
                            failed_states.add(f"{bid}|{case['state_key']}")
                    if a.cases == "standard" and "folded_reset" in cs:
                        rid = cs["folded_reset"]
                        ckf = ck_of(rid, "event_after_fold", AC.job_config(runs, rid, mcfg[rid]))
                        rsn = R.RefNet.from_model_dict(snap["model"])
                        rf = rsn.folded()
                        saved = R.RefNet.from_model_dict(ckf["model"])
                        pw = tensor_agreement(rf, saved, fold_scales(rsn))
                        case = {"f0": bid, "parent": parent, "fork": fk, "state": "folded_start",
                                "state_key": f"{parent}/{fk}/folded_reset"}
                        r_ = certify(case, "fold", ckf["model"], saved, None, None,
                                     {"params_ok": pw <= 1.0, "params_worst": pw})
                        checked.add((bid, parent, fk, "folded_start"))
                        if not r_["passed"]:
                            failed_states.add(f"{bid}|{parent}/{fk}/folded_reset")
                    if a.cases == "mechanism":
                        rsnap = R.RefNet.from_model_dict(snap["model"])
                        pairs = R.swap_pairs(snap["model"])
                        for cn in MECH:
                            if cn not in cs:
                                continue
                            rid = cs[cn]
                            ccfg = AC.job_config(runs, rid, mcfg[rid])
                            cke = ck_of(rid, "event_after_redistribute", ccfg)
                            kind, t = EDIT_OF[cn]
                            re_ = rsnap.with_swap(pairs) if kind == "swap" else rsnap.with_shift(t)
                            saved = R.RefNet.from_model_dict(cke["model"])
                            if set(saved.P) != set(re_.P):
                                raise Fail(f"{rid}: the saved start has other tensors than the edit")
                            worst = tensor_agreement(re_, saved)
                            case = {"f0": bid, "parent": parent, "fork": fk, "state": f"edit:{cn}",
                                    "state_key": f"{parent}/{fk}/{cn}"}
                            r_ = certify(case, "edit", cke["model"], saved, None, None,
                                         {"params_ok": worst <= 1.0, "params_worst": worst})
                            checked.add((bid, parent, fk, f"edit:{cn}"))
                            if not r_["passed"]:
                                failed_states.add(f"{bid}|{parent}/{fk}/{cn}")
            if "f0" in [p["parent"] for p in plan if p["f0"] == bid]:
                case = {"f0": bid, "parent": "f0", "fork": "f0", "state": "f0", "state_key": "f0/f0/f0"}
                state_rows(case, f0ck["model"], (bid, "f0", "f0", "f0"))
                checked.add((bid, "f0", "f0", "f0"))
                if not all(r["passed"] for r in rows if r["f0"] == bid and r["state"] == "f0"):
                    failed_states.add(f"{bid}|f0/f0/f0")
            print(f"f0 {bid} recomputed", flush=True)
        except (Fail, R.Unsupported, KeyError, RuntimeError, ValueError) as ex_:
            cov["failed"].append({"f0": bid, "reason": f"{type(ex_).__name__}: {ex_}"})
            print(f"FAIL {bid}: {ex_}", file=sys.stderr, flush=True)
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    keys = []
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    with open(f"{out}_rows.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys or ["f0"])
        w.writeheader()
        w.writerows(rows)
    Path(f"{out}_failed_states.txt").write_text("".join(x + "\n" for x in sorted(failed_states)))
    want = {(p["f0"], p["parent"], p["fork"], p["state"]) for p in plan}
    missing = sorted(want - checked)
    cov.update({"expected_cases": len(want), "checked_cases": len(checked & want), "missing_cases":
                [list(m) for m in missing], "rows": len(rows),
                "passed_rows": sum(1 for r in rows if r["passed"] and r.get("status") != "ineligible"),
                "ineligible_rows": sum(1 for r in rows if r.get("status") == "ineligible"),
                "failed_rows": [{k: r.get(k) for k in ("f0", "parent", "fork", "state", "measure")} |
                                {k: r[k] for k in r if k.endswith("_ok") and not r[k]} for r in rows if not r["passed"]],
                "failed_states": sorted(failed_states)})
    cov["complete"] = bool(want) and not missing and not cov["failed"]
    cov["passed"] = cov["complete"] and not cov["failed_rows"]
    Path(f"{out}_coverage.json").write_text(json.dumps(cov, indent=1, default=str))
    print(json.dumps({k: cov[k] for k in ("selection", "expected_cases", "checked_cases", "rows", "passed_rows",
                                          "ineligible_rows", "complete", "passed")} |
                     {"failed_rows": len(cov["failed_rows"])}))
    return 0 if cov["passed"] else (4 if cov["complete"] else 1)


def fold_scales(snap_ref) -> dict:
    """the floating-point error scale of the fold's composed receiving layer: a product W (I + M) of inner dimension
    n computed in float32 is within n u |W| |I + M| of the exact product (u = 2^-24); its bias b + W c within
    n u (|b| + |W| |c|).  -> {receiver tensor name: 2 n u x that scale}."""
    M, c = snap_ref.merge_map()
    r = snap_ref.receiver()
    W, b = snap_ref.P[f"{r}.weight"].double(), snap_ref.P[f"{r}.bias"].double()
    I_ = torch.eye(M.shape[0], dtype=torch.float64, device=M.device)
    n = M.shape[0] + 1
    u = 2.0 ** -24
    return {f"{r}.weight": 2 * n * u * (W.abs() @ (I_ + M).abs()),
            f"{r}.bias": 2 * n * u * (b.abs() + W.abs() @ c.abs())}


def tensor_agreement(ref, saved, scales: dict | None = None) -> float:
    """worst |saved - ref| / (P_ATOL + P_RTOL |ref|) over the tensors, matched by their place in the network (the
    backbone in order, then the branches in order), with the reference's float64 tensors rounded to the saved
    dtype first (storage).  inf when the structures differ."""
    if len(ref.backbone) != len(saved.backbone) or len(ref.branches) != len(saved.branches):
        return math.inf
    pairs = [(a[1], b[1]) for a, b in zip(ref.backbone, saved.backbone) if a[1]]
    pairs += [(ba[x], bb[x]) for ba, bb in zip(ref.branches, saved.branches) for x in ("A", "B")]
    worst = 0.0
    for ka, kb in pairs:
        for w in ("weight", "bias"):
            r = ref.P[f"{ka}.{w}"]
            sv = saved.P[f"{kb}.{w}"]
            if r.shape != sv.shape:
                return math.inf
            r32 = r.float().double()
            tol = P_ATOL + P_RTOL * r32.abs()
            if scales and f"{ka}.{w}" in scales:
                tol = tol + scales[f"{ka}.{w}"]
            worst = max(worst, float(((sv - r32).abs() / tol).max()) if r.numel() else 0.0)
    return worst


def impl_edit(name, W, b, W0, b0, lay, fam) -> torch.Tensor:
    """the implementation's own edited first layer (what the analysis measured)."""
    if fam == "mlp":
        import component_change as CC
        blk = CC.blocks_of(lay, int(W0.shape[1]))
        return CC.edit_layers(W, b, W0, b0, blk)[name][0]
    import image_forks as IF
    c0, c1 = lay["causal"]
    blocks = {"causal": torch.arange(int(c0), int(c1)), "shortcut": torch.tensor([int(lay["shortcut"])])}
    return IF.normalised_layers(W, b, W0, b0, blocks)[name][0]


if __name__ == "__main__":
    sys.exit(main())
