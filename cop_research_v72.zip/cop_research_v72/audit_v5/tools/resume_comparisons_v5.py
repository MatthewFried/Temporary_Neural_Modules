"""v5 job-level interrupted-vs-uninterrupted comparisons for the new paths: dissipation and repair with
the contraction diagnostics, the locality experiment (pegged and none arms, finite and stabilized), a
finite chain with a gradual temporary bridge, the full transplant grid and a witness baseline.  The v4
cases are in audit_v4/tools/resume_comparisons_v4.py (rerun them on v5 code too).
Usage: python audit_v5/tools/resume_comparisons_v5.py OUT_DIR [case,case,...]   (DEVICE=cuda for the GPU)"""
import os, sys, json, shutil, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / "tests"))
import torch; torch.set_num_threads(2)
import tiny_configs as T
from resume_harness import compare_interrupted
from cop.config import resolve, run_id
root = Path(sys.argv[1]); shutil.rmtree(root, ignore_errors=True); root.mkdir(parents=True)
TR = {**T.TRAIN, "checkpoint_every": 7}
lay = T.traj({"topology": "layered", "rounds": 1}, train=TR)
cyc = T.traj({"topology": "layered", "rounds": 2, "contract_every": 1, "contract_updates": 4}, train=TR)   # ends compact
LOC = {"task_kind": "locality", "n_pearls": 3, "global_updates": 24, "local_updates": 6, "locality_repair_updates": 8,
       "locality_eval_points": 2}
DQ = {"name": "delayed_query", "n_train": "full", "params": {"n_bits": 3, "split_mode": "complete"}}
DQM = {"family": "mlp", "width": 16, "depth": 3, "query_at_layer": 1}
RELU_T = {"name": "teacher", "n_train": 256, "n_val": 128, "n_test": 128,
          "params": {"teacher_depth": 2, "teacher_width": 12, "activation": "relu", "task": "regression", "d_in": 8,
                     "out_dim": 3}}
b = T.base(train=TR)
cases = {
    "diss_diagnostics": lay + [T.child("dissipation", lay[-1], {"dissipation": {"method": "linear", "speed_updates": 10,
                                                                                "post_updates": 10}})],
    "repair_diagnostics": lay + [T.child("repair", lay[-1], {"repair": {"budget_multiplier": 0.5, "eval_points": 2}})],
    "locality_finite_learned": T.cop({**LOC, "locality_interface": "finite_learned"},
                                     {"dim": 2, "mode": "uniform", "bits": 1}, train=TR),
    "locality_finite_stabilized": T.cop({**LOC, "locality_interface": "finite_stabilized"},
                                        {"dim": 2, "mode": "uniform", "bits": 1}, train=TR),
    "locality_none": T.cop({**LOC, "locality_interface": "none"}, {"mode": "none"}, train=TR),
    "finite_bridge_gradual": T.cop({"task_kind": "chain", "n_pearls": 2, "global_updates": 24},
                                   {"dim": 1, "mode": "uniform", "bits": 1, "temp_channel": 4, "temp_open_updates": 6},
                                   data=DQ, model=DQM, train=TR),
    "transplant_grid": cyc + [resolve({
        "kind": "transplant", "data": T.DATA, "model": T.MODEL, "train": TR, "seeds": {"optimizer": 0},
        "parents": {"upstream": run_id(cyc[0]), "downstream": run_id(cyc[-1])},
        "transplant": {"upstream_stage": "baseline", "downstream_stage": "final", "design": "grid",
                       "align_families": ["identity", "orthogonal", "affine", "mlp", "affine_task", "mlp_task"],
                       "adapter_updates": 10}})],
    "witness_baseline": [T.base(data=RELU_T, model={"family": "mlp", "width": 16, "depth": 4, "act": "relu"}, train=TR)],
}
only = sys.argv[2].split(",") if len(sys.argv) > 2 else None
unknown = sorted(set(only or []) - set(cases))
rep = {}
for name, cfgs in cases.items():
    if only and name not in only:
        continue
    t = time.time()
    try:
        r = compare_interrupted(cfgs, root / name, ex={"device": os.environ.get("DEVICE", "cpu"),
                                                       "data_root": os.environ.get("COP_DATA_ROOT")})
    except Exception as e:
        import traceback; traceback.print_exc(); r = {"error": repr(e)}
    if r.get("polls_uninterrupted") == 0:
        r["not_interruptible"] = True
        r["outputs_equal"] = not r["checkpoints_differing"] and not r["n_metrics_differing"] and \
            not r["results_differing"] and r["work_equal"]
    rep[name] = r
    print(name, round(time.time() - t, 1), {k: r.get(k) for k in ("equal", "attempts", "interrupted_at_polls",
          "polls_uninterrupted", "checkpoints_differing", "n_metrics_differing", "results_differing", "work_equal",
          "not_interruptible", "outputs_equal", "error")}, flush=True)
# v8: the verdict is part of the report and decides the exit status (1 on any failure, unknown case or
# empty check set).  Cases without a training loop pass only their documented repeatability check.
from cop.analysis.gates import resume_verdict, write_and_exit
verdict = resume_verdict(rep, allow_not_interruptible=set())
if unknown:
    verdict["passed"] = False
    verdict["failures"].append({"case": unknown, "reason": "requested cases do not exist"})
write_and_exit(root / "report.json", rep, verdict)
