#!/usr/bin/env python3
"""v56: at saved training states of an expansion, how do the update actually taken, the ordinary gradient and the
routed gradient relate, and what does the update do to the ordinary training loss and to the weight norms?

Analysis only: reads a finished panel (wave 25 or wave 26), trains no network.  For every f0, every expansion arm
and every saved state that carries the optimizer's state after at least one update (the configured snapshots and
the end; not the states saved right at an insertion):

  the update   the last AdamW step, reconstructed from the saved optimizer state (first and second moment,
               step count, learning rate, betas, eps):  d = -lr / (1 - b1^t) * m / (sqrt(v) / sqrt(1 - b2^t) + eps).
               Weight decay must be zero.  Held coordinates do not move: the trainer restores them after every
               step (train.freeze_inputs = shortcut: the first layer's shortcut column; train.freeze_backbone =
               downstream: every backbone layer after the first), although the optimizer still carries moments
               for them from before the hold, so the step is set to zero there.  The parameters before the step
               are theta_prev = theta - d.
  ordinary gradient   of the mean training loss over the whole training set at theta_prev, no masks
  routed gradient     the same loss value with the arm's gradient masks (growth.spec_partition random_matched,
                      from the trajectory's saved split; all_examples: masks of ones, which must reproduce the
                      ordinary gradient), under the arm's mask route (growth.spec_mask_route):
                        gradient   an example's gradient enters only the addition it is assigned to
                        parameter  (v57) only the additions' parameters are masked; every example's gradient
                                   reaches the backbone through both additions, so the backbone's routed gradient
                                   must equal its ordinary one
What each quantity is (v59 wording):
  the update     the HISTORICAL step: the last update the run actually took before the saved state, reconstructed
                 from the saved AdamW moments by the AdamW formula in float64, to verified numerical tolerance (the
                 tests check that theta(snap_u) minus it is theta at the previous update on miniatures).  Recomputing
                 in float64 does not undo the rounding of the original update, so it is not exact.  Its direction is
                 set by the first moment, an exponential average of the minibatch gradients of the routed training
                 loss (beta1 0.9: about the last ten minibatches); the step's own minibatch is not redrawn here
  the gradients  DIAGNOSTIC: full-batch gradients of the mean training loss, evaluated at the parameters before
                 that step (theta minus the step); ordinary (no masks) and routed (the arm's masks)
  the loss       the full-batch training loss before and after that one historical step, and its first-order
                 prediction from the ordinary gradient; one step at each saved state.  The measured change and its
                 prediction use the same full-batch objective and the same update, so the remainder (actual minus
                 predicted) is the higher-order (curvature) part of the change plus numerical and reconstruction
                 error.  Minibatch sampling decides the update's direction; it is not a separate term of the remainder
Gradients are compared on the coordinates that are free to move: a held column or a held layer has no update and
is left out, its ordinary gradient norm reported separately (ordinary_grad_norm_on_held).

  _checkpoints  per state: the ordinary training loss before and after the step, the first-order prediction of that
                change from the update (sum of ordinary gradient x update), the remainder (actual - predicted: what
                the linearisation misses), the same prediction with the routed gradient, and the built-in checks
  _updates      per state and parameter group (the first layer; its causal / shortcut / other input columns; the
                backbone up to the merge; the backbone after it; the additions; everything): norms of the update
                and of both gradients, cosines (ordinary with routed; the descent direction -update with each),
                each group's share of the predicted loss change, the weight norm before and after, and the radial
                cosines (does the update, or minus a gradient, point along the weights, i.e. grow their norm?)
Each with _by_draw and _summary (seeds averaged within a draw, 95% t intervals over draws), grouped by design_id.

Built-in checks (a failure fails the f0): the routed forward value equals the ordinary one; routing leaves the
gradients of the backbone after the merge unchanged; masks of ones reproduce the ordinary gradient; an
all-examples arm's routed gradient is its ordinary gradient; under the parameter route the whole backbone's routed
gradient is its ordinary gradient.
Compact controls are not included: their saved states carry no optimizer state.  The all-examples arms are the
ordinary-gradient expansions.  Everything here is exploratory.

usage: routing_updates.py RESULTS OUT_PREFIX --manifest M [--data-root D] [--device cpu|cuda] [--strict]
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import component_change as CC  # noqa: E402
import coordinated_edits as CE  # noqa: E402
import f0_panel as FP  # noqa: E402
import selective_reversal as SR  # noqa: E402

torch = SR.torch
Fail = SR.Fail
GraphNet = SR.GraphNet

ANALYSIS_SCHEMA = "routing_updates/v57"
STATUS = "exploratory reanalysis of existing checkpoints (no network is trained)"
GRAD_TOL = 1e-5                # relative tolerance of the gradient identities checked
VALUE_TOL = 1e-6               # relative tolerance between the routed and the ordinary loss value
GROUPS = ("first_layer", "first_layer_causal", "first_layer_shortcut", "first_layer_other", "backbone_to_merge",
          "backbone_after_merge", "additions", "all")
CKPT_KEYS = ("design_id", "cell", "variant", "stage", "updates_since_f0")
UPDATE_KEYS = CKPT_KEYS + ("group",)
CKPT_METRICS = ("train_loss_before", "train_loss_after", "actual_dloss", "predicted_dloss_ordinary",
                "remainder_dloss", "predicted_dloss_routed", "lr")
UPDATE_METRICS = ("update_norm", "ordinary_grad_norm", "routed_grad_norm", "cos_ordinary_routed",
                  "cos_descent_ordinary", "cos_descent_routed", "predicted_dloss_ordinary", "predicted_dloss_routed",
                  "weight_norm_before", "weight_norm_after", "weight_norm_change", "radial_cos_update",
                  "radial_cos_minus_ordinary", "radial_cos_minus_routed", "free_fraction",
                  "ordinary_grad_norm_on_held")


def held_masks(tcfg: dict, shapes: dict, wk: list, bk: list, sc: int) -> dict:
    """{parameter name: bool mask of the coordinates the trainer holds for the whole job} from the job's training
    settings, as the trainer defines them (restored after every update)."""
    t = tcfg.get("train") or {}
    fi, fb = t.get("freeze_inputs", "none"), t.get("freeze_backbone", "none")
    if fi not in ("none", "shortcut") or fb not in ("none", "downstream"):
        raise Fail(f"unknown hold: freeze_inputs={fi!r}, freeze_backbone={fb!r}")
    out = {k: torch.zeros(tuple(sh), dtype=torch.bool) for k, sh in shapes.items()}
    if fi == "shortcut":
        out[wk[0]][:, sc] = True
    if fb == "downstream":
        for k in (*wk[1:], *bk[1:]):
            out[k][...] = True
    return out


def adam_last_update(opt: dict, names: list, shapes: dict) -> tuple:
    """the last AdamW step of every optimized tensor, from a saved optimizer state_dict, before any hold is applied.
    -> ({parameter name: update, float64}, {name: second moment > 0}, the learning rate of that step).
    A tensor with no state (never stepped) has a zero update.  Weight decay, amsgrad and maximize are refused."""
    out, moved, lrs = {}, {}, set()
    seen = 0
    for gp in opt["param_groups"]:
        if float(gp.get("weight_decay", 0.0)) != 0.0 or gp.get("amsgrad") or gp.get("maximize"):
            raise Fail("the last update is reconstructed for AdamW without weight decay, amsgrad or maximize only")
        if "betas" not in gp:
            raise Fail("the optimizer state is not Adam's (no betas)")
        b1, b2 = (float(x) for x in gp["betas"])
        lr, eps = float(gp["lr"]), float(gp["eps"])
        lrs.add(lr)
        for idx in gp["params"]:
            if idx >= len(names):
                raise Fail("the optimizer state has more tensors than recorded parameter names")
            name = names[idx]
            seen += 1
            st = opt["state"].get(idx) or {}
            if "exp_avg" not in st:
                out[name] = torch.zeros(shapes[name], dtype=torch.float64)
                moved[name] = torch.zeros(shapes[name], dtype=torch.bool)
                continue
            t = float(st["step"])
            m, v = st["exp_avg"].double().cpu(), st["exp_avg_sq"].double().cpu()
            if tuple(m.shape) != tuple(shapes[name]) or t < 1:
                raise Fail(f"optimizer state of {name}: wrong shape or no step")
            out[name] = -(lr / (1.0 - b1 ** t)) * m / (v.sqrt() / math.sqrt(1.0 - b2 ** t) + eps)
            moved[name] = v > 0
    if seen != len(names):
        raise Fail(f"the optimizer state holds {seen} tensors, the recorded names {len(names)}")
    if len(lrs) != 1:
        raise Fail("the parameter groups ran at different learning rates")
    return out, moved, lrs.pop()


def cos(a, b):
    den = float(a.norm()) * float(b.norm())
    return float((a * b).sum()) / den if den > 0 else None


def flat(d: dict, picks: list):
    """picks: [(name, column index tensor or None)] -> one float64 vector."""
    return torch.cat([(d[n] if cols is None else d[n][:, cols]).reshape(-1).double() for n, cols in picks])


def full_grad(g, X, y, ctx, chunk: int) -> tuple:
    """-> (mean loss over the examples, {parameter name: gradient}) with one forward-backward per chunk."""
    g.zero_grad(set_to_none=True)
    n, total = y.shape[0], 0.0
    for i0 in range(0, n, chunk):
        c = None if ctx is None else {**{k: v for k, v in ctx.items() if k != "grad_masks"},
                                      "grad_masks": {k: m[i0:i0 + chunk] for k, m in ctx["grad_masks"].items()}}
        out = g({k: t[i0:i0 + chunk] for k, t in X.items()}, c)
        loss = torch.nn.functional.cross_entropy(out, y[i0:i0 + chunk], reduction="sum") / n
        loss.backward()
        total += float(loss.detach())
    grads = {k: (p.grad.detach().double().cpu() if p.grad is not None else torch.zeros(p.shape, dtype=torch.float64))
             for k, p in g.named_parameters()}
    g.zero_grad(set_to_none=True)
    return total, grads


def close(a: dict, b: dict, names, tol: float) -> float:
    """max |a - b| over the named tensors relative to the larger gradient's max |.|; -> that ratio."""
    num = max((float((a[n] - b[n]).abs().max()) for n in names), default=0.0)
    den = max((max(float(a[n].abs().max()), float(b[n].abs().max())) for n in names), default=0.0)
    return 0.0 if num == 0 else num / max(den, 1e-300)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("results")
    ap.add_argument("out")
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--strict", action="store_true", help="exit 1 unless every f0 is analysed")
    a = ap.parse_args(argv)
    dev = torch.device(a.device)
    if dev.type == "cuda" and not torch.cuda.is_available():
        print("--device cuda requested but CUDA is not available", file=sys.stderr)
        return 2
    numerics = CE.numerics_policy(dev)
    cov = {"tool": "routing_updates", "analysis_schema": ANALYSIS_SCHEMA, "status": STATUS,
           "results": str(Path(a.results).resolve()), "manifest": a.manifest,
           "manifest_sha256": CE.sha256_file(a.manifest),
           "source_sha256": {p.name: CE.sha256_file(p) for p in (Path(__file__), Path(FP.__file__), Path(CC.__file__),
                                                                 Path(CE.__file__), Path(SR.__file__))},
           "numerics": numerics, "definitions": {"groups": list(GROUPS), "grad_tol": GRAD_TOL,
                                                 "value_tol": VALUE_TOL},
           "expected_f0": 0, "analysed_f0": 0, "failed": []}
    out = defaultdict(list)
    want = {}
    try:
        P = FP.open_panel(a.results, a.manifest)
    except Fail as ex_:
        cov["failed"].append({"f0": None, "reason": str(ex_)})
        print(f"FAIL: {ex_}", file=sys.stderr)
        P = None
    jobs = {} if P is None else P.jobs
    cov["expected_f0"] = len(jobs)
    if P is not None:
        cov["design"] = {"expansions": P.exp_lev, "expansion_updates": P.fork_u}
    bundles = {}
    for n_done, bid in enumerate(sorted(jobs), 1):
        staged = defaultdict(list)
        try:
            F = FP.open_f0(P, bid, a.data_root, dev, bundles)
            wk, bk, L = F.wk, F.bk, F.L
            Xtr = {"x": F.parts["train"].X["x"].to(dev)}
            ytr = F.parts["train"].y.to(dev).long()
            N = int(ytr.shape[0])
            n_ck = 0
            for v in sorted(F.J["exp"]):
                rid, tid = F.J["exp"][v]
                gcfg = F.cfgs[tid].get("growth") or {}
                mode = gcfg.get("spec_partition", "auto")
                route = gcfg.get("spec_mask_route", "gradient")
                if route not in ("gradient", "parameter") or \
                        ((gcfg.get("spec_reassign") or {}).get("mode", "none") != "none"):
                    raise Fail(f"{v}: only the gradient and parameter mask routes with a fixed split are supported")
                flags = {"mask_param_only": True} if route == "parameter" else {}
                if mode == "random_matched":
                    fp = F.runs / tid / "spec_partition.pt"
                    if not fp.exists():
                        raise Fail(f"{v}: the trajectory's saved split (spec_partition.pt) is missing")
                    ind = torch.load(fp, map_location="cpu", weights_only=False).long()
                    if tuple(ind.shape) != (N,) or not bool(((ind == 0) | (ind == 1)).all()):
                        raise Fail(f"{v}: the saved split does not index the training set")
                    ma = ind.to(dev).float()
                    masks = {"spec_a": ma, "spec_b": 1.0 - ma}
                elif mode == "all_examples":
                    masks = {"spec_a": torch.ones(N, device=dev), "spec_b": torch.ones(N, device=dev)}
                else:
                    raise Fail(f"{v}: growth.spec_partition={mode} is not supported here")
                ones = {k: torch.ones(N, device=dev) for k in masks}
                lev = P.exp_lev[v]
                for stage, upd, ck in FP.expansion_states(P, F, v):
                    if stage.startswith("post_insert"):
                        continue                              # no update of the inserted parameters yet
                    what = f"{v} {stage}"
                    tr = ck.get("trainer") or {}
                    if not tr.get("opt") or not tr.get("opt_param_names"):
                        raise Fail(f"{what}: the checkpoint carries no optimizer state")
                    g = GraphNet.from_checkpoint(ck["model"], dev).eval()
                    if g.gate_vals or any(g.nodes[n].op in ("bn", "ln") for n in g.live_nodes()):
                        raise Fail(f"{what}: gates or normalisation layers are not supported")
                    params = dict(g.named_parameters())
                    names = [f"mods.{n}" for n in tr["opt_param_names"]]
                    if any(n not in params for n in names) or len(set(names)) != len(names):
                        raise Fail(f"{what}: the optimizer's parameter names do not match the model")
                    theta = {k: p.detach().double().cpu() for k, p in params.items()}
                    upd_, _, lr = adam_last_update(tr["opt"], names, {n: params[n].shape for n in names})
                    held = held_masks(F.cfgs[tid], {k: p.shape for k, p in params.items()}, wk, bk, F.sc)
                    for k in params:
                        if k not in upd_:                     # a tensor outside the optimizer did not move
                            upd_[k] = torch.zeros(params[k].shape, dtype=torch.float64)
                            held[k][...] = True
                        upd_[k] = upd_[k] * (~held[k]).double()      # the trainer restores held coordinates
                    prev = {k: theta[k] - upd_[k] for k in params}
                    sites = FP.layer_sites(g, L)
                    merges = [n for n in sites if n.endswith("_post_merge")]
                    if len(merges) != 1:
                        raise Fail(f"{what}: needs exactly one merge on the backbone")
                    c = int(merges[0][len("layer"):-len("_post_merge")])
                    with torch.no_grad():
                        loss_after = float(torch.nn.functional.cross_entropy(g(Xtr), ytr))
                        for k, p in params.items():
                            p.copy_(prev[k].to(p.dtype))
                    l_ord, g_ord = full_grad(g, Xtr, ytr, None, F.batch)
                    l_rt, g_rt = full_grad(g, Xtr, ytr, {"grad_masks": masks, **flags}, F.batch)
                    l_one, g_one = full_grad(g, Xtr, ytr, {"grad_masks": ones, **flags}, F.batch)
                    # ---- checks
                    if abs(l_rt - l_ord) > VALUE_TOL * max(1.0, abs(l_ord)):
                        raise Fail(f"{what}: the routed forward value differs from the ordinary one")
                    after = [k_ for i in range(c, len(L)) for k_ in (wk[i], bk[i])]
                    d_after = close(g_rt, g_ord, after, GRAD_TOL)
                    d_ones = close(g_one, g_ord, list(params), GRAD_TOL)
                    if d_after > GRAD_TOL:
                        raise Fail(f"{what}: routing changed the gradient of the backbone after the merge "
                                   f"({d_after:.2e})")
                    if d_ones > GRAD_TOL:
                        raise Fail(f"{what}: masks of ones do not reproduce the ordinary gradient ({d_ones:.2e})")
                    d_all = close(g_rt, g_ord, list(params), GRAD_TOL)
                    if mode == "all_examples" and d_all > GRAD_TOL:
                        raise Fail(f"{what}: an all-examples arm's routed gradient is not its ordinary gradient")
                    d_bb = close(g_rt, g_ord, [*wk, *bk], GRAD_TOL)
                    if route == "parameter" and d_bb > GRAD_TOL:
                        raise Fail(f"{what}: the parameter route changed the backbone's gradient ({d_bb:.2e})")
                    # ---- groups: [(name, columns or None)]
                    backbone = set(wk) | set(bk)
                    blk = {k_: i.cpu() for k_, i in F.blk.items()}
                    groups = {
                        "first_layer": [(wk[0], None), (bk[0], None)],
                        "first_layer_causal": [(wk[0], blk["causal"])],
                        "first_layer_shortcut": [(wk[0], blk["shortcut"])],
                        "first_layer_other": [(wk[0], blk["other"])],
                        "backbone_to_merge": [(k_, None) for i in range(c) for k_ in (wk[i], bk[i])],
                        "backbone_after_merge": [(k_, None) for k_ in after],
                        "additions": [(k_, None) for k_ in sorted(params) if k_ not in backbone],
                        "all": [(k_, None) for k_ in sorted(params)]}
                    if not groups["additions"]:
                        raise Fail(f"{what}: the state has no addition parameters")
                    mv = {k: (~held[k]).double() for k in params}
                    go = {k: g_ord[k] * mv[k] for k in params}       # on the coordinates that are free to move
                    gr = {k: g_rt[k] * mv[k] for k in params}
                    unm = {k: g_ord[k] * (1.0 - mv[k]) for k in params}
                    cmeta = {**F.meta, "variant": v, "stage": stage, "updates_since_f0": upd,
                             "hold": lev["hold"], "route": lev["route"], "mask_route": route, "act": lev["act"],
                             "arm_lr": lev["lr"]}
                    pred_o = float(sum((g_ord[k] * upd_[k]).sum() for k in params))
                    pred_r = float(sum((g_rt[k] * upd_[k]).sum() for k in params))
                    staged["checkpoints"].append({
                        **cmeta, "lr": lr, "merge_after_layer": c, "n_train": N,
                        "train_loss_before": l_ord, "train_loss_after": loss_after,
                        "actual_dloss": loss_after - l_ord, "predicted_dloss_ordinary": pred_o,
                        "remainder_dloss": (loss_after - l_ord) - pred_o, "predicted_dloss_routed": pred_r,
                        "check_routed_value_diff": abs(l_rt - l_ord), "check_after_merge_grad_diff": d_after,
                        "check_ones_mask_grad_diff": d_ones, "routed_vs_ordinary_grad_diff": d_all,
                        "routed_vs_ordinary_backbone_grad_diff": d_bb})
                    for gname in GROUPS:
                        pk = groups[gname]
                        u_, o_, r_ = flat(upd_, pk), flat(go, pk), flat(gr, pk)
                        w0_, w1_ = flat(prev, pk), flat(theta, pk)
                        staged["updates"].append({
                            **cmeta, "group": gname, "n_entries": int(u_.numel()),
                            "free_fraction": float(flat(mv, pk).mean()),
                            "update_norm": float(u_.norm()), "ordinary_grad_norm": float(o_.norm()),
                            "routed_grad_norm": float(r_.norm()),
                            "ordinary_grad_norm_on_held": float(flat(unm, pk).norm()),
                            "cos_ordinary_routed": cos(o_, r_), "cos_descent_ordinary": cos(-u_, o_),
                            "cos_descent_routed": cos(-u_, r_),
                            "predicted_dloss_ordinary": float((flat(g_ord, pk) * u_).sum()),
                            "predicted_dloss_routed": float((flat(g_rt, pk) * u_).sum()),
                            "weight_norm_before": float(w0_.norm()), "weight_norm_after": float(w1_.norm()),
                            "weight_norm_change": float(w1_.norm()) - float(w0_.norm()),
                            "radial_cos_update": cos(u_, w0_), "radial_cos_minus_ordinary": cos(-o_, w0_),
                            "radial_cos_minus_routed": cos(-r_, w0_)})
                    n_ck += 1
            if n_ck == 0:
                raise Fail(f"f0 {bid}: no saved state with an optimizer state")
            want[bid] = n_ck
            for k_, rows_ in staged.items():
                out[k_].extend(rows_)
            cov["analysed_f0"] += 1
            print(f"f0 {n_done}/{len(jobs)} analysed ({n_ck} states)", flush=True)
        except Fail as ex_:
            cov["failed"].append({"f0": bid, "reason": str(ex_)})
            print(f"FAIL f0 {bid}: {ex_}", file=sys.stderr)

    Pfx = a.out
    for t_ in ("checkpoints", "updates"):
        SR.atomic_csv(f"{Pfx}_{t_}.csv", out.get(t_, []))

    def long(rows_, keys, metrics):
        return [{**{k: r.get(k) for k in keys + ("data_draw", "optimizer_seed")}, "metric": m, "v": float(r[m])}
                for r in rows_ for m in metrics if r.get(m) is not None]
    for name, keys, metrics in (("checkpoints", CKPT_KEYS, CKPT_METRICS), ("updates", UPDATE_KEYS, UPDATE_METRICS)):
        bd, sm = SR.two_stage(long(out[name], keys, metrics), keys + ("metric",), "v")
        SR.atomic_csv(f"{Pfx}_{name}_by_draw.csv", bd)
        SR.atomic_csv(f"{Pfx}_{name}_summary.csv", sm)
    cnt = defaultdict(int)
    for r in out["checkpoints"]:
        cnt[r["f0"]] += 1
    miss = [f"{bid}: {cnt[bid]} states, expected {n}" for bid, n in want.items() if bid in cnt and cnt[bid] != n]
    if len(out["updates"]) != len(GROUPS) * len(out["checkpoints"]):
        miss.append(f"update rows {len(out['updates'])}, expected {len(GROUPS) * len(out['checkpoints'])}")
    cov["design_ids"] = sorted({r["design_id"] for r in out["checkpoints"]})
    cov["output_membership_failures"] = miss
    cov["n_failed"] = len(cov["failed"])
    cov["n_states"] = len(out["checkpoints"])
    cov["passed"] = cov["n_failed"] == 0 and cov["analysed_f0"] > 0 and not miss and \
        cov["analysed_f0"] == cov["expected_f0"]
    Path(f"{Pfx}_coverage.json").write_text(json.dumps(cov, indent=1, default=str))
    print(json.dumps({k: cov[k] for k in ("expected_f0", "analysed_f0", "n_failed", "n_states", "passed")}))
    return 1 if (a.strict and not cov["passed"]) else 0


if __name__ == "__main__":
    sys.exit(main())
