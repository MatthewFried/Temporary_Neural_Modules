"""v13 runtime estimate for a manifest from MEASURED per-job elapsed seconds of an earlier run on the same machine.

  fit       MANIFEST RESULTS_OR_REPORT OUT.json    per-stratum cost model sec = a + b * work_updates
  estimate  MANIFEST RATES.json [--workers N]       serial / wall hours by kind and block

RESULTS_OR_REPORT is a results root (runs/*/attempts) or a pilot_report.json (its 'jobs' list carries
elapsed_seconds per run id).  work_updates counts every update a job trains, including continuation budgets
resolved from their parents in the manifest (updates_of in cop/orchestration/calibrate.py returns 0 for them),
dissipation removal + repair, CoP global + local phases, and the baseline's own updates; v20: recode jobs count
their nested replacement fits (recode_work) in a stratum of their own.  Strata: (kind, data,
model family), falling back to (kind, model family), then kind.  v13 adds per-job evaluation work (K = 8
validation candidates per compact phase, 20 full path evaluations per removal path, decoder refits, locality
controls) that the v9 timings do not contain: those are priced by OVERHEAD below and reported separately.
A planning estimate, not a bound: re-fit on the re-pilot's own timings before the confirmation run."""
import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from cop.utils import read_jsonl, read_json  # noqa: E402

# seconds per extra full evaluation, as a multiple of one training update (an evaluation pass over ~2-8k
# validation / test examples costs roughly 2-10 updates of batch 128; 6 is a middle value)
EVAL_UPDATES = 6.0


def work_updates(e: dict, ents: dict, memo: dict) -> float:
    rid = e["run_id"]
    if rid in memo:
        return memo[rid]
    c = e["cfg"]
    k = c["kind"]
    u = 0.0
    if k == "baseline":
        u = c["train"]["baseline_updates"]
    elif k == "trajectory":
        g = c["growth"]
        u = g["rounds"] * g["updates_per_round"] if g["compute_schedule"] == "per_round" else g["total_updates"]
    elif k == "dissipation":
        d = c["dissipation"]
        u = d["speed_updates"] + d["post_updates"]
        if d.get("post_match_macs_of"):
            ref = c["parents"].get(d["post_match_macs_of"])
            u = work_updates(ents[ref], ents, memo) if ref in ents else u
    elif k == "repair":
        g = c["growth"]
        u = c["repair"]["budget_multiplier"] * g["rounds"] * g["updates_per_round"]
    elif k == "cop" and (c["cop"].get("task_kind") == "recode"):
        u = recode_work(c["cop"])
    elif k == "cop":
        cc = c["cop"]
        u = cc["global_updates"] + cc["local_updates"] * max(1, cc.get("n_pearls", 2))
        if cc.get("task_kind") == "cycles":
            u = (cc["global_updates"] + cc["local_updates"]) * max(1, cc.get("cycles", 2))
        if cc.get("task_kind") == "locality":
            u += 4 * 3 * cc.get("locality_repair_updates", 0) + 3 * cc.get("locality_repair_updates", 0)
        u += cc.get("decoder_refit_updates", 0) or 0
    elif k == "continue":
        cc = c["continue"]
        par = c["parents"].get(cc.get("budget_parent") or "treated")
        if cc["budget"] == "fixed":
            u = cc.get("updates", 0) or sum(cc.get("segments") or [])
        elif par in ents:
            u = work_updates(ents[par], ents, memo)
            if cc.get("budget_add_f0") and c["parents"].get("baseline") in ents:
                u += work_updates(ents[c["parents"]["baseline"]], ents, memo)
    elif k == "transplant":
        u = 0.0
    memo[rid] = float(u)
    return float(u)


def recode_fit_counts(cc: dict) -> dict:
    """v20: the nested fit grid of a recode job (cop/cop_pegs/recode.plan_fits): one fit per middle pearl,
    regime, relabelling (and its encoding seeds), side, replacement class and fit seed.  A chain of n pearls has
    n - 1 pegs and n - 2 middle pearls.  Pearls skipped for their message size still count (an upper bound)."""
    from cop.cop_pegs.recode import plan_fits
    n_mid = max(0, int(cc.get("n_pearls", 2)) - 2)
    fits = plan_fits(cc, list(range(1, n_mid + 1)))
    by_class = defaultdict(int)
    for f in fits:
        by_class[f["class"]] += 1
    return {"fits": len(fits), "by_class": dict(by_class), "updates_per_fit": int(cc["recode_updates"])}


def recode_work(cc: dict) -> float:
    """v20: recode work in fit-update units: every fit's full-batch updates weighted by its replacement class
    (linear 1, an MLP of width h: 1 + h / 16; the support is at most the 2^bits alphabet of the same peg in
    every job of a stratum, so it enters the per-stratum rate) plus one evaluation of the support per
    evaluation point.  Recode jobs have their own stratum (kind cop:recode); the rate comes from measured jobs."""
    n = recode_fit_counts(cc)
    U, every = int(cc["recode_updates"]), max(1, int(cc["recode_eval_every"]))
    w = 0.0
    for cls, k in n["by_class"].items():
        f = 1.0 if cls == "linear" else 1.0 + int(cls[3:]) / 16.0
        w += k * (U * f + (U // every + 1) * f)
    return w


def overhead_updates(c: dict) -> float:
    """v13 evaluation work that has no counterpart in pre-v13 timings, in update-equivalents."""
    k = c["kind"]
    t = c.get("train") or {}
    o = EVAL_UPDATES * int(t.get("select_candidates", 0) or 0)
    if k == "dissipation":
        d = c["dissipation"]
        if d.get("path_full_eval"):
            o += EVAL_UPDATES * int(d.get("path_eval_points", 0))
    if k == "trajectory" and (c.get("growth") or {}).get("topology") == "specialized":
        o += EVAL_UPDATES
    return o


def strata(c):
    k = c["kind"]
    if k == "cop" and (c.get("cop") or {}).get("task_kind") == "recode":
        k = "cop:recode"                 # v20: recode jobs fit replacements, not chains: their own stratum
    return ((k, c["data"]["name"], c["model"]["family"]), (k, c["model"]["family"]), (k,))


def _elapsed(src: Path) -> dict:
    if src.is_file():
        return {j["run_id"]: float(j.get("elapsed_seconds") or 0) for j in read_json(src)["jobs"]
                if j.get("elapsed_seconds") is not None}
    out = {}
    for rd in (src / "runs").glob("*"):
        st = rd / "status.json"
        if not st.exists() or read_json(st).get("status") != "complete":
            continue
        s = sum(float(read_json(p).get("elapsed_seconds") or 0) for p in (rd / "attempts").glob("*.json"))
        out[rd.name] = s
    return out


def _fit(pts):
    """least squares sec = a + b u with a, b >= 0 (falls back to a pure rate)."""
    n = len(pts)
    su = sum(u for u, _ in pts)
    ss = sum(s for _, s in pts)
    if n >= 3:
        mu, ms = su / n, ss / n
        var = sum((u - mu) ** 2 for u, _ in pts)
        if var > 0:
            b = sum((u - mu) * (s - ms) for u, s in pts) / var
            a = ms - b * mu
            if a >= 0 and b >= 0:
                return {"a": a, "b": b, "n": n, "model": "a+b*u"}
    return {"a": 0.0, "b": ss / max(su, 1e-9), "n": n, "model": "rate"} if su > 0 else \
        {"a": ss / max(n, 1), "b": 0.0, "n": n, "model": "constant"}


def _fit_pairs(pairs, out):
    """pairs: [(manifest, timings)]; every measured job of every pair enters one per-stratum fit (v17: the
    re-pilot and the control panel together, so strata measured only in the panel are priced from it)."""
    groups = [defaultdict(list) for _ in range(3)]
    n_timed = 0
    for manifest, timings in pairs:
        ents = {e["run_id"]: e for e in read_jsonl(manifest)}
        el = _elapsed(Path(timings))
        memo = {}
        for rid, s in el.items():
            if rid not in ents:
                continue
            n_timed += 1
            c = ents[rid]["cfg"]
            u = work_updates(ents[rid], ents, memo)
            for i, k in enumerate(strata(c)):
                groups[i]["|".join(map(str, k))].append((u, s))
    rates = {f"level{i}": {k: _fit(v) for k, v in g.items()} for i, g in enumerate(groups)}
    json.dump({"source": [str(t) for _, t in pairs], "manifest": [str(m) for m, _ in pairs], "n_jobs": n_timed,
               "rates": rates, "eval_update_equivalent": EVAL_UPDATES}, open(out, "w"), indent=1)
    print(json.dumps({"n_jobs_timed": n_timed, "strata": {k: len(v) for k, v in rates.items()}}))


def cmd_fit(a):
    _fit_pairs([(a.manifest, a.timings)], a.out)


def cmd_fitmany(a):
    if not a.pair:
        raise SystemExit("give at least one --pair MANIFEST TIMINGS")
    _fit_pairs([tuple(p) for p in a.pair], a.out)


def cmd_estimate(a):
    R = read_json(a.rates)
    rates = R["rates"]
    ents_l = read_jsonl(a.manifest)
    ents = {e["run_id"]: e for e in ents_l}
    memo = {}
    est, by_kind, by_block, ovh, level, missing = {}, defaultdict(float), defaultdict(float), 0.0, defaultdict(int), set()
    for e in ents_l:
        c = e["cfg"]
        u = work_updates(e, ents, memo)
        o = overhead_updates(c)
        f = None
        for i, k in enumerate(strata(c)):
            f = rates[f"level{i}"].get("|".join(map(str, k)))
            if f:
                level[i] += 1
                break
        if f is None:
            missing.add(strata(c)[0])
            level["unmeasured"] += 1
            est[e["run_id"]] = 0.0
            continue
        s = f["a"] + f["b"] * u
        so = f["b"] * o if f["b"] > 0 else 0.0
        est[e["run_id"]] = s + so
        ovh += so
        by_kind[c["kind"]] += s + so
        by_block[e["blocks"][0]] += s + so
    cp = {}
    for e in ents_l:
        cp[e["run_id"]] = est[e["run_id"]] + max([cp.get(d, 0.0) for d in e["deps"]] or [0.0])
    serial = sum(est.values())
    wall = max(serial / a.workers, max(cp.values() or [0]))
    res = {"manifest": a.manifest, "jobs": len(ents_l), "workers": a.workers,
           "serial_hours": round(serial / 3600, 2), "wall_hours": round(wall / 3600, 2),
           "of_which_v13_evaluation_overhead_hours": round(ovh / 3600, 2),
           "critical_path_hours": round(max(cp.values() or [0]) / 3600, 3),
           "hours_by_kind": {k: round(v / 3600, 2) for k, v in sorted(by_kind.items())},
           "hours_by_block": {k: round(v / 3600, 2) for k, v in sorted(by_block.items())},
           "fit_level_counts": {str(k): v for k, v in level.items()},
           "unmeasured_strata": sorted(map(list, missing)),
           "rates_from": R.get("source"),
           "note": "per-stratum fit of measured elapsed seconds against trained updates; v13 evaluation work priced "
                   f"at {R.get('eval_update_equivalent')} update-equivalents per evaluation; concurrent workers "
                   "share one GPU, so wall time with N > 1 workers is optimistic; a planning estimate, not a bound"}
    if a.out:
        json.dump(res, open(a.out, "w"), indent=1)
    print(json.dumps(res, indent=1))


ap = argparse.ArgumentParser()
sub = ap.add_subparsers(dest="cmd", required=True)
s = sub.add_parser("fit")
s.add_argument("manifest")
s.add_argument("timings")
s.add_argument("out")
s.set_defaults(f=cmd_fit)
s = sub.add_parser("fitmany")
s.add_argument("out")
s.add_argument("--pair", nargs=2, action="append", metavar=("MANIFEST", "TIMINGS"))
s.set_defaults(f=cmd_fitmany)
s = sub.add_parser("estimate")
s.add_argument("manifest")
s.add_argument("rates")
s.add_argument("--workers", type=int, default=1)
s.add_argument("--out", default=None)
s.set_defaults(f=cmd_estimate)
a = ap.parse_args()
a.f(a)
