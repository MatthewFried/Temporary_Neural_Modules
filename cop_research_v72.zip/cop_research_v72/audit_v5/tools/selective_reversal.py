"""Layer transplants and selective reversal WITHOUT retraining (read-only; trains nothing).

  python audit_v5/tools/selective_reversal.py RESULTS OUT_PREFIX [--manifest M --strict] [--data-root DIR]
         [--device cpu] [--codes auto|all|LIST] [--trace [--trace-codes auto|all|LIST] [--codes-at-2u]]
         [--implant-codes] [--decompose [--cross] [--scale-controls]] [--grid] [--limit N]

Operation.  The additions are deleted and each backbone layer i is set to (1 - a_i) x its value + a_i x its f0
value (a = 0 keeps the state's layer, a = 1 restores f0's): `0-1-1-1-1` puts the state's first layer alone into an
otherwise untouched f0.  Nothing is trained; every evaluation is in eval mode.  The only fitted quantities are the
two scale-selected rescaling controls' one or two scale factors, chosen on the selection partition (val_indep, never
test) over a fixed grid.

v41.  One arithmetic path for every first-layer component edit (the decomposition, the cross, the rescaling controls
and the component trace): W0 + (the selected generator-coordinate column changes) @ Q, the state's own W when every
group comes from that state.  Identities checked in every job: the empty subset is f0 and the full subset is the
first-layer transplant (bitwise); causal_transplant is the decomposition's causal subset, cross after/after/f0 its
shortcut+causal subset and after/after/after its full subset (bitwise, same state); cross before/before/f0 is the
abrupt state's shortcut+causal subset (bitwise, else max |diff| <= 1e-5 with identical decisions: another compact
graph object of the same checkpoint).  --preflight checks a results folder (configs, states, saved predictions, trace
checkpoints) without evaluating.

Population.  With --manifest, the expected jobs are the manifest's eligible jobs (below); without it, the complete
job folders found (exploratory use only; --limit only there).  Eligible: removal jobs of families PE / X25 with the
task target, all repair data, no warmup, no hybrid (variants: full linear removal; abrupt; keep / keep_frozen;
restricted repair scopes; restored repairs; phase-matched forks; holds; rebuilt starts), and the controls C1, C2,
C1_phase, C1_first, C1_first_window, C1_disturbed.  Required per job: the config on disk equal to the manifest's;
status complete; a valid endpoint (endpoint.json not diverged, not recorded numerically invalid); data provenance
(v34: a logged hash for train and EVERY evaluated partition, each equal to the regenerated one; none logged is a
failure); every required state, each checkpoint with its recorded lineage (run, stage), parameter and graph hashes
recomputed and equal, finite tensors and recorded data hashes equal; every declared code; with --decompose all 16
update subsets (shortcut data); with --trace every checkpoint of the CONFIG-derived inventory (v34: the job's phase
and event ledger must equal the one its config implies; a missing ledger fails).  Rows of a job
are committed only when all of its required analyses pass; otherwise they go to _diagnostic_partial.csv (never into
a summary) and the job is a coverage failure.  --strict exits 1 on any coverage failure.

States.  full linear removal: abrupt (the trajectory end, additions deleted), after_transition (end of the gate
anneal), repaired (the exported endpoint).  abrupt / restricted / restored / phase-matched abrupt: repaired.  keep:
kept_end (the native expanded endpoint; transplants use its branch-deleted backbone).  Controls: <arm>_final.
`function` in every row: native (a compact state, nothing restored), branch_deleted (a state with additions,
nothing restored), layer_transplant (any restoration).

Audits (_checks.csv; each must pass):
  native_reload          the job's endpoint checkpoint, unedited, reproduces the job's saved endpoint predictions
                         (bitwise when analysed on the recorded training device type; otherwise max |diff| <= 1e-4 x
                         max(1, max |ref|) and identical decisions; a missing or mis-shaped reference fails)
  compaction             branch deletion succeeds (a gated graph: gates at 0, then export, then the same function
                         within 1e-5); the compact backbone has f0's layers in f0's order
  zero_code_identity     reloading the unedited compact state through the transplant machinery leaves its
                         predictions bitwise unchanged
  full_restore_identity  restoring every layer reproduces f0's predictions bitwise
  decomposition          (--decompose) the feature groups are disjoint and cover every input coordinate; the empty
                         subset reproduces f0 and the full subset (assigned exactly) reproduces the first-layer
                         transplant, bitwise; the rotation round-trip residual is reported

Inventory (v41, per job, before any row is committed): codes x states, one native row per endpoint, 16 decomposition
rows per state, 8 rescaling rows per state (v42; 6 before), 8 cross rows per eligible endpoint, 5 component-trace
rows per trace checkpoint, one displacement row per own trace checkpoint plus the endpoint (v42); unique keys;
finite values.  v42: in a lineage that holds the first layer's shortcut column at f0 (train.freeze_inputs on the job
and, for a removal, its trajectory) every state's shortcut-column change must be exactly zero, else the job fails.  Cross exclusions (rebuilt starts; a start other than the trajectory's final
checkpoint) and data without a shortcut layout are listed in the coverage.

Outputs (each written atomically and always replaced; an empty table is written as a file holding `empty`):
  _codes.csv / _codes_by_setting.csv / _codes_by_draw.csv / _codes_summary.csv
      per run; partition seeds averaged within (draw, optimizer setting); settings averaged within each data draw;
      summary over UNIQUE data draws (n_unique_data_draws, settings per draw, mean gain vs f0 with a draw-level t
      interval, draws beating f0)
  _contrasts.csv     (v43: per C1 variant, reference_variant / _arm / _state / _run_ids on every row; a duplicated
                     reference or a missing partner the design holds fails coverage)
                     paired differences of each group against the same code on C1's final state, matched on the
                     data draw and the optimizer setting (missing partners flagged, never silently dropped)
  _decomposition*.csv  (--decompose) the first layer's update W - W0 split by generator feature group (shortcut,
                     causal, noise columns of W Q^T) and the bias, all 16 subsets added to f0's first layer
  _cross*.csv        (--cross, v39) in f0's first layer, the causal-column change and the shortcut-column change
                     each taken from the trajectory's end ('before', additions deleted) or from the job's endpoint
                     ('after'), all four crossings, noise and bias at f0 (primary) or from 'after'; every other
                     layer is f0's.  _cross_contrasts.csv: paired contrasts within a job (the shortcut change's
                     effect given each causal origin, the causal change's given each shortcut origin, and their
                     interaction), averaged over settings within each draw, over unique draws.  Removal jobs that
                     start from the trajectory's end only (no rebuilt starts)
  _scale*.csv        (--scale-controls, v39) is the causal-column transplant more than a rescaling of f0's own
                     causal weights?  causal_transplant (= the decomposition's causal row); f0's causal block scaled
                     to the transplant's Frobenius norm, or row by row to its row norms; the transplant's row
                     directions with f0's row norms; f0's causal block scaled by alpha, and by (alpha_causal,
                     alpha_shortcut), both chosen on val_indep (never test).  Each row records the norm ratio and the
                     norm-weighted row cosine between f0's causal block and the transplant's
  _trace.csv         (--trace) declared codes at every checkpoint of the inventory (trajectory insertions, v41 its
                     configured snapshots, and its end; the edit-event checkpoints; the removal's dense early repair
                     path checkpoints and, v41, each phase's last update when the path schedule saved it; controls'
                     at_<u> checkpoints for the declared eval_at), with the checkpoint file, phase and update; shared
                     trajectory histories once
  _decomposition_trace.csv  (v41, --trace --decompose) at every trace checkpoint: none, causal, shortcut,
                     shortcut+causal and the full first-layer change (incl. bias), the decomposition's arithmetic
  _native*.csv       (v41) the unedited endpoints (e.g. a kept model with its additions)
  _decomposition_contrasts*.csv  (v41, --decompose) each arm's component rows against C1's same components (same
                     draw and optimizer seed; C1 shared, not replicated; a missing partner fails strict coverage) and
                     the fixed against the redrawn variant (reported, unpaired rows counted)
  _cross_contrasts_by_draw.csv  (v41) the cross contrasts per data draw
  _scale_contrasts*.csv  (v41) each rescaling control minus the causal transplant, same job and state (positive =
                     the transplant has the lower test error); grid-edge selections and zero-norm rows are counted
                     in the coverage
  _displacement*.csv  (v42, --trace --displacement) each job's NET parameter movement from a reference state (the
                     trajectory checkpoint it forked from; f0 for a compact control; v43: also a compact control's
                     own state at 2U) at its own trace checkpoints and endpoint: backbone, first layer and its
                     causal / shortcut / noise columns, additions ('deleted or not applicable' after a deletion).
                     Net movement is not update size; v43 jobs with train.log_update_norms add the PATH length
                     (sum of update norms) since the reference
  _registry_by_setting / _by_draw / _summary.csv  (v43, --contrasts NAME) the declared contrasts (REGISTRIES):
                     value = err(B) - err(A), positive = A has the lower test error; endpoint, time-matched (2U)
                     and within-job pairs; every arm named must be in the manifest and every pair it holds present
  _compact_fork_audit.csv  (v43) the compact controls' records at each segment start (model, optimizer by name,
                     sampler, RNG, minibatch stream) and at their end; one prefix must agree at 2U and draw the
                     same minibatches throughout
  _scale_metrics_by_draw / _summary.csv, _scale_vectors.csv  (v43) every agreement / fit / norm metric of the
                     rescaling controls aggregated over settings and draws; the per-unit fitted scales
  _native_contrasts_by_setting / _by_draw.csv  (v43) the native endpoints against C1 per reference variant and in
                     the variant pairs
  _native_contrasts.csv  (v42) the variant pairs (fixed vs redrawn, fixed vs fixed_scfrozen, compact vs
                     compact_scfrozen) on the native endpoints; the same pairs on the components are in
                     _decomposition_contrasts*.csv, and C1 there is matched per C1 variant
  _fork_audit.csv, _continuation_factorial_by_setting / _by_draw / _summary.csv  (v41) the keep continuation's
                     2x2 (masks retained / released x optimizer carried / reset), paired within the forks of one
                     parent (same draw, seed, partition, update): reset_vs_carry | masks M = err(M, carried) -
                     err(M, reset); release_vs_retain | optimizer O = err(retained, O) - err(released, O); interaction
                     = (reset_vs_carry | released) - (reset_vs_carry | retained); positive = the named change lowers
                     test error.  Measures: native endpoint, branch-deleted, first layer alone in f0, causal, shortcut
                     and both column changes alone in f0, at the endpoint and at every traced fork checkpoint.  The
                     forks of one parent must share the start state, the minibatch stream, the update count and the
                     learning rate (carried forks the parent's optimizer state at the start, reset forks none,
                     retained-mask forks the same split and gradient eligibility that follows it); any failure, a
                     missing partner the design holds or a duplicate fails strict coverage
  _grid.csv          (--grid, exploratory) every {0, 0.5, 1} mixture
  _checks.csv, _coverage.json, _diagnostic_partial.csv
v44.  --codes all evaluates every keep / restore combination (2^K; the full contraction map, exploratory);
--trace-codes sets the trace checkpoints' codes separately (auto by default) and --codes-at-2u uses the --codes set
at the end of the expansion (the trajectory's end and the compact controls' at_2U).  --implant-codes adds
_codes_implants*.csv: on every state that has additions, the codes with the additions PRESENT (the raw graph, gates as
recorded, backbone layers mixed toward f0 by the same arithmetic; the zero code reproduces the state, an endpoint its
native function, bitwise) and _codes_implants_contrasts*.csv, present minus deleted for the same job, state and code.
The rescaling controls add f0_causal_plus_residual: the learned causal block C1 split as s * C0 + Res with s the
signed per-row least-squares fit, evaluated as C0 + Res (scaling only is f0_causal_row_ls_fit, both together the
transplant; checked to add up), with the residual's energy share |Res|^2 / |C1|^2 and |Res| / |C1 - C0| on every
row.  train.freeze_backbone=downstream: in a lineage that holds layers 2..K at f0 every such state must equal f0
there exactly (the abrupt state follows its trajectory), else the job fails; downstream_change_max_abs is reported.
The wave-24 registry adds 'cross_measure' contrasts (two named measures of two arms, e.g. the extraction rule,
code 0-1-1-1-1 on the abrupt state, against the repaired native endpoint, the expanded network, f0, the compact
extraction at 2U, the compact endpoint and the oracle rescaling controls).
v45.  Every binary keep / restore code is verified as loaded: a restored layer's tensors (weights and biases) are
f0's, a kept layer's the state's, every other tensor unchanged, bitwise; the deletion must leave no live addition
and must not alter the first layer.  _compute*.csv: the training cost since f0 of every named state (and every trace
row): updates, the trainer's 3 x forward estimate and its backward-aware estimate in parts (forward, input
gradient, parameter gradient computed, the part a parameter hold discards, the part used); an analytic estimate
over linear-type nodes, elementwise work not counted.  --paired-streams: within one f0 and seed the trajectories
must share the audited minibatch stream (train.audit_batches), insertion initialization and configuration apart
from their holds, and the compact controls' stream at 2U must equal theirs (_paired_streams.csv; any break fails
the run).  --save-extractions DIR saves each 2U extraction (and the expansion's with additions present), reloaded
and checked.  _extraction_2u*.csv: the five models at 2U (expanded with additions, trained backbone without,
the extraction, the extraction with additions, f0) for every expansion and compact control, with cost.  The
rescaling controls add, from the per-row split w = a * w0 + r (reconstruction and orthogonality checked):
f0_causal_dir_at_norm_of_plus_residual (f0's directions at the row norms of w0 + r) and
f0_causal_plus_residual_at_f0_norm (w0 + r at f0's row norms); every rescaling row reports its assembled
candidate's own causal-block norms.  The wave-25 registry marks its primary contrasts and adds 'interaction'
contrasts, (err(B1) - err(A1)) - (err(B2) - err(A2)) per draw and seed.
v53.  --paired-vary section.key,... (with --paired-streams): settings in which a design's trajectories differ on
purpose (wave 26: growth.act, growth.spec_partition, train.lr) are left out of the configuration that must be equal
across the trajectories of one f0 and seed; the stream, the insertion initialization and f0 must still be equal.
Compact controls enter the fork-equality audit grouped by their training settings apart from the holds as well
(controls at different learning rates share f0 and the stream, not their states).  The wave-26 registry: one
extraction on every expansion at 2U and on every compact control at 2U and at its endpoint; the route and activation
factors, their interaction, the lower learning rate and the hold; no contrast is primary.  --contrasts needs
--decompose only when the registry pairs first-layer components.
v54.  The wave-26 registry names two primary contrasts, both on the arm that repeats wave 25's B arm on new draws
(B_routed_relu): its extraction against f0 and against the matched compact control's extraction at 2U.  They were
named after the v53 panel was launched and before any wave-26 result was read (DEVIATIONS 289); every other
wave-26 contrast is secondary.  No value changes; the role column and the coverage's primary list do.
Draw roles come from cop.analysis.v13_tables.draw_role (the design's declared role, else the legacy rule)."""
from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
import math
import os
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import torch  # noqa: E402

import audit_common as AC  # noqa: E402
from audit_common import EXTRA_PARTS, Fail, logged_split_hashes, rj  # noqa: E402,F401
from cop.utils import stable_hash  # noqa: E402

from cop.analysis.v13_tables import draw_role  # noqa: E402
from cop.data.registry import load_bundle  # noqa: E402
from cop.graph import edits as E  # noqa: E402
from cop.graph.export import export_compact  # noqa: E402
from cop.graph.graph import GraphNet  # noqa: E402
from cop.graph.accounting import count_macs  # noqa: E402
from cop.train.trainer import evaluate  # noqa: E402

CONTROL_ARMS = ("C1", "C2", "C1_phase", "C1_reset", "C1_first", "C1_first_window", "C1_disturbed", "C1_disturbed_loss")
T95 = {1: 12.706, 2: 4.303, 3: 3.182, 4: 2.776, 5: 2.571, 6: 2.447, 7: 2.365, 8: 2.306, 9: 2.262, 10: 2.228,
       11: 2.201, 12: 2.179, 13: 2.160, 14: 2.145, 15: 2.131, 20: 2.086, 30: 2.042}


def ckp(d: Path, name: str):
    p = d / "ckpt" / f"{name}.pt"
    return torch.load(p, map_location="cpu", weights_only=False) if p.exists() else None


def removal_kind(cfg: dict):
    d = cfg.get("design") or {}
    dc = cfg.get("dissipation") or {}
    rb = dc.get("rebuild") or {}
    if not (cfg.get("kind") == "dissipation" and d.get("family") in ("PE", "X25")
            and dc.get("method") in ("linear", "abrupt", "keep")
            and dc.get("target", "task") == "task" and not dc.get("repair_subset")
            and not (cfg.get("train") or {}).get("warmup") and not (dc.get("hybrid") or {}).get("donor_role")):
        return None
    if rb.get("backbone", "receiver") != "receiver" or rb.get("implants", "receiver") != "receiver":
        # v32: rebuilt start states (trained backbone + fresh additions, f0 + trained additions): repaired only
        return f"rebuild_{rb.get('backbone', 'receiver')}_{rb.get('implants', 'receiver')}"
    if dc["method"] == "linear" and (dc.get("gate_schedule") == "hold" or dc.get("keep_frozen_implants")):
        # v32: the additions stay coupled (gates at 1) for speed_updates, trained or frozen, then go
        return f"hold_{int(dc.get('speed_updates', 0))}" + ("_frozen" if dc.get("keep_frozen_implants") else "")
    pm = "_pm" if int(dc.get("split_updates", 0) or 0) else ""
    # v39: the continuation regime, when not the v30 default (masks released, optimizer reset)
    pm += ("+masks" if dc.get("removal_masks", "released") == "retained" else "") + \
        ("+carry" if dc.get("optimizer_policy", "reset_each_phase") == "carry_from_parent" else "")
    if dc["method"] == "keep":
        return ("keep_frozen" if dc.get("keep_frozen_implants") else "keep") + pm
    sc = dc.get("repair_scope", "full")
    if dc.get("restore_before_repair", "none") != "none":
        return f"{sc}+restored"
    if dc["method"] == "abrupt":
        return ("abrupt" if sc == "full" else f"abrupt_{sc}") + pm
    return sc


def eligible(cfg: dict):
    rk = removal_kind(cfg)
    if rk is not None:
        return "removal", rk
    des = cfg.get("design") or {}
    if cfg.get("kind") == "continue" and des.get("arm") in CONTROL_ARMS and des.get("family") in ("PE", "X25"):
        return "control", "control"
    return None


def code_meaning(c: str, has_implants: bool) -> str:
    al = [float(x) for x in c.split("-")]
    keep = [f"L{i + 1}" for i, x in enumerate(al) if x == 0.0]
    half = [f"L{i + 1}" for i, x in enumerate(al) if 0.0 < x < 1.0]
    if not keep and not half:
        return "f0 (every layer restored)"
    if len(keep) == len(al):
        return "branch-deleted state (nothing restored)" if has_implants else "the state itself (nothing restored)"
    return "state's " + ",".join(keep) + (" + halfway " + ",".join(half) if half else "") + " in f0"


def auto_codes(k: int) -> list[str]:
    out = ["-".join(["0"] * k), "-".join(["1"] * k)]
    out += ["-".join("0" if j == i else "1" for j in range(k)) for i in range(k)]
    out += ["-".join("0" if j in (i, i + 1) else "1" for j in range(k)) for i in range(k - 1)]
    out.append("-".join(["1"] + ["0"] * (k - 1)))
    return list(dict.fromkeys(out))


def all_codes(k: int) -> list[str]:
    """v44: every keep / restore combination of the k backbone layers (2^k codes, 0 = the state's layer)."""
    return ["-".join(map(str, t)) for t in itertools.product((0, 1), repeat=k)]


def code_set(spec: str, k: int) -> list[str]:
    """--codes / --trace-codes: 'auto', 'all' (v44) or a comma-separated list."""
    if spec == "auto":
        return auto_codes(k)
    if spec == "all":
        return all_codes(k)
    return [c for c in spec.split(",") if c]


def parse_code(c: str, k: int) -> tuple:
    try:
        al = tuple(float(x) for x in c.split("-"))
    except ValueError:
        raise Fail(f"declared code {c!r} is not numeric")
    if len(al) != k or not all(math.isfinite(x) and 0.0 <= x <= 1.0 for x in al):
        raise Fail(f"declared code {c!r} does not fit {k} layers with values in [0, 1]")
    return al


def backbone_layers(m: GraphNet) -> list[str]:
    out = []
    for n in m.topo_order(m.live_nodes()):
        nd = m.nodes[n]
        if nd.pkey is not None and nd.owner is None and nd.pkey not in out and \
                any(True for _ in m.mods[nd.pkey].parameters()):
            out.append(nd.pkey)
    return out


def atomic_csv(path: str, rows: list[dict]) -> None:
    tmp = f"{path}.tmp"
    with open(tmp, "w", newline="") as f:
        if rows:
            fields = list(dict.fromkeys(k for r in rows for k in r))
            w = csv.DictWriter(f, fieldnames=fields)
            w.writeheader()
            w.writerows(rows)
        else:
            f.write("empty\n")
    os.replace(tmp, path)


def atomic_json(path: str, obj) -> None:
    tmp = f"{path}.tmp"
    with open(tmp, "w") as f:
        json.dump(obj, f, indent=1, default=str)
    os.replace(tmp, path)


def recorded_device(d: Path) -> str:
    best = None
    for f in (sorted((d / "attempts").glob("*.json")) if (d / "attempts").is_dir() else []):
        try:
            att = rj(f)
        except ValueError:
            continue
        if att.get("status") == "complete":
            best = att
    return str(((best or {}).get("exec") or {}).get("device") or "cpu")


def expected_schedule(cfg: dict):
    """v34: the phases [(name, start update, declared updates)] and ledger events [(event, checkpoint, phase)] a
    removal job of this config logs, derived from the config alone (joint order, no MAC matching; the methods
    selective_reversal analyses: linear (incl. hold), abrupt, keep, with split_updates and restore_before_repair)."""
    dc = cfg["dissipation"]
    if dc.get("order", "joint") != "joint" or dc.get("post_match_macs_of"):
        raise Fail("trace: no config-derived schedule for this removal (joint order without MAC matching only)")
    m, P = dc["method"], int(dc["post_updates"])
    S_ = int(dc.get("speed_updates", 0) or 0)
    sp = int(dc.get("split_updates", 0) or 0)
    restore = dc.get("restore_before_repair", "none") == "all_but_first"
    phases, events = [], []

    def ph(name, n):
        if n <= 0:
            return
        phases.append((name, sum(x[2] for x in phases), int(n)))
        events.append(("optimizer_reset", None, name))
        if restore and name.startswith(("post_", "recover_")) and not any(e[0] == "restore_before" for e in events):
            events.extend([("restore_before", "event_restore_before", None), ("restore_after", "event_restore_after",
                                                                               None)])
    if m == "linear":
        ph("anneal_0", S_)
        events.append(("physical_deletion", "event_deleted_0", None))
        ph("post_0", P)
    elif m == "abrupt":
        events.append(("physical_deletion", "event_deleted_0", None))
        if sp and 0 < sp < P:
            ph("recover_0", sp)
            ph("recover_0b", P - sp)
        else:
            ph("recover_0", P)
    elif m == "keep":
        if sp and 0 < sp < P:
            ph("keep_0", sp)
            ph("keep_1", P - sp)
        else:
            ph("keep_0", P)
            if dc.get("optimizer_policy", "reset_each_phase") == "carry_from_parent":
                events.append(("optimizer_carried", None, "keep_0"))      # v39
    else:
        raise Fail(f"trace: no config-derived schedule for method {m}")
    return phases, events


CROSS_CONTRASTS = (      # v39: (name, [(sign, causal_from, shortcut_from)]) on test error, noise and bias held fixed
    ("shortcut_after_vs_before | causal before", [(+1, "before", "before"), (-1, "before", "after")]),
    ("causal_after_vs_before | shortcut before", [(+1, "before", "before"), (-1, "after", "before")]),
    ("shortcut_after_vs_before | causal after", [(+1, "after", "before"), (-1, "after", "after")]),
    ("causal_after_vs_before | shortcut after", [(+1, "before", "after"), (-1, "after", "after")]),
    ("interaction", [(+1, "before", "before"), (-1, "before", "after"), (-1, "after", "before"), (+1, "after", "after")]),
)


def cross_contrasts(rows):
    """v39: paired contrasts of the cross (positive = the first-named change lowers test error), formed within a
    job and state, averaged over optimizer settings within each data draw, summarised over unique data draws.
    interaction = (bb - ba) - (ab - aa) in test error, i.e. how much the shortcut change's effect depends on the
    causal change's origin."""
    by = defaultdict(dict)
    for r in rows:
        by[(r["cell"], r["variant"], r["arm"], r["removal_variant"], r["state"], r["draw_set"], r["noise_bias_from"],
            r["data_draw"], r["optimizer_seed"], r["run_id"])][(r["causal_from"], r["shortcut_from"])] = r["test_err"]
    per = defaultdict(lambda: defaultdict(list))
    for k, cell in by.items():
        for name, terms in CROSS_CONTRASTS:
            if all((c, s_) in cell for _, c, s_ in terms):
                v = sum(sg * cell[(c, s_)] for sg, c, s_ in terms)
                per[(*k[:7], name)][(k[7], k[8])].append(v)
    out, by_draw = [], []
    names = ("cell", "variant", "arm", "removal_variant", "state", "draw_set", "noise_bias_from", "contrast")
    for k, sets in sorted(per.items(), key=lambda t: tuple(map(str, t[0]))):
        draws = defaultdict(list)
        for (ds, os_), v in sorted(sets.items(), key=lambda t: tuple(map(str, t[0]))):
            draws[ds].append((os_, sum(v) / len(v)))
        dm = []
        for ds, lst in sorted(draws.items(), key=lambda t: str(t[0])):
            dm.append(sum(x for _, x in lst) / len(lst))
            by_draw.append({**dict(zip(names, k)), "data_draw": ds,
                            "optimizer_settings": " ".join(str(o) for o, _ in lst),
                            "test_err_difference": dm[-1]})
        n = len(dm)
        mu = sum(dm) / n
        sd = (sum((x - mu) ** 2 for x in dm) / (n - 1)) ** 0.5 if n > 1 else None
        t = T95.get(n - 1, 2.0) if n > 1 else None
        out.append({**dict(zip(names, k)),
                    "n_unique_data_draws": n, "mean_test_err_difference": mu,
                    "ci95_low": mu - t * sd / n ** 0.5 if sd is not None else None,
                    "ci95_high": mu + t * sd / n ** 0.5 if sd is not None else None,
                    "draws_positive": f"{sum(x > 0 for x in dm)}/{n}"})
    return by_draw, out


def fork_audit_row(meta: dict, j: dict) -> dict:
    """v41: what the keep fork's own record says about its start, its stream and its optimizer (the factorial
    requires these equal across the forks of one parent; see fork_equality).  A retained-mask fork's gradient
    eligibility must follow the parent's split for every example seen."""
    sa = j.get("schedule_audit") or {}
    ph = [x for x in sa.get("phases") or [] if str(x.get("phase", "")).startswith("keep_")]
    if len(ph) != 1:
        raise Fail(f"fork audit: {len(ph)} keep phases logged, expected 1")
    ph = ph[0]
    rp = j.get("removal_policy") or {}
    oa = ph.get("optimizer_audit") or {}
    st0, st1 = oa.get("start") or {}, oa.get("after_first_update") or {}
    el = ph.get("eligibility")
    if ph.get("grad_masks") == "retained":
        if not isinstance(el, dict) or el.get("a_matches_split") is not True or el.get("b_is_complement") is not True:
            raise Fail(f"fork audit: the gradient eligibility does not follow the parent's split ({el})")
    elif ph.get("grad_masks") != "released":
        raise Fail(f"fork audit: unknown mask record {ph.get('grad_masks')!r}")
    if ph.get("grad_masks") != meta["fork_masks"] or \
            (ph.get("optimizer") == "carried from the parent") != (meta["fork_optimizer"] == "carry_from_parent"):
        raise Fail("fork audit: the logged masks / optimizer differ from the config's")
    if not st0 or not st1:
        raise Fail("fork audit: the optimizer audit is missing (results from before v41)")
    return {**{k: meta[k] for k in ("run_id", "cell", "variant", "arm", "removal_variant", "parent", "data_draw",
                                    "optimizer_seed", "partition_seed", "fork_masks", "fork_optimizer")},
            "parent_state_hash": sa.get("parent_state_hash"), "batch_id_hash_end": ph.get("batch_id_hash_end"),
            "batches_drawn_end": ph.get("batches_drawn_end"), "updates": ph.get("updates"), "lr": ph.get("lr"),
            "lr_schedule": ph.get("lr_schedule"), "membership_hash": rp.get("membership_hash"),
            "mask_route": rp.get("mask_route"),
            "examples_seen": el.get("examples_seen") if isinstance(el, dict) else None,
            "opt_start_digest": st0.get("digest"), "opt_start_tensors_with_state": st0.get("tensors_with_state"),
            "opt_start_step_min": st0.get("step_min"), "opt_start_step_max": st0.get("step_max"),
            "opt_first_update_digest": st1.get("digest"), "opt_first_update_step_max": st1.get("step_max")}


def compact_audit_rows(meta: dict, cfg: dict, cr: dict) -> list:
    """v43: a compact control's fork-audit records (continue.fork_audit): one row per fresh segment start (before
    its optimizer rule) and one for the end of the job."""
    fa = cr.get("fork_audit")
    if not fa or not fa.get("starts"):
        raise Fail("compact fork audit: no records (continue.fork_audit was set)")
    t = cfg.get("train") or {}
    fsg = (cfg.get("continue") or {}).get("freeze_segments") or []
    held = [f"{k_}={t[k_]}" for k_ in ("freeze_inputs", "freeze_backbone") if t.get(k_, "none") != "none"]
    pre = bool(held) and (not fsg or bool(fsg[0]))
    base = {k: meta[k] for k in ("run_id", "cell", "variant", "arm", "data_draw", "optimizer_seed", "parent")}
    base["prefix_frozen"] = pre
    base["prefix_freeze"] = "+".join(held) if pre else "none"        # v44: what the frozen prefix holds
    # v53: the training settings apart from the holds.  Controls that differ in them (e.g. the learning rate) share
    # f0 and the minibatch stream but not their states, so they are separate equality groups
    base["prefix_train"] = stable_hash({k_: v_ for k_, v_ in t.items() if k_ not in ("freeze_inputs",
                                                                                     "freeze_backbone")})
    out = []
    for r in fa["starts"]:
        o = r.get("opt") or {}
        out.append({**base, "record": "segment_start", "segment": r["segment"], "update": r["update"],
                    "model_param_hash": r["model_param_hash"], "opt_digest": o.get("digest"),
                    "opt_tensors_with_state": o.get("tensors_with_state"),
                    "sampler": json.dumps(r["sampler"], sort_keys=True), "rng_hash": r["rng_hash"],
                    "batch_id_hash": r.get("batch_id_hash"), "batches_drawn": r.get("batches_drawn"),
                    "reset_applied": r.get("reset_applied"),
                    "opt_tensors_with_state_after_configure": r.get("opt_tensors_with_state_after_configure")})
    out.append({**base, "record": "end", "segment": None, "update": fa["updates"],
                "batch_id_hash": fa["batch_id_hash_end"], "batches_drawn": fa["batches_drawn_end"]})
    return out


def compact_fork_equality(rows: list, fork_u) -> list:
    """v43: compact controls of one f0 (cell, draw, seed, baseline) that share their prefix (frozen or not; v53: and
    their training settings apart from the holds) must agree at every segment start they share, the end of the
    expansion (2U) among them: model, optimizer state by name, sampler, RNG and minibatch stream; and at the end: the
    same minibatches and update count.  A declared reset must leave no optimizer state; a carried segment must keep
    it.  -> the failures."""
    bad = []
    grp = defaultdict(list)
    for r in rows:
        grp[(r["cell"], r["data_draw"], r["optimizer_seed"], r["parent"], r["prefix_frozen"],
             r.get("prefix_freeze", "none"), r.get("prefix_train"))].append(r)
    fields = ("model_param_hash", "opt_digest", "sampler", "rng_hash", "batch_id_hash", "batches_drawn")
    for k, rs in sorted(grp.items(), key=lambda t: tuple(map(str, t[0]))):
        runs_ = sorted({r["run_id"] for r in rs})
        starts = defaultdict(dict)
        for r in rs:
            if r["record"] == "segment_start":
                starts[r["update"]][r["run_id"]] = r
                if r["segment"] > 0 and r["reset_applied"] is not None:
                    left = r["opt_tensors_with_state_after_configure"]
                    if bool(r["reset_applied"]) == bool(left):
                        bad.append({"group": list(map(str, k)), "run_id": r["run_id"], "update": r["update"],
                                    "field": "the optimizer rule (reset leaves no state, carry keeps it)"})
        shared = sorted(u for u, m in starts.items() if set(m) == set(runs_))
        if len(runs_) > 1 and fork_u is not None and fork_u not in shared:
            bad.append({"group": list(map(str, k)), "field": f"no shared segment start at {fork_u} (2U)"})
        for u in shared:
            for f in fields:
                if len({json.dumps(m[f]) for m in starts[u].values()}) != 1:
                    bad.append({"group": list(map(str, k)), "update": u, "field": f})
        ends = [r for r in rs if r["record"] == "end"]
        for f in ("batch_id_hash", "batches_drawn", "update"):
            if len({json.dumps(r[f]) for r in ends}) != 1:
                bad.append({"group": list(map(str, k)), "update": "end", "field": f})
    return bad


def fork_equality(audit: list) -> list:
    """v41: the forks of one parent must share the start state, the minibatch stream, the update count and the
    learning rate; carried forks the same (parent's) optimizer state at the start, reset forks none; retained-mask
    forks the same split.  -> the failures."""
    by = defaultdict(list)
    for r in audit:
        by[(r["cell"], r["variant"], r["parent"])].append(r)
    bad = []
    for k, rs in sorted(by.items(), key=lambda t: tuple(map(str, t[0]))):
        for f in ("parent_state_hash", "batch_id_hash_end", "batches_drawn_end", "updates", "lr", "lr_schedule",
                  "data_draw", "optimizer_seed", "partition_seed"):
            if len({json.dumps(r[f]) for r in rs}) != 1 or rs[0][f] is None and f not in ("partition_seed",):
                bad.append({"parent": k[2], "variant": k[1], "field": f, "values": sorted({str(r[f]) for r in rs})})
        car = [r for r in rs if r["fork_optimizer"] == "carry_from_parent"]
        if len({r["opt_start_digest"] for r in car}) > 1 or any(not r["opt_start_tensors_with_state"] for r in car):
            bad.append({"parent": k[2], "variant": k[1], "field": "carried optimizer state at the fork start"})
        if any(r["opt_start_tensors_with_state"] for r in rs if r["fork_optimizer"] != "carry_from_parent"):
            bad.append({"parent": k[2], "variant": k[1], "field": "a reset fork starts with optimizer state"})
        ret = [r for r in rs if r["fork_masks"] == "retained"]
        if len({r["membership_hash"] for r in ret}) > 1 or any(r["membership_hash"] is None for r in ret):
            bad.append({"parent": k[2], "variant": k[1], "field": "membership_hash"})
        if len({(r["fork_masks"], r["fork_optimizer"]) for r in rs}) != len(rs):
            bad.append({"parent": k[2], "variant": k[1], "field": "a duplicated fork setting"})
    return bad


def ci_stats(dm: list, vk: str) -> dict:
    n = len(dm)
    mu = sum(dm) / n
    sd = (sum((x - mu) ** 2 for x in dm) / (n - 1)) ** 0.5 if n > 1 else None
    t = T95.get(n - 1, 2.0) if n > 1 else None
    return {"n_unique_data_draws": n, f"mean_{vk}": mu,
            "ci95_low": mu - t * sd / n ** 0.5 if sd is not None else None,
            "ci95_high": mu + t * sd / n ** 0.5 if sd is not None else None,
            "draws_positive": f"{sum(x > 0 for x in dm)}/{n}"}


def two_stage(rows: list, gk: tuple, vk: str):
    """v41: a paired value averaged over partition seeds within (data draw, optimizer seed), over optimizer seeds
    within each data draw, then summarised over UNIQUE data draws.  -> (by_draw, summary)."""
    per = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
    for r in rows:
        if r.get(vk) is not None:
            per[tuple(r[k] for k in gk)][r["data_draw"]][r["optimizer_seed"]].append(float(r[vk]))
    by_draw, summ = [], []
    for k, draws in sorted(per.items(), key=lambda t: tuple(map(str, t[0]))):
        dm = []
        for ds, seeds in sorted(draws.items(), key=lambda t: str(t[0])):
            m = sum(sum(v) / len(v) for v in seeds.values()) / len(seeds)
            dm.append(m)
            by_draw.append({**dict(zip(gk, k)), "data_draw": ds,
                            "optimizer_settings": " ".join(sorted(str(x) for x in seeds)),
                            "n_values": sum(len(v) for v in seeds.values()), vk: m})
        summ.append({**dict(zip(gk, k)), **ci_stats(dm, vk)})
    return by_draw, summ


ANALYSIS_SCHEMA = "selective_reversal/v57"
# v42: the causal grid extends to 16 (v41's 4.0 was selected for every f0)
A_GRID_ = (0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 2.5, 3.0, 4.0, 6.0, 8.0, 12.0, 16.0)
S_GRID_ = (0.0, 0.25, 0.5, 0.75, 1.0)
FIT_EPS = 1e-12


def fit_row_scales(C0, C1, nonneg: bool = False):
    """v43: per row r the through-origin least-squares scale s_r = <C0_r, C1_r> / |C0_r|^2 taking f0's causal row
    toward the learned one (a SIGNED scaling: s_r < 0 reverses the row).  nonneg: the constrained fit, which for one
    scalar is max(0, s_r).  A zero row of C0 is degenerate: s_r = 1 (no change), flagged.  -> (s, degenerate)."""
    den = (C0 * C0).sum(1)
    deg = den <= FIT_EPS
    s = torch.where(deg, torch.ones_like(den), (C0 * C1).sum(1) / den.clamp_min(FIT_EPS))
    return (s.clamp_min(0.0) if nonneg else s), deg


def row_scale_residual(C0, C1):
    """v44: the learned block split into a per-row scaling of f0's block plus a residual, C1 = s * C0 + Res, with s
    the signed least-squares row fit (so each residual row is orthogonal to f0's row; a zero row of C0 is
    degenerate, s = 1).  -> (s, Res, stats): the residual's share of the learned block's energy |Res|^2 / |C1|^2,
    and of the change from f0, |Res| / |C1 - C0|."""
    s, deg = fit_row_scales(C0, C1)
    res = C1 - C0 * s.unsqueeze(1)
    n1 = float((C1 * C1).sum())
    nd = float(((C1 - C0) ** 2).sum()) ** 0.5
    nr = float((res * res).sum())
    return s, res, {"residual_energy_fraction": nr / n1 if n1 > 0 else None,
                    "residual_norm_vs_change": nr ** 0.5 / nd if nd > 0 else None,
                    "residual_degenerate_rows": int(deg.sum())}


def residual_magnitude_blocks(C0, C1, eps: float = 1e-12):
    """v45: per row w_learned = a * w0 + r (a the weight-space least-squares scale, r orthogonal to w0; a zero row of
    f0 is degenerate: a = 1, r = w_learned - w0).  -> blocks and per-row records:
      plus_residual            w0 + r
      f0_dir_norm_of_plus_res  w0 scaled to exactly the row norm of w0 + r (a zero row of f0 stays zero)
      plus_residual_f0_norm    w0 + r rescaled to w0's row norm (a zero row of w0 + r stays as it is)
    with the reconstruction error (max |a w0 + r - w_learned|) and the largest |<r, w0>| / (|r| |w0|) over the
    non-degenerate rows.  Nothing is tuned on any data."""
    a, deg = fit_row_scales(C0, C1)
    r = C1 - C0 * a.unsqueeze(1)
    n0, nr = C0.norm(dim=1), r.norm(dim=1)
    pr = C0 + r
    npr = pr.norm(dim=1)
    z0, zp = n0 <= eps, npr <= eps
    s1 = torch.where(z0, torch.ones_like(n0), npr / n0.clamp_min(1e-300))
    s2 = torch.where(zp, torch.ones_like(npr), n0 / npr.clamp_min(1e-300))
    cos = (r * C0).sum(1).abs() / (nr * n0).clamp_min(1e-300)
    ok = ~deg & (nr > eps)
    rec = {"reconstruction_max_abs": float((C0 * a.unsqueeze(1) + r - C1).abs().max()),
           "orthogonality_max_abs_cos": float(cos[ok].max()) if bool(ok.any()) else 0.0,
           "degenerate_rows": int(deg.sum()), "f0_zero_rows_kept_zero": int(z0.sum()),
           "plus_residual_zero_rows_unscaled": int(zp.sum())}
    return {"plus_residual": pr, "f0_dir_norm_of_plus_res": C0 * s1.unsqueeze(1),
            "plus_residual_f0_norm": pr * s2.unsqueeze(1)}, a, r, rec


def insertion_hash(td: Path) -> Optional[str]:
    """v45: a hash of the parameters each growth round newly inserted, as saved right after its insertion
    (post_insert_r1, r2, ...: only the additions new in that round, so training of earlier ones does not enter).
    Equal across trajectories that differ only in what they hold means the same insertion initialization."""
    rounds = sorted((int(p_.stem.split("_r")[-1]), p_) for p_ in (td / "ckpt").glob("post_insert_r*.pt"))
    if not rounds:
        return None
    prev, parts = set(), []
    for r_, p_ in rounds:
        ck_ = torch.load(p_, map_location="cpu", weights_only=False)["model"]
        g_ = GraphNet.from_checkpoint(ck_)
        own = {n.pkey for n in g_.nodes.values() if n.owner is not None and n.pkey}
        new = sorted(own - prev)
        prev |= own
        sd_ = ck_["state"]
        parts.append([r_, new, {k: hashlib.sha256(sd_[k].contiguous().view(torch.uint8).numpy().tobytes()
                                                  ).hexdigest()[:16]
                                for k in sorted(sd_) if k.split(".")[1] in new}])
    return stable_hash(parts)


EXTRACTION_MODELS = (
    ("expanded_with_additions", "codes_implants", "zero", "the expanded network as trained (additions present)"),
    ("trained_backbone_additions_deleted", "codes", "zero", "the trained backbone, additions deleted"),
    ("extraction_first_layer_rest_f0", "codes", "x1",
     "the learned first layer (weights and bias), layers 2..K f0's, additions deleted: the extraction"),
    ("extraction_with_additions", "codes_implants", "x1",
     "the same restored backbone with the trained additions present"),
    ("f0", "codes", "ones", "f0"))


def access_fields(r: dict, model: str) -> dict:
    """v46: what each 2U model needed to know.  Training access follows the lineage that trained the state: an
    expansion's from its TRAJECTORY (its removal job lifts the holds, so the job's own settings would mislead), a
    compact control's from its own holds.  Holding the shortcut column uses the feature layout (which input column is
    the shortcut); holding layers 2..K uses only the layer index.  The extraction itself (keep layer 1, restore
    layers 2..K, delete the additions) uses no feature labels."""
    fi = r.get("parent_freeze_inputs") if r.get("source") == "removal" else r.get("freeze_inputs")
    fb = r.get("parent_freeze_backbone") if r.get("source") == "removal" else r.get("freeze_backbone")
    if model == "f0":
        tr = "none (f0)"
    elif fi not in (None, "none", ""):
        tr = f"feature layout: the {fi} input column held at f0" + (
            "; layers 2..K held (layer index only)" if fb not in (None, "none", "") else "")
    elif fb not in (None, "none", ""):
        tr = "none (layers 2..K held: layer index only)"
    else:
        tr = "none"
    ex = "none (unedited model)" if model in ("expanded_with_additions", "f0") else \
        "none: whole-layer operation (no feature labels)"
    return {"training_access": tr, "extraction_access": ex}


def extraction_2u_rows(out: dict, fork_u: int) -> list:
    """v45: the five models at the end of the expansion (2U), one table: for an expansion its abrupt state (the
    trajectory's end) from its removal job; for a compact control its at_2U checkpoint (no additions: the first
    two rows are its native model, the fourth does not exist).  With the training cost since f0."""
    rows = []
    cost = {(r["run_id"], r["state"]): r for r in out.get("compute", [])}
    for tab in ("codes", "codes_implants"):
        for r in out.get(tab, []):
            if r["state"] != "abrupt":
                continue
            K = len(r["code"].split("-"))
            want = {"zero": "-".join(["0"] * K), "x1": "-".join(["0"] + ["1"] * (K - 1)), "ones": "-".join(["1"] * K)}
            for m, t_, c_, desc in EXTRACTION_MODELS:
                if t_ == tab and r["code"] == want[c_]:
                    cf = cost.get((r["run_id"], "abrupt")) or {}
                    rows.append({**r, "state": "2U", "model": m, "model_meaning": desc, **access_fields(r, m),
                                 "source_table": tab,
                                 **{k: v for k, v in cf.items() if k.startswith(("cost_", "macs_", "f0_training",
                                                                                 "f0_macs", "total_macs"))}})
    for r in out.get("trace", []):
        if r["source"] == "removal" or r["arm"] == "trajectory" or r["updates_since_f0"] != fork_u:
            continue
        K = len(r["code"].split("-"))
        want = {"zero": "-".join(["0"] * K), "x1": "-".join(["0"] + ["1"] * (K - 1)), "ones": "-".join(["1"] * K)}
        for m, t_, c_, desc in EXTRACTION_MODELS:
            if t_ == "codes_implants" and m != "expanded_with_additions":
                continue
            if r["code"] == want[c_]:
                rows.append({**r, "state": "2U", "model": m, **access_fields(r, m), "source_table": "trace",
                             "model_meaning": desc if m != "expanded_with_additions" else
                             "the compact control's model at 2U (it has no additions)"})
    for r in rows:
        if r["model"] == "f0":                  # f0 itself: no training after f0
            for k in [k for k in r if k.startswith("macs_")] + ["cost_updates", "cost_examples"]:
                r[k] = 0
            r["total_macs_backward_aware_including_f0"] = r.get("f0_macs_backward_aware")
            r["cost_basis"] = "f0 itself (no training after f0)"
    return rows


# v47: coordinated reversal.  With the trained first layer kept (weights and bias), two edits are varied
# independently on the expanded network: every addition's gate multiplied by alpha (1 = as trained, 0 = removed)
# and backbone layers 2..K set to f0 + beta * (trained - f0) (1 = as trained, 0 = restored to f0).  The grid and the
# three paths across it are fixed in advance; no path or point is selected on any data.
GRID_LEVELS = (1.0, 0.75, 0.5, 0.25, 0.0)
REVERSAL_PATHS = {
    "diagonal": [(t, t) for t in GRID_LEVELS],
    "delete_then_rewind": [(t, 1.0) for t in GRID_LEVELS] + [(0.0, t) for t in GRID_LEVELS[1:]],
    "rewind_then_delete": [(1.0, t) for t in GRID_LEVELS] + [(t, 0.0) for t in GRID_LEVELS[1:]]}
CELLS_2X2 = ("present_trained", "deleted_trained", "present_rewound", "deleted_rewound")
MARGIN_QUANTILES = (0.01, 0.05, 0.25, 0.5, 0.75, 0.95, 0.99)
LOGIT_DIAGNOSTICS = tuple(f"test_margin_q{round(100 * q):02d}" for q in MARGIN_QUANTILES) + \
    tuple(f"test_ce_q{round(100 * q):02d}" for q in MARGIN_QUANTILES) + \
    ("test_abs_logit_q50", "test_abs_logit_q99", "test_abs_logit_max", "test_ce_gt10_share", "test_ce_from_wrong_share")
GRID_METRICS = ("test_err", "test_ce", "val_err", "val_ce", "shift_err", "rare_err", "shortcut_flip_rate",
                "disagreement_vs_native", "disagreement_vs_extraction") + LOGIT_DIAGNOSTICS
PATH_QUANTITIES = ("max_test_err", "max_test_ce", "barrier_test_err", "barrier_test_ce")


def reversal_interactions(rows: list) -> list:
    """v47: per run and checkpoint, the four 2x2 cells and the finite-difference interaction on test error,
    R(deleted, trained) + R(present, rewound) - R(present, trained) - R(deleted, rewound) (an interaction on error,
    not an accuracy gain).  When layers 2..K are f0's at that checkpoint the rewind is a no-op (flagged)."""
    by = defaultdict(dict)
    for r in rows:
        by[(r["run_id"], r["checkpoint"])][r["reversal_cell"]] = r
    out = []
    for (rid, ck), cs_ in sorted(by.items(), key=lambda t: tuple(map(str, t[0]))):
        if set(cs_) != set(CELLS_2X2):
            continue
        r0 = cs_["present_trained"]
        e = {c: float(cs_[c]["test_err"]) for c in CELLS_2X2}
        out.append({k: r0[k] for k in ("run_id", "cell", "variant", "arm", "removal_variant", "draw_set",
                                        "data_draw", "optimizer_seed", "partition_seed", "checkpoint",
                                        "updates_since_f0", "rewind_is_noop", "training_access")}
                   | {f"{c}_test_err": e[c] for c in CELLS_2X2}
                   | {"interaction": e["deleted_trained"] + e["present_rewound"] - e["present_trained"]
                      - e["deleted_rewound"],
                      "joint_vs_native": e["present_trained"] - e["deleted_rewound"],
                      "sign": "interaction > 0: the two edits interact (each alone costs more than together); "
                              "joint_vs_native > 0: deleting and rewinding together beats the expanded network"})
    return out


def reversal_paths(grid_rows: list) -> tuple:
    """v47: the three predeclared paths read off each run's grid, both ends included, and paired contrasts against
    the diagonal (value = sequential path's worst - diagonal's worst; positive = the diagonal's worst point is
    better).  v48: per path the raw worst test error and cross-entropy and the endpoint-relative barrier, worst on
    the path - max(start, end), which separates bad intermediate points from differences in endpoint quality.  All
    three paths share both ends ((1,1) and (0,0)), so a barrier contrast equals the worst-point contrast.  v47's
    mean along the path is dropped: it weights the sampled points by schedule (5 points on the diagonal, 9 on the
    sequential paths, and repeated identical functions wherever the rewind is a no-op, as in C and D), so it is not a
    comparison of removal quality.  A sampled path describes these points only; it says nothing about paths not
    sampled or finer steps."""
    by = defaultdict(dict)
    for r in grid_rows:
        by[r["run_id"]][(float(r["alpha"]), float(r["beta"]))] = r
    rows, con = [], []
    for rid, pts in sorted(by.items()):
        r0 = next(iter(pts.values()))
        base = {k: r0[k] for k in ("run_id", "cell", "variant", "arm", "removal_variant", "draw_set", "data_draw",
                                    "optimizer_seed", "partition_seed", "rewind_is_noop", "training_access")}
        summ = {}
        for name, pth in REVERSAL_PATHS.items():
            if any(q not in pts for q in pth):
                continue
            rec = {"n_points": len(pth), "points": " ".join(f"({a_:g},{b_:g})" for a_, b_ in pth)}
            for m, tag in (("test_err", "test_err"), ("test_ce", "test_ce")):
                v = [pts[q].get(m) for q in pth]
                if any(x is None for x in v):
                    rec[f"max_{tag}"] = rec[f"barrier_{tag}"] = None
                    continue
                v = [float(x) for x in v]
                rec[f"max_{tag}"] = max(v)
                rec[f"start_{tag}"], rec[f"end_{tag}"] = v[0], v[-1]
                rec[f"barrier_{tag}"] = max(v) - max(v[0], v[-1])
            summ[name] = rec
            rows.append({**base, "path": name, **rec})
        if "diagonal" in summ:
            for name in ("delete_then_rewind", "rewind_then_delete"):
                if name in summ:
                    for q in ("max_test_err", "max_test_ce"):
                        if summ[name][q] is not None and summ["diagonal"][q] is not None:
                            con.append({**base, "contrast": f"{name}_vs_diagonal", "quantity": q,
                                        "value": summ[name][q] - summ["diagonal"][q],
                                        "sign": "positive = the diagonal path's worst point is better"})
    return rows, con


EXTRACTION_METRICS = ("test_err", "val_err", "shift_err", "rare_err", "cf_base_err", "cf_causal_err", "cf_shortcut_err",
                      "shortcut_flip_rate", "cost_updates", "macs_backward_aware", "macs_forward", "macs_input_grad",
                      "macs_param_grad", "macs_param_grad_discarded", "macs_param_grad_used", "macs_3x_forward",
                      "f0_macs_backward_aware", "total_macs_backward_aware_including_f0",
                      "inference_macs_per_example")
METRIC_NOTES = {"cost_updates": "training updates after f0",
                "inference_macs_per_example": "the model's analytic forward MACs per example (not measured runtime)",
                "f0_macs_backward_aware": "f0's own training, backward-aware analytic estimate",
                "total_macs_backward_aware_including_f0": "f0's training plus the training after f0"}


def extraction_summaries(rows: list) -> tuple:
    """v46: the 2U extraction table aggregated with its errors AND its costs (long format, one row per metric):
    optimizer seeds averaged within a draw, the summary over draws.  MAC figures are analytic estimates (training:
    backward-aware per example, in parts; inference: forward per example), never measured runtime."""
    long_ = []
    for r in rows:
        for m in EXTRACTION_METRICS:
            v = r.get(m)
            if v is None or v == "":
                continue
            long_.append({k: r[k] for k in ("cell", "variant", "arm", "removal_variant", "draw_set", "data_draw",
                                            "optimizer_seed", "partition_seed", "model", "training_access",
                                            "extraction_access")} | {"metric": m, "v": float(v),
                                                                     "note": METRIC_NOTES.get(m, m.replace("_", " ")
                                                                                              + (" (analytic MAC "
                                                                                                 "estimate)" if
                                                                                                 m.startswith("macs")
                                                                                                 else ""))})
    bd, sm = two_stage(long_, ("cell", "variant", "arm", "removal_variant", "draw_set", "model", "training_access",
                               "extraction_access", "metric", "note"), "v")
    return long_, bd, sm


def output_membership_failures(out: dict, design_jobs: set, fork_u, want_extraction: bool, want_saved: bool) -> list:
    """v46: complete output membership derived from the manifest, not merely nonempty files.  Every expansion
    (a removal job of the full kind) must have exactly the five 2U models and every compact control exactly four,
    each once, with finite errors in [0, 1] and, where cost is recorded, 2U updates after f0 (0 for f0 itself);
    every expansion two saved extractions (additions deleted, present) and every compact control one, each
    reloaded and checked."""
    bad = []
    if want_extraction:
        exp = {}
        for k in design_jobs:
            if k[2] == "control":
                ms = [m[0] for m in EXTRACTION_MODELS if m[0] != "extraction_with_additions"]
            elif k[2] == "full":
                ms = [m[0] for m in EXTRACTION_MODELS]
            else:
                continue
            for m in ms:
                exp[(k[0], k[1], k[3], k[4], k[5], m)] = 0
        seen = defaultdict(int)
        for r in out.get("extraction_2u", []):
            kk = (r["variant"], r["arm"], r["cell"], r["data_draw"], r["optimizer_seed"], r["model"])
            seen[kk] += 1
            for f in ("test_err", "val_err", "shift_err", "rare_err"):
                v = r.get(f)
                if v is None or not (0.0 <= float(v) <= 1.0):
                    bad.append({"table": "extraction_2u", "check": f"{f} in [0, 1]", "key": list(map(str, kk))})
            cu = r.get("cost_updates")
            if cu is not None and int(cu) != (0 if r["model"] == "f0" else int(fork_u or -1)):
                bad.append({"table": "extraction_2u", "check": "updates after f0 at 2U", "key": list(map(str, kk)),
                            "value": cu})
        for kk in sorted(set(exp) | set(seen), key=lambda t: tuple(map(str, t))):
            if kk not in exp:
                bad.append({"table": "extraction_2u", "check": "unexpected row", "key": list(map(str, kk))})
            elif seen.get(kk, 0) != 1:
                bad.append({"table": "extraction_2u", "check": f"{seen.get(kk, 0)} rows (want 1)",
                            "key": list(map(str, kk))})
    if want_saved:
        exp = {}
        for k in design_jobs:
            for ad in (["none (compact)"] if k[2] == "control" else ["deleted", "present"] if k[2] == "full" else []):
                exp[(k[0], k[1], k[3], k[4], k[5], ad)] = 0
        seen = defaultdict(int)
        for r in out.get("extractions_saved", []):
            kk = (r["variant"], r["arm"], r["cell"], r["data_draw"], r["optimizer_seed"], r["additions"])
            seen[kk] += 1
            if r.get("reload_reproduces_predictions") is not True:
                bad.append({"table": "extractions_saved", "check": "reloaded and reproduced", "key": list(map(str, kk))})
        for kk in sorted(set(exp) | set(seen), key=lambda t: tuple(map(str, t))):
            if kk not in exp or seen.get(kk, 0) != 1:
                bad.append({"table": "extractions_saved", "check": f"{seen.get(kk, 0)} saved (want "
                            f"{1 if kk in exp else 0})", "key": list(map(str, kk))})
    return bad


def paired_stream_failures(rows: list, design_jobs: set, fork_u) -> list:
    """v45/v46: the paired-stream audit.  Groups are (cell, data draw, optimizer seed) -- never keyed by f0, so a
    condition that points at another f0 is a failure, not a group of its own.  Membership comes from the manifest:
    every condition with a removal job must have exactly one trajectory record, every compact-control condition
    exactly one compact record, and nothing else.  Within a group: one f0 (run id and state hash); identical
    trajectory streams (hash, batches drawn = updates = 2U), insertion initializations, configurations apart from the
    holds and data; each compact control's stream at 2U (one fork record at update 2U, batches drawn = 2U) equal to
    the trajectories'.  A run recorded twice with different content is a conflict.  -> failures (empty when all
    hold)."""
    exp_t, exp_c = defaultdict(set), defaultdict(set)
    for k in design_jobs:
        (exp_c if k[2] == "control" else exp_t)[(k[3], k[4], k[5])].add(k[0])
    if not design_jobs:                     # no manifest: membership is what was observed (equality checks only)
        for r in rows:
            (exp_c if r["role"] == "compact" else exp_t)[(r["cell"], r["data_draw"], r["optimizer_seed"])].add(
                r["variant"])
    grp, recs, bad = defaultdict(list), {}, []
    for r in rows:
        key = (r["role"], r["run_id"])
        if key in recs:
            if json.dumps(recs[key], sort_keys=True, default=str) != json.dumps(r, sort_keys=True, default=str):
                bad.append({"group": [str(r["cell"]), str(r["data_draw"]), str(r["optimizer_seed"])],
                            "check": "conflicting duplicate records", "run_id": r["run_id"]})
            continue
        recs[key] = r
        grp[(r["cell"], r["data_draw"], r["optimizer_seed"])].append(r)
    for g in sorted(set(grp) | set(exp_t) | set(exp_c), key=lambda t: tuple(map(str, t))):
        gs = [str(x) for x in g]
        rs = grp.get(g, [])
        tr_ = [r for r in rs if r["role"] == "trajectory"]
        cp_ = [r for r in rs if r["role"] == "compact"]
        for role, have, want in (("trajectory", tr_, exp_t.get(g, set())), ("compact", cp_, exp_c.get(g, set()))):
            byv = defaultdict(set)
            for r in have:
                byv[r["variant"]].add(r["run_id"])
            for v in sorted(want - set(byv), key=str):
                bad.append({"group": gs, "check": f"{role} missing", "variant": v})
            for v in sorted(set(byv) - want, key=str):
                bad.append({"group": gs, "check": f"unexpected {role}", "variant": v})
            for v, ids in byv.items():
                if len(ids) > 1:
                    bad.append({"group": gs, "check": f"{len(ids)} {role}s for one condition", "variant": v})
        f0s = {(r["f0"], r.get("f0_state_hash")) for r in rs}
        if len(f0s) > 1 or any(x[1] is None for x in f0s):
            bad.append({"group": gs, "check": "one f0 (run id and state hash)", "values": sorted(map(str, f0s))})
        for f in ("batch_id_hash", "insertion_init_hash", "config_apart_from_holds", "data_hash"):
            vals = {r[f] for r in tr_}
            if len(vals) > 1 or (tr_ and None in vals):
                bad.append({"group": gs, "check": f"trajectories: {f}", "values": sorted(map(str, vals))})
        for r in rs:
            if fork_u is None or r.get("updates") != fork_u or r.get("batches_drawn") != fork_u:
                bad.append({"group": gs, "check": "updates and batches drawn at 2U", "run_id": r["run_id"],
                            "values": [str(r.get("updates")), str(r.get("batches_drawn")), str(fork_u)]})
        if tr_ and cp_:
            th = tr_[0]["batch_id_hash"]
            for r in cp_:
                if r.get("fork_records_at_2U") != 1 or r["batch_id_hash"] is None or r["batch_id_hash"] != th \
                        or r["data_hash"] != tr_[0]["data_hash"]:
                    bad.append({"group": gs, "check": "compact stream at 2U = the trajectories'",
                                "run_id": r["run_id"], "values": [str(r["batch_id_hash"]), str(th)]})
    return bad


COUNTER_PARTS = ("forward", "input_grad", "param_grad", "param_grad_discarded")


def counters_of(ck) -> Optional[dict]:
    """v45: a checkpoint's (or a result's compute_end) cumulative training counters: from its trainer state, else its
    extras' 'compute' record (checkpoints that carry no trainer state).  None when absent; mac_parts None before
    v45."""
    if ck is None:
        return None
    if "train_macs" in ck and "mac_parts" in ck:          # already a compute record
        st = ck
    else:
        st = (ck.get("trainer") or {}).get("state") if isinstance(ck.get("trainer"), dict) else None
        ex_ = ck.get("extra") or {}
        if st is None and isinstance(ex_.get("trainer"), dict):        # e.g. a trajectory's baseline_ref copy of f0
            st = ex_["trainer"].get("state")
        if st is None:
            st = ex_.get("compute")
    if not st or "train_macs" not in st:
        return None
    mp = st.get("mac_parts")
    return {"updates": int(st.get("global_step", 0)), "examples": int(st.get("examples", 0)),
            "train_macs": int(st.get("train_macs", 0)), "train_macs_bwd": int(st.get("train_macs_bwd", 0)),
            "mac_parts": {k: int(mp.get(k, 0)) for k in COUNTER_PARTS} if mp else None}


def counters_comb(a, b, sign: int):
    """a + sign * b, part by part (None when either is None; parts None when either lacks them)."""
    if a is None or b is None:
        return None
    o = {k: a[k] + sign * b[k] for k in ("updates", "examples", "train_macs", "train_macs_bwd")}
    o["mac_parts"] = ({k: a["mac_parts"][k] + sign * b["mac_parts"][k] for k in COUNTER_PARTS}
                      if a.get("mac_parts") and b.get("mac_parts") else None)
    return o


def cost_fields(c, basis: str, f0=None) -> dict:
    """v45: training cost since f0 as table columns.  macs_3x_forward is the trainer's dense estimate (3 x forward);
    macs_backward_aware the analytic per-node estimate (linear-type nodes; elementwise work not counted) with its
    parts; param_grad counts what autograd computes, param_grad_discarded the part a parameter hold zeroes."""
    o = {"cost_basis": basis, "cost_updates": None, "cost_examples": None, "macs_3x_forward": None,
         "macs_backward_aware": None, **{f"macs_{k}": None for k in COUNTER_PARTS}, "macs_param_grad_used": None}
    # v46: f0's own training and the total including it (backward-aware estimate)
    o["f0_training_updates"] = f0["updates"] if f0 else None
    o["f0_macs_backward_aware"] = f0["train_macs_bwd"] if f0 else None
    o["total_macs_backward_aware_including_f0"] = None
    if c is None:
        return o
    o.update({"cost_updates": c["updates"], "cost_examples": c["examples"], "macs_3x_forward": c["train_macs"],
              "macs_backward_aware": c["train_macs_bwd"]})
    if f0:
        o["total_macs_backward_aware_including_f0"] = c["train_macs_bwd"] + f0["train_macs_bwd"]
    if c.get("mac_parts"):
        o.update({f"macs_{k}": c["mac_parts"][k] for k in COUNTER_PARTS})
        o["macs_param_grad_used"] = c["mac_parts"]["param_grad"] - c["mac_parts"]["param_grad_discarded"]
    return o


RESIDUAL_CONTRASTS = (
    # (name, A control, B control or 'f0', sign): value = err(B) - err(A); positive = A has the lower test error
    ("direction_at_matched_row_norms", "f0_causal_plus_residual", "f0_causal_dir_at_norm_of_plus_residual",
     "positive = w0 + r beats f0's own directions at the same row norms (the changed directions help)"),
    ("direction_at_f0_row_norms", "f0_causal_plus_residual_at_f0_norm", "f0",
     "positive = w0 + r rescaled to f0's row norms beats f0 (the changed directions help at f0's magnitude)"),
    ("magnitude_alone", "f0_causal_dir_at_norm_of_plus_residual", "f0",
     "positive = f0's directions at the row norms of w0 + r beat f0 (the larger magnitude alone helps)"))


def residual_contrasts(scale_rows: list) -> tuple:
    """v46: the residual-versus-magnitude contrasts within each (run, state): every run and state that has the
    rescaling controls must have both sides of every contrast.  -> (rows, missing)."""
    by = defaultdict(dict)
    for r in scale_rows:
        by[(r["run_id"], r["state"])][r["control"]] = r
    rows, missing = [], []
    for (rid, st), cs_ in sorted(by.items(), key=lambda t: tuple(map(str, t[0]))):
        any_ = next(iter(cs_.values()))
        for name, a_, b_, sign in RESIDUAL_CONTRASTS:
            ra = cs_.get(a_)
            eb = (any_.get("f0_test_err") if b_ == "f0" else (cs_.get(b_) or {}).get("test_err"))
            if ra is None or eb is None:
                missing.append({"run_id": rid, "state": st, "contrast": name})
                continue
            rows.append({**{k: any_[k] for k in ("run_id", "cell", "variant", "arm", "removal_variant", "state",
                                                 "draw_set", "data_draw", "optimizer_seed", "partition_seed")},
                         "contrast": name, "a": a_, "b": b_, "a_test_err": float(ra["test_err"]),
                         "b_test_err": float(eb), "value": float(eb) - float(ra["test_err"]), "sign": sign})
    return rows, missing


def block_norms(B, B0) -> dict:
    """v45: an assembled candidate's own causal block: Frobenius norm, mean row norm, and their ratios to f0's."""
    f, f0 = float(B.norm()), float(B0.norm())
    rn, rn0 = B.norm(dim=1), B0.norm(dim=1)
    return {"candidate_causal_fro": f, "candidate_causal_fro_vs_f0": f / f0 if f0 > 0 else None,
            "candidate_row_norm_mean": float(rn.mean()),
            "candidate_row_norm_vs_f0_mean": float((rn / rn0.clamp_min(1e-300))[rn0 > 1e-12].mean())
            if bool((rn0 > 1e-12).any()) else None}


def fit_drive_scales(Uc, C0, C1, nonneg: bool = False):
    """v43: per unit r the scale that best maps f0's causal drive b_r = Uc C0_r to the learned one a_r = Uc C1_r
    over the rows of Uc (inputs' causal coordinates): s_r = <a_r, b_r> / |b_r|^2; signed unless nonneg; a unit
    whose f0 drive is zero on these inputs is degenerate (s_r = 1, flagged).  -> (s, degenerate)."""
    b_, a_ = Uc @ C0.T, Uc @ C1.T
    den = (b_ * b_).sum(0)
    deg = den <= FIT_EPS
    s = torch.where(deg, torch.ones_like(den), (a_ * b_).sum(0) / den.clamp_min(FIT_EPS))
    return (s.clamp_min(0.0) if nonneg else s), deg


def drive_r2(Uc, C0, C1, s):
    """v43: how much of the learned causal drive a_r = Uc C1_r the rescaled f0 drive s_r Uc C0_r explains, pooled
    over units: 1 - SSE / SST (SST about each unit's mean).  None when SST is zero (a constant target is degenerate,
    not a perfect fit).  -> (r2 or None, degenerate)."""
    b_, a_ = Uc @ C0.T, Uc @ C1.T
    sse = float(((a_ - b_ * s) ** 2).sum())
    sst = float(((a_ - a_.mean(0)) ** 2).sum())
    if sst <= FIT_EPS:
        return None, True
    return 1.0 - sse / sst, False


def agreement(q0, q1) -> dict:
    """v43: two classifiers' outputs (logits) on the same inputs: the share of differing decisions and the mean
    total-variation distance of the softmax outputs."""
    q0, q1 = q0.double(), q1.double()
    return {"decision_disagreement_vs_transplant": float((q0.argmax(-1) != q1.argmax(-1)).double().mean()),
            "tv_vs_transplant": float(0.5 * (q0.softmax(-1) - q1.softmax(-1)).abs().sum(-1).mean())}
DISP_METRICS = ("net_backbone_l2", "net_backbone_rel", "net_first_layer_l2", "net_first_layer_rel",
                "net_first_layer_causal_l2", "net_first_layer_shortcut_l2", "net_first_layer_noise_l2",
                "net_additions_l2", "net_additions_rel", "path_backbone", "path_first_layer",
                "path_first_layer_causal", "path_first_layer_shortcut", "path_additions", "path_updates")
N_SCALE_CONTROLS = 13         # v42: 6 (v39) + two fitted per-row rescalings; v43: + their nonnegative fits;
                              # v44: + f0's block plus the row fit's residual (f0_causal_plus_residual);
                              # v45: + f0's directions at the norm of w0 + r, and w0 + r at f0's norm
SCALE_METRICS = ("test_err", "decision_disagreement_vs_transplant", "tv_vs_transplant", "drive_r2_fit",
                 "drive_r2_heldout", "scale_mean", "n_negative_scales", "n_degenerate_rows", "causal_norm_ratio",
                 "causal_row_cosine_weighted", "shortcut_flip_rate", "residual_energy_fraction",
                 "residual_norm_vs_change")
KEEP_FORKS = {"keep": ("released", "reset_each_phase"), "keep+carry": ("released", "carry_from_parent"),
              "keep+masks": ("retained", "reset_each_phase"), "keep+masks+carry": ("retained", "carry_from_parent")}
FACTORIAL_SIGN = "positive = the named change lowers test error"


def factorial_measures(out: dict) -> list:
    """v41: (row, measure, update) for the keep forks: the endpoint's native function, its branch-deleted backbone,
    its first layer alone in f0, and its causal / shortcut / both column changes alone in f0, at the endpoint and
    (with --trace) at every traced checkpoint of the fork."""
    res = []
    fork = lambda r: r.get("source") == "removal" and r.get("removal_variant") in KEEP_FORKS

    def code_measure(c):
        z = c.split("-")
        if set(z) == {"0"}:
            return "branch_deleted"
        if z[0] == "0" and set(z[1:]) == {"1"}:
            return "first_layer"
        return None
    for r in out.get("native", []):
        if fork(r):
            res.append((r, "native", "endpoint"))
    for r in out.get("codes", []):
        if fork(r) and code_measure(r["code"]):
            res.append((r, code_measure(r["code"]), "endpoint"))
    for r in out.get("decomposition", []):
        if fork(r) and r["update_groups"] in ("causal", "shortcut", "shortcut+causal"):
            res.append((r, r["update_groups"], "endpoint"))
    for r in out.get("trace", []):
        if fork(r) and code_measure(r["code"]):
            res.append((r, code_measure(r["code"]), int(r["updates_since_f0"])))
    for r in out.get("decomposition_trace", []):
        if fork(r) and r["update_groups"] in ("causal", "shortcut", "shortcut+causal"):
            res.append((r, r["update_groups"], int(r["updates_since_f0"])))
    return res


def continuation_factorial(out: dict, design: dict):
    """v41: the paired 2x2 of the keep continuation (masks retained / released x optimizer carried / reset), within
    the forks of one parent trajectory (same draw, optimizer seed, partition seed, update); test error.
      reset_vs_carry | masks M     = err(M, carried) - err(M, reset)
      release_vs_retain | optim O  = err(retained, O) - err(released, O)
      interaction                  = (reset_vs_carry | released) - (reset_vs_carry | retained)
                                   = (release_vs_retain | reset) - (release_vs_retain | carried)
    positive = the named change lowers test error.  design: variant -> the fork settings the manifest holds (a
    partner the design holds but the results lack is flagged, never dropped silently).
    -> (by_setting, by_draw, summary, missing, duplicates)."""
    tab = defaultdict(lambda: defaultdict(list))
    for r, msr, upd in factorial_measures(out):
        g = (r["cell"], r["variant"], r["parent"], r["data_draw"], r["optimizer_seed"], r["partition_seed"],
             r["draw_set"], msr, str(upd))
        tab[g][(r["fork_masks"], r["fork_optimizer"])].append(r["test_err"])
    E_ = lambda c, m, o: c.get((m, o))
    by_setting, missing, dups = [], [], []
    for g, cell in sorted(tab.items(), key=lambda t: tuple(map(str, t[0]))):
        for st_, v in cell.items():
            if len(v) != 1:
                dups.append({"key": list(map(str, g)), "setting": list(st_), "n": len(v)})
        c = {k: v[0] for k, v in cell.items()}
        want_ = design.get(g[1], set())
        lack = sorted(want_ - set(c))
        if lack:
            missing.append({"key": list(map(str, g)), "missing_settings": [list(x) for x in lack]})
        eff = {}
        for m in ("released", "retained"):
            a_, b_ = E_(c, m, "carry_from_parent"), E_(c, m, "reset_each_phase")
            if a_ is not None and b_ is not None:
                eff[f"reset_vs_carry | masks {m}"] = a_ - b_
        for o, oname in (("reset_each_phase", "reset"), ("carry_from_parent", "carried")):
            a_, b_ = E_(c, "retained", o), E_(c, "released", o)
            if a_ is not None and b_ is not None:
                eff[f"release_vs_retain | optimizer {oname}"] = a_ - b_
        if "reset_vs_carry | masks released" in eff and "reset_vs_carry | masks retained" in eff:
            eff["interaction"] = eff["reset_vs_carry | masks released"] - eff["reset_vs_carry | masks retained"]
        for name, v in eff.items():
            by_setting.append({**dict(zip(("cell", "variant", "parent", "data_draw", "optimizer_seed",
                                           "partition_seed", "draw_set", "measure", "update"), g)),
                               "effect": name, "test_err_difference": v, "sign": FACTORIAL_SIGN,
                               **{f"test_err[{m},{o}]": x for (m, o), x in sorted(c.items())}})
    bd, sm = two_stage(by_setting, ("cell", "variant", "draw_set", "measure", "update", "effect"),
                       "test_err_difference")
    for r in sm:
        r["sign"] = FACTORIAL_SIGN
    return by_setting, bd, sm, missing, dups


def paired_vs(rows: list, match: tuple, side_key: str, ref_val, val_name: str, ref_name: str):
    """rows (setting-level): pair each row whose side_key != ref_val with the row of the same `match` key whose
    side_key == ref_val; value = ref err - row err (positive = the row's arm has the lower test error).  A ref
    shared by several arms is used once per arm (shared, not replicated).  v43: a duplicated reference key keeps
    its FIRST row and is counted (never silently overwritten); callers fail coverage on any.
    -> (pairs, missing, duplicates)."""
    ref, dup = {}, 0
    for r in rows:
        if r[side_key] == ref_val:
            k_ = tuple(r[k] for k in match)
            if k_ in ref:
                dup += 1
                continue
            ref[k_] = r
    pairs, miss = [], 0
    for r in rows:
        if r[side_key] == ref_val:
            continue
        p = ref.get(tuple(r[k] for k in match))
        miss += p is None
        pairs.append({**r, ref_name: None if p is None else p["test_err"],
                      val_name: (p["test_err"] - r["test_err"]) if p is not None else None,
                      "reference_run_ids": None if p is None else p.get("run_ids"),
                      "partner_missing": p is None})
    return pairs, miss, dup


def c1_contrasts(rows: list, what: str, design_jobs: set, ref_name: str, val_name: str):
    """v43: every non-C1 setting row against C1's final state with the same `what` (code, components, measure),
    data draw and optimizer seed, SEPARATELY for each C1 variant the design holds (compact, compact_scfrozen, ...);
    each row carries reference_variant / reference_arm / reference_state / reference_run_ids.  A partner the design
    holds (a C1 job of that variant at that cell, draw and seed) but the results lack is missing; one the design
    does not hold is noncomparable.  -> (pairs, {missing, duplicates, noncomparable})."""
    c1v = sorted({k[0] for k in design_jobs if k[1] == "C1"} or
                 {r["variant"] for r in rows if r["arm"] == "C1" and r["state"] == "C1_final"}, key=str)
    out, cnt = [], {"missing": 0, "duplicates": 0, "noncomparable": 0}
    for cv in c1v:
        sel = [r for r in rows if r["arm"] != "C1" or (r["variant"] == cv and r["state"] == "C1_final")]
        pr_, _, dup = paired_vs(sel, ("cell", what, "data_draw", "optimizer_seed"), "arm", "C1", val_name, ref_name)
        cnt["duplicates"] += dup
        for r in pr_:
            if r["arm"] == "C1":
                continue
            held = any(k[0] == cv and k[1] == "C1" and k[3] == r["cell"] and k[4] == r["data_draw"]
                       and k[5] == r["optimizer_seed"] for k in design_jobs) if design_jobs else True
            if r["partner_missing"]:
                cnt["missing" if held else "noncomparable"] += 1
                if not held:
                    continue
            out.append({**r, "reference_variant": cv, "reference_arm": "C1", "reference_state": "C1_final"})
    return out, cnt


VARIANT_PAIRS = (("fixed", "redrawn"), ("fixed", "fixed_scfrozen"), ("compact", "compact_scfrozen"),
                 ("fixed", "fixed_dsfrozen"), ("compact", "compact_dsfrozen_lift"))         # v44: the last two


def variant_pairs(rows: list, what: str, design_jobs: set = frozenset()):
    """v41/v42/v43: each VARIANT_PAIRS (A, B): the same arm, removal variant, state and `what` (components,
    measure) in both variants, paired by draw and optimizer seed; value = err(B) - err(A) (positive = A has the
    lower test error).  v43: the (arm, removal variant) cells come from the design (both variants hold that arm),
    and a row's partner is REQUIRED when the design holds the partner job (same cell, draw and seed): absent, it
    is missing (either side); a partner the design does not hold is noncomparable; duplicates are counted.
    -> (pairs, summary, {missing, noncomparable, duplicates})."""
    pairs, summ = [], []
    cnt = {"missing": 0, "noncomparable": 0, "duplicates": 0}
    for A, B in VARIANT_PAIRS:
        if design_jobs:
            cells = {(k[1], k[2]) for k in design_jobs if k[0] == A} & {(k[1], k[2]) for k in design_jobs if k[0] == B}
        else:
            ca = {(r["arm"], r["removal_variant"]) for r in rows if r["variant"] == A}
            cells = ca & {(r["arm"], r["removal_variant"]) for r in rows if r["variant"] == B}
        sel = [r for r in rows if r["variant"] in (A, B) and (r["arm"], r["removal_variant"]) in cells]
        if not sel:
            continue
        key = lambda r: (r["cell"], r["arm"], r["removal_variant"], r["state"], r[what], r["data_draw"],
                         r["optimizer_seed"])
        held = lambda v, r: (not design_jobs) or (v, r["arm"], r["removal_variant"], r["cell"], r["data_draw"],
                                                  r["optimizer_seed"]) in design_jobs
        side = {A: {}, B: {}}
        for r in sel:
            k = key(r)
            if k in side[r["variant"]]:
                cnt["duplicates"] += 1
                continue
            side[r["variant"]][k] = r
        vn = f"{A}_vs_{B}"
        pr = []
        for k, ra in side[A].items():
            rb = side[B].get(k)
            if rb is None:
                cnt["missing" if held(B, ra) else "noncomparable"] += 1
                continue
            pr.append({**ra, f"{B}_test_err": rb["test_err"], "value": rb["test_err"] - ra["test_err"],
                       "reference_variant": B, "reference_run_ids": rb.get("run_ids"), "partner_missing": False,
                       "contrast": vn, "sign": f"positive = {A} has the lower test error"})
        for k, rb in side[B].items():
            if k not in side[A]:
                cnt["missing" if held(A, rb) else "noncomparable"] += 1
        _, sm = two_stage(pr, ("cell", "arm", "removal_variant", "state", what, "contrast"), "value")
        pairs += pr
        summ += sm
    return pairs, summ, cnt


# v43: declared contrasts.  value = err(B) - err(A): positive = A has the lower test error.  Endpoint contrasts
# pair the named states of two arms (same cell, data draw, optimizer seed); trace contrasts pair two arms' states at
# the end of the expansion (the trajectory's end and a compact arm's checkpoint at the same update, '2U'); within-
# job contrasts pair two states of one job.  Every arm a registry names must be in the manifest, and every
# (cell, draw, seed) the manifest holds for either side needs both values for every measure (else coverage fails).
COMPONENTS = ("shortcut+causal+noise+bias", "causal", "shortcut", "shortcut+causal")
REGISTRIES = {"wave23": [
    # the frozen lineage: lift the shortcut freeze for the removal, or keep it
    ("release_vs_remain_frozen", "endpoint", ("fixed_scfrozen", "treated", "repaired"),
     ("fixed_scfrozen", "treated_frozen", "repaired")),
    ("compact_release_vs_remain_frozen", "endpoint", ("compact_scfrozen_lift", "C1_phase", "C1_phase_final"),
     ("compact_scfrozen", "C1_phase", "C1_phase_final")),
    # frozen against ordinary expansion
    ("frozen_vs_ordinary_expansion_removal", "endpoint", ("fixed_scfrozen", "treated", "repaired"),
     ("fixed", "treated", "repaired")),
    ("frozen_vs_ordinary_expansion_keep", "endpoint", ("fixed_scfrozen", "keep", "kept_end"),
     ("fixed", "keep", "kept_end")),
    # the compact optimizer schedules
    ("compact_single_reset_vs_carry", "endpoint", ("compact", "C1_reset", "C1_reset_final"),
     ("compact", "C1", "C1_final")),
    ("compact_two_resets_vs_carry", "endpoint", ("compact", "C1_phase", "C1_phase_final"),
     ("compact", "C1", "C1_final")),
    ("compact_two_resets_vs_single_reset", "endpoint", ("compact", "C1_phase", "C1_phase_final"),
     ("compact", "C1_reset", "C1_reset_final")),
    ("compact_frozen_vs_ordinary_two_resets", "endpoint", ("compact_scfrozen", "C1_phase", "C1_phase_final"),
     ("compact", "C1_phase", "C1_phase_final")),
    # each expanded schedule against the compact control with the same freeze and reset schedule
    ("expansion_vs_matched_compact_removal", "endpoint", ("fixed", "treated", "repaired"),
     ("compact", "C1_phase", "C1_phase_final")),
    ("expansion_vs_matched_compact_keep", "endpoint", ("fixed", "keep", "kept_end"),
     ("compact", "C1_reset", "C1_reset_final")),
    ("frozen_expansion_lifted_vs_matched_compact", "endpoint", ("fixed_scfrozen", "treated", "repaired"),
     ("compact_scfrozen_lift", "C1_phase", "C1_phase_final")),
    ("frozen_expansion_kept_vs_matched_compact", "endpoint", ("fixed_scfrozen", "treated_frozen", "repaired"),
     ("compact_scfrozen", "C1_phase", "C1_phase_final")),
    # at the end of the expansion (2U), before the schedules diverge
    ("frozen_vs_ordinary_trajectory_at_2U", "trace", ("fixed_scfrozen", "trajectory"), ("fixed", "trajectory")),
    ("ordinary_trajectory_vs_compact_at_2U", "trace", ("fixed", "trajectory"), ("compact", "C1")),
    ("frozen_trajectory_vs_frozen_compact_at_2U", "trace", ("fixed_scfrozen", "trajectory"),
     ("compact_scfrozen", "C1")),
    # within a lineage: the repaired state against the start of the removal (its trajectory's end)
    ("repair_change_ordinary", "within_job", ("fixed", "treated", "repaired"), ("fixed", "treated", "abrupt")),
    ("repair_change_frozen_lifted", "within_job", ("fixed_scfrozen", "treated", "repaired"),
     ("fixed_scfrozen", "treated", "abrupt")),
    ("repair_change_frozen_kept", "within_job", ("fixed_scfrozen", "treated_frozen", "repaired"),
     ("fixed_scfrozen", "treated_frozen", "abrupt")),
]}
# v44 (wave 24): the downstream-frozen expansion (the additions and the first layer train; layers 2 to 5 stay f0's)
# and the extraction rule (at the end of the expansion: delete the additions, keep the first layer, restore every
# other layer to f0, i.e. code 0-1-1-1-1 on the abrupt state).  'cross_measure' pairs two named measures of two arms
# (same cell, draw, seed): (variant, arm, state, table, value) with table codes / codes_implants / native / scale /
# trace_codes (a compact or trajectory checkpoint at 2U, state unused)
XR = lambda v: (v, "treated", "abrupt", "codes", "0-1-1-1-1")        # the extraction rule on a lineage
REGISTRIES["wave24"] = [
    # at the end of the expansion (2U)
    ("dsfrozen_vs_ordinary_trajectory_at_2U", "trace", ("fixed_dsfrozen", "trajectory"), ("fixed", "trajectory")),
    ("ordinary_trajectory_vs_compact_at_2U", "trace", ("fixed", "trajectory"), ("compact", "C1")),
    ("dsfrozen_trajectory_vs_dsfrozen_compact_at_2U", "trace", ("fixed_dsfrozen", "trajectory"),
     ("compact_dsfrozen_lift", "C1_reset")),
    ("dsfrozen_compact_vs_compact_at_2U", "trace", ("compact_dsfrozen_lift", "C1_reset"), ("compact", "C1")),
    # endpoints: downstream-frozen against ordinary expansion (the freeze lifted for the removal / keep)
    ("dsfrozen_vs_ordinary_expansion_removal", "endpoint", ("fixed_dsfrozen", "treated", "repaired"),
     ("fixed", "treated", "repaired")),
    ("dsfrozen_vs_ordinary_expansion_keep", "endpoint", ("fixed_dsfrozen", "keep", "kept_end"),
     ("fixed", "keep", "kept_end")),
    # each expanded schedule against the compact control with the same freeze and reset schedule
    ("expansion_vs_matched_compact_removal", "endpoint", ("fixed", "treated", "repaired"),
     ("compact", "C1_phase", "C1_phase_final")),
    ("expansion_vs_matched_compact_keep", "endpoint", ("fixed", "keep", "kept_end"),
     ("compact", "C1_reset", "C1_reset_final")),
    ("dsfrozen_expansion_vs_matched_compact_removal", "endpoint", ("fixed_dsfrozen", "treated", "repaired"),
     ("compact_dsfrozen_lift", "C1_phase", "C1_phase_final")),
    ("dsfrozen_expansion_vs_matched_compact_keep", "endpoint", ("fixed_dsfrozen", "keep", "kept_end"),
     ("compact_dsfrozen_lift", "C1_reset", "C1_reset_final")),
    # the compact controls: the downstream freeze for 2U, then released, against none
    ("compact_dsfrozen_vs_ordinary_two_resets", "endpoint", ("compact_dsfrozen_lift", "C1_phase", "C1_phase_final"),
     ("compact", "C1_phase", "C1_phase_final")),
    ("compact_dsfrozen_vs_ordinary_single_reset", "endpoint", ("compact_dsfrozen_lift", "C1_reset", "C1_reset_final"),
     ("compact", "C1_reset", "C1_reset_final")),
    ("compact_single_reset_vs_carry", "endpoint", ("compact", "C1_reset", "C1_reset_final"),
     ("compact", "C1", "C1_final")),
    ("compact_two_resets_vs_carry", "endpoint", ("compact", "C1_phase", "C1_phase_final"),
     ("compact", "C1", "C1_final")),
    # within a lineage: the repaired state against the start of the removal
    ("repair_change_ordinary", "within_job", ("fixed", "treated", "repaired"), ("fixed", "treated", "abrupt")),
    ("repair_change_dsfrozen", "within_job", ("fixed_dsfrozen", "treated", "repaired"),
     ("fixed_dsfrozen", "treated", "abrupt")),
] + [c for v, tag, cv, ca in (("fixed_dsfrozen", "dsfrozen", "compact_dsfrozen_lift", "C1_reset"),
                              ("fixed", "ordinary", "compact", "C1"))
     for c in (
    # the extraction rule against: removal and repair of the same lineage; the expanded network itself (additions
    # present); f0; the compact control's extraction at 2U and at its endpoint; the oracle rescaling controls
    (f"extraction_vs_repaired_native_{tag}", "cross_measure", XR(v),
     (v, "treated", "repaired", "native", "native_endpoint")),
    (f"extraction_vs_expanded_native_{tag}", "cross_measure", XR(v),
     (v, "treated", "abrupt", "codes_implants", "0-0-0-0-0")),
    (f"extraction_vs_f0_{tag}", "cross_measure", XR(v), (v, "treated", "abrupt", "codes", "1-1-1-1-1")),
    (f"extraction_vs_compact_extraction_at_2U_{tag}", "cross_measure", XR(v),
     (cv, ca, None, "trace_codes", "0-1-1-1-1")),
    (f"extraction_vs_compact_endpoint_native_{tag}", "cross_measure", XR(v),
     (cv, "C1_phase", "C1_phase_final", "native", "native_endpoint")),
    (f"extraction_vs_causal_scale_selected_{tag}", "cross_measure", XR(v),
     (v, "treated", "abrupt", "scale", "f0_causal_scale_selected")),
    (f"extraction_vs_causal_shortcut_scale_selected_{tag}", "cross_measure", XR(v),
     (v, "treated", "abrupt", "scale", "f0_causal_shortcut_scale_selected")))]

# v45 (wave 25): the freezing factorial.  Every extraction is the same operation at the same point: at 2U, the first
# layer kept whole (its bias too), layers 2 to 5 restored to f0, the additions deleted: code 0-1-1-1-1 on the
# expansion's abrupt state (its trajectory's end) and on the compact control's at_2U checkpoint.  'interaction'
# takes two (A, B) cross_measure pairs: value = (err(B1) - err(A1)) - (err(B2) - err(A2)).
V45_VAR = {"A": "A_free", "B": "B_scfrozen", "C": "C_dsfrozen", "D": "D_bothfrozen"}
_X1, _F0, _Z = "0-1-1-1-1", "1-1-1-1-1", "0-0-0-0-0"
EXT = lambda k: (V45_VAR[k], "treated", "abrupt", "codes", _X1)          # the expansion's extraction
CEXT = lambda k: (f"compact_{k}", "C1_phase", None, "trace_codes", _X1)    # the compact control's, at 2U
REGISTRIES["wave25"] = [
    # primary 1 (confirmation): the v43 recipe against the identically extracted shortcut-frozen compact control,
    # and against f0
    ("P1_B_extraction_vs_compact_B_extraction", "cross_measure", EXT("B"), CEXT("B")),
    ("P1_B_extraction_vs_f0", "cross_measure", EXT("B"), (V45_VAR["B"], "treated", "abrupt", "codes", _F0)),
    # primary 2 (mechanism): (B expansion gain - B compact gain) - (D expansion gain - D compact gain); the gains are
    # against the same f0, which cancels within a draw
    ("P2_interaction_B_minus_D", "interaction", (EXT("B"), CEXT("B")), (EXT("D"), CEXT("D"))),
] + [c for k in "ACD" for c in (
    (f"S_{k}_extraction_vs_compact_{k}_extraction", "cross_measure", EXT(k), CEXT(k)),
    (f"S_{k}_extraction_vs_f0", "cross_measure", EXT(k), (V45_VAR[k], "treated", "abrupt", "codes", _F0)))] + [
    ("S_interaction_A_minus_C", "interaction", (EXT("A"), CEXT("A")), (EXT("C"), CEXT("C"))),
    ("S_interaction_B_minus_A", "interaction", (EXT("B"), CEXT("B")), (EXT("A"), CEXT("A"))),
    ("S_interaction_D_minus_C", "interaction", (EXT("D"), CEXT("D")), (EXT("C"), CEXT("C"))),
] + [c for k in "ABCD" for c in (
    (f"S_compact_{k}_extraction_vs_f0", "cross_measure", CEXT(k),
     (f"compact_{k}", "C1_phase", None, "trace_codes", _F0)),
    # the expanded network itself and the trained backbone without its additions, against the extraction
    (f"S_{k}_extraction_vs_expanded_with_additions", "cross_measure", EXT(k),
     (V45_VAR[k], "treated", "abrupt", "codes_implants", _Z)),
    (f"S_{k}_extraction_vs_extraction_with_additions", "cross_measure", EXT(k),
     (V45_VAR[k], "treated", "abrupt", "codes_implants", _X1)),
    # secondary, a different procedure: both holds lifted at 2U, removal and repair, against the compact control
    # released at 2U with the same optimizer resets (freeze-released endpoints only)
    (f"S_{k}_repaired_vs_compact_{k}_endpoint", "endpoint", (V45_VAR[k], "treated", "repaired"),
     (f"compact_{k}", "C1_phase", "C1_phase_final")),
    (f"S_{k}_extraction_vs_repaired_native", "cross_measure", EXT(k),
     (V45_VAR[k], "treated", "repaired", "native", "native_endpoint")),
    # the first-layer components at 2U, expansion against its compact control
    (f"S_{k}_components_vs_compact_{k}_at_2U", "trace", (V45_VAR[k], "trajectory"), (f"compact_{k}", "C1_phase")))]
# v53 (wave 26): what drives the expansion's drift.  Arms {A, B} x {routed, all} x {relu, affine} and the routed relu
# arm at 0.3 x the learning rate; compact controls trained for 4U (compact_A, compact_B, and both at the lower
# rate).  One extraction throughout (code 0-1-1-1-1): on an expansion's abrupt state (2U), on a compact control's
# at_2U checkpoint and on its endpoint (4U).  value = err(B) - err(A); positive = A has the lower test error.
_E26 = lambda v: (v, "treated", "abrupt", "codes", _X1)                 # an expansion's extraction at 2U
_N26 = lambda v: (v, "treated", "abrupt", "codes_implants", _Z)          # the expanded network itself at 2U
_C26 = lambda c: (c, "C1", None, "trace_codes", _X1)                    # a compact control's extraction at 2U
_CL26 = lambda c: (c, "C1", "C1_final", "codes", _X1)                   # the same at its endpoint (4U)
V53_LR = "lr0.3"
REGISTRIES["wave26"] = [c for h in "AB" for v in (f"{h}_routed_relu", f"{h}_routed_affine", f"{h}_all_relu",
                                                  f"{h}_all_affine", f"{h}_routed_relu_{V53_LR}")
                        for cp in (f"compact_{h}" + (f"_{V53_LR}" if v.endswith(V53_LR) else ""),) for c in (
    (f"S_{v}_extraction_vs_f0", "cross_measure", _E26(v), (v, "treated", "abrupt", "codes", _F0)),
    (f"S_{v}_extraction_vs_{cp}_extraction_at_2U", "cross_measure", _E26(v), _C26(cp)),
    (f"S_{v}_extraction_vs_{cp}_extraction_at_4U", "cross_measure", _E26(v), _CL26(cp)),
    (f"S_{v}_extraction_vs_expanded_with_additions", "cross_measure", _E26(v), _N26(v)),
    (f"S_{v}_extraction_vs_repaired_native", "cross_measure", _E26(v),
     (v, "treated", "repaired", "native", "native_endpoint")))] + [c for h in "AB" for c in (
    # the two crossed factors, on the extraction and on the expanded network itself
    *[(f"F_{h}_affine_vs_relu_given_{r}_{w}", "cross_measure", f_(f"{h}_{r}_affine"), f_(f"{h}_{r}_relu"))
      for r in ("routed", "all") for w, f_ in (("extraction", _E26), ("expanded", _N26))],
    *[(f"F_{h}_all_vs_routed_given_{a_}_{w}", "cross_measure", f_(f"{h}_all_{a_}"), f_(f"{h}_routed_{a_}"))
      for a_ in ("relu", "affine") for w, f_ in (("extraction", _E26), ("expanded", _N26))],
    (f"F_{h}_interaction_act_by_route_extraction", "interaction",
     (_E26(f"{h}_routed_affine"), _E26(f"{h}_routed_relu")), (_E26(f"{h}_all_affine"), _E26(f"{h}_all_relu"))),
    # the lower learning rate: the routed relu arm against itself, and its excess over the matched compact control
    (f"L_{h}_{V53_LR}_vs_lr1_extraction", "cross_measure", _E26(f"{h}_routed_relu_{V53_LR}"),
     _E26(f"{h}_routed_relu")),
    (f"L_{h}_interaction_excess_over_compact_lr1_minus_{V53_LR}", "interaction",
     (_E26(f"{h}_routed_relu"), _C26(f"compact_{h}")),
     (_E26(f"{h}_routed_relu_{V53_LR}"), _C26(f"compact_{h}_{V53_LR}"))))] + [
    # holding the shortcut column, within each arm
    (f"H_{s_}_B_vs_A_extraction", "cross_measure", _E26(f"B_{s_}"), _E26(f"A_{s_}"))
    for s_ in ("routed_relu", "routed_affine", "all_relu", "all_affine", f"routed_relu_{V53_LR}")] + [
    c for cp in ("compact_A", "compact_B", f"compact_A_{V53_LR}", f"compact_B_{V53_LR}") for c in (
        (f"S_{cp}_extraction_at_2U_vs_f0", "cross_measure", _C26(cp), (cp, "C1", None, "trace_codes", _F0)),
        (f"S_{cp}_extraction_at_4U_vs_at_2U", "cross_measure", _CL26(cp), _C26(cp)))]
# v57 (wave 27): which part of routing matters.  Arms {A, B} x {routed, param, all} with relu additions (routed and
# all are wave 26's arms; param is the parameter-only mask route) and the compact controls compact_A, compact_B.
# The same extraction and sign as wave 26.
REGISTRIES["wave27"] = [c for h in "AB" for v in (f"{h}_routed_relu", f"{h}_param_relu", f"{h}_all_relu")
                        for c in (
    (f"S_{v}_extraction_vs_f0", "cross_measure", _E26(v), (v, "treated", "abrupt", "codes", _F0)),
    (f"S_{v}_extraction_vs_compact_{h}_extraction_at_2U", "cross_measure", _E26(v), _C26(f"compact_{h}")),
    (f"S_{v}_extraction_vs_compact_{h}_extraction_at_4U", "cross_measure", _E26(v), _CL26(f"compact_{h}")),
    (f"S_{v}_extraction_vs_expanded_with_additions", "cross_measure", _E26(v), _N26(v)))] + [
    # the route, on the extraction and on the expanded network itself (first named arm minus second: positive =
    # the first has the lower test error)
    (f"R_{h}_{a_}_vs_{b_}_{w}", "cross_measure", f_(f"{h}_{a_}_relu"), f_(f"{h}_{b_}_relu"))
    for h in "AB" for a_, b_ in (("param", "routed"), ("param", "all"), ("routed", "all"))
    for w, f_ in (("extraction", _E26), ("expanded", _N26))] + [
    (f"H_{s_}_B_vs_A_extraction", "cross_measure", _E26(f"B_{s_}"), _E26(f"A_{s_}"))
    for s_ in ("routed_relu", "param_relu", "all_relu")] + [
    (f"S_{cp}_extraction_at_2U_vs_f0", "cross_measure", _C26(cp), (cp, "C1", None, "trace_codes", _F0))
    for cp in ("compact_A", "compact_B")]
# v46: the cohort each registry is read on, recorded apart from the manifest's draw role (the jobs keep their
# 'exploratory' draw role: changing it would change every run id).  P1 and P2 are the prespecified comparisons;
# everything else, the full code map and the other tables included, is secondary or exploratory.
REGISTRY_COHORT = {"wave25": "fresh-draw confirmation cohort: data draws 325-336 (unused before v45), P1 and P2 fixed "
                             "before the run",
                   "wave26": "data draws 337-348 (unused before v53).  Two primary contrasts, on the arm that repeats "
                             "wave 25's B arm (B_routed_relu): its extraction against f0 and against the matched "
                             "compact control's extraction at 2U.  Named in v54, after the panel was launched and "
                             "before any wave-26 result was read; every other contrast is secondary"}
REGISTRY_COHORT["wave27"] = ("data draws 337-348, wave 26's (its f0, routed and all arms and compact controls are "
                             "wave 26's own jobs, not new evidence).  New: the parameter-route arms.  Two primary "
                             "contrasts, named before any wave-27 job ran: the held-shortcut parameter-route arm's "
                             "extraction against f0 and against the held-shortcut gradient-route arm's extraction; "
                             "every other contrast is secondary")
REGISTRY_PRIMARY = {"wave25": {"P1_B_extraction_vs_compact_B_extraction", "P1_B_extraction_vs_f0",
                               "P2_interaction_B_minus_D"},
                    "wave27": {"S_B_param_relu_extraction_vs_f0", "R_B_param_vs_routed_extraction"},
                    "wave26": {"S_B_routed_relu_extraction_vs_f0",
                               "S_B_routed_relu_extraction_vs_compact_B_extraction_at_2U"}}


def registry_contrasts(name: str, out: dict, design_jobs: set, fork_u):
    """v43: the declared contrasts of REGISTRIES[name] on the native endpoints (endpoint contrasts) and the
    first-layer components (every kind).  -> (by_setting, by_draw, summary, problems)."""
    rows, problems = [], []

    def design_keys(variant, arm):
        if arm == "trajectory":           # a trajectory's (cell, draw, seed): its removal children's
            return {(k[3], k[4], k[5]) for k in design_jobs if k[0] == variant and k[2] not in ("control", None)}
        return {(k[3], k[4], k[5]) for k in design_jobs if k[0] == variant and k[1] == arm}

    def side(kind, spec):
        """-> {(cell, draw, seed, measure[, run]): (err, run_id)} and the duplicate keys."""
        got, dup = {}, []
        if kind == "cross_measure":
            variant, arm, state, table, val = spec
            col = {"codes": "code", "codes_implants": "code", "native": "measure", "scale": "control",
                   "trace_codes": "code"}[table]
            src = [(r, "cross") for r in out.get("trace" if table == "trace_codes" else table, [])
                   if r["variant"] == variant and r["arm"] == arm and r[col] == val
                   and (r["updates_since_f0"] == fork_u if table == "trace_codes" else r["state"] == state)]
        elif kind == "trace":
            variant, arm = spec
            src = [(r, r["update_groups"]) for r in out.get("decomposition_trace", [])
                   if r["variant"] == variant and r["arm"] == arm and r["update_groups"] in COMPONENTS
                   and fork_u is not None and r["updates_since_f0"] == fork_u]
        else:
            variant, arm, state = spec
            src = [(r, r["update_groups"]) for r in out.get("decomposition", [])
                   if r["variant"] == variant and r["arm"] == arm and r["state"] == state
                   and r["update_groups"] in COMPONENTS]
            if kind == "endpoint":
                src += [(r, "native") for r in out.get("native", [])
                        if r["variant"] == variant and r["arm"] == arm and r["state"] == state]
        for r, msr in src:
            k = (r["cell"], r["data_draw"], r["optimizer_seed"], msr) + ((r["run_id"],) if kind == "within_job" else ())
            if k in got:
                dup.append(k)
                continue
            got[k] = (r["test_err"], r["run_id"], r.get("draw_set"))
        return got, dup

    prim = REGISTRY_PRIMARY.get(name, set())
    cohort = REGISTRY_COHORT.get(name, "")
    for cname, kind, A, B in REGISTRIES[name]:
        role = "primary" if cname in prim else ("secondary" if prim else "declared")
        if kind == "interaction":
            # v45: two (A, B) cross_measure pairs on the same (cell, draw, seed)
            sides = [A[0], A[1], B[0], B[1]]
            ks = [design_keys(s_[0], s_[1]) for s_ in sides]
            if not all(ks):
                problems.append({"contrast": cname, "problem": "a side has no job in the manifest"})
                continue
            if fork_u is None:
                problems.append({"contrast": cname, "problem": "no unique expansion length (2U) in the manifest"})
                continue
            gs = []
            for s_ in sides:
                g_, d_ = side("cross_measure", s_)
                for k in d_:
                    problems.append({"contrast": cname, "problem": "duplicate", "key": list(map(str, k))})
                gs.append(g_)
            for c, d, s_ in sorted(set.union(*ks), key=lambda t: tuple(map(str, t))):
                k = (c, d, s_, "cross")
                v = [g_.get(k) for g_ in gs]
                if any(x is None for x in v):
                    problems.append({"contrast": cname, "problem": "missing", "key": list(map(str, k)),
                                     "side": ",".join(n_ for n_, x in zip(("A1", "B1", "A2", "B2"), v) if x is None)})
                    continue
                d1, d2 = v[1][0] - v[0][0], v[3][0] - v[2][0]
                rows.append({"contrast": cname, "kind": kind, "role": role, "cohort": cohort,
                             "measure": "(B1 - A1) - (B2 - A2), test error", "cell": c, "data_draw": d,
                             "optimizer_seed": s_, "a": " | ".join("/".join(map(str, x)) for x in A),
                             "b": " | ".join("/".join(map(str, x)) for x in B),
                             "a_test_err": v[0][0], "b_test_err": v[1][0], "a2_test_err": v[2][0],
                             "b2_test_err": v[3][0], "first_difference": d1, "second_difference": d2,
                             "value": d1 - d2, "a_run_id": v[0][1], "b_run_id": v[1][1], "a2_run_id": v[2][1],
                             "b2_run_id": v[3][1], "draw_set": v[0][2],
                             "sign": "positive = the first pair's A gains more over its B than the second pair's"})
            continue
        ka, kb = design_keys(A[0], A[1]), design_keys(B[0], B[1])
        if not ka or not kb:
            problems.append({"contrast": cname, "problem": "a side has no job in the manifest"})
            continue
        if kind in ("trace", "cross_measure") and fork_u is None:
            problems.append({"contrast": cname, "problem": "no unique expansion length (2U) in the manifest"})
            continue
        ga, da = side(kind, A)
        gb, db = side(kind, B)
        for k in da + db:
            problems.append({"contrast": cname, "problem": "duplicate", "key": list(map(str, k))})
        msrs = ("cross",) if kind == "cross_measure" else (("native",) if kind == "endpoint" else ()) + COMPONENTS
        if kind == "within_job":
            req = {(k[0], k[1], k[2], m, k[4]) for k in list(ga) + list(gb) for m in msrs}
            have = {(k[0], k[1], k[2]) for k in list(ga) + list(gb)}
            for c, d, s_ in sorted(ka - have, key=lambda t: tuple(map(str, t))):
                problems.append({"contrast": cname, "problem": "missing", "key": [str(c), str(d), str(s_)]})
        else:
            req = {(c, d, s_, m) for c, d, s_ in ka | kb for m in msrs}
        for k in sorted(req, key=lambda t: tuple(map(str, t))):
            va, vb = ga.get(k), gb.get(k)
            if va is None or vb is None:
                problems.append({"contrast": cname, "problem": "missing", "key": list(map(str, k)),
                                 "side": "A" if va is None else "B"})
                continue
            rows.append({"contrast": cname, "kind": kind, "role": role, "cohort": cohort,
                         "measure": k[3] if kind != "cross_measure" else
                         f"{A[3]}:{A[4]} vs {B[3]}:{B[4]}", "cell": k[0], "data_draw": k[1],
                         "optimizer_seed": k[2], "a": "/".join(map(str, A)), "b": "/".join(map(str, B)),
                         "a_test_err": va[0], "b_test_err": vb[0], "value": vb[0] - va[0],
                         "a_run_id": va[1], "b_run_id": vb[1], "draw_set": va[2],
                         "sign": "positive = A has the lower test error"})
    bd, sm = two_stage(rows, ("contrast", "kind", "role", "cohort", "measure", "a", "b", "cell"), "value")
    return rows, bd, sm, problems


def design_key(cfg: dict) -> tuple:
    """v43: (variant, arm, removal variant, cell, data draw, optimizer seed) of an eligible job's config."""
    des = cfg.get("design") or {}
    return (des.get("variant"), des.get("arm"), eligible(cfg)[1], (des.get("contrast") or "").split("|")[-1],
            (cfg.get("data") or {}).get("data_seed"), (cfg.get("seeds") or {}).get("optimizer"))


def levels(rs, what):
    """partition seeds averaged within (data draw, optimizer setting); settings averaged within each data draw;
    the summary over UNIQUE data draws.  -> (per setting, per draw, summary)."""
    gk = ("cell", "variant", "arm", "removal_variant", "state", what, "draw_set")
    by_set = defaultdict(lambda: defaultdict(list))
    for r in rs:
        by_set[tuple(r[k] for k in gk)][(r["data_draw"], r["optimizer_seed"])].append(r)
    setting_rows, draw_rows, summ = [], [], []
    for k, sets in sorted(by_set.items(), key=lambda t: tuple(map(str, t[0]))):
        met = [x for x in next(iter(sets.values()))[0] if x.endswith("_err") or x.endswith("flip_rate")]
        per_draw = defaultdict(list)
        for (ds, os_), rr in sorted(sets.items(), key=lambda t: tuple(map(str, t[0]))):
            m = {x: sum(r[x] for r in rr) / len(rr) for x in met}
            setting_rows.append({**dict(zip(gk, k)), "data_draw": ds, "optimizer_seed": os_, "n_runs": len(rr),
                                 "run_ids": " ".join(sorted(str(r.get("run_id", "")) for r in rr)), **m})
            per_draw[ds].append((os_, m))
        dms = []
        for ds, lst in sorted(per_draw.items(), key=lambda t: str(t[0])):
            m = {x: sum(v[x] for _, v in lst) / len(lst) for x in met}
            m["test_gain_vs_f0"] = m["f0_test_err"] - m["test_err"]
            dms.append(m)
            draw_rows.append({**dict(zip(gk, k)), "data_draw": ds,
                              "optimizer_settings": " ".join(str(o) for o, _ in lst), **m})
        n = len(dms)
        gains = [m["test_gain_vs_f0"] for m in dms]
        mu = sum(gains) / n
        sd = (sum((x - mu) ** 2 for x in gains) / (n - 1)) ** 0.5 if n > 1 else None
        t = T95.get(n - 1, 2.0) if n > 1 else None
        summ.append({**dict(zip(gk, k)), "n_unique_data_draws": n,
                     "settings_per_draw": " ".join(sorted({str(len(v)) for v in per_draw.values()})),
                     "n_runs": sum(len(v) for v in sets.values()),
                     "draws_beating_f0_test": f"{sum(g > 0 for g in gains)}/{n}",
                     "mean_test_gain_vs_f0": mu,
                     "gain_ci95_low": mu - t * sd / n ** 0.5 if sd is not None else None,
                     "gain_ci95_high": mu + t * sd / n ** 0.5 if sd is not None else None,
                     **{f"mean_{x}": sum(mm[x] for mm in dms) / n for x in met}})
    return setting_rows, draw_rows, summ


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("results")
    ap.add_argument("out_prefix")
    ap.add_argument("--manifest", default=None)
    ap.add_argument("--strict", action="store_true", help="exit 1 on any coverage failure (needs --manifest)")
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--codes", default="auto", help="the named states' codes: auto | all (v44: 2^K) | a list")
    ap.add_argument("--trace-codes", default="auto",
                    help="v44: the trace checkpoints' codes (auto | all | a list); before v44 the trace used --codes")
    ap.add_argument("--codes-at-2u", action="store_true",
                    help="v44 (with --trace): at the trace checkpoints at the end of the expansion (2U), the --codes "
                         "set (e.g. all 2^K) instead of --trace-codes")
    ap.add_argument("--paired-streams", action="store_true",
                    help="v45: every trajectory of one f0 and seed must share its minibatch stream (train.audit_batches),"
                         " insertion initialization and configuration apart from its holds, and every compact "
                         "control's stream at 2U must equal theirs; _paired_streams.csv")
    ap.add_argument("--paired-vary", default="",
                    help="v53 (with --paired-streams): comma-separated section.key settings in which the design's "
                         "trajectories differ on purpose (e.g. growth.act,train.lr); they are left out of the "
                         "configuration that must be equal across the trajectories of one f0 and seed, like the "
                         "holds.  The stream, the insertion initialization and f0 must still be equal")
    ap.add_argument("--save-extractions", default=None, metavar="DIR",
                    help="v45: save the 2U extraction (first layer kept, layers 2..K f0's, additions deleted) of every "
                         "expansion and compact control, and the expansion's with its additions present, to DIR "
                         "(each reloaded and checked to reproduce its evaluated predictions); _extractions_saved.csv")
    ap.add_argument("--trace-implants", action="store_true",
                    help="v47 (with --trace): at every trajectory checkpoint that has additions, the 2x2 of addition "
                         "presence x layers 2..K trained / restored to f0, the first layer kept (_reversal_2x2*.csv)")
    ap.add_argument("--reversal-grid", action="store_true",
                    help="v47 (with --implant-codes): at 2U, the 5x5 grid of addition gates x alpha and layers 2..K "
                         "at f0 + beta (trained - f0), the first layer kept, with exact corner checks and the three "
                         "predeclared paths (_reversal_grid*.csv, _reversal_paths*.csv)")
    ap.add_argument("--save-preds", default=None, metavar="DIR",
                    help="v47: save the grid's and the 2x2's test predictions (class indices) to DIR")
    ap.add_argument("--implant-codes", action="store_true",
                    help="v44: the codes also on every state that has additions WITH the additions present (the raw "
                         "graph, backbone layers mixed toward f0)")
    ap.add_argument("--trace", action="store_true")
    ap.add_argument("--decompose", action="store_true")
    ap.add_argument("--cross", action="store_true",
                    help="v39 (with --decompose): the causal and shortcut first-layer changes crossed between the "
                         "trajectory's end and the job's endpoint")
    ap.add_argument("--scale-controls", action="store_true",
                    help="v39 (with --decompose): f0's own causal (and shortcut) weights rescaled, beside the "
                         "causal-column transplant")
    ap.add_argument("--grid", action="store_true", help="exploratory: every {0, 0.5, 1} mixture")
    ap.add_argument("--displacement", action="store_true",
                    help="v42 (with --trace): each job's parameter displacement from its start at every traced "
                         "checkpoint of its own and at the endpoint (backbone, first layer and its column groups, "
                         "additions)")
    ap.add_argument("--contrasts", default=None, choices=sorted(REGISTRIES),
                    help="v43: a declared contrast registry (REGISTRIES); its arms must be in the manifest and every "
                         "pair it implies must be present")
    ap.add_argument("--preflight", action="store_true",
                    help="v41: verify every job's configs, states, saved predictions and the trace inventory's "
                         "checkpoints exist and check out, without evaluating anything (writes _coverage.json only)")
    ap.add_argument("--no-grid", action="store_true", help="(the default; accepted for older commands)")
    a = ap.parse_args()
    if a.strict and not a.manifest:
        ap.error("--strict needs --manifest")
    if a.strict and a.limit:
        ap.error("--limit is exploratory: a strict analysis covers the whole manifest")
    if (a.cross or a.scale_controls) and not a.decompose:
        ap.error("--cross and --scale-controls need --decompose")
    if a.displacement and not a.trace:
        ap.error("--displacement needs --trace")
    if a.codes_at_2u and not a.trace:
        ap.error("--codes-at-2u needs --trace")
    if a.trace_implants and not a.trace:
        ap.error("--trace-implants needs --trace")
    if a.reversal_grid and not a.implant_codes:
        ap.error("--reversal-grid needs --implant-codes")
    # v53: a registry of cross_measure / interaction contrasts only reads the code tables; the first-layer
    # decomposition is needed by the kinds that pair components (trace, endpoint, within_job)
    reg_decomp = bool(a.contrasts) and any(k_ not in ("cross_measure", "interaction")
                                           for _, k_, _, _ in REGISTRIES[a.contrasts])
    if a.contrasts and not (a.trace and a.manifest and (a.decompose or not reg_decomp)):
        ap.error("--contrasts needs --trace and --manifest, and --decompose when the registry pairs first-layer "
                 "components")
    paired_vary = [tuple(x.split(".", 1)) for x in a.paired_vary.split(",") if x]
    if any(len(x) != 2 or x[0] not in ("growth", "train") or not x[1] for x in paired_vary):
        ap.error("--paired-vary takes growth.<key> or train.<key> settings")
    if paired_vary and not a.paired_streams:
        ap.error("--paired-vary needs --paired-streams")
    dev = a.device
    runs = Path(a.results) / "runs"
    coverage = {"tool_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()[:16],
                "results": str(a.results), "manifest": a.manifest,
                "manifest_sha256": hashlib.sha256(Path(a.manifest).read_bytes()).hexdigest()[:16] if a.manifest else None,
                "options": {k: getattr(a, k) for k in ("codes", "trace_codes", "codes_at_2u", "implant_codes",
                                                         "paired_streams", "paired_vary", "save_extractions",
                                                         "trace_implants", "reversal_grid", "save_preds",
                                                         "trace", "decompose", "cross", "scale_controls",
                                                         "grid", "device", "displacement", "contrasts", "preflight")},
                "analysis_schema": ANALYSIS_SCHEMA,
                "expected": 0, "analysed": 0, "failed": [], "excluded": [], "by_variant": defaultdict(int),
                "decomposition_not_applicable": [], "cross_excluded": [], "inventory": defaultdict(int)}
    # ---- population
    if a.manifest:
        mcfg = {e["run_id"]: e["cfg"] for e in AC.manifest_entries(a.manifest)}
        ids = [rid for rid, c in mcfg.items() if eligible(c) is not None]
    else:
        mcfg = None
        ids = sorted(p.name for p in runs.glob("*") if (p / "config.json").exists() and
                     eligible(rj(p / "config.json")) is not None)
    if a.limit:
        ids = ids[:a.limit]
    coverage["expected"] = len(ids)
    jobs, dup_key = [], {}
    for rid in ids:
        d = runs / rid
        if not (d / "config.json").exists():
            coverage["failed"].append({"run_id": rid, "reason": "job folder missing"})
            continue
        why_d = AC.declared_invalid(d, mcfg[rid] if mcfg is not None else None) if (d / "config.json").exists() else None
        if why_d:
            coverage["excluded"].append({"run_id": rid, "reason": why_d})      # v36: listed, never silently dropped
            continue
        try:
            cfg = AC.job_config(runs, rid, mcfg[rid] if mcfg is not None else None)
        except Fail as ex:
            coverage["failed"].append({"run_id": rid, "reason": str(ex)})
            continue
        src, kind = eligible(cfg)
        if src == "control":
            # a control copy that differs ONLY by a partition seed (controls have no partition) is a duplicate
            # when its scientific config and its endpoint predictions equal the first copy's
            norm = json.loads(json.dumps(cfg))
            norm.get("seeds", {}).pop("partition", None)
            key = json.dumps(norm, sort_keys=True)
            if key in dup_key:
                p0 = runs / dup_key[key] / "preds" / "endpoint__test.pt"
                p1 = d / "preds" / "endpoint__test.pt"
                if p0.exists() and p1.exists() and torch.equal(torch.load(p0, weights_only=False),
                                                               torch.load(p1, weights_only=False)):
                    coverage["excluded"].append({"run_id": rid, "reason": f"verified duplicate of {dup_key[key]}"})
                    continue
            else:
                dup_key[key] = rid
        jobs.append((src, kind, d, cfg))
    # v41: the continuation factorial's design, from the population (variant -> the keep fork settings it holds)
    design = defaultdict(set)
    design_jobs: set = set()                   # v43: (variant, arm, removal variant, cell, draw, seed) of every job
    traj_variants = defaultdict(set)           # v43: a trajectory's variant, from all its children (not traversal order)
    for rid in ids:
        if mcfg is None and not (runs / rid / "config.json").exists():
            continue
        c_ = mcfg[rid] if mcfg is not None else rj(runs / rid / "config.json")
        el_ = eligible(c_)
        if el_ and el_[1] in KEEP_FORKS:
            design[(c_.get("design") or {}).get("variant")].add(KEEP_FORKS[el_[1]])
        if el_:
            design_jobs.add(design_key(c_))
            if el_[0] == "removal":
                traj_variants[(c_.get("parents") or {}).get("trajectory")].add((c_.get("design") or {}).get("variant"))
    design_rid = {}
    for rid in ids:
        if mcfg is not None or (runs / rid / "config.json").exists():
            design_rid[rid] = design_key(mcfg[rid] if mcfg is not None else rj(runs / rid / "config.json"))
    tl = {int((c_.get("growth") or {}).get("updates_per_round", 0)) * int((c_.get("growth") or {}).get("rounds", 1))
          for c_ in (mcfg or {}).values() if c_.get("kind") == "trajectory"}
    fork_u = next(iter(tl)) if len(tl) == 1 else None        # v43: the expansion length 2U, when unique
    bundles, trajcache = {}, set()
    cfg_cache: dict = {}

    def owner_cfg(rid: str) -> dict:
        """v43: the configuration a checkpoint's owner was run with (its folder's config.json, which the runner
        hashed into every checkpoint; the manifest's copy must agree)."""
        if rid not in cfg_cache:
            c_ = rj(runs / rid / "config.json")
            if mcfg is not None and rid in mcfg and stable_hash(mcfg[rid]) != stable_hash(c_):
                raise Fail(f"{rid}: config.json differs from the manifest's configuration")
            cfg_cache[rid] = c_
        return cfg_cache[rid]
    scale_grid_cache: dict = {}
    grid_edges: dict = {}                        # v43: per unique (f0, data, partition) grid: edge selections                  # v41: f0-only rescaling grids, by (f0 tensors, data, partition)
    out = defaultdict(list)                      # committed rows by table
    partial = []

    for src, kind, d, cfg in jobs:
        des = cfg.get("design") or {}
        sd_ = cfg.get("seeds") or {}
        meta = {"run_id": d.name, "source": src, "family": des.get("family"), "variant": des.get("variant"),
                "arm": des.get("arm"), "removal_variant": kind, "cell": (des.get("contrast") or "").split("|")[-1],
                "data_draw": (cfg.get("data") or {}).get("data_seed"), "optimizer_seed": sd_.get("optimizer"),
                "partition_seed": sd_.get("partition"), "label_noise": (cfg.get("data") or {}).get("label_noise", 0.0),
                "draw_set": draw_role(cfg)}
        dcm = cfg.get("dissipation") or {}
        meta.update({"parent": (cfg.get("parents") or {}).get("trajectory" if src == "removal" else "baseline"),
                     "fork_masks": dcm.get("removal_masks", "released") if src == "removal" else None,
                     "fork_optimizer": dcm.get("optimizer_policy", "reset_each_phase") if src == "removal" else None})
        staged = defaultdict(list)
        before_cache: dict = {}
        dec_preds: dict = {}
        n_cross_endpoints = 0
        n_trace_ckpts = 0
        n_disp = 0
        n_imp_states = 0
        claimed = []
        try:
            ep = rj(d / "endpoint.json") if (d / "endpoint.json").exists() else None
            if ep is None or ep.get("diverged") or ep.get("numerically_valid") is False:
                raise Fail("endpoint missing, diverged or recorded numerically invalid")
            key = json.dumps(cfg["data"], sort_keys=True)
            if key not in bundles:
                b0 = load_bundle(cfg["data"], a.data_root, device="cpu")
                bundles[key] = (b0.to(dev), b0.hashes())
            b, hashes = bundles[key]
            # v34: provenance is required, for every partition this analysis evaluates (and train)
            need = {"train", *AC.eval_partitions(b)}
            AC.check_logged_data(d, hashes, need, "data provenance")

            def checked(ck, label, owner, stage):
                """a state's checkpoint with its lineage, parameter / graph hashes, data hashes and (v43) its owner's
                configuration hash verified."""
                AC.check_ckpt(ck, label, run_id=owner, stage=stage, cfg=owner_cfg(owner), hashes=hashes, need=need)
                return ck
            parts_all = b.partitions()
            selp = "val_indep" if "val_indep" in parts_all else "val"
            extra = [p for p in EXTRA_PARTS if p in parts_all]
            pairs_ok = "cf_base" in parts_all and "cf_shortcut" in parts_all
            batch = int((cfg.get("train") or {}).get("eval_batch", 4096))
            layout = (b.meta or {}).get("feature_layout") or {}
            Q64 = torch.tensor(layout["input_rotation"], dtype=torch.float64) if layout.get("input_rotation") else None

            def measure(m):
                ps = sorted({"val", "test", selp, *extra} | ({"cf_base"} if pairs_ok else set()))
                r, pr = evaluate(m, b, ps, batch, return_preds=True)
                if not all(bool(torch.isfinite(v).all()) for v in pr.values() if v.is_floating_point()):
                    raise Fail("non-finite predictions")
                o = {f"{p}_err": 1.0 - r[p]["acc"] for p in ps}
                if pairs_ok:
                    o["shortcut_flip_rate"] = float((pr["cf_base"].argmax(-1) != pr["cf_shortcut"].argmax(-1))
                                                    .double().mean())
                return o, pr

            # ---- f0 and the states
            history = []
            tid = td = None
            if src == "removal":
                tid = cfg["parents"]["trajectory"]
                td = runs / tid
                f0k = checked(ckp(td, "baseline_ref"), "f0", tid, "baseline_ref")
                dcf = cfg["dissipation"]
                pu = f"path_u{int(dcf['speed_updates'])}"
                pstage0 = (cfg.get("tags") or {}).get("parent_stage", "final")
                if kind == "full" or kind.startswith("hold_"):
                    # v41: the state the job started from (its parent stage; 'final' for every current design)
                    states = {"abrupt": (checked(ckp(td, pstage0), "abrupt", tid, pstage0), False),
                              "after_transition": (checked(ckp(d, pu), "after_transition", d.name, pu), False),
                              "repaired": (checked(ckp(d, ep["checkpoint"]), "repaired", d.name, ep["checkpoint"]),
                                           True)}
                elif kind.startswith("keep"):
                    states = {"kept_end": (checked(ckp(d, ep["checkpoint"]), "kept_end", d.name, ep["checkpoint"]),
                                           True)}
                else:
                    states = {"repaired": (checked(ckp(d, ep["checkpoint"]), "repaired", d.name, ep["checkpoint"]),
                                           True)}
            else:
                pstage0 = None
                bid = cfg["parents"]["baseline"]
                cc = cfg.get("continue") or {}
                f0k = checked(ckp(runs / bid, cc.get("start_stage", "best_val")), "f0", bid,
                              cc.get("start_stage", "best_val"))
                states = {f"{des['arm']}_final": (checked(ckp(d, ep["checkpoint"]), "final", d.name, ep["checkpoint"]),
                                                  True)}
            # v42: does this state's whole lineage hold the first layer's shortcut column at f0 (train.freeze_inputs)?
            # then its shortcut-column change must be exactly zero
            fz_job = (cfg.get("train") or {}).get("freeze_inputs", "none") == "shortcut"
            fz_job_sched = fz_job                      # v44: the schedule's prefix holds the column only if set
            # v43: a compact control with a freeze schedule is frozen only through its frozen prefix
            fsg_ = (cfg.get("continue") or {}).get("freeze_segments") or [] if src != "removal" else []
            frozen_until = (sum(int(n_) for n_, f_ in zip(cfg["continue"]["segments"], fsg_) if f_)
                            if fsg_ else None)
            if fsg_ and not all(fsg_):
                fz_job = False                         # the endpoint is past the release
            tcfg0 = ((mcfg or {}).get(tid) or rj(td / "config.json")) if src == "removal" else None
            fz_traj = bool(tcfg0) and (tcfg0.get("train") or {}).get("freeze_inputs", "none") == "shortcut"
            fz_lineage = fz_job and (src != "removal" or fz_traj)
            meta["freeze_inputs"] = (cfg.get("train") or {}).get("freeze_inputs", "none")
            meta["parent_freeze_inputs"] = (tcfg0.get("train") or {}).get("freeze_inputs", "none") if tcfg0 else None
            # v44: train.freeze_backbone=downstream holds every backbone layer after the first at f0: in such a
            # lineage (the job, through its frozen prefix; for a removal's start, its trajectory) layers 2..K of
            # every state must equal f0's exactly, else the job fails
            bh_job = (cfg.get("train") or {}).get("freeze_backbone", "none") == "downstream"
            bh_job_sched = bh_job
            if fsg_ and not all(fsg_):
                bh_job = False
            bh_traj = bool(tcfg0) and (tcfg0.get("train") or {}).get("freeze_backbone", "none") == "downstream"
            bh_lineage = bh_job and (src != "removal" or bh_traj)
            meta["freeze_backbone"] = (cfg.get("train") or {}).get("freeze_backbone", "none")
            meta["parent_freeze_backbone"] = (tcfg0.get("train") or {}).get("freeze_backbone", "none") \
                if tcfg0 else None
            start_ck = (checked(ckp(td, pstage0), "displacement start", tid, pstage0) if src == "removal" else f0k) \
                if a.displacement else None
            start_label = f"trajectory:{pstage0}" if src == "removal" else "f0"
            ref2 = None
            if a.displacement and src != "removal" and fork_u is not None and (d / "ckpt" / f"at_{fork_u}.pt").exists():
                ref2 = checked(ckp(d, f"at_{fork_u}"), "displacement 2U reference", d.name, f"at_{fork_u}")
            f0 = GraphNet.from_checkpoint(f0k["model"], dev).eval()
            f0_sd = {k: v.clone() for k, v in f0.state_dict().items()}
            L = backbone_layers(f0)
            K = len(L)
            als = {c: parse_code(c, K) for c in code_set(a.codes, K)}
            tals = {c: parse_code(c, K) for c in code_set(a.trace_codes, K)}       # v44: the trace's own set
            f0e, f0p = measure(f0) if not a.preflight else ({}, {})
            f0_hash = hashlib.sha256(b"".join(
                k.encode() + v.detach().cpu().contiguous().reshape(-1).view(torch.uint8).numpy().tobytes()
                for k, v in sorted(f0_sd.items()))).hexdigest()

            # v45: training cost since f0.  Trajectory checkpoints count from f0's own counters (subtracted); a removal
            # or keep job's trainer is fresh (its counters are its own, added to its trajectory's); a compact
            # control's counters start at the continuation
            f0c = counters_of(f0k)
            traj_c = traj_ck = None
            if src == "removal" and not a.preflight:
                traj_ck = states["abrupt"][0] if "abrupt" in states else \
                    checked(ckp(td, pstage0), "trajectory end", tid, pstage0)
                traj_c = counters_comb(counters_of(traj_ck), f0c, -1)
            job_res = rj(d / ("dissipation_result.json" if src == "removal" else "continue_result.json")) \
                if (d / ("dissipation_result.json" if src == "removal" else "continue_result.json")).exists() else {}

            def cost_of(sname_, ck_=None, owner_="job"):
                """v45: the cost since f0 of a named state (sname_) or a trace checkpoint (ck_)."""
                if owner_ == "trajectory":
                    return cost_fields(counters_comb(counters_of(ck_), f0c, -1), "trajectory counters - f0's", f0c)
                if src == "removal":
                    if sname_ == "abrupt":
                        return cost_fields(traj_c, "trajectory counters - f0's", f0c)
                    own = counters_of(job_res.get("compute_end")) if ck_ is None and sname_ in (
                        "repaired", "kept_end") else counters_of(ck_)
                    return cost_fields(counters_comb(traj_c, own, 1), "trajectory - f0 + this job's own counters", f0c)
                own = counters_of(job_res.get("compute_end")) if ck_ is None else counters_of(ck_)
                if own is not None:
                    # the MAC counters restart at the continuation; its update / example counters continue f0's
                    own = dict(own)
                    cc_ = cfg.get("continue") or {}
                    if f0c is not None and cc_.get("start") == "baseline" and cc_.get("inherit_state", True) \
                            and not cc_.get("reinit"):                    # f0's trainer state was continued
                        own["updates"] -= f0c["updates"]
                        own["examples"] -= f0c["examples"]
                return cost_fields(own, "the continuation's MAC counters (restarted at f0); updates and examples "
                                        "less f0's", f0c)

            x1_code = "-".join(["0"] + ["1"] * (K - 1))
            z_code = "-".join(["0"] * K)

            def save_extraction(model_, preds_, name_, src_run, code_, additions_):
                """v45: the extracted model saved, reloaded and checked to give the same test predictions."""
                od = Path(a.save_extractions)
                od.mkdir(parents=True, exist_ok=True)
                obj = {"model": model_.checkpoint(), "param_hash": model_.param_hash(), "source_run": src_run,
                       "code": code_, "additions": additions_, "f0": meta.get("parent") if src != "removal" else
                       (tcfg0.get("parents") or {}).get("baseline"), "analysis_schema": ANALYSIS_SCHEMA}
                torch.save(obj, od / f"{name_}.pt")
                back = GraphNet.from_checkpoint(torch.load(od / f"{name_}.pt", map_location="cpu",
                                                           weights_only=False)["model"], dev).eval()
                _, pb_ = measure(back)
                if not torch.equal(pb_["test"], preds_["test"]):
                    raise Fail(f"saved extraction {name_}: the reloaded model differs from the evaluated one")
                staged["extractions_saved"].append({"run_id": src_run, "file": f"{name_}.pt", "code": code_,
                                                    "additions": additions_, "param_hash": obj["param_hash"],
                                                    "variant": meta["variant"], "arm": meta["arm"],
                                                    "cell": meta["cell"], "data_draw": meta["data_draw"],
                                                    "optimizer_seed": meta["optimizer_seed"],
                                                    "reload_reproduces_predictions": True})

            parts_ = b.partitions()

            def with_ce(e, pr):
                """v47: test and val cross-entropy beside the errors (classification logits).  v48: the test
                cross-entropy is re-derived per example from log_softmax and must agree with the mean (else Fail),
                with the per-example loss and the correct-class margin (logit of the label minus the largest other
                logit; negative = wrong) summarised by quantiles, and the largest absolute logit per example."""
                e = dict(e)
                for p_ in ("test", "val"):
                    if p_ in pr and pr[p_].dim() == 2 and not parts_[p_].y.is_floating_point():
                        e[f"{p_}_ce"] = float(torch.nn.functional.cross_entropy(
                            pr[p_].double(), parts_[p_].y.to(pr[p_].device).long()))
                if "test_ce" in e:
                    z_ = pr["test"].double()
                    y_ = parts_["test"].y.to(z_.device).long()[:, None]
                    nll_ = -torch.log_softmax(z_, -1).gather(1, y_)[:, 0]
                    if abs(float(nll_.mean()) - e["test_ce"]) > 1e-9 * max(1.0, abs(e["test_ce"])):
                        raise Fail(f"test cross-entropy {e['test_ce']} differs from the per-example mean "
                                   f"{float(nll_.mean())}")
                    zo_ = z_.clone().scatter_(1, y_, float("-inf"))
                    mg_ = z_.gather(1, y_)[:, 0] - zo_.max(-1).values
                    qv_ = torch.tensor(MARGIN_QUANTILES, dtype=torch.float64, device=z_.device)
                    for q_, v_ in zip(MARGIN_QUANTILES, torch.quantile(mg_, qv_).tolist()):
                        e[f"test_margin_q{round(100 * q_):02d}"] = v_
                    for q_, v_ in zip(MARGIN_QUANTILES, torch.quantile(nll_, qv_).tolist()):
                        e[f"test_ce_q{round(100 * q_):02d}"] = v_
                    al_ = z_.abs().max(-1).values
                    e["test_abs_logit_q50"] = float(torch.quantile(al_, 0.5))
                    e["test_abs_logit_q99"] = float(torch.quantile(al_, 0.99))
                    e["test_abs_logit_max"] = float(al_.max())
                    e["test_ce_gt10_share"] = float((nll_ > 10).double().mean())
                    e["test_ce_from_wrong_share"] = float(nll_[mg_ < 0].sum() / nll_.sum()) \
                        if float(nll_.sum()) > 0 else 0.0
                return e

            def raw_graph(mdl, label):
                """v47: the state with its additions present (gates as recorded), backbone keys as in the compact."""
                g_ = GraphNet.from_checkpoint(mdl, dev).eval()
                g_._plan = None
                gb_ = {k: v.clone() for k, v in g_.state_dict().items()}
                gk_ = {Lk: [k for k in gb_ if k.startswith(f"mods.{Lk}.")] for Lk in L}
                if any(gb_[k].shape != f0_sd[k].shape for Lk in L for k in gk_[Lk]):
                    raise Fail(f"{label}: the raw graph's backbone tensors differ from f0's")
                return g_, gb_, gk_

            def save_pred_array(name_, arr, extra_, logits_=None):
                # v48: the test logits (float32) beside the decisions
                if not a.save_preds:
                    return
                import numpy as _np
                od = Path(a.save_preds)
                od.mkdir(parents=True, exist_ok=True)
                kw_ = {} if logits_ is None else {"logits": _np.asarray(logits_, dtype=_np.float32),
                                                  "labels": parts_["test"].y.cpu().numpy().astype(_np.int16)}
                _np.savez_compressed(od / f"{name_}.npz", preds=_np.asarray(arr, dtype=_np.int16),
                                     meta=_np.asarray(json.dumps(extra_, default=str)), **kw_)

            # v45: the paired-stream audit (--paired-streams): the trajectory's minibatch stream and insertion
            # initialization, the compact control's stream at 2U; checked across the conditions of one f0 later
            if a.paired_streams and not a.preflight:
                if src == "removal":
                    tst = ((traj_ck or {}).get("trainer") or {}).get("state") or {}
                    tcf = json.loads(json.dumps(tcfg0))
                    for k_ in ("freeze_inputs", "freeze_backbone"):
                        tcf["train"].pop(k_, None)
                    for sec_, k_ in paired_vary:              # v53: the design's declared arm factors
                        (tcf.get(sec_) or {}).pop(k_, None)
                    staged["paired_streams"].append({
                        "role": "trajectory", "run_id": tid, "variant": meta["variant"], "cell": meta["cell"],
                        "data_draw": meta["data_draw"], "optimizer_seed": meta["optimizer_seed"],
                        "f0": (tcfg0.get("parents") or {}).get("baseline"), "f0_state_hash": f0_hash,
                        "batch_id_hash": tst.get("batch_id_hash"), "batches_drawn": tst.get("batches_drawn"),
                        "updates": traj_c["updates"] if traj_c else None,
                        "insertion_init_hash": insertion_hash(td),
                        "config_apart_from_holds": stable_hash({k_: tcf.get(k_) for k_ in (
                            "data", "model", "seeds", "growth", "train")}),
                        "data_hash": stable_hash(tcfg0.get("data"))})
                elif src != "removal":
                    st2 = [r_ for r_ in ((job_res.get("fork_audit") or {}).get("starts") or [])
                           if fork_u is not None and int(r_.get("update", -1)) == int(fork_u)]
                    staged["paired_streams"].append({
                        "role": "compact", "run_id": d.name, "variant": meta["variant"], "cell": meta["cell"],
                        "data_draw": meta["data_draw"], "optimizer_seed": meta["optimizer_seed"],
                        "f0": cfg["parents"]["baseline"], "f0_state_hash": f0_hash,
                        "batch_id_hash": st2[0].get("batch_id_hash") if len(st2) == 1 else None,
                        "batches_drawn": st2[0].get("batches_drawn") if len(st2) == 1 else None,
                        "updates": int(st2[0]["update"]) if len(st2) == 1 else None,
                        "fork_records_at_2U": len(st2), "insertion_init_hash": None, "config_apart_from_holds": None,
                        "data_hash": stable_hash(cfg.get("data"))})

            start_upd = None
            if src == "removal":
                tc_ = tcfg0["growth"]
                start_upd = int(tc_["updates_per_round"]) * int(tc_.get("rounds", 1))
                if pstage0 != "final":
                    start_upd = None                # a start other than the trajectory end: no update offset
            else:
                start_upd = 0
            bb_keys = lambda sd: [k for k in sd if k.startswith("mods.") and k.split(".")[1] in L
                                  and sd[k].is_floating_point()]

            def norms_of(ck_):
                """v43: the cumulative update norms a checkpoint carries (its extra, else its trainer state)."""
                un = (ck_.get("extra") or {}).get("update_norms")
                if un is None:
                    un = ((ck_.get("trainer") or {}).get("state") or {}).get("update_norms")
                return un

            def displacement(ck_t, ck_0, since, ref_label, from_job_start=True):
                """v42/v43: NET parameter movement of this state from a reference state (the trajectory checkpoint a
                removal or keep job forked from; f0 for a compact control; or, for a compact control, its own
                state at the end of the expansion, 2U): the Euclidean distance over the backbone, its first layer
                (and its causal / shortcut / noise columns, generator coordinates), and the additions present in
                both (absent after a deletion: 'deleted or not applicable', never zero).  Net movement is not the
                size of the updates (large updates can cancel); v43 jobs that log their update norms also give
                the PATH length (sum of update norms) since the reference."""
                sd_t, sd_0 = ck_t["model"]["state"], ck_0["model"]["state"]
                bk = [k for k in bb_keys(sd_0) if k in sd_t and sd_t[k].shape == sd_0[k].shape]
                if len(bk) != len(bb_keys(sd_0)):
                    raise Fail("displacement: backbone tensors differ from the reference's")
                d2 = lambda ks: float(sum(float(((sd_t[k].double() - sd_0[k].double()) ** 2).sum()) for k in ks))
                n2 = lambda ks: float(sum(float((sd_0[k].double() ** 2).sum()) for k in ks))
                fk = [k for k in bk if k.split(".")[1] == L[0]]
                ad = [k for k in sd_0 if k.startswith("mods.") and k.split(".")[1] not in L and k in sd_t
                      and sd_0[k].is_floating_point() and sd_t[k].shape == sd_0[k].shape]
                row = {"reference_checkpoint": ref_label, "updates_since_reference": since,
                       "net_backbone_l2": d2(bk) ** 0.5, "net_backbone_rel": (d2(bk) / max(n2(bk), 1e-30)) ** 0.5,
                       "net_first_layer_l2": d2(fk) ** 0.5,
                       "net_first_layer_rel": (d2(fk) / max(n2(fk), 1e-30)) ** 0.5,
                       "net_additions_l2": d2(ad) ** 0.5 if ad else None,
                       "net_additions_rel": (d2(ad) / max(n2(ad), 1e-30)) ** 0.5 if ad else None,
                       "additions_status": "measured" if ad else "deleted or not applicable",
                       "n_addition_tensors": len(ad)}
                if all(layout.get(k_) is not None for k_ in ("shortcut", "causal", "noise")):
                    w = f"mods.{L[0]}.weight"
                    dg = sd_t[w].double() - sd_0[w].double()
                    if Q64 is not None:
                        dg = dg @ Q64.T
                    c0_, c1_ = layout["causal"]
                    n0_, n1_ = layout["noise"]
                    row.update({"net_first_layer_causal_l2": float(dg[:, c0_:c1_].norm()),
                                "net_first_layer_shortcut_l2": float(dg[:, [int(layout["shortcut"])]].norm()),
                                "net_first_layer_noise_l2": float(dg[:, n0_:n1_].norm())})
                un_t = norms_of(ck_t)
                if un_t is not None:
                    un_0 = None if from_job_start else norms_of(ck_0)
                    if not from_job_start and un_0 is None:
                        raise Fail("displacement: the reference checkpoint has no update norms")
                    p0 = (un_0 or {}).get("path") or {}
                    row.update({f"path_{k}": v - p0.get(k, 0.0) for k, v in (un_t.get("path") or {}).items()})
                    row["path_updates"] = int(un_t.get("n_updates", 0)) - int((un_0 or {}).get("n_updates", 0))
                return row

            def compact(mdl, label):
                """branch deletion; a gated graph: gates at 0, export, and the same function (else a failure)."""
                g = GraphNet.from_checkpoint(mdl, dev).eval()
                tops = [t for t, imp in g.implants.items() if imp.nodes and imp.parent is None]
                if not tops:
                    return g, False
                try:
                    h = E.delete(g, tops, share_params=False).eval()
                except Exception as ex:                     # noqa: BLE001
                    if not g.gate_vals:
                        raise Fail(f"{label}: branch deletion failed ({type(ex).__name__}: {ex})")
                    g0 = g.clone(share_params=False)
                    for gd in list(g0.gate_vals):
                        g0.gate_vals[gd] = 0.0
                    h = export_compact(g0)[0].eval()
                    if any(imp.nodes for imp in h.implants.values() if imp.parent is None):
                        raise Fail(f"{label}: gated export still holds additions")
                    _, p_g = measure(g0)
                    _, p_h = measure(h)
                    if float((p_g["test"].double() - p_h["test"].double()).abs().max()) > 1e-5:
                        raise Fail(f"{label}: gated export is not the gated-to-zero function")
                h._plan = None
                return h, True

            def load_with(h, base, keys, al):
                new = dict(base)
                for Lk, x in zip(L, al):
                    if x == 1:              # v45: a restored layer is f0's tensors themselves (bitwise)
                        for k in keys[Lk]:
                            new[k] = f0_sd[k].to(base[k].device, base[k].dtype).clone()
                    elif x:
                        for k in keys[Lk]:
                            new[k] = (1 - x) * base[k] + x * f0_sd[k].to(base[k].device, base[k].dtype)
                h.load_state_dict(new)
                h._plan = None
                if all(x in (0, 1) for x in al):
                    verify_code(h, base, keys, al)

            def verify_code(h, base, keys, al):
                """v45: a keep / restore code as loaded: every restored layer's tensors (weights and biases) equal
                f0's, every kept layer's and every other tensor equal the state's, bitwise; else the job fails."""
                sd_ = h.state_dict()
                for Lk, x in zip(L, al):
                    for k in keys[Lk]:
                        ref_ = f0_sd[k] if x == 1 else base[k]
                        if not torch.equal(sd_[k].cpu(), ref_.to(sd_[k].dtype).cpu()):
                            raise Fail(f"code {'-'.join(map(str, al))}: {k} is not the "
                                       f"{'f0' if x == 1 else 'state'} tensor")
                bk = {k for Lk in L for k in keys[Lk]}
                for k, v in sd_.items():
                    if k not in bk and not torch.equal(v.cpu(), base[k].cpu()):
                        raise Fail(f"code {'-'.join(map(str, al))}: {k} changed")

            def downstream_change(sd_):
                """v44: max |state - f0| over the backbone layers after the first (the compact state's tensors)."""
                ks = [k for k in sd_ if k.startswith("mods.") and k.split(".")[1] in L[1:]
                      and sd_[k].is_floating_point()]
                return max((float((sd_[k].double() - f0_sd[k].to(sd_[k].device).double()).abs().max()) for k in ks),
                           default=0.0)

            def prepare(mdl, label):
                h, had = compact(mdl, label)
                if backbone_layers(h) != L:
                    raise Fail(f"{label}: compact backbone layers differ from f0's")
                # v45: every addition deleted (no live node owned by an addition, none registered)
                if any(imp.nodes for imp in h.implants.values()) or \
                        any(h.nodes[n].owner is not None for n in h.live_nodes()):
                    raise Fail(f"{label}: an addition survived the deletion")
                base = {k: v.clone() for k, v in h.state_dict().items()}
                # v45: the deletion does not alter the retained first layer (the state's own tensors, bitwise)
                raw_ = (mdl or {}).get("state") or {}
                for k in [k for k in base if k.startswith(f"mods.{L[0]}.")]:
                    if k in raw_ and not torch.equal(raw_[k].to(base[k].dtype).cpu(), base[k].cpu()):
                        raise Fail(f"{label}: deleting the additions changed the first layer ({k})")
                keys = {Lk: [k for k in base if k.startswith(f"mods.{Lk}.")] for Lk in L}
                if any(k not in f0_sd or f0_sd[k].shape != base[k].shape for Lk in L for k in keys[Lk]):
                    raise Fail(f"{label}: backbone tensors differ from f0's")
                return h, had, base, keys

            # ---- v41: the first-layer component surgery, one arithmetic path for the decomposition, the cross,
            # the rescaling controls and the component trace (the feature groups are the generator's)
            comp = None
            if a.decompose:
                if "shortcut" not in layout:
                    coverage["decomposition_not_applicable"].append({"run_id": d.name,
                                                                     "reason": "the data has no shortcut layout"})
                else:
                    L1 = L[0]
                    wk, bk_ = f"mods.{L1}.weight", f"mods.{L1}.bias"
                    W0 = f0_sd[wk].double()
                    c0, c1 = layout["causal"]
                    n0, n1 = layout["noise"]
                    groups = {"shortcut": [int(layout["shortcut"])], "causal": list(range(c0, c1)),
                              "noise": list(range(n0, n1))}
                    if sorted(x for v in groups.values() for x in v) != list(range(W0.shape[1])):
                        raise Fail(f"feature groups are not a disjoint cover of the {W0.shape[1]} inputs")
                    Qd = Q64.to(device=W0.device) if Q64 is not None else None
                    comp = {"groups": groups, "W0": W0, "Qd": Qd}

            def to_gen(dW):
                return dW @ comp["Qd"].T if comp["Qd"] is not None else dW

            def from_gen(sel):
                return sel @ comp["Qd"] if comp["Qd"] is not None else sel

            def first_layer_probe(h, base, W, bias):
                """f0 in every backbone layer except the first layer's weights W (input coordinates) and bias
                (None: f0's).  -> measure(h)."""
                new = {k: (f0_sd[k].to(v.device, v.dtype) if k.startswith("mods.") and k.split(".")[1] in L
                           else v) for k, v in base.items()}
                new[wk] = W.to(base[wk].dtype)
                if bias is not None and bk_ in base:
                    new[bk_] = bias.to(base[bk_].device, base[bk_].dtype)
                h.load_state_dict(new)
                h._plan = None
                return measure(h)

            def mixed_weight(src: dict, exact=None):
                """W0 + the generator-coordinate columns of each group taken from src[group] (a dE, or None for
                f0's own columns); exact: the state's own W when every group comes from that state (assigned
                exactly, as the full decomposition subset)."""
                if exact is not None:
                    return exact
                sel = torch.zeros_like(comp["W0"])
                for gname, cs in comp["groups"].items():
                    if src.get(gname) is not None:
                        sel[:, cs] = src[gname][:, cs]
                return comp["W0"] + from_gen(sel)

            def state_parts(base):
                W1 = base[wk].double()
                return W1, to_gen(W1 - comp["W0"]), (base[bk_] if bk_ in base else None)

            TRACE_SUBSETS = ("none", "causal", "shortcut", "shortcut+causal", "shortcut+causal+noise+bias")

            def subset_probe(h, base, keys, gname, p_first=None):
                """one decomposition subset ('shortcut+causal', ...): -> (metrics, predictions)."""
                W1, dE, b1 = state_parts(base)
                use = {g_: (g_ in gname.split("+")) for g_ in ("shortcut", "causal", "noise", "bias")}
                full = use["shortcut"] and use["causal"] and use["noise"]
                W = mixed_weight({g_: dE for g_ in comp["groups"] if use[g_]}, exact=W1 if full else None)
                e, pr = first_layer_probe(h, base, W, b1.clone() if (use["bias"] and b1 is not None) else None)
                if gname == "none" and not torch.equal(pr["test"], f0p["test"]):
                    raise Fail("the empty update subset does not reproduce f0")
                if all(use.values()) and p_first is not None and not torch.equal(pr["test"], p_first["test"]):
                    raise Fail("the full update subset does not reproduce the first-layer transplant")
                return e, pr

            def measure_sel(m):
                """the selection partition's error only (the rescaling grid: v41, nothing else is evaluated)."""
                r, pr = evaluate(m, b, [selp], batch, return_preds=True)
                if not bool(torch.isfinite(pr[selp]).all()):
                    raise Fail("non-finite predictions")
                return 1.0 - r[selp]["acc"]

            A_GRID, S_GRID = A_GRID_, S_GRID_

            def scale_rows(h, base, sname, dE, p_causal):
                """v39/v41: is the causal-column transplant more than a rescaling of f0's own causal weights?  Every
                control is W0 + (a change of the causal and shortcut columns, generator coordinates), the
                decomposition's arithmetic; causal_transplant is the decomposition's causal subset (checked
                bitwise).  The two scale-selected controls take the scale(s) with the lowest error on the selection
                partition (never test) over a fixed grid; the grid depends on f0 and the data only, so it is
                evaluated once per (f0, data) on the selection partition alone.
                v42: two fitted per-row rescalings of f0's causal block toward the learned one, row r scaled by s_r:
                  f0_causal_row_ls_fit          s_r = <C0_r, C1_r> / |C0_r|^2 (weights)
                  f0_causal_activation_fit      s_r = <a_r, b_r> / |b_r|^2 with b_r, a_r = the causal block's
                                                contribution to unit r's pre-activation on the selection partition
                                                under f0's and the learned weights
                and for every control its agreement with the causal transplant on test: the share of differing
                decisions and the mean total-variation distance of the softmax outputs."""
                cs, sc = comp["groups"]["causal"], comp["groups"]["shortcut"]
                WE0 = to_gen(comp["W0"])
                C0, S0 = WE0[:, cs], WE0[:, sc]
                C1_ = C0 + dE[:, cs]
                n0r, n1r = C0.norm(dim=1), C1_.norm(dim=1)
                eps = 1e-12
                cosr = (C0 * C1_).sum(1) / (n0r * n1r).clamp_min(1e-30)
                stat = {"causal_norm_ratio": float(C1_.norm() / C0.norm().clamp_min(1e-30)),
                        "causal_row_cosine_weighted": float((cosr * n1r).sum() / n1r.sum().clamp_min(1e-30)),
                        "causal_row_cosine_min": float(cosr.min()),
                        "f0_causal_zero_norm_rows": int((n0r <= eps).sum()),
                        "transplant_causal_zero_norm_rows": int((n1r <= eps).sum())}
                # v44: the learned block = per-row scaling of f0's block (the signed row fit) + a residual
                s_ls, res_ls, rstat = row_scale_residual(C0, C1_)
                if float((C0 * (s_ls - 1.0).unsqueeze(1) + res_ls - dE[:, cs]).abs().max()) > \
                        1e-9 * max(1.0, float(dE[:, cs].abs().max())):
                    raise Fail(f"{sname}: scaling + residual does not add up to the learned causal change")
                stat.update(rstat)
                # v45: the residual-versus-magnitude blocks, checked: the decomposition reconstructs the learned
                # block and its residual is orthogonal to f0's row (weight-space least squares), row by row
                rmb, _, _, rrec = residual_magnitude_blocks(C0, C1_)
                if rrec["reconstruction_max_abs"] > 1e-9 * max(1.0, float(C1_.abs().max())):
                    raise Fail(f"{sname}: a * w0 + r does not reconstruct the learned causal block")
                if rrec["orthogonality_max_abs_cos"] > 1e-9:
                    raise Fail(f"{sname}: the residual is not orthogonal to f0's row "
                               f"(|cos| {rrec['orthogonality_max_abs_cos']:.3g})")
                stat.update({f"decomposition_{k}": v for k, v in rrec.items()})

                def weight(dc=None, ds=None):
                    sel = torch.zeros_like(comp["W0"])
                    if dc is not None:
                        sel[:, cs] = dc
                    if ds is not None:
                        sel[:, sc] = ds
                    return comp["W0"] + from_gen(sel)
                rows_out = []

                ref_pt = {}

                eval_rows: dict = {}                   # v46: evaluated causal-block row norms by control

                def put(ctrl, W, **kw):
                    e, pr = first_layer_probe(h, base, W, None)
                    agree = agreement(ref_pt["test"], pr["test"]) if ref_pt else \
                        {"decision_disagreement_vs_transplant": 0.0, "tv_vs_transplant": 0.0}
                    # v46: the candidate's causal-block norms read back from the weights actually evaluated (in the
                    # model's dtype); the ideal construction's (float64, before the cast) kept beside them
                    W_ev = h.state_dict()[wk].detach().double()
                    B_ev = to_gen(W_ev)[:, cs]
                    eval_rows[ctrl] = B_ev.norm(dim=1)
                    cn = block_norms(B_ev, C0)
                    cn_ideal = {f"ideal_{k}": v for k, v in block_norms(to_gen(W.double())[:, cs], C0).items()}
                    rows_out.append({**meta, "state": sname, "control": ctrl, **kw, **stat, **cn, **cn_ideal, **e,
                                     **agree, "evaluated_dtype": str(h.state_dict()[wk].dtype),
                                     # v46: what each probe needs to know (all rescaling controls address the
                                     # generator's causal / shortcut columns: privileged feature-group labels)
                                     "probe_access": "feature-group labels" + (
                                         " + selection on " + str(kw.get("selected_on")) if kw.get("oracle_tuning")
                                         else ""),
                                     **{f"f0_{k}": v for k, v in f0e.items()}})
                    return pr
                pt = put("causal_transplant", mixed_weight({"causal": dE}))
                if not torch.equal(pt["test"], p_causal):
                    raise Fail(f"{sname}: causal_transplant does not reproduce the decomposition's causal subset")
                ref_pt["test"] = pt["test"]
                # v42/v43: fitted per-row rescalings, signed and nonnegative, on the weights and on the causal drive
                # over the selection partition's inputs (no labels); the drive R^2 in the fit and on 'val' (held out)
                pts_ = b.partitions()
                gen = lambda part: ((pts_[part].X["x"].double().to(C0.device) @ comp["Qd"].T) if comp["Qd"] is not None
                                    else pts_[part].X["x"].double().to(C0.device))[:, cs]
                Uf = gen(selp)
                hop = "val" if ("val" in pts_ and selp != "val") else None
                Uh = gen(hop) if hop else None
                for ctrl, fitter in (("f0_causal_row_ls_fit", lambda nn: fit_row_scales(C0, C1_, nn)),
                                     ("f0_causal_activation_fit", lambda nn: fit_drive_scales(Uf, C0, C1_, nn))):
                    for nn in (False, True):
                        sv, deg = fitter(nn)
                        r2f, dgf = drive_r2(Uf, C0, C1_, sv)
                        r2h, dgh = drive_r2(Uh, C0, C1_, sv) if Uh is not None else (None, None)
                        name_ = ctrl + ("_nonneg" if nn else "")
                        put(name_, weight(C0 * (sv - 1.0).unsqueeze(1)), fit_on=selp if "activation" in ctrl else
                            "weights", signed=not nn, scale_mean=float(sv.mean()), scale_min=float(sv.min()),
                            scale_max=float(sv.max()), n_negative_scales=int((sv < 0).sum()),
                            n_degenerate_rows=int(deg.sum()), drive_r2_fit=r2f, drive_r2_fit_degenerate=dgf,
                            drive_r2_heldout=r2h, drive_r2_heldout_on=hop, drive_r2_heldout_degenerate=dgh)
                        staged["scale_vectors"] += [{"run_id": meta["run_id"], "state": sname, "control": name_,
                                                     "unit": i, "scale": float(v_), "degenerate": bool(dg_)}
                                                    for i, (v_, dg_) in enumerate(zip(sv.tolist(), deg.tolist()))]
                # v44: f0's block plus the residual alone (scaling only is f0_causal_row_ls_fit; both together is
                # the transplant): C0 + (C1 - s * C0)
                put("f0_causal_plus_residual", weight(res_ls), fit_on="weights", signed=True,
                    scale_mean=float(s_ls.mean()))
                # v45: does w0 + r help beyond its larger row norm?  f0's own directions at exactly the row norms of
                # w0 + r; and the changed directions at f0's row norms
                put("f0_causal_dir_at_norm_of_plus_residual", weight(rmb["f0_dir_norm_of_plus_res"] - C0),
                    fit_on="weights", rows_left_unscaled=rrec["f0_zero_rows_kept_zero"])
                put("f0_causal_plus_residual_at_f0_norm", weight(rmb["plus_residual_f0_norm"] - C0),
                    fit_on="weights", rows_left_unscaled=rrec["plus_residual_zero_rows_unscaled"])
                # v46: the norm matching checked row by row on the EVALUATED weights: f0's directions at the row norms
                # of w0 + r (rows where f0's row is zero have no direction to scale: excluded and counted), and
                # w0 + r at f0's row norms (rows where w0 + r is zero excluded and counted); tolerance from the
                # evaluated dtype
                epsd = torch.finfo(h.state_dict()[wk].dtype).eps
                n0_ev = to_gen(f0_sd[wk].detach().double())[:, cs].norm(dim=1)
                for a_, b_, excl, lab in (
                        ("f0_causal_dir_at_norm_of_plus_residual", "f0_causal_plus_residual", n0r <= 1e-12,
                         "f0 direction at the row norm of w0 + r"),
                        ("f0_causal_plus_residual_at_f0_norm", None, rmb["plus_residual"].norm(dim=1) <= 1e-12,
                         "w0 + r at f0's row norm")):
                    na = eval_rows[a_]
                    nb = eval_rows[b_] if b_ else n0_ev
                    ok = ~excl
                    tol = 64.0 * epsd * torch.clamp(torch.maximum(na, nb), min=1.0) * max(1.0, float(len(cs)) ** 0.5)
                    bad = ok & ((na - nb).abs() > tol)
                    if bool(bad.any()):
                        raise Fail(f"{sname}: {lab}: {int(bad.sum())} rows do not match in norm on the evaluated "
                                   f"weights (max |diff| {float((na - nb).abs()[ok].max()):.3g})")
                    for r_ in rows_out:
                        if r_["control"] == a_:
                            r_["norm_match_rows_checked"] = int(ok.sum())
                            r_["norm_match_rows_excluded_degenerate"] = int(excl.sum())
                            r_["norm_match_max_abs_diff"] = float((na - nb).abs()[ok].max()) if bool(ok.any()) else 0.0
                            r_["norm_match_reference"] = b_ or "f0"
                put("f0_causal_global_norm_matched", weight(C0 * (stat["causal_norm_ratio"] - 1.0)),
                    alpha_causal=stat["causal_norm_ratio"])
                put("f0_causal_row_norm_matched", weight(C0 * (n1r / n0r.clamp_min(1e-30)).unsqueeze(1) - C0))
                put("transplant_directions_f0_row_norms",
                    weight(C1_ * (n0r / n1r.clamp_min(1e-30)).unsqueeze(1) - C0))
                gkey = (f0_hash, key, selp)
                if gkey not in scale_grid_cache:
                    grid = {}
                    for ac in A_GRID:
                        for as_ in S_GRID:
                            grid[(ac, as_)] = measure_sel_probe(h, base, weight(C0 * (ac - 1.0), S0 * (as_ - 1.0)))
                    scale_grid_cache[gkey] = grid
                grid = scale_grid_cache[gkey]
                # first minimum in grid order (ties go to the smaller scale)
                b1 = min(A_GRID, key=lambda ac: (grid[(ac, 1.0)], A_GRID.index(ac)))
                b2 = min(grid, key=lambda t: (grid[t], A_GRID.index(t[0]), S_GRID.index(t[1])))
                grid_edges[gkey] = {"causal": b1 in (A_GRID[0], A_GRID[-1]),
                                    "combined": b2[0] in (A_GRID[0], A_GRID[-1]) or b2[1] in (S_GRID[0], S_GRID[-1])}
                put("f0_causal_scale_selected", weight(C0 * (b1 - 1.0)), alpha_causal=b1, selected_on=selp,
                    oracle_tuning=True,
                    selection_err=grid[(b1, 1.0)], grid=" ".join(map(str, A_GRID)),
                    alpha_causal_at_grid_edge=b1 in (A_GRID[0], A_GRID[-1]))
                put("f0_causal_shortcut_scale_selected", weight(C0 * (b2[0] - 1.0), S0 * (b2[1] - 1.0)),
                    alpha_causal=b2[0], alpha_shortcut=b2[1], selected_on=selp, oracle_tuning=True,
                    selection_err=grid[b2],
                    grid=f"{' '.join(map(str, A_GRID))} x {' '.join(map(str, S_GRID))}",
                    alpha_causal_at_grid_edge=b2[0] in (A_GRID[0], A_GRID[-1]),
                    alpha_shortcut_at_grid_edge=b2[1] in (S_GRID[0], S_GRID[-1]))
                return rows_out

            def measure_sel_probe(h, base, W):
                new = {k: (f0_sd[k].to(v.device, v.dtype) if k.startswith("mods.") and k.split(".")[1] in L
                           else v) for k, v in base.items()}
                new[wk] = W.to(base[wk].dtype)
                h.load_state_dict(new)
                h._plan = None
                return measure_sel(h)

            for sname, (sk, is_endpoint) in states.items():
                if sk is None:
                    raise Fail(f"state {sname}: checkpoint missing")
                if a.preflight:
                    if is_endpoint and not (d / "preds" / "endpoint__test.pt").exists():
                        raise Fail(f"{sname}: saved endpoint predictions missing")
                    continue
                chk = {**meta, "state": sname}
                if is_endpoint:
                    # native reload: the unedited endpoint checkpoint against the job's saved endpoint predictions
                    ref_p = d / "preds" / "endpoint__test.pt"
                    if not ref_p.exists():
                        raise Fail(f"{sname}: saved endpoint predictions missing")
                    nat = GraphNet.from_checkpoint(sk["model"], dev).eval()
                    e_nat, pn = measure(nat)
                    # v41: the native (unedited) endpoint, e.g. a kept model WITH its additions
                    staged["native"].append({**meta, "state": sname, "measure": "native_endpoint", **e_nat,
                                             **{f"f0_{k}": v for k, v in f0e.items()}})
                    ref = torch.load(ref_p, map_location="cpu", weights_only=False)
                    got = pn["test"].detach().cpu()
                    if ref.shape != got.shape:
                        raise Fail(f"{sname}: saved endpoint predictions have another shape")
                    diff = float((ref.double() - got.double()).abs().max())
                    if recorded_device(d).split(":")[0] == str(dev).split(":")[0]:
                        ok, pol = bool(torch.equal(ref.to(got.dtype), got)), "bitwise (same device type)"
                    else:
                        ok = diff <= 1e-4 * max(1.0, float(ref.abs().max())) and \
                            bool(torch.equal(ref.argmax(-1), got.argmax(-1)))
                        pol = "max |diff| <= 1e-4 x max(1, max |ref|) and identical decisions (other device)"
                    chk.update({"native_reload_pass": ok, "native_reload_policy": pol,
                                "native_reload_max_abs_diff": diff})
                    if not ok:
                        staged["checks"].append(chk)
                        raise Fail(f"{sname}: the endpoint checkpoint does not reproduce its saved predictions")
                h, had, base, keys = prepare(sk["model"], sname)
                chk["compaction"] = "branches deleted" if had else "already compact"
                dsc = downstream_change(base)
                chk["downstream_change_max_abs"] = dsc
                # the abrupt state is the trajectory's end (held iff the trajectory held); the others are the job's
                held_here = bh_traj if (src == "removal" and sname == "abrupt") else bh_lineage
                if held_here and dsc != 0.0:
                    raise Fail(f"{sname}: layers 2..K moved ({dsc:.3g}) in a lineage that held them at f0")
                _, p_before = measure(h)
                load_with(h, base, keys, tuple([0.0] * K))
                _, p_zero = measure(h)
                chk["zero_code_identity"] = bool(torch.equal(p_before["test"], p_zero["test"]))
                load_with(h, base, keys, tuple([1.0] * K))
                _, p_one = measure(h)
                chk["full_restore_identity"] = bool(torch.equal(p_one["test"], f0p["test"]))
                if not (chk["zero_code_identity"] and chk["full_restore_identity"]):
                    staged["checks"].append(chk)
                    raise Fail(f"{sname}: transplant identities failed")
                code_preds: dict = {}
                cost_ = cost_of(sname, None if is_endpoint else sk)
                staged["compute"].append({**meta, "state": sname, **cost_})   # v45
                inf_h = int(count_macs(h)["macs"])         # v46: analytic forward MACs / example, additions deleted
                for c, al in als.items():
                    load_with(h, base, keys, al)
                    e, pc_ = measure(h)
                    fn = "layer_transplant" if any(al) else ("branch_deleted" if had else "native")
                    staged["codes"].append({**meta, "state": sname, "code": c, "function": fn,
                                            "code_meaning": code_meaning(c, had), **e,
                                            "inference_macs_per_example": inf_h,
                                            **{f"f0_{k}": v for k, v in f0e.items()}})
                    if a.save_extractions and sname == "abrupt" and c == x1_code:
                        save_extraction(h, pc_, f"{tid}__2U_extraction_additions_deleted", tid, c, "deleted")
                    if c in (z_code, x1_code):
                        code_preds[c] = pc_["test"]          # v47: the grid's corners are checked against these
                if a.implant_codes and had:
                    # v44: the same codes with the additions PRESENT: the raw graph (gates as recorded), its backbone
                    # layers mixed toward f0 by the same arithmetic; all-zeros must reproduce the unedited state
                    n_imp_states += 1
                    g_raw = GraphNet.from_checkpoint(sk["model"], dev).eval()
                    g_raw._plan = None
                    gb = {k: v.clone() for k, v in g_raw.state_dict().items()}
                    gk = {Lk: [k for k in gb if k.startswith(f"mods.{Lk}.")] for Lk in L}
                    if any(sorted(gk[Lk]) != sorted(keys[Lk]) or any(gb[k].shape != f0_sd[k].shape for k in gk[Lk])
                           for Lk in L):
                        raise Fail(f"{sname}: the raw graph's backbone tensors differ from f0's")
                    bb_del = max(float((gb[k].double() - base[k].double()).abs().max()) for Lk in L for k in gk[Lk])
                    _, p_raw = measure(g_raw)
                    if is_endpoint and not torch.equal(p_raw["test"], pn["test"]):
                        raise Fail(f"{sname}: the raw graph does not reproduce the native endpoint")
                    load_with(g_raw, gb, gk, tuple([0.0] * K))
                    _, p_raw0 = measure(g_raw)
                    if not torch.equal(p_raw0["test"], p_raw["test"]):
                        raise Fail(f"{sname}: the zero code with the additions present changes the state")
                    chk["implants_zero_code_identity"] = True
                    inf_raw = int(count_macs(g_raw)["macs"])    # v46: with the additions (gates as recorded)
                    chk["backbone_change_on_deletion_max_abs"] = bb_del
                    imp_x1_preds = None
                    for c, al in als.items():
                        load_with(g_raw, gb, gk, al)
                        e, pg_ = measure(g_raw)
                        if a.save_extractions and sname == "abrupt" and c == x1_code:
                            save_extraction(g_raw, pg_, f"{tid}__2U_extraction_additions_present", tid, c, "present")
                        if c == x1_code:
                            imp_x1_preds = pg_["test"]
                        staged["codes_implants"].append({
                            **meta, "state": sname, "code": c, "function": "implants_present",
                            "code_meaning": code_meaning(c, False) + ", additions present",
                            "backbone_change_on_deletion_max_abs": bb_del, **e,
                            "inference_macs_per_example": inf_raw,
                            **{f"f0_{k}": v for k, v in f0e.items()}})
                    if a.reversal_grid and sname == "abrupt":
                        # v47: the 5x5 coordinated-reversal grid at 2U, the first layer kept throughout
                        if imp_x1_preds is None or z_code not in code_preds or x1_code not in code_preds:
                            raise Fail(f"--reversal-grid needs the codes {z_code} and {x1_code} in --codes")
                        # the additions' gates as the removal attaches them (cop.graph.edits.add_gate on every leaf
                        # addition: a branch's merge coefficient times its gate; no new parameters), all at 1 (the
                        # function unchanged), then scaled together by alpha; gates the state already has are scaled
                        # with them.  alpha = 0 removes every branch contribution, nested ones included.
                        leaves = sorted([t_ for t_, im_ in g_raw.implants.items() if im_.nodes and not any(
                            o_.parent == t_ and o_.nodes for o_ in g_raw.implants.values())],
                            key=lambda s_: int(s_[1:]))
                        g0 = dict(g_raw.gate_vals)
                        new_g = [E.add_gate(g_raw, t_, 1.0) for t_ in leaves]
                        if set(g_raw.state_dict()) != set(gb):
                            raise Fail("gating the additions changed the parameter set")
                        chk["reversal_grid_gated_additions"] = " ".join(leaves)
                        grid_preds, grid_rows_, cellp = [], [], {}
                        for al_ in GRID_LEVELS:
                            for be_ in GRID_LEVELS:
                                g_raw.gate_vals = {**{k_: v_ * al_ for k_, v_ in g0.items()},
                                                   **{k_: al_ for k_ in new_g}}
                                load_with(g_raw, gb, gk, tuple([0.0] + [1.0 - be_] * (K - 1)))
                                e, pq = measure(g_raw)
                                cellp[(al_, be_)] = pq
                                grid_rows_.append({**meta, "state": "2U", "alpha": al_, "beta": be_,
                                                   **with_ce(e, pq), "rewind_is_noop": dsc == 0.0,
                                                   "training_access": access_fields(
                                                       {**meta, "parent_freeze_inputs": meta.get(
                                                           "parent_freeze_inputs"), "source": src},
                                                       "grid")["training_access"],
                                                   "intervention_access": "none (gate scaling and parameter "
                                                                          "interpolation; no feature labels)",
                                                   "inference_macs_per_example": inf_raw if al_ > 0 else inf_h})
                        # the corners are the existing models exactly: native, deletion by zero gates = the
                        # compact deletion, the restored backbone with additions, the extraction
                        for (al_, be_), ref_, lab in (((1.0, 1.0), p_raw["test"], "the native state"),
                                                      ((0.0, 1.0), code_preds[z_code], "the deletion (zero gates)"),
                                                      ((1.0, 0.0), imp_x1_preds, "the restored backbone + additions"),
                                                      ((0.0, 0.0), code_preds[x1_code], "the extraction")):
                            if not torch.equal(cellp[(al_, be_)]["test"], ref_):
                                dd_ = (cellp[(al_, be_)]["test"].double() - ref_.double()).abs()
                                raise Fail(f"reversal grid corner ({al_}, {be_}) does not reproduce {lab}: max |diff| "
                                           f"{float(dd_.max()):.3g}, rel {float(dd_.max() / ref_.abs().max()):.3g}, "
                                           f"decisions differ {int((cellp[(al_, be_)]['test'].argmax(-1) != ref_.argmax(-1)).sum())}")
                        nat_c = cellp[(1.0, 1.0)]["test"].argmax(-1)
                        ext_c = cellp[(0.0, 0.0)]["test"].argmax(-1)
                        for r_ in grid_rows_:
                            pc = cellp[(r_["alpha"], r_["beta"])]["test"].argmax(-1)
                            r_["disagreement_vs_native"] = float((pc != nat_c).double().mean())
                            r_["disagreement_vs_extraction"] = float((pc != ext_c).double().mean())
                            grid_preds.append(pc.cpu().numpy())
                        chk["reversal_grid_corners_exact"] = True
                        staged["reversal_grid"].extend(grid_rows_)
                        save_pred_array(f"{d.name}__2U_grid", grid_preds,
                                        {"run_id": d.name, "trajectory": tid, "order": "alpha-major",
                                         "levels": GRID_LEVELS, "partition": "test"},
                                        [cellp[(r_["alpha"], r_["beta"])]["test"].float().cpu().numpy()
                                         for r_ in grid_rows_])
                        del cellp
                    del g_raw
                if a.grid:
                    for al in itertools.product((0.0, 0.5, 1.0) if K <= 5 else (0.0, 1.0), repeat=K):
                        load_with(h, base, keys, al)
                        e, _ = measure(h)
                        staged["grid"].append({**meta, "state": sname, "code": "-".join(f"{x:g}" for x in al),
                                               **{k: e[k] for k in (f"{selp}_err", "val_err", "test_err")},
                                               "f0_test_err": f0e["test_err"], "sel_partition": selp})
                if comp is not None:
                    W1, dE, b1 = state_parts(base)
                    dW = W1 - comp["W0"]
                    Qd = comp["Qd"]
                    rt = float(((dE @ Qd) - dW).norm() / max(1e-30, float(dW.norm()))) if Qd is not None else 0.0
                    sc_chg = float(dW[:, comp["groups"]["shortcut"]].abs().max()) if Qd is None else \
                        float(dE[:, comp["groups"]["shortcut"]].abs().max())
                    if fz_lineage and sc_chg != 0.0:
                        raise Fail(f"{sname}: the shortcut column moved ({sc_chg:.3g}) in a lineage that froze it")
                    chk["shortcut_column_change_max_abs"] = sc_chg
                    load_with(h, base, keys, tuple([0.0] + [1.0] * (K - 1)))
                    _, p_first = measure(h)
                    dpred = {}
                    for mask in itertools.product((0, 1), repeat=4):
                        use = dict(zip(("shortcut", "causal", "noise", "bias"), mask))
                        gname = "+".join(k for k, v in use.items() if v) or "none"
                        e, pr = subset_probe(h, base, keys, gname, p_first=p_first)
                        dpred[gname] = pr["test"]
                        staged["decomposition"].append({**meta, "state": sname, "update_groups": gname,
                                                        **{f"with_{k}": v for k, v in use.items()}, **e,
                                                        **{f"f0_{k}": v for k, v in f0e.items()},
                                                        "rotation_round_trip_residual": rt,
                                                        "shortcut_column_change_max_abs": sc_chg})
                    chk["decomposition_identities"] = True
                    chk["rotation_round_trip_residual"] = rt
                    dec_preds[sname] = dpred
                    pstage = (cfg.get("tags") or {}).get("parent_stage", "final")
                    cross_ok = src == "removal" and not kind.startswith("rebuild_") and pstage == "final"
                    if a.cross and is_endpoint and src == "removal" and not cross_ok:
                        coverage["cross_excluded"].append({"run_id": d.name, "reason": (
                            "a rebuilt start" if kind.startswith("rebuild_") else
                            f"the job starts from the trajectory's {pstage}, not its final checkpoint")})
                    if a.cross and is_endpoint and cross_ok:
                        # v39: 'before' = the trajectory's end (additions deleted), 'after' = this endpoint; the
                        # causal and the shortcut column changes from either, crossed; noise and bias at f0 (primary)
                        # or from 'after' (secondary); every other backbone layer is f0's.  v41: the decomposition's
                        # arithmetic, so a crossing that equals a decomposition subset reproduces it
                        n_cross_endpoints += 1
                        if "trajectory_end" not in before_cache:
                            ckb = checked(ckp(td, "final"), "trajectory_end", tid, "final")
                            _, _, bb, _ = prepare(ckb["model"], "trajectory_end")
                            before_cache["trajectory_end"] = state_parts(bb)
                        _, dEb, _ = before_cache["trajectory_end"]
                        dE_by = {"before": dEb, "after": dE}
                        # the identities: same state and graph -> bitwise; 'before/before/f0' against the abrupt
                        # state's decomposition (the same trajectory end, another compact graph object) -> bitwise,
                        # else max |diff| <= 1e-5 with identical decisions
                        ref_ = {("after", "after", "f0"): (dec_preds[sname]["shortcut+causal"], True),
                                ("after", "after", "after"): (dec_preds[sname]["shortcut+causal+noise+bias"], True)}
                        if "abrupt" in dec_preds:
                            ref_[("before", "before", "f0")] = (dec_preds["abrupt"]["shortcut+causal"], False)
                        for cfrom in ("before", "after"):
                            for sfrom in ("before", "after"):
                                for nb in ("f0", "after"):
                                    srcs = {"causal": dE_by[cfrom], "shortcut": dE_by[sfrom],
                                            "noise": dE_by[nb] if nb != "f0" else None}
                                    exact = W1 if (cfrom == sfrom == nb == "after") else None
                                    e, pr = first_layer_probe(h, base, mixed_weight(srcs, exact),
                                                              b1.clone() if (nb == "after" and b1 is not None) else None)
                                    comb = f"causal@{cfrom}+shortcut@{sfrom}+noise_bias@{nb}"
                                    ident, idiff = None, None
                                    if (cfrom, sfrom, nb) in ref_:
                                        want, strict = ref_[(cfrom, sfrom, nb)]
                                        idiff = float((pr["test"].double() - want.double()).abs().max())
                                        if torch.equal(pr["test"], want):
                                            ident = "bitwise"
                                        elif not strict and idiff <= 1e-5 and \
                                                torch.equal(pr["test"].argmax(-1), want.argmax(-1)):
                                            ident = "within 1e-5, same decisions"
                                        else:
                                            raise Fail(f"{sname}: cross {comb} does not reproduce its decomposition "
                                                       f"subset (max |diff| {idiff:.3g})")
                                    staged["cross"].append({**meta, "state": sname, "combination": comb,
                                                            "causal_from": cfrom, "shortcut_from": sfrom,
                                                            "noise_bias_from": nb, "decomposition_identity": ident,
                                                            "identity_max_abs_diff": idiff,
                                                            "parent_stage": pstage, **e,
                                                            **{f"f0_{k}": v for k, v in f0e.items()}})
                    if a.scale_controls:
                        staged["scale"] += scale_rows(h, base, sname, dE, dec_preds[sname]["causal"])
                h.load_state_dict(base)
                staged["checks"].append(chk)
            # ---- trace inventory (v34: from the job's config; the job's ledger must match it exactly)
            if a.trace:
                if src == "removal":
                    tcfg_ = (mcfg or {}).get(tid) or rj(td / "config.json")
                    U_ = int(tcfg_["growth"]["updates_per_round"])
                    R_ = int(tcfg_["growth"].get("rounds", 1))
                    if tid not in trajcache:          # a shared trajectory history is evaluated once
                        claimed.append(tid)
                        history += [("trajectory", (f"traj_post_insert_r{r}", td / "ckpt" / f"post_insert_r{r}.pt",
                                                    f"trajectory round {r} at insertion", (r - 1) * U_, "config"))
                                    for r in range(1, R_ + 1)]
                        # v41: the trajectory's snapshots (the configured train.snapshot_at, ages of the additions)
                        for u in sorted({int(u) for u in (tcfg_.get("train") or {}).get("snapshot_at") or []
                                         if 0 < int(u) < R_ * U_}):
                            history.append(("trajectory", (f"traj_snap_{u}", td / "ckpt" / f"snap_{u}.pt",
                                                           "trajectory snapshot", u, "config")))
                        history.append(("trajectory", ("traj_final", td / "ckpt" / "final.pt",
                                                       "trajectory end (expanded)", R_ * U_, "config")))
                    exp_ph, exp_ev = expected_schedule(cfg)
                    j = rj(d / "dissipation_result.json")
                    sa = j.get("schedule_audit") or {}
                    if not sa:
                        raise Fail("trace: the job has no schedule ledger (results from before v31)")
                    got_ph = [(str(x["phase"]), int(x["start_update"]), int(x["declared_updates"]))
                              for x in sa.get("phases") or []]
                    if got_ph != [(n_, s_, k_) for n_, s_, k_ in exp_ph] or \
                            any(int(x["updates"]) != int(x["declared_updates"]) for x in sa.get("phases") or []):
                        raise Fail(f"trace: logged phases {got_ph} differ from the config's {exp_ph}")
                    got_ev = [(str(x["event"]), x.get("checkpoint"), x.get("phase")) for x in sa.get("events") or []]
                    if got_ev != exp_ev:
                        raise Fail(f"trace: logged events {got_ev} differ from the config's {exp_ev}")
                    for ev_, ck_, _ in exp_ev:
                        if ck_:
                            upd_ = next(int(x["update"]) for x in sa["events"] if x.get("checkpoint") == ck_)
                            history.append(("job", (f"event_{ev_}", d / "ckpt" / f"{ck_}.pt", f"event {ev_}",
                                                    R_ * U_ + upd_, "config")))
                    if cfg["dissipation"].get("save_path_checkpoints"):
                        early = [int(k) for k in (cfg["dissipation"].get("early_eval") or [])]
                        n_pts = max(2, int(cfg["dissipation"].get("path_eval_points", 20)))
                        for name_, start_, n_ in exp_ph:
                            # the dense early repair checkpoints, and (v41) each phase's last update when the
                            # path schedule saved it (joint order: every = max(1, n // n_pts)), e.g. the end of the
                            # gate anneal
                            ks = {k for k in early if 1 <= k <= n_} if name_.startswith(("post_", "recover_", "keep_")) \
                                else set()
                            if n_ % max(1, n_ // n_pts) == 0:
                                ks.add(n_)
                            for k in sorted(ks):
                                u = start_ + k
                                history.append(("job", (f"removal_u{u}", d / "ckpt" / f"path_u{u}.pt",
                                                        f"{name_} +{k}", R_ * U_ + u, "config")))
                elif (cfg.get("continue") or {}).get("save_eval_checkpoints"):
                    cr = rj(d / "continue_result.json")
                    total_ = int(cr["requested_updates"])
                    for u in sorted({int(u) for u in (cfg.get("continue") or {}).get("eval_at") or []
                                     if 0 < int(u) <= total_}):
                        history.append(("job", (f"at_{u}", d / "ckpt" / f"at_{u}.pt", "control", int(u), "config")))
                seen = set()
                for owner, (tag, path, phase, upd, usrc) in history:
                    if (tag, str(path)) in seen:
                        continue
                    seen.add((tag, str(path)))
                    if not path.exists():
                        raise Fail(f"trace: required checkpoint {path.relative_to(runs)} missing")
                    # v43: the preflight loads and checks every checkpoint too (lineage, hashes, owner config),
                    # once per file, without evaluating anything
                    ck_t = checked(torch.load(path, map_location="cpu", weights_only=False), f"trace {tag}",
                                   path.parent.parent.name, path.stem)
                    if a.preflight:
                        continue
                    h, had, base, keys = prepare(ck_t["model"], tag)
                    tv_ = traj_variants.get(tid) or {meta["variant"]}
                    tm = dict(meta) if owner == "job" else {
                        **meta, "run_id": cfg["parents"]["trajectory"], "source": "trajectory", "arm": "trajectory",
                        "removal_variant": "trajectory", "fork_masks": None, "fork_optimizer": None,
                        # v43: the trajectory's own training metadata, never its first child's
                        "variant": next(iter(tv_)) if len(tv_) == 1 else "mixed:" + "+".join(sorted(map(str, tv_))),
                        "freeze_inputs": (tcfg_.get("train") or {}).get("freeze_inputs", "none"),
                        "parent_freeze_inputs": None, "parent": (tcfg_.get("parents") or {}).get("baseline"),
                        "freeze_backbone": (tcfg_.get("train") or {}).get("freeze_backbone", "none"),
                        "parent_freeze_backbone": None}
                    where = {"checkpoint": tag, "checkpoint_file": str(path.relative_to(runs)), "phase": phase,
                             "updates_since_f0": upd, "update_source": usrc,
                             "update_origin": "updates since f0 (excluding f0's own training)"}
                    dsc_t = downstream_change(base)
                    bh_here = (bh_lineage or (frozen_until is not None and bh_job_sched and upd <= frozen_until)) \
                        if owner == "job" else bh_traj
                    if bh_here and dsc_t != 0.0:
                        raise Fail(f"trace {tag}: layers 2..K moved ({dsc_t:.3g}) in a lineage that held them at f0")
                    where["downstream_change_max_abs"] = dsc_t
                    where.update(cost_of(None, ck_t, owner))                 # v45: training cost since f0
                    use_ = als if (a.codes_at_2u and fork_u is not None and upd == fork_u) else tals
                    where["inference_macs_per_example"] = int(count_macs(h)["macs"])     # v46
                    if a.trace_implants and owner == "trajectory" and had:
                        # v47: the 2x2 at this expansion age: additions present / deleted x layers 2..K trained /
                        # restored to f0, the first layer kept (weights and bias)
                        g_r, gbr, gkr = raw_graph(ck_t["model"], f"trace {tag}")
                        x1_al = tuple([0.0] + [1.0] * (K - 1))
                        z_al = tuple([0.0] * K)
                        pp, pl = {}, {}
                        for cell_, mdl_, base_, keys_, al_ in (
                                ("present_trained", g_r, gbr, gkr, z_al), ("present_rewound", g_r, gbr, gkr, x1_al),
                                ("deleted_trained", h, base, keys, z_al), ("deleted_rewound", h, base, keys, x1_al)):
                            load_with(mdl_, base_, keys_, al_)
                            e, pq = measure(mdl_)
                            pp[cell_] = pq["test"].argmax(-1).cpu().numpy()
                            pl[cell_] = pq["test"].float().cpu().numpy()
                            staged["reversal_2x2"].append({
                                **tm, **where, "reversal_cell": cell_, **with_ce(e, pq),
                                "rewind_is_noop": dsc_t == 0.0,
                                "training_access": access_fields({**tm, "source": "compact-like"}, "x")[
                                    "training_access"],
                                "intervention_access": "none (deletion and parameter restoration; no feature labels)"})
                        save_pred_array(f"{tm['run_id']}__{tag}_2x2", [pp[c_] for c_ in CELLS_2X2],
                                        {"run_id": tm["run_id"], "checkpoint": tag, "cells": CELLS_2X2,
                                         "updates_since_f0": upd, "partition": "test"},
                                        [pl[c_] for c_ in CELLS_2X2])
                        del g_r
                    for c, al in use_.items():
                        load_with(h, base, keys, al)
                        e, pt_ = measure(h)
                        if a.save_extractions and owner == "job" and src != "removal" and upd == fork_u \
                                and c == x1_code:
                            save_extraction(h, pt_, f"{d.name}__2U_extraction", d.name, c, "none (compact)")
                        staged["trace"].append({**tm, **where, "code": c, "code_meaning": code_meaning(c, had),
                                                "code_set": "codes" if use_ is als else "trace_codes", **e,
                                                **{f"f0_{k}": v for k, v in f0e.items()}})
                    if comp is not None:
                        # v41: the component trace, the named-state decomposition's arithmetic at every checkpoint
                        n_trace_ckpts += 1
                        _, dE_t, _ = state_parts(base)
                        sc_t = float(dE_t[:, comp["groups"]["shortcut"]].abs().max())
                        fz_here = (fz_lineage or (frozen_until is not None and fz_job_sched
                                                  and upd <= frozen_until)) if owner == "job" else fz_traj
                        if fz_here and sc_t != 0.0:
                            raise Fail(f"trace {tag}: the shortcut column moved ({sc_t:.3g}) in a lineage that froze it")
                        where = {**where, "shortcut_column_change_max_abs": sc_t}
                        load_with(h, base, keys, tuple([0.0] + [1.0] * (K - 1)))
                        _, p_first_t = measure(h)
                        for gname in TRACE_SUBSETS:
                            e, _ = subset_probe(h, base, keys, gname, p_first=p_first_t)
                            staged["decomposition_trace"].append({**tm, **where, "update_groups": gname, **e,
                                                                  **{f"f0_{k}": v for k, v in f0e.items()}})
                    if a.displacement and owner == "job":
                        n_disp += 1
                        staged["displacement"].append({**tm, **where, **displacement(
                            ck_t, start_ck, None if start_upd is None else upd - start_upd, start_label)})
                        if ref2 is not None and upd > fork_u:
                            # v43: a compact control also from its own state at the end of the expansion (2U)
                            n_disp += 1
                            staged["displacement"].append({**tm, **where, **displacement(
                                ck_t, ref2, upd - fork_u, f"own at_{fork_u}", from_job_start=False)})
                    h.load_state_dict(base)
            if a.displacement and not a.preflight:
                # the named endpoint too (every job), so a job without trace checkpoints still has one row; its
                # updates are the job's own (the removal schedule's phases, or the continuation's update count)
                sk_end = next(sk for sk, ie in states.values() if ie)
                if src == "removal":
                    n_job = sum(int(n_) for _, _, n_ in expected_schedule(cfg)[0])
                else:
                    cr_ = rj(d / "continue_result.json") if (d / "continue_result.json").exists() else {}
                    n_job = cr_.get("requested_updates")
                n_disp += 1
                staged["displacement"].append({**meta, "checkpoint": "endpoint", "updates_since_f0": None,
                                               **displacement(sk_end, start_ck, n_job, start_label)})
                if ref2 is not None:
                    n_disp += 1
                    staged["displacement"].append({**meta, "checkpoint": "endpoint", "updates_since_f0": None,
                                                   **displacement(sk_end, ref2, None if n_job is None
                                                                  else int(n_job) - fork_u,
                                                                  f"own at_{fork_u}", from_job_start=False)})
            if a.preflight:
                coverage["analysed"] += 1
                continue
            if src != "removal" and (cfg.get("continue") or {}).get("fork_audit"):
                staged["compact_fork_audit"] += compact_audit_rows(meta, cfg, rj(d / "continue_result.json"))
            if src == "removal" and kind in KEEP_FORKS and len(design.get(des.get("variant"), ())) > 1:
                # a fork of a factorial (more than one continuation setting for the variant): audit required
                staged["fork_audit"].append(fork_audit_row(meta, rj(d / "dissipation_result.json")))
            # ---- v41: the per-job inventory (exact row counts, unique keys, finite values) before any commit
            drop = os.environ.get("COP_TEST_DROP")          # test hook: drop one row of a table, which must fail
            if drop and staged.get(drop):
                staged[drop].pop()
            n_end = sum(1 for _, ie in states.values() if ie)
            want = {"codes": (len(als) * len(states), ("state", "code")), "native": (n_end, ("state",)),
                    "compute": (len(states), ("state",))}
            if a.implant_codes:
                want["codes_implants"] = (len(als) * n_imp_states, ("state", "code"))
            if a.displacement:
                want["displacement"] = (n_disp, ("checkpoint", "reference_checkpoint"))
            if comp is not None:
                want["decomposition"] = (16 * len(states), ("state", "update_groups"))
                if a.scale_controls:
                    want["scale"] = (N_SCALE_CONTROLS * len(states), ("state", "control"))
                if a.cross:
                    want["cross"] = (8 * n_cross_endpoints, ("state", "combination"))
                if a.trace:
                    want["decomposition_trace"] = (len(TRACE_SUBSETS) * n_trace_ckpts,
                                                   ("run_id", "checkpoint", "update_groups"))
            elif a.decompose and staged.get("decomposition"):
                raise Fail("inventory: decomposition rows without an applicable decomposition")
            for tname, (n_want, kcols) in want.items():
                rows_ = staged.get(tname, [])
                if len(rows_) != n_want:
                    raise Fail(f"inventory: {tname} has {len(rows_)} rows, expected {n_want}")
                if len({tuple(r[c] for c in kcols) for r in rows_}) != len(rows_):
                    raise Fail(f"inventory: duplicate {tname} keys")
            for tname, rows_ in staged.items():
                for r in rows_:
                    if any(isinstance(v, float) and not math.isfinite(v) for v in r.values()):
                        raise Fail(f"inventory: a non-finite value in {tname}")
            for k_, v_ in staged.items():
                out[k_] += v_
                coverage["inventory"][k_] += len(v_)
            trajcache.update(claimed)
            coverage["analysed"] += 1
            coverage["by_variant"][f"{src}:{kind}:{meta['arm']}"] += 1
        except Exception as ex:                          # noqa: BLE001  (every failure is a coverage failure)
            why = str(ex) if isinstance(ex, Fail) else f"{type(ex).__name__}: {ex}"
            coverage["failed"].append({"run_id": d.name, "reason": why})
            for k_, v_ in staged.items():
                partial += [{**r, "partial_table": k_, "failure": why} for r in v_]

    # v43: a declared outcome (an excluded job) holds no partner: its design key leaves the requirements unless
    # another, analysed job shares it
    excl = {e["run_id"] for e in coverage["excluded"]}
    keep_keys = {k for rid, k in design_rid.items() if rid not in excl}
    design_jobs = {k for k in design_jobs if k in keep_keys}
    if a.preflight:
        coverage["by_variant"] = dict(coverage["by_variant"])
        coverage["inventory"] = {}
        coverage["n_failed"] = len(coverage["failed"])
        coverage["n_excluded"] = len(coverage["excluded"])
        coverage["passed"] = (coverage["n_failed"] == 0 and coverage["analysed"] > 0 and
                              coverage["analysed"] + coverage["n_excluded"] == coverage["expected"])
        atomic_json(f"{a.out_prefix}_coverage.json", coverage)
        print(json.dumps({k: coverage[k] for k in ("expected", "analysed", "n_failed", "n_excluded", "passed")}),
              "first failures:", coverage["failed"][:3])
        return 0 if coverage["passed"] else 1
    cs, cd, csum = levels(out["codes"], "code")
    # paired contrasts against C1's final state with the same code, matched on the data draw AND the optimizer
    # setting (an arm run at one setting is never compared with C1 averaged over settings).  v43: separately for
    # each C1 variant (reference_variant), never by overwrite; missing partners and duplicates fail coverage
    contrasts, ccnt = c1_contrasts(cs, "code", design_jobs, "c1_same_code_test_err", "gain_vs_c1_same_code")
    contrasts = [{**{k: r[k] for k in ("cell", "variant", "arm", "removal_variant", "state", "code", "draw_set",
                                        "data_draw", "optimizer_seed", "run_ids", "reference_variant",
                                        "reference_arm", "reference_state", "reference_run_ids")},
                  "test_err": r["test_err"], "c1_same_code_test_err": r["c1_same_code_test_err"],
                  "gain_vs_c1_same_code": r["gain_vs_c1_same_code"], "partner_missing": r["partner_missing"]}
                 for r in contrasts]
    coverage["contrast_partners_missing"] = ccnt["missing"] + ccnt["duplicates"]
    coverage["contrast_counts"] = ccnt
    P = a.out_prefix
    atomic_csv(f"{P}_codes.csv", out["codes"])
    atomic_csv(f"{P}_codes_by_setting.csv", cs)
    atomic_csv(f"{P}_codes_by_draw.csv", cd)
    atomic_csv(f"{P}_codes_summary.csv", csum)
    atomic_csv(f"{P}_contrasts.csv", contrasts)
    if a.implant_codes:
        # v44: the codes with the additions present, and paired against the same code with them deleted (same job
        # and state): value = err(present) - err(deleted), positive = deleting the additions lowers test error
        _, ci_d, ci_s = levels(out["codes_implants"], "code")
        atomic_csv(f"{P}_codes_implants.csv", out["codes_implants"])
        atomic_csv(f"{P}_codes_implants_by_draw.csv", ci_d)
        atomic_csv(f"{P}_codes_implants_summary.csv", ci_s)
        dele = {(r["run_id"], r["state"], r["code"]): r["test_err"] for r in out["codes"]}
        ip = [{**{k: r[k] for k in ("run_id", "cell", "variant", "arm", "removal_variant", "state", "code",
                                     "draw_set", "data_draw", "optimizer_seed", "partition_seed")},
               "present_test_err": r["test_err"], "deleted_test_err": dele[(r["run_id"], r["state"], r["code"])],
               "value": r["test_err"] - dele[(r["run_id"], r["state"], r["code"])]}
              for r in out["codes_implants"]]
        ipb, ips = two_stage(ip, ("cell", "variant", "arm", "removal_variant", "state", "code", "draw_set"), "value")
        atomic_csv(f"{P}_codes_implants_contrasts_by_draw.csv", ipb)
        atomic_csv(f"{P}_codes_implants_contrasts.csv",
                   [{**r, "sign": "positive = deleting the additions lowers test error"} for r in ips])
    ds_, dd_, dsum = levels(out["decomposition"], "update_groups")
    atomic_csv(f"{P}_decomposition.csv", out["decomposition"])
    atomic_csv(f"{P}_decomposition_by_draw.csv", dd_)
    atomic_csv(f"{P}_decomposition_summary.csv", dsum)
    # v41: the native (unedited) endpoints
    ns_, nd_, nsum = levels(out["native"], "measure")
    atomic_csv(f"{P}_native.csv", out["native"])
    atomic_csv(f"{P}_native_summary.csv", nsum)
    pair_fail = 0
    if a.decompose:
        # v41: each arm's component rows against C1's same components; v43: per C1 variant, one implementation
        dvc, dcnt = c1_contrasts(ds_, "update_groups", design_jobs, "c1_test_err", "gain_vs_c1")
        _, dvc_sum = two_stage(dvc, ("cell", "variant", "arm", "removal_variant", "state", "update_groups",
                                     "draw_set", "reference_variant"), "gain_vs_c1")
        vp, vp_sum, vcnt = variant_pairs(ds_, "update_groups", design_jobs)
        coverage["decomposition_contrast_partners_missing"] = dcnt["missing"] + dcnt["duplicates"]
        coverage["decomposition_contrast_counts"] = dcnt
        coverage["variant_pair_counts"] = vcnt
        pair_fail += vcnt["missing"] + vcnt["duplicates"]
        atomic_csv(f"{P}_decomposition_contrasts.csv",
                   [{**r, "contrast": f"vs C1 ({r['reference_variant']}), same components",
                     "sign": "positive = lower test error than C1"} for r in dvc] + vp)
        atomic_csv(f"{P}_decomposition_contrasts_summary.csv",
                   [{**r, "contrast": f"vs C1 ({r['reference_variant']}), same components"} for r in dvc_sum] + vp_sum)
    # v42/v43: the native endpoints against C1 (per variant) and in the variant pairs; per-setting, per-draw and
    # summary tables
    nvc, ncnt = c1_contrasts(ns_, "measure", design_jobs, "c1_test_err", "gain_vs_c1")
    nvp, nvp_sum, nvcnt = variant_pairs(ns_, "measure", design_jobs)
    coverage["native_contrast_counts"] = {"vs_c1": ncnt, "variant_pairs": nvcnt}
    pair_fail += ncnt["missing"] + ncnt["duplicates"] + nvcnt["missing"] + nvcnt["duplicates"]
    nb_vc, ns_vc = two_stage(nvc, ("cell", "variant", "arm", "removal_variant", "state", "measure",
                                   "reference_variant"), "gain_vs_c1")
    nb_vp, _ = two_stage(nvp, ("cell", "arm", "removal_variant", "state", "measure", "contrast"), "value")
    atomic_csv(f"{P}_native_contrasts_by_setting.csv",
               [{**r, "contrast": f"vs C1 ({r['reference_variant']})"} for r in nvc] + nvp)
    atomic_csv(f"{P}_native_contrasts_by_draw.csv",
               [{**r, "contrast": f"vs C1 ({r['reference_variant']})"} for r in nb_vc] + nb_vp)
    atomic_csv(f"{P}_native_contrasts.csv",
               [{**r, "contrast": f"vs C1 ({r['reference_variant']})"} for r in ns_vc] + nvp_sum)
    coverage["pair_failures"] = pair_fail
    if a.displacement:
        dsp = out["displacement"]
        atomic_csv(f"{P}_displacement.csv", dsp)
        dsum = []
        for col in DISP_METRICS:
            rows_ = [{**r, "update": r["updates_since_reference"] if r["checkpoint"] != "endpoint" else "endpoint",
                      "measure": col, "v": r.get(col)} for r in dsp if r.get(col) is not None]
            _, sm = two_stage(rows_, ("cell", "variant", "arm", "removal_variant", "freeze_inputs",
                                      "freeze_backbone", "reference_checkpoint", "measure", "update"), "v")
            dsum += sm
        atomic_csv(f"{P}_displacement_summary.csv", dsum)
    if a.cross:
        _, cxd, cxs = levels(out["cross"], "combination")
        atomic_csv(f"{P}_cross.csv", out["cross"])
        atomic_csv(f"{P}_cross_by_draw.csv", cxd)
        atomic_csv(f"{P}_cross_summary.csv", cxs)
        cc_draw, cc_sum = cross_contrasts(out["cross"])
        atomic_csv(f"{P}_cross_contrasts.csv", cc_sum)
        atomic_csv(f"{P}_cross_contrasts_by_draw.csv", cc_draw)
    if a.scale_controls:
        _, scd, scs = levels(out["scale"], "control")
        atomic_csv(f"{P}_scale.csv", out["scale"])
        atomic_csv(f"{P}_scale_by_draw.csv", scd)
        atomic_csv(f"{P}_scale_summary.csv", scs)
        # v41: each control against the causal transplant of the same job and state (positive = the transplant
        # has the lower test error)
        tp = {(r["run_id"], r["state"]): r["test_err"] for r in out["scale"] if r["control"] == "causal_transplant"}
        sc_pairs = [{**{k: r[k] for k in ("run_id", "cell", "variant", "arm", "removal_variant", "state", "draw_set",
                                         "data_draw", "optimizer_seed", "partition_seed", "control")},
                     "control_test_err": r["test_err"], "transplant_test_err": tp[(r["run_id"], r["state"])],
                     "control_minus_transplant": r["test_err"] - tp[(r["run_id"], r["state"])]}
                    for r in out["scale"] if r["control"] != "causal_transplant"]
        scb, scsum = two_stage(sc_pairs, ("cell", "variant", "arm", "removal_variant", "state", "draw_set", "control"),
                               "control_minus_transplant")
        atomic_csv(f"{P}_scale_contrasts.csv",
                   [{**r, "sign": "positive = the causal transplant has the lower test error"} for r in scsum])
        atomic_csv(f"{P}_scale_contrasts_by_draw.csv", scb)
        # v46: the residual-versus-magnitude questions as direct paired contrasts (same run and state), seeds
        # averaged within a draw, intervals over draws
        rc_rows, rc_missing = residual_contrasts(out["scale"])
        rcb, rcs = two_stage(rc_rows, ("cell", "variant", "arm", "removal_variant", "state", "draw_set", "contrast",
                                       "sign"), "value")
        atomic_csv(f"{P}_residual_contrasts_by_setting.csv", rc_rows)
        atomic_csv(f"{P}_residual_contrasts_by_draw.csv", rcb)
        atomic_csv(f"{P}_residual_contrasts.csv", rcs)
        coverage["residual_contrast_partners_missing"] = rc_missing
        coverage["scale_grid_edge_hits"] = sum(bool(r.get("alpha_causal_at_grid_edge")) or
                                               bool(r.get("alpha_shortcut_at_grid_edge")) for r in out["scale"])
        # v43: the independent cases are the unique (f0, data, selection partition) grids, not the rows
        coverage["scale_grid_edges_unique"] = {"grids": len(grid_edges),
                                               "causal_at_edge": sum(v["causal"] for v in grid_edges.values()),
                                               "combined_at_edge": sum(v["combined"] for v in grid_edges.values()),
                                               "grid_causal": [A_GRID_[0], A_GRID_[-1]]}
        # v43: every agreement / fit / norm metric aggregated within setting and draw, summarised over draws
        mrows = [{**{k: r[k] for k in ("cell", "variant", "arm", "removal_variant", "state", "control", "data_draw",
                                       "optimizer_seed")}, "metric": m, "v": r.get(m)}
                 for r in out["scale"] for m in SCALE_METRICS if r.get(m) is not None]
        smb, sms = two_stage(mrows, ("cell", "variant", "arm", "removal_variant", "state", "control", "metric"), "v")
        atomic_csv(f"{P}_scale_metrics_by_draw.csv", smb)
        atomic_csv(f"{P}_scale_metrics_summary.csv", sms)
        atomic_csv(f"{P}_scale_vectors.csv", out["scale_vectors"])
        coverage["scale_zero_norm_rows"] = sum(int(r["f0_causal_zero_norm_rows"]) +
                                               int(r["transplant_causal_zero_norm_rows"])
                                               for r in out["scale"] if r["control"] == "causal_transplant")
    if a.trace and a.decompose:
        atomic_csv(f"{P}_decomposition_trace.csv", out["decomposition_trace"])
    # v45: training cost since f0 by state, the paired-stream audit, the 2U extraction table, the saved extractions
    atomic_csv(f"{P}_compute.csv", out["compute"])
    cg = defaultdict(list)
    for r in out["compute"]:
        cg[(r["cell"], r["variant"], r["arm"], r["state"])].append(r)
    csum = []
    for k, rs in sorted(cg.items(), key=lambda t: tuple(map(str, t[0]))):
        row = dict(zip(("cell", "variant", "arm", "state"), k))
        row["n_runs"] = len(rs)
        row["cost_basis"] = rs[0]["cost_basis"]
        for f in ("cost_updates", "macs_3x_forward", "macs_backward_aware", "macs_forward", "macs_input_grad",
                  "macs_param_grad", "macs_param_grad_discarded", "macs_param_grad_used"):
            v_ = [r[f] for r in rs if r.get(f) is not None]
            row[f"mean_{f}"] = sum(v_) / len(v_) if len(v_) == len(rs) else None
        row["note"] = ("analytic estimate per example: linear-type nodes only, elementwise work not counted; "
                       "param_grad is what autograd computes (a hold keeps requires_grad and zeroes it after "
                       "backward); param_grad_used excludes the zeroed part")
        csum.append(row)
    atomic_csv(f"{P}_compute_summary.csv", csum)
    if a.paired_streams:
        atomic_csv(f"{P}_paired_streams.csv", out["paired_streams"])
        coverage["paired_stream_failures"] = paired_stream_failures(out["paired_streams"], design_jobs, fork_u)
        coverage["paired_stream_groups"] = len({(r["cell"], r["data_draw"], r["optimizer_seed"])
                                                for r in out["paired_streams"]})
        coverage["paired_stream_records"] = len({(r["role"], r["run_id"]) for r in out["paired_streams"]})
    if a.save_extractions:
        atomic_csv(f"{P}_extractions_saved.csv", out["extractions_saved"])
    want_ex = bool(a.codes_at_2u and a.implant_codes and fork_u is not None)
    if want_ex:
        ex_rows = extraction_2u_rows(out, fork_u)
        out["extraction_2u"] = ex_rows
        atomic_csv(f"{P}_extraction_2u.csv", ex_rows)
        exl, exd, exs = extraction_summaries(ex_rows)       # v46: errors and costs, long format
        atomic_csv(f"{P}_extraction_2u_by_setting.csv", exl)
        atomic_csv(f"{P}_extraction_2u_by_draw.csv", exd)
        atomic_csv(f"{P}_extraction_2u_summary.csv", exs)
    # v47: coordinated reversal: the 2x2 at every expansion age, the 5x5 grid at 2U and its three paths
    rev_bad = []
    if a.trace_implants:
        atomic_csv(f"{P}_reversal_2x2.csv", out["reversal_2x2"])
        ri = reversal_interactions(out["reversal_2x2"])
        atomic_csv(f"{P}_reversal_2x2_by_setting.csv", ri)
        long_ = [{**{k: r[k] for k in ("cell", "variant", "arm", "removal_variant", "draw_set", "data_draw",
                                        "optimizer_seed", "partition_seed", "checkpoint", "updates_since_f0",
                                        "rewind_is_noop", "training_access")}, "quantity": q, "v": float(r[q])}
                 for r in ri for q in [f"{c}_test_err" for c in CELLS_2X2] + ["interaction", "joint_vs_native"]]
        rb, rs_ = two_stage(long_, ("cell", "variant", "arm", "removal_variant", "draw_set", "checkpoint",
                                    "updates_since_f0", "rewind_is_noop", "training_access", "quantity"), "v")
        atomic_csv(f"{P}_reversal_2x2_by_draw.csv", rb)
        atomic_csv(f"{P}_reversal_2x2_summary.csv", rs_)
        have = {(r["variant"], r["cell"], r["data_draw"], r["optimizer_seed"]) for r in ri
                if r["updates_since_f0"] == fork_u}
        for k in design_jobs:
            if k[2] == "full" and (k[0], k[3], k[4], k[5]) not in have:
                rev_bad.append({"table": "reversal_2x2", "check": "the 2x2 at 2U", "key": list(map(str, k))})
    if a.reversal_grid:
        atomic_csv(f"{P}_reversal_grid.csv", out["reversal_grid"])
        gl = [{**{k: r[k] for k in ("cell", "variant", "arm", "removal_variant", "draw_set", "data_draw",
                                     "optimizer_seed", "partition_seed", "alpha", "beta", "rewind_is_noop",
                                     "training_access")}, "metric": m, "v": float(r[m])}
              for r in out["reversal_grid"] for m in GRID_METRICS if r.get(m) is not None]
        gb_, gs_ = two_stage(gl, ("cell", "variant", "arm", "removal_variant", "draw_set", "alpha", "beta",
                                  "rewind_is_noop", "training_access", "metric"), "v")
        atomic_csv(f"{P}_reversal_grid_by_draw.csv", gb_)
        atomic_csv(f"{P}_reversal_grid_summary.csv", gs_)
        prow, pcon = reversal_paths(out["reversal_grid"])
        atomic_csv(f"{P}_reversal_paths_by_setting.csv", prow)
        pl = [{**{k: r[k] for k in ("cell", "variant", "arm", "removal_variant", "draw_set", "data_draw",
                                     "optimizer_seed", "partition_seed", "rewind_is_noop", "training_access")},
               "path": r["path"], "quantity": q, "v": float(r[q])}
              for r in prow for q in PATH_QUANTITIES if r.get(q) is not None]
        _, ps_ = two_stage(pl, ("cell", "variant", "arm", "removal_variant", "draw_set", "rewind_is_noop",
                                "training_access", "path", "quantity"), "v")
        atomic_csv(f"{P}_reversal_paths.csv", ps_)
        cb_, cs_ = two_stage(pcon, ("cell", "variant", "arm", "removal_variant", "draw_set", "rewind_is_noop",
                                    "training_access", "contrast", "quantity", "sign"), "value")
        atomic_csv(f"{P}_reversal_path_contrasts_by_draw.csv", cb_)
        atomic_csv(f"{P}_reversal_path_contrasts.csv", cs_)
        cnt = defaultdict(int)
        for r in out["reversal_grid"]:
            cnt[(r["variant"], r["arm"], r["cell"], r["data_draw"], r["optimizer_seed"])] += 1
        for k in design_jobs:
            if k[2] == "full" and cnt.get((k[0], k[1], k[3], k[4], k[5]), 0) != len(GRID_LEVELS) ** 2:
                rev_bad.append({"table": "reversal_grid", "check": f"{len(GRID_LEVELS) ** 2} grid points",
                                "key": list(map(str, k)), "have": cnt.get((k[0], k[1], k[3], k[4], k[5]), 0)})
    if rev_bad or a.trace_implants or a.reversal_grid:
        coverage["output_membership_failures"] = coverage.get("output_membership_failures", []) + rev_bad
        coverage["reversal_status"] = ("exploratory reanalysis of existing checkpoints (no new training); the grid "
                                       "and paths are sampled straight-line interpolations at steps of 0.25")
    if a.manifest and (want_ex or a.save_extractions):
        coverage["output_membership_failures"] = coverage.get("output_membership_failures", []) + \
            output_membership_failures(out, design_jobs, fork_u, want_ex, bool(a.save_extractions))
        coverage["output_membership"] = {"extraction_2u_rows": len(out.get("extraction_2u", [])),
                                         "extractions_saved": len(out.get("extractions_saved", []))}
    # v43: the declared contrast registry
    if a.contrasts:
        rg_rows, rg_draw, rg_sum, rg_prob = registry_contrasts(a.contrasts, out, design_jobs, fork_u)
        coverage["registry"] = {"name": a.contrasts, "rows": len(rg_rows), "problems": rg_prob, "fork_u": fork_u,
                                "cohort": REGISTRY_COHORT.get(a.contrasts),
                                "primary": sorted(REGISTRY_PRIMARY.get(a.contrasts, set())),
                                "exploratory": "every table outside the registry (the full code map, the trace, the "
                                               "rescaling and residual probes, cross, displacement) and every "
                                               "registry contrast not marked primary"}
        atomic_csv(f"{P}_registry_by_setting.csv", rg_rows)
        atomic_csv(f"{P}_registry_by_draw.csv", rg_draw)
        atomic_csv(f"{P}_registry_summary.csv", rg_sum)
    # v41: the paired continuation factorial and its fork audit
    fb, fd, fs, fmiss, fdup = continuation_factorial(out, design)
    feq = fork_equality(out["fork_audit"])
    cfeq = compact_fork_equality(out["compact_fork_audit"], fork_u)
    coverage["compact_fork_equality_failures"] = cfeq
    atomic_csv(f"{P}_compact_fork_audit.csv", out["compact_fork_audit"])
    coverage.update({"factorial_partners_missing": fmiss, "factorial_duplicates": fdup,
                     "fork_equality_failures": feq,
                     "factorial_design": {str(k): sorted(map(list, v)) for k, v in design.items()}})
    atomic_csv(f"{P}_fork_audit.csv", out["fork_audit"])
    atomic_csv(f"{P}_continuation_factorial_by_setting.csv", fb)
    atomic_csv(f"{P}_continuation_factorial_by_draw.csv", fd)
    atomic_csv(f"{P}_continuation_factorial_summary.csv", fs)
    atomic_csv(f"{P}_trace.csv", out["trace"])
    atomic_csv(f"{P}_grid.csv", out["grid"])
    atomic_csv(f"{P}_checks.csv", out["checks"])
    atomic_csv(f"{P}_diagnostic_partial.csv", partial)
    coverage["by_variant"] = dict(coverage["by_variant"])
    coverage["inventory"] = dict(coverage["inventory"])
    coverage["n_failed"] = len(coverage["failed"])
    coverage["n_excluded"] = len(coverage["excluded"])
    coverage["passed"] = (coverage["n_failed"] == 0 and coverage["analysed"] > 0 and
                          coverage["analysed"] + coverage["n_excluded"] == coverage["expected"] and
                          (not a.manifest or (coverage["contrast_partners_missing"] == 0 and
                                              coverage.get("decomposition_contrast_partners_missing", 0) == 0 and
                                              coverage.get("pair_failures", 0) == 0 and
                                              not (coverage.get("registry") or {}).get("problems") and
                                              not cfeq and
                                              not fmiss and not fdup)) and
                          not feq and not coverage.get("paired_stream_failures")
                          and not coverage.get("residual_contrast_partners_missing")
                          and not coverage.get("output_membership_failures"))
    atomic_json(f"{P}_coverage.json", coverage)
    print(json.dumps({**{k: coverage[k] for k in ("expected", "analysed", "n_failed", "n_excluded",
                                                  "contrast_partners_missing", "passed")},
                      "factorial_missing": len(fmiss), "fork_equality_failures": len(feq),
                      "paired_stream_failures": len(coverage.get("paired_stream_failures") or []),
                      "inventory": coverage["inventory"]}),
          "first failures:", coverage["failed"][:3])
    if a.strict:
        return 0 if coverage["passed"] else 1
    return 0 if coverage["analysed"] > 0 else 1


if __name__ == "__main__":
    sys.exit(main())
