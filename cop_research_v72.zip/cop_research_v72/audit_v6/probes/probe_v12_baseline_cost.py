"""Compare an actual trained baseline checkpoint with run_work's result.
Usage: PYTHONPATH=/path/to/cop_research_v12 python probe_v12_baseline_cost.py OUTPUT_ROOT
Uses a fresh tiny synthetic baseline; never reads or modifies the user's runs.
"""
import json
import sys
from pathlib import Path
import torch
from cop.config import resolve, run_id
from cop.orchestration.runner import run_job
from cop.experiments.continuation import run_work

torch.set_num_threads(2)
root = Path(sys.argv[1])
cfg = resolve({'kind':'baseline',
               'data':{'name':'teacher','n_train':64,'n_val':32,'n_test':32,
                       'params':{'teacher_depth':1,'d_in':4,'out_dim':2,'task':'regression'}},
               'model':{'family':'mlp','width':8,'depth':2},
               'train':{'baseline_updates':5,'batch_size':16,'eval_every':5},
               'seeds':{'optimizer':0}})
status = run_job(cfg, root, {'device':'cpu'})
d = root/'runs'/run_id(cfg)
ck = torch.load(d/'ckpt'/'baseline.pt', map_location='cpu', weights_only=False)
state = ck['trainer']['state']
work = run_work(d)
result = {'status':status, 'run_id':run_id(cfg),
          'checkpoint_global_step':state['global_step'],
          'checkpoint_train_macs':state['train_macs'],
          'reported_run_work':work,
          'issue_reproduced':state['train_macs']>0 and work['macs']==0 and work['macs_complete']}
print(json.dumps(result,indent=2))
