"""Real GraphNet counterexample to subtracting roundoff magnitudes.
Run from the source checkout with PYTHONPATH set to that checkout.
No monkeypatching and no model training.
"""
import json
import torch
from cop.graph.graph import GraphNet
from cop.experiments.common import identity_check


def build(sign):
    g = GraphNet('vec', 'identity_probe')
    x = g.set_input('x', 1)
    def linear(inp, w, b):
        n = g.add_node('linear', [inp], {'in': 1, 'out': 1, 'dim': 1}, build=True)
        with torch.no_grad():
            g.mods[g.nodes[n].pkey].weight.fill_(w)
            g.mods[g.nodes[n].pkey].bias.fill_(b)
        return n
    a = linear(x, 1, 1e8)
    b = linear(a, 1, -1e8)
    err = g.add_node('add', [b, x], {'dim': 1, 'coefs': [1.0, -1.0]})
    y = linear(err, sign, 1)
    g.set_output(y)
    return g


pre, post = build(1.0), build(-1.0)
X = {'x': torch.tensor([[1.0], [2.0], [3.0]])}
cfg = {'criteria': {'identity_rel_tol_fp64': 1e-10, 'identity_rel_tol_fp32': 1e-5}}
r = identity_check(pre, post, {'audit': X}, torch.float32, cfg)
pe, qe = pre(X).detach().double(), post(X).detach().double()
Xd = {'x': X['x'].double()}
p64 = pre.clone(share_params=False).double()(Xd).detach()
q64 = post.clone(share_params=False).double()(Xd).detach()
r['outputs_fp32'] = {'pre': pe.flatten().tolist(), 'post': qe.flatten().tolist()}
r['outputs_fp64'] = {'pre': p64.flatten().tolist(), 'post': q64.flatten().tolist()}
r['roundoff_displacement_rel'] = float(((qe-q64)-(pe-p64)).abs().max()/p64.abs().mean())
r['issue_reproduced'] = r['verdict'] == 'exact' and r['roundoff_displacement_rel'] > r['stability_max_rel']
print(json.dumps(r, indent=2))
