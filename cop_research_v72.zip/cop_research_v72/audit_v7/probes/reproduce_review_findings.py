"""Read-only probes for v14 reporting and shell failure propagation.

Usage: python reproduce_review_findings.py /path/to/cop_research_v14
The launcher probe uses mocked executables in a temporary directory; no jobs run.
"""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

root = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(root))
from cop.analysis import v13_tables as tables


def row(seed, arm):
    return dict(family="M_Er", contrast="same_cell", arm=arm,
                replication=f"data{seed}_teacher{seed}_opt0", f0_run=f"f0_{seed}",
                run_id=f"{arm}_{seed}", test_risk=.1, test_err=0.,
                later_I1_test_acc_mean=.7)


a, b, c, d = row(101, "treated"), row(101, "M1"), row(102, "treated"), row(102, "M1")
normal = tables.later_query_retention([a, b, c, d])
shuffled = tables.later_query_retention([a, d, c, b])
out = {"retention": {"expected_pairs": 2, "normal_order": normal, "shuffled_order": shuffled}}

with tempfile.TemporaryDirectory(prefix="cop_review_") as td:
    p = Path(td)
    run = p / "run"
    run.mkdir()
    (run / "dissipation_result.json").write_text(json.dumps({"path": [
        {"update": 0, "tag": "start", "val_risk": .2},
        {"update": 0, "tag": "after_abrupt_delete_0", "val_risk": .8}]}))
    metrics = [dict(stage=st, atoms=None, evaluation_partition="test",
                    metric_name="loss", metric_value=val)
               for st, val in [("path_start", .3), ("path_after_abrupt_delete_0", .9)]]
    old_rows = tables._rows
    tables._rows = lambda r: metrics
    try:
        out["removal_table"] = tables.removal_path_table({"r": dict(
            cfg={"kind": "dissipation", "design": {},
                 "dissipation": {"method": "abrupt", "speed_updates": 0, "post_updates": 100}},
            dir=run, status={"status": "complete"})})
    finally:
        tables._rows = old_rows
    scripts = p / "scripts"
    scripts.mkdir()
    shutil.copy2(root / "scripts/16_v13_confirmation.sh", scripts / "16_v13_confirmation.sh")
    (scripts / "common.sh").write_text('''set -euo pipefail
export COP_HOME="$MOCK_ROOT"
export COP_DATA_ROOT="$MOCK_ROOT"
export WORKERS=1 THREADS=1 DEVICE=cpu
cop() {
  echo "cop $*" >> "$MOCK_ROOT/events.txt"
  if [ "$1" = run ]; then return 7; fi
  return 0
}
''')
    bindir = p / "bin"
    bindir.mkdir()
    fakepython = bindir / "python"
    fakepython.write_text('''#!/bin/bash
echo "python $*" >> "$MOCK_ROOT/events.txt"
if [ "$1" = - ]; then
  cat >/dev/null
  case "$2" in
    *.jsonl) echo '{"semantic_code_hash":"mock","manifest_sha256":"mock","jobs":1}' ;;
    *) echo "mock successful Python stage" ;;
  esac
  exit 0
fi
case "$1" in
  *check_results.py) exit 8 ;;
  *fresh_reload.py) exit 9 ;;
esac
exit 0
''')
    fakepython.chmod(0o755)
    (p / "results/confirmation_full").mkdir(parents=True)
    (p / "results/confirmation_full/PROTOCOL_FROZEN.json").write_text("{}")
    env = dict(os.environ, MOCK_ROOT=str(p), COP_RESULTS=str(p / "results"),
               ZIP_DIR=str(p), SCALE="full", CONFIRM="1", PATH=str(bindir) + ":" + os.environ["PATH"])
    completed = subprocess.run(["bash", str(scripts / "16_v13_confirmation.sh"), "run"],
                               env=env, capture_output=True, text=True)
    out["launcher_mock"] = {"run_exit_injected": 7, "audit_exit_injected": 8,
                            "reload_exit_injected": 9, "actual_launcher_exit": completed.returncode,
                            "events": (p / "events.txt").read_text().splitlines(),
                            "stdout": completed.stdout, "stderr": completed.stderr}

out["reproduced"] = {
    "retention_seed_overwrite": len(normal) != 2,
    "retention_cross_seed_pair": any(r["treated_run"].rsplit("_", 1)[1] !=
                                     r["control_run"].rsplit("_", 1)[1] for r in shuffled),
    "removal_metrics_omitted": all(r["full_test_risk"] is None for r in out["removal_table"]),
    "launcher_masks_failure": out["launcher_mock"]["actual_launcher_exit"] == 0,
}
print(json.dumps(out, indent=2))
