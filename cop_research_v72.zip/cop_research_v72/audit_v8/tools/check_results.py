"""v8 acceptance check over a results directory (read-only).  Exit 1 on any failure; the report is written
first.  Checks (each can be required):
  --manifest M          every manifest job has a status, and it is complete and valid (v36: or invalid with a
                        declared outcome of its design, audit_v5/tools/declared.py; listed)
  --diagnostics         every contraction-diagnostic row is complete (fit, virtual replacement, deletion,
                        JVP each ok or not applicable); at least one row must exist
  --transplants         every grid transplant assembly is eligible (fit ok, not diverged, finite parameters,
                        predictions and metrics); at least one grid assembly must exist
  --diagnostics-if-any, --transplants-if-any
                        the same checks, but a results folder with no diagnostic rows / no grid assemblies
                        passes that check (used for recovery of existing folders, where a check can be empty);
                        the report records that the check set was empty
  recoding (v20)        always, for every recode job of the manifest (or, without a manifest, of the folder):
                        controls present and passed, a nonempty plan, at least one checked pearl, every planned
                        fit recorded with a saved artifact; --recode additionally requires at least one recode job
Usage: python audit_v8/tools/check_results.py RESULTS OUT.json [--manifest M] [--diagnostics[-if-any]]
       [--transplants[-if-any]]"""
import argparse
import json
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "audit_v5/tools"))
from cop.analysis.gates import diagnostics_verdict, write_and_exit  # noqa: E402
from declared import declared_invalid  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("results")
ap.add_argument("out")
ap.add_argument("--manifest")
ap.add_argument("--diagnostics", action="store_true")
ap.add_argument("--transplants", action="store_true")
ap.add_argument("--diagnostics-if-any", action="store_true")
ap.add_argument("--transplants-if-any", action="store_true")
ap.add_argument("--recode", action="store_true")
a = ap.parse_args()
strict_d, strict_t = a.diagnostics, a.transplants
a.diagnostics = a.diagnostics or a.diagnostics_if_any
a.transplants = a.transplants or a.transplants_if_any
R = Path(a.results)
report, failures = {}, []
if not (a.manifest or a.diagnostics or a.transplants or a.recode):
    failures.append({"check": None, "reason": "empty check set: no check was requested"})
if a.manifest:
    st = {}
    for line in open(a.manifest):
        e = json.loads(line)
        p = R / "runs" / e["run_id"] / "status.json"
        s = json.load(open(p)) if p.exists() else {"status": "missing"}
        st[e["run_id"]] = s
        why_d = declared_invalid(R / "runs" / e["run_id"], e["cfg"])
        if why_d:
            # v36: a declared outcome of the job's design (an unreachable matched perturbation): listed, not a failure
            report.setdefault("manifest_declared_outcomes", []).append({"run": e["run_id"], "reason": why_d})
            continue
        if s.get("status") != "complete" or s.get("validity", "valid") != "valid":
            failures.append({"check": "manifest", "run": e["run_id"], "kind": e["cfg"]["kind"],
                             "block": e["cfg"].get("block"), "status": s.get("status"), "validity": s.get("validity"),
                             "reason": s.get("reason") or s.get("validity_reasons")})
    report["manifest"] = {"jobs": len(st), "complete_valid": sum(s.get("status") == "complete" and
                                                                 s.get("validity", "valid") == "valid" for s in st.values())}
    if not st:
        failures.append({"check": "manifest", "reason": "empty manifest"})
if a.diagnostics:
    v = diagnostics_verdict(R)
    report["diagnostics"] = {k: v[k] for k in ("n_files", "n_rows", "resolved_by_recompute",
                                               "excluded_source_recorded_invalid") if k in v}
    empty = not v.get("n_rows")
    report["diagnostics"]["empty_check_set"] = empty
    if empty and not strict_d and not any(f.get("run") for f in v["failures"]):
        pass                                                  # --diagnostics-if-any: nothing to check here
    elif not v["passed"]:
        failures += [{"check": "diagnostics", **f} for f in v["failures"]]
if a.transplants:
    from cop.analysis.v5_tables import grid_assembly_eligibility
    n, bad = 0, 0
    for rd in sorted((R / "runs").glob("*")):
        p = rd / "transplant_result.json"
        if not p.exists():
            continue
        j = json.load(open(p))
        if (j.get("info") or {}).get("design") != "grid":
            continue
        for k, e in grid_assembly_eligibility(j).items():
            n += 1
            if not e.get("eligible"):
                bad += 1
                failures.append({"check": "transplants", "run": rd.name, "assembly": k, "reason": e.get("reasons")})
    report["transplants"] = {"assemblies": n, "ineligible": bad, "empty_check_set": n == 0}
    if n == 0 and strict_t:
        failures.append({"check": "transplants", "reason": "empty check set: no grid transplant assembly found"})
# v20: recoding results are checked whenever there are recode jobs (never skipped because other sets are empty)
from cop.cop_pegs.recode import verify_recode_result  # noqa: E402
rc_runs = []
if a.manifest:
    for line in open(a.manifest):
        e = json.loads(line)
        if e["cfg"].get("kind") == "cop" and (e["cfg"].get("cop") or {}).get("task_kind") == "recode":
            rc_runs.append(e["run_id"])
else:
    for rd in sorted((R / "runs").glob("*")):
        cp = rd / "config.json"
        if cp.exists():
            c = json.load(open(cp))
            if c.get("kind") == "cop" and (c.get("cop") or {}).get("task_kind") == "recode":
                rc_runs.append(rd.name)
n_rc, n_ok = 0, 0
for rid in rc_runs:
    rd = R / "runs" / rid
    stp = rd / "status.json"
    if not stp.exists() or json.load(open(stp)).get("status") != "complete":
        continue                                       # the manifest check reports incomplete / invalid jobs
    n_rc += 1
    v = verify_recode_result(rd)
    if v["passed"]:
        n_ok += 1
    else:
        failures.append({"check": "recode", "run": rid, "reason": v["failures"]})
report["recode"] = {"jobs": len(rc_runs), "complete_checked": n_rc, "passed": n_ok, "empty_check_set": not rc_runs}
if a.recode and not rc_runs:
    failures.append({"check": "recode", "reason": "empty check set: no recode job found"})
write_and_exit(Path(a.out), report, {"passed": not failures, "failures": failures})
