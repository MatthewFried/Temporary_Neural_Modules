"""Read-only probe: are finite-peg inputs that sit exactly at the clipping range's edge pushed outside it by
rounding, which zeroes their straight-through gradient?

For every finished run whose design family is FQr, F07r, C4i or M_Er and that has a uniform peg, loads the
final (and best_val, if saved) checkpoint, computes each uniform peg's input on the first 2048 training examples
in eval mode, once as one batch (as calibration does) and once in training-size batches (as training does), and
reports per peg:
  clip_strict      fraction outside [lo, hi] (zero straight-through gradient in Quantizer.forward)
  clip_rounding    fraction outside by less than 1e-4 x (hi - lo): edge values pushed out by rounding
  clip_real        fraction outside by more than that: genuine clipping
  distinct_inputs  number of distinct input values over all coordinates (small = discrete input)
Nothing is written into the results folder.

  python audit_v8/tools/quant_boundary_probe.py ~/cop_results_v16/control_panel ~/quant_boundary_probe.json
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import torch  # noqa: E402
from cop.data.registry import load_bundle  # noqa: E402
from cop.graph.graph import GraphNet  # noqa: E402
from cop.utils import configure_torch  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("results")
ap.add_argument("out")
ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
ap.add_argument("--data-root", default=None)
ap.add_argument("--families", default="FQr,F07r,C4i,M_Er")
a = ap.parse_args()
fams = set(a.families.split(","))


def exec_of(rd: Path) -> dict:
    best = None
    for f in sorted((rd / "attempts").glob("*.json")):
        try:
            att = json.load(open(f))
        except ValueError:
            continue
        if att.get("status") == "complete":
            best = att
    return dict((best or {}).get("exec") or {})


@torch.no_grad()
def peg_inputs(g, X, nodes, bs):
    n = len(next(iter(X.values())))
    outs = {nd: [] for nd in nodes}
    for i in range(0, n, bs):
        _, v = g({k: t[i:i + bs] for k, t in X.items()}, return_nodes=nodes)
        for nd in nodes:
            outs[nd].append(v[nd])
    return {nd: torch.cat(vs) for nd, vs in outs.items()}


bundles, rows = {}, []
for rd in sorted(p for p in (Path(a.results) / "runs").glob("*") if p.is_dir()):
    try:
        cfg = json.load(open(rd / "config.json"))
        st = json.load(open(rd / "status.json")).get("status")
    except (OSError, ValueError):
        continue
    d = cfg.get("design") or {}
    if st != "complete" or ("all" not in fams and d.get("family") not in fams):
        continue
    configure_torch({**exec_of(rd), "device": a.device})
    key = json.dumps(cfg["data"], sort_keys=True)
    if key not in bundles:
        bundles[key] = load_bundle(cfg["data"], a.data_root, device="cpu").to(a.device)
    b = bundles[key]
    bs_train = int((cfg.get("train") or {}).get("batch_size", 128))
    for stage in ("final", "best_val"):
        p = rd / "ckpt" / f"{stage}.pt"
        if not p.exists():
            continue
        ck = torch.load(p, map_location="cpu", weights_only=False)
        g = GraphNet.from_checkpoint(ck["model"], a.device)
        g.eval()
        qn = [n for n in g.topo_order() if g.nodes[n].op == "quant"
              and g.mods[g.nodes[n].pkey].mode == "uniform"]
        if not qn:
            continue
        dt = next(p_.dtype for p_ in g.parameters() if p_.is_floating_point())
        X = {k: (v[:2048].to(dt) if v.is_floating_point() else v[:2048]) for k, v in b.train.X.items()}
        inp = {n: g.nodes[n].inputs[0] for n in qn}
        for label, bs in (("one_batch", 2048), ("train_batches", bs_train)):
            vals = peg_inputs(g, X, list(set(inp.values())), bs)
            for n in qn:
                q = g.mods[g.nodes[n].pkey]
                z = vals[inp[n]]
                z = (z.movedim(1, -1) if z.dim() == 4 else z).reshape(-1, q.k)
                lo, hi = q.lo.to(z.dtype), q.hi.to(z.dtype)
                out_by = torch.maximum(lo - z, z - hi)          # > 0 means outside
                tol = 1e-4 * (hi - lo)
                rows.append({"run": rd.name, "family": d.get("family") or "", "contrast": d.get("contrast"),
                             "arm": d.get("arm"), "stage": stage, "batching": label, "peg_node": n,
                             "bits": int(q.bits), "dtype": str(dt),
                             "clip_strict": float((out_by > 0).float().mean()),
                             "clip_rounding": float(((out_by > 0) & (out_by <= tol)).float().mean()),
                             "clip_real": float((out_by > tol).float().mean()),
                             "distinct_inputs": int(torch.unique(z).numel())})

summ = {}
for r in rows:
    k = (r["family"], r["batching"], r["bits"])
    s = summ.setdefault(k, {"n": 0, "rounding_max": 0.0, "real_max": 0.0, "pegs_with_rounding_over_10pct": 0})
    s["n"] += 1
    s["rounding_max"] = max(s["rounding_max"], r["clip_rounding"])
    s["real_max"] = max(s["real_max"], r["clip_real"])
    s["pegs_with_rounding_over_10pct"] += r["clip_rounding"] > 0.1
json.dump({"rows": rows, "summary": [{"family": k[0], "batching": k[1], "bits": k[2], **v}
                                     for k, v in sorted(summ.items())]}, open(a.out, "w"), indent=1)
for k, v in sorted(summ.items()):
    print(k, v)
print("wrote", a.out, len(rows), "rows")
