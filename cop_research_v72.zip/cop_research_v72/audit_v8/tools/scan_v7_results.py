"""Supplied unchanged by the independent v7 audit (CoP_v7_Independent_Audit_and_Checks), kept here so it
runs from the v8 checkout.

Read-only CoP v7 result audit; no project or torch imports required.

Usage: python scan_v7_results.py ~/cop_results_v5 --out v7_scan.json
If the actual runs are under a pilot subfolder, pass that folder instead.
Add --check-insertions to read metric logs for unusually loose identity gates.
The --out file is the only file this script writes. It never modifies runs.
"""
import argparse
from collections import Counter
import json
import math
from pathlib import Path


def finite(x):
    try:
        return math.isfinite(float(x))
    except (ValueError, TypeError):
        return False


def scan(root, check_insertions=False):
    root = Path(root).expanduser()
    dirs = root if root.name == 'runs' else root / 'runs'
    if not dirs.is_dir():
        raise ValueError(f'No runs directory: {dirs}. Pass the directory that contains the actual runs.')
    statuses, errors = Counter(), []
    out = {'results': str(root), 'read_errors': errors, 'diagnostic_errors': [],
           'diverged_transplant_fits': [], 'nonfinite_transplant_contrasts': [],
           'nonfinite_deletion_values': [], 'loose_insertion_gates': [],
           'identity_review_threshold': 1e-3,
           'identity_note': 'Threshold is a review flag, not proof that the insertion was invalid.'}
    def read(p):
        try:
            return json.loads(p.read_text())
        except (OSError, ValueError) as exc:
            errors.append({'path': str(p), 'error': str(exc)})
            return None
    for rd in sorted(dirs.iterdir()):
        if not rd.is_dir():
            continue
        st = read(rd / 'status.json') if (rd / 'status.json').exists() else {}
        st = st or {}
        statuses[st.get('status', 'missing')] += 1
        diag = rd / 'contraction_diagnostics.json'
        if diag.exists():
            for tag, rec in (read(diag) or {}).items():
                for iid, row in rec.get('implants', {}).items():
                    if row.get('error'):
                        out['diagnostic_errors'].append({'run': rd.name, 'tag': tag, 'implant': iid,
                                                        'error': row['error'], 'status': st.get('status')})
        tp = rd / 'transplant_result.json'
        if tp.exists():
            r = read(tp) or {}
            for name, fit in r.get('info', {}).get('fits', {}).items():
                if fit.get('diverged'):
                    out['diverged_transplant_fits'].append({'run': rd.name, 'fit': name,
                        'status': st.get('status'), 'validity': st.get('validity')})
            for fam, parts in r.get('contrasts', {}).items():
                for part, vals in parts.items():
                    for k, v in vals.items():
                        if v is not None and not finite(v):
                            out['nonfinite_transplant_contrasts'].append({'run': rd.name,
                                'family': fam, 'partition': part, 'metric': k, 'value': v})
        for p in rd.glob('deletions_*.json'):
            r = read(p) or {}
            for i, row in enumerate(r.get('rows', [])):
                for part, vals in row.get('metrics', {}).items():
                    for k in ('delta_risk', 'nmse_increase', 'delta_acc'):
                        v = vals.get(k)
                        if v is not None and not finite(v):
                            out['nonfinite_deletion_values'].append({'run': rd.name, 'file': p.name,
                                'row': i, 'partition': part, 'metric': k, 'value': v})
        if check_insertions and (rd / 'metrics.jsonl').exists():
            with (rd / 'metrics.jsonl').open() as f:
                for i, line in enumerate(f):
                    try:
                        row = json.loads(line)
                    except ValueError:
                        errors.append({'path': str(rd / 'metrics.jsonl'), 'line': i+1,
                                       'error': 'incomplete or invalid JSON line (may be an active write)'})
                        continue
                    tol = row.get('tolerance_rel')
                    if row.get('metric_name') == 'insertion_label' and tol is not None:
                        if not finite(tol) or float(tol) > 1e-3:
                            out['loose_insertion_gates'].append({'run': rd.name, 'stage': row.get('stage'),
                                'label': row.get('metric_value'), 'tolerance_rel': tol,
                                'roundoff_floor_rel': row.get('roundoff_floor_rel')})
    out['statuses'] = dict(statuses)
    out['diagnostic_error_types'] = dict(Counter(r['error'] for r in out['diagnostic_errors']))
    out['counts'] = {k: len(out[k]) for k in ('diagnostic_errors', 'diverged_transplant_fits',
        'nonfinite_transplant_contrasts', 'nonfinite_deletion_values', 'loose_insertion_gates', 'read_errors')}
    return out


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('results')
    p.add_argument('--out')
    p.add_argument('--check-insertions', action='store_true')
    a = p.parse_args()
    r = scan(a.results, a.check_insertions)
    if a.out:
        Path(a.out).write_text(json.dumps(r, indent=2)+'\n')
        print(json.dumps({k: r[k] for k in ('results', 'statuses', 'counts', 'diagnostic_error_types')}, indent=2))
        print('Report:', a.out)
    else:
        print(json.dumps(r, indent=2))
    raise SystemExit(1 if any(r['counts'].values()) else 0)
