"""Cut, Expand, Remove, and Replace / Chain of Pearls research framework."""
__version__ = "1.0.0"
