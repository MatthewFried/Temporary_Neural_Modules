"""Static dependence game of a fixed-weight deletion landscape (v5, P4).

Players are the deletion atoms of one checkpoint (cop.experiments.deletion).  Sign convention
(damage): d(S) = R(delete S from the fixed checkpoint) - R(checkpoint), so d(empty) = 0 and
positive values are damage.  Exact quantities need the COMPLETE Boolean game: every subset of
the atoms evaluated (the exhaustive family, below deletion.max_exhaustive_atoms); a structured
or sampled family, or any invalid deletion, makes the game incomplete and no exact value is
reported (unobserved coalitions are never interpolated and never scored as zero).

Hierarchy: deleting an implant removes its descendants (canonical deletion), so a coalition
containing an ancestor has the value of the ancestor's subtree whatever the descendants'
membership; the resulting player semantics are not those of independent components.  This is
flagged (`hierarchical`) and the game is still analysed as defined; a hierarchy-aware
(feasible-set) game is a different object.

Reported for a complete game:
  shapley          phi_i = sum_S |S|!(n-|S|-1)!/n! [d(S+i) - d(S)]   (efficiency: sum = d(N))
  pair_at_empty    J(i,j) = d(ij) - d(i) - d(j) + d(empty)           (the deletion module's J)
  shapley_interaction  I(i,j) = sum_{S without i,j} |S|!(n-|S|-2)!/(n-1)! [d(S+ij) - d(S+i) - d(S+j) + d(S)]
  mobius           m(T) = sum_{S subset T} (-1)^(|T|-|S|) d(S); summarised by order (max |m|)
  best_k / greedy_k  min over |S| = k of d(S) against the greedy one-at-a-time path (fixed weights)
  minmax_path      the smallest achievable maximum intermediate damage over one-at-a-time removal
                   paths from the checkpoint to removing every atom (the endpoint is included)
  min_batch        per tolerance tau: the smallest batch size b such that some path removing at
                   most b atoms per step reaches 'every atom removed' with every visited state's
                   damage <= tau (None: the endpoint itself exceeds tau)
The inverse pair (d(a) = d(b) = 1, d(ab) = 0) has Shapley values 0 and 0 although each single
deletion damages; its pair interaction is -2 and it needs a batch of 2.  Strong interactions do
not by themselves make greedy fail (a symmetric game ties every equal-size deletion).

Static means fixed weights: with no updates between removals and commuting deletions, order
changes only intermediate damage, never the endpoint.  When repair runs between removals the
weights change and this landscape no longer determines the path; dynamic order effects come
from the paired repair-order experiments (mechanism D, F06c).
"""
from __future__ import annotations

import itertools
import math
from collections import deque
from typing import Optional


def game_from_values(values: dict, n: int) -> list[float]:
    """values: {frozenset of player indices: damage}; returns d indexed by bitmask, d[0] = 0."""
    d = [None] * (1 << n)
    d[0] = 0.0
    for S, v in values.items():
        m = 0
        for i in S:
            m |= 1 << i
        d[m] = float(v)
    return d


def shapley(d: list[float], n: int) -> list[float]:
    fact = [math.factorial(k) for k in range(n + 1)]
    phi = [0.0] * n
    for i in range(n):
        bi = 1 << i
        for S in range(1 << n):
            if S & bi:
                continue
            s = bin(S).count("1")
            phi[i] += fact[s] * fact[n - s - 1] / fact[n] * (d[S | bi] - d[S])
    return phi


def shapley_interaction(d: list[float], n: int) -> dict:
    fact = [math.factorial(k) for k in range(n + 1)]
    out = {}
    for i, j in itertools.combinations(range(n), 2):
        bi, bj = 1 << i, 1 << j
        tot = 0.0
        for S in range(1 << n):
            if S & (bi | bj):
                continue
            s = bin(S).count("1")
            w = fact[s] * fact[n - s - 2] / fact[n - 1]
            tot += w * (d[S | bi | bj] - d[S | bi] - d[S | bj] + d[S])
        out[(i, j)] = tot
    return out


def mobius(d: list[float], n: int) -> list[float]:
    m = list(d)
    for i in range(n):
        for S in range(1 << n):
            if S & (1 << i):
                m[S] -= m[S ^ (1 << i)]
    return m


def greedy_vs_best(d: list[float], n: int) -> list[dict]:
    rows, cur = [], 0
    for k in range(1, n + 1):
        best = min(d[S] for S in range(1 << n) if bin(S).count("1") == k)
        cand = [(d[cur | (1 << i)], i) for i in range(n) if not cur & (1 << i)]
        v, i = min(cand)
        cur |= 1 << i
        rows.append({"k": k, "best_k": best, "greedy_k": v, "greedy_gap": v - best})
    return rows


def minmax_path(d: list[float], n: int) -> dict:
    """Bottleneck DP over the subset lattice, one atom added per step."""
    full = (1 << n) - 1
    B = [math.inf] * (1 << n)
    arg = [-1] * (1 << n)
    B[0] = max(0.0, d[0])
    for S in range(1, 1 << n):
        for i in range(n):
            if S & (1 << i):
                v = max(d[S], B[S ^ (1 << i)])
                if v < B[S]:
                    B[S], arg[S] = v, i
    path, S = [], full
    while S:
        path.append(arg[S])
        S ^= 1 << arg[S]
    return {"minmax_damage": B[full], "order": list(reversed(path))}


def min_batch(d: list[float], n: int, tau: float) -> Optional[int]:
    full = (1 << n) - 1
    if d[full] > tau:
        return None
    for b in range(1, n + 1):
        seen = {0}
        q = deque([0])
        while q:
            S = q.popleft()
            if S == full:
                return b
            rest = [i for i in range(n) if not S & (1 << i)]
            for k in range(1, min(b, len(rest)) + 1):
                for T in itertools.combinations(rest, k):
                    S2 = S
                    for i in T:
                        S2 |= 1 << i
                    if S2 not in seen and d[S2] <= tau:
                        seen.add(S2)
                        q.append(S2)
    return None


def analyse_game(d: list[float], n: int, taus=(0.0,), labels: Optional[list[str]] = None) -> dict:
    if any(v is None for v in d):
        missing = sum(v is None for v in d)
        return {"exact": False, "reason": f"{missing} coalitions not evaluated: the game is incomplete"}
    def _f(v):
        try:
            return float(v)
        except (TypeError, ValueError):
            return float("nan")
    d = [_f(v) for v in d]
    bad = [S for S, v in enumerate(d) if not math.isfinite(v)]
    if bad:
        return {"exact": False, "reason": f"{len(bad)} non-finite or non-numeric coalition utilities (incl. the "
                                          f"reference d(empty) = {d[0]}): the landscape is invalid",
                "nonfinite_masks": bad[:20]}
    if max(abs(v) for v in d) > 1e150:
        return {"exact": False, "reason": "coalition utilities too large for exact summation (|d| > 1e150): the "
                                          "landscape is reported, not analysed"}
    labels = labels or [str(i) for i in range(n)]
    phi = shapley(d, n)
    full = (1 << n) - 1
    scale = max(1.0, max(abs(v) for v in d))
    if not math.isfinite(sum(phi)) or abs(sum(phi) - (d[full] - d[0])) > 1e-9 * scale * (1 << n):
        return {"exact": False, "reason": "Shapley efficiency check failed numerically: the landscape is reported, "
                                          "not analysed"}
    I = shapley_interaction(d, n) if n >= 2 else {}
    mob = mobius(d, n)
    by_order: dict[int, float] = {}
    for T in range(1, 1 << n):
        o = bin(T).count("1")
        by_order[o] = max(by_order.get(o, 0.0), abs(mob[T]))
    J = {f"{labels[i]},{labels[j]}": d[(1 << i) | (1 << j)] - d[1 << i] - d[1 << j] + d[0]
         for i, j in itertools.combinations(range(n), 2)}
    mp = minmax_path(d, n)
    return {"exact": True, "n_players": n, "players": labels, "sign": "damage: d(S) = R(delete S) - R(checkpoint)",
            "endpoint_damage": d[full],
            "shapley": dict(zip(labels, phi)),
            "single_deletion_damage": {labels[i]: d[1 << i] for i in range(n)},
            "pair_at_empty": J,
            "shapley_interaction": {f"{labels[i]},{labels[j]}": v for (i, j), v in I.items()},
            "mobius_max_abs_by_order": by_order,
            "greedy_vs_best": greedy_vs_best(d, n),
            "minmax_path": {"minmax_damage": mp["minmax_damage"], "order": [labels[i] for i in mp["order"]]},
            "min_batch": {str(t): min_batch(d, n, float(t)) for t in taus}}


def _finite_value(v) -> bool:
    try:
        return math.isfinite(float(v))
    except (TypeError, ValueError):
        return False


def game_from_deletions(dele: dict, partition: str, value: str = "delta_risk", taus=(0.0,)) -> dict:
    """Build the damage game of one deletions_<stage>.json (evaluate_family output).  value:
    delta_risk (headline risk) | nmse_increase (regression criterion units) | acc_drop_pp."""
    info = dele.get("info") or {}
    atoms = list(info.get("atoms") or [])
    n = len(atoms)
    base = {"source_stage": dele.get("stage"), "partition": partition, "value": value, "atoms": atoms}
    if not info.get("exhaustive"):
        return {**base, "exact": False, "reason": "landscape not exhaustive (structured / sampled subsets only)"}
    rows = dele.get("rows") or []
    ref = (dele.get("base") or {}).get(partition) or {}
    bad_ref = sorted(k for k, v in ref.items() if isinstance(v, (int, float, str)) and k in ("loss", "mse", "acc")
                     and not _finite_value(v))
    if bad_ref:
        return {**base, "exact": False, "reason": f"non-finite reference (undeleted) utility {bad_ref}: the landscape "
                                                  f"is invalid"}
    pos = {a: i for i, a in enumerate(atoms)}
    vals, invalid, hier, nonfinite = {}, [], False, []
    for r in rows:
        S = frozenset(pos[a] for a in r["atoms"])
        if "invalid" in r:
            invalid.append(r["atoms"])
            continue
        src = rows[r["same_graph_as"]] if "same_graph_as" in r else r
        if "metrics" not in src or partition not in src["metrics"]:
            invalid.append(r["atoms"])
            continue
        e = src["metrics"][partition]
        key = {"delta_risk": "delta_risk", "nmse_increase": "nmse_increase", "acc_drop_pp": "delta_acc"}.get(value)
        if key is None:
            raise ValueError(value)
        v = e.get(key)
        try:
            v = None if v is None else float(v)        # serialised 'nan' / 'inf' strings become floats here
        except (TypeError, ValueError):
            v = None
        if v is not None and value == "acc_drop_pp":
            v = -100.0 * v
        if v is None:
            invalid.append(r["atoms"])
            continue
        if not math.isfinite(v):
            nonfinite.append({"atoms": r["atoms"], "value": str(v)})
            continue
        if sorted(r.get("canonical", r["atoms"])) != sorted(r["atoms"]):
            hier = True
        vals[S] = v
    if nonfinite:
        return {**base, "exact": False, "reason": f"{len(nonfinite)} non-finite coalition utilities: the landscape is "
                                                  f"invalid (never replaced by zero)", "nonfinite": nonfinite[:20]}
    if invalid:
        return {**base, "exact": False, "reason": f"{len(invalid)} invalid or unevaluated deletions: the game is "
                                                  f"incomplete", "invalid": invalid[:20]}
    d = game_from_values(vals, n)
    out = analyse_game(d, n, taus=taus, labels=atoms)
    # v22: the game over DISJOINT players only.  An atom whose pair deletion with another atom canonicalises to
    # itself is that atom's ancestor (deleting a parent deletes its children), so a parent and its child are not
    # separate players and their 'interaction' is an artefact of the hierarchy.  The disjoint game keeps the
    # atoms that are no other atom's ancestor (e.g. the four specialised branches, not their group container);
    # every subset of them is a subset of the atoms, so the exhaustive landscape already holds it.
    anc = set()
    for r in rows:
        ra = list(r["atoms"])
        if len(ra) == 2 and "canonical" in r and len(r["canonical"]) == 1:
            anc.add(r["canonical"][0])
    disjoint = None
    leaves = [a for a in atoms if a not in anc]
    if hier and 2 <= len(leaves) < n:
        li = [pos[a] for a in leaves]
        dv = {}
        for m in range(1 << len(leaves)):
            S = frozenset(li[k] for k in range(len(leaves)) if (m >> k) & 1)
            dv[frozenset(k for k in range(len(leaves)) if (m >> k) & 1)] = 0.0 if not S else vals.get(S)
        if all(v is not None for v in dv.values()):
            disjoint = analyse_game(game_from_values(dv, len(leaves)), len(leaves), taus=taus, labels=leaves)
            disjoint["ancestors_excluded"] = sorted(anc)
    return {**base, **out, "hierarchical": hier, "disjoint_game": disjoint,
            "hierarchy_note": ("coalitions containing an ancestor take its subtree's value; players are not "
                               "independent components") if hier else None,
            "static_note": "fixed-weight landscape: says nothing about order effects when repair runs between removals"}
