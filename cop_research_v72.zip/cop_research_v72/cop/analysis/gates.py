"""Pass / fail verdicts for the acceptance helpers (v8, audit V7-04).

Every helper writes its full report first and then exits with the verdict, so a failed gate still leaves
actionable evidence.  Rules shared by the helpers:

* an empty check set is a failure (zero comparisons never count as success);
* any error, mismatch or missing required artifact is a failure;
* a case that cannot be interrupted (no training loop) passes only an explicit, documented output
  repeatability check, is listed in `allow_not_interruptible`, and is reported separately: it never
  counts as interruption / resume coverage;
* non-finite values never pass a comparison.
"""
from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Iterable, Optional


def finite_number(v) -> bool:
    try:
        return math.isfinite(float(v))
    except (TypeError, ValueError):
        return False


def resume_verdict(report: dict, allow_not_interruptible: Iterable[str] = ()) -> dict:
    allow = set(allow_not_interruptible)
    failures, covered, repeat_only = [], [], []
    if not report:
        failures.append({"case": None, "reason": "empty check set: no resume comparison ran"})
    for name, r in report.items():
        if not isinstance(r, dict):
            failures.append({"case": name, "reason": "malformed result"})
            continue
        if r.get("error"):
            failures.append({"case": name, "reason": f"error: {r['error']}"})
            continue
        if r.get("polls_uninterrupted") == 0 or r.get("not_interruptible"):
            if name not in allow:
                failures.append({"case": name, "reason": "no training loop was interrupted, and the case is not on "
                                                         "the documented not-interruptible list"})
            elif not r.get("outputs_equal"):
                failures.append({"case": name, "reason": "rerun outputs differ (repeatability check)"})
            else:
                repeat_only.append(name)
            continue
        if not r.get("interrupted_at_polls"):
            failures.append({"case": name, "reason": "the job was never interrupted (no coverage)"})
            continue
        if not r.get("equal"):
            why = {k: r.get(k) for k in ("checkpoints_differing", "n_metrics_differing", "results_differing",
                                          "work_equal") if r.get(k)}
            failures.append({"case": name, "reason": f"interrupted and uninterrupted runs differ: {why}"})
            continue
        covered.append(name)
    return {"passed": not failures, "n_cases": len(report), "interruption_covered": covered,
            "repeatability_only": repeat_only, "failures": failures}


def write_and_exit(path: Path, payload: dict, verdict: dict) -> None:
    """Write the report with its verdict, print a one-line summary and exit 0 / 1."""
    import sys
    payload = {**payload, "_verdict": verdict}
    Path(path).write_text(json.dumps(payload, indent=1, default=str))
    print(json.dumps({"passed": verdict["passed"], "n_failures": len(verdict.get("failures", [])),
                      "report": str(path)}), flush=True)
    for f in verdict.get("failures", [])[:30]:
        print("FAIL", json.dumps(f, default=str), flush=True)
    sys.exit(0 if verdict["passed"] else 1)


def source_recorded_invalid(results: Path, run: str, tag: str) -> Optional[str]:
    """If the model diagnosed under `tag` is a parent checkpoint that the parent job itself recorded as
    numerically invalid (its endpoint.json: that checkpoint, numerically_valid false), the reason; else None.
    Such a row measures a model already known to be broken (e.g. a diverged trajectory); it is excluded by
    that prior record and listed, never silently passed.  Only the parent's own record counts."""
    if tag not in ("dissipation_start", "repair_start"):
        return None
    rd = Path(results) / "runs" / run
    try:
        cfg = json.loads((rd / "config.json").read_text())
    except (OSError, ValueError):
        return None
    parent = (cfg.get("parents") or {}).get("trajectory")
    stage = (cfg.get("tags") or {}).get("parent_stage", "final")
    if not parent:
        return None
    try:
        ep = json.loads((Path(results) / "runs" / parent / "endpoint.json").read_text())
    except (OSError, ValueError):
        return None
    if ep.get("checkpoint") == stage and ep.get("numerically_valid") is False:
        return f"diagnosed model {parent}:{stage} is recorded numerically invalid ({ep.get('numerical_reasons')})"
    return None


def run_diagnostic_rows(results: Path, run: str, excluded: Optional[list] = None):
    """(n_rows, incomplete rows, rows resolved by a recomputed record) for one run's contraction diagnostics.
    A row counts as resolved only when RESULTS/recomputed_diagnostics/<run>.json has status 'ok' for its
    tag and the recomputed row is complete.  An incomplete row whose diagnosed model is recorded numerically
    invalid by its own job (source_recorded_invalid) is appended to `excluded` (with the reason) instead of
    the failures."""
    rd = Path(results) / "runs" / run
    p = rd / "contraction_diagnostics.json"
    if not p.exists():
        return 0, [], []
    try:
        store = json.loads(p.read_text())
    except ValueError as ex:
        return 0, [{"run": run, "reason": f"unreadable: {ex}"}], []
    rp = Path(results) / "recomputed_diagnostics" / f"{run}.json"
    try:
        recomputed = (json.loads(rp.read_text()).get("records") or {}) if rp.exists() else {}
    except ValueError:
        recomputed = {}
    n, bad, resolved = 0, [], []
    for tag, rec in store.items():
        new = recomputed.get(tag) or {}
        new_rows = ((new.get("record") or {}).get("implants") or {}) if new.get("status") == "ok" else {}
        for iid, row in (rec.get("implants") or {}).items():
            if "skipped" in row:
                continue
            n += 1
            if not (row.get("error") or row.get("complete") is False):
                continue
            why = source_recorded_invalid(results, run, tag)
            if (new_rows.get(iid) or {}).get("complete"):
                resolved.append({"run": run, "tag": tag, "implant": iid,
                                 "by": f"recomputed {new.get('diagnostic_version')} from {new['source'].get('stage')}"})
            elif why and excluded is not None:
                excluded.append({"run": run, "tag": tag, "implant": iid, "reason": row.get("error") or "incomplete",
                                 "excluded_because": why})
            else:
                bad.append({"run": run, "tag": tag, "implant": iid, "reason": row.get("error") or "incomplete",
                            "statuses": {k: row.get(k) for k in row if k.endswith("_status")}})
    return n, bad, resolved


def diagnostics_verdict(results: Path) -> dict:
    """Every contraction-diagnostic record under RESULTS/runs must be complete (fit, virtual replacement,
    deletion and JVP each ok or not applicable).  Reports every incomplete row; rows whose diagnosed model
    its own job recorded as numerically invalid are listed under excluded_source_recorded_invalid."""
    runs = Path(results) / "runs"
    failures, resolved, excluded, n_rows, n_files = [], [], [], 0, 0
    if not runs.is_dir():
        return {"passed": False, "n_rows": 0, "failures": [{"reason": f"no runs directory under {results}"}]}
    for rd in sorted(runs.iterdir()):
        if not (rd / "contraction_diagnostics.json").exists():
            continue
        n_files += 1
        n, bad, res = run_diagnostic_rows(results, rd.name, excluded)
        n_rows += n
        failures += bad
        resolved += res
    return {"passed": not failures and n_rows > 0, "n_files": n_files, "n_rows": n_rows, "resolved_by_recompute": resolved,
            "excluded_source_recorded_invalid": excluded,
            "failures": failures if (failures or n_rows) else [{"reason": "no diagnostic rows found"}]}
