"""Build the generic review archive (spec section 19; `cop package-for-review`, used by scripts/09).

v8 (audit V7-07): run evidence is selected by rule, not by a fixed list of file names.
  * every JSON / JSONL / text report at a run's top level is included (endpoint.json, contraction_diagnostics,
    locality / transplant / witness / bridge reports and any later ones), except transient files
    (partial states, progress records, locks);
  * the attempts/, graphs/, finite/, preds/ and diagnostics/ folders are included (diagnostics/*.pt are the
    saved affine maps);
  * checkpoints are chosen from the run's own metadata: the endpoint checkpoint (endpoint.json), every saved
    transplant model (transplant_result.json), the witness (witness.json), the classic stages
    (baseline, final, export, baseline_ref, reference_exported), and every parent stage a child job loads
    (tags.parent_stage, tags.f0_stage, transplant upstream_stage / downstream_stage);
  * RESULTS/recomputed_diagnostics/ (v8 recovery records and maps) is included;
  * saved predictions and diagnostic maps count against their own budget (max_evidence_mb, default 1000);
  * other binary files count against the size budget (max_ckpt_mb); a referenced checkpoint that does not fit,
    or does not exist, is listed with its reason in results/INVENTORY.json, which also lists every file
    written with its size.
This is separate from the recursive pilot packager inside scripts/11, which zips the whole pilot folder.
"""
from __future__ import annotations

import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SRC_DIRS = ["cop", "tests", "scripts", "configs", "docs", "manifests", "audit_v4", "audit_v5", "audit_v8"]
TOP_SUFFIXES = (".md", ".txt", ".toml", ".json", ".diff")
REPORT_SUFFIXES = (".json", ".jsonl", ".txt", ".csv")
RUN_SUBDIRS = ("attempts", "graphs", "finite", "preds", "diagnostics")
TRANSIENT = ("partial", "progress_", "state__", "diss_state", ".lock", ".tmp")
CLASSIC_CKPTS = ("baseline", "final", "export", "baseline_ref", "reference_exported")
BINARY_SUFFIXES = (".pt", ".pth", ".bin", ".npz", ".npy")
SMALL_PT_FILES = ("alternatives_modules.pt", "alternatives_predictions.pt", "split_modules.pt", "split_predictions.pt")


def _transient(name: str) -> bool:
    return any(t in name for t in TRANSIENT)


def _read(p: Path):
    try:
        return json.loads(p.read_text())
    except (OSError, ValueError):
        return None


def referenced_checkpoints(run: Path, children_stages: set[str]) -> dict[str, str]:
    """{checkpoint stage: why it is referenced} from the run's own metadata."""
    ref = {c: "classic stage" for c in CLASSIC_CKPTS}
    ep = _read(run / "endpoint.json") or {}
    if ep.get("checkpoint"):
        ref[ep["checkpoint"]] = "endpoint.json"
    tr = _read(run / "transplant_result.json") or {}
    for name, s in ((tr.get("info") or {}).get("saved_models") or {}).items():
        if s.get("checkpoint"):
            ref[s["checkpoint"]] = f"transplant model {name}"
    w = _read(run / "witness.json") or {}
    if w.get("realizable"):
        ref["witness"] = "witness.json"
    for st in children_stages:
        ref[st] = "parent stage of a child job"
    return ref


def parent_stage_references(runs) -> dict[str, set]:
    """{parent run id: {stage, ...}} for every parent checkpoint a child job loads: tags.parent_stage (roles
    trajectory / parent), tags.f0_stage (role baseline) and the transplant's upstream / downstream stages
    (roles named by transplant.upstream / transplant.downstream)."""
    ref: dict[str, set] = {}
    for d in runs:
        cfg = _read(d / "config.json") or {}
        parents = cfg.get("parents") or {}
        tags = cfg.get("tags") or {}
        st = tags.get("parent_stage")
        for role, pid in parents.items():
            if st and role in ("trajectory", "parent"):
                ref.setdefault(pid, set()).add(st)
        if tags.get("f0_stage") and parents.get("baseline"):
            ref.setdefault(parents["baseline"], set()).add(tags["f0_stage"])
        tp = cfg.get("transplant") or {}
        for rk, sk in (("upstream", "upstream_stage"), ("downstream", "downstream_stage")):
            role, stage = tp.get(rk), tp.get(sk)
            if role and stage and parents.get(role):
                ref.setdefault(parents[role], set()).add(stage)
    return ref


def package_for_review(results: str, out: str, manifests: str, max_ckpt_mb: float = 50.0,
                       max_evidence_mb: float = 1000.0) -> str:
    out = Path(out)
    results = Path(results)
    top = out.stem
    budget, ev_budget = max_ckpt_mb * 1e6, max_evidence_mb * 1e6
    used, ev_used = 0.0, 0.0
    inv = {"included": [], "omitted": [], "budget_mb": max_ckpt_mb, "evidence_budget_mb": max_evidence_mb}
    n_src = 0
    runs = sorted(p for p in (results / "runs").glob("*") if p.is_dir()) if (results / "runs").exists() else []
    child_stage = parent_stage_references(runs)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        def put(f: Path, arc: str, binary: bool = False, why: str = "", evidence: bool = False) -> None:
            nonlocal used, ev_used
            size = f.stat().st_size
            if binary and used + size > budget:
                inv["omitted"].append({"path": arc, "bytes": size, "reason": f"binary size budget {max_ckpt_mb} MB",
                                       "referenced_by": why})
                return
            if evidence and ev_used + size > ev_budget:
                inv["omitted"].append({"path": arc, "bytes": size, "referenced_by": why,
                                       "reason": f"evidence size budget {max_evidence_mb} MB (preds / diagnostic maps)"})
                return
            z.write(f, f"{top}/{arc}")
            if binary:
                used += size
            if evidence:
                ev_used += size
            inv["included"].append({"path": arc, "bytes": size, **({"referenced_by": why} if why else {})})

        for d in SRC_DIRS:
            p = ROOT / d
            if not p.exists():
                continue
            for f in sorted(p.rglob("*")):
                if f.is_file() and "__pycache__" not in f.parts and not f.name.endswith(".pyc"):
                    z.write(f, f"{top}/{f.relative_to(ROOT)}")
                    n_src += 1
        for f in sorted(ROOT.iterdir()):
            if f.is_file() and f.suffix in TOP_SUFFIXES:
                z.write(f, f"{top}/{f.name}")
        if results.exists():
            for f in sorted(results.iterdir()):
                if f.is_file() and f.suffix in REPORT_SUFFIXES and not _transient(f.name):
                    put(f, f"results/{f.name}")
            # recomputed diagnostic records (v8 recovery) and their saved maps are evidence: always included
            rc = results / "recomputed_diagnostics"
            if rc.exists():
                for f in sorted(rc.rglob("*")):
                    if f.is_file() and not _transient(f.name):
                        put(f, f"results/recomputed_diagnostics/{f.relative_to(rc)}", why="recomputed diagnostics",
                            evidence=f.suffix in BINARY_SUFFIXES)
            summ = results / "summary"
            if summ.exists():
                for f in sorted(summ.rglob("*")):
                    if f.is_file():
                        put(f, f"results/summary/{f.relative_to(summ)}")
            for d in runs:
                base = f"results/runs/{d.name}"
                for f in sorted(d.iterdir()):
                    if f.is_file() and not _transient(f.name):
                        if f.suffix in REPORT_SUFFIXES:
                            put(f, f"{base}/{f.name}")
                        elif f.name in SMALL_PT_FILES:
                            put(f, f"{base}/{f.name}", binary=True, why="run-level saved modules / predictions")
                for sub in RUN_SUBDIRS:
                    if (d / sub).exists():
                        for f in sorted((d / sub).rglob("*")):
                            if f.is_file() and not _transient(f.name):
                                # saved predictions and diagnostic maps are small evidence: always included;
                                # only checkpoints and other large binaries count against the budget
                                ev = sub in ("preds", "diagnostics")
                                put(f, f"{base}/{sub}/{f.relative_to(d / sub)}",
                                    binary=(f.suffix in BINARY_SUFFIXES and not ev), why=sub, evidence=ev)
                for stage, why in sorted(referenced_checkpoints(d, child_stage.get(d.name, set())).items()):
                    f = d / "ckpt" / f"{stage}.pt"
                    if f.exists():
                        put(f, f"{base}/ckpt/{stage}.pt", binary=True, why=why)
                    elif why != "classic stage":
                        inv["omitted"].append({"path": f"{base}/ckpt/{stage}.pt", "reason": "referenced but missing",
                                               "referenced_by": why})
        inv["checkpoint_mb_included"] = round(used / 1e6, 3)
        inv["evidence_mb_included"] = round(ev_used / 1e6, 3)
        z.writestr(f"{top}/results/INVENTORY.json", json.dumps(inv, indent=1))
    return (f"wrote {out} ({n_src} source files; {used / 1e6:.1f} MB of checkpoints; "
            f"{len(inv['omitted'])} omissions listed in results/INVENTORY.json)")
