"""Integration-pilot report: per job, the exact environment, config, status,
validity, measured runtime, peak device memory, measured work, disk use,
checkpoint parameter hashes and prediction hashes, plus fresh-process reload
checks of the P3 / P4 runs.  Usage:
    python -m cop.analysis.pilot_report --results R --manifest M --data-root D --device cuda --out pilot_report.json
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch

from ..utils import read_json, read_jsonl, atomic_write_json, tensor_hash


def _dir_size(p: Path) -> int:
    return sum(f.stat().st_size for f in p.rglob("*") if f.is_file())


def report(results: str, manifest: str, data_root: str | None, device: str) -> dict:
    from ..experiments.continuation import baseline_cost
    results = Path(results)
    out = {"environment": read_json(results / "environment.json") if (results / "environment.json").exists() else None,
           "manifest": manifest, "jobs": []}
    for e in read_jsonl(manifest):
        d = results / "runs" / e["run_id"]
        st = read_json(d / "status.json") if (d / "status.json").exists() else {"status": "missing"}
        summ = read_json(d / "summary.json") if (d / "summary.json").exists() else {}
        rec = {"run_id": e["run_id"], "kind": e["cfg"]["kind"], "blocks": e["blocks"],
               "task": (e["cfg"].get("cop") or {}).get("task_kind") or (e["cfg"].get("growth") or {}).get("topology"),
               "data": (e["cfg"].get("data") or {}).get("name"), "model": (e["cfg"].get("model") or {}).get("family"),
               "status": st.get("status"), "validity": st.get("validity"), "reason": st.get("reason"),
               "elapsed_seconds": summ.get("elapsed_seconds"), "peak_memory_bytes": summ.get("peak_memory_bytes"),
               "work": summ.get("work"), "disk_bytes": _dir_size(d) if d.exists() else 0,
               # v13 (audit A2): a baseline's work with provenance (ledger, checkpoint counters, or missing)
               "baseline_cost": baseline_cost(d) if e["cfg"]["kind"] == "baseline" and d.exists() else None,
               "provenance": read_json(d / "provenance.json") if (d / "provenance.json").exists() else None}
        ck = {}
        for p in sorted((d / "ckpt").glob("*.pt")) if (d / "ckpt").exists() else []:
            if any(t in p.name for t in ("partial", "state__")):
                continue
            c = torch.load(p, map_location="cpu", weights_only=False)
            if isinstance(c, dict) and "lineage" in c:
                ck[p.stem] = {"param_hash": c["lineage"]["param_hash"], "graph_hash": c["lineage"]["graph_hash"]}
        rec["checkpoints"] = ck
        preds = {}
        for p in sorted((d / "preds").glob("*.pt")) if (d / "preds").exists() else []:
            preds[p.stem] = tensor_hash(torch.load(p, map_location="cpu", weights_only=False))
        for name in ("alternatives_result.json", "split_result.json"):
            if (d / name).exists():
                for r in read_json(d / name)["rows"]:
                    preds[str(r.get("assembly") or r.get("variant"))] = r.get("pred_hash")
        rec["prediction_hashes"] = preds
        if rec["status"] == "complete" and rec["task"] in ("alternatives", "split"):
            try:
                from ..cop_pegs.alternatives import reload_alternatives
                from ..cop_pegs.split import reload_split
                fn = reload_alternatives if rec["task"] == "alternatives" else reload_split
                r = fn(d, data_root, device)
                rec["fresh_reload"] = {"ok": r["ok"], "max_abs_diff": r["max_abs_diff"],
                                       "all_bitwise_equal": r["all_bitwise_equal"]}
            except Exception as ex:
                rec["fresh_reload"] = {"ok": False, "error": repr(ex)}
        out["jobs"].append(rec)
    out["n_jobs"] = len(out["jobs"])
    out["status_counts"] = {}
    for r in out["jobs"]:
        out["status_counts"][r["status"]] = out["status_counts"].get(r["status"], 0) + 1
    out["max_peak_memory_bytes"] = max((r["peak_memory_bytes"] or 0 for r in out["jobs"]), default=0)
    out["total_elapsed_seconds"] = sum(r["elapsed_seconds"] or 0 for r in out["jobs"])
    return out


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", required=True)
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--out", required=True)
    a = ap.parse_args(argv)
    rep = report(a.results, a.manifest, a.data_root, a.device)
    atomic_write_json(a.out, rep)
    print(json.dumps({k: v for k, v in rep.items() if k not in ("jobs", "environment")}, indent=1))
    bad = [r for r in rep["jobs"] if r["status"] != "complete" or r.get("validity") not in (None, "valid", "unverified")
           or (r.get("fresh_reload") and not r["fresh_reload"]["ok"])]
    for r in bad:
        print("PROBLEM", r["run_id"], r["kind"], r["task"], r["status"], r.get("validity"), r.get("reason"))


if __name__ == "__main__":
    main()
