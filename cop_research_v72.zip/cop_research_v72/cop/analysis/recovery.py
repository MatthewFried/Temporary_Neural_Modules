"""Recovery of existing results after the v7 audit (v8).  Nothing here modifies an existing run directory.

  recovery_manifest(results)        per-run classification and the action each run needs
  recompute_diagnostics(results)    explicit, versioned recomputation of contraction diagnostics from the exact
                                    source checkpoint; written to RESULTS/recomputed_diagnostics/<run>.json
                                    (originals are kept; the analysis prefers a recomputed record for a row whose
                                    original was incomplete)
  recheck_insertions(results)       high-precision identity check (common.identity_check) of recorded insertions,
                                    pre-edit state round_<r-1> (or baseline_ref) against post_insert_r<r>
  replay_cycles(results, scratch)   for cycle contractions without a pre-contraction checkpoint: rerun the
                                    trajectory in a SCRATCH root from copies of its parents, check that every
                                    replayed round_<r> has the original parameter hash, and only then recompute
                                    the diagnostics from the replayed pre_contraction_r<r> state

Sources are verified before use: the checkpoint's recorded parameter hash must match the loaded model, and a
recomputed record must reproduce the original pre-contraction risk; otherwise the run is reported unverifiable.
"""
from __future__ import annotations

import hashlib
import json
import math
import shutil
import time
from pathlib import Path
from types import SimpleNamespace
from typing import Optional

DECLARED_FP32_TOL = 1e-5


def _read(p: Path):
    try:
        return json.loads(Path(p).read_text())
    except (OSError, ValueError):
        return None


def _finite(v) -> bool:
    try:
        return math.isfinite(float(v))
    except (TypeError, ValueError):
        return False


def _sha(p: Path) -> str:
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()[:16]


def _runs(results: Path) -> list[Path]:
    R = Path(results) / "runs"
    return sorted(p for p in R.iterdir() if p.is_dir()) if R.is_dir() else []


def _diag_source(results: Path, run: Path, cfg: dict, tag: str) -> dict:
    """Where the model diagnosed under `tag` comes from."""
    if tag in ("dissipation_start", "repair_start"):
        parent = (cfg.get("parents") or {}).get("trajectory")
        stage = (cfg.get("tags") or {}).get("parent_stage", "final")
        p = Path(results) / "runs" / str(parent) / "ckpt" / f"{stage}.pt"
        return {"kind": "parent_checkpoint", "run": parent, "stage": stage, "path": str(p), "exists": p.exists()}
    if tag.startswith("contraction_c"):
        r = int(tag.rsplit("_r", 1)[1])
        p = run / "ckpt" / f"pre_contraction_r{r}.pt"
        if p.exists():
            return {"kind": "pre_contraction_checkpoint", "run": run.name, "stage": f"pre_contraction_r{r}",
                    "path": str(p), "exists": True}
        return {"kind": "needs_replay", "run": run.name, "stage": f"pre_contraction_r{r}", "path": str(p),
                "exists": False, "note": f"round_{r} is saved after the contraction and is not a substitute"}
    return {"kind": "unknown_tag", "run": run.name, "exists": False}


def recovery_manifest(results: str) -> dict:
    results = Path(results)
    rec_dir = results / "recomputed_diagnostics"
    out = {"results": str(results), "time": time.time(), "runs": {}, "counts": {}}
    for rd in _runs(results):
        cfg = _read(rd / "config.json") or {}
        st = _read(rd / "status.json") or {"status": "missing"}
        e = {"kind": cfg.get("kind"), "status": st.get("status"), "validity": st.get("validity"),
             "categories": [], "actions": [], "reasons": []}
        if st.get("status") != "complete":
            e["categories"].append("unverifiable")
            e["reasons"].append(f"status {st.get('status')}: {st.get('reason')}")
        elif st.get("validity", "valid") != "valid":
            e["categories"].append("unverified_run")
            e["reasons"].append(f"validity {st.get('validity')}: {st.get('validity_reasons')}")
        # Wave-0 controls judged by the v7 relaxed identity rule (cheap to rerun: no dependants train on them)
        cr = _read(rd / "control_results.json") if (rd / "control_results.json").exists() else None
        if cr:
            loose = [x for x in cr.get("records", []) if x.get("roundoff_floor_rel") is not None and
                     (not _finite(x.get("tolerance_rel")) or float(x.get("tolerance_rel")) > DECLARED_FP32_TOL)]
            if loose:
                e["categories"].append("needs_identity_recheck")
                e["actions"].append("rerun this control job under v8 (the v8 identity check replaces the v7 rule)")
                e["reasons"].append(f"{len(loose)} control checks passed under the v7 relaxed tolerance "
                                    f"(e.g. {loose[0].get('construction')} {loose[0].get('dtype')})")
        # contraction diagnostics
        diag = _read(rd / "contraction_diagnostics.json") if (rd / "contraction_diagnostics.json").exists() else None
        recomputed = _read(rec_dir / f"{rd.name}.json") or {}
        for tag, r in (diag or {}).items():
            bad = [i for i, row in (r.get("implants") or {}).items()
                   if "skipped" not in row and (row.get("error") or row.get("complete") is False)]
            if not bad:
                continue
            if (recomputed.get("records") or {}).get(tag, {}).get("status") == "ok":
                e["reasons"].append(f"{tag}: recomputed ({recomputed.get('diagnostic_version')})")
                continue
            from .gates import source_recorded_invalid
            why = source_recorded_invalid(results, rd.name, tag)
            if why:
                e["categories"].append("source_recorded_invalid")
                e["reasons"].append(f"{tag}: incomplete rows {bad}; {why} (nothing to recompute)")
                continue
            src = _diag_source(results, rd, cfg, tag)
            if src["kind"] == "needs_replay":
                e["categories"].append("needs_cycle_replay")
                e["actions"].append(f"replay {rd.name} in a scratch root to recover {src['stage']} ({tag})")
            elif src["exists"]:
                e["categories"].append("needs_diagnostic_recompute")
                e["actions"].append(f"recompute {tag} from {src['run']}:{src['stage']}")
            else:
                e["categories"].append("unverifiable")
                e["reasons"].append(f"{tag}: source checkpoint missing ({src.get('path')})")
            e["reasons"].append(f"{tag}: incomplete rows {bad}")
        # transplants
        tr = _read(rd / "transplant_result.json") if (rd / "transplant_result.json").exists() else None
        if tr and (tr.get("info") or {}).get("design") == "grid":
            from .v5_tables import grid_assembly_eligibility
            bad = sorted(k for k, v in grid_assembly_eligibility(tr).items() if not v.get("eligible"))
            if bad:
                e["categories"].append("needs_adapter_refit")
                e["actions"].append("rerun this transplant job under v8 (parents are reused; only adapters are fitted)")
                e["reasons"].append(f"ineligible assemblies {bad}")
        # deletion landscapes: analysis only
        for p in sorted(rd.glob("deletions_*.json")):
            d = _read(p) or {}
            nf = sum(1 for row in d.get("rows", []) for part in (row.get("metrics") or {}).values()
                     for k in ("delta_risk", "nmse_increase", "delta_acc")
                     if part.get(k) is not None and not _finite(part.get(k)))
            if nf:
                e["categories"].append("analysis_only")
                e["reasons"].append(f"{p.name}: {nf} non-finite deletion values (landscape reported invalid by v8)")
        # insertion gates relaxed by the v7 rule
        if (rd / "metrics.jsonl").exists() and cfg.get("kind") == "trajectory":
            loose = []
            with open(rd / "metrics.jsonl") as f:
                for line in f:
                    try:
                        row = json.loads(line)
                    except ValueError:
                        continue
                    if row.get("metric_name") == "insertion_label" and row.get("roundoff_floor_rel") is not None:
                        tol = row.get("tolerance_rel")
                        if tol is None or not _finite(tol) or float(tol) > DECLARED_FP32_TOL:
                            loose.append({"stage": row.get("stage"), "label": row.get("metric_value"),
                                          "tolerance_rel": tol, "roundoff_floor_rel": row.get("roundoff_floor_rel")})
            if loose:
                e["categories"].append("needs_identity_recheck")
                e["actions"].append("recheck-insertions (high precision, pre-edit vs post-edit checkpoints)")
                e["reasons"].append(f"v7 relaxed identity tolerance at {[x['stage'] for x in loose]} "
                                    f"(review flag, not proof of an invalid insertion)")
                e["loose_insertions"] = loose
        if not e["categories"]:
            e["categories"].append("reusable_unchanged")
        e["categories"] = sorted(set(e["categories"]))
        out["runs"][rd.name] = e
    from collections import Counter
    out["counts"] = dict(Counter(c for e in out["runs"].values() for c in e["categories"]))
    out["note"] = ("v8 code has a new semantic hash, so every v7 run is 'stale' to the runner.  Reusable runs can be "
                   "kept with an explicit, reasoned `cop accept-stale`; runs needing a recompute keep their "
                   "training outputs and get a separate recomputed diagnostic record.")
    return out


def same_value(a, b) -> bool:
    """Recorded and recomputed scalar agree (relative 1e-6); stored non-finite values are 'inf' / 'nan'
    strings and agree only with the same non-finite value."""
    a, b = float(a), float(b)
    if not (math.isfinite(a) and math.isfinite(b)):
        return a == b or (math.isnan(a) and math.isnan(b))
    return abs(a - b) <= 1e-6 * max(1.0, abs(a))


def _load_model(path: Path, device: str):
    import torch
    from ..graph.graph import GraphNet
    ck = torch.load(path, map_location="cpu", weights_only=False)
    g = GraphNet.from_checkpoint(ck["model"], device)
    recorded = (ck.get("lineage") or {}).get("param_hash")
    return g, recorded, g.param_hash()


def _recompute_one(results: Path, rd: Path, cfg: dict, tag: str, orig: dict, src: dict, device: str,
                   data_root: Optional[str], out_dir: Path) -> dict:
    from ..data.registry import load_bundle
    from ..experiments.diagnostics import contraction_diagnostics, DIAGNOSTIC_VERSION
    g, recorded, loaded = _load_model(Path(src["path"]), device)
    res = {"source": {**src, "recorded_param_hash": recorded, "loaded_param_hash": loaded},
           "diagnostic_version": DIAGNOSTIC_VERSION,
           "original_record_sha256": hashlib.sha256(json.dumps(orig, sort_keys=True).encode()).hexdigest()[:16],
           "original_incomplete_rows": sorted(i for i, r in (orig.get("implants") or {}).items()
                                              if "skipped" not in r and (r.get("error") or r.get("complete") is False))}
    if recorded is not None and recorded != loaded:
        res["status"] = "unverifiable: the source checkpoint does not reproduce its recorded parameter hash"
        return res
    bundle = load_bundle(cfg["data"], data_root, device="cpu").to(device)
    ids = [i for i, r in (orig.get("implants") or {}).items() if "skipped" not in r]
    # a fresh, version-keyed folder per attempt: a cached record of an earlier attempt is never reused
    work = out_dir / DIAGNOSTIC_VERSION / tag
    if work.exists():
        shutil.rmtree(work)                              # created by this tool, inside recomputed_diagnostics/
    work.mkdir(parents=True)
    ctx = SimpleNamespace(dir=work, cfg=cfg, metric=lambda *a, **k: None)
    rec = contraction_diagnostics(ctx, g, bundle, ids, tag)
    po, pn = orig.get("pre_contraction_risk") or {}, rec.get("pre_contraction_risk") or {}
    same = bool(po) and all(k in pn and same_value(po[k], pn[k]) for k in po)
    if not same:
        status = ("unverifiable: the recomputed pre-contraction risk differs from the original record (the source "
                  "state is not the diagnosed state)")
    elif not rec.get("complete"):
        status = "incomplete: the recomputation still has incomplete measurements (see record); retry is allowed"
    else:
        status = "ok"
    res.update({"record": rec, "reproduces_original_pre_contraction_risk": same, "status": status})
    return res


def recompute_diagnostics(results: str, device: str = "cpu", data_root: Optional[str] = None,
                          runs: Optional[list[str]] = None, only_incomplete: bool = True) -> dict:
    from ..utils import semantic_code_hash
    results = Path(results)
    out_root = results / "recomputed_diagnostics"
    out_root.mkdir(exist_ok=True)
    summary = {"written": [], "skipped": [], "unverifiable": [], "needs_replay": []}
    for rd in _runs(results):
        if runs and rd.name not in runs:
            continue
        diag = _read(rd / "contraction_diagnostics.json") if (rd / "contraction_diagnostics.json").exists() else None
        if not diag:
            continue
        cfg = _read(rd / "config.json") or {}
        doc = _read(out_root / f"{rd.name}.json") or {"run_id": rd.name, "records": {}}
        doc.update({"diagnostic_code_semantic_hash": semantic_code_hash(), "time": time.time()})
        for tag, orig in diag.items():
            bad = [i for i, r in (orig.get("implants") or {}).items()
                   if "skipped" not in r and (r.get("error") or r.get("complete") is False)]
            if only_incomplete and not bad:
                continue
            if not only_incomplete:
                pass                                     # --all: recompute every record again
            elif tag in doc["records"] and doc["records"][tag].get("status") == "ok":
                summary["skipped"].append(f"{rd.name}:{tag} (already recomputed)")
                continue
            src = _diag_source(results, rd, cfg, tag)
            if src["kind"] == "needs_replay":
                summary["needs_replay"].append(f"{rd.name}:{tag}")
                doc["records"][tag] = {"source": src, "status": "needs_replay"}
                continue
            if not src["exists"]:
                summary["unverifiable"].append(f"{rd.name}:{tag} (missing {src.get('path')})")
                doc["records"][tag] = {"source": src, "status": "unverifiable: source checkpoint missing"}
                continue
            r = _recompute_one(results, rd, cfg, tag, orig, src, device, data_root, out_root / rd.name)
            doc["records"][tag] = r
            (summary["written"] if r["status"] == "ok" else summary["unverifiable"]).append(
                f"{rd.name}:{tag}" + ("" if r["status"] == "ok" else f" ({r['status'][:60]})"))
        if doc["records"]:
            doc["diagnostic_version"] = "diag-8.0"
            (out_root / f"{rd.name}.json").write_text(json.dumps(doc, indent=1, default=str))
    return summary


def recheck_insertions(results: str, device: str = "cpu", data_root: Optional[str] = None,
                       runs: Optional[list[str]] = None, all_insertions: bool = False) -> dict:
    """identity_check of recorded insertions from the saved pre- and post-edit checkpoints."""
    import torch
    from ..data.registry import load_bundle
    from ..experiments import common as C
    man = recovery_manifest(results)
    out = {"rechecked": {}, "unavailable": {}}
    for rid, e in man["runs"].items():
        if runs and rid not in runs:
            continue
        if not all_insertions and "needs_identity_recheck" not in e["categories"]:
            continue
        rd = Path(results) / "runs" / rid
        cfg = _read(rd / "config.json") or {}
        if cfg.get("kind") != "trajectory":
            continue                                  # controls are rerun, not rechecked (see the manifest action)
        stages = [x["stage"] for x in e.get("loose_insertions", [])] if not all_insertions else \
            sorted(p.stem.replace("post_insert_r", "insert_r").replace("post_insert_all", "insert_all")
                   for p in (rd / "ckpt").glob("post_insert_*.pt"))
        bundle = load_bundle(cfg["data"], data_root, device="cpu").to(device)
        sets = C.calib_sets(bundle, cfg["eval"]["calib_size"], cfg["eval"]["stress_scale"])
        dtype = torch.float64 if cfg["train"]["precision"] == "fp64" else torch.float32
        for stage in stages:
            if stage == "insert_all":                # all-at-once schedule: f0 (baseline_ref) against post_insert_all
                pre_p, post_p = rd / "ckpt" / "baseline_ref.pt", rd / "ckpt" / "post_insert_all.pt"
            elif stage.startswith("insert_r"):
                r = int(stage[len("insert_r"):])
                pre_p = rd / "ckpt" / (f"round_{r - 1}.pt" if r > 1 else "baseline_ref.pt")
                post_p = rd / "ckpt" / f"post_insert_r{r}.pt"
            else:
                out["unavailable"][f"{rid}:{stage}"] = "not an insertion stage"
                continue
            if not (pre_p.exists() and post_p.exists()):
                out["unavailable"][f"{rid}:{stage}"] = f"missing {pre_p.name if not pre_p.exists() else post_p.name}"
                continue
            pre, _, _ = _load_model(pre_p, device)
            post, _, _ = _load_model(post_p, device)
            out["rechecked"][f"{rid}:{stage}"] = C.identity_check(pre, post, sets, dtype, cfg)
    out["note"] = ("pre-edit = round_<r-1> (baseline_ref for r = 1), post-edit = post_insert_r<r>; a contraction "
                   "inside round r-1 happens before round_<r-1> is saved, so this is the state the insertion saw")
    return out


def _parent_closure(results: Path, run_id: str) -> list[str]:
    seen, stack = [], [run_id]
    while stack:
        r = stack.pop()
        cfg = _read(Path(results) / "runs" / r / "config.json") or {}
        for pid in (cfg.get("parents") or {}).values():
            if pid and pid not in seen:
                seen.append(pid)
                stack.append(pid)
    return seen


def replay_cycles(results: str, scratch: str, device: str = "cpu", data_root: Optional[str] = None,
                  runs: Optional[list[str]] = None) -> dict:
    """Rerun cycle trajectories that lack pre-contraction checkpoints, in a scratch root, from COPIES of their
    parents (each copy is marked as an accepted reuse with the reason in its own reuse_accepted.jsonl), then
    compare every replayed round_<r> with the original parameter hash.  Diagnostics are recomputed from the
    replayed pre_contraction_r<r> only when every compared checkpoint matches."""
    import torch
    from ..orchestration.runner import run_job
    from ..utils import append_jsonl, semantic_code_hash
    results, scratch = Path(results).resolve(), Path(scratch).resolve()
    if scratch == results or results in scratch.parents or scratch in results.parents:
        raise ValueError(f"the scratch folder {scratch} must be outside the results folder {results} (and not contain it)")
    man = recovery_manifest(str(results))
    out = {}
    for rid, e in man["runs"].items():
        if "needs_cycle_replay" not in e["categories"] or (runs and rid not in runs):
            continue
        cfg = _read(results / "runs" / rid / "config.json")
        root = scratch / rid
        marker = root / ".cop_replay_scratch"
        if root.exists():
            if not marker.exists():
                raise ValueError(f"{root} exists and was not created by replay-cycles: refusing to remove it")
            shutil.rmtree(root)
        (root / "runs").mkdir(parents=True)
        marker.write_text(json.dumps({"created_by": "cop.analysis.recovery.replay_cycles", "source_results": str(results),
                                      "run": rid, "time": time.time()}))
        for pid in _parent_closure(results, rid):
            shutil.copytree(results / "runs" / pid, root / "runs" / pid)
            append_jsonl(root / "runs" / pid / "reuse_accepted.jsonl",
                         {"accepted_for_semantic_hash": semantic_code_hash(), "reason": "v8 recovery replay: a copy of a "
                          "completed parent, reused unchanged to regenerate a missing pre-contraction state",
                          "time": time.time(), "user": "recovery.replay_cycles"})
        st = run_job(cfg, root, {"device": device, "data_root": data_root})
        rec = {"replay_status": st, "rounds": {}}
        orig_ck, new_ck = results / "runs" / rid / "ckpt", root / "runs" / rid / "ckpt"
        match = st == "complete"
        compared = sorted(orig_ck.glob("round_*.pt")) + sorted(orig_ck.glob("post_insert_r*.pt"))
        if not compared:
            match = False
            rec["reason"] = "the original run has no round_<r> / post_insert_r<r> checkpoints to compare against"
        for p in compared:
            a = (torch.load(p, map_location="cpu", weights_only=False).get("lineage") or {}).get("param_hash")
            q = new_ck / p.name
            b = (torch.load(q, map_location="cpu", weights_only=False).get("lineage") or {}).get("param_hash") \
                if q.exists() else None
            rec["rounds"][p.stem] = {"original": a, "replayed": b, "equal": a is not None and a == b}
            match = match and a is not None and a == b
        rec["history_reproduced"] = bool(match)
        if match:
            diag = _read(results / "runs" / rid / "contraction_diagnostics.json") or {}
            doc = _read(results / "recomputed_diagnostics" / f"{rid}.json") or {"run_id": rid, "records": {}}
            for tag, orig in diag.items():
                if not tag.startswith("contraction_c"):
                    continue
                r_ = int(tag.rsplit("_r", 1)[1])
                src = {"kind": "replayed_pre_contraction_checkpoint", "run": rid, "stage": f"pre_contraction_r{r_}",
                       "path": str(new_ck / f"pre_contraction_r{r_}.pt"), "exists": (new_ck / f"pre_contraction_r{r_}.pt").exists(),
                       "replay_root": str(root), "history_check": rec["rounds"]}
                if not src["exists"]:
                    doc["records"][tag] = {"source": src, "status": "unverifiable: replay saved no pre-contraction state"}
                    continue
                doc["records"][tag] = _recompute_one(results, results / "runs" / rid, cfg, tag, orig, src, device,
                                                     data_root, results / "recomputed_diagnostics" / rid)
            (results / "recomputed_diagnostics").mkdir(exist_ok=True)
            (results / "recomputed_diagnostics" / f"{rid}.json").write_text(json.dumps(doc, indent=1, default=str))
        out[rid] = rec
    return out
