"""Tables and figures 1-7 of the strengthening extension (wave 7).

Unit of analysis: the ENDPOINT of one job, i.e. the checkpoint named in its
endpoint.json, re-evaluated on every partition (stage 'endpoint'), with its
numerical status and architecture.  No other stage stands in for an endpoint.

A comparison pairs a treated endpoint with a control endpoint of the same
contrast under a CONTRACT:
  * pairing key: (design.contrast, f0 run, replication, control arm, budget panel); the f0 run fixes
    data, split, teacher, model, training scale and seeds; a duplicate key is an error (strict) or
    excludes every entry of that key (recorded), never resolved by file order;
  * compatibility: data, model config, target regime and f0 run must agree;
  * estimand, from the endpoint architectures (sharing-aware hash):
      fixed_architecture   treated, control and f0 share one architecture (same-architecture gain)
      matched_endpoint     treated and control share an architecture different from f0's (e.g. a
                           control re-trained on the treated CoP export)
      cost_frontier        the architectures differ (risk against cost; not a gain at fixed architecture)
  * numerical eligibility: complete, valid, not diverged, finite tensors and endpoint metrics.
G = R(control) - R(treated) (positive: treated better) per replication; mean and percentile
bootstrap over replications are EXPLORATORY at screening sizes.  Every summary row carries its
denominators (expected, eligible, diverged, unmatched, paired).  Compute columns are the declared
estimate (dense 3 x forward MACs, plus a backward-aware estimate), with a completeness flag.
"""
from __future__ import annotations

import json
import math
import random
from collections import defaultdict
from pathlib import Path
from typing import Optional

from ..config import condition_id
from ..utils import read_json, atomic_write_json

ESTIMANDS = ("fixed_architecture", "matched_endpoint", "cost_frontier")


def _rk(cfg) -> str:
    """Replication unit inside a contrast: the paired data / teacher / optimizer seed of wave 7 (other
    seed streams of a job, e.g. insertion, follow the replication and are not pairing keys)."""
    d = cfg.get("data") or {}
    sd = cfg.get("seeds") or {}
    k = f"data{d.get('data_seed')}_teacher{d.get('teacher_seed')}_opt{sd.get('optimizer')}"
    # v17: an explicitly set partition seed is a replication within the draw (nested, like optimizer seeds)
    return k + (f"_part{sd['partition']}" if sd.get("partition") is not None else "")


PARTS = ("val", "test", "rare", "shift", "cf_base", "cf_causal", "cf_shortcut", "complete_domain",
         "val_indep", "val_reversed", "val_rare")


def _rows(run):
    from .summarize import metrics_of
    return metrics_of(run)


def _stage_metrics(rows, stage) -> dict:
    out = defaultdict(dict)
    for r in rows:
        if r["stage"] == stage and r.get("atoms") is None:
            out[r["evaluation_partition"]][r["metric_name"]] = r["metric_value"]
    return out


def post_f0_work(runs: dict, rid: str, seen=None) -> dict:
    """Post-f0 training work of the chain ending at run rid (the C1 / C2 budget rule:
    experiments.continuation.chain_work_dir; snapshot children charged up to the snapshot;
    diagnostic phases excluded).  A continuation that starts from another run's endpoint
    (durability, endpoint-matched controls) adds that run's chain."""
    from ..experiments.continuation import chain_work_dir, run_work, ZERO_WORK
    seen = seen or set()
    if rid in seen or rid not in runs:
        return dict(ZERO_WORK)
    seen.add(rid)
    r = runs[rid]
    c = r["cfg"]
    if c["kind"] == "baseline":
        return dict(ZERO_WORK)
    if c["kind"] == "continue":
        w = run_work(r["dir"])
        s_ = c["continue"]["start"]
        if s_ != "baseline" and (c.get("parents") or {}).get(s_) and not c["continue"].get("reinit"):
            pw = post_f0_work(runs, c["parents"][s_], seen)
            from ..experiments.continuation import _W0
            w2 = {k: w.get(k, 0) + pw.get(k, 0) for k in _W0}
            w2["macs_complete"] = bool(w.get("macs_complete", True)) and bool(pw.get("macs_complete", True))
            w2["accounting_complete"] = bool(w.get("accounting_complete", True)) and \
                bool(pw.get("accounting_complete", True))
            if pw.get("accounting_note"):
                w2["accounting_note"] = pw["accounting_note"]
            w = w2
        return w
    return chain_work_dir(r["dir"])


def cost_parts(runs: dict, rid: str) -> dict:
    """v20: the explicit cost split of a run that consumes learned models (dissipations, hybrids): own training
    (removal / repair), the source lineage up to the stage used, the donor's incremental training, and their
    accounting completeness."""
    from ..experiments.continuation import chain_work_parts
    r = runs.get(rid)
    if r is None or r["cfg"]["kind"] in ("baseline", "continue"):
        return {}
    parts = chain_work_parts(r["dir"])
    out = {}
    for name in ("own", "source_lineage", "donor_incremental"):
        for k in ("updates", "examples", "macs"):
            out[f"cost_{name}_{k}"] = parts[name].get(k)
    out["cost_accounting_complete"] = bool(parts["total"].get("accounting_complete", True))
    if parts["total"].get("accounting_note"):
        out["cost_accounting_note"] = parts["total"]["accounting_note"]
    return out


def _f0_run(runs: dict, rid: str, seen=None) -> Optional[str]:
    """The baseline (f0) job at the root of a run's chain."""
    seen = seen or set()
    if rid in seen or rid not in runs:
        return None
    seen.add(rid)
    c = runs[rid]["cfg"]
    if c["kind"] == "baseline":
        return rid
    par = c.get("parents") or {}
    for role in ("baseline", "trajectory", "start", "treated", "upstream", "downstream"):
        if role in par:
            r = _f0_run(runs, par[role], seen)
            if r:
                return r
    return None


def f0_cost(runs: dict, rid: str) -> dict:
    """Baseline (f0) training work of the chain ending at rid, with provenance (v13, audit A2): the baseline
    job's ledger or its checkpoint counters, or the counters of an f0 trained inline by the chain's root job.
    Missing evidence is incomplete, never zero-and-complete."""
    from ..experiments.continuation import baseline_cost, inline_f0_cost, ZERO_WORK
    f0 = _f0_run(runs, rid)
    if f0 is not None and f0 in runs:
        return {**baseline_cost(runs[f0]["dir"]), "f0_run": f0}
    seen, cur = set(), rid
    while cur in runs and cur not in seen:                   # walk to the chain root
        seen.add(cur)
        par = runs[cur]["cfg"].get("parents") or {}
        nxt = next((par[k] for k in ("trajectory", "start", "treated", "parent") if k in par), None)
        if nxt is None or nxt not in runs:
            break
        cur = nxt
    if cur in runs:
        w = inline_f0_cost(runs[cur]["dir"])
        if w is not None:
            return {**w, "f0_run": f"inline:{cur}"}
    return {**dict(ZERO_WORK), "macs_complete": False, "provenance": "missing: no f0 found for this chain",
            "source": None, "f0_run": None}


def _f0_stage(runs: dict, rid: str, seen=None) -> str:
    """Which checkpoint of the baseline job the chain ending at rid started from: tags.f0_stage of the chain's
    trajectory / CoP root, or continue.start_stage of a continuation started from the baseline."""
    seen = seen or set()
    if rid in seen or rid not in runs:
        return "baseline"
    seen.add(rid)
    c = runs[rid]["cfg"]
    cc = c.get("continue") or {}
    if c["kind"] == "continue" and cc.get("start") == "baseline":
        return str(cc.get("start_stage", "baseline"))
    tag = (c.get("tags") or {}).get("f0_stage")
    if tag and "baseline" in (c.get("parents") or {}):
        return str(tag)
    par = c.get("parents") or {}
    for role in ("trajectory", "start", "treated", "parent", "cycles"):
        if role in par and (c["kind"] != "continue" or role == cc.get("start")):
            return _f0_stage(runs, par[role], seen)
    return "baseline"


def _from_scratch_history(runs: dict, rid: str, seen=None) -> bool:
    """True when the chain ending at rid trains its model from random initialisation (a trajectory with
    growth.schedule = from_scratch): such a history never used f0's training, so no baseline cost is added."""
    seen = seen or set()
    if rid in seen or rid not in runs:
        return False
    seen.add(rid)
    c = runs[rid]["cfg"]
    if c["kind"] == "trajectory" and (c.get("growth") or {}).get("schedule") == "from_scratch":
        return True
    cc = c.get("continue") or {}
    if c["kind"] == "continue" and cc.get("reinit"):
        # v23: a re-initialised continuation starts from random weights: it consumes no trained f0 (f0 is a
        # reference / budget source only), whether or not its budget adds f0's updates
        return True
    par = c.get("parents") or {}
    for role in ("trajectory", "start", "treated", "parent"):
        if role in par and (c["kind"] != "continue" or role == cc.get("start")):
            return _from_scratch_history(runs, par[role], seen)
    return False


def _starts_from_snapshot(runs: dict, rid: str) -> bool:
    c = runs[rid]["cfg"]
    if (c.get("tags") or {}).get("f0_stage") or str((c.get("continue") or {}).get("start_stage", "")).startswith("snap_"):
        return True
    par = c.get("parents") or {}
    t = par.get("trajectory")
    return bool(t in runs and (runs[t]["cfg"].get("tags") or {}).get("f0_stage"))


def _endpoint_record(run) -> Optional[dict]:
    p = run["dir"] / "endpoint.json"
    return read_json(p) if p.exists() else None


def _selected_fields(run, task, prefix: str) -> dict:
    """Metrics of a job's validation-selected endpoint (endpoint_best_val.json, stage endpoint_best_val)."""
    p = run["dir"] / "endpoint_best_val.json"
    if not p.exists():
        return {f"{prefix}available": False}
    ep = read_json(p)
    if not ep.get("checkpoint"):
        return {f"{prefix}available": False, f"{prefix}reason": ep.get("reason")}
    m = _stage_metrics(_rows(run), "endpoint_best_val")
    out = {f"{prefix}available": bool(ep.get("numerically_valid", True)), f"{prefix}n_candidates": ep.get("n_candidates"),
           f"{prefix}global_step": ep.get("selected_global_step"), f"{prefix}partition": ep.get("selection_partition"),
           f"{prefix}architecture_hash": ep.get("architecture_hash")}
    for part in PARTS:
        mp = m.get(part, {})
        if mp:
            out[f"{prefix}{part}_risk"] = _risk(mp, task)
            if "acc" in mp:
                out[f"{prefix}{part}_err"] = 1.0 - mp["acc"]
    return out


def selected_gain(E: list[dict], metric: str, estimand: str, f0_fallback: bool, rejected: Optional[list] = None):
    """Analysis (ii), the best deployable compact endpoint (v13, audit C1 / C2): every arm's
    VALIDATION-SELECTED endpoint, paired as in compact_gain.  Rules, applied symmetrically to every arm:
      * an arm enters only with a selected endpoint whose architecture is the arm's own final architecture
        (selection runs in the final compact phase only, so an expanded state never wins);
      * a pair needs equal declared selection opportunities (n_candidates) in the two arms;
      * f0_fallback (fixed_architecture only): each arm's choice is min-by-VALIDATION of its selected endpoint and
        the selected f0; the row records whether the arm fell back to f0 (an edited endpoint that did not beat
        f0 on validation is reported, not hidden).  C0 is the selected f0 itself.
    Test partitions are only read after the choice."""
    rej = rejected if rejected is not None else []
    out, by_tr = [], {}
    for e in E:
        if not e.get("eligible"):
            continue
        if not e.get("sel_available"):
            rej.append({"run_id": e["run_id"], "reason": "no validation-selected endpoint"})
            continue
        if e.get("sel_architecture_hash") != e.get("architecture_hash"):
            rej.append({"run_id": e["run_id"], "reason": "selected checkpoint is not the arm's final architecture"})
            continue
        x = dict(e)
        x[metric] = e.get(f"sel_{metric}")
        # the fallback compares on the partition the selection itself used
        sp = e.get("sel_partition") or "val"
        x["selected_val_risk"] = e.get(f"sel_{sp}_risk")
        f0v = e.get(f"f0_sel_{sp}_risk")
        x["selected_f0"] = False
        if f0_fallback and estimand == "fixed_architecture" and f0v is not None \
                and x["selected_val_risk"] is not None and f0v < x["selected_val_risk"]:
            x[metric] = e.get(f"f0_sel_{metric}")
            x["selected_f0"] = True
        x[f"f0_{metric}"] = e.get(f"f0_sel_{metric}")              # C0 = the selected f0
        out.append(x)
        if e.get("design_arm") == "treated":
            by_tr[(e["design_contrast"], e.get("f0_run"), e.get("f0_stage"), e["replication"])] = e.get("sel_n_candidates")
    keep = []
    for x in out:
        k = (x["design_contrast"], x.get("f0_run"), x.get("f0_stage"), x["replication"])
        if x.get("design_arm") != "treated" and k in by_tr and x.get("sel_n_candidates") != by_tr[k]:
            rej.append({"run_id": x["run_id"], "reason": f"unequal selection opportunities (treated "
                                                         f"{by_tr[k]}, this arm {x.get('sel_n_candidates')})"})
            continue
        keep.append(x)
    summ, pairs = compact_gain(keep, metric, estimand, strict=False, rejected=rej)
    sel = {x["run_id"]: x for x in keep}
    for q in pairs:
        q["treated_selected_f0"] = bool(sel.get(q["treated_run"], {}).get("selected_f0"))
        q["control_selected_f0"] = bool(sel.get(q["control_run"], {}).get("selected_f0"))
        q["f0_fallback_policy"] = bool(f0_fallback)
        q["analysis"] = "validation-selected endpoint (ii)"
    for r_ in summ:
        r_["f0_fallback_policy"] = bool(f0_fallback)
        r_["analysis"] = "validation-selected endpoint (ii)"
    return summ, pairs


def _run_task(runs: dict, rid: str, cache: dict) -> Optional[str]:
    """classification when the run logged an accuracy, otherwise regression (as in endpoint_table)."""
    if rid not in cache:
        rows = _rows(runs[rid]) if rid in runs else []
        cache[rid] = None if not rows else ("classification" if any(r.get("metric_name") == "acc" for r in rows)
                                            else "regression")
    return cache[rid]


def _risk(mp: dict, task: str):
    if not mp:
        return None
    return mp.get("mse") if task == "regression" else mp.get("loss")


def contraction_mechanism(c: dict) -> str:
    """How a treated endpoint returned to compactness (v5): exact fold (algebra), bypass / gated removal,
    abrupt removal, learned repair, fitted replacement (CoP local fits), export of a pegged chain, or none."""
    k = c["kind"]
    if k == "dissipation":
        m = c["dissipation"]["method"]
        if m == "fold":
            return "exact_fold"
        if m == "fold_unrouted":
            return "exact_fold_unrouted"               # v59: exact, and the routing ends at the fold
        if m in ("abrupt", "group_removal"):
            return "abrupt_removal_plus_training" if int(c["dissipation"].get("post_updates", 0)) else "abrupt_removal"
        if m == "peg_replacement":
            return "fitted_replacement"
        return "gated_removal"                         # linear / cosine / stochastic bypass / residual penalty ...
    if k == "repair":
        return "abrupt_removal_plus_learned_repair"
    if k == "trajectory":
        g = c.get("growth") or {}
        if int(g.get("contract_every") or 0):
            return f"cycle_contraction_{g.get('contract_method', 'auto')}"
        return "none"
    if k == "cop":
        tk = (c.get("cop") or {}).get("task_kind")
        return {"chain": "pegged_chain_export", "cycles": "fitted_replacement", "baseline": "control_training"}.get(tk, tk)
    return "none (control or reference)"


def _expanded_state(runs: dict, c: dict, task: str, run_dir=None) -> dict:
    """Test risk of the expanded model immediately before contraction, for dissipation / repair endpoints.
    Primary source: the job's own contraction diagnostics (`pre_contraction_risk`, evaluated on the model
    the job actually started from, whatever its parent stage, including snapshots).  Fallback: the parent
    trajectory's metrics at the parent stage (logged for 'final' and the round stages, not for snapshots).
    When neither exists the reason is recorded (never silently None)."""
    if c["kind"] not in ("dissipation", "repair"):
        return {}
    st = (c.get("tags") or {}).get("parent_stage", "final")
    tag = "dissipation_start" if c["kind"] == "dissipation" else "repair_start"
    if run_dir is not None:
        p = Path(run_dir) / "contraction_diagnostics.json"
        if p.exists():
            v = ((read_json(p).get(tag) or {}).get("pre_contraction_risk") or {}).get("test")
            if v is not None:
                return {"expanded_stage": st, "expanded_test_risk": float(v),
                        "expanded_source": f"contraction_diagnostics:{tag}"}
    t = (c.get("parents") or {}).get("trajectory")
    if t not in runs:
        return {"expanded_stage": st, "expanded_test_risk": None, "expanded_source": "parent trajectory missing"}
    m = _stage_metrics(_rows(runs[t]), st).get("test", {})
    if not m:
        return {"expanded_stage": st, "expanded_test_risk": None,
                "expanded_source": f"no test metrics at parent stage {st}"}
    return {"expanded_stage": st, "expanded_test_risk": _risk(m, task), "expanded_source": f"parent:{st}"}


def _witness_of(runs: dict, f0: Optional[str], task: str) -> dict:
    if f0 not in runs:
        return {}
    p = runs[f0]["dir"] / "witness.json"
    if not p.exists():
        return {}
    w = read_json(p)
    out = {"witness_realizable": bool(w.get("realizable")), "witness_reason": w.get("reason")}
    if w.get("realizable") and task == "regression":
        out["witness_test_risk"] = ((w.get("risk") or {}).get("test") or {}).get("mse")
    return out


def endpoint_table(runs: dict) -> list[dict]:
    """One row per design job with its eligibility reasons (eligible = no reason)."""
    out = []
    f0_cache: dict = {}
    for rid, r in runs.items():
        c = r["cfg"]
        d = c.get("design") or {}
        if not d.get("family"):
            continue
        f0 = _f0_run(runs, rid)
        row = {"run_id": rid, "kind": c["kind"], "status": r["status"]["status"],
               "validity": r["status"].get("validity"), "reason": r["status"].get("reason"),
               "condition_id": condition_id(c), "replication": _rk(c), "block": c.get("block"),
               **{f"design_{k}": v for k, v in d.items()}, "data": c["data"]["name"], "model": c["model"]["family"],
               "data_identity": json.dumps(c["data"], sort_keys=True),
               "model_identity": json.dumps(c["model"], sort_keys=True), "f0_run": f0, "task": None,
               "f0_stage": _f0_stage(runs, rid)}
        reasons = []
        if row["status"] != "complete":
            reasons.append(f"status {row['status']}")
        elif row["validity"] not in (None, "valid"):
            reasons.append(f"validity {row['validity']}")
        ep = _endpoint_record(r) if not reasons else None
        if not reasons and ep is None:
            multi = c["kind"] == "transplant" or (c["kind"] == "cop" and (c.get("cop") or {}).get("task_kind") in
                                                  ("alternatives", "locality"))
            reasons.append("multi-model job without a single endpoint: reported per row in s_transplants.csv / "
                           "s_transplant_grid.csv / s_cop_extension.csv / s_locality.csv, not as a paired endpoint "
                           "contrast" if multi else "no endpoint record (endpoint.json)")
        if ep is not None:
            row.update({"endpoint_checkpoint": ep["checkpoint"], "endpoint_updates": ep["updates"],
                        "diverged": ep["diverged"], "diverged_reason": ep.get("diverged_reason"),
                        "architecture_hash": ep["architecture_hash"], "endpoint_params": ep["params"],
                        "endpoint_macs": ep["macs"], "endpoint_peg_bits": ep.get("peg_bits_per_example"),
                        "any_bypass": ep.get("any_bypass"), "n_implants": ep.get("n_implants")})
            reasons += list(ep.get("numerical_reasons") or [])
            m = _stage_metrics(_rows(r), "endpoint")
            task = "classification" if "acc" in m.get("test", m.get("val", {})) else "regression"
            row["task"] = task
            for p in PARTS:
                mp = m.get(p, {})
                if not mp:
                    continue
                row[f"{p}_risk"] = _risk(mp, task)
                if "acc" in mp:
                    row[f"{p}_err"] = 1.0 - mp["acc"]
                for k in ("balanced_group_acc", "worst_group_acc", "worst_group_mse", "teacher_imitation_mse",
                          "teacher_imitation_nmse", "teacher_imitation_kl", "teacher_disagreement"):
                    if k in mp:
                        row[f"{p}_{k}"] = mp[k]
            none = _stage_metrics(_rows(r), "export").get("none", {}) if c["kind"] == "cop" else {}
            if c["kind"] == "cop":
                row["bits_per_example"] = none.get("bits_per_example")
                bw = none.get("bits_per_example_with_adapters")
                row["bits_per_example_with_adapters"] = bw if bw is not None else row["bits_per_example"]
            # f0: its own endpoint (architecture, metrics) for the compact flag and the C0 reference
            if f0 not in f0_cache:
                f0r = runs.get(f0)
                f0ep = _endpoint_record(f0r) if f0r and f0r["status"]["status"] == "complete" else None
                f0_cache[f0] = (f0ep, _stage_metrics(_rows(f0r), "endpoint") if f0ep else {})
            f0ep, f0m = f0_cache[f0]
            row["contraction_mechanism"] = contraction_mechanism(c)
            row.update(_expanded_state(runs, c, task, r["dir"]))
            row.update(_witness_of(runs, f0, task))
            row["f0_architecture_hash"] = f0ep["architecture_hash"] if f0ep else None
            row["compact"] = bool(f0ep) and ep["architecture_hash"] == f0ep["architecture_hash"]
            # C0 = the f0 state the chain actually started from: the fixed-budget baseline endpoint, or (v13)
            # the baseline's validation-selected endpoint; snapshot starts (snap_<u>) have no C0
            st0 = _f0_stage(runs, rid)
            ref_ep, ref_m = (f0ep, f0m) if st0 == "baseline" else (None, {})
            if st0 == "best_val" and f0 in runs:
                pb = runs[f0]["dir"] / "endpoint_best_val.json"
                ebv = read_json(pb) if pb.exists() else None
                if ebv and ebv.get("checkpoint"):
                    ref_ep, ref_m = ebv, _stage_metrics(_rows(runs[f0]), "endpoint_best_val")
            if st0 not in ("baseline", "best_val"):
                ref_ep = None
            if ref_ep and ref_ep.get("numerically_valid"):
                for p in ("test", "rare", "shift"):
                    mp = ref_m.get(p, {})
                    if mp:
                        row[f"f0_{p}_risk"] = _risk(mp, task)
                        if "acc" in mp:
                            row[f"f0_{p}_err"] = 1.0 - mp["acc"]
            # v13: the validation-selected endpoint of this job and of its f0 (separate from the fixed endpoint)
            row.update(_selected_fields(r, task, "sel_"))
            if f0 in runs:
                row.update(_selected_fields(runs[f0], task, "f0_sel_"))
            w = post_f0_work(runs, rid)
            row.update({f"post_f0_{k}": v for k, v in w.items()})
            row.update(cost_parts(runs, rid))
            row["compute_complete"] = bool(w.get("macs_complete", True)) and bool(w.get("accounting_complete", True))
            tmacs = w["macs"] + w["teacher_macs"]
            if c["kind"] == "continue" and c["continue"]["arm"] == "distill":
                t = (c.get("parents") or {}).get(c["continue"]["teacher"])
                tw = post_f0_work(runs, t) if t else None
                if tw:
                    tmacs += tw["macs"] + tw["teacher_macs"]
                    row["compute_complete"] = row["compute_complete"] and bool(tw.get("macs_complete", True))
            row["post_f0_macs_incl_teacher"] = tmacs
            # controls whose budget adds f0's own budget (M1 / M2, the cycles direct_small control) train a
            # fresh model for f0 + chain exposure; their cost compares with the treated chain PLUS f0
            cc_ = c.get("continue") or {}
            row["includes_f0_budget"] = bool(cc_.get("budget_add_f0")) or (
                c["kind"] == "cop" and (c.get("cop") or {}).get("task_kind") == "baseline"
                and "cycles" in (c.get("parents") or {}))
            # v13 (audit A2): f0's own training cost, from its ledger / checkpoint counters / inline baseline_ref
            fw = f0_cost(runs, rid)
            row["f0_train_macs"] = int(fw["macs"] + fw["teacher_macs"])
            row["f0_train_updates"] = int(fw["updates"])
            row["f0_compute_complete"] = bool(fw.get("macs_complete", False))
            row["f0_cost_provenance"] = fw.get("provenance")
            # explicit cost split: baseline pretraining, post-baseline work, total procedure
            # no baseline term for a scratch control (its budget already holds the f0 updates) or for a history
            # trained from random initialisation (it never used f0's training)
            no_f0 = row["includes_f0_budget"] or _from_scratch_history(runs, rid)
            row["history_from_scratch"] = bool(no_f0 and not row["includes_f0_budget"])
            row["consumes_trained_f0"] = not no_f0
            row["baseline_macs"] = 0 if no_f0 else row["f0_train_macs"]
            # v13: validation-selection evaluations (this job's, and f0's when f0 was selected), forward only
            from ..experiments.continuation import search_work
            sw = search_work(r["dir"])["macs"]
            f0sw = 0
            if not no_f0 and f0 in runs and _f0_stage(runs, rid) == "best_val":
                f0sw = search_work(runs[f0]["dir"])["macs"]
            row["f0_search_macs"] = int(f0sw)                     # shared by every descendant of the selected f0
            row["search_macs"] = int(sw + f0sw)
            row["total_procedure_macs"] = row["post_f0_macs_incl_teacher"] + row["baseline_macs"] + row["search_macs"]
            row["total_procedure_complete"] = row["compute_complete"] and (no_f0 or row["f0_compute_complete"])
        row["eligibility_reasons"] = "; ".join(reasons)
        row["eligible"] = not reasons
        out.append(row)
    return out


def _boot(xs: list[float], n: int = 2000, seed: int = 0) -> tuple[Optional[float], Optional[float]]:
    if len(xs) < 2:
        return None, None
    rnd = random.Random(seed)
    ms = sorted(sum(rnd.choice(xs) for _ in xs) / len(xs) for _ in range(n))
    return ms[int(0.025 * n)], ms[int(0.975 * n) - 1]


def _numerically_ok(e: dict, metric: str) -> tuple[bool, str]:
    if e.get("status", "complete") != "complete":
        return False, f"status {e.get('status')}"
    if e.get("validity") not in (None, "valid"):
        return False, f"validity {e.get('validity')}"
    if e.get("diverged"):
        return False, "diverged"
    if e.get("eligible") is False:
        return False, e.get("eligibility_reasons") or "ineligible"
    v = e.get(metric)
    if v is None:
        return False, f"no {metric}"
    if not math.isfinite(float(v)):
        return False, f"non-finite {metric}"
    return True, ""


def _parse_rep(rk: str) -> tuple[Optional[str], Optional[str]]:
    """(draw, optimizer seed) of a replication key data<d>_teacher<t>_opt<o>; the draw is the data / teacher pair."""
    import re
    m = re.match(r"data(.+?)_teacher(.+?)_opt(.+?)(?:_part(.+))?$", str(rk))
    if not m:
        return str(rk), None
    # within-draw seed label: the optimizer seed, plus the partition seed when one was set explicitly (v17);
    # the primary analysis takes optimizer seed 0 with the default partition only
    return f"{m.group(1)}/{m.group(2)}", m.group(3) + (f"/part{m.group(4)}" if m.group(4) is not None else "")


def draw_level(reps_g: list[tuple[str, float]], primary_opt: str = "0") -> dict:
    """v15 replication hierarchy: data / teacher draws are the independent units; optimizer seeds within a draw
    are not.  primary_*: one paired effect per draw at optimizer seed `primary_opt` (the confirmation's primary
    analysis), mean and percentile bootstrap over draws.  pooled_*: effects averaged within each draw over its
    optimizer seeds, then over draws (each draw weighted once).  within_draw_sd: the mean over crossed draws of
    the SD of the effect across optimizer seeds.  With few draws the intervals are wide; report them as such."""
    by = defaultdict(dict)
    for rk, g in reps_g:
        d, o = _parse_rep(rk)
        by[d][o] = g
    prim = [v[primary_opt] for v in by.values() if primary_opt in v]
    pooled = [sum(v.values()) / len(v) for v in by.values()]
    sds = []
    for v in by.values():
        if len(v) > 1:
            m = sum(v.values()) / len(v)
            sds.append((sum((x - m) ** 2 for x in v.values()) / (len(v) - 1)) ** 0.5)
    plo, phi = _boot(prim) if len(prim) > 1 else (None, None)
    qlo, qhi = _boot(pooled) if len(pooled) > 1 else (None, None)
    return {"n_draws": len(by), "n_draws_primary": len(prim),
            "primary_G_mean": sum(prim) / len(prim) if prim else None, "primary_G_ci_lo": plo, "primary_G_ci_hi": phi,
            "primary_n_positive": sum(1 for x in prim if x > 0),
            "pooled_draw_G_mean": sum(pooled) / len(pooled) if pooled else None,
            "pooled_draw_G_ci_lo": qlo, "pooled_draw_G_ci_hi": qhi,
            "n_crossed_draws": len(sds), "within_draw_sd_over_optimizer_seeds": (sum(sds) / len(sds)) if sds else None}


def classify_pair(t: dict, c: dict) -> tuple[Optional[str], str]:
    """(estimand, reason): None when the two endpoints are not comparable at all."""
    for k in ("f0_run", "data_identity", "model_identity", "data", "model", "design_target_regime"):
        if t.get(k) is not None and c.get(k) is not None and t[k] != c[k]:
            return None, f"incompatible {k}"
    ta, ca, fa = t.get("architecture_hash"), c.get("architecture_hash"), t.get("f0_architecture_hash")
    if ta is not None and ca is not None:
        if ta != ca:
            return "cost_frontier", "endpoint architectures differ"
        if fa is not None:
            return ("fixed_architecture" if ta == fa else "matched_endpoint"), ""
        return ("fixed_architecture" if t.get("compact") is True and c.get("compact") is True
                else "matched_endpoint"), ""
    # no architecture records (hand-built rows): the compact flags decide
    if t.get("compact") is True and c.get("compact") is True:
        return "fixed_architecture", ""
    return "cost_frontier", "not both compact"


def compact_gain(E: list[dict], metric: str = "test_risk", estimand: str = "fixed_architecture",
                 strict: bool = True, rejected: Optional[list] = None) -> tuple[list[dict], list[dict]]:
    """Paired G = R(control) - R(treated) for one estimand.  Returns (summary rows, pairs).
    strict: a duplicated pairing key raises ValueError; otherwise every entry of that key is
    excluded and recorded in `rejected` (as is every incompatible or ineligible pairing)."""
    if estimand not in ESTIMANDS:
        raise ValueError(estimand)
    rej = rejected if rejected is not None else []
    keyed = defaultdict(list)
    for e in E:
        if not e.get("design_contrast"):
            continue
        # v13: the f0 STATE is part of the pairing identity (fixed-budget f0 or the validation-selected f0):
        # paired descendants must start from the same full baseline checkpoint
        key = (e["design_contrast"], f"{e.get('f0_run') or ''}@{e.get('f0_stage') or 'baseline'}", e["design_arm"],
               e["replication"], e.get("design_budget_panel", ""))
        keyed[key].append(e)
        if e["design_arm"] == "treated" and e.get("kind") != "continue" and e.get(f"f0_{metric}") is not None:
            # C0: f0 with no further training (its own endpoint evaluation)
            c0 = {"run_id": e.get("f0_run") or "f0", "kind": "baseline", "status": "complete", "validity": "valid",
                  "design_contrast": e["design_contrast"], "design_arm": "C0", "replication": e["replication"],
                  "design_budget_panel": "none", metric: e[f"f0_{metric}"], "compact": True,
                  "architecture_hash": e.get("f0_architecture_hash"), "f0_architecture_hash": e.get("f0_architecture_hash"),
                  "post_f0_macs": 0, "post_f0_macs_incl_teacher": 0, "compute_complete": True,
                  "baseline_macs": e.get("f0_train_macs"), "total_procedure_macs": e.get("f0_train_macs"),
                  "total_procedure_complete": bool(e.get("f0_compute_complete")),
                  "f0_train_macs": e.get("f0_train_macs"), "f0_compute_complete": e.get("f0_compute_complete")}
            for k in ("f0_run", "data_identity", "model_identity", "data", "model", "design_target_regime"):
                if k in e:
                    c0[k] = e[k]
            keyed[(e["design_contrast"], f"{e.get('f0_run') or ''}@{e.get('f0_stage') or 'baseline'}", "C0",
                   e["replication"], "none")].append(c0)
    dup = {k: v for k, v in keyed.items() if len(v) > 1}
    if dup and strict:
        k0 = next(iter(dup))
        raise ValueError(f"{len(dup)} duplicated pairing keys, e.g. {k0}: {[x['run_id'] for x in dup[k0]]}")
    for k, v in dup.items():
        for x in v:
            rej.append({"run_id": x["run_id"], "key": list(k), "reason": "duplicated pairing key"})
    # v15: a summary pools every replication of a contrast (each replication has its own f0 run); a PAIR is formed
    # only within one (f0 run @ stage, replication), so treated and control always share their baseline state
    groups = defaultdict(lambda: defaultdict(dict))        # (contrast, f0 stage) -> arm -> (f0@stage, rep) -> entry
    expected = defaultdict(lambda: defaultdict(set))
    excl = defaultdict(lambda: defaultdict(lambda: defaultdict(int)))
    for k, v in keyed.items():
        if k in dup:
            continue
        e = v[0]
        g = (k[0], k[1].rsplit("@", 1)[-1])
        unit = (k[1], k[3])
        expected[g][k[2]].add(unit)
        ok, why = _numerically_ok(e, metric)
        if not ok:
            excl[g][k[2]]["diverged" if why == "diverged" else "ineligible"] += 1
            rej.append({"run_id": e["run_id"], "key": list(k), "reason": why})
            continue
        groups[g][k[2]][unit] = e
    pairs, summ = [], []
    for g in sorted(set(groups) | set(expected)):
        con, f0_stage = g
        arms = groups.get(g, {})
        tr = arms.get("treated", {})
        for arm in sorted(set(expected[g]) - {"treated"}):
            reps = arms.get(arm, {})
            gs, panel = [], ""
            reps_g = []
            n_wrong = 0
            for unit in sorted(set(tr) & set(reps)):
                t, cc = tr[unit], reps[unit]
                f0, rk = unit
                panel = cc.get("design_budget_panel", "")
                est, why = classify_pair(t, cc)
                if est != estimand:
                    if est is None:
                        rej.append({"run_id": cc["run_id"], "treated_run": t["run_id"], "reason": why})
                    n_wrong += 1
                    continue
                gv = cc[metric] - t[metric]
                gs.append(gv)
                reps_g.append((rk, gv))
                pairs.append({"contrast": con, "f0_run": f0, "estimand": estimand, "budget_panel": panel,
                              "control_arm": arm, "replication": rk,
                              "comparison": "treatment_variant" if arm.startswith("treated") else "control", "treated_run": t["run_id"],
                              "control_run": cc["run_id"], "G": gv, "treated_risk": t[metric],
                              "control_risk": cc[metric], "task": t.get("task"), "data": t.get("data"),
                              "treated_post_f0_macs": t.get("post_f0_macs"),
                              "control_post_f0_macs": cc.get("post_f0_macs"),
                              "treated_macs_incl_teacher": t.get("post_f0_macs_incl_teacher"),
                              # the treated cost the control's budget was matched to (adds f0 for M1 / M2)
                              "treated_cost_matched": (None if t.get("post_f0_macs_incl_teacher") is None else
                                                       t["post_f0_macs_incl_teacher"] + (
                                                           int(t.get("f0_train_macs") or 0)
                                                           if cc.get("includes_f0_budget") else 0)),
                              "control_includes_f0_budget": bool(cc.get("includes_f0_budget")),
                              # v13: explicit baseline / total-procedure costs (baseline counted exactly once)
                              "treated_baseline_macs": t.get("baseline_macs"),
                              "control_baseline_macs": cc.get("baseline_macs"),
                              "treated_total_procedure_macs": t.get("total_procedure_macs"),
                              "control_total_procedure_macs": cc.get("total_procedure_macs"),
                              "total_procedure_complete": bool(t.get("total_procedure_complete")) and
                              bool(cc.get("total_procedure_complete")),
                              "f0_cost_provenance": t.get("f0_cost_provenance"),
                              "control_macs_incl_teacher": cc.get("post_f0_macs_incl_teacher", cc.get("post_f0_macs")),
                              "compute_complete": bool(t.get("compute_complete", True)) and
                              bool(cc.get("compute_complete", True)),
                              "treated_params": t.get("endpoint_params"), "control_params": cc.get("endpoint_params"),
                              "variant": t.get("design_variant"), "family": t.get("design_family")})
            if not gs and not n_wrong and not reps and not excl[g][arm]:
                continue
            if not gs and n_wrong and not excl[g][arm]:
                continue                                  # this arm belongs to another estimand's table
            lo, hi = _boot(gs)
            v = next(iter(tr.values()), {})
            summ.append({"contrast": con, "f0_run": f"per replication @{f0_stage}", "f0_stage": f0_stage,
                         "estimand": estimand, "budget_panel": panel,
                         "comparison": "treatment_variant" if arm.startswith("treated") else "control",
                         "control_arm": arm, "family": v.get("design_family"), "variant": v.get("design_variant"),
                         "task": v.get("task"), "target_regime": v.get("design_target_regime"), "metric": metric,
                         "n_expected": len(expected[g][arm] | expected[g]["treated"]),
                         "n_treated_eligible": len(tr), "n_control_eligible": len(reps),
                         "n_treated_diverged": excl[g]["treated"]["diverged"],
                         "n_control_diverged": excl[g][arm]["diverged"],
                         "n_treated_ineligible": excl[g]["treated"]["ineligible"],
                         "n_control_ineligible": excl[g][arm]["ineligible"],
                         "n_unmatched": len(set(tr) ^ set(reps)), "n_pairs": len(gs),
                         "G_mean": sum(gs) / len(gs) if gs else None, "G_ci_lo": lo, "G_ci_hi": hi,
                         "interval": "exploratory percentile bootstrap over replications (not independent when "
                                     "optimizer seeds share a draw; see primary_* / pooled_draw_*)",
                         **draw_level(reps_g)})
    return summ, pairs


def cycle_table(runs: dict) -> list[dict]:
    """Per-cycle rows of grow/contract trajectories: contraction info, risk on every partition."""
    out = []
    for rid, r in runs.items():
        c = r["cfg"]
        if c["kind"] != "trajectory" or not int(c["growth"].get("contract_every", 0) or 0) or \
                r["status"]["status"] != "complete":
            continue
        rows = _rows(r)
        cyc = sorted({x["stage"] for x in rows if x["stage"].startswith("cycle_")}, key=lambda s: int(s.split("_")[1]))
        for s in cyc:
            m = _stage_metrics(rows, s)
            row = {"run_id": rid, "cycle": int(s.split("_")[1]), "variant": (c.get("design") or {}).get("variant"),
                   "contrast": (c.get("design") or {}).get("contrast"), "topology": c["growth"]["topology"],
                   "contract_method": c["growth"]["contract_method"], "cycle_cut": c["growth"]["cycle_cut"],
                   "replication": _rk(c)}
            for k, v in m.get("val", {}).items():
                if k.startswith("contraction."):
                    row[k] = v
            for p in PARTS:
                mp = m.get(p, {})
                if mp:
                    row[f"{p}_risk"] = mp.get("mse", mp.get("loss"))
                    if "acc" in mp:
                        row[f"{p}_err"] = 1 - mp["acc"]
            out.append(row)
    return out


def _collect(runs, name):
    from .summarize import collect_json
    return collect_json(runs, name)


def repair_scope_table(runs: dict) -> list[dict]:
    out = []
    for r, j in _collect(runs, "repair_result.json"):
        sc = j.get("repair_graph_distance") or {}
        out.append({"run_id": r["run_id"], "region": j["region"], "data_access": j.get("data_access"),
                    "opt_state": j.get("opt_state"), "n_trainable": j["n_trainable"], "scope_max": sc.get("max"),
                    "scope_mean": sc.get("mean"), "termination_reason": j.get("termination_reason"),
                    "variant": (r["cfg"].get("design") or {}).get("variant"), "updates_done": j["updates_done"]})
    return out


def repair_curves(runs: dict) -> list[dict]:
    out = []
    for r, j in _collect(runs, "repair_result.json"):
        for row in j.get("curve", []):
            out.append({"run_id": r["run_id"], "region": j["region"], "update": row["update"],
                        **{k: v for k, v in row.items() if k != "update" and isinstance(v, (int, float))}})
    for r, j in _collect(runs, "dissipation_result.json"):
        for p in j.get("path", []):
            out.append({"run_id": r["run_id"], "region": "dissipation:" + j["method"], "update": p.get("update"),
                        "val.risk": p.get("val_risk")})
    return out


def transplant_table(runs: dict) -> list[dict]:
    out = []
    for r, j in _collect(runs, "transplant_result.json"):
        if j["info"].get("design") == "grid":
            continue                                   # v5 grid jobs: s_transplant_grid.csv
        for name, parts in j["rows"].items():
            m = parts.get("test", {})
            out.append({"run_id": r["run_id"], "row": name, "cut": j["info"]["cut"], "align": j["info"]["align"],
                        "test_risk": m.get("mse", m.get("loss")), "test_err": (1 - m["acc"]) if "acc" in m else None,
                        "variant": (r["cfg"].get("design") or {}).get("variant")})
    return out


def cop_extension_table(runs: dict) -> list[dict]:
    out = []
    for r, j in _collect(runs, "cop_chain_result.json"):
        c = r["cfg"]
        ex = j["export"]
        row = {"run_id": r["run_id"], "variant": (c.get("design") or {}).get("variant"),
               "temp_channel": c["peg"]["temp_channel"], "temp_target": c["peg"]["temp_target"],
               "temp_on": c["peg"]["temp_on"], "temp_open_updates": c["peg"]["temp_open_updates"],
               "redundancy": c["peg"]["redundancy"], "route_dropout": c["peg"]["route_dropout"],
               "bits_per_example": ex["bits_per_example_total"],
               "bits_with_adapters": ex.get("bits_per_example_with_adapters", ex["bits_per_example_total"]),
               "adapter_params": ex.get("adapter_params", 0), "export_params": ex["params"],
               "any_bypass": any(v.get("has_bypass") for v in ex["bypass"].values()),
               "test_risk": ex["test"].get("mse", ex["test"].get("loss"))}
        rd = j.get("route_damage") or {}
        if rd:
            worst = [max(rr["impute"]["test"] for rr in v["rows"]) - v["base"]["test"] for v in rd.values()
                     if "test" in v["base"]]
            row["worst_route_loss_damage_test"] = max(worst) if worst else None
        rr = j.get("route_repair")
        if rr:
            row.update({"route_removed_test": rr["immediate"].get("test"), "route_repaired_test": rr["repaired"].get("test"),
                        "bits_after_route_removal": rr["bits_per_example_after"]})
        lq = j.get("later_queries")
        if lq:
            row["later_query_input_reaccess_test"] = sum(lq["input_reaccess"]["test"]) / lq["queries"]
            row["later_query_chance_test"] = sum(lq["chance"]["test"]) / lq["queries"]
            for pid, v in lq["pegs"].items():
                row[f"later_query_{pid}_test"] = sum(v["test"]) / lq["queries"]
        out.append(row)
    return out


def summarize_strengthening(runs: dict, out: Path) -> dict:
    """Every table is written per ESTIMAND; eligibility records list every endpoint with its
    reasons and every rejected pairing (duplicate key, incompatible contract, ineligible numerics)."""
    from .summarize import _write_csv
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    E = endpoint_table(runs)
    _write_csv(out / "s_endpoints.csv", E)
    elig = [{k: e.get(k) for k in ("run_id", "kind", "status", "validity", "design_family", "design_variant",
                                   "design_arm", "design_contrast", "replication", "f0_run", "endpoint_checkpoint",
                                   "endpoint_updates", "diverged", "architecture_hash", "f0_architecture_hash",
                                   "compact", "compute_complete", "eligible", "eligibility_reasons")} for e in E]
    _write_csv(out / "s_endpoint_eligibility.csv", elig)
    atomic_write_json(out / "s_endpoint_eligibility.json", elig)
    tabs, pairs_by = {}, {}
    rejected: list = []
    for est in ESTIMANDS:
        for metric in ("test_risk", "test_err", "rare_risk", "shift_risk", "test_teacher_imitation_mse",
                       "test_teacher_imitation_kl"):
            rj: list = []
            summ, pairs = compact_gain(E, metric, est, strict=False, rejected=rj)
            if metric == "test_risk":
                rejected += [dict(r, estimand=est) for r in rj]
            pairs_by[(est, metric)] = pairs
            if summ:
                _write_csv(out / f"s_{est}_{metric}.csv", summ)
                _write_csv(out / f"s_{est}_pairs_{metric}.csv", pairs)
                tabs[(est, metric)] = summ
    # v13: analysis (ii) tables, validation-selected endpoints, kept apart from the fixed-budget tables above
    sel_counts = {}
    for est in ("fixed_architecture", "matched_endpoint"):
        for fb in ((True, False) if est == "fixed_architecture" else (False,)):
            for metric in ("test_risk", "test_err", "rare_risk", "shift_risk"):
                rj: list = []
                summ, pairs = selected_gain(E, metric, est, fb, rejected=rj)
                tag = f"s_selected_{est}{'_f0fallback' if fb else ''}_{metric}"
                if summ:
                    _write_csv(out / f"{tag}.csv", summ)
                    _write_csv(out / f"{tag.replace('s_selected_', 's_selected_pairs_')}.csv", pairs)
                if metric == "test_risk":
                    _write_csv(out / f"{tag}_rejected.csv", rj)
                    sel_counts[tag] = {"rows": len(summ), "pairs": len(pairs), "rejected": len(rj)}
    # one record per rejected pairing / entry (they are identical across estimands for entry-level reasons)
    seen, rej_u = set(), []
    for r in rejected:
        k = (r.get("run_id"), r.get("treated_run"), r.get("reason"))
        if k not in seen:
            seen.add(k)
            rej_u.append({k_: (json.dumps(v) if isinstance(v, list) else v) for k_, v in r.items()})
    _write_csv(out / "s_rejected.csv", rej_u)
    atomic_write_json(out / "s_rejected.json", rej_u)
    CY = cycle_table(runs)
    RS = repair_scope_table(runs)
    RC = repair_curves(runs)
    TP = transplant_table(runs)
    CO = cop_extension_table(runs)
    # every per-run table carries its task (figures facet by it) and the run's endpoint validity
    tcache: dict = {}
    for tab in (CY, RS, RC, TP, CO):
        for row in tab:
            row["task"] = _run_task(runs, row["run_id"], tcache)
            ep = _endpoint_record(runs[row["run_id"]]) if row["run_id"] in runs else None
            row["endpoint_numerically_valid"] = None if ep is None else bool(ep.get("numerically_valid"))
    for n, t in (("s_cycles", CY), ("s_repair_scope", RS), ("s_repair_curves", RC), ("s_transplants", TP),
                 ("s_cop_extension", CO)):
        _write_csv(out / f"{n}.csv", t)
    untested = sorted({(e["design_family"], e["design_variant"], e["design_arm"],
                        e["eligibility_reasons"] or "eligible") for e in E if not e["eligible"]})
    atomic_write_json(out / "s_untested_or_ineligible_cells.json", [list(u) for u in untested])
    counts = {"n_design_runs": len(E), "n_complete": sum(e["status"] == "complete" for e in E),
              "selected_tables": sel_counts,
              "n_eligible": sum(bool(e["eligible"]) for e in E),
              "n_diverged": sum(bool(e.get("diverged")) for e in E),
              "n_ineligible": sum(not e["eligible"] for e in E),
              "n_compute_incomplete": sum(e.get("compute_complete") is False for e in E),
              "n_rejected_records": len(rej_u)}
    from .v5_tables import write_v5_tables
    from .v13_tables import write_v13_tables
    v5 = write_v5_tables(runs, E, out)
    try:
        counts["v13_tables"] = write_v13_tables(runs, E, out)
    except Exception as ex:                                      # noqa: BLE001  recorded, other tables stand
        import traceback
        counts["v13_tables_error"] = f"{type(ex).__name__}: {ex}"
        (out / "v13_tables_ERROR.txt").write_text(traceback.format_exc())
    v5_t = v5.pop("tables")
    figs, fig_errors = [], {}
    for name, fn in (("strengthening_figures",
                      lambda: make_strengthening_figures(out, E, tabs, CY, RS, RC, TP, CO, untested, pairs_by, counts)),
                     ("v5_figures", lambda: make_v5_figures(out, v5_t))):
        try:
            figs += fn()
        except Exception as ex:                                  # noqa: BLE001  tables are already written
            import traceback
            import matplotlib.pyplot as plt
            plt.close("all")
            fig_errors[name] = f"{type(ex).__name__}: {ex}"
            (out / f"{name}_ERROR.txt").write_text(traceback.format_exc())
    res = {**counts, **v5, **{f"n_{est}_rows": len(tabs.get((est, "test_risk"), [])) for est in ESTIMANDS},
           "n_cycle_rows": len(CY), "figures": figs, "figure_errors": fig_errors,
           "note": "exploratory screening summaries; confirmation needs held-out seeds"}
    atomic_write_json(out / "s_summary.json", res)
    return res


def make_strengthening_figures(out: Path, E, tabs, CY, RS, RC, TP, CO, untested, pairs_by, counts) -> list[str]:
    """Overview figures.  Facets never mix tasks (MSE vs cross-entropy) or estimands; parameters and
    MACs never share an axis; every figure shows all eligible rows (no truncation) and its counts."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    figs = []

    def save(fig, name):
        p = out / name
        fig.tight_layout()
        fig.savefig(p, dpi=110)
        plt.close(fig)
        figs.append(str(p))

    def empty(name, title):
        fig, ax = plt.subplots(figsize=(6, 3))
        ax.text(0.5, 0.5, "no eligible rows for this figure", ha="center", va="center")
        ax.set_title(title)
        ax.axis("off")
        save(fig, name)

    cnt = (f"{counts['n_eligible']} eligible of {counts['n_design_runs']} design jobs; "
           f"{counts['n_diverged']} diverged; {counts['n_compute_incomplete']} with incomplete compute")
    # 1. gain against relative compute, one panel per (estimand, task); incomplete-compute pairs excluded
    arms1 = ("C1", "C1_lr0.3", "C1_lr3.0", "C2", "C3", "C4", "C5", "M1", "M2")
    for est in ("fixed_architecture", "matched_endpoint"):
        P = [q for q in pairs_by.get((est, "test_risk"), []) if q["control_arm"] in arms1]
        tasks = sorted({q["task"] for q in P if q.get("task")})
        name = f"s_fig1_gain_vs_compute_{est}.png"
        if not P:
            empty(name, f"Fig 1 ({est})")
            continue
        fig, axs = plt.subplots(1, len(tasks), figsize=(6.5 * len(tasks), 4.6), squeeze=False)
        for ax, task in zip(axs[0], tasks):
            q_all = [q for q in P if q["task"] == task]
            q_ok = [q for q in q_all if q["compute_complete"] and q.get("treated_cost_matched")]
            for a in arms1:
                q = [x for x in q_ok if x["control_arm"] == a]
                if q:
                    ax.scatter([max(1e-3, (x["control_macs_incl_teacher"] or 0) / x["treated_cost_matched"])
                                for x in q], [x["G"] for x in q], s=11, alpha=0.7, label=f"{a} (n={len(q)})")
            ax.set_xscale("log")
            ax.axhline(0, color="k", lw=0.6)
            ax.axvline(1, color="0.5", lw=0.6, ls="--")
            ax.set_xlabel("control / treated estimated training MACs (teacher forwards and chain included; "
                          "f0 added for M1 / M2)", fontsize=8)
            ax.set_ylabel("G = R(control) - R(treated), test " + ("MSE" if task == "regression" else "cross-entropy"))
            ax.set_title(f"{task}: {len(q_ok)} pairs plotted, {len(q_all) - len(q_ok)} without complete compute",
                         fontsize=9)
            ax.legend(fontsize=7)
        fig.suptitle(f"Fig 1: compact gain against compute, {est} (exploratory). {cnt}", fontsize=9)
        save(fig, name)
    # 2. immediate damage and repair / contraction curves: every curve, one panel per (task, kind);
    #    numerically invalid endpoints are left out and counted
    if RC:
        kinds = sorted({("dissipation" if str(r["region"]).startswith("dissipation") else "repair") for r in RC})
        tasks2 = sorted({r["task"] for r in RC if r.get("task")})
        fig, axs = plt.subplots(len(tasks2), len(kinds), figsize=(6 * len(kinds), 4 * len(tasks2)), squeeze=False)
        for ti, task in enumerate(tasks2):
            for ax, kd in zip(axs[ti], kinds):
                by, bad = defaultdict(list), set()
                for r in RC:
                    if r.get("task") != task or \
                            ("dissipation" if str(r["region"]).startswith("dissipation") else "repair") != kd:
                        continue
                    if r.get("endpoint_numerically_valid") is False:
                        bad.add(r["run_id"])
                        continue
                    v = r.get("val.risk")
                    if v is not None and r.get("update") is not None and math.isfinite(float(v)):
                        by[r["run_id"]].append((r["update"], v))
                for rid, xs in by.items():
                    xs.sort()
                    ax.plot([x[0] for x in xs], [x[1] for x in xs], lw=0.6, alpha=0.6)
                ax.set_yscale("log")
                ax.set_xlabel("updates after removal" if kd == "repair" else "updates during contraction")
                ax.set_ylabel(f"val {'MSE' if task == 'regression' else 'cross-entropy'} (log scale)")
                ax.set_title(f"{task}, {kd}: {len(by)} runs; {len(bad)} numerically invalid left out", fontsize=9)
        fig.suptitle("Fig 2: immediate damage and repair curves", fontsize=9)
        save(fig, "s_fig2_damage_repair.png")
    else:
        empty("s_fig2_damage_repair.png", "Fig 2")
    # 3. repair scope: graph distance and trainable parameters
    pts = [r for r in RS if r.get("scope_max") is not None]
    if pts:
        fig, ax = plt.subplots(figsize=(6.5, 4.5))
        for reg in sorted({r["region"] for r in pts}):
            q = [r for r in pts if r["region"] == reg]
            ax.scatter([r["n_trainable"] for r in q], [r["scope_max"] for r in q], s=16, label=f"{reg} (n={len(q)})")
        ax.set_xscale("log")
        ax.set_xlabel("trainable parameters during repair")
        ax.set_ylabel("max graph distance of trained modules from the deletion site")
        ax.set_title("Fig 3: repair scope (two coordinates)")
        ax.legend(fontsize=7)
        save(fig, "s_fig3_repair_scope.png")
    else:
        empty("s_fig3_repair_scope.png", "Fig 3")
    # 4. risk and rare-case risk across cycles, one row of panels per task; invalid endpoints left out
    if CY:
        tasks4 = sorted({r["task"] for r in CY if r.get("task")})
        fig, axs = plt.subplots(len(tasks4), 2, figsize=(10, 4 * len(tasks4)), squeeze=False)
        for ti, task in enumerate(tasks4):
            by, bad = defaultdict(list), set()
            for r in CY:
                if r.get("task") != task:
                    continue
                if r.get("endpoint_numerically_valid") is False:
                    bad.add(r["run_id"])
                    continue
                by[r["run_id"]].append(r)
            for rid, xs in by.items():
                xs.sort(key=lambda r: r["cycle"])
                axs[ti][0].plot([r["cycle"] for r in xs], [r.get("test_risk") for r in xs], marker="o", lw=0.7)
                if any(r.get("rare_risk") is not None for r in xs):
                    axs[ti][1].plot([r["cycle"] for r in xs], [r.get("rare_risk") for r in xs], marker="o", lw=0.7)
            unit = "MSE" if task == "regression" else "cross-entropy"
            axs[ti][0].set_title(f"Fig 4a ({task}): test {unit} after each contraction; {len(by)} histories, "
                                 f"{len(bad)} invalid left out", fontsize=9)
            axs[ti][1].set_title(f"Fig 4b ({task}): rare-case {unit} (shortcut data only)", fontsize=9)
            for a in axs[ti]:
                a.set_xlabel("cycle")
                a.set_yscale("log")
        save(fig, "s_fig4_cycles.png")
    else:
        empty("s_fig4_cycles.png", "Fig 4")
    # 5. two-factor boundary: sample size x target complexity, fixed-architecture G vs C2, untested marked
    import re
    pat = re.compile(r"size_complexity_n(\d+)_d(\d+)$")
    expected = defaultdict(set)
    for e in E:
        m = pat.search(str(e.get("design_contrast") or ""))
        if m and e.get("design_arm") == "treated":
            expected[e["design_variant"]].add((int(m.group(1)), int(m.group(2))))
    got = {}
    for g in tabs.get(("fixed_architecture", "test_risk"), []):
        m = pat.search(g["contrast"])
        if m and g["control_arm"] == "C2" and g["G_mean"] is not None:
            got[(g["variant"], int(m.group(1)), int(m.group(2)))] = g
    if expected:
        vs = sorted(expected)
        fig, axs = plt.subplots(1, len(vs), figsize=(3.2 * len(vs), 3.6), squeeze=False)
        lim = max([abs(g["G_mean"]) for g in got.values()] or [1.0]) or 1.0
        for ax, v in zip(axs[0], vs):
            ns = sorted({c[0] for c in expected[v]})
            ds = sorted({c[1] for c in expected[v]})
            Mx = np.full((len(ds), len(ns)), np.nan)
            for i, d in enumerate(ds):
                for j, n in enumerate(ns):
                    g = got.get((v, n, d))
                    if g is not None:
                        Mx[i, j] = g["G_mean"]
                        ci = "" if g["G_ci_lo"] is None else f"\n[{g['G_ci_lo']:.3g}, {g['G_ci_hi']:.3g}]"
                        ax.text(j, i, f"{g['G_mean']:.3g}{ci}\n{g['n_pairs']}/{g['n_expected']} paired",
                                ha="center", va="center", fontsize=6)
                    else:
                        ax.text(j, i, "untested or\nineligible", ha="center", va="center", fontsize=6, color="0.3")
            ax.imshow(Mx, cmap="RdBu", vmin=-lim, vmax=lim, origin="lower")
            ax.set_xticks(range(len(ns)))
            ax.set_xticklabels([f"n={n}" for n in ns])
            ax.set_yticks(range(len(ds)))
            ax.set_yticklabels([f"depth {d}" for d in ds])
            ax.set_title(v)
        fig.suptitle("Fig 5: fixed-architecture G vs C2 (compute proxy matched), test MSE; exploratory", fontsize=9)
        save(fig, "s_fig5_gain_boundary.png")
    else:
        empty("s_fig5_gain_boundary.png", "Fig 5")
    # 5b. every contrast x control arm per family and estimand (blank = no eligible pair)
    for est in ESTIMANDS:
        rows = tabs.get((est, "test_risk"), [])
        for fam in sorted({g["family"] for g in rows if g.get("family")}):
            rr = [g for g in rows if g.get("family") == fam]
            cons = sorted({g["contrast"] for g in rr})
            arms = sorted({g["control_arm"] for g in rr})
            Mx = np.full((len(cons), len(arms)), np.nan)
            lab = {}
            for g in rr:
                i, j = cons.index(g["contrast"]), arms.index(g["control_arm"])
                if g["G_mean"] is not None:
                    Mx[i, j] = g["G_mean"]
                lab[(i, j)] = f"{'' if g['G_mean'] is None else format(g['G_mean'], '.2g')}\n{g['n_pairs']}/{g['n_expected']}"
            lim = np.nanmax(np.abs(Mx)) if np.isfinite(Mx).any() else 1.0
            fig, ax = plt.subplots(figsize=(1.0 * len(arms) + 4, 0.28 * len(cons) + 1.8))
            ax.imshow(Mx, cmap="RdBu", vmin=-lim, vmax=lim, aspect="auto")
            ax.set_xticks(range(len(arms)))
            ax.set_xticklabels(arms, fontsize=7, rotation=45)
            ax.set_yticks(range(len(cons)))
            ax.set_yticklabels([c.split("|", 1)[1] if "|" in c else c for c in cons], fontsize=6)
            for (i, j), t in lab.items():
                ax.text(j, i, t, ha="center", va="center", fontsize=4.5)
            ax.set_title(f"Fig 5b {fam}, {est}: G (test risk, per-contrast task units); cells: mean, paired/expected",
                         fontsize=7)
            save(fig, f"s_fig5b_{est}_{fam}.png")
    # 6. exported inference cost vs task risk: MACs and parameters on separate panels, per task
    pts = [e for e in E if e["eligible"] and e.get("test_risk") is not None]
    if pts:
        tasks = sorted({e["task"] for e in pts})
        fig, axs = plt.subplots(len(tasks), 3, figsize=(15, 4 * len(tasks)), squeeze=False)
        for row_, task in zip(axs, tasks):
            q = [e for e in pts if e["task"] == task]
            row_[0].scatter([e["endpoint_macs"] for e in q if e.get("endpoint_macs")],
                            [e["test_risk"] for e in q if e.get("endpoint_macs")], s=9)
            row_[0].set_xlabel("endpoint MACs per example")
            row_[1].scatter([e["endpoint_params"] for e in q if e.get("endpoint_params")],
                            [e["test_risk"] for e in q if e.get("endpoint_params")], s=9)
            row_[1].set_xlabel("endpoint parameters")
            cq = [r for r in CO if r.get("test_risk") is not None and r.get("task") == task
                  and r.get("endpoint_numerically_valid") is not False and r.get("bits_with_adapters") is not None]
            if cq:
                row_[2].scatter([max(1, r["bits_with_adapters"]) for r in cq], [r["test_risk"] for r in cq], s=9)
            else:
                row_[2].text(0.5, 0.5, "no CoP interface rows for this task", ha="center", va="center",
                             transform=row_[2].transAxes, fontsize=8)
            row_[2].set_xlabel("interface bits per example (adapters included; CoP jobs)", fontsize=8)
            for a in row_:
                a.set_xscale("log")
                a.set_ylabel(f"test {'MSE' if task == 'regression' else 'cross-entropy'} ({task})")
        fig.suptitle(f"Fig 6: exported inference cost against task risk. {cnt}", fontsize=9)
        save(fig, "s_fig6_cost_vs_risk.png")
    else:
        empty("s_fig6_cost_vs_risk.png", "Fig 6")
    # 7. transplants with and without alignment: every transplant job, one panel per task
    if TP:
        order = ["upstream", "downstream", "direct", "aligned", "bn_recalibrated"]
        tasks7 = sorted({r["task"] for r in TP if r.get("task")})
        fig, axs = plt.subplots(1, len(tasks7), figsize=(7 * len(tasks7), 4), squeeze=False)
        for ax, task in zip(axs[0], tasks7):
            by = defaultdict(dict)
            for r in TP:
                if r.get("task") == task:
                    by[r["run_id"]][r["row"]] = r["test_risk"]
            for rid, d in by.items():
                ax.plot(range(len(order)), [d.get(o) for o in order], marker="o", lw=0.7)
            ax.set_xticks(range(len(order)))
            ax.set_xticklabels(order, fontsize=8)
            ax.set_ylabel(f"test {'MSE' if task == 'regression' else 'cross-entropy'}")
            ax.set_yscale("log")
            ax.set_title(f"Fig 7 ({task}): cut-level transplants, {len(by)} jobs", fontsize=9)
        save(fig, "s_fig7_transplants.png")
    else:
        empty("s_fig7_transplants.png", "Fig 7")
    return figs


def make_v5_figures(out: Path, T: dict) -> list[str]:
    """Fig 8: smallest successful tested repair scope against co-adaptation checkpoint, one line per interface
    arm and replication, one panel per tolerance (censored = plotted at 5, open marker).  Fig 9: finite
    interfaces, learned / oracle / optimal error per cell (decoder-learning gap and code gap)."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    figs = []
    LO = T.get("LO") or []
    if LO:
        tols = sorted({r["tolerance"] for r in LO})
        fig, axs = plt.subplots(1, len(tols), figsize=(5 * len(tols), 3.8), squeeze=False)
        for ax, tol in zip(axs[0], tols):
            by = defaultdict(list)
            for r in LO:
                if r["tolerance"] == tol:
                    by[(r["interface"], r["replication"])].append(r)
            arms = sorted({k[0] for k in by})
            for (arm, rep), rows in sorted(by.items()):
                rows.sort(key=lambda r: r["checkpoint"])
                xs = [r["updates_at_checkpoint"] for r in rows]
                ys = [5 if r["censored"] else r["smallest_successful_tested_scope"] for r in rows]
                col = plt.cm.tab10(arms.index(arm) % 10)
                ax.plot(xs, ys, marker="o", lw=0.8, color=col, label=arm if rep == sorted(
                    k[1] for k in by if k[0] == arm)[0] else None)
                for x, y, r in zip(xs, ys, rows):
                    if r["censored"]:
                        ax.scatter([x], [y], facecolors="none", edgecolors=col, s=40)
            ax.set_yticks(range(6))
            ax.set_yticklabels(["0 none", "1 pearl", "2 +interfaces", "3 +neighbours", "4 full", "censored"], fontsize=7)
            ax.set_xlabel("updates at the co-adaptation checkpoint")
            ax.set_title(f"tolerance {tol:g}", fontsize=9)
            ax.legend(fontsize=7)
        fig.suptitle("Fig 8: smallest successful tested repair scope after replacing the middle pearl (exploratory)",
                     fontsize=9)
        fig.tight_layout()
        p = out / "s_fig8_locality.png"
        fig.savefig(p, dpi=110)
        plt.close(fig)
        figs.append(str(p))
    FI = [r for r in (T.get("FI") or []) if r.get("applicable")]
    if FI:
        fig, axs = plt.subplots(1, 2, figsize=(13, 4), squeeze=False)
        A = [r for r in FI if r["family"] == "A_direct_delayed_query"]
        Bf = [r for r in FI if r["family"] == "B_retention"]
        for ax, rows, keys, title in ((axs[0][0], A, ("e_star", "e_oracle", "e_model"), "A: direct delayed query"),
                                      (axs[0][1], Bf, ("e_later_star_unconstrained", "e_later_star_relevant",
                                                       "e_later_oracle"),
                                       "B: retention (later queries); relevant ceiling = task-preserving optimum if the "
                                       "code is task-pure,\nelse the exact frontier at its task error (blank: not "
                                       "enumerated)")):
            if not rows:
                ax.axis("off")
                continue
            rows = sorted(rows, key=lambda r: (str(r.get("task")), r["n_bits"], r["K_bits"], r["bridge"], r["run_id"]))
            labs = [f"{r.get('task') or ''} n{r['n_bits']} K{r['K_bits']}{' br' if r['bridge'] else ''}".strip()
                    for r in rows]
            for j, k in enumerate(keys):
                tot = [r.get("answers") or r.get("answers_later") for r in rows]
                if any(t is None for t in tot):
                    raise ValueError("finite-interface row without an answer count: cannot plot error rates")
                vals = [(r.get(k) if r.get(k) is not None else float("nan")) / t for r, t in zip(rows, tot)]
                ax.bar([i + 0.27 * (j - 1) for i in range(len(rows))], vals, width=0.27, label=k)
            ax.set_xticks(range(len(rows)))
            ax.set_xticklabels(labs, rotation=60, fontsize=6)
            ax.set_ylabel("error rate on the complete domain")
            ax.set_title(title, fontsize=9)
            ax.legend(fontsize=7)
        fig.suptitle("Fig 9: learned code versus the exact optimum (full-domain analysis diagnostic)", fontsize=9)
        fig.tight_layout()
        p = out / "s_fig9_finite_interfaces.png"
        fig.savefig(p, dpi=110)
        plt.close(fig)
        figs.append(str(p))
    return figs
