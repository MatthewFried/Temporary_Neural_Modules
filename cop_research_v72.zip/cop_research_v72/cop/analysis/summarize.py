"""Aggregation, coverage, paired contrasts and the twelve required figures.

Every number is recomputed from raw run files (metrics.jsonl, *_result.json,
deletions_*.json); figures are drawn from the generated tables only.  Failed,
unsupported, skipped and missing jobs stay visible in the coverage matrix and
are never silently dropped from tables (their rows carry their status).
Analysis cells: a cell is a CONDITION, identified by config.condition_id =
hash of the full logical config minus replication fields (data/teacher seed,
every seeds.* entry) and lineage (parent run ids).  Every manipulated setting
(dataset parameters such as omega, explicit widths, depth, optimizer and its
state policy, penalties, cut subsets, ...) therefore separates cells; only
replication draws are pooled.  Within a cell each replication key must be
unique (a duplicate is reported as an error, never counted twice).  The
continued baseline of a treated run must match it on data, model, train,
seeds, baseline parent, exposure and driver; mismatched pairs are excluded and
listed.  Runs whose effective status is not 'complete' (including 'invalid'
quarantined runs and 'stale' runs produced by different result-determining
code) or whose validity is not 'valid' are never pooled.
The statistical unit for paired contrasts is the replication (data/teacher
seed, optimizer seed); deletion subsets and checkpoints are repeated
measurements of one trained model and are not treated as replications.
"""
from __future__ import annotations

import csv
import json
import math
import random
from collections import defaultdict
from pathlib import Path
from typing import Optional

from ..config import condition_id, condition_view, replication_key
from ..utils import read_json, read_jsonl, atomic_write_json

PAIR_MATCH_GROWTH = ("rounds", "updates_per_round", "compute_schedule", "total_updates", "driver", "driver_strength")


def load_runs(results: Path, sem_hash: Optional[str] = None) -> dict[str, dict]:
    """Every run with its EFFECTIVE status: a complete / unsupported / invalid
    run produced by different result-determining code (semantic hash) is
    'stale' and is never pooled, unless its reuse was explicitly accepted
    (cop.cli accept-stale), which is recorded in the row."""
    from ..orchestration.runner import effective_status
    from ..utils import semantic_code_hash
    sem = sem_hash or semantic_code_hash()
    runs = {}
    for d in sorted((results / "runs").glob("*")):
        if not d.is_dir() or not (d / "config.json").exists():
            continue
        st = read_json(d / "status.json") if (d / "status.json").exists() else {"status": "pending"}
        st = dict(st)
        if st.get("status") in ("complete", "unsupported", "invalid"):
            eff = effective_status(results, d.name, sem)
            if eff != st["status"]:
                st.update({"status": eff, "status_on_disk": st["status"],
                           "reason": "produced by different result-determining code (semantic hash)"})
            prov = d / "provenance.json"
            if eff != "stale" and prov.exists() and read_json(prov).get("semantic_hash") != sem:
                st["stale_reuse_accepted"] = True
        r = {"run_id": d.name, "dir": d, "cfg": read_json(d / "config.json"), "status": st}
        if (d / "summary.json").exists():
            r["summary"] = read_json(d / "summary.json")
        runs[d.name] = r
    return runs


def metrics_of(run: dict) -> list[dict]:
    """Long-format rows, de-duplicated so a re-run stage (after a hard kill)
    contributes its LATEST attempt only."""
    rows = read_jsonl(run["dir"] / "metrics.jsonl")
    latest: dict = {}
    for r in rows:
        key = (r["stage"], r["evaluation_partition"], r["metric_name"], json.dumps(r.get("atoms")), r.get("tag"))
        latest[key] = r
    return list(latest.values())


def _get(rows, stage, part, name):
    for r in rows:
        if r["stage"] == stage and r["evaluation_partition"] == part and r["metric_name"] == name:
            return r["metric_value"]
    return None


def trajectory_table(runs: dict) -> list[dict]:
    out = []
    for rid, r in runs.items():
        c = r["cfg"]
        if c["kind"] != "trajectory":
            continue
        g, d, m = c["growth"], c["data"], c["model"]
        row = {"run_id": rid, "status": r["status"]["status"], "validity": r["status"].get("validity"),
               "condition_id": condition_id(c), "replication": replication_key(c),
               "block": c.get("block"), "wp": ",".join(c.get("wp", [])),
               "data": d["name"], "n_train": d["n_train"], "teacher_seed": d["teacher_seed"], "data_seed": d["data_seed"],
               "teacher_depth": (d.get("params") or {}).get("teacher_depth"), "label_noise": d["label_noise"],
               "target_noise": d["target_noise"], "model": m["family"], "width": m.get("width"),
               "width_mult": m.get("width_mult"), "topology": g["topology"], "schedule": g["schedule"],
               "rounds": g["rounds"], "shape": g["shape"], "cut_kind": g["cut_kind"], "cut_where": g["cut_where"],
               "channels": g["channels"], "construction": g["construction"], "tie": g["tie"], "merge": g["merge"],
               "order": g["order"], "policy": g["policy"], "driver": g["driver"], "freeze": c["train"]["freeze"],
               "optimizer": c["train"]["optimizer"], "opt_seed": c["seeds"]["optimizer"],
               "controlled": c.get("controlled"), "continued_parent": c.get("parents", {}).get("continued")}
        if row["status"] == "complete":
            rows = metrics_of(r)
            R = g["rounds"]
            fin = "final"
            for p in ("val", "test"):
                for k in ("loss", "mse", "acc"):
                    v = _get(rows, fin, p, k)
                    if v is not None:
                        row[f"{p}_{k}"] = v
                for ref in ("f0", "fc"):
                    for k in ("nmse", "js", "disagreement"):
                        v = _get(rows, fin, p, f"drift_vs_{ref}.{k}")
                        if v is not None:
                            row[f"{p}_drift_{ref}_{k}"] = v
            dl = [x for x in rows if x["stage"] == f"round_{R}" and x["metric_name"].startswith("delete[")
                  and x["metric_name"].endswith("delta_risk")]
            for p in ("val", "test"):
                vals = [x["metric_value"] for x in dl if x["evaluation_partition"] == p]
                if vals:
                    row[f"{p}_max_single_delete_delta"] = max(vals)
                    row[f"{p}_min_single_delete_delta"] = min(vals)
            row["training_quality"] = _get(rows, fin, "val", "training_quality")
            row["params"] = _get(rows, fin, "none", "params")
            row["n_atoms"] = _get(rows, fin, "none", "n_atoms")
            row["export_params"] = _get(rows, fin, "none", "export_params")
            row["graph_hash"] = (r.get("summary", {}).get("result") or {}).get("graph_hash")
            row["elapsed_seconds"] = r.get("summary", {}).get("elapsed_seconds")
        out.append(row)
    return out


def continued_mismatch(cfg: dict, fc_cfg: dict) -> list[str]:
    """Fields on which a treated run and its continued baseline must agree."""
    bad = []
    for sec in ("data", "model", "seeds"):
        if cfg.get(sec) != fc_cfg.get(sec):
            bad.append(sec)
    t, ft = dict(cfg.get("train", {})), dict(fc_cfg.get("train", {}))
    t.pop("freeze", None)
    ft.pop("freeze", None)
    if t != ft:
        bad.append("train")
    if (cfg.get("parents") or {}).get("baseline") != (fc_cfg.get("parents") or {}).get("baseline"):
        bad.append("parents.baseline")
    for k in PAIR_MATCH_GROWTH:
        if cfg["growth"].get(k) != fc_cfg["growth"].get(k):
            bad.append(f"growth.{k}")
    if fc_cfg["growth"].get("topology") != "none":
        bad.append("continued baseline topology is not 'none'")
    return bad


def paired_contrasts(table: list[dict], metric: str = "test_mse", alt_metric: str = "test_loss",
                     n_boot: int = 2000, seed: int = 0, runs: Optional[dict] = None) -> list[dict]:
    """Topology minus ITS OWN continued baseline (parents.continued, validated
    to match on data, model, train, seeds, baseline parent, exposure and driver).
    One contrast per CONDITION (condition_id); replications are the seeds.
    Hierarchical bootstrap: resample data/teacher seeds, then optimizer seeds
    within them.  Returns contrasts; pairing and duplicate-replication errors
    are attached to the first element under '__errors__' when `runs` is given
    (see paired_contrasts_report)."""
    return paired_contrasts_report(table, metric, alt_metric, n_boot, seed, runs)["contrasts"]


def paired_contrasts_report(table: list[dict], metric: str = "test_mse", alt_metric: str = "test_loss",
                            n_boot: int = 2000, seed: int = 0, runs: Optional[dict] = None) -> dict:
    by_id = {r["run_id"]: r for r in table}
    groups = defaultdict(list)
    errors = {"pairing_mismatch": [], "duplicate_replication": [], "excluded_validity": [], "excluded_stale": []}
    labels = {}
    for r in table:
        fc = by_id.get(r.get("continued_parent") or "")
        if fc is not None and "stale" in (r["status"], fc["status"]):
            errors["excluded_stale"].append({"run_id": r["run_id"], "status": r["status"],
                                             "continued": fc["run_id"], "continued_status": fc["status"]})
            continue
        if r["status"] != "complete" or fc is None or fc["status"] != "complete":
            continue
        if (r.get("validity") or "valid") != "valid" or (fc.get("validity") or "valid") != "valid":
            errors["excluded_validity"].append({"run_id": r["run_id"], "validity": r.get("validity"),
                                                "continued_validity": fc.get("validity")})
            continue
        if runs is not None:
            mm = continued_mismatch(runs[r["run_id"]]["cfg"], runs[fc["run_id"]]["cfg"])
            if mm:
                errors["pairing_mismatch"].append({"run_id": r["run_id"], "continued": fc["run_id"], "fields": mm})
                continue
        m = metric if metric in r else alt_metric
        if m not in r or m not in fc:
            continue
        rep = r["replication"]
        groups[r["condition_id"]].append((rep, r[m] - fc[m], m, r["run_id"], fc["run_id"]))
        labels[r["condition_id"]] = r
    out = []
    rng = random.Random(seed)
    for cid, diffs in groups.items():
        keys = [json.dumps(x[0], sort_keys=True) for x in diffs]
        dup = {k for k in keys if keys.count(k) > 1}
        if dup:
            errors["duplicate_replication"].append({"condition_id": cid, "replications": sorted(dup),
                                                    "run_ids": [x[3] for x, k in zip(diffs, keys) if k in dup]})
            diffs = [x for x, k in zip(diffs, keys) if k not in dup]
            if not diffs:
                continue
        vals = [x[1] for x in diffs]
        mean = sum(vals) / len(vals)
        sd = math.sqrt(sum((v - mean) ** 2 for v in vals) / (len(vals) - 1)) if len(vals) > 1 else float("nan")
        by_t = defaultdict(list)
        for rep, v, _, _, _ in diffs:
            by_t[(rep.get("data.data_seed"), rep.get("data.teacher_seed"))].append(v)
        tk = list(by_t)
        boots = []
        for _ in range(n_boot):
            samp = []
            for _t in range(len(tk)):
                vs = by_t[rng.choice(tk)]
                samp += [rng.choice(vs) for _ in vs]
            boots.append(sum(samp) / len(samp))
        boots.sort()
        lab = labels[cid]
        out.append({"condition_id": cid, "block": lab.get("block"), "topology": lab.get("topology"),
                    "data": lab.get("data"), "n_train": lab.get("n_train"), "model": lab.get("model"),
                    "width": lab.get("width"), "schedule": lab.get("schedule"), "controlled": lab.get("controlled"),
                    "metric": diffs[0][2], "n_pairs": len(vals), "n_data_teacher_seeds": len(tk),
                    "mean_diff_vs_continued": mean, "sd": sd,
                    "ci95_lo": boots[int(0.025 * n_boot)], "ci95_hi": boots[int(0.975 * n_boot) - 1],
                    "per_seed": [{"replication": rep, "diff": v, "run_id": rid, "continued": fid}
                                 for rep, v, _, rid, fid in diffs],
                    "unit": "paired replication (data/teacher seed, optimizer seed); deletion subsets are not "
                            "replications"})
    return {"contrasts": out, "errors": errors}


def condition_table(runs: dict) -> list[dict]:
    """One row per condition id: the full condition (JSON) and its replications."""
    cells = {}
    for rid, r in runs.items():
        c = r["cfg"]
        cid = condition_id(c)
        e = cells.setdefault(cid, {"condition_id": cid, "kind": c["kind"], "block": c.get("block"),
                                   "condition": json.dumps(condition_view(c), sort_keys=True), "runs": []})
        e["runs"].append({"run_id": rid, "status": r["status"]["status"], "validity": r["status"].get("validity"),
                          "replication": replication_key(c)})
    for e in cells.values():
        e["n_runs"] = len(e["runs"])
    return list(cells.values())


def coverage(runs: dict, manifests: list[str]) -> dict:
    out = {"blocks": {}, "totals": defaultdict(int), "missing_or_incomplete": []}
    for mpath in manifests:
        for e in read_jsonl(mpath):
            st = runs.get(e["run_id"], {}).get("status", {}).get("status", "pending")
            out["totals"][st] += 1
            for b in e["blocks"]:
                bb = out["blocks"].setdefault(b, defaultdict(int))
                bb[st] += 1
            if st != "complete":
                out["missing_or_incomplete"].append({"run_id": e["run_id"], "blocks": e["blocks"], "status": st,
                                                     "reason": runs.get(e["run_id"], {}).get("status", {}).get("reason")})
    out["totals"] = dict(out["totals"])
    out["blocks"] = {k: dict(v) for k, v in out["blocks"].items()}
    return out


def _write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("")
        return
    keys = sorted({k for r in rows for k in r if not isinstance(r.get(k), (list, dict))})
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k) for k in keys})


def collect_json(runs: dict, name: str) -> list[tuple[dict, dict]]:
    """Result files of COMPLETE runs only (a result file left by a run that
    later failed or was quarantined is not a result)."""
    out = []
    for r in runs.values():
        p = r["dir"] / name
        if p.exists() and r["status"]["status"] == "complete":
            out.append((r, read_json(p)))
    return out


def historical_semantic_hash(results: Path) -> str:
    """The single semantic hash that produced every completed run under RESULTS (for a historical
    remeasurement); refuses a mixed folder."""
    hs = set()
    for d in sorted((Path(results) / "runs").glob("*")):
        p = d / "provenance.json"
        if p.exists():
            h = read_json(p).get("semantic_hash")
            if h:
                hs.add(h)
    if len(hs) != 1:
        raise ValueError(f"a historical summary needs runs from one semantic hash; found {sorted(hs)}")
    return hs.pop()


def numeric_validity(results: Path, runs: dict) -> dict:
    """v13 (audit Phase 0.2): global numerical-validity counts that keep four different things apart:
    jobs whose OWN endpoint is numerically invalid (a divergent source), jobs that descend from such a
    source, incomplete contraction diagnostics (with those excluded by a source's own record listed apart),
    and multi-model jobs that have no single endpoint and so never belong in an endpoint table."""
    from .gates import run_diagnostic_rows
    own_invalid, parents = {}, {}
    for rid, r in runs.items():
        p = r["dir"] / "endpoint.json"
        if p.exists():
            ep = read_json(p)
            if ep.get("numerically_valid") is False:
                own_invalid[rid] = ep.get("numerical_reasons")
        parents[rid] = list((r["cfg"].get("parents") or {}).values())

    def invalid_ancestor(rid, seen=()):
        for q in parents.get(rid, []):
            if q in own_invalid:
                return q
            if q not in seen:
                a = invalid_ancestor(q, (*seen, q))
                if a:
                    return a
        return None
    desc = {rid: invalid_ancestor(rid) for rid in runs}
    desc = {k: v for k, v in desc.items() if v}
    inc, exc, n_rows = [], [], 0
    for rid in runs:
        n, bad, _ = run_diagnostic_rows(results, rid, exc)
        n_rows += n
        inc += bad
    multi = [rid for rid, r in runs.items() if r["cfg"]["kind"] == "transplant" or
             (r["cfg"]["kind"] == "cop" and (r["cfg"].get("cop") or {}).get("task_kind") in ("alternatives", "locality"))]
    return {"n_runs": len(runs),
            "own_endpoint_numerically_invalid": {"n": len(own_invalid), "runs": own_invalid},
            "descendants_of_numerically_invalid_sources": {"n": len(desc), "runs": desc},
            "contraction_diagnostics": {"n_rows": n_rows, "n_incomplete": len(inc), "incomplete": inc,
                                        "n_excluded_by_source_record": len(exc), "excluded": exc},
            "multi_model_jobs_without_single_endpoint": {"n": len(multi), "runs": multi}}


def summarize(results: str, manifests: list[str], out: Optional[str] = None, historical: bool = False) -> dict:
    """historical=True (v13): judge staleness against the code that PRODUCED the runs (one semantic hash),
    so a read-only folder of earlier results is re-analysed with the current ANALYSIS code (e.g. repaired cost
    accounting read from checkpoints) without retraining.  The output records that it is a remeasurement."""
    from ..utils import semantic_code_hash, code_hash
    results = Path(results)
    out = Path(out or results / "summary")
    out.mkdir(parents=True, exist_ok=True)
    sem_used = historical_semantic_hash(results) if historical else None
    runs = load_runs(results, sem_used)
    if historical:
        atomic_write_json(out / "historical_provenance.json", {
            "mode": "historical remeasurement: current analysis code over runs produced by earlier code",
            "runs_produced_by_semantic_hash": sem_used, "current_semantic_hash": semantic_code_hash(),
            "analysis_code_hash": code_hash(), "results": str(results),
            "recomputed_from_saved_files": ["cost accounting (baseline ledger fallback from ckpt/baseline.pt and "
                                            "inline baseline_ref counters)", "all tables and figures"],
            "not_recomputed": ["training, insertion identity checks and every job-level measurement: these are "
                               "the producing code's; checks changed since then need reruns (see "
                               "RECOVERY_v13.md)"]})
    status_counts = defaultdict(int)
    for r in runs.values():
        status_counts[r["status"]["status"]] += 1
    T = trajectory_table(runs)
    _write_csv(out / "trajectories.csv", T)
    rep_pc = paired_contrasts_report(T, runs=runs)
    PC = rep_pc["contrasts"]
    atomic_write_json(out / "paired_contrasts.json", PC)
    atomic_write_json(out / "analysis_errors.json", rep_pc["errors"])
    _write_csv(out / "paired_contrasts.csv", PC)
    CT = condition_table(runs)
    atomic_write_json(out / "conditions.json", CT)
    quarantine = [{"run_id": rid, "kind": r["cfg"]["kind"], "block": r["cfg"].get("block"),
                   "status": r["status"]["status"], "validity": r["status"].get("validity"),
                   "reason": r["status"].get("reason") or r["status"].get("validity_reasons")}
                  for rid, r in runs.items() if r["status"]["status"] in ("invalid", "stale") or
                  r["status"].get("validity") not in (None, "valid")]
    atomic_write_json(out / "accepted_stale_reuse.json",
                      [rid for rid, r in runs.items() if r["status"].get("stale_reuse_accepted")])
    _write_csv(out / "validity_quarantine.csv", quarantine)
    atomic_write_json(out / "validity_quarantine.json", quarantine)
    cov = coverage(runs, manifests) if manifests else {}
    atomic_write_json(out / "coverage.json", cov)
    rep = collect_json(runs, "repair_result.json")
    rep_rows = [{"run_id": r["run_id"], "condition_id": condition_id(r["cfg"]), "validity": r["status"].get("validity"),
                 "parent": r["cfg"]["parents"]["trajectory"], "region": j["region"],
                 "target": j["target"], "budget": j["budget"], "updates_done": j["updates_done"], "extended": j["extended"],
                 "n_trainable": j["n_trainable"], **{f"reach_{c}_{t}": v for c, d in j["reach"].items() if isinstance(d, dict)
                                                     for t, v in d.items()}} for r, j in rep]
    _write_csv(out / "repairs.csv", rep_rows)
    dis = collect_json(runs, "dissipation_result.json")
    dis_rows = [{"run_id": r["run_id"], "validity": r["status"].get("validity"), "parent": r["cfg"]["parents"]["trajectory"],
                 "speed_updates": r["cfg"]["dissipation"]["speed_updates"], "condition_id": condition_id(r["cfg"]),
                 **{k: v for k, v in j.items() if not isinstance(v, (list, dict))}} for r, j in dis]
    _write_csv(out / "dissipation.csv", dis_rows)
    chains = collect_json(runs, "cop_chain_result.json")
    ch_rows = []
    for r, j in chains:
        c = r["cfg"]
        ex = j["export"]
        ch_rows.append({"run_id": r["run_id"], "validity": r["status"].get("validity"), "condition_id": condition_id(c),
                        "data": c["data"]["name"], "placement": c["cop"]["placement"],
                        "peg_dim": c["peg"]["dim"], "peg_mode": c["peg"]["mode"], "bits": c["peg"]["bits"],
                        "codebook": c["peg"]["codebook_size"], "temp_channel": c["peg"]["temp_channel"],
                        "edit": c["cop"]["peg_edit"], "branch_pegs": c["cop"]["branch_pegs"],
                        "export_params": ex["params"], "bits_per_example": ex["bits_per_example_total"],
                        "export_err": ex["export_max_abs_err_vs_endpoint"],
                        "any_bypass": any(v.get("has_bypass") for v in ex["bypass"].values()),
                        "test_risk": ex["test"].get("mse", ex["test"].get("loss")), "test_acc": ex["test"].get("acc")})
    _write_csv(out / "cop_chains.csv", ch_rows)
    alts = collect_json(runs, "alternatives_result.json")
    alt_rows = [{"run_id": r["run_id"], "validity": r["status"].get("validity"), "condition_id": condition_id(r["cfg"]),
                 "interface_enforce": j.get("interface_enforce"),
                 "data": r["cfg"]["data"]["name"], "mode": j["mode"], "code_kind": j["code_kind"],
                 "interface_weight": r["cfg"]["cop"]["interface_weight"], "mean_risk_seen": j["mean_risk_seen"],
                 "mean_risk_heldout": j["mean_risk_heldout"], "n_heldout": j["n_heldout"],
                 "heldout_disjoint": j["audit"]["heldout_disjoint"]} for r, j in alts]
    _write_csv(out / "cop_alternatives.csv", alt_rows)
    splits = collect_json(runs, "split_result.json")
    sp_rows = [{"run_id": r["run_id"], "validity": r["status"].get("validity"), "condition_id": condition_id(r["cfg"]),
                "data": r["cfg"]["data"]["name"], "s": j["s"], "budget": j["budget"], **row}
               for r, j in splits for row in j["rows"]]
    _write_csv(out / "cop_split.csv", sp_rows)
    cyc = collect_json(runs, "cycles_result.json") + collect_json(runs, "baseline_result.json")
    cy_rows = [{"run_id": r["run_id"], "condition_id": condition_id(r["cfg"]), "validity": r["status"].get("validity"),
                "data": r["cfg"]["data"]["name"], "variant": j.get("variant", j.get("baseline")),
                "order": r["cfg"]["cop"]["cycle_order"], "pegs": r["cfg"]["cop"]["cycle_pegs"],
                "cycles": r["cfg"]["cop"]["cycles"], "parent_cycles": (r["cfg"].get("parents") or {}).get("cycles"),
                "export_params": j["export"]["params"], "export_macs": j["export"].get("macs"),
                "test": j["export"]["test"].get("mse", j["export"]["test"].get("acc")),
                "exposure_updates": j.get("exposure_updates"),
                "work_updates": (j.get("work_total") or {}).get("updates"),
                "work_forward_examples": (j.get("work_total") or {}).get("forward_examples"),
                "work_seconds": (j.get("work_total") or {}).get("seconds"),
                "matched_architecture": (j.get("control") or {}).get("architecture_equal_to_parent_endpoint"),
                "exposure_basis": (j.get("control") or {}).get("exposure_basis")} for r, j in cyc]
    _write_csv(out / "cop_cycles_baselines.csv", cy_rows)
    fin = []
    for r in runs.values():
        if r["cfg"]["kind"] != "finite":
            continue
        p = r["dir"] / "finite" / "summary.json"
        if p.exists():
            s = read_json(p)
            fin.append({"run_id": r["run_id"], "kind": r["cfg"]["finite"]["kind"], **{k: v for k, v in s.items()
                        if not isinstance(v, (list, dict))}})
    _write_csv(out / "finite.csv", fin)
    figs = make_figures(out, T, PC, cov, rep_rows, dis_rows, ch_rows, alt_rows, sp_rows, fin, runs)
    strength = None
    if any((r["cfg"].get("design") or {}).get("family") for r in runs.values()):
        from .strengthening import summarize_strengthening
        try:
            strength = summarize_strengthening(runs, out / "strengthening")
            figs += strength["figures"]
        except Exception as ex:                                  # noqa: BLE001  recorded; the summary is still written
            import traceback
            (out / "strengthening_ERROR.txt").write_text(traceback.format_exc())
            strength = {"error": f"{type(ex).__name__}: {ex}", "figures": []}
    nv = numeric_validity(results, runs)
    atomic_write_json(out / "numeric_validity.json", nv)
    res = {"n_runs": len(runs), "status_counts": dict(status_counts),
           "numeric_validity": {k: (v["n"] if isinstance(v, dict) and "n" in v else v) for k, v in nv.items()
                                if k != "contraction_diagnostics"} | {
               "diagnostic_rows": nv["contraction_diagnostics"]["n_rows"],
               "diagnostic_incomplete": nv["contraction_diagnostics"]["n_incomplete"],
               "diagnostic_excluded_by_source_record": nv["contraction_diagnostics"]["n_excluded_by_source_record"]}, "n_trajectories": len(T),
           "n_conditions": len(CT), "n_paired_contrasts": len(PC), "n_quarantined_or_unverified": len(quarantine),
           "analysis_errors": {k: len(v) for k, v in rep_pc["errors"].items()}, "figures": figs, "out": str(out),
           "figure_errors": read_json(out / "figure_errors.json") if (out / "figure_errors.json").exists() else {},
           "strengthening": None if strength is None else {k: v for k, v in strength.items() if k != "figures"}}
    atomic_write_json(out / "summary.json", res)
    return res


def make_figures(out: Path, T, PC, cov, rep, dis, ch, alt, sp, fin, runs) -> list[str]:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    made = []

    def save(fig, name):
        p = out / name
        fig.tight_layout()
        fig.savefig(p, dpi=120)
        plt.close(fig)
        made.append(name)

    def empty(name, title):
        fig, ax = plt.subplots(figsize=(6, 3))
        ax.text(0.5, 0.5, f"{title}\nno completed runs yet", ha="center", va="center")
        ax.axis("off")
        save(fig, name)

    def num(v) -> float:
        """Row values come from JSON, where non-finite floats are stored as 'nan' / 'inf' strings."""
        try:
            return float(v)
        except (TypeError, ValueError):
            return float("nan")

    def cond_means(rows, key):
        """Mean of `key` over the replications of each condition (valid complete rows only)."""
        acc = defaultdict(list)
        lab = {}
        for r in rows:
            v = num(r.get(key))
            if r["status"] == "complete" and (r.get("validity") or "valid") == "valid" and math.isfinite(v):
                acc[r["condition_id"]].append(v)
                lab[r["condition_id"]] = r
        return [(lab[c], sum(v) / len(v), len(v)) for c, v in acc.items()]


    def fig_1():
        # 1 coverage
        if cov and cov.get("blocks"):
            blocks = sorted(cov["blocks"])
            sts = ["complete", "running", "pending", "failed", "timed_out", "unsupported", "skipped_with_reason",
                   "invalid", "stale"]
            fig, ax = plt.subplots(figsize=(8, max(3, 0.18 * len(blocks))))
            left = [0] * len(blocks)
            for s in sts:
                v = [cov["blocks"][b].get(s, 0) for b in blocks]
                ax.barh(blocks, v, left=left, label=s)
                left = [a + b for a, b in zip(left, v)]
            ax.legend(fontsize=6)
            ax.tick_params(axis="y", labelsize=5)
            ax.set_xlabel("jobs")
            ax.set_title("Fig 1. Coverage by block (all statuses shown)")
            save(fig, "fig01_coverage.png")
        else:
            empty("fig01_coverage.png", "Fig 1. Coverage")
    def fig_2():
        # 2 dependence vs depth / n / width (W1 core): one point per CONDITION (mean over its replications)
        core = [r for r in T if r.get("block") == "W1_core" and r["topology"] != "none"]
        cm = cond_means(core, "test_max_single_delete_delta")
        if cm:
            fig, axs = plt.subplots(1, 3, figsize=(12, 3.5))
            topos = sorted({r["topology"] for r, _, _ in cm})
            for ax, key in zip(axs, ["teacher_depth", "n_train", "width"]):
                for j, topo in enumerate(topos):
                    pts = [(r[key], v) for r, v, _ in cm if r["topology"] == topo and r.get(key) is not None]
                    if pts:
                        ax.scatter([x for x, _ in pts], [y for _, y in pts], s=10, label=topo, alpha=0.7)
                ax.set_xlabel(key)
                ax.set_ylabel("max single-deletion delta risk (test)")
                if key == "n_train":
                    ax.set_xscale("log")
            axs[0].legend(fontsize=7)
            fig.suptitle("Fig 2. Dependence vs task complexity, sample size, capacity (one point per condition)")
            save(fig, "fig02_dependence_vs_axes.png")
        else:
            empty("fig02_dependence_vs_axes.png", "Fig 2. Dependence vs axes")
    def fig_3():
        # 3 equal final graph histories: one box per condition (block x topology x order x schedule)
        hist = [r for r in T if r["status"] == "complete" and (r.get("validity") or "valid") == "valid"
                and r["topology"] in ("tree_depth2", "recursive_branch")
                and (r.get("block") or "").startswith(("W3_E3_order", "W3_schedules", "W3_hard_fixed"))]
        if hist:
            by = defaultdict(list)
            for r in hist:
                v = num(r.get("test_mse", r.get("test_loss")))
                if math.isfinite(v):
                    by[(r["block"], r["topology"], r["order"], r["schedule"])].append(v)
            labels = sorted(by)
            fig, ax = plt.subplots(figsize=(max(8, 0.5 * len(labels)), 3.8))
            ax.boxplot([by[l] for l in labels])
            ax.set_xticks(range(1, len(labels) + 1))
            ax.set_xticklabels(["|".join(map(str, l)) for l in labels])
            ax.tick_params(axis="x", rotation=60, labelsize=5)
            ax.set_ylabel("final test risk")
            ax.set_title("Fig 3. Same final graph, different construction histories (per condition)")
            save(fig, "fig03_histories.png")
        else:
            empty("fig03_histories.png", "Fig 3. Histories")
    def fig_4():
        # 4 deletion landscape
        land = []
        for r in list(runs.values())[:2000]:
            p = r["dir"] / "deletions_final.json"
            if p.exists() and len(land) < 6:
                d = read_json(p)
                if d["info"].get("exhaustive"):
                    land.append((r, d))
        if land:
            fig, axs = plt.subplots(1, len(land), figsize=(3.2 * len(land), 3), squeeze=False)
            for ax, (r, d) in zip(axs[0], land):
                xs, ys = [], []
                for row in d["rows"]:
                    src = d["rows"][row["same_graph_as"]] if "same_graph_as" in row else row
                    if "metrics" in src:
                        y = num(src["metrics"][d["partitions"][0]].get("delta_risk"))
                        if math.isfinite(y):                     # non-finite subsets are not drawn
                            xs.append(len(row["canonical"]))
                            ys.append(y)
                ax.scatter(xs, ys, s=8)
                ax.set_title(r["cfg"]["growth"]["topology"], fontsize=8)
                ax.set_xlabel("atoms deleted")
            axs[0][0].set_ylabel("delta risk")
            fig.suptitle("Fig 4. Deletion-subset landscapes (exhaustive)")
            save(fig, "fig04_deletion_landscape.png")
        else:
            empty("fig04_deletion_landscape.png", "Fig 4. Deletion landscape")
    def fig_5():
        # 5 repair cost vs region
        if rep:
            regions = sorted({r["region"] for r in rep})
            fig, ax = plt.subplots(figsize=(8, 3.5))
            for tgt in sorted({r["target"] for r in rep}):
                ys = []
                for reg in regions:
                    rows = [r for r in rep if r["region"] == reg and r["target"] == tgt]
                    hit = [r for r in rows if any(k.startswith("reach_task") and r[k] is not None for k in r)]
                    ys.append(len(hit) / max(1, len(rows)))
                ax.plot(regions, ys, marker="o", label=f"target={tgt}")
            ax.set_ylabel("fraction reaching a task tolerance")
            ax.tick_params(axis="x", rotation=30, labelsize=7)
            ax.legend(fontsize=7)
            ax.set_title("Fig 5. Repair success vs region and target (censored runs count as not reached)")
            save(fig, "fig05_repair.png")
        else:
            empty("fig05_repair.png", "Fig 5. Repair")
    def fig_6():
        # 6 long histories: one point per condition
        lh = [r for r in T if (r.get("block") or "").startswith(("W3_E1", "W3_I1")) and r["shape"] == "chain"]
        d1, d2 = cond_means(lh, "test_max_single_delete_delta"), cond_means(lh, "test_mse") or cond_means(lh, "test_loss")
        if d1 or d2:
            fig, axs = plt.subplots(1, 2, figsize=(10, 3.5))
            for ax, dd, lab_ in ((axs[0], d1, "max single-deletion delta"), (axs[1], d2, "test risk")):
                for blk in sorted({r["block"] for r, _, _ in dd}):
                    pts = sorted((r["rounds"], v) for r, v, _ in dd if r["block"] == blk)
                    ax.scatter([x for x, _ in pts], [y for _, y in pts], s=10, label=blk)
                ax.set_xscale("log", base=2)
                ax.set_xlabel("growth events")
                ax.set_ylabel(lab_)
            axs[0].legend(fontsize=6)
            fig.suptitle("Fig 6. Long histories (one point per condition; no monotone fit imposed)")
            save(fig, "fig06_long_histories.png")
        else:
            empty("fig06_long_histories.png", "Fig 6. Long histories")
    def fig_7():
        # 7 paths: per (method, order, speed) condition, mean over parents
        if dis:
            by = defaultdict(list)
            n_bad = 0
            for r in dis:
                v = [num(r.get(k)) for k in ("start_risk", "peak_risk", "final_risk")]
                if not all(map(math.isfinite, v)):
                    n_bad += 1                                   # diverged / non-finite paths are counted, not drawn
                    continue
                by[(r["method"], r.get("order"), r.get("speed_updates"))].append(v)
            labels = sorted(by, key=lambda t: tuple(str(x) for x in t))
            fig, ax = plt.subplots(figsize=(max(8, 0.35 * len(labels)), 3.8))
            xs = range(len(labels))
            ax.scatter(xs, [sum(p - s0 for s0, p, _ in by[l]) / len(by[l]) for l in labels],
                       label="peak - start", s=12)
            ax.scatter(xs, [sum(f - s0 for s0, _, f in by[l]) / len(by[l]) for l in labels],
                       label="final - start", s=12, marker="x")
            ax.set_xticks(list(xs))
            ax.set_xticklabels(["|".join(map(str, l)) for l in labels])
            ax.tick_params(axis="x", rotation=70, labelsize=5)
            ax.set_ylabel("risk change from start")
            ax.legend(fontsize=7)
            ax.set_title("Fig 7. Removal paths: peak and final (observed on these paths only)"
                         + (f"; {n_bad} paths with non-finite risk not drawn" if n_bad else ""))
            save(fig, "fig07_paths.png")
        else:
            empty("fig07_paths.png", "Fig 7. Paths")
    def fig_8():
        # 8 peg width / precision
        if ch:
            fig, ax = plt.subplots(figsize=(6, 4))
            for mode in sorted({r["peg_mode"] for r in ch}):
                rs = [r for r in ch if r["peg_mode"] == mode]
                pts = [(max(1.0, num(r["bits_per_example"])), num(r["test_risk"])) for r in rs]
                pts = [(x, y) for x, y in pts if math.isfinite(x) and math.isfinite(y)]
                ax.scatter([x for x, _ in pts], [y for _, y in pts], label=mode, s=12)
            ax.set_xscale("log")
            ax.set_xlabel("bits per example through pegs")
            ax.set_ylabel("test risk (exported model)")
            ax.legend(fontsize=7)
            ax.set_title("Fig 8. Peg communication vs task quality")
            save(fig, "fig08_pegs.png")
        else:
            empty("fig08_pegs.png", "Fig 8. Pegs")
    def fig_9():
        # 9 seen vs unseen assemblies
        if alt:
            fig, ax = plt.subplots(figsize=(6, 4))
            pts = [(num(r["mean_risk_seen"]), num(r["mean_risk_heldout"])) for r in alt]
            pts = [(x, y) for x, y in pts if math.isfinite(x) and math.isfinite(y)]
            for x, y in pts:
                ax.scatter(x, y, s=14)
            lim = [min(x for x, _ in pts), max(x for x, _ in pts)] if pts else [0.0, 1.0]
            ax.plot(lim, lim, "k--", lw=0.8)
            ax.set_xlabel("mean risk, assemblies seen in training")
            ax.set_ylabel("mean risk, held-out assemblies")
            ax.set_title("Fig 9. Seen vs unseen module combinations")
            save(fig, "fig09_assemblies.png")
        else:
            empty("fig09_assemblies.png", "Fig 9. Assemblies")
    def fig_10():
        # 10 split frontier
        if sp:
            fig, ax = plt.subplots(figsize=(6, 4))
            for kind in ("chain", "shared", "one_large"):
                rs = [r for r in sp if (kind in r["variant"]) and (kind != "chain" or "shared" not in r["variant"])]
                pts = [(num(r["params"]), num(r["val_local_rel_mse"])) for r in rs]
                pts = [(x, y) for x, y in pts if math.isfinite(x) and math.isfinite(y)]
                ax.scatter([x for x, _ in pts], [y for _, y in pts], label=kind, s=14)
            ax.set_xscale("log")
            ax.set_xlabel("total parameters")
            ax.set_ylabel("validation local relative MSE")
            ax.legend(fontsize=7)
            ax.set_title("Fig 10. Recursive pearl splitting frontier")
            save(fig, "fig10_split.png")
        else:
            empty("fig10_split.png", "Fig 10. Split")
    def fig_11():
        # 11 training adequacy and cost
        done = [r for r in T if r["status"] == "complete"]
        if done:
            fig, axs = plt.subplots(1, 2, figsize=(10, 3.5))
            q = defaultdict(int)
            for r in done:
                q[str(r.get("training_quality"))] += 1
            axs[0].bar(list(q), list(q.values()))
            axs[0].set_title("training quality labels (rows kept)")
            axs[1].hist([v for v in (num(r.get("elapsed_seconds")) for r in done) if math.isfinite(v)], bins=30)
            axs[1].set_xlabel("seconds per trajectory")
            fig.suptitle("Fig 11. Training adequacy and compute")
            save(fig, "fig11_training_cost.png")
        else:
            empty("fig11_training_cost.png", "Fig 11. Training adequacy")
    def fig_12():
        # 12 certificates
        if fin:
            fig, ax = plt.subplots(figsize=(8, max(2, 0.25 * len(fin))))
            ax.axis("off")
            cells = [[r["kind"], str(r.get("all_checks_ok")), str(r.get("n_certificates", ""))] for r in fin[:60]]
            ax.table(cellText=cells, colLabels=["kind", "independent check ok", "certificates"], loc="center", fontsize=6)
            ax.set_title("Fig 12. Finite certificates (see finite/ certificate files for domains and scope)")
            save(fig, "fig12_certificates.png")
        else:
            empty("fig12_certificates.png", "Fig 12. Certificates")
    errors = {}
    for name, fn in [("fig1", fig_1), ("fig2", fig_2), ("fig3", fig_3), ("fig4", fig_4), ("fig5", fig_5), ("fig6", fig_6), ("fig7", fig_7), ("fig8", fig_8), ("fig9", fig_9), ("fig10", fig_10), ("fig11", fig_11), ("fig12", fig_12)]:
        try:
            fn()
        except Exception as ex:                                  # noqa: BLE001  one figure never stops the others
            import traceback
            plt.close("all")
            errors[name] = f"{type(ex).__name__}: {ex}"
            (out / f"{name}_ERROR.txt").write_text(traceback.format_exc())
    if errors:
        atomic_write_json(out / "figure_errors.json", errors)
    return made
