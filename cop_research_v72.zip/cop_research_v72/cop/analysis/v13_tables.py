"""v13 analysis tables (audit of v12, Parts C and D).  Three analyses are kept apart:

  (i)   fixed-history mechanism: computation movement, deletion damage and bounded repair at declared checkpoints
        -> s13_removal_paths.csv, s13_x4_information.csv, s13_locality_controls.csv, s13_finite_refit.csv, and
           the v5/v8 mechanism tables (s_locality, s_finite_interface, s_contraction_diagnostics, ...)
  (ii)  best deployable compact endpoint: validation-selected endpoints under one allocated budget
        -> s_selected_* (strengthening.selected_gain) and s13_tuned_* (equal learning-rate tuning opportunities)
  (iii) same final architecture: history versus strong direct training
        -> s_matched_endpoint_* (fixed endpoints), s13_history_ingredients.csv, s13_later_query_retention.csv

Every row carries the arm's information access and budget metadata.  All tables are exploratory at re-pilot
size (one discovery seed); none is a confirmation result.
"""
from __future__ import annotations

import math
from collections import defaultdict
from pathlib import Path
from typing import Optional

from ..utils import read_json, atomic_write_json
from .strengthening import _boot, _numerically_ok, _rk, _rows, _stage_metrics, draw_level

# learning-rate tuning groups: each side gets the same two declared learning rates (base, 0.3x)
TUNING_GROUPS = {"treated": ("treated", "treated_lr0.3"), "C1": ("C1", "C1_lr0.3"), "M1": ("M1", "M1_lr0.3")}


def _info(cfg: dict) -> dict:
    from ..orchestration.wave13 import info_access, budget_meta
    return {**{f"access_{k}": v for k, v in info_access(cfg).items()},
            **{f"budget_{k}": v for k, v in budget_meta(cfg).items()}}


def _vrisk(e: dict) -> Optional[float]:
    v = e.get("val_risk")
    return float(v) if v is not None else None


def tuning_cost(xs: list[dict]) -> Optional[int]:
    """The whole tuning procedure: every candidate's own training and selection work, plus the shared baseline
    and the shared f0 selection search once (each candidate's total includes them)."""
    if not xs or any(x.get("total_procedure_macs") is None for x in xs):
        return None
    shared = max(int(x.get("baseline_macs") or 0) + int(x.get("f0_search_macs") or 0) for x in xs)
    return shared + sum(int(x["total_procedure_macs"]) - int(x.get("baseline_macs") or 0)
                        - int(x.get("f0_search_macs") or 0) for x in xs)


STRICT_RECIPES = ("fixed", "ema", "fixed_m", "ema_m")     # m = v17 straight-through margin variant


def _parse_fq_arm(arm: str) -> Optional[tuple[str, str, str, str]]:
    """FQr arm -> (side, recipe, lr factor, panel).
      treated[_ema][_m][_lr<f>]                      treated chain (panel '-')
      M1_<recipe>[_lr<f>]  /  M2_<recipe>[_lr<f>]    scratch, update-matched / compute-matched
    recipe in fixed | ema | fixed_m | ema_m | warmup."""
    import re
    m = re.match(r"^treated(_ema)?(_m)?(?:_lr([0-9.]+))?$", arm)
    if m:
        return "treated", ("ema" if m.group(1) else "fixed") + ("_m" if m.group(2) else ""), m.group(3) or "1.0", "-"
    m = re.match(r"^(M1|M2)_(fixed_m|ema_m|fixed|ema|warmup)(?:_lr([0-9.]+))?$", arm)
    if m:
        return "scratch", m.group(2), m.group(3) or "1.0", "updates" if m.group(1) == "M1" else "compute"
    return None


def finite_recipe_gain(E: list[dict], metric: str = "test_risk", rejected: Optional[list] = None):
    """v15 / v17 finite-peg recipe panel (FQr), within one pairing unit (contrast, f0 @ stage, replication):
      tuned       for each strict recipe (fixed, ema and their v17 margin variants) and each scratch budget panel
                  (updates = treated chain + f0 updates; compute = treated chain + f0 training MACs): the treated
                  arms and the scratch arms of THAT recipe, each over the same declared learning rates, best by
                  fixed-endpoint validation risk on each side (equal opportunities: the same set of rates)
      matched_lr  every recipe and panel at every learning rate present on both sides, no selection; the warm-up
                  scratch arm (capacity relaxation) is compared with the treated fixed-range arm at the same rate
                  and is never part of a best-of selection
    G = R(scratch) - R(treated) on `metric`."""
    rej = rejected if rejected is not None else []
    units = defaultdict(dict)
    for e in E:
        if e.get("design_family") != "FQr" or not e.get("design_contrast"):
            continue
        pa = _parse_fq_arm(e.get("design_arm") or "")
        if pa is None:
            continue
        k = (e["design_contrast"], f"{e.get('f0_run')}@{e.get('f0_stage')}", e["replication"])
        if pa in units[k]:
            rej.append({"contrast": k[0], "replication": k[2], "arm": e["design_arm"], "reason": "duplicate arm"})
            units[k][pa] = None
            continue
        units[k][pa] = e
    tuned, matched = [], []
    for (con, f0, rep), arms in sorted(units.items()):
        def side(sd, rec, panel):
            return {lr: x for (s_, r_, lr, p_), x in arms.items() if s_ == sd and r_ == rec and p_ == panel}
        panels = sorted({p_ for (s_, _, _, p_) in arms if s_ == "scratch"})
        for rec in STRICT_RECIPES:
            T_ = side("treated", rec, "-")
            for panel in panels:
                C_ = side("scratch", rec, panel)
                if not T_ or not C_:
                    continue
                bad = [x for x in list(T_.values()) + list(C_.values()) if x is None
                       or not _numerically_ok(x, metric)[0] or _vrisk(x) is None]
                if set(T_) != set(C_) or bad:
                    rej.append({"contrast": con, "replication": rep, "recipe": rec, "panel": panel,
                                "reason": "unequal learning-rate sets" if set(T_) != set(C_) else
                                "a candidate is missing, duplicated or ineligible"})
                    continue
                bt = min(T_.items(), key=lambda kv: (_vrisk(kv[1]), -float(kv[0])))
                bc = min(C_.items(), key=lambda kv: (_vrisk(kv[1]), -float(kv[0])))
                tuned.append({"contrast": con, "f0": f0, "replication": rep, "recipe": rec, "scratch_panel": panel,
                              "lr_candidates": " ".join(sorted(T_)), "treated_lr_selected": bt[0],
                              "scratch_lr_selected": bc[0], "treated_run": bt[1]["run_id"],
                              "scratch_run": bc[1]["run_id"], "treated_risk": bt[1][metric],
                              "scratch_risk": bc[1][metric], "G": bc[1][metric] - bt[1][metric],
                              "treated_selected_procedure_macs": bt[1].get("total_procedure_macs"),
                              "scratch_selected_procedure_macs": bc[1].get("total_procedure_macs"),
                              "treated_tuning_procedure_macs": tuning_cost(list(T_.values())),
                              "scratch_tuning_procedure_macs": tuning_cost(list(C_.values()))})
        for rec in STRICT_RECIPES + ("warmup",):
            T_ = side("treated", "fixed" if rec == "warmup" else rec, "-")
            for panel in panels:
                C_ = side("scratch", rec, panel)
                for lr in sorted(set(T_) & set(C_)):
                    t, c = T_[lr], C_[lr]
                    if t is None or c is None or not _numerically_ok(t, metric)[0] or not _numerically_ok(c, metric)[0]:
                        continue
                    matched.append({"contrast": con, "f0": f0, "replication": rep, "recipe": rec,
                                    "scratch_panel": panel, "lr_factor": lr,
                                    "comparison": "capacity_relaxation_control" if rec == "warmup" else "same_recipe",
                                    "treated_run": t["run_id"], "scratch_run": c["run_id"], "treated_risk": t[metric],
                                    "scratch_risk": c[metric], "G": c[metric] - t[metric],
                                    "treated_procedure_macs": t.get("total_procedure_macs"),
                                    "scratch_procedure_macs": c.get("total_procedure_macs")})
    return tuned, matched


def finite_recipe_gain_selected(E: list[dict], metric: str = "test_risk", rejected: Optional[list] = None):
    """v17: the recipe panel at the VALIDATION-SELECTED checkpoint of every arm (wave 16 showed fixed-endpoint and
    selected-endpoint gaps can differ several-fold).  Same rules as the selected-endpoint analysis: an arm enters
    only with a selected checkpoint of its own final architecture; the learning rate is then chosen by the
    selected checkpoint's validation risk on each side; every arm of a pairing unit must have had the same
    number of selection candidates.  Test partitions are read only after both choices."""
    rej = rejected if rejected is not None else []
    xs, ncand = [], defaultdict(set)
    for e in E:
        if e.get("design_family") != "FQr":
            continue
        if not e.get("sel_available") or e.get("sel_architecture_hash") != e.get("architecture_hash"):
            rej.append({"run_id": e.get("run_id"), "reason": "no selected checkpoint of the arm's final architecture"})
            continue
        x = dict(e, **{metric: e.get(f"sel_{metric}"), "val_risk": e.get("sel_val_risk"),
                       "endpoint_policy": "best_val"})
        xs.append(x)
        ncand[(e.get("design_contrast"), e.get("f0_run"), e.get("f0_stage"), e.get("replication"))].add(
            e.get("sel_n_candidates"))
    bad = {k for k, v in ncand.items() if len(v) > 1}
    for k in sorted(bad, key=str):
        rej.append({"contrast": k[0], "replication": k[3], "reason": "unequal selection opportunities in the unit"})
    xs = [x for x in xs if (x.get("design_contrast"), x.get("f0_run"), x.get("f0_stage"), x.get("replication"))
          not in bad]
    return finite_recipe_gain(xs, metric, rej)


def draw_summary(rows: list[dict], by: tuple, values: dict, rejected: Optional[list] = None) -> list[dict]:
    """v15: pool per-replication paired rows over replications.  `by` names the grouping fields (the f0 stage is
    always added, from the row's 'f0' = '<run>@<stage>', so fixed-budget and selected f0 never mix); `values` maps
    an output name to a function row -> paired effect (or None).  Each group gets draw_level fields per value
    (primary = optimizer seed 0, one per draw; pooled = each draw weighted once).  A replication appearing twice
    in one group rejects the group (it would be silently overwritten otherwise)."""
    rej = rejected if rejected is not None else []
    groups = defaultdict(list)
    for r in rows:
        st = str(r.get("f0") or "").rpartition("@")[2] or None
        groups[tuple(r.get(k) for k in by) + (st,)].append(r)
    out = []
    for key, rs in sorted(groups.items(), key=lambda kv: tuple(str(x) for x in kv[0])):
        reps = [r.get("replication") for r in rs]
        if len(set(reps)) != len(reps):
            rej.append({**dict(zip(by + ("f0_stage",), key)), "reason": "a replication appears twice in one group"})
            continue
        row = {**dict(zip(by + ("f0_stage",), key)), "n_replications": len(rs)}
        for name, fn in values.items():
            pts = [(r["replication"], fn(r)) for r in rs]
            pts = [(k, float(v)) for k, v in pts if v is not None and math.isfinite(float(v))]
            row.update({f"{name}_{k}": v for k, v in draw_level(pts).items()})
        out.append(row)
    return out


def _diff(a: str, b: str):
    return lambda r: (r[a] - r[b]) if r.get(a) is not None and r.get(b) is not None else None


def later_query_summary(LQ: list[dict], rejected: Optional[list] = None) -> list[dict]:
    """M_E pooled over replications: test-error gain (control - treated) and, per readout, the accuracy retained
    by the treated endpoint relative to the control (treated - control)."""
    # readout retention is pooled only over pairs with the same decoder class on both sides
    rd = sorted({k[len("treated_"):] for r in LQ for k in r
                 if k.startswith(("treated_readout_", "treated_sel_readout_")) and k.endswith("_acc")})
    same = lambda f: (lambda r: f(r) if r.get("same_decoder_class") is not False else None)
    vals = {"test_err_G": _diff("control_test_err", "treated_test_err"),
            "test_risk_G": _diff("control_test_risk", "treated_test_risk"),
            **{f"{k}_retained": same(_diff(f"treated_{k}", f"control_{k}")) for k in rd}}
    return draw_summary(LQ, ("contrast", "endpoint_policy", "control_arm", "comparison"), vals, rejected)


def tuned_gain(E: list[dict], metric: str = "test_risk", rejected: Optional[list] = None):
    """Analysis (ii) with equal tuning opportunities: on each side the declared learning rates (base and 0.3x)
    are both run and the one with the lower FIXED-ENDPOINT VALIDATION risk is kept (ties to the base rate);
    G = R(control tuned) - R(treated tuned) on `metric`.  A pair needs every declared rate on both sides."""
    rej = rejected if rejected is not None else []
    by = defaultdict(dict)                         # (contrast, f0, replication, panel) -> arm -> entry
    dup = set()
    for e in E:
        if not e.get("design_contrast") or e.get("design_arm") is None:
            continue
        panel = e.get("design_budget_panel", "")
        if e["design_arm"].startswith("treated"):
            panel = "updates"                      # the treated side is shared by every updates-panel control
        k = (e["design_contrast"], f"{e.get('f0_run')}@{e.get('f0_stage')}", e["replication"], panel)
        if e["design_arm"] in by[k]:
            dup.add((k, e["design_arm"]))
        by[k][e["design_arm"]] = e
    for k, arm in sorted(dup, key=str):
        rej.append({"contrast": k[0], "replication": k[2], "side": arm, "reason": "duplicate arm in one pairing unit"})
        by[k].pop(arm, None)

    def all_candidates_cost(arms: dict, group: tuple):
        """the whole tuning procedure: every candidate's own work, the shared baseline once"""
        xs = [arms[a] for a in group if a in arms]
        return tuning_cost(xs)

    def tune(arms: dict, group: tuple) -> tuple[Optional[dict], str]:
        got = [arms.get(a) for a in group]
        if any(x is None for x in got):
            return None, f"missing tuning arm(s) {[a for a, x in zip(group, got) if x is None]}"
        ok = [(x, _numerically_ok(x, metric)) for x in got]
        good = [x for x, (o, _) in ok if o and _vrisk(x) is not None]
        if len(good) < len(got):
            return None, "a tuning arm is ineligible: " + "; ".join(w for _, (o, w) in ok if not o)
        best = min(good, key=lambda x: (_vrisk(x), group.index(x["design_arm"])))
        return best, ""
    pairs = []
    for (con, f0, rep, panel), arms in sorted(by.items()):
        t, why = tune(arms, TUNING_GROUPS["treated"])
        if t is None:
            # only a contrast that declares tuned controls is missing something
            if any(a in arms for g in ("C1", "M1") for a in TUNING_GROUPS[g][1:]):
                rej.append({"contrast": con, "replication": rep, "side": "treated", "reason": why})
            continue
        for cname in ("C1", "M1"):
            if not any(a in arms for a in TUNING_GROUPS[cname]):
                continue
            c, why = tune(arms, TUNING_GROUPS[cname])
            if c is None:
                rej.append({"contrast": con, "replication": rep, "side": cname, "reason": why})
                continue
            if c.get("architecture_hash") != t.get("architecture_hash"):
                rej.append({"contrast": con, "replication": rep, "side": cname,
                            "reason": "control endpoint architecture differs from the treated endpoint's"})
                continue
            pairs.append({"contrast": con, "f0": f0, "replication": rep, "control": f"{cname}_tuned",
                          "treated_arm_selected": t["design_arm"], "control_arm_selected": c["design_arm"],
                          "treated_run": t["run_id"], "control_run": c["run_id"], "treated_val_risk": _vrisk(t),
                          "control_val_risk": _vrisk(c), "treated_risk": t[metric], "control_risk": c[metric],
                          "G": c[metric] - t[metric], "tuning_opportunities_each_side": 2,
                          "family": t.get("design_family"), "variant": t.get("design_variant"),
                          "treated_selected_model_procedure_macs": t.get("total_procedure_macs"),
                          "control_selected_model_procedure_macs": c.get("total_procedure_macs"),
                          "treated_tuning_procedure_macs": all_candidates_cost(arms, TUNING_GROUPS["treated"]),
                          "control_tuning_procedure_macs": all_candidates_cost(arms, TUNING_GROUPS[cname]),
                          "cost_note": "MAC estimates (dense 3x forward), not wall time; tuning cost counts every "
                                       "candidate's training and the shared baseline once"})
    summ = []
    g = defaultdict(list)
    for p in pairs:
        g[(p["contrast"], p["control"])].append(p)
    from .strengthening import draw_level
    for (con, ctl), ps in sorted(g.items()):
        gs = [p["G"] for p in ps]
        lo, hi = _boot(gs)
        dl = draw_level([(p["replication"], p["G"]) for p in ps])
        summ.append({"contrast": con, "control": ctl, "family": ps[0]["family"], "variant": ps[0]["variant"],
                     "metric": metric, "n_pairs": len(gs), "G_mean": sum(gs) / len(gs), "G_ci_lo": lo, "G_ci_hi": hi,
                     "selection": "fixed-endpoint validation risk over {base, 0.3x} on each side (the "
                                  "best-validation-checkpoint tables are separate)",
                     "interval": "exploratory percentile bootstrap over replications", **dl})
    return summ, pairs


def removal_path_table(runs: dict) -> list[dict]:
    """Analysis (i): sampled removal / repair paths of every removal protocol, with the declared removal / repair
    split.  Each path event is joined to its full evaluation by EVENT identity (v15): key events (start, the
    model right after an abrupt deletion or a fold, the physically removed model) are logged as stage
    path_<tag>; sampled points as pathfull@<update>.  The start and the immediate deletion both sit at update 0
    and stay separate rows.  A missing evaluation is left empty and flagged (full_eval_source = missing), never
    taken from another event.  peak_risk_sampled is the maximum over the sampled path points (validation), not a
    continuously observed maximum."""
    out = []
    for rid, r in runs.items():
        c = r["cfg"]
        p = r["dir"] / "dissipation_result.json"
        if c["kind"] != "dissipation" or not p.exists() or r["status"]["status"] != "complete":
            continue
        j = read_json(p)
        d = c.get("design") or {}
        by_stage = defaultdict(dict)
        for m in _rows(r):
            st = m["stage"]
            if m.get("atoms") is None and (st.startswith("pathfull@") or st.startswith("path_")):
                by_stage[st][f"{m['evaluation_partition']}_{m['metric_name']}"] = m["metric_value"]
        mm = j.get("mac_matching") or {}
        path = j.get("path", [])
        base = {"run_id": rid, "contrast": d.get("contrast"), "family": d.get("family"), "variant": d.get("variant"),
                "arm": d.get("arm"), "method": c["dissipation"]["method"],
                "removal_updates": c["dissipation"]["speed_updates"],
                "repair_updates": mm.get("planned_updates", c["dissipation"]["post_updates"]),
                "mac_matching": bool(j.get("mac_matching")), "total_updates": j.get("total_updates"),
                "peak_risk_sampled": j.get("peak_risk"), "n_path_points": len(path),
                "peak_kind": "maximum over sampled path points (validation); not a continuous maximum",
                "final_risk": j.get("final_risk")}
        for i, q in enumerate(path):
            tag = q.get("tag")
            src = None
            if f"path_{tag}" in by_stage:
                f, src = by_stage[f"path_{tag}"], f"path_{tag}"
            elif f"pathfull@{q['update']}" in by_stage and not str(tag).startswith(("start", "after_", "physically")):
                f, src = by_stage[f"pathfull@{q['update']}"], f"pathfull@{q['update']}"
            else:
                f = {}

            def risk(part, f=f):
                v = f.get(f"{part}_mse", f.get(f"{part}_loss"))
                return v

            def err(part, f=f):
                a = f.get(f"{part}_acc")
                return None if a is None else 1.0 - a
            out.append({**base, "event_index": i, "update": q["update"], "tag": tag,
                        "full_eval_source": src or "missing", "val_risk": q.get("val_risk"),
                        "val_acc": q.get("val_acc"), "gated_contribution": q.get("gated_contribution"),
                        "full_test_risk": risk("test"), "full_test_err": err("test"),
                        "full_rare_risk": risk("rare"), "full_rare_err": err("rare"),
                        "full_shift_risk": risk("shift"), "full_shift_err": err("shift"),
                        "full_test_worst_group_acc": f.get("test_worst_group_acc"),
                        "logit_norm_mean": f.get("val_logit_norm_mean"),
                        "prediction_drift_rms_from_start": f.get("val_prediction_drift_rms_from_start"),
                        "prediction_flip_rate_from_start": f.get("val_prediction_flip_rate_from_start")})
    return out


def x4_information_table(runs: dict, E: list[dict]) -> list[dict]:
    """X4 re-pilot: every arm's endpoint (fixed and selected) with its information access, gradient coverage of
    each branch, sampler, removal protocol and the inference group-metadata check."""
    byrun = {e["run_id"]: e for e in E}
    out = []
    for rid, r in runs.items():
        d = r["cfg"].get("design") or {}
        if d.get("family") not in ("X4r", "P2") or rid not in byrun:
            continue
        e = byrun[rid]
        row = {"run_id": rid, "contrast": d.get("contrast"), "expansion": d.get("variant"), "arm": d.get("arm"),
               "kind": r["cfg"]["kind"], "replication": e.get("replication"), "eligible": e.get("eligible"),
               **_info(r["cfg"])}
        for k in ("test_risk", "test_err", "rare_risk", "rare_err", "shift_risk", "shift_err", "test_worst_group_acc",
                  "rare_worst_group_acc", "val_risk", "sel_test_risk", "sel_rare_risk", "sel_shift_risk",
                  "sel_global_step", "sel_n_candidates", "total_procedure_macs", "baseline_macs", "post_f0_macs"):
            row[k] = e.get(k)
        # the trajectory the arm descends from carries the specialization record; compact continuations start
        # from f0 and never trained the expanded model, so they get none
        tid = rid if r["cfg"]["kind"] == "trajectory" else (r["cfg"].get("parents") or {}).get("trajectory")
        if tid and tid in runs:
            acc = runs[tid]["dir"] / "specialization_access.json"
            if acc.exists():
                a = read_json(acc)
                row.update({"spec_partition": a.get("spec_partition"), "branch_a_fraction": a.get("branch_a_fraction"),
                            "grad_coverage_branch_a": a["gradient_coverage"]["branch_a"],
                            "grad_coverage_branch_b": a["gradient_coverage"]["branch_b"],
                            "branch_a_by_group": str(a["branch_a"].get("by_group")),
                            "branch_b_by_group": str(a["branch_b"].get("by_group"))})
            sp = runs[tid]["dir"] / "summary.json"
            if sp.exists():
                ex = (read_json(sp).get("result") or {}).get("spec_exposure") or {}
                if ex.get("examples"):
                    # v15: EMPIRICAL exposure under the actual sampler (not the nominal dataset proportions)
                    row["exposure_branch_a_fraction"] = ex["branch_a"] / ex["examples"]
                    row["exposure_branch_b_fraction"] = ex["branch_b"] / ex["examples"]
                    for k, v in ex.items():
                        if k.startswith("group") and k.endswith("_examples"):
                            row[f"exposure_{k[:-9]}_share"] = v / ex["examples"]
                gi = (read_json(sp).get("result") or {}).get("group_inference_check")
                row["inference_independent_of_group_metadata"] = None if gi is None else \
                    gi["predictions_identical_under_permuted_groups"]
        out.append(row)
    return out


def _cont_result(r) -> dict:
    p = r["dir"] / "summary.json"
    return (read_json(p).get("result") or {}) if p.exists() else {}


def _later_query_means(lq: Optional[dict]) -> dict:
    """Held-out READOUT accuracy of later queries at each peg (v15 naming): training-fitted probes (least squares
    for continuous pegs, a majority table per transmitted message for finite pegs, unseen messages falling back
    to the training majority), applied to val / test.  These are probe accuracies, not information oracles: a
    better score can mean more retained information, easier decoding, or both.  I1, I2 are interface locations.
    The exact finite-domain code oracle lives in s_finite_interface / s13_finite_refit."""
    if not lq:
        return {}
    out = {"readout_queries_n": lq.get("queries"), "readout_fit_partition": lq.get("decoder_fit"),
           "readout_checkpoint": lq.get("checkpoint", "final")}       # v17: which checkpoint was read out
    for pid, v in (lq.get("pegs") or {}).items():
        out[f"readout_{pid}_decoder"] = v.get("decoder")
        for k in ("train_messages", "fit_examples", "code_dim"):
            if k in v:
                out[f"readout_{pid}_{k}"] = v.get(k)
        for part in ("val", "test"):
            xs = v.get(part)
            if xs:
                out[f"readout_{pid}_{part}_acc"] = sum(xs) / len(xs)
            if f"{part}_unseen_message_frac" in v:
                out[f"readout_{pid}_{part}_unseen_message_frac"] = v[f"{part}_unseen_message_frac"]
    for part in ("val", "test"):
        xs = (lq.get("chance") or {}).get(part)
        if xs:
            out[f"readout_chance_{part}_acc"] = sum(xs) / len(xs)
        xs = (lq.get("input_reaccess") or {}).get(part)
        if xs:
            out[f"readout_input_reaccess_{part}_acc"] = sum(xs) / len(xs)
    return out


IDENTITY_FIELDS = ("replication", "f0_run", "f0_stage", "design_budget_panel", "architecture_hash", "eligible",
                   "eligibility_reasons")


def _identity(r, e: dict) -> dict:
    c = r["cfg"]
    d = c.get("data") or {}
    ident = {k: e.get(k) for k in IDENTITY_FIELDS}
    if ident.get("replication") is None:
        ident["replication"] = _rk(c)                  # never None: a None key would pool replications
    if ident.get("f0_run") is None:
        ident["f0_run"] = (c.get("parents") or {}).get("baseline")
    return {**ident,
            "data_draw": d.get("data_seed"), "teacher_draw": d.get("teacher_seed"),
            "optimizer_seed": (c.get("seeds") or {}).get("optimizer"), "endpoint_policy": "fixed"}


def history_ingredients_table(runs: dict, E: list[dict]) -> list[dict]:
    """Analysis (iii): one row per arm of the matched-architecture families (C4i ingredients, F07r, F09r, M_Er,
    X3r): fixed and selected endpoint risks, the scratch arms' quantiser / gradient / reset audit, and the later-
    query readouts scored identically for treated and control arms.  Every row carries its replication, data /
    teacher draw, optimizer seed, f0 run and stage, budget panel, architecture and eligibility (v15)."""
    byrun = {e["run_id"]: e for e in E}
    out = []
    for rid, r in runs.items():
        d = r["cfg"].get("design") or {}
        if d.get("family") not in ("C4i", "F07r", "F09r", "M_Er", "X3r", "FQr") or r["status"]["status"] != "complete":
            continue
        e = byrun.get(rid, {})
        row = {"run_id": rid, "family": d.get("family"), "contrast": d.get("contrast"), "variant": d.get("variant"),
               "arm": d.get("arm"), "kind": r["cfg"]["kind"], **_identity(r, e), **_info(r["cfg"])}
        for k in ("test_risk", "test_err", "val_risk", "sel_test_risk", "sel_test_err", "sel_val_risk",
                  "sel_n_candidates", "total_procedure_macs", "baseline_macs", "post_f0_macs", "search_macs",
                  "endpoint_params", "endpoint_peg_bits"):
            row[k] = e.get(k)
        pc = r["cfg"].get("peg") or {}
        if pc:
            row["peg_dim"], row["peg_bits_per_coordinate"] = pc.get("dim"), pc.get("bits")

        def msg_bits(qs):
            # bits per transmitted message at each finite peg: dimension x bits per coordinate (e.g. d 4, b 2 = 8)
            return str([int(q["k"] * math.log2(q["levels"])) for q in qs if q.get("levels")]) if qs else None
        def grads(row, ga, when):
            if ga is not None:
                row[f"zero_gradient_modules_at_{when}"] = len(ga.get("zero_gradient_modules") or [])
                gn = list((ga.get("grad_norm_by_module") or {}).values())
                row[f"grad_norm_max_at_{when}"] = max(gn) if gn else None

        def selected_readouts(row, lq_sel):
            # v17: readouts of the validation-selected checkpoint, prefixed sel_ (the plain columns are the
            # fixed endpoint's, readout_checkpoint says so)
            if lq_sel and not lq_sel.get("unavailable"):
                row.update({f"sel_{k}": v for k, v in _later_query_means(lq_sel).items()})
            elif lq_sel:
                row["sel_readout_unavailable"] = lq_sel.get("unavailable")
        if r["cfg"]["kind"] == "cop":
            p = r["dir"] / "cop_chain_result.json"
            j = read_json(p) if p.exists() else {}
            row.update(_later_query_means(j.get("later_queries")))
            selected_readouts(row, j.get("later_queries_selected"))
            qa = j.get("quantizers_at_export") or []
            if qa:
                # the treated chain's fixed endpoint is its export: reported in the end_* columns, as for scratch
                row["message_bits_per_peg"] = msg_bits(qa)
                row["quant_end_clip_fraction_max"] = max((q.get("clip_fraction") or 0 for q in qa), default=None)
                row["quant_end_clip_edge_max"] = max((q.get("clip_fraction_edge") or 0 for q in qa), default=None)
                row["quant_end_distinct_messages"] = str([q.get("distinct_messages") for q in qa])
                row["quant_end_min_coordinate_entropy_bits"] = min(
                    (min(q.get("coordinate_entropy_bits") or [0]) for q in qa), default=None)
            qsel = j.get("quantizers_at_selected") or []
            if qsel:
                row["quant_selected_clip_fraction_max"] = max((q.get("clip_fraction") or 0 for q in qsel), default=None)
                row["quant_selected_distinct_messages"] = str([q.get("distinct_messages") for q in qsel])
            grads(row, j.get("gradients_at_export"), "end")
            grads(row, j.get("gradients_at_selected"), "selected")
            if j.get("quant_recipe"):
                row["quant_recipe"] = j["quant_recipe"].get("recipe")
        else:
            res = _cont_result(r)
            row.update(_later_query_means(res.get("later_queries")))
            selected_readouts(row, res.get("later_queries_selected"))
            au = res.get("reinit") or {}
            if au:
                qs, qe = au.get("quantizers_at_start") or [], au.get("quantizers_at_end") or []
                qsel = au.get("quantizers_at_selected") or []
                row["message_bits_per_peg"] = msg_bits(qs)
                row["reinit_unchanged_tensors"] = len(au.get("unchanged_after_reset") or [])
                row["quant_start_clip_fraction_max"] = max((q.get("clip_fraction") or 0 for q in qs), default=None)
                row["quant_end_clip_fraction_max"] = max((q.get("clip_fraction") or 0 for q in qe), default=None)
                row["quant_start_clip_edge_max"] = max((q.get("clip_fraction_edge") or 0 for q in qs), default=None)
                row["quant_end_clip_edge_max"] = max((q.get("clip_fraction_edge") or 0 for q in qe), default=None)
                row["quant_selected_clip_fraction_max"] = max((q.get("clip_fraction") or 0 for q in qsel), default=None)
                row["quant_start_distinct_messages"] = str([q.get("distinct_messages") for q in qs])
                row["quant_end_distinct_messages"] = str([q.get("distinct_messages") for q in qe])
                row["quant_selected_distinct_messages"] = str([q.get("distinct_messages") for q in qsel])
                row["quant_end_min_coordinate_entropy_bits"] = min(
                    (min(q.get("coordinate_entropy_bits") or [0]) for q in qe), default=None)
                row["quant_code_drift_start_to_end"] = str([q.get("code_change_fraction_from_start") for q in qe])
                row["quant_calibrated_at_start"] = all(q.get("calibrated") for q in qs) if qs else None
                for when in ("start", "end", "selected"):
                    grads(row, au.get(f"gradients_at_{when}"), when)
            qr = res.get("quant_recipe")
            if qr:
                row["quant_recipe"] = qr.get("recipe")
                row["quant_warmup_updates"] = qr.get("warmup_updates")
        out.append(row)
    return out


TREATMENT_VARIANTS = ("treated_lr0.3",)


def later_query_retention(rows: list[dict], rejected: Optional[list] = None) -> list[dict]:
    """M_E: original-task error and held-out later-query READOUT accuracy, treated versus each control.  Pairs
    are formed within one pairing unit (contrast, f0 run @ stage, replication, endpoint policy), as in the
    endpoint analysis, so seeds never overwrite each other and a treated model is never paired with another
    replication's control.  A duplicate arm in a unit rejects the unit's pairs for that arm; a control whose
    architecture differs from the treated one is rejected; treated_lr0.3 is labelled a treatment variant."""
    rej = rejected if rejected is not None else []
    units = defaultdict(lambda: defaultdict(list))
    for r in rows:
        if r["family"] != "M_Er":
            continue
        key = (r["contrast"], f"{r.get('f0_run')}@{r.get('f0_stage')}", r.get("replication"), r.get("endpoint_policy"))
        units[key][r["arm"]].append(r)
    out = []
    for key, arms in sorted(units.items(), key=lambda kv: tuple(str(x) for x in kv[0])):
        con, f0, rep, pol = key
        ts = arms.get("treated", [])
        if len(ts) != 1:
            rej.append({"contrast": con, "replication": rep, "arm": "treated",
                        "reason": "missing treated arm" if not ts else f"{len(ts)} treated rows in one pairing unit"})
            continue
        t = ts[0]
        for arm, cs in sorted(arms.items()):
            if arm == "treated":
                continue
            if len(cs) != 1:
                rej.append({"contrast": con, "replication": rep, "arm": arm,
                            "reason": f"{len(cs)} rows for this arm in one pairing unit"})
                continue
            c = cs[0]
            if c.get("architecture_hash") != t.get("architecture_hash"):
                rej.append({"contrast": con, "replication": rep, "arm": arm,
                            "reason": "control architecture differs from the treated endpoint"})
                continue
            row = {"contrast": con, "f0": f0, "replication": rep, "data_draw": t.get("data_draw"),
                   "optimizer_seed": t.get("optimizer_seed"), "endpoint_policy": pol, "control_arm": arm,
                   "comparison": "treatment_variant" if arm in TREATMENT_VARIANTS else "control",
                   "treated_run": t["run_id"], "control_run": c["run_id"],
                   "treated_test_risk": t.get("test_risk"), "control_test_risk": c.get("test_risk"),
                   "treated_test_err": t.get("test_err"), "control_test_err": c.get("test_err")}
            for k in t:
                if k.startswith(("readout_", "sel_readout_")) and k.endswith(
                        ("_acc", "_decoder", "_unseen_message_frac", "_train_messages", "_fit_examples", "_code_dim",
                         "_checkpoint")):
                    row[f"treated_{k}"], row[f"control_{k}"] = t.get(k), c.get(k)
            # like decoder families only: a readout difference across decoder classes also changes the procedure
            dk = [k for k in t if k.startswith("readout_") and k.endswith("_decoder")]
            row["same_decoder_class"] = all(t.get(k) == c.get(k) for k in dk) if dk else None
            out.append(row)
    return out


def finite_refit_table(runs: dict) -> list[dict]:
    """D3: model error, optimal-decoder (oracle) error and global optimum, before and after a decoder-only refit
    of the frozen code, with MAC-matching records."""
    out = []
    for rid, r in runs.items():
        d = r["cfg"].get("design") or {}
        p = r["dir"] / "cop_chain_result.json"
        if not str(d.get("family", "")).startswith("FIN_") or not p.exists():
            continue
        j = read_json(p)
        fi, dr, mm = j.get("finite_interface") or {}, j.get("decoder_refit") or {}, j.get("mac_matching") or {}
        row = {"run_id": rid, "family": d.get("family"), "variant": d.get("variant"), "arm": d.get("arm"),
               "contrast": d.get("contrast"), "applicable": fi.get("applicable"), "reason": fi.get("reason"),
               **_info(r["cfg"])}
        for k in ("e_model", "e_oracle", "e_star", "e_task_model", "e_task_oracle", "e_later_oracle",
                  "e_later_star_task_preserving", "distinct_messages", "message_capacity"):
            row[k] = fi.get(k)
        if dr:
            row["refit_updates"], row["refit_code_unchanged"] = dr["updates"], dr["code_unchanged"]
            for k, v in (dr.get("after") or {}).items():
                row[f"refit_{k}"] = v
            em, eo = (dr.get("before") or {}).get("e_model"), (dr.get("before") or {}).get("e_oracle")
            ea = (dr.get("after") or {}).get("e_model")
            if None not in (em, eo, ea) and em > eo:
                row["decoder_gap_closed_by_refit"] = (em - ea) / (em - eo)
        if mm:
            row["mac_reference_macs"] = mm.get("reference_macs")
            row["mac_achieved_over_reference"] = mm.get("achieved_over_reference")
            row["mac_planned_global_updates"] = mm.get("planned_global_updates")
        out.append(row)
    return out


def _func_agreement(m: dict) -> Optional[float]:
    """function / prediction disagreement with the checkpoint's reference model on val (nmse for regression,
    the argmax disagreement rate for classification)"""
    d = (m or {}).get("drift_vs_checkpoint") or {}
    return d.get("nmse", d.get("disagreement"))


def locality_controls_table(runs: dict) -> list[dict]:
    """D4: three separate notions of local recovery per scope-1 repair, checkpoint and tolerance (v15): task-risk
    recovery (first passage, final, sustained), function agreement with the reference model, and agreement of the
    transmitted integer code at the outgoing interface; next to the positive controls (original pearl spliced in,
    frozen-code lookup) and representation matching (the replacement trained on MSE to the old pre-quantiser
    values).  The reference model's own validation risk is reported beside every row; unreached tolerances are
    censored at the tested budget, not irreducible."""
    out = []
    for rid, r in runs.items():
        p = r["dir"] / "locality_result.json"
        if not p.exists() or r["status"]["status"] != "complete":
            continue
        j = read_json(p)
        cc = r["cfg"]["cop"]
        d = r["cfg"].get("design") or {}
        for rec in j["snapshots"]:
            ctl = rec.get("controls") or {}
            ex = ctl.get("exact_local_replacement") or {}
            cm = ctl.get("representation_match_scope1") or ctl.get("code_match_scope1") or {}
            s1 = (rec.get("scopes") or {}).get("1") or {}
            ref = (rec.get("reference") or {}).get("val") or {}
            ia1, iacm = s1.get("interface_agreement") or {}, cm.get("interface_agreement") or {}
            for tol, sm in rec["tolerances"].items():
                ps = sm["per_scope"]
                p1 = ps.get("1") or {}
                out.append({"run_id": rid, "contrast": d.get("contrast"), "interface": j["interface"],
                            "replication": _rk(r["cfg"]), "f0_run": (r["cfg"].get("parents") or {}).get("baseline"),
                            "replace_width": cc["replace_width"], "repair_updates": cc["locality_repair_updates"],
                            "checkpoint": rec["checkpoint"], "tolerance": float(tol),
                            "reference_val_risk": ref.get("mse", ref.get("loss")),
                            "task_scope1_first_passage_update": p1.get("first_update_reaching"),
                            "task_scope1_success_at_end": p1.get("success_at_end"),
                            "task_scope1_sustained": p1.get("sustained_from_first_passage"),
                            "task_scope1_dipped_after_passage": p1.get("dipped_after_first_passage"),
                            "task_scope1_lost_at_end": p1.get("lost_at_end"),
                            "task_smallest_successful_scope": sm["smallest_successful_tested_scope"],
                            "censored": sm["censored"],
                            "function_disagreement_scope1": _func_agreement((s1.get("final") or {}).get("val")),
                            "code_agreement_scope1": ia1.get("code_agreement"),
                            "representation_match_task_success": (cm.get("success") or {}).get(tol),
                            "representation_match_function_disagreement": _func_agreement(
                                (cm.get("final") or {}).get("val")),
                            "representation_match_code_agreement": iacm.get("code_agreement"),
                            "exact_replacement_matches_reference": ex.get("matches_reference"),
                            "frozen_code_lookup_matches_reference": (ctl.get("frozen_code_lookup") or {})
                            .get("matches_reference"),
                            "exact_replacement_certificate_all_equal": (ex.get("certificate") or {}).get("all_equal"),
                            "certificate_coverage": (ex.get("certificate") or {}).get("coverage"),
                            "note": rec.get("censoring_note")})
    return out


REFERENCE_MATCH_REL_TOL = 0.05     # v17: references count as performance-matched within 5% relative risk


def locality_performance_matched(rows: list[dict], rel_tol: float = REFERENCE_MATCH_REL_TOL) -> list[dict]:
    """v15 / v17: the no-peg and pegged reference models start from different validation risks, and a poorer
    reference can be easier to match.  For each pegged row, the no-peg row (same width, repair budget and
    tolerance; any checkpoint, the SAME replication and f0) whose reference risk is closest is placed beside it.
    The pair counts as performance-matched only if |gap| <= rel_tol x the pegged reference risk; otherwise it is
    reported as the nearest available reference and `performance_matched` is False (no matched claim)."""
    out = []
    nopeg = [r for r in rows if r["interface"] == "none" and r.get("reference_val_risk") is not None]
    for r in rows:
        if r["interface"] == "none" or r.get("reference_val_risk") is None:
            continue
        cands = [q for q in nopeg if q["replace_width"] == r["replace_width"] and
                 q["repair_updates"] == r["repair_updates"] and q["tolerance"] == r["tolerance"]
                 and q["replication"] == r["replication"] and q["f0_run"] == r["f0_run"]]   # within one replication
        if not cands:
            continue
        q = min(cands, key=lambda q: abs(q["reference_val_risk"] - r["reference_val_risk"]))
        gap = r["reference_val_risk"] - q["reference_val_risk"]
        rel = abs(gap) / max(abs(r["reference_val_risk"]), 1e-12)
        out.append({"pegged_run": r["run_id"], "replication": r["replication"], "interface": r["interface"],
                    "replace_width": r["replace_width"],
                    "repair_updates": r["repair_updates"], "tolerance": r["tolerance"],
                    "pegged_checkpoint": r["checkpoint"], "pegged_reference_val_risk": r["reference_val_risk"],
                    "pegged_smallest_scope": r["task_smallest_successful_scope"],
                    "pegged_scope1_sustained": r.get("task_scope1_sustained"),
                    "nopeg_run": q["run_id"], "nopeg_checkpoint": q["checkpoint"],
                    "nopeg_reference_val_risk": q["reference_val_risk"],
                    "nopeg_smallest_scope": q["task_smallest_successful_scope"],
                    "nopeg_scope1_sustained": q.get("task_scope1_sustained"),
                    "reference_risk_gap": gap, "reference_risk_rel_gap": rel,
                    "performance_matched": rel <= rel_tol, "match_rule": f"|gap| <= {rel_tol:g} x pegged risk"})
    return out


def _truthy(v) -> Optional[bool]:
    if v is None or v == "":
        return None
    return v if isinstance(v, bool) else str(v).lower() == "true"


def locality_outcome_summary(rows: list[dict]) -> list[dict]:
    """v17: per (interface, width, repair budget, tolerance, checkpoint), over replications: scope-1 task success
    at the end, sustained success, found-then-lost (a first passage, then failing at the end: a feasible repair
    was found, so the end failure is not irreducibility) and censoring; plus mean function disagreement and
    transmitted-code agreement, which stay separate from task recovery."""
    g = defaultdict(list)
    for r in rows:
        g[(r["interface"], r["replace_width"], r["repair_updates"], r["tolerance"], r["checkpoint"])].append(r)
    out = []
    for (itf, w, ru, tol, ck), rs in sorted(g.items(), key=lambda kv: tuple(str(x) for x in kv[0])):
        n = len(rs)
        fp = [r for r in rs if r.get("task_scope1_first_passage_update") not in (None, "")]
        end = [r for r in rs if _truthy(r.get("task_scope1_success_at_end"))]
        lost = [r for r in fp if not _truthy(r.get("task_scope1_success_at_end"))]

        def mean(k):
            xs = [float(r[k]) for r in rs if r.get(k) not in (None, "")]
            return sum(xs) / len(xs) if xs else None
        out.append({"interface": itf, "replace_width": w, "repair_updates": ru, "tolerance": tol, "checkpoint": ck,
                    "n_replications": n, "scope1_first_passage": len(fp), "scope1_success_at_end": len(end),
                    "scope1_sustained": sum(bool(_truthy(r.get("task_scope1_sustained"))) for r in rs),
                    "scope1_found_then_lost": len(lost),
                    "censored_any_scope": sum(bool(_truthy(r.get("censored"))) for r in rs),
                    "mean_function_disagreement_scope1": mean("function_disagreement_scope1"),
                    "mean_code_agreement_scope1": mean("code_agreement_scope1"),
                    "mean_reference_val_risk": mean("reference_val_risk")})
    return out


def frozen_sweep_table(runs: dict) -> list[dict]:
    """v15 (Families 1 / 4): the expanded checkpoint with every weight frozen, before any repair: intact, the
    removal targets' gates scaled to 0.75 / 0.5 / 0.25 / 0, the deletion of EVERY implant alone (branches inside a
    group included, labelled by kind / slot / parent) and the joint deletion of the targets."""
    out = []
    for rid, r in runs.items():
        p = r["dir"] / "dissipation_result.json"
        if r["cfg"]["kind"] != "dissipation" or not p.exists():
            continue
        fs = read_json(p).get("frozen_weight_sweep")
        if not fs:
            continue
        d = r["cfg"].get("design") or {}
        hy = (r["cfg"].get("dissipation") or {}).get("hybrid") or {}
        hy = hy if hy.get("donor_role") else {}          # the resolved default (no donor) is not a hybrid
        conds = [("intact", fs.get("intact"))] + [(f"gate_{k}", v) for k, v in (fs.get("gate_scale") or {}).items()] \
            + [(f"delete_{t}", v) for t, v in (fs.get("single_deletion") or {}).items()] \
            + ([("delete_all", fs["joint_deletion"])] if fs.get("joint_deletion") else [])
        for name, sc in conds:
            row = {"run_id": rid, "contrast": d.get("contrast"), "arm": d.get("arm"), "condition": name,
                   "variant": d.get("variant"), "replication": _rk(r["cfg"]),
                   "targets": " ".join(fs.get("targets") or []),
                   "receiver_stage": ((r["cfg"].get("tags") or {}).get("parent_stage") or "final"),
                   "hybrid_donor_stage": hy.get("donor_stage"), "hybrid_slots": " ".join(hy.get("slots") or [])
                   if hy else None}
            if name.startswith("delete_") and name != "delete_all":
                t = name[len("delete_"):]
                # a branch deleted alone vs a whole group (deleting a parent deletes its descendants)
                row.update({"implant": t, "implant_kind": (fs.get("kinds") or {}).get(t),
                            "implant_slot": (fs.get("slots") or {}).get(t),
                            "implant_parent": (fs.get("parents") or {}).get(t),
                            "is_removal_target": t in (fs.get("targets") or [])})
                dm = (fs.get("damage_by_membership") or {}).get(t)
                if dm:
                    # v19: training-set damage of deleting this branch on its own partition vs the others
                    row.update({f"membership_{k}": v for k, v in dm.items()})
            if sc and "error" in sc:
                row["error"] = sc["error"]
            else:
                for part, v in (sc or {}).items():
                    row[f"{part}_risk"] = v.get("risk")
                    row[f"{part}_err"] = v.get("err")
            out.append(row)
    return out


def _sweep_scores(fs: dict, cond: str) -> dict:
    sc = (fs or {}).get(cond) if cond != "joint_deletion" else (fs or {}).get("joint_deletion")
    sc = sc or {}
    return {"val_risk": (sc.get("val") or {}).get("risk"), "test_err": (sc.get("test") or {}).get("err"),
            "test_risk": (sc.get("test") or {}).get("risk"), "rare_err": (sc.get("rare") or {}).get("err")}


# v20 (review item 7): declared recovery targets for the repair curves (validation decides, test is reported at
# the first evaluated update that reaches the target).  Three different estimands:
#   f0         the original task performance: val risk <= f0's val risk x (1 + RECOVERY_RTOL)
#   receiver   the recipient's own task performance: val risk <= the receiver's val risk x (1 + RECOVERY_RTOL)
#   imitation  the recipient's FUNCTION: val output RMS distance from the receiver <= IMITATION_REL_RMS x the
#              RMS of the receiver's val outputs
# v23: what the shortcut splits measure (cop/data/synthetic.build_shortcut); the "test" columns are NOT IID
TEST_SPLIT_MEANING = {"shortcut": "test = shortcut independent of the label (training and val: shortcut agrees with "
                                  "probability rho_train); shift = reversed correlation; rare = rare group only, "
                                  "shortcut independent; cf_* = paired single-feature interventions"}
RECOVERY_RTOL = 0.02
IMITATION_REL_RMS = 0.1
IMITATION_FLIP = 0.05          # v22: decision imitation: at most 5 % of val decisions differ from the receiver's
IMITATION_TV = 0.05            # v22: probability imitation: mean total-variation distance at most 0.05


def repair_curve(j: dict) -> dict:
    """first evaluated update of the COMPACT phase (from the last removal event on) reaching each declared recovery
    target, the test risk there, final success at the exported state and censoring (never reached)."""
    path = j.get("path") or []
    ref = j.get("recovery_reference") or {}
    out = {"recovery_rtol": RECOVERY_RTOL, "imitation_rel_rms": IMITATION_REL_RMS,
           "imitation_flip": IMITATION_FLIP, "imitation_tv": IMITATION_TV}
    # the compact phase starts at the LAST removal event (every target gone): a physical removal after a gated
    # transition, an abrupt deletion, a fold or a deletion after a penalty / merge; else the exported point only
    ev_prefix = ("physically_removed_", "after_abrupt_delete_", "after_delete_", "after_fold")
    last = max((i for i, pt in enumerate(path) if str(pt.get("tag", "")).startswith(ev_prefix)), default=None)
    if last is None:
        last = next((i for i, pt in enumerate(path) if pt.get("tag") == "exported"), None)
    compact = path[last:] if last is not None else []
    tests = {}
    if ref.get("f0_val_risk") is not None:
        tests["f0"] = lambda pt: pt.get("val_risk") is not None and \
            pt["val_risk"] <= ref["f0_val_risk"] * (1 + RECOVERY_RTOL)
    if ref.get("receiver_val_risk") is not None:
        tests["receiver"] = lambda pt: pt.get("val_risk") is not None and \
            pt["val_risk"] <= ref["receiver_val_risk"] * (1 + RECOVERY_RTOL)
    if ref.get("receiver_val_out_rms") is not None:
        tests["imitation"] = lambda pt: pt.get("val_rms_drift_from_receiver") is not None and \
            pt["val_rms_drift_from_receiver"] <= IMITATION_REL_RMS * ref["receiver_val_out_rms"]
    if any("val_flip_rate_from_receiver" in pt for pt in path):
        tests["decision_imitation"] = lambda pt: pt.get("val_flip_rate_from_receiver") is not None and \
            pt["val_flip_rate_from_receiver"] <= IMITATION_FLIP
        tests["probability_imitation"] = lambda pt: pt.get("val_tv_from_receiver") is not None and \
            pt["val_tv_from_receiver"] <= IMITATION_TV
    if compact:
        for k in ("val_flip_rate_from_receiver", "val_tv_from_receiver", "val_kl_receiver_to_model",
                  "val_rms_drift_from_receiver"):
            if k in compact[-1]:
                out[f"final_{k}"] = compact[-1][k]
    for nm, ok in tests.items():
        hit = next((pt for pt in compact if ok(pt)), None)
        out[f"recovery_{nm}_first_update"] = hit["update"] if hit else None
        out[f"recovery_{nm}_test_risk_at_first"] = hit.get("test_risk") if hit else None
        out[f"recovery_{nm}_final_success"] = bool(ok(compact[-1])) if compact else None
        out[f"recovery_{nm}_censored"] = hit is None
    out.update({f"reference_{k}": v for k, v in ref.items()})
    out["path_points_compact"] = len(compact)
    return out


def swap_table(runs: dict, E: list[dict]) -> list[dict]:
    """v19 swaps (family SW): one row per removal, with the start state's identity (receiver lineage and stage,
    donor stage and swapped slots), the FROZEN start (intact and every implant removed) and the repaired
    endpoint.  Rows of plain removals (ages) are the references for the hybrids built from the same states."""
    byrun = {e["run_id"]: e for e in E}
    out = []
    for rid, r in runs.items():
        d = r["cfg"].get("design") or {}
        if d.get("family") != "SW" or r["cfg"]["kind"] != "dissipation":
            continue
        p = r["dir"] / "dissipation_result.json"
        j = read_json(p) if p.exists() else {}
        fs = j.get("frozen_weight_sweep") or {}
        hy = j.get("hybrid") or {}
        e = byrun.get(rid, {})
        row = {"run_id": rid, "contrast": d.get("contrast"), "variant": d.get("variant"), "arm": d.get("arm"),
               "replication": _rk(r["cfg"]),
               "receiver_lineage": str(d.get("contrast", "")).rsplit("|", 1)[-1],
               "receiver_stage": (r["cfg"].get("tags") or {}).get("parent_stage", "final"),
               "donor_stage": hy.get("donor_stage"), "swapped_slots": " ".join(hy.get("slots") or []) or None,
               "swapped_values": hy.get("values_copied"), "receiver_minus_donor_rel_l2": hy.get("receiver_minus_donor_rel_l2"),
               "receiver_run": (r["cfg"].get("parents") or {}).get("trajectory"),
               "donor_run": (r["cfg"].get("parents") or {}).get("donor"),
               "removal_masks": (j.get("removal_policy") or {}).get("masks"),
               "gate_schedule": (j.get("removal_policy") or {}).get("gate_schedule")}
        ages = (hy.get("receiver_branch_ages") if hy else j.get("branch_ages")) or {}
        row["receiver_branch_ages"] = " ".join(f"{k}={v}" for k, v in sorted((ages.get("ages") or {}).items())) or None
        dag = (hy.get("donor_branch_ages") or {}) if hy else {}
        row["donor_branch_ages"] = " ".join(f"{k}={v}" for k, v in sorted((dag.get("ages") or {}).items())) or None
        for k, v in _sweep_scores(fs, "intact").items():
            row[f"frozen_intact_{k}"] = v
        for k, v in _sweep_scores(fs, "joint_deletion").items():
            row[f"frozen_removed_{k}"] = v
        for k in ("test_err", "test_risk", "rare_err", "sel_test_err", "sel_test_risk"):
            row[f"repaired_{k}"] = e.get(k)
        row.update(repair_curve(j))
        out.append(row)
    return out


def swap_scan_table(runs: dict) -> list[dict]:
    """v20: one row per subset of the branch players in every swap scan (frozen, raw and aligned), with the
    receiver / donor identities and native scores; the empty subset is the receiver itself."""
    out = []
    for rid, r in runs.items():
        if r["cfg"]["kind"] != "dissipation":
            continue
        p = r["dir"] / "dissipation_result.json"
        if not p.exists():
            continue
        j = read_json(p)
        sc = j.get("swap_scan")
        if not sc:
            continue
        d = r["cfg"].get("design") or {}
        par = r["cfg"].get("parents") or {}
        nat = sc.get("native") or {}
        base = {"run_id": rid, "contrast": d.get("contrast"), "variant": d.get("variant"), "replication": _rk(r["cfg"]),
                "receiver_run": par.get("trajectory"), "receiver_stage": sc.get("receiver_stage"),
                "donor_run": par.get(sc.get("donor_role")), "donor_stage": sc.get("donor_stage"),
                "players": " ".join(sc.get("players") or []), "backbone_params": sc.get("backbone_params"),
                "subset_params_note": ("aligned_adapter_params = fitted values (capacity of the alignment fit); the map "
                                       "is folded into the branch's last linear layer, so it adds no inference "
                                       "parameters or MACs; aligned_adapter_fit_macs = fitting work")}
        for who in ("receiver", "donor"):
            for part, v in (nat.get(who) or {}).items():
                base[f"{who}_native_{part}_risk"] = v.get("risk")
                base[f"{who}_native_{part}_err"] = v.get("err")
        for x in sc.get("subsets") or []:
            row = {**base, "subset": " ".join(x["subset"]) or "(none: receiver)", "n_players": x["n_players"],
                   "values_copied": x["values_copied"],
                   "subset_branch_params": sum((sc.get("player_params") or {}).get(sl, 0) for sl in x["subset"])}
            for cond in ("raw", "aligned"):
                v = x.get(cond)
                if not v:
                    continue
                for part in ("val", "test"):
                    if part in v:
                        row[f"{cond}_{part}_risk"] = v[part].get("risk")
                        row[f"{cond}_{part}_err"] = v[part].get("err")
                row.update({f"{cond}_{k}": val for k, val in (v.get("function") or {}).items()})
                if cond == "aligned":
                    ad = v.get("adapter") or {}
                    row["aligned_adapter_params"] = ad.get("params")
                    row["aligned_adapter_fit_seconds"] = ad.get("fit_seconds")
                    row["aligned_adapter_solve_macs"] = ad.get("solve_macs")
                    row["aligned_adapter_fit_macs"] = ad.get("fit_macs_total")
                    row["aligned_adapter_train_examples"] = ad.get("train_examples")
                    # v34: the per-branch fit status (results before v34 have none: None)
                    row["aligned_adapter_ok"] = ad.get("ok")
                    for k_ in ("fitted", "identity_fallback", "unsupported", "numerical_failure"):
                        row[f"aligned_adapter_n_{k_}"] = (ad.get("status_counts") or {}).get(k_)
            out.append(row)
    return out


def reassignment_table(runs: dict, E: list[dict]) -> list[dict]:
    """v19 / v20 reassignment (family RA): per arm, the schedule and its realised dose (events, examples moved
    with their denominators, ever moved, away from the initial split at the end), the empirical exposure of each
    branch, the expanded model before removal (frozen), with all additions removed (frozen), the mean
    END-ASSIGNMENT damage of deleting one branch (own partition vs the others, under the split in force at the
    end) and, when it differs, the damage under the INITIAL split, the repaired endpoint and C1 on the same
    budget.  The per-batch redrawn reference (other end of the schedule) is joined from the swap block's end-state
    removal of the redrawn lineage (same cell, draws and removal protocol), marked as a shared reference."""
    byrun = {e["run_id"]: e for e in E}
    c1 = {}
    for rid, r in runs.items():
        d = r["cfg"].get("design") or {}
        if d.get("family") in ("RA", "SW") and d.get("arm") == "C1":
            c1[(d.get("contrast"), _rk(r["cfg"]))] = byrun.get(rid, {})
    out = []
    for rid, r in runs.items():
        d = r["cfg"].get("design") or {}
        # v20: the per-batch redrawn reference lives in the swap block (SW, end-state removal of the redrawn
        # lineage, same cell, draws and removal protocol); it is joined here as a shared reference row, not an
        # independent observation
        is_ref = (d.get("family") == "SW" and d.get("variant") == "redrawn_age_end" and d.get("arm") == "treated")
        if (d.get("family") != "RA" and not is_ref) or r["cfg"]["kind"] != "dissipation":
            continue
        j = read_json(r["dir"] / "dissipation_result.json") if (r["dir"] / "dissipation_result.json").exists() else {}
        fs = j.get("frozen_weight_sweep") or {}
        e = byrun.get(rid, {})
        g = r["cfg"].get("growth") or {}
        ra = g.get("spec_reassign") or {}
        row = {"run_id": rid, "contrast": d.get("contrast"), "variant": "redrawn_every_batch" if is_ref else d.get("variant"),
               "reference_from": "SW block (shared reference, not an independent observation)" if is_ref else None,
               "replication": _rk(r["cfg"]), "spec_partition": g.get("spec_partition"),
               "reassign_mode": "redrawn_every_batch" if is_ref else ra.get("mode"), "reassign_start": ra.get("start"),
               "reassign_period": ra.get("period"), "reassign_fraction": ra.get("fraction"),
               "reassign_fraction_denominator": "smaller side's examples" if ra.get("mode") not in (None, "none") else None}
        tp = runs.get((r["cfg"].get("parents") or {}).get("trajectory"))
        if tp is not None:
            tj = _traj_result(tp)
            sr = tj.get("spec_reassign") or {}
            evs = sr.get("events") or []
            row.update({"reassign_events": len(evs),
                        "examples_moved_total": sum(x.get("examples_moved", 0) for x in evs),
                        "moved_fraction_of_training_set_total": sum(x.get("moved_fraction_of_training_set", 0)
                                                                    for x in evs),
                        "ever_moved_fraction": sr.get("ever_moved_fraction"),
                        "away_from_initial_at_end_fraction": sr.get("final_differs_from_initial_fraction")})
            ex = tj.get("spec_exposure") or {}
            if ex.get("examples"):
                row["exposure_branch_a_fraction"] = ex.get("branch_a", 0) / ex["examples"]
                row["exposure_branch_b_fraction"] = ex.get("branch_b", 0) / ex["examples"]
        for k, v in _sweep_scores(fs, "intact").items():
            row[f"frozen_intact_{k}"] = v
        for k, v in _sweep_scores(fs, "joint_deletion").items():
            row[f"frozen_removed_{k}"] = v
        dm = [x for x in (fs.get("damage_by_membership") or {}).values() if not x.get("not_applicable")]
        for k in ("own_err_increase", "other_err_increase", "own_loss_increase", "other_loss_increase"):
            xs = [x[k] for x in dm if x.get(k) is not None]
            row[f"end_assignment_mean_{k}"] = sum(xs) / len(xs) if xs else None
            xs = [x[f"initial_{k}"] for x in dm if x.get(f"initial_{k}") is not None]
            row[f"initial_assignment_mean_{k}"] = sum(xs) / len(xs) if xs else None
        for k in ("test_err", "test_risk", "rare_err", "sel_test_err"):
            row[f"repaired_{k}"] = e.get(k)
        c = c1.get((d.get("contrast"), _rk(r["cfg"])), {})
        row["c1_test_err"] = c.get("test_err")
        row["G_test_err"] = (c["test_err"] - e["test_err"]) if c.get("test_err") is not None and \
            e.get("test_err") is not None else None
        rp = (j.get("removal_policy") or {})
        row.update({f"removal_{k}": v for k, v in rp.items()})
        out.append(row)
    return out


def early_repair(j: dict, offsets=(1, 2, 4, 8, 16, 32, 64, 128, 256)) -> dict:
    """v22: val / test risk at fixed offsets after the last removal event (dense early repair evaluation)."""
    path = j.get("path") or []
    ev_prefix = ("physically_removed_", "after_abrupt_delete_", "after_delete_", "after_fold")
    last = max((i for i, pt in enumerate(path) if str(pt.get("tag", "")).startswith(ev_prefix)), default=None)
    out = {}
    if last is None:
        return out
    u0 = path[last]["update"]
    at = {pt["update"] - u0: pt for pt in path[last:]}
    out["post_removal_val_risk_at_0"] = path[last].get("val_risk")
    out["post_removal_test_risk_at_0"] = path[last].get("test_risk")
    for k in offsets:
        pt = at.get(k)
        out[f"post_removal_val_risk_at_{k}"] = pt.get("val_risk") if pt else None
        out[f"post_removal_test_risk_at_{k}"] = pt.get("test_risk") if pt else None
    return out


def _removal_row(r: dict, e: dict) -> tuple[dict, dict]:
    p = r["dir"] / "dissipation_result.json"
    j = read_json(p) if p.exists() else {}
    fs = j.get("frozen_weight_sweep") or {}
    row = {}
    for k, v in _sweep_scores(fs, "intact").items():
        row[f"frozen_intact_{k}"] = v
    for k, v in _sweep_scores(fs, "joint_deletion").items():
        row[f"frozen_removed_{k}"] = v
    # v22: IID test, rare group and shifted set kept separate, final and validation-selected
    for k in ("test_err", "test_risk", "rare_err", "shift_err", "cf_shortcut_err", "cf_causal_err",
              "sel_test_err", "sel_test_risk", "sel_rare_err", "sel_shift_err", "sel_cf_shortcut_err",
              "sel_cf_causal_err"):
        row[f"repaired_{k}"] = e.get(k)
    row["selection_candidates"] = _n_candidates(r)
    # v31: what the endpoint is: a compact network (every removal) or the native expanded model (method keep)
    kept = (r["cfg"].get("dissipation") or {}).get("method") == "keep"
    row["endpoint_kind"] = "native_expanded" if kept else "compact"
    row["endpoint_macs"] = j.get("export_macs")
    row["endpoint_architecture_equals_f0"] = j.get("export_architecture_equals_f0")
    row.update(repair_curve(j))
    row.update(early_repair(j))
    return row, j


FRESH_DRAWS_V22 = (203, 204, 205)


DISCOVERY_DRAWS = (0, 201, 202)


def draw_role(cfg: dict) -> str:
    """v31, the one shared rule: the role declared in the job's design (confirmation / exploratory, waves 21+);
    otherwise the legacy rule: discovery = draws 0, 201, 202 at optimizer seed 0 (chosen after looking at
    results), fresh = draws 203-205 (wave 18 onwards), other = anything else."""
    r = (cfg.get("design") or {}).get("role")
    if r:
        return r
    ds = (cfg.get("data") or {}).get("data_seed")
    os_ = (cfg.get("seeds") or {}).get("optimizer")
    if ds in DISCOVERY_DRAWS and os_ in (0, None):
        return "discovery"
    return "fresh" if ds in FRESH_DRAWS_V22 else "other"


def _draw_meta(cfg: dict) -> dict:
    """v23: the data draw, its role (see draw_role) and the partition seed: partition seeds are replications
    WITHIN a data draw (pair and cluster at the draw level)."""
    ds = (cfg.get("data") or {}).get("data_seed")
    return {"data_draw": ds, "draw_set": draw_role(cfg),
            "partition_seed": (cfg.get("seeds") or {}).get("partition"),
            "optimizer_seed": (cfg.get("seeds") or {}).get("optimizer")}


def _n_candidates(r: dict) -> Optional[int]:
    """the ACTUAL number of validation-selection candidates of a job (endpoint_best_val.json)."""
    p = r["dir"] / "endpoint_best_val.json"
    if not p.exists():
        return None
    j = read_json(p)
    if j.get("n_candidates") is not None:
        return int(j["n_candidates"])
    return len(((j.get("selection") or {}).get("candidates")) or []) or None


def persistence_table(runs: dict, E: list[dict]) -> list[dict]:
    """v22 (family PE): one row per removal: the gradient-assignment schedule (fixed, per-batch redrawn, 10 %
    periodic exchange, cyclic blocks of period T with equal exposure), the realised per-example exposure, frozen
    damage, repaired endpoint, repair curve with dense early points, and the draw's C1 (G = C1 - treated)."""
    byrun = {e["run_id"]: e for e in E}
    c1 = {}
    for rid, r in runs.items():
        d = r["cfg"].get("design") or {}
        if d.get("family") == "PE" and d.get("arm") == "C1":
            c1[_rk(r["cfg"])] = byrun.get(rid, {})
    c2 = {}
    for rid, r in runs.items():
        d = r["cfg"].get("design") or {}
        if d.get("family") == "PE" and d.get("arm") == "C2":
            c2[_rk(r["cfg"])] = byrun.get(rid, {})
    out = []
    for rid, r in runs.items():
        d = r["cfg"].get("design") or {}
        if d.get("family") != "PE" or r["cfg"]["kind"] != "dissipation":
            continue
        e = byrun.get(rid, {})
        g = r["cfg"].get("growth") or {}
        row = {"run_id": rid, "variant": d.get("variant"), "replication": _rk(r["cfg"]), **_draw_meta(r["cfg"]),
               "trajectory_run": (r["cfg"].get("parents") or {}).get("trajectory"),
               "spec_partition": g.get("spec_partition"), "period": g.get("spec_block_period") or None,
               "reassign_mode": (g.get("spec_reassign") or {}).get("mode")}
        tp = runs.get(row["trajectory_run"])
        if tp is not None:
            tj = _traj_result(tp)
            cy = tj.get("spec_cyclic") or {}
            row.update({f"cyclic_{k}": cy.get(k) for k in ("updates_in_a_per_cycle", "cycle_share_a", "whole_cycles",
                                                           "per_example_share_a_min", "per_example_share_a_max")})
            ex = tj.get("spec_exposure") or {}
            if ex.get("examples"):
                row["exposure_branch_a_fraction"] = ex.get("branch_a", 0) / ex["examples"]
            pe = tj.get("spec_exposure_per_example") or {}
            row["eligible_share_a_mean"] = pe.get("share_a_mean")
            row["eligible_share_a_std"] = pe.get("share_a_std")
            for qk, qv in (pe.get("share_a_quantiles") or {}).items():
                row[f"eligible_share_a_{qk}"] = qv
            row["eligible_examples_never_on_b"] = pe.get("examples_never_on_b")
            for br, d_ in (pe.get("by_physical_branch") or {}).items():
                tag = br.replace("spec/", "")
                row[f"eligible_share_a_mean_{tag}"] = d_.get("share_a_mean")
                row[f"eligible_share_a_std_{tag}"] = d_.get("share_a_std")
            sq = tj.get("spec_quota") or {}
            if sq:
                fr = (g.get("spec_quota") or {})
                row["quota_family"] = f"q{int(round(100 * float(fr.get('fraction', 0))))}"
                row["quota_b_run"] = fr.get("b_run")
                row["stream_hashes"] = " ".join(f"{w}:{v['stream_hash']}" for w, v in sorted(sq.items()))
                row["quota_hashes"] = " ".join(f"{w}:{v['quota_hash']}" for w, v in sorted(sq.items()))
                row["quota_share_a"] = " ".join(f"{w}:{v['quota_share_a']:.4f}" for w, v in sorted(sq.items()))
                row["b_runs_mean"] = " ".join(f"{w}:{v['b_runs_mean']:.2f}" for w, v in sorted(sq.items())
                                              if v.get("b_runs_mean") is not None)
        rr, _ = _removal_row(r, e)
        row.update(rr)
        c = c1.get(_rk(r["cfg"]), {})
        row["c1_test_err"] = c.get("test_err")
        row["c1_sel_test_err"] = c.get("sel_test_err")
        row["G_test_err"] = (c["test_err"] - e["test_err"]) if c.get("test_err") is not None and \
            e.get("test_err") is not None else None
        # v22: the compute-matched compact control (same training MACs as the fixed-split treatment of the draw)
        c_ = c2.get(_rk(r["cfg"]), {})
        row["c2_test_err"] = c_.get("test_err")
        row["c2_sel_test_err"] = c_.get("sel_test_err")
        row["removal_transition_updates"] = (r["cfg"].get("dissipation") or {}).get("speed_updates")
        row["post_removal_repair_updates"] = (r["cfg"].get("dissipation") or {}).get("post_updates")
        row["test_split"] = TEST_SPLIT_MEANING.get((r["cfg"].get("data") or {}).get("name"))
        out.append(row)
    # v23: within one replication and quota family, every arm must have the same stream and the same quotas
    grp = {}
    for row in out:
        if row.get("quota_family"):
            grp.setdefault((row["replication"], row["quota_family"]), set()).add((row.get("stream_hashes"),
                                                                                row.get("quota_hashes")))
    for row in out:
        if row.get("quota_family"):
            row["quota_matched_within_family"] = len(grp[(row["replication"], row["quota_family"])]) == 1
    return out


def etd_table(runs: dict, E: list[dict]) -> list[dict]:
    """v22 / v23 (family PE, arms ETD_*): the example-tied dropout comparator (Maini et al. 2023): its native
    test-time function (memorization neurons dropped) right after the dropout phase, the dense early repair path
    after the drop, and the endpoint after the drop-and-regrow repair; beside the draw's fixed-split removal and
    C1.  Selected endpoints are compared only when both jobs had the same number of selection candidates."""
    byrun = {e["run_id"]: e for e in E}
    ref = {}
    for rid, r in runs.items():
        d = r["cfg"].get("design") or {}
        if d.get("family") == "PE" and r["cfg"]["kind"] == "dissipation" and d.get("variant") == "fixed":
            ref[_rk(r["cfg"])] = (byrun.get(rid, {}), _n_candidates(r))
        if d.get("family") == "PE" and d.get("arm") == "C1":
            ref[("C1", _rk(r["cfg"]))] = (byrun.get(rid, {}), _n_candidates(r))
    out = []
    for rid, r in runs.items():
        cc = r["cfg"].get("continue") or {}
        if r["cfg"]["kind"] != "continue" or cc.get("arm") != "example_tied_dropout":
            continue
        d = r["cfg"].get("design") or {}
        e = byrun.get(rid, {})
        p = r["dir"] / "continue_result.json"
        j = read_json(p) if p.exists() else {}
        et = j.get("example_tied_dropout") or {}
        nat = (et.get("native") or {}).get("metrics") or {}
        ph = et.get("phase_updates") or {}
        pc = (et.get("native") or {}).get("phase_cost") or {}
        row = {"run_id": rid, "arm": d.get("arm"), "replication": _rk(r["cfg"]), **_draw_meta(r["cfg"]),
               "reinit": cc.get("reinit"),
               "p_gen": et.get("p_gen"), "p_mem": et.get("p_mem"),
               "dropout_phase_updates": ph.get("dropout_phase"), "removal_transition_updates": ph.get("removal_transition"),
               "post_removal_repair_updates": ph.get("post_removal_repair"),
               "native_phase_train_macs": pc.get("train_macs"), "repair_semantics": et.get("repair_semantics"),
               "test_split": TEST_SPLIT_MEANING.get((r["cfg"].get("data") or {}).get("name"))}
        for part in ("val", "test", "rare", "shift", "cf_shortcut", "cf_causal", "cf_base"):
            m = nat.get(part) or {}
            if "acc" in m:
                row[f"native_{part}_err"] = 1.0 - m["acc"]
        for k in ("test_err", "rare_err", "shift_err", "cf_shortcut_err", "cf_causal_err", "sel_test_err",
                  "sel_rare_err", "sel_shift_err", "sel_cf_shortcut_err", "sel_cf_causal_err"):
            row[f"repaired_{k}"] = e.get(k)
        for pt in et.get("repair_path") or []:
            k_ = pt["offset_from_drop"]
            row[f"post_drop_val_risk_at_{k_}"] = pt.get("val_risk")
            row[f"post_drop_test_risk_at_{k_}"] = pt.get("test_risk")
            if "val_flip_rate_from_native_at_drop" in pt:
                row[f"post_drop_flip_from_native_at_{k_}"] = pt["val_flip_rate_from_native_at_drop"]
        n_me = _n_candidates(r)
        f, n_f = ref.get(_rk(r["cfg"]), ({}, None))
        c1, n_c1 = ref.get(("C1", _rk(r["cfg"])), ({}, None))
        row["selection_candidates"] = n_me
        row["fixed_removal_selection_candidates"] = n_f
        row["fixed_removal_test_err"] = f.get("test_err")
        row["c1_test_err"] = c1.get("test_err")
        comparable = n_me is not None and n_me == n_f
        row["selected_comparable_with_fixed_removal"] = comparable
        row["fixed_removal_sel_test_err"] = f.get("sel_test_err") if comparable else None
        if not comparable:
            row["selected_note"] = (f"selected endpoints not compared: {n_me} candidates here, {n_f} in the fixed "
                                    f"removal")
        out.append(row)
    return out


def backbone_table(runs: dict, E: list[dict]) -> list[dict]:
    """v22 (family BB): rebuilt start states (untouched f0 backbone with fresh or trained branches; trained
    backbone with fresh branches) beside the plain removal of the same trajectory (family PE, same protocol)."""
    byrun = {e["run_id"]: e for e in E}
    plain = {}
    for rid, r in runs.items():
        d = r["cfg"].get("design") or {}
        if d.get("family") == "PE" and r["cfg"]["kind"] == "dissipation":
            plain[(r["cfg"].get("parents") or {}).get("trajectory")] = (rid, byrun.get(rid, {}))
    out = []
    for rid, r in runs.items():
        d = r["cfg"].get("design") or {}
        if d.get("family") != "BB" or r["cfg"]["kind"] != "dissipation":
            continue
        e = byrun.get(rid, {})
        tr_id = (r["cfg"].get("parents") or {}).get("trajectory")
        rb = (r["cfg"].get("dissipation") or {}).get("rebuild") or {}
        row = {"run_id": rid, "lineage": d.get("variant"), "start_state": d.get("arm"), "replication": _rk(r["cfg"]),
               **_draw_meta(r["cfg"]),
               "trajectory_run": tr_id, "backbone": rb.get("backbone"), "implants": rb.get("implants")}
        rr, j = _removal_row(r, e)
        row.update(rr)
        row["rebuild_max_abs_diff_from_f0_val"] = (j.get("rebuild") or {}).get("max_abs_diff_from_f0_val")
        row["rebuild_certificate"] = ((j.get("rebuild") or {}).get("certificate") or {}).get("passed")
        row["removal_transition_updates"] = (r["cfg"].get("dissipation") or {}).get("speed_updates")
        row["post_removal_repair_updates"] = (r["cfg"].get("dissipation") or {}).get("post_updates")
        row["test_split"] = TEST_SPLIT_MEANING.get((r["cfg"].get("data") or {}).get("name"))
        row["imitation_reference"] = ("receiver = the trained lineage model at the start checkpoint, before the "
                                      "rebuild (not the rebuilt start)")
        pr = plain.get(tr_id)
        if pr is not None:
            row["plain_run"] = pr[0]
            row["plain_repaired_test_err"] = pr[1].get("test_err")
            row["plain_repaired_sel_test_err"] = pr[1].get("sel_test_err")
        out.append(row)
    return out


def panel25_table(runs: dict, E: list[dict]) -> list[dict]:
    """v25 / v26 (family X25): one row per removal or compact-control job of waves 19 / 20: block, cell, arm and start
    state, the training-changing factors (route, partition, quota, branch width, label noise, removal method and
    target, warmup, repair scope and data subset, rebuild), draw / optimizer / partition seeds, frozen dependence (intact and joint deletion,
    before any repair), the repaired endpoint (final and validation-selected), the dense early repair path, and the
    draw's C1, C1_phase and fixed-arm removal on the same contrast and replication (gains = control - row)."""
    byrun = {e["run_id"]: e for e in E}
    refs: dict = {}
    for rid, r in runs.items():
        d = r["cfg"].get("design") or {}
        if d.get("family") != "X25":
            continue
        k = (d.get("contrast"), _rk(r["cfg"]))
        if d.get("arm") in ("C1", "C1_phase", "ETD_from_f0"):
            refs[(d["arm"],) + k] = byrun.get(rid, {})
        if r["cfg"]["kind"] == "dissipation" and d.get("variant") == "fixed" and d.get("arm") == "treated":
            refs[("fixed",) + k] = byrun.get(rid, {})
    out = []
    for rid, r in runs.items():
        cfg = r["cfg"]
        d = cfg.get("design") or {}
        if d.get("family") != "X25" or cfg["kind"] not in ("dissipation", "continue"):
            continue
        e = byrun.get(rid, {})
        dc = cfg.get("dissipation") or {}
        row = {"run_id": rid, "block": cfg.get("block"),
               "cell": (d.get("contrast") or "").split("|")[-1], "variant": d.get("variant"), "arm": d.get("arm"),
               "kind": cfg["kind"], "replication": _rk(cfg), **_draw_meta(cfg),
               "label_noise": (cfg.get("data") or {}).get("label_noise", 0.0)}
        if cfg["kind"] == "dissipation":
            tp = runs.get((cfg.get("parents") or {}).get("trajectory"))
            g = (tp["cfg"].get("growth") if tp is not None else cfg.get("growth")) or {}
            rb = dc.get("rebuild") or {}
            row.update({"spec_partition": g.get("spec_partition"), "mask_route": g.get("spec_mask_route", "gradient"),
                        "branch_width": g.get("width"), "spec_random_fraction": g.get("spec_random_fraction"),
                        "quota_fraction": (g.get("spec_quota") or {}).get("fraction")
                        if g.get("spec_partition") == "matched_quota" else None,
                        "quota_b_run": (g.get("spec_quota") or {}).get("b_run")
                        if g.get("spec_partition") == "matched_quota" else None,
                        "removal_method": dc.get("method"), "repair_scope": dc.get("repair_scope", "full"),
                        "removal_target": dc.get("target", "task"), "repair_subset": dc.get("repair_subset", 0),
                        "bypass_keep": dc.get("bypass_keep") if dc.get("method") == "stochastic_bypass" else None,
                        "removal_warmup": (cfg.get("train") or {}).get("warmup", 0),
                        "keep_frozen_implants": dc.get("keep_frozen_implants") if dc.get("method") in ("keep", "linear")
                        else None,
                        "restore_before_repair": dc.get("restore_before_repair", "none"),
                        "cut_where": g.get("cut_where"), "gate_schedule": dc.get("gate_schedule", "anneal"),
                        "rebuild_backbone": rb.get("backbone"), "rebuild_implants": rb.get("implants"),
                        "trajectory_run": (cfg.get("parents") or {}).get("trajectory")})
            rr, j = _removal_row(r, e)
            row.update(rr)
            sc = j.get("repair_scope") or {}
            rs_ = j.get("repair_subset") or {}
            row["repair_subset_rare_group"] = rs_.get("n_rare_group")
            row["repair_trainable_params"] = sc.get("trainable_params")
            row["repair_compact_params"] = sc.get("compact_params")
            cert = ((j.get("rebuild") or {}).get("certificate") or {})
            row["rebuild_certificate"] = cert.get("passed") if cert else None
        else:
            cc = cfg.get("continue") or {}
            row.update({"continue_arm": cc.get("arm"), "segments": " ".join(map(str, cc.get("segments") or [])) or None,
                        "segment_reset": " ".join(str(bool(x)).lower() for x in cc.get("segment_reset") or []) or None})
            for k in ("test_err", "test_risk", "rare_err", "shift_err", "cf_shortcut_err", "cf_causal_err",
                      "sel_test_err", "sel_test_risk"):
                row[f"repaired_{k}"] = e.get(k)
            row["selection_candidates"] = _n_candidates(r)
        k = (d.get("contrast"), row["replication"])
        for nm in ("C1", "C1_phase", "ETD_from_f0", "fixed"):
            ref = refs.get((nm,) + k) or {}
            row[f"{nm.lower()}_test_err"] = ref.get("test_err")
            # v31: a native expanded endpoint (method keep) is never counted as a compact-model gain
            if row.get("endpoint_kind") == "native_expanded":
                continue
            if ref.get("test_err") is not None and e.get("test_err") is not None:
                row[f"gain_vs_{nm.lower()}_test_err"] = ref["test_err"] - e["test_err"]
        row["test_split"] = TEST_SPLIT_MEANING.get((cfg.get("data") or {}).get("name"))
        out.append(row)
    return out


def sink_profile_table(runs: dict) -> list[dict]:
    """v25: the frozen per-stratum dependence of the training examples (dissipation_result.sink_profile), one row
    per (removal job, condition, stratum): condition = intact, joint_deletion, or one implant's deletion (with its
    slot); f0's own loss / error in the stratum beside it."""
    out = []
    for rid, r in runs.items():
        cfg = r["cfg"]
        d = cfg.get("design") or {}
        if cfg["kind"] != "dissipation":
            continue
        p = r["dir"] / "dissipation_result.json"
        if not p.exists():
            continue
        sp = read_json(p).get("sink_profile") or {}
        if not sp:
            continue
        base = {"run_id": rid, "family": d.get("family"), "variant": d.get("variant"), "arm": d.get("arm"),
                "cell": (d.get("contrast") or "").split("|")[-1], "replication": _rk(cfg), **_draw_meta(cfg),
                "label_noise": (cfg.get("data") or {}).get("label_noise", 0.0)}
        f0 = sp.get("f0") or {}
        conds = [("intact", None, sp.get("intact") or {}), ("joint_deletion", None, sp.get("joint_deletion") or {})]
        conds += [("single_deletion", t, v) for t, v in (sp.get("single_deletion") or {}).items()]
        for cond, t, m in conds:
            if "error" in m:
                out.append({**base, "condition": cond, "implant": t, "error": m["error"]})
                continue
            for st, v in m.items():
                out.append({**base, "condition": cond, "implant": t, "slot": (sp.get("slots") or {}).get(t),
                            "stratum": st, **{k: v.get(k) for k in ("n", "loss", "loss_increase", "err", "err_increase")},
                            "f0_loss": (f0.get(st) or {}).get("loss"), "f0_err": (f0.get(st) or {}).get("err")})
    return out


def _pearson(xs: list, ys: list) -> Optional[float]:
    n = len(xs)
    if n < 3:
        return None
    mx, my = sum(xs) / n, sum(ys) / n
    sx = sum((x - mx) ** 2 for x in xs)
    sy = sum((y - my) ** 2 for y in ys)
    if sx <= 0 or sy <= 0:
        return None
    return sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / (sx * sy) ** 0.5


def dependence_benefit_table(rows: list[dict], source: str) -> list[dict]:
    """v25: does frozen dependence (test error after the joint deletion, before repair) go with the repaired
    endpoint?  Pearson r of frozen_removed_test_err vs repaired_test_err (a) ACROSS arms within one replication
    (one row per replication; arms differ in training history, so the arm is a confound), and (b) WITHIN one arm
    across the replications that share a draw (partition seeds; one row per arm and draw) and across all of the
    arm's replications.  Plain removals only (no rebuild, full scope, linear method)."""
    keep = [r for r in rows if r.get("frozen_removed_test_err") not in (None, "") and
            r.get("repaired_test_err") not in (None, "") and r.get("removal_method", "linear") in ("linear", None) and
            r.get("removal_target", "task") in ("task", None) and not r.get("removal_warmup") and
            r.get("restore_before_repair", "none") in ("none", None) and
            r.get("gate_schedule", "anneal") in ("anneal", None) and not r.get("keep_frozen_implants") and
            not r.get("repair_subset") and
            r.get("repair_scope", "full") in ("full", None) and r.get("rebuild_backbone") in (None, "receiver") and
            r.get("rebuild_implants") in (None, "receiver")]
    out = []
    by_rep: dict = {}
    for r in keep:
        by_rep.setdefault((r.get("cell"), r.get("replication")), []).append(r)
    for (cell, rep), rs in sorted(by_rep.items(), key=lambda t: str(t[0])):
        xs = [float(r["frozen_removed_test_err"]) for r in rs]
        ys = [float(r["repaired_test_err"]) for r in rs]
        out.append({"source": source, "scope": "across_arms_within_replication", "cell": cell, "replication": rep,
                    "arm": None, "n": len(rs), "pearson_r": _pearson(xs, ys)})
    by_arm_draw: dict = {}
    by_arm: dict = {}
    for r in keep:
        arm = r.get("variant")
        by_arm_draw.setdefault((r.get("cell"), arm, r.get("data_draw"), r.get("optimizer_seed")), []).append(r)
        by_arm.setdefault((r.get("cell"), arm), []).append(r)
    for (cell, arm, ds, os_), rs in sorted(by_arm_draw.items(), key=lambda t: str(t[0])):
        if len(rs) < 3:
            continue
        out.append({"source": source, "scope": "within_arm_within_draw (partition seeds)", "cell": cell,
                    "replication": f"draw{ds}_opt{os_}", "arm": arm, "n": len(rs),
                    "pearson_r": _pearson([float(r["frozen_removed_test_err"]) for r in rs],
                                          [float(r["repaired_test_err"]) for r in rs])})
    for (cell, arm), rs in sorted(by_arm.items(), key=lambda t: str(t[0])):
        out.append({"source": source, "scope": "within_arm_all_replications", "cell": cell, "replication": None,
                    "arm": arm, "n": len(rs),
                    "pearson_r": _pearson([float(r["frozen_removed_test_err"]) for r in rs],
                                          [float(r["repaired_test_err"]) for r in rs])})
    return out


def _traj_result(r: dict) -> dict:
    """a trajectory job's returned result (summary.json 'result')."""
    p = r["dir"] / "summary.json"
    return (read_json(p).get("result") or {}) if p.exists() else {}


def integer_exactness(x: dict) -> dict:
    """v25: a fit's exact / censored status recomputed from integer counts (cop_pegs.recode.curve_exact): v21-v24
    records decided exactness by comparing a float mean with 1.0, which can read 0.9999999999999999 for an exact
    fit.  `status_integer` is the status the tables use; `status_corrected` marks a changed record."""
    from ..cop_pegs.recode import curve_exact
    st = x.get("status")
    if st not in ("exact", "censored"):
        return {"status_integer": st, "status_corrected": False}
    n = x.get("support_size")
    cv = x.get("curve") or []
    ex = [c for c in cv if curve_exact(c, n)]
    first = ex[0]["update"] if ex else None
    sustained = None
    if cv and curve_exact(cv[-1], n):
        sustained = cv[-1]["update"]
        for c in reversed(cv):
            if not curve_exact(c, n):
                break
            sustained = c["update"]
    st2 = "exact" if first is not None else "censored"
    return {"status_integer": st2, "status_corrected": st2 != st, "first_exact_update_integer": first,
            "sustained_exact_from_integer": sustained,
            "final_exact_integer": bool(cv and curve_exact(cv[-1], n))}


def recode_table(runs: dict) -> list[dict]:
    """v19 / v20 interface recoding (family RC): one row per planned fit of every recode job (pearl, regime,
    relabelling, side, class, fit seed), with the history of the chain it read, the fit status (exact / censored /
    numerical_failure), the pearl's support description and the source risk.  Skipped pearls stay as rows with
    their reason; runs whose validity checks failed are not complete and are listed by the status tables."""
    out = []
    for rid, r in runs.items():
        d = r["cfg"].get("design") or {}
        p = r["dir"] / "recode_result.json"
        if r["cfg"]["kind"] != "cop" or (r["cfg"].get("cop") or {}).get("task_kind") != "recode" or not p.exists():
            continue
        if r["status"].get("status") != "complete":
            continue
        j = read_json(p)
        pe = {x["pearl"]: x for x in j.get("pearls") or []}
        ref = j.get("reference") or {}
        src = {f"source_{pt}_{k}": v for pt, m in ref.items() for k, v in m.items() if k in ("loss", "mse", "acc")}
        for x in j.get("rows") or []:
            row = {"run_id": rid, "contrast": d.get("contrast"),
                   "history": str(d.get("arm", "")).replace("recode_", ""), "replication": _rk(r["cfg"]),
                   "source_checkpoint": (j.get("source") or {}).get("stage"), **src,
                   **{k: v for k, v in x.items() if k not in ("curve", "failure")}}
            if x.get("failure"):
                row["failure_update"], row["failure_cause"] = x["failure"].get("update"), x["failure"].get("cause")
            row.update(integer_exactness(x))
            q = pe.get(x.get("pearl"), {})
            for k in ("reachable_in_messages_train", "distinct_out_messages_train", "support_frequency_entropy_bits",
                      "val_messages_unseen_in_train", "test_messages_unseen_in_train"):
                row[f"pearl_{k}"] = q.get(k)
            if q.get("target_bit_balance_observed") is not None:
                row["pearl_target_bit_balance_observed"] = " ".join(f"{b:.3f}" for b in q["target_bit_balance_observed"])
            out.append(row)
    return out


def write_v13_tables(runs: dict, E: list[dict], out: Path) -> dict:
    from .summarize import _write_csv
    out = Path(out)
    res = {}
    rej: list = []
    for metric in ("test_risk", "test_err", "rare_risk", "shift_risk"):
        s, p = tuned_gain(E, metric, rej if metric == "test_risk" else None)
        _write_csv(out / f"s13_tuned_{metric}.csv", s)
        _write_csv(out / f"s13_tuned_pairs_{metric}.csv", p)
        res[f"n_tuned_{metric}_pairs"] = len(p)
    _write_csv(out / "s13_tuned_rejected.csv", rej)
    fq_rej: list = []
    for metric in ("test_risk", "test_err"):
        tq, mq = finite_recipe_gain(E, metric, fq_rej if metric == "test_risk" else None)
        _write_csv(out / f"s15_finite_recipe_tuned_{metric}.csv", tq)
        _write_csv(out / f"s15_finite_recipe_matched_lr_{metric}.csv", mq)
        # pooled over replications (draw-level), one row per (contrast, recipe[, rate])
        _write_csv(out / f"s15_finite_recipe_tuned_summary_{metric}.csv",
                   draw_summary(tq, ("contrast", "recipe", "scratch_panel"), {"G": lambda r: r.get("G")},
                                fq_rej if metric == "test_risk" else None))
        _write_csv(out / f"s15_finite_recipe_matched_lr_summary_{metric}.csv",
                   draw_summary(mq, ("contrast", "recipe", "scratch_panel", "lr_factor", "comparison"),
                                {"G": lambda r: r.get("G")},
                                fq_rej if metric == "test_risk" else None))
        res[f"n_finite_recipe_tuned_{metric}"] = len(tq)
    _write_csv(out / "s15_finite_recipe_rejected.csv", fq_rej)
    fqs_rej: list = []
    for metric in ("test_risk", "test_err"):
        tq, mq = finite_recipe_gain_selected(E, metric, fqs_rej if metric == "test_risk" else None)
        _write_csv(out / f"s17_finite_recipe_tuned_selected_{metric}.csv", tq)
        _write_csv(out / f"s17_finite_recipe_matched_lr_selected_{metric}.csv", mq)
        _write_csv(out / f"s17_finite_recipe_tuned_selected_summary_{metric}.csv",
                   draw_summary(tq, ("contrast", "recipe", "scratch_panel"), {"G": lambda r: r.get("G")}))
        res[f"n_finite_recipe_tuned_selected_{metric}"] = len(tq)
    _write_csv(out / "s17_finite_recipe_selected_rejected.csv", fqs_rej)
    HI = history_ingredients_table(runs, E)
    lq_rej: list = []
    LQ = later_query_retention(HI, lq_rej)
    _write_csv(out / "s15_later_query_retention_summary.csv", later_query_summary(LQ, lq_rej))
    _write_csv(out / "s13_later_query_retention_rejected.csv", lq_rej)
    tabs = {"s13_removal_paths": removal_path_table(runs), "s13_x4_information": x4_information_table(runs, E),
            "s13_history_ingredients": HI, "s13_later_query_retention": LQ,
            "s13_finite_refit": finite_refit_table(runs)}
    LC = locality_controls_table(runs)
    tabs["s13_locality_controls"] = LC
    tabs["s15_locality_performance_matched"] = locality_performance_matched(LC)
    tabs["s17_locality_outcomes"] = locality_outcome_summary(LC)
    tabs["s19_swaps"] = swap_table(runs, E)
    tabs["s20_swap_scan"] = swap_scan_table(runs)
    tabs["s22_persistence"] = persistence_table(runs, E)
    tabs["s22_backbone"] = backbone_table(runs, E)
    tabs["s22_etd"] = etd_table(runs, E)
    # v25 panel
    P25 = panel25_table(runs, E)
    tabs["s25_panel"] = P25
    tabs["s25_sink_profile"] = sink_profile_table(runs)
    tabs["s25_dependence_benefit"] = (dependence_benefit_table(tabs["s22_persistence"], "s22_persistence") +
                                      dependence_benefit_table([r for r in P25 if r["kind"] == "dissipation"],
                                                               "s25_panel"))
    tabs["s19_reassignment"] = reassignment_table(runs, E)
    tabs["s19_recode"] = recode_table(runs)
    tabs["s15_frozen_weight_sweep"] = frozen_sweep_table(runs)
    for n, t in tabs.items():
        _write_csv(out / f"{n}.csv", t)
        res[f"n_{n}"] = len(t)
    atomic_write_json(out / "s13_analyses.json", {
        "(i) fixed-history mechanism": ["s13_removal_paths", "s13_x4_information", "s13_locality_controls",
                                        "s13_finite_refit", "s_locality", "s_finite_interface",
                                        "s_contraction_diagnostics", "s_repair_scope", "s_repair_curves"],
        "(ii) best deployable compact endpoint (validation-selected)": [
            "s_selected_fixed_architecture_*", "s_selected_fixed_architecture_f0fallback_*",
            "s_selected_matched_endpoint_*", "s13_tuned_*"],
        "(iii) same final architecture, history vs direct training": [
            "s_matched_endpoint_*", "s13_history_ingredients", "s13_later_query_retention"],
        "fixed-budget compact endpoints (pre-v13 analysis, kept)": ["s_fixed_architecture_*", "s_cost_frontier_*"],
        "note": "re-pilot tables use the discovery seed only; they guide the protocol and are not confirmation"})
    return res
