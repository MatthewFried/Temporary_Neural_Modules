"""v5 analysis tables (written by summarize_strengthening into summary/strengthening/).

  s_gain_retention.csv          per treated dissipation / repair endpoint and its C1 control:
                                  G = R_C1 - R_compact (numerator), D = R_C1 - R_expanded (expansion gain)
                                  retention eta = G / D only when D > DELTA (raw numerator and denominator
                                  always kept; eta is not clipped and may exceed 1 or be negative);
                                  gap closure G / (R_C1 - R_witness) only with a realisable compact witness
                                  (regression, clean held-out targets) and a denominator > DELTA.
                                The ratio is DESCRIPTIVE: it is gain retention, not a fraction of
                                computation absorbed, and the compact endpoint may have used repair work
                                the expanded model did not (C1 is the matched-update control for G).
  s_contraction_diagnostics.csv one row per (run, contraction, implant): the P1 diagnostics next to the
                                run's outcomes (endpoint risk, G vs C1, repair first-hit update).
  s_predictor_screen.json       exploratory: Spearman correlation of every diagnostic and baseline predictor
                                with each outcome within each replication; the first replication is the
                                discovery set and the sign is checked on every other (held-out)
                                replication; a screen, never a confirmation.
  s_finite_interface.csv        P2 scores of every finite-interface CoP job (and bridge phases).
  s_locality.csv                P3: smallest successful tested scope per (run, checkpoint, tolerance).
  s_dependence_game.json/.csv   P4: exact static games of complete deletion landscapes (incomplete ones are
                                listed with the reason, never scored).
  s_transplant_grid.csv         P5: 2 x 2 x adapter-family contrasts.
  s_witness.csv                 P0: witness status of every known-teacher f0.
"""
from __future__ import annotations

import math
from collections import defaultdict
from pathlib import Path
from typing import Optional

from ..utils import read_json, atomic_write_json

DELTA = 1e-3      # predeclared minimum denominator (risk units: standardised MSE, or nats of cross-entropy)


def _idx(E):
    by = {}
    for e in E:
        if e.get("design_contrast"):
            by[(e["design_contrast"], e.get("f0_run"), e["replication"], e["design_arm"])] = e
    return by


def gain_retention(E: list[dict]) -> list[dict]:
    by = _idx(E)
    out = []
    for e in E:
        if e.get("design_arm") != "treated" or e.get("kind") not in ("dissipation", "repair") or not e.get("eligible"):
            continue
        c1 = by.get((e["design_contrast"], e.get("f0_run"), e["replication"], "C1"))
        row = {"run_id": e["run_id"], "contrast": e["design_contrast"], "family": e.get("design_family"),
               "variant": e.get("design_variant"), "replication": e["replication"], "task": e.get("task"),
               "contraction_mechanism": e.get("contraction_mechanism"), "R_compact": e.get("test_risk"),
               "R_expanded": e.get("expanded_test_risk"), "expanded_stage": e.get("expanded_stage"),
               "R_f0": e.get("f0_test_risk"), "delta": DELTA, "expanded_source": e.get("expanded_source")}
        if c1 is None or not c1.get("eligible") or c1.get("test_risk") is None:
            row["status"] = "no eligible C1 control"
            out.append(row)
            continue
        Rc = c1["test_risk"]
        row["R_C1"] = Rc
        row["C1_run"] = c1["run_id"]
        if e.get("test_risk") is None:
            row["status"] = "no compact risk"
            out.append(row)
            continue
        num = Rc - e["test_risk"]
        row["G_numerator"] = num
        if row["R_expanded"] is None:
            row["retention_eta"] = None
            row["retention_status"] = f"undefined: no expanded-model risk ({e.get('expanded_source')})"
        else:
            den = Rc - row["R_expanded"]
            row["expansion_gain_denominator"] = den
            row["retention_eta"] = num / den if den > DELTA else None
            row["retention_status"] = "defined" if den > DELTA else f"undefined: expansion gain <= delta ({DELTA})"
        if e.get("witness_realizable") and e.get("task") == "regression" and e.get("witness_test_risk") is not None:
            dw = Rc - e["witness_test_risk"]
            row["R_witness"] = e["witness_test_risk"]
            row["witness_gap_denominator"] = dw
            row["gap_closure"] = num / dw if dw > DELTA else None
        else:
            row["gap_closure_status"] = ("no realisable compact witness (approximation-mismatch condition)"
                                         if e.get("witness_realizable") is False else "not applicable")
        row["status"] = "ok"
        out.append(row)
    return out


def contraction_diagnostics_table(runs: dict, E: list[dict]) -> list[dict]:
    by_run = {e["run_id"]: e for e in E}
    pairs = _idx(E)
    out = []
    for rid, r in runs.items():
        p = r["dir"] / "contraction_diagnostics.json"
        if not p.exists() or r["status"]["status"] != "complete":
            continue
        e = by_run.get(rid, {})
        c1 = pairs.get((e.get("design_contrast"), e.get("f0_run"), e.get("replication"), "C1")) if e else None
        G = (c1["test_risk"] - e["test_risk"]) if (c1 and c1.get("eligible") and e.get("eligible") and
                                                    c1.get("test_risk") is not None and
                                                    e.get("test_risk") is not None) else None
        first_hit = None
        rr = r["dir"] / "repair_result.json"
        if rr.exists():
            reach = (read_json(rr).get("reach") or {}).get("task") or {}
            vals = [v for v in reach.values() if v is not None]
            first_hit = min(vals) if vals else None
        rp = r["dir"].parent.parent / "recomputed_diagnostics" / f"{rid}.json"
        recomputed = (read_json(rp).get("records") or {}) if rp.exists() else {}
        for tag, rec in read_json(p).items():
            new = recomputed.get(tag) or {}
            new_rows = ((new.get("record") or {}).get("implants") or {}) if new.get("status") == "ok" else {}
            for iid, d in rec["implants"].items():
                source = "original"
                if (d.get("error") or d.get("complete") is False) and (new_rows.get(iid) or {}).get("complete"):
                    d, source = new_rows[iid], f"recomputed {new.get('diagnostic_version')}"
                row = {"run_id": rid, "kind": r["cfg"]["kind"], "tag": tag, "implant": iid,
                       "replication": e.get("replication"), "contrast": e.get("design_contrast"),
                       "family": e.get("design_family"), "variant": e.get("design_variant"),
                       "cut_where": (r["cfg"].get("growth") or {}).get("cut_where"),
                       "topology": (r["cfg"].get("growth") or {}).get("topology"),
                       "nonlinearity": (r["cfg"].get("growth") or {}).get("nonlinearity"),
                       "endpoint_test_risk": e.get("test_risk"), "G_vs_C1": G,
                       "repair_first_hit_update": first_hit, "state_unchanged": rec.get("state_unchanged"),
                       "diagnostic_source": source}
                for k in ("skipped", "error", "complete", "fit_status", "virtual_status", "deletion_status", "jvp_status",
                          "fit_error", "virtual_error", "deletion_error", "jvp_error", "jvp_backend", "construction", "rho_raw", "rho_rel_output", "rho_rel_change",
                          "rho_train_raw", "cond", "rank", "jvp_residual", "jvp_residual_rel_output",
                          "implant_change_sq", "implant_output_sq", "fit_seconds", "jvp_seconds", "virtual_seconds"):
                    if k in d:
                        row[k] = d[k]
                for k in ("virtual_affine_damage", "deletion_damage"):
                    if isinstance(d.get(k), dict):
                        row[f"{k}_val"] = d[k].get("val")
                        row[f"{k}_test"] = d[k].get("test")
                row["pre_contraction_val_risk"] = (rec.get("pre_contraction_risk") or {}).get("val")
                out.append(row)
    return out


def _spearman(x: list[float], y: list[float]) -> Optional[float]:
    n = len(x)
    if n < 4:
        return None

    def ranks(v):
        o = sorted(range(n), key=lambda i: v[i])
        r = [0.0] * n
        i = 0
        while i < n:
            j = i
            while j + 1 < n and v[o[j + 1]] == v[o[i]]:
                j += 1
            for k in range(i, j + 1):
                r[o[k]] = (i + j) / 2.0
            i = j + 1
        return r
    rx, ry = ranks(x), ranks(y)
    mx, my = sum(rx) / n, sum(ry) / n
    sx = math.sqrt(sum((a - mx) ** 2 for a in rx))
    sy = math.sqrt(sum((b - my) ** 2 for b in ry))
    if sx == 0 or sy == 0:
        return None
    return sum((a - mx) * (b - my) for a, b in zip(rx, ry)) / (sx * sy)


PREDICTORS = ("rho_raw", "rho_rel_output", "jvp_residual_rel_output", "virtual_affine_damage_val",
              "deletion_damage_val", "implant_change_sq", "pre_contraction_val_risk")
OUTCOMES = ("repair_first_hit_update", "G_vs_C1", "endpoint_test_risk")


def predictor_screen(rows: list[dict]) -> dict:
    """Exploratory screen with a held-out split by replication.  Correlations are computed within one
    replication at a time (a replication is a whole paired data / teacher / optimizer seed, never random
    rows of one model).  The DISCOVERY replication is the first in sorted order; every other
    replication is HELD OUT.  For each predictor -> outcome pair the discovery sign is compared with the
    sign in each held-out replication.  Nothing is fitted or thresholded here, so the held-out check is
    only a sign-replication check; a predictor chosen from this screen still needs confirmatory seeds."""
    out = {"unit": "replication (paired data / teacher / optimizer seed)", "note": "exploratory screen; choose "
           "predictors on the discovery replication, check the sign on held-out replications, confirm on new "
           "seeds; virtual_affine_damage and deletion_damage are intervention measurements of immediate damage, "
           "so they are screened against later outcomes only"}
    reps = sorted({r.get("replication") for r in rows if r.get("replication")})
    out["discovery_replication"] = reps[0] if reps else None
    out["held_out_replications"] = reps[1:]
    out["results"] = _screen(rows, reps)
    # pooled rows mix contraction mechanisms (fold, gated removal, ...): the same screen within each family
    fams = sorted({r.get("family") for r in rows if r.get("family")})
    out["by_family"] = {f: _screen([r for r in rows if r.get("family") == f], reps) for f in fams}
    out["transfer"] = _transfer(rows)
    return out


TRANSFER_KEYS = ("topology", "cut_where", "nonlinearity")


def _transfer(rows: list[dict]) -> dict:
    """Hold out one level of a condition (topology, cut location, nonlinearity) at a time: the Spearman
    correlation on the rows of every OTHER level against the one on the held-out level (rows pooled over
    replications on both sides), and whether the signs agree.  Exploratory, like the screen."""
    res = {}
    for key in TRANSFER_KEYS:
        levels = sorted({str(r.get(key)) for r in rows if r.get(key) is not None})
        if len(levels) < 2:
            continue
        for oc in OUTCOMES:
            for pr in PREDICTORS:
                ok = [r for r in rows if r.get(key) is not None and isinstance(r.get(pr), (int, float))
                      and isinstance(r.get(oc), (int, float))]
                per = {}
                for lv in levels:
                    held = [r for r in ok if str(r[key]) == lv]
                    rest = [r for r in ok if str(r[key]) != lv]
                    a = _spearman([r[pr] for r in rest], [r[oc] for r in rest])
                    h = _spearman([r[pr] for r in held], [r[oc] for r in held])
                    if a is not None and h is not None:
                        per[lv] = {"other_levels": a, "held_out_level": h, "n_other": len(rest), "n_held_out": len(held),
                                   "same_sign": (a > 0) == (h > 0) if a != 0 and h != 0 else None}
                if per:
                    res.setdefault(key, {})[f"{pr}->{oc}"] = per
    return res


def _screen(rows: list[dict], reps: list) -> dict:
    results = {}
    for oc in OUTCOMES:
        for pr in PREDICTORS:
            per = {}
            for rep in reps:
                xs = [(r[pr], r[oc]) for r in rows if r.get("replication") == rep and isinstance(r.get(pr), (int, float))
                      and isinstance(r.get(oc), (int, float))]
                rho = _spearman([a for a, _ in xs], [b for _, b in xs])
                if rho is not None:
                    # sibling jobs of one parent share the same pre-contraction diagnostics: n_distinct_predictor
                    # is the number of distinct predictor values behind the n rows (rows are not independent)
                    per[rep] = {"spearman": rho, "n": len(xs), "n_distinct_predictor": len({a for a, _ in xs})}
            if not per:
                continue
            res = {"per_replication": per}
            d = per.get(reps[0])
            if d is not None:
                res["discovery_spearman"] = d["spearman"]
                held = {k: v["spearman"] for k, v in per.items() if k != reps[0]}
                res["held_out_spearman"] = held
                if held and d["spearman"] != 0:
                    res["held_out_same_sign"] = sum((v > 0) == (d["spearman"] > 0) for v in held.values() if v != 0)
                    res["held_out_n"] = sum(v != 0 for v in held.values())
            results[f"{pr}->{oc}"] = res
    return results


def finite_interface_table(runs: dict) -> list[dict]:
    out = []
    for rid, r in runs.items():
        p = r["dir"] / "cop_chain_result.json"
        if r["cfg"]["kind"] != "cop" or not p.exists() or r["status"]["status"] != "complete":
            continue
        j = read_json(p)
        fi = j.get("finite_interface")
        if fi is None:
            continue
        pc, d = r["cfg"]["peg"], r["cfg"].get("design") or {}
        row = {"run_id": rid, "contrast": d.get("contrast"), "variant": d.get("variant"), "arm": d.get("arm"),
               "data": r["cfg"]["data"]["name"], "n_bits": fi.get("n"), "family": fi.get("family"),
               "peg_dim": pc["dim"], "peg_bits": pc["bits"], "bridge": int(pc.get("temp_channel", 0)),
               "bridge_target": pc.get("temp_target"), "bridge_anneal_updates": pc.get("temp_anneal_updates"),
               "applicable": fi.get("applicable"), "reason": fi.get("reason")}
        for k in ("K_bits", "task", "distinct_messages", "message_capacity", "e_model", "e_oracle", "e_star", "answers",
                  "answers_later", "answers_task", "e_task_model", "e_task_oracle", "e_later_oracle", "e_later_star_unconstrained",
                  "e_later_star_task_preserving", "e_later_star_at_task_error", "retention_gap", "protocol_violation",
                  "encoder_query_blind_empirical"):
            if k in fi:
                row[k] = fi[k]
        if fi.get("family") == "B_retention" and fi.get("applicable"):
            # the ceiling that applies to this code: task-preserving optimum if the code is pure in the original
            # task, else the exact frontier at the code's own original-task error (None if not enumerated)
            row["e_later_star_relevant"] = (fi.get("e_later_star_task_preserving") if fi.get("e_task_oracle") == 0
                                            else fi.get("e_later_star_at_task_error"))
        dec = fi.get("decomposition") or {}
        row.update({f"decomposition_{k}": v for k, v in dec.items() if k != "notes"})
        for ph, v in (j.get("bridge_phases") or {}).items():
            row[f"phase_{ph}_val_risk"] = v.get("val_risk")
            f = v.get("finite_interface") or {}
            if f.get("applicable"):
                row[f"phase_{ph}_e_oracle"] = f.get("e_oracle") if f.get("e_oracle") is not None else f.get("e_later_oracle")
        out.append(row)
    return out


def locality_table(runs: dict) -> list[dict]:
    out = []
    for rid, r in runs.items():
        p = r["dir"] / "locality_result.json"
        if not p.exists() or r["status"]["status"] != "complete":
            continue
        j = read_json(p)
        d = r["cfg"].get("design") or {}
        for rec in j["snapshots"]:
            stab = rec.get("code_stability_vs_previous") or {}
            for tol, sm in rec["tolerances"].items():
                row = {"run_id": rid, "contrast": d.get("contrast"), "interface": j["interface"],
                       "replication": f"data{r['cfg']['data'].get('data_seed')}_opt{r['cfg']['seeds'].get('optimizer')}",
                       "checkpoint": rec["checkpoint"], "updates_at_checkpoint": rec["updates_at_checkpoint"],
                       "tolerance": float(tol), "smallest_successful_tested_scope": sm["smallest_successful_tested_scope"],
                       "censored": sm["censored"], "reference_val_risk": None}
                ref = rec["reference"].get("val") or {}
                row["reference_val_risk"] = ref.get("mse", ref.get("loss"))
                for s, v in sm["per_scope"].items():
                    row[f"scope{s}_first_update"] = v["first_update_reaching"]
                    row[f"scope{s}_success"] = v["success_at_end"]
                for s, sr in rec["scopes"].items():
                    row[f"scope{s}_n_trainable"] = sr["n_trainable"]
                    row[f"scope{s}_diverged"] = sr["diverged"]
                for k, v in stab.items():
                    for kk, vv in v.items():
                        if isinstance(vv, (int, float)):
                            row[f"stability_{k}_{kk}"] = vv
                for k, v in (rec.get("certificate") or {}).items():
                    if v.get("applicable"):
                        row[f"certificate_{k}_all_equal"] = v["all_equal"]
                        row[f"certificate_{k}_n_mismatched"] = v["n_mismatched"]
                out.append(row)
    return out


def dependence_games(runs: dict) -> tuple[list[dict], list[dict]]:
    from .dependence_game import game_from_deletions
    full, flat = [], []
    for rid, r in runs.items():
        # provenance / validity first: only complete, valid runs enter the static-game analysis (an excluded
        # run is listed with its reason)
        if r["status"]["status"] != "complete" or r["status"].get("validity", "valid") != "valid":
            for p in sorted(r["dir"].glob("deletions_*.json")):
                flat.append({"run_id": rid, "file": p.name, "exact": False,
                             "reason": f"run not included: status {r['status']['status']}, validity "
                                       f"{r['status'].get('validity', 'valid')}"})
            continue
        crit = r["cfg"].get("criteria") or {}
        for p in sorted(r["dir"].glob("deletions_*.json")):
            try:
                dele = read_json(p)
            except (OSError, ValueError) as ex:
                flat.append({"run_id": rid, "file": p.name, "exact": False, "reason": f"unreadable: {ex}"})
                continue
            task_reg = any("mse" in m for m in (dele.get("base") or {}).values())
            parts = [q for q in ("val", "complete_domain") if q in (dele.get("partitions") or [])]
            for part in parts:
                # each game in its own guard: one defective landscape never aborts the others, and a failure of
                # the criterion game never discards a valid risk game
                def guarded(fn):
                    try:
                        return fn()
                    except Exception as ex:
                        return {"exact": False, "reason": f"analysis error: {type(ex).__name__}: {ex}"}
                g1 = guarded(lambda: game_from_deletions(dele, part, "delta_risk"))
                if task_reg:
                    g2 = guarded(lambda: game_from_deletions(dele, part, "nmse_increase",
                                                             taus=tuple(crit.get("nmse") or (0.0,))))
                else:
                    g2 = guarded(lambda: game_from_deletions(dele, part, "acc_drop_pp",
                                                             taus=tuple(crit.get("acc_drop_pp") or (0.0,))))
                rec = {"run_id": rid, "file": p.name, "partition": part, "risk_game": g1, "criterion_game": g2}
                full.append(rec)
                row = {"run_id": rid, "file": p.name, "partition": part, "exact": g1.get("exact"),
                       "reason": g1.get("reason"), "n_players": g1.get("n_players", len(g1.get("atoms") or [])),
                       "hierarchical": g1.get("hierarchical")}
                if g1.get("exact"):
                    row["endpoint_damage"] = g1["endpoint_damage"]
                    row["max_single_damage"] = max(g1["single_deletion_damage"].values())
                    row["min_pair_interaction"] = min(g1["pair_at_empty"].values()) if g1["pair_at_empty"] else None
                    row["max_greedy_gap"] = max(x["greedy_gap"] for x in g1["greedy_vs_best"])
                    row["minmax_path_damage"] = g1["minmax_path"]["minmax_damage"]
                    dj = g1.get("disjoint_game") or {}
                    if dj.get("exact"):
                        # v22: interactions among disjoint players only (no ancestor / descendant pairs)
                        row["disjoint_n_players"] = dj["n_players"]
                        row["disjoint_players"] = " ".join(dj["players"])
                        row["disjoint_endpoint_damage"] = dj["endpoint_damage"]
                        row["disjoint_max_single_damage"] = max(dj["single_deletion_damage"].values())
                        row["disjoint_min_pair_interaction"] = min(dj["pair_at_empty"].values())
                        row["disjoint_max_pair_interaction"] = max(dj["pair_at_empty"].values())
                        row["disjoint_max_greedy_gap"] = max(x["greedy_gap"] for x in dj["greedy_vs_best"])
                if g2.get("exact"):
                    for t, b in g2["min_batch"].items():
                        row[f"min_batch@{t}"] = b
                flat.append(row)
    return full, flat


def _finite(v) -> bool:
    try:
        return math.isfinite(float(v))
    except (TypeError, ValueError):
        return False


def grid_assembly_eligibility(j: dict) -> dict:
    """Per-assembly eligibility of a grid transplant result.  v8 results carry info.assemblies; older ones
    are re-derived from info.fits (diverged / failed fits) and the stored metrics, with serialised 'nan',
    'inf' and '-inf' strings treated as non-finite."""
    info = j.get("info") or {}
    if "assemblies" in info:
        return info["assemblies"]
    from ..experiments.transplant_job import assembly_eligibility
    out = {}
    for key in set(info.get("fits") or {}) | set(j.get("rows") or {}):
        out[key] = assembly_eligibility((info.get("fits") or {}).get(key, {}), None, None, (j.get("rows") or {}).get(key))
    return out


def transplant_grid_table(runs: dict) -> list[dict]:
    """One row per (run, adapter family, partition).  A row is eligible only when the run is complete and
    every assembly its contrasts use is eligible; ineligible rows are kept with their reasons and null
    numbers (they are never dropped from the denominators)."""
    out = []
    for rid, r in runs.items():
        tp = r["cfg"].get("transplant") or {}
        p = r["dir"] / "transplant_result.json"
        res_design = ((read_json(p).get("info") or {}).get("design") if p.exists() else None)
        if tp.get("design") != "grid" and res_design != "grid":
            continue
        d = r["cfg"].get("design") or {}
        if r["status"]["status"] != "complete" or not p.exists():
            # a required grid job that did not complete stays in the table (and in every denominator)
            out.append({"run_id": rid, "contrast": d.get("contrast"), "arm": d.get("arm"), "family_adapter": None,
                        "partition": None, "eligible": False, "run_validity": r["status"].get("validity"),
                        "ineligibility_reasons": f"job {r['status']['status']}: {r['status'].get('reason')}"})
            continue
        j = read_json(p)
        if (j.get("info") or {}).get("design") != "grid":
            continue
        elig = grid_assembly_eligibility(j)
        # an 'unverified' run whose only reasons are its own ineligible assemblies keeps its eligible rows;
        # any other validity problem (e.g. an unverified parent) makes every row ineligible
        vr = [x for x in (r["status"].get("validity_reasons") or []) if not str(x).startswith("transplant grid:")]
        run_problem = None if r["status"].get("validity", "valid") == "valid" or not vr else f"run validity: {vr}"
        for fam, c in j["contrasts"].items():
            used = [f"{x}_{fam}" for x in ("Aup_Adown", "Bup_Adown", "Aup_Bdown", "Bup_Bdown")]
            bad = sorted(k for k in used if not elig.get(k, {}).get("eligible", False))
            for part, v in c.items():
                fit = (j["info"]["fits"].get(f"Bup_Adown_{fam}") or {})
                nums = {k: v[k] for k in ("R_A", "R_B", "R_Bup_Adown", "R_Aup_Bdown",
                                          "new_upstream_gain_on_old_downstream",
                                          "new_downstream_gain_with_old_upstream") if k in v}
                nonfinite = sorted(k for k, x in nums.items() if x is not None and not _finite(x))
                eligible = not bad and not nonfinite and run_problem is None
                reasons = [f"{k}: {'; '.join(elig.get(k, {}).get('reasons', ['missing']))}" for k in bad]
                if nonfinite:
                    reasons.append(f"non-finite values: {nonfinite}")
                if run_problem:
                    reasons.append(run_problem)
                row = {"run_id": rid, "contrast": d.get("contrast"), "arm": d.get("arm"),
                       "model_A": f"{(r['cfg'].get('parents') or {}).get('upstream')}@{tp.get('upstream_stage')}",
                       "model_B": f"{(r['cfg'].get('parents') or {}).get('downstream')}@{tp.get('downstream_stage')}",
                       "family_adapter": fam, "partition": part, "adapter_params": fit.get("params"),
                       "eligible": eligible, "run_validity": r["status"].get("validity", "valid"),
                       "ineligibility_reasons": "; ".join(reasons) if reasons else None}
                for k, x in nums.items():
                    row[k] = float(x) if (eligible and x is not None) else None
                out.append(row)
    return out


def witness_table(runs: dict) -> list[dict]:
    out = []
    for rid, r in runs.items():
        p = r["dir"] / "witness.json"
        if not p.exists():
            continue
        w = read_json(p)
        out.append({"run_id": rid, "realizable": w.get("realizable"), "reason": w.get("reason"),
                    "max_abs_err": (w.get("verification") or {}).get("max_abs_err"),
                    "test_mse": ((w.get("risk") or {}).get("test") or {}).get("mse"),
                    "train_mse": ((w.get("risk") or {}).get("train") or {}).get("mse"),
                    "data_identity": str(r["cfg"]["data"])})
    return out


def write_v5_tables(runs: dict, E: list[dict], out: Path) -> dict:
    from .summarize import _write_csv
    out = Path(out)
    GR = gain_retention(E)
    CD = contraction_diagnostics_table(runs, E)
    FI = finite_interface_table(runs)
    LO = locality_table(runs)
    DG_full, DG = dependence_games(runs)
    TG = transplant_grid_table(runs)
    WI = witness_table(runs)
    for name, t in (("s_gain_retention", GR), ("s_contraction_diagnostics", CD), ("s_finite_interface", FI),
                    ("s_locality", LO), ("s_dependence_game", DG), ("s_transplant_grid", TG), ("s_witness", WI)):
        _write_csv(out / f"{name}.csv", t)
    atomic_write_json(out / "s_dependence_game.json", DG_full)
    atomic_write_json(out / "s_predictor_screen.json", predictor_screen(CD))
    return {"n_gain_retention_rows": len(GR), "n_retention_defined": sum(r.get("retention_eta") is not None for r in GR),
            "n_contraction_diagnostic_rows": len(CD),
            "n_contraction_diagnostic_errors": sum(1 for r in CD if r.get("error")),
            "n_contraction_diagnostic_incomplete": sum(1 for r in CD if r.get("complete") is False or r.get("error")), "n_finite_interface_rows": len(FI), "n_locality_rows": len(LO),
            "n_dependence_games": len(DG), "n_exact_dependence_games": sum(bool(r.get("exact")) for r in DG),
            "n_transplant_grid_rows": len(TG), "n_witness_rows": len(WI),
            "tables": {"GR": GR, "CD": CD, "FI": FI, "LO": LO, "TG": TG}}
