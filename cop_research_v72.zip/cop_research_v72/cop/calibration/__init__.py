"""Calibration examples with known answers (strengthening addendum, Section 7)."""
