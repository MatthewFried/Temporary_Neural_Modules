"""Section 7 calibrations of the strengthening addendum (independent, standard library).

Port of the supplied boundary_checks.py (tests/fixtures/strengthening/boundary_checks_supplied.py):
the functions below reproduce the supplied results byte for byte (tests check the SHA-256 of
results/boundary_results.json and results/scalar_trajectories.csv).  One addition: the supplied
"query known before encoding" assertion compared x[q] with itself; `query_before_encoding()`
computes that case (a 1-bit code chosen with knowledge of q, and the 0-bit control).

Run: python -m cop.calibration.boundary --out results
These are constructed examples with known answers, not neural results.  The same constructions
are also run through the cop graph / optimizer / finite / deletion / transplant code in
tests/test_strengthening.py.
"""
import argparse
import csv
import itertools
import json
import math
from fractions import Fraction as F
from pathlib import Path


def loss(w):
    return 0.5 * (w - 2.0) ** 2


def scalar_run(c, lr, steps=40, rebalance_every=0):
    # The same function w*x is initially represented by a*b*x, a*b=1.
    a, b, direct = c, 1 / c, 1.0
    rows = []
    for step in range(steps + 1):
        w = a * b
        if not all(math.isfinite(v) and abs(v) < 1e12 for v in (a, b, direct, w)):
            rows.append(dict(c=c, lr=lr, rebalance_every=rebalance_every,
                             step=step, status="unstable", expanded_loss=None,
                             direct_loss=loss(direct) if math.isfinite(direct) and abs(direct)<1e12 else None))
            break
        rows.append(dict(c=c, lr=lr, rebalance_every=rebalance_every,
                         step=step, status="finite", expanded_loss=loss(w),
                         direct_loss=loss(direct)))
        if step == steps:
            break
        g = w - 2
        aa, bb = a - lr * g * b, b - lr * g * a
        # Exact effective-weight update. This is a diagnostic using factor state,
        # NOT an independent compact optimizer with no extra information/cost.
        shadow = w - lr * g * (a*a + b*b) + lr*lr*g*g*w
        assert math.isclose(aa*bb, shadow, rel_tol=1e-9, abs_tol=1e-9)
        a, b = aa, bb
        direct -= lr * (direct - 2)
        if rebalance_every and (step + 1) % rebalance_every == 0:
            product = a * b
            if math.isfinite(product) and abs(product)<1e12:
                a = math.sqrt(abs(product))
                b = math.copysign(a, product)
                assert math.isclose(a*b, product, rel_tol=1e-12, abs_tol=1e-12)
    return rows


def exact_one_step():
    rows=[]
    for eta in (F(1,5), F(6,5)):
        direct=1+eta
        expanded=(1+eta)**2
        rows.append(dict(eta=str(eta),direct_weight=str(direct),
                         expanded_folded_weight=str(expanded),
                         direct_loss=str((direct-2)**2/2),
                         expanded_loss=str((expanded-2)**2/2)))
    assert F(rows[0]['expanded_loss']) < F(rows[0]['direct_loss'])
    assert F(rows[1]['expanded_loss']) > F(rows[1]['direct_loss'])
    return rows


def partitions(n, max_blocks):
    # Restricted-growth strings enumerate each partition once; code names
    # cannot change the optimal decoder, so this exhausts deterministic encoders
    # up to permutation of labels.
    def rec(xs, high):
        if len(xs) == n:
            yield tuple(xs)
            return
        for label in range(min(high+1, max_blocks-1)+1):
            yield from rec(xs+[label], max(high,label))
    yield from rec([0],0)


def optimal_decoder_error(encoder, bits):
    total=0
    for code in set(encoder):
        selected=[x for x,z in zip(bits,encoder) if z==code]
        for q in range(3):
            ones=sum(x[q] for x in selected)
            total+=min(ones,len(selected)-ones)
    return total


def late_query():
    bits=list(itertools.product((0,1),repeat=3))
    out=[]
    for k in (1,2,4,8):
        best=25; witness=None; count=0
        for encoder in partitions(8,k):
            count+=1
            err=optimal_decoder_error(encoder,bits)
            if err<best:
                best,witness=err,encoder
        # Independently enumerate EVERY possible decoder for the chosen
        # encoder; at most 2^(8*3) at K=8, so use its zero-error witness there.
        if k<=4:
            used=max(witness)+1
            check=25
            for outputs in itertools.product((0,1), repeat=3*used):
                e=sum(outputs[3*witness[i]+q]!=x[q]
                      for i,x in enumerate(bits) for q in range(3))
                check=min(check,e)
            assert check==best
        out.append(dict(code_count=k, bit_budget=int(math.log2(k)),
                        partitions_checked=count, min_errors=best,
                        total_queries=24, max_accuracy=str(F(24-best,24)),
                        witness=list(witness)))
    assert out[-1]['partitions_checked']==4140
    assert [v['min_errors'] for v in out]==[12,6,4,0]
    # If q is known BEFORE encoding, just transmit x[q]: one bit suffices.
    known_before=sum(x[q]==x[q] for x in bits for q in range(3))
    assert known_before==24
    # If the current task is x0, retaining only x0 solves it exactly, but
    # permits only 2/3 accuracy on uniformly selected future queries.
    x0_encoder=[x[0] for x in bits]
    assert optimal_decoder_error(x0_encoder,bits)==8
    return dict(domain=bits, curves=out, query_before_peg_max_accuracy="1",
                current_task_x0_accuracy="1",future_random_query_accuracy_with_x0_only="2/3",
                scope="Deterministic encoder before query; decoder sees only code and query; uniform complete finite domain; no side channel")


def joint_deletion():
    xs=list(itertools.product((-1,0,1),repeat=2))
    def mse(scale):
        return sum((scale[j]*x[j]-x[j])**2 for x in xs for j in range(2))/F(2*len(xs))
    out={"neither_removed":str(mse((F(1),F(1)))),
         "A_removed":str(mse((F(1,2),F(2)))),
         "inverse_A_removed":str(mse((F(2),F(1,2)))),
         "both_removed":str(mse((F(1),F(1))))}
    assert out['neither_removed']==out['both_removed']=='0'
    assert F(out['A_removed'])>0 and F(out['inverse_A_removed'])>0
    return out


def drifting_codes():
    codes=list(range(8))
    permutation=[(i+1)%8 for i in codes]
    inverse=[permutation.index(i) for i in codes]
    # Both versions compute the identity perfectly when assembled together.
    assert all(inverse[permutation[i]]==i for i in codes)
    # An old pearl coupled to a new decoder uses the wrong convention.
    naive=sum(inverse[i]==i for i in codes)
    aligned=sum(inverse[permutation[i]]==i for i in codes)
    return dict(old_network_accuracy="1",new_network_accuracy="1",
                mixed_modules_accuracy=str(F(naive,8)),
                aligned_mixed_modules_accuracy=str(F(aligned,8)),
                permutation=permutation,
                scope="Constructed finite symbol interface, not evidence that training learns this permutation")


def query_before_encoding():
    """Q disclosed BEFORE encoding: the encoder may depend on (x, q).  One bit (x_q) gives zero
    errors on all 24 (x, q) pairs; zero bits cannot do better than 12 errors.  Exhaustive over
    every encoder (x, q) -> {0, 1} would be 2^24; it is not needed: the 1-bit witness has 0
    errors (optimal), and with one code the decoder sees only q, so each q costs min(#0, #1) = 4."""
    bits = list(itertools.product((0, 1), repeat=3))
    one_bit = sum(int(x[q] != x[q]) for x in bits for q in range(3))          # transmit z = x_q, decode z
    zero_bit = sum(min(sum(x[q] for x in bits), 8 - sum(x[q] for x in bits)) for q in range(3))
    assert one_bit == 0 and zero_bit == 12
    return {"one_bit_errors": one_bit, "zero_bit_errors": zero_bit, "total_queries": 24,
            "one_bit_max_accuracy": "1", "zero_bit_max_accuracy": "1/2"}


def main():
    p=argparse.ArgumentParser();p.add_argument('--out',default='results');args=p.parse_args()
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    trajectories=[]
    for c,lr,period in itertools.product((.25,.5,1.,2.,4.),(.001,.01,.05,.1,.2,.5,1.2),(0,1,5)):
        trajectories.extend(scalar_run(c,lr,rebalance_every=period))
    with (out/'scalar_trajectories.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(trajectories[0]));writer.writeheader();writer.writerows(trajectories)
    report={"status":"calibration only; no GPU or real-data research results",
            "scalar_conditions":105,"scalar_one_step_exact":exact_one_step(),
            "late_query":late_query(),"joint_deletion":joint_deletion(),
            "code_convention":drifting_codes()}
    (out/'boundary_results.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
