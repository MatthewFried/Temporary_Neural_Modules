"""Command line interface:  python -m cop.cli <command> ...

  inspect-environment   machine / torch / CUDA report, real CUDA forward-backward-update check
  fetch-data            download datasets into a local root (offline runs afterwards)
  generate-manifest     expand waves into resolved job lists (+ coverage, counts); --dry-run prints only
  validate-manifest     re-resolve configs, recompute run ids, dependency order, factorial counts
  run                   execute a manifest (resumable; claims; --workers N spawns N processes)
  status                job status counts per block
  evaluate-deletions    R1 family on an existing trajectory run
  repair                one R2 repair job on an existing trajectory run
  export-compact        physically simplified export of a checkpoint + accounting
  verify-certificate    independent checker for finite certificates
  calibrate             time representative jobs on this machine (per-update cost, memory, disk)
  estimate              runtime / disk estimate for a manifest from calibration timings
  summarize             aggregate results, coverage matrix, paired contrasts, figures
  package-for-review    build the review archive
  gate                  exit non-zero unless every (device-applicable) job of a manifest is complete
                        and scientifically valid (used between waves, e.g. after the Wave-0 controls)
  recovery-manifest     v8: per-run classification of existing results and the action each needs
  recompute-diagnostics v8: versioned recomputation of incomplete contraction diagnostics (separate records)
  recheck-insertions    v8: high-precision identity recheck of insertions flagged by the v7 rule
  replay-cycles         v8: replay cycle trajectories in a scratch root to recover pre-contraction states
  accept-stale          record an explicit, reasoned reuse of a run produced by different
                        result-determining code (otherwise such runs are 'stale' and block)
  verify-reload         fresh-process check of a P3 / P4 run: rebuild the saved modules and
                        reproduce the saved predictions and risks

Exit codes: run / gate return 1 if any job ended failed, invalid, timed_out or stale.
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _print(obj):
    print(json.dumps(obj, indent=1, sort_keys=True, default=str))


def cmd_inspect(a):
    from .env import inspect_environment
    info = inspect_environment(check_cuda=not a.no_cuda)
    if a.out:
        from .utils import atomic_write_json
        atomic_write_json(a.out, info)
    short = {k: v for k, v in info.items() if k != "pip_freeze"}
    _print(short)
    ok = info.get("cuda_smoke", {}).get("ok")
    if not a.no_cuda and not ok:
        print("\nWARNING: CUDA training check did not pass; see cuda_smoke above.", file=sys.stderr)


def cmd_fetch(a):
    from .data.registry import fetch_all
    _print(fetch_all(a.root, a.names.split(",") if a.names else None))


def _waves(s: str) -> list[int]:
    return [int(x) for x in s.split(",")]


def cmd_generate(a):
    from .orchestration.manifest import generate, factorial_checks
    from .utils import atomic_write_json
    B = generate(_waves(a.wave), a.scale, Path(a.results) if a.results else None,
                 Path(a.selection) if a.selection else None)
    entries = B.entries_list()
    cov = B.coverage()
    cov["factorials"] = factorial_checks(B)
    cov["scale"] = a.scale
    cov["waves"] = _waves(a.wave)
    print(f"waves {a.wave} scale {a.scale}: {len(entries)} jobs")
    print("by kind:", cov["by_kind"])
    print("factorials:", cov["factorials"])
    print("jobs per work package:", cov["jobs_per_work_package"])
    if cov["missing_work_packages"]:
        print("work packages with no job in these waves:", cov["missing_work_packages"])
    if a.verbose:
        for b, v in cov["blocks"].items():
            print(f"  {b:55s} {v['n_jobs']:6d}  {','.join(v['wp'])}")
    if a.dry_run:
        return
    out = Path(a.out or ROOT / "manifests" / f"wave{a.wave.replace(',', '_')}_{a.scale}.jsonl")
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_suffix(".tmp")
    with open(tmp, "w") as f:
        for e in entries:
            f.write(json.dumps(e, sort_keys=True) + "\n")
    os.replace(tmp, out)
    atomic_write_json(out.with_suffix(".coverage.json"), cov)
    print(f"wrote {out} and {out.with_suffix('.coverage.json')}")


def cmd_validate(a):
    from .config import resolve, run_id
    from .utils import read_jsonl
    ents = read_jsonl(a.manifest)
    seen, errors = set(), []
    for i, e in enumerate(ents):
        try:
            c = resolve(e["cfg"])
        except Exception as ex:
            errors.append(f"entry {i}: config does not resolve: {ex}")
            continue
        if run_id(c) != e["run_id"]:
            errors.append(f"entry {i}: run id mismatch (config changed or code version differs)")
        for d in e.get("deps", []):
            if d not in seen:
                errors.append(f"entry {i}: dependency {d} does not appear earlier")
        for role, pid in c.get("parents", {}).items():
            if pid not in e.get("deps", []):
                errors.append(f"entry {i}: parent {role}={pid} missing from deps")
        if e["run_id"] in seen:
            errors.append(f"entry {i}: duplicate run id")
        seen.add(e["run_id"])
    cov_p = Path(a.manifest).with_suffix(".coverage.json")
    res = {"entries": len(ents), "errors": errors[:50], "n_errors": len(errors)}
    if cov_p.exists():
        cov = json.load(open(cov_p))
        res["factorials"] = cov.get("factorials")
        f = cov.get("factorials", {})
        if f.get("wave1_core_trajectories") not in (None, 0):
            res["wave1_core_matches_810"] = f["wave1_core_trajectories"] == 810 and f["wave1_core_distinct_cells"] == 810
        if f.get("wave2_images_trajectories") not in (None, 0):
            res["wave2_images_matches_270"] = f["wave2_images_trajectories"] == 270 and \
                f["wave2_images_distinct_cells"] == 270
    _print(res)
    sys.exit(1 if errors else 0)


def _exec_cfg(a) -> dict:
    return {"device": a.device, "data_root": a.data_root, "allow_tf32": a.allow_tf32, "deterministic": not a.nondeterministic,
            "torch_threads": a.threads, "cudnn_benchmark": False}


def cmd_run(a):
    if a.threads:
        for k in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
            os.environ[k] = str(a.threads)
    if a.workers > 1 and a.worker_id is None:
        procs = []
        for k in range(a.workers):
            argv = [sys.executable, "-m", "cop.cli"] + [x for x in sys.argv[1:]] + ["--worker-id", str(k)]
            procs.append(subprocess.Popen(argv))
            time.sleep(2)
        rc = 0
        try:
            for p in procs:
                rc |= p.wait()
        except KeyboardInterrupt:
            for p in procs:
                p.send_signal(2)
            for p in procs:
                p.wait()
        sys.exit(rc)
    from .orchestration.runner import run_manifest
    w = f"w{a.worker_id or 0}"
    counts = run_manifest(a.manifest, a.results, _exec_cfg(a), resume=a.resume, worker=w,
                          only=a.only.split(",") if a.only else None, kinds=a.kinds.split(",") if a.kinds else None,
                          time_limit=a.time_limit, max_jobs=a.max_jobs, allow_code_change=a.allow_code_change,
                          rerun_stale=a.rerun_stale)
    print(f"[{w}] finished: {counts}")
    if counts.get("pending"):
        print(f"[{w}] interrupted; checkpoints written, continue with --resume", file=sys.stderr)
        sys.exit(130)
    bad = {k: v for k, v in counts.items() if k in ("failed", "invalid", "timed_out", "stale")}
    if bad:
        print(f"[{w}] NOT CLEAN: {bad} (see status.json / invalid.json of those runs)", file=sys.stderr)
        sys.exit(1)


def cmd_status(a):
    from .orchestration.runner import effective_status
    from .utils import read_jsonl, semantic_code_hash
    ents = read_jsonl(a.manifest)
    by_block: dict = {}
    tot: dict = {}
    sem = semantic_code_hash()
    for e in ents:
        st = effective_status(Path(a.results), e["run_id"], sem)
        tot[st] = tot.get(st, 0) + 1
        for b in e["blocks"]:
            by_block.setdefault(b, {}).setdefault(st, 0)
            by_block[b][st] += 1
    print("total:", tot)
    for b, d in sorted(by_block.items()):
        print(f"  {b:55s} {d}")


def cmd_eval_deletions(a):
    from .config import resolve, run_id
    from .orchestration.runner import run_job
    from .utils import read_json
    pdir = Path(a.results) / "runs" / a.run
    pc = read_json(pdir / "config.json")
    cfg = {"kind": "deletion", "data": pc["data"], "model": pc["model"], "train": pc["train"], "growth": pc["growth"],
           "seeds": pc["seeds"], "parents": {"trajectory": a.run}, "deletion": {"family": a.family},
           "tags": {"parent_stage": a.stage}, "wp": ["R1"], "block": "cli"}
    c = resolve(cfg)
    print(run_id(c), run_job(c, a.results, _exec_cfg(a)))


def cmd_repair(a):
    from .config import resolve, run_id
    from .orchestration.runner import run_job
    from .utils import read_json
    pdir = Path(a.results) / "runs" / a.parent
    pc = read_json(pdir / "config.json")
    cfg = {"kind": "repair", "data": pc["data"], "model": pc["model"], "train": pc["train"], "growth": pc["growth"],
           "seeds": {**pc["seeds"], "repair": a.seed}, "parents": {"trajectory": a.parent},
           "repair": {"deletion": a.deletion, "region": a.region, "budget_multiplier": a.budget, "target": a.target},
           "wp": ["R2", "R4"], "block": "cli"}
    c = resolve(cfg)
    print(run_id(c), run_job(c, a.results, _exec_cfg(a)))


def cmd_export(a):
    import torch
    from .graph.graph import GraphNet
    from .graph.export import export_compact
    from .graph.accounting import report
    ck = torch.load(a.checkpoint, map_location="cpu", weights_only=False)
    g = GraphNet.from_checkpoint(ck["model"] if "model" in ck else ck)
    exp, rep = export_compact(g)
    out = Path(a.out or str(a.checkpoint).replace(".pt", ".export.pt"))
    torch.save({"model": exp.checkpoint()}, out)
    _print({"before": rep["before"], "after": rep["after"], "notes": rep["notes"], "out": str(out)})


def cmd_verify(a):
    from .finite import verify_certificate
    _print(verify_certificate(a.certificate))


def cmd_calibrate(a):
    from .orchestration.calibrate import calibrate
    _print(calibrate(a.results, _exec_cfg(a), a.scale, a.families.split(",") if a.families else None))


def cmd_estimate(a):
    from .orchestration.calibrate import estimate
    _print(estimate(a.manifest, a.timing, a.workers))


def cmd_gate(a):
    """Every job of the manifest that applies to this device must be complete
    with validity 'valid' (or 'unverified' when --allow-unverified), and every contraction-diagnostic row
    of those jobs must be complete (or resolved by an 'ok' recomputed record)."""
    from .orchestration.runner import effective_status, status_of
    from .utils import read_jsonl, semantic_code_hash
    from .analysis.gates import run_diagnostic_rows
    sem = semantic_code_hash()
    problems, excluded_diag = [], []
    n = 0
    for e in read_jsonl(a.manifest):
        req = (e["cfg"].get("control") or {}).get("device")
        if req and not str(a.device).startswith(req):
            continue
        if a.kinds and e["cfg"]["kind"] not in a.kinds.split(","):
            continue
        n += 1
        st = effective_status(Path(a.results), e["run_id"], sem)
        val = status_of(Path(a.results), e["run_id"]).get("validity")
        ok = st == "complete" and (val in (None, "valid") or (a.allow_unverified and val == "unverified"))
        if not ok:
            problems.append({"run_id": e["run_id"], "kind": e["cfg"]["kind"], "blocks": e["blocks"], "status": st,
                             "validity": val})
            continue
        # v8: a complete job with an incomplete contraction diagnostic does not pass the gate
        _, bad, _ = run_diagnostic_rows(Path(a.results), e["run_id"], excluded_diag)
        if bad:
            problems.append({"run_id": e["run_id"], "kind": e["cfg"]["kind"], "blocks": e["blocks"], "status": st,
                             "validity": val, "incomplete_diagnostics": bad[:5], "n_incomplete_diagnostics": len(bad)})
    _print({"manifest": a.manifest, "checked": n, "problems": problems[:50], "n_problems": len(problems),
            "excluded_diagnostics_source_recorded_invalid": excluded_diag[:50]})
    sys.exit(1 if problems else 0)


def cmd_accept_stale(a):
    import getpass
    from .utils import append_jsonl, read_json, semantic_code_hash
    d = Path(a.results) / "runs" / a.run_id
    prov = read_json(d / "provenance.json") if (d / "provenance.json").exists() else {}
    rec = {"accepted_for_semantic_hash": semantic_code_hash(), "produced_by_semantic_hash": prov.get("semantic_hash"),
           "reason": a.reason, "time": time.time(), "user": getpass.getuser()}
    if not a.reason.strip():
        sys.exit("a reason is required")
    append_jsonl(d / "reuse_accepted.jsonl", rec)
    _print(rec)


def cmd_verify_reload(a):
    from .utils import read_json
    cfg = read_json(Path(a.run_dir) / "config.json")
    tk = (cfg.get("cop") or {}).get("task_kind")
    if tk == "alternatives":
        from .cop_pegs.alternatives import reload_alternatives as fn
    elif tk == "split":
        from .cop_pegs.split import reload_split as fn
    else:
        sys.exit(f"verify-reload applies to cop alternatives / split runs, not {cfg['kind']}:{tk}")
    res = fn(a.run_dir, a.data_root, a.device)
    _print(res)
    sys.exit(0 if res["ok"] else 1)


def summary_errors(res: dict) -> list[str]:
    """table-level analysis errors that summarize records instead of raising (figure errors are not counted)."""
    st = res.get("strengthening") or {}
    errs = []
    if st.get("error"):
        errs.append(f"strengthening: {st['error']}")
    if st.get("v13_tables_error"):
        errs.append(f"v13 tables: {st['v13_tables_error']}")
    return errs


def cmd_summarize(a):
    from .analysis.summarize import summarize
    res = summarize(a.results, a.manifest, a.out, historical=a.historical)
    _print(res)
    errs = summary_errors(res)
    if errs and a.strict:
        print("analysis errors (--strict):", *errs, sep="\n  ", file=sys.stderr)
        sys.exit(3)


def cmd_package(a):
    from .analysis.package import package_for_review
    print(package_for_review(a.results, a.out, a.manifests, a.max_ckpt_mb, a.max_evidence_mb))


def cmd_recovery(a):
    from .analysis import recovery as RV
    if a.recovery_cmd == "recovery-manifest":
        res = RV.recovery_manifest(a.results)
    elif a.recovery_cmd == "recompute-diagnostics":
        res = RV.recompute_diagnostics(a.results, a.device, a.data_root, a.runs.split(",") if a.runs else None,
                                       only_incomplete=not a.all)
    elif a.recovery_cmd == "recheck-insertions":
        res = RV.recheck_insertions(a.results, a.device, a.data_root, a.runs.split(",") if a.runs else None,
                                    all_insertions=a.all)
    else:
        if not a.scratch:
            sys.exit("--scratch is required (a separate folder outside RESULTS; runs are never written, only RESULTS/recomputed_diagnostics/)")
        res = RV.replay_cycles(a.results, a.scratch, a.device, a.data_root, a.runs.split(",") if a.runs else None)
    Path(a.out).write_text(json.dumps(res, indent=1, default=str))
    print(json.dumps(res.get("counts", {k: (len(v) if isinstance(v, (list, dict)) else v) for k, v in res.items()}),
                     indent=1, default=str))
    print("report:", a.out)


def main(argv=None):
    p = argparse.ArgumentParser(prog="cop", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = p.add_subparsers(dest="cmd", required=True)

    def execopts(q):
        q.add_argument("--device", default="cpu")
        q.add_argument("--data-root", default=os.environ.get("COP_DATA_ROOT", str(Path.home() / "cop_data")))
        q.add_argument("--allow-tf32", action="store_true", help="speed variant: TF32 matmul/conv (recorded)")
        q.add_argument("--nondeterministic", action="store_true")
        q.add_argument("--threads", type=int, default=None)

    q = sp.add_parser("inspect-environment")
    q.add_argument("--out")
    q.add_argument("--no-cuda", action="store_true")
    q.set_defaults(f=cmd_inspect)
    q = sp.add_parser("fetch-data")
    q.add_argument("--root", default=os.environ.get("COP_DATA_ROOT", str(Path.home() / "cop_data")))
    q.add_argument("--names")
    q.set_defaults(f=cmd_fetch)
    q = sp.add_parser("generate-manifest")
    q.add_argument("--wave", required=True, help="e.g. 1 or 0,1,2")
    q.add_argument("--scale", default="full", choices=["full", "pilot", "smoke"])
    q.add_argument("--results", help="results root (Wave 4 balanced parent selection)")
    q.add_argument("--selection", help="Wave 6 frozen selection YAML")
    q.add_argument("--out")
    q.add_argument("--dry-run", action="store_true")
    q.add_argument("-v", "--verbose", action="store_true")
    q.set_defaults(f=cmd_generate)
    q = sp.add_parser("validate-manifest")
    q.add_argument("--manifest", required=True)
    q.set_defaults(f=cmd_validate)
    q = sp.add_parser("run")
    q.add_argument("--manifest", required=True)
    q.add_argument("--results", default=os.environ.get("COP_RESULTS", str(Path.home() / "cop_results_v2")))
    execopts(q)
    q.add_argument("--resume", action="store_true")
    q.add_argument("--workers", type=int, default=1)
    q.add_argument("--worker-id", type=int, default=None)
    q.add_argument("--only")
    q.add_argument("--kinds")
    q.add_argument("--time-limit", type=float, default=None, help="per-job wall-time limit in seconds")
    q.add_argument("--max-jobs", type=int, default=None)
    q.add_argument("--allow-code-change", action="store_true",
                   help="continue an INCOMPLETE run whose checkpoints were written by different result-determining "
                        "code (recorded in the attempt); never applies to completed runs")
    q.add_argument("--rerun-stale", action="store_true",
                   help="archive and recompute completed / invalid runs produced by different result-determining code")
    q.set_defaults(f=cmd_run)
    q = sp.add_parser("gate")
    q.add_argument("--manifest", required=True)
    q.add_argument("--results", default=os.environ.get("COP_RESULTS", str(Path.home() / "cop_results_v2")))
    q.add_argument("--device", default="cpu")
    q.add_argument("--kinds")
    q.add_argument("--allow-unverified", action="store_true")
    q.set_defaults(f=cmd_gate)
    for name in ("recovery-manifest", "recompute-diagnostics", "recheck-insertions", "replay-cycles"):
        q = sp.add_parser(name)
        q.add_argument("--results", required=True)
        q.add_argument("--out", required=True)
        q.add_argument("--device", default="cpu")
        q.add_argument("--data-root", default=os.environ.get("COP_DATA_ROOT", str(Path.home() / "cop_data")))
        q.add_argument("--runs", help="comma-separated run ids (default: every applicable run)")
        q.add_argument("--all", action="store_true", help="recompute / recheck every record, not only flagged ones")
        q.add_argument("--scratch", help="replay-cycles: separate folder for the replays")
        q.set_defaults(f=cmd_recovery, recovery_cmd=name)
    q = sp.add_parser("accept-stale")
    q.add_argument("--run-id", required=True)
    q.add_argument("--reason", required=True)
    q.add_argument("--results", default=os.environ.get("COP_RESULTS", str(Path.home() / "cop_results_v2")))
    q.set_defaults(f=cmd_accept_stale)
    q = sp.add_parser("verify-reload")
    q.add_argument("--run-dir", required=True)
    q.add_argument("--data-root", default=os.environ.get("COP_DATA_ROOT", str(Path.home() / "cop_data")))
    q.add_argument("--device", default="cpu")
    q.set_defaults(f=cmd_verify_reload)
    q = sp.add_parser("status")
    q.add_argument("--manifest", required=True)
    q.add_argument("--results", default=os.environ.get("COP_RESULTS", str(Path.home() / "cop_results_v2")))
    q.set_defaults(f=cmd_status)
    q = sp.add_parser("evaluate-deletions")
    q.add_argument("--run", required=True, help="trajectory run id")
    q.add_argument("--stage", default="final")
    q.add_argument("--family", default="auto", choices=["auto", "exhaustive", "structured"])
    q.add_argument("--results", default=os.environ.get("COP_RESULTS", str(Path.home() / "cop_results_v2")))
    execopts(q)
    q.set_defaults(f=cmd_eval_deletions)
    q = sp.add_parser("repair")
    q.add_argument("--parent", required=True)
    q.add_argument("--deletion", default="max_single")
    q.add_argument("--region", default="full")
    q.add_argument("--budget", type=float, default=1.0)
    q.add_argument("--target", default="task")
    q.add_argument("--seed", type=int, default=0)
    q.add_argument("--results", default=os.environ.get("COP_RESULTS", str(Path.home() / "cop_results_v2")))
    execopts(q)
    q.set_defaults(f=cmd_repair)
    q = sp.add_parser("export-compact")
    q.add_argument("--checkpoint", required=True)
    q.add_argument("--out")
    q.set_defaults(f=cmd_export)
    q = sp.add_parser("verify-certificate")
    q.add_argument("--certificate", required=True)
    q.set_defaults(f=cmd_verify)
    q = sp.add_parser("calibrate")
    q.add_argument("--results", default=os.environ.get("COP_RESULTS", str(Path.home() / "cop_results_v2")) + "_calibration")
    q.add_argument("--scale", default="pilot", choices=["full", "pilot", "smoke"])
    q.add_argument("--families")
    execopts(q)
    q.set_defaults(f=cmd_calibrate)
    q = sp.add_parser("estimate")
    q.add_argument("--manifest", required=True)
    q.add_argument("--timing", required=True)
    q.add_argument("--workers", type=int, default=1)
    q.set_defaults(f=cmd_estimate)
    q = sp.add_parser("summarize")
    q.add_argument("--results", default=os.environ.get("COP_RESULTS", str(Path.home() / "cop_results_v2")))
    q.add_argument("--manifest", action="append", default=[])
    q.add_argument("--out", default=None)
    q.add_argument("--historical", action="store_true",
                   help="v13: re-analyse a read-only folder of earlier results with the current analysis code "
                        "(staleness judged against the code that produced the runs; nothing is retrained)")
    q.add_argument("--strict", action="store_true",
                   help="v16: exit 3 when a table-level analysis (strengthening, v13 / v15 tables) failed; the "
                        "summary and the error traceback are still written")
    q.set_defaults(f=cmd_summarize)
    q = sp.add_parser("package-for-review")
    q.add_argument("--results", default=os.environ.get("COP_RESULTS", str(Path.home() / "cop_results_v2")))
    q.add_argument("--manifests", default=str(ROOT / "manifests"))
    q.add_argument("--out", default=str(ROOT.parent / "cop_review_bundle.zip"))
    q.add_argument("--max-ckpt-mb", type=float, default=50.0)
    q.add_argument("--max-evidence-mb", type=float, default=1000.0)
    q.set_defaults(f=cmd_package)
    a = p.parse_args(argv)
    a.f(a)


if __name__ == "__main__":
    main()
