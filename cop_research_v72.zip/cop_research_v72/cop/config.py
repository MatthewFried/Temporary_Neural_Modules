"""Job configuration schema, strict validation and run identity.

A job config has a `kind` and the sections that kind uses.  Every section is
merged onto its defaults with `strict_merge`: unknown keys, sections the kind
does not use, and unsupported value combinations raise ConfigError.  The
resolved config is immutable JSON; its hash (plus CODE_VERSION) is the run id.

Execution-only fields (device, worker id, paths) live in a separate `exec`
dict that is recorded with every attempt but never enters the run id.
"""
from __future__ import annotations

import copy
from typing import Any

from .utils import stable_hash, canonical_json

CODE_VERSION = "cop-7.21.0"   # bump when experiment SEMANTICS change; exact code hash is recorded per attempt
# v2.0.0: corrections after the independent v1 audit (see AUDIT_RESPONSE.md); v1 run ids stay distinct
# v3.0.0: strengthening extension (docs/STRENGTHENING.md): design identity section, train.target wired,
#         compute accounting, new controls and routes back; v2 run ids stay distinct


class ConfigError(ValueError):
    pass


FREE = object()   # marker: free-form dict validated elsewhere


def strict_merge(defaults: dict, user: dict | None, path: str = "") -> dict:
    user = {} if user is None else user
    if not isinstance(user, dict):
        raise ConfigError(f"{path}: expected a mapping, got {type(user).__name__}")
    unknown = set(user) - set(defaults)
    if unknown:
        raise ConfigError(f"{path}: unknown keys {sorted(unknown)}; allowed: {sorted(defaults)}")
    out = {}
    for k, dv in defaults.items():
        p = f"{path}.{k}" if path else k
        if k not in user:
            out[k] = copy.deepcopy(dv) if dv is not FREE else {}
            continue
        uv = user[k]
        if dv is FREE:
            if not isinstance(uv, dict):
                raise ConfigError(f"{p}: expected mapping")
            out[k] = copy.deepcopy(uv)
        elif isinstance(dv, dict) and dv:
            out[k] = strict_merge(dv, uv, p)
        elif isinstance(dv, bool):
            if not isinstance(uv, bool):
                raise ConfigError(f"{p}: expected bool, got {uv!r}")
            out[k] = uv
        elif isinstance(dv, float):
            if isinstance(uv, bool) or not isinstance(uv, (int, float)):
                if uv is None:
                    out[k] = None
                    continue
                raise ConfigError(f"{p}: expected number, got {uv!r}")
            out[k] = float(uv)
        elif isinstance(dv, int):
            if isinstance(uv, float) and uv.is_integer():
                uv = int(uv)
            if isinstance(uv, bool) or not isinstance(uv, (int, str)) and uv is not None:
                raise ConfigError(f"{p}: expected int, got {uv!r}")
            out[k] = uv
        else:
            out[k] = copy.deepcopy(uv)
    return out


def check_choice(cfg: dict, key: str, choices, path: str) -> None:
    if cfg[key] not in choices:
        raise ConfigError(f"{path}.{key}={cfg[key]!r} not in {list(choices)}")


# =============================================================================
# Section defaults
# =============================================================================

TRAIN_DEFAULTS = {
    "optimizer": "adamw",            # adamw | sgd
    "lr": 1e-3,
    "momentum": 0.0,                 # sgd only
    "betas": [0.9, 0.999],
    "weight_decay": 0.0,
    "batch_size": 128,
    "baseline_updates": 2000,
    "lr_schedule": "constant",       # constant | cosine (cosine restarts per training segment)
    "warmup": 0,
    "grad_clip": 0.0,
    "precision": "fp32",             # fp32 | fp64 | bf16_autocast (speed variant; separately named)
    "loss": "auto",                  # auto | ce | mse
    "target": "task",                # task (T1: observed labels / targets) | teacher_star (T0: the known compact
                                     # teacher's clean output; datasets with a known teacher only)
    "distill_temperature": 1.0,
    "freeze": "none",                # none | original_frozen | implants_frozen | upstream_only | downstream_only
                                     # | upstream_plus_implants | downstream_plus_implants
    "opt_state_on_edit": "preserve", # preserve | reset
    "stream": "fixed",               # fixed (finite training set) | fresh (new samples each batch; synthetic only)
    "eval_every": 0,                 # 0 = evaluate only at stage boundaries
    "checkpoint_every": 0,           # 0 = only stage boundaries
    "eval_batch": 4096,
    "decay_mode": "uniform",         # uniform (decay on every trainable tensor: factor-wise for factorised maps)
                                     # | composite (no decay on factor tensors of linear_factor / node_factorization /
                                     # node_split implants; train.weight_decay * ||folded map||^2 added to the loss)
    "bn_stats": "follow",            # follow (BN running stats update iff the BN parameters are trainable)
                                     # | frozen (every BN in eval mode during training) | update (stats always update)
    "freeze_schedule": "fixed",      # fixed (train.freeze throughout) | alternate (implant-only and backbone-only phases
                                     # of freeze_period updates) | release (implant-only for release_after updates of
                                     # each round, then train.freeze)
    "freeze_period": 0,
    "release_after": 0,
    "sampler": "uniform",            # uniform | group_balanced (oversampling of rare groups: a disclosed intervention)
    "select_candidates": 0,          # v13: declared validation candidates in the job's final compact phase
                                     # (0 = no selection; the fixed-budget endpoint is always recorded)
    "select_partition": "val",       # a validation partition only (val or val_*); never test/shift/rare
    "quant_range": "fixed",          # v15 finite-peg training recipe: fixed (calibrated once) | ema (train-only
                                     # adaptive global clipping range, frozen in eval; shared across examples)
    "quant_range_momentum": 0.99,    # ema: lo/hi <- m * lo/hi + (1 - m) * batch quantile (0.001 / 0.999)
    "quant_warmup_updates": 0,       # > 0: the uniform pegs pass values through (continuous) for this many of the
                                     # job's updates, then are calibrated on training activations and quantise:
                                     # a capacity-relaxation history control, NOT strict finite-capacity training
    "quant_ste_margin": 0.0,         # v17: uniform pegs pass the straight-through gradient for inputs up to
                                     # margin x (hi - lo) outside the range (the forward value is unchanged).  0 =
                                     # the strict v13-v16 rule, under which inputs that sit exactly at the range's
                                     # edge (discrete inputs, e.g. behind another finite peg) can land one rounding
                                     # step outside it and get exactly zero gradient
    "snapshot_at": [],               # update counts (of this job's own training) at which a full checkpoint
                                     # 'snap_<u>' is saved: baseline expansion points (F06d), release offsets (F04e, B)
    "freeze_inputs": "none",         # v42: none | shortcut.  The first backbone layer's weights that read the named
                                     # input group (the shortcut feature of the shortcut data, unrotated inputs only)
                                     # get no gradient and are restored after every update, so they stay at the
                                     # values they had when this job's training started (f0's for a trajectory or a
                                     # compact continuation from f0, unchanged since f0 for a child of a frozen
                                     # trajectory); the rest of the network trains as usual
    "audit_batches": False,          # v45: the ordered minibatch ids as a hash chain in the trainer state
    "freeze_backbone": "none",       # v44: none | downstream.  Every backbone layer after the first is held at its
                                     # values at the job's start (no gradient; restored after every update); the
                                     # first layer and the additions train
    "log_update_norms": False,       # v43: the Euclidean norm of every update (backbone, first layer, its causal /
                                     # shortcut columns, additions) summed into a cumulative path length in the
                                     # trainer state, the first 32 updates of each segment kept; no effect on training
}

GROWTH_DEFAULTS = {
    "topology": "none",
    # none | layered | parallel | recursive | recursive_branch                      (Wave-1 core five)
    # tree_depth2 (E3 order study) | hard_submodule | recursive_descendants | chain_in_branch
    # | dup_branch | cancel_pair | inverse_pair | linear_factor | concat_expand | node_factorization
    # | complementary | specialized | known_module | bridge
    "rounds": 3,
    "updates_per_round": 1000,
    "compute_schedule": "per_round",  # per_round (constant compute per round) | total (constant total compute)
    "total_updates": 0,               # used when compute_schedule == total
    "construction": "residual_zero",  # residual_zero | linear_factor | concat_expand | inverse_pair | cancel_pair
    "width": 32,
    "act": "relu",
    "shape": "chain",                 # chain | wide | alternating | separated   (E1)
    "narrow_width": 8,
    "wide_width": 128,
    "cut_kind": "post_act",
    "cut_where": "middle",
    "cut_subset": None,               # named edge subset of the cutpoint (e.g. 'skip', 'branch')
    "channels": None,                 # int k => first k channels; list => explicit; None => full width
    "channel_order": "first",         # first | random (permutation control) | top_variance (feature-guided, train data)
    "positions": None,                # token/spatial subset spec, e.g. {'last': 1} or {'region': [0,16,0,16]}
    "inner_cut": "hidden",            # cutpoint inside implants for recursive insertion
    "merge": "sum",                   # sum | concat | route
    "branches_per_round": 1,
    "tie": "untied",                  # untied | tied | enforced | learned
    "symmetry_noise": 0.0,            # >0 makes the insertion explicitly approximate (L0)
    "split": 0.5,                     # duplicated-branch split; != 0.5 is an exact symmetry breaker
    "route_split": 0.3,               # route merges: exact expert split s / (1 - s) when growing next to trained experts
    "inverse_kind": "coupling",       # coupling | linear
    "order": "breadth_first",         # breadth_first | depth_first (leaf-first)
    "schedule": "incremental",        # incremental | all_at_once | from_scratch
    "policy": "fixed",                # fixed | random | dependence_seeking | removability_preserving
    "policy_candidates": 4,
    "policy_probe_updates": 100,
    "driver": "fixed",                # fixed | fresh | changing_target | output_constrained | neutral_mutation
                                      # | stationary_self (zero-loss self-distillation control)
    "driver_strength": 0.0,
    "aux_objective": "none",          # none | aligned | antagonistic  (deliberate intervention)
    "aux_weight": 0.1,
    "replacement_pressure": 0.0,      # L2 penalty on implant contributions during growth (I4)
    "peg_dim": 0,                     # >0: communication limit (peg) placed around each implant (I4)
    "stable_pegs": False,             # freeze those pegs after placement (I4)
    "known_module": "none",           # none | poly | pretrained | random_matched | mixing_random | mixing_aligned
    "known_trainable": True,
    "pretrain_updates": 500,
    "specialize": "class_halves",     # class_halves (observed labels) | class_halves_oracle (clean labels:
                                      # privileged-information intervention) | aux   (for topology specialized)
    "spec_partition": "auto",         # v13: auto (group ids if present, else labels: v12) | group | observed_label
    "spec_random_fraction": None,    # v15: branch-a share of the random partitions (null: the training set's
                                     # group-0 share, as random_matched in v13)
    "spec_block_period": 0,           # v22: spec_partition=cyclic_blocks: updates per cycle (each example spends
                                     # round(spec_random_fraction x period) updates of every cycle in branch a,
                                     # the rest in branch b; phases spread uniformly over the examples)
    "spec_mask_route": "gradient",    # v25: gradient (masks act on gradients only; every example's forward pass uses
                                     # both branches, as in every earlier version) | forward (a branch's OUTPUT is
                                     # zeroed for the examples not assigned to it in that batch, so its gradient
                                     # is masked too: the forward-masked comparator of memorization sinks /
                                     # example-tied dropout) | parameter (v26: only the branch's own parameters are
                                     # masked; every example's gradient still flows through the branch into the
                                     # upstream backbone).  Evaluation never applies masks.
    "spec_quota": {"fraction": 0.95, "b_run": 0},
                                     # v23: spec_partition=matched_quota: per growth round, every example gets
                                     # floor(fraction x appearances + 1/2) branch-a appearances on the replayed
                                     # minibatch stream; b_run 0 = its b-appearances in one run, k >= 1 = runs of at
                                     # most k appearances (persistence varies, quotas do not)
    "spec_reassign": {"mode": "none", "start": 0, "end": None, "period": 0, "fraction": 0.0},
                                     # v19: change a FIXED random split (random_matched) during training by
                                     # exchanging pairs (one branch-a, one branch-b example), so both branches
                                     # keep their exact example counts.  Units: this job's own training updates.
                                     # abrupt: one exchange at `start` of `fraction` of the smaller side (1 = the
                                     # smaller side's whole responsibility moves); abrupt_redraw: a fresh
                                     # independent split at `start`; periodic: `fraction` every `period` updates
                                     # in [start, end); periodic_redraw: a fresh independent split every `period`
                                     # updates in [start, end) (between fixed and per-batch redrawn). periodic
                                     # picks fresh random pairs each event, so the share of examples still in
                                     # their original branch decays geometrically. ramp: the CUMULATIVE share of
                                     # the smaller side's original examples moved rises linearly to `fraction`
                                     # over the events in [start, end); only unmoved examples are exchanged
                                      # | random_matched (deterministic partition with the group-0 proportion)
    "peg_bits": 0,                    # >0: quantise the I4 communication-limit pegs to this many bits/coord
    "evaluate_deletions": True,
    "crossover": True,
    "probes": True,
    # ---- strengthening extension (v3) ----
    "factor_balance": 1.0,            # node_factorization: W1 * c, W2 / c (same function, different factor geometry)
    "inverse_cond": None,             # inverse_pair (linear): condition number of A (None = default random draw)
    "kernel": 1,                      # conv implants: kernel size of the first implant layer (F10b)
    "nonlinearity": 1.0,              # residual implants: s in [0,1]; act = leaky with negative slope 1 - s
                                      # (s = 0 linear / foldable, s = 1 the plain activation)  (F01d)
    "bottleneck_dim": 4,              # topology bottleneck: rank k of the series interface (F01e)
    "bottleneck_bits": 0,             # >0: uniform quantisation of the bottleneck code (finite interface)
    "n_chunks": 4,                    # topology chunked: coordinatewise branches on disjoint channel chunks (F03e)
    "width_match": "none",            # none | params | macs: choose each implant's width so the added params / MACs
    "width_match_target": 0,          # match this target per insertion (F03 equal-cost panels)
    "known_access": "x",              # known_module input: x (raw input; extra context, disclosed) | cut (the cut)
    "bridge_inputs": "all",           # topology bridge: input features the helper reads: all | causal | shortcut
                                      # | random (a seeded choice between causal and shortcut; datasets with a
                                      # declared feature_layout, e.g. shortcut)   (mechanism A)
    "known_partial": False,           # known_module trainable but only its last layer (F10e partial)
    "helper_schedule": "both",        # twin_helpers: both | alternate | single | stochastic   (mechanism G)
    "helper_period": 50,
    "helper_keep": 0.5,
    "contract_every": 0,              # >0: grow / contract cycles: contract all implants after every k rounds (F06a)
    "contract_method": "auto",        # auto (fold if affine, else gate anneal) | abrupt | gate
    "contract_updates": 0,            # updates of each contraction (gate anneal + repair), part of the round budget
    "contract_trigger": "fixed",      # fixed (every contract_every rounds) | damage (contract when the val damage of
    "contract_threshold": 0.0,        # an abrupt deletion exceeds this; probe cost counted)   (F06e)
    "cycle_cut": "same",              # same | moving (cut advances each cycle) | nested (recursive growth inside a
                                      # cycle; needs a recursive topology and contract_every >= 2)
    "mixer": "mlp",                   # F10c: residual implant body: mlp (pointwise) | attention (causal self-attention
                                      # over sequence positions; transformer cuts)
}

DELETION_DEFAULTS = {
    "family": "auto",                 # auto | exhaustive | structured
    "max_exhaustive_atoms": 10,
    "n_sampled": 64,
    "sample_sizes": [2, 3, 4],
    "partitions": ["val", "test"],
    "compare_greedy": False,          # also run greedy one-at-a-time removal with the same evaluation budget (F05e)
}

REPAIR_DEFAULTS = {
    "deletion": "max_single",         # max_single | min_single | all | generation:<k> | subtree:<id> | atoms:<a,b>
    "region": "full",                 # none | incident_adapters | adjacent | containing_pearl | downstream
                                      # | full | fresh_original | fresh_smaller
    "target": "task",                 # task | expanded | original
    "budget_multiplier": 1.0,
    "budget_reference": "growth_total",  # growth_total | per_round
    "adapter_width": 16,
    "adjacent_radius": 1,
    "eval_points": 10,
    "extend_if_inconclusive": True,
    "extension_factor": 4.0,
    "extend_on": "target",            # criterion that decides an extension: target (the configured repair
                                      # target's criterion) | task | both (either unmet)
    "opt_state": "reset",             # reset | preserve (the parent's optimizer state for the surviving tensors)
    "calibration_size": 256,          # data_access=calibration: the first n training INPUTS retained (labels unused:
                                      # the repair target must be the expanded or original model)
    "data_access": "train",           # train | calibration (repair.calibration_size training inputs) | fresh (new
                                      # same-distribution samples; synthetic) | checkpoint (oracle: restore the parent's
                                      # pre-growth tensors of the repair region before training)   (F08e)
}

DISSIPATION_DEFAULTS = {
    "method": "abrupt",               # abrupt | linear | cosine | residual_penalty | inverse_restore | branch_merge
                                      # | group_removal | peg_replacement
    "order": "joint",                 # joint | ancestor_first | descendant_first
    "speed_updates": 500,
    "penalty": 1e-2,
    "post_updates": 500,
    "path_eval_points": 20,
    "targets": "all",                 # all | generation:<k> | atoms:<a,b>
    "target": "task",                 # task | expanded (match the parent's expanded model during the path)
    "bypass_keep": 0.5,               # stochastic_bypass: keep probability of each target per batch
    "bypass_rescale": False,          # stochastic_bypass: scale kept contributions by 1 / keep (activation scale)
    "require_f0_architecture": True,  # export must equal the parent's f0 architecture (structure and parameters)
    # ---- v13 (audit D1)
    "post_match_macs_of": "",         # parent role of a reference job: the final compact phase gets as many
                                      # updates as needed for this job's estimated training MACs to equal the
                                      # reference's (MAC-matched panel); "" = post_updates as declared
    "save_path_checkpoints": False,   # save a checkpoint at every path evaluation point (dense path states)
    "path_full_eval": False,          # evaluate every partition (test / rare / shift / group metrics), logit norm and
                                      # prediction drift from the start at every path point
    # ---- v19: hybrid start states (swap experiments)
    "hybrid": {"donor_role": "", "donor_stage": "final", "slots": []},
                                      # donor_role set: before anything else, the parameters of the implants named
                                      # by `slots` (implant slot labels, e.g. spec/r1/a; ["all"] = every implant)
                                      # and of their descendants are copied from the donor parent's checkpoint
                                      # `donor_stage` into the receiver (the trajectory parent at tags.parent_stage).
                                      # Both graphs must be structurally identical; nothing else is copied
    # ---- v20: explicit removal policy (review item 5) and the frozen swap scan (review item 7)
    "removal_masks": "released",      # released: v19 behaviour, every branch receives every example's gradient
                                      # during removal (no gradient masks); retained: the specialised branches
                                      # keep the gradient masks of the split in force at the start checkpoint
                                      # (masks act on gradients only, never on the forward route)
    "gate_schedule": "anneal",        # anneal: the gates follow the method's schedule (v19); hold: the gates
                                      # stay at 1 for the transition and the additions are then removed at once
    "optimizer_policy": "reset_each_phase",  # every training phase (transition, repair) starts a fresh
                                      # optimizer state (v19 behaviour, now recorded); the only supported value
    "rebuild": {"backbone": "receiver", "implants": "receiver"},
                                      # v22: backbone receiver | f0 (the untouched baseline's backbone modules);
                                      # implants receiver | fresh (every implant reset to its insertion state);
                                      # applied to the start state before a hybrid copy; f0 + fresh must equal f0
    "early_eval": [],                 # v22: extra evaluation points (updates from the start of every repair phase)
    "split_updates": 0,               # v31: method keep / abrupt: split the single training phase at this update
                                      # (a fresh optimizer at the boundary, the minibatch stream continuing), so a
                                      # fork matches the linear removal's reset times (set to its speed_updates)
    "keep_frozen_implants": False,    # v30: method keep (the expanded model trained on for post_updates WITH its
                                      # additions, nothing removed): true = the additions' parameters are frozen;
                                      # v32 method linear: frozen during the transition (with gate_schedule hold:
                                      # the additions stay coupled, unchanged, for speed_updates, then go)
    "restore_before_repair": "none",  # v30: none | all_but_first: at the start of the post-removal repair, every
                                      # backbone layer except the first is reset to f0 (use with repair_scope first:
                                      # can the first layer acquire the benefit directly in f0's surroundings?)
    "repair_subset": 0,               # v26: >0: the repair phases after removal (post_* / recover_*) sample only a
                                      # fixed random subset of this many training examples (same updates); 0 = all
    "repair_scope": "full",           # v25: which compact parameters learn in the repair phases after removal
                                      # (post_* / recover_*): full | readout (the last parametric layer) | top2
                                      # (the last two) | first (v29: the first parametric layer only).  The transition (anneal) phase always trains everything.
    "swap_scan": {"donor_role": "", "donor_stage": "final"},
                                      # donor_role set: before training, every subset of the specialised branch
                                      # players (2^n, the empty set is the receiver itself) is copied from the
                                      # donor into a copy of the start state and scored with frozen weights,
                                      # raw and after an affine interface alignment fitted on training inputs
}

CRITERIA_DEFAULTS = {
    "acc_drop_pp": [0.1, 0.5, 1.0],
    "nmse": [1e-4, 1e-3, 1e-2],
    "js": [1e-3, 1e-2],
    "identity_rel_tol_fp32": 1e-5,
    "identity_rel_tol_fp64": 1e-10,
}

EVAL_DEFAULTS = {
    "partitions": ["train", "val", "test"],   # train = the (possibly noisy) training subset: generalisation gap
    "extra": True,                    # also evaluate extra partitions (shift, rare, extrap, complete_domain)
    "save_predictions": ["baseline", "final"],
    "calib_size": 2048,               # training calibration inputs for equivalence checks
    "stress_scale": 4.0,              # stress inputs = calibration inputs * scale + noise
}

SEED_DEFAULTS = {
    "optimizer": 0,      # also seeds init and minibatch streams unless given separately
    "init": None,
    "minibatch": None,
    "augmentation": None,
    "insertion": 0,
    "partition": None,   # v17: the random gradient-partition draw (fixed and redrawn splits); None = insertion
    "deletion": 0,
    "repair": 0,
    "policy": 0,
    "peg": 0,
    "mutation": 0,
    "assembly": 0,
}

PEG_DEFAULTS = {
    "dim": 8,
    "mode": "none",                   # none | uniform | vq | multi
    "bits": 8,
    "codebook_size": 16,
    "n_messages": 1,
    "float_bits": 32,                 # communication accounting precision for continuous pegs
    "temp_channel": 0,                # width of the temporary residual channel (0 = none)
    "bypass": True,                   # start with alpha=1 bypass (identity) and anneal
    "anneal_updates": 1000,
    "init": "pca",                    # pca | random
    # ---- strengthening extension (v3) ----
    "temp_open_updates": 0,           # mechanism H: updates with the temporary channel (bridge) fully open and the
                                      # pegs active, before it is retired
    "temp_target": "all",             # what learns while the bridge is retired: all | peg (the bridged peg and the
                                      # bridge only) | pegs (every peg and the bridge) | adapter (the bridge is not
                                      # retired: it is kept as a permanent adapter; its bits / params are counted)
    "temp_on": "all",                 # pegs with a temporary channel: all | middle (one difficult interface)
    "redundancy": 1,                  # F07e: repetition code: dim/redundancy distinct coordinates sent redundancy
                                      # times (equal total bits); decoded by averaging redundancy route decoders
    "temp_anneal_updates": None,      # v5: updates over which the bridge is retired (null = anneal_updates; 1 =
                                      # abrupt removal)
    "route_dropout": 0.0,             # F07e: per update, probability of erasing one random block of the quantised
                                      # code (blocks = redundancy routes, or cop.route_blocks for an ordinary peg);
                                      # the erased block is filled with its training mean at the start of training
}

COP_DEFAULTS = {
    "task_kind": "chain",             # chain | alternatives | split | cycles | baseline | locality (v5) | recode (v19)
    # ---- v13 (audit D3)
    "global_match_macs_of": "",       # chain: parent role of a reference chain; global training gets the updates that
                                      # bring this job's estimated training MACs to the reference's (MAC panel)
    "decoder_refit_updates": 0,       # chain on a finite cube: after export, freeze the encoder side of the
                                      # bottleneck peg and retrain only the decoder side for this many updates,
                                      # then re-score (a diagnostic of decoder optimisation; not the chain's work)
    "n_pearls": 3,
    "pearl_depth": 2,
    "pearl_width": 64,
    "placement": "regular",           # regular | random | known | adaptive
    "placement_candidates": 6,
    "branch_pegs": "none",            # none | shared | separate
    "peg_edit": "none",               # none | move | split | merge
    "route_blocks": 0,                # F07e control: cut an ordinary peg's code into this many blocks and report the
                                      # damage of losing each block (a peg with redundancy r uses its r routes)
    "route_repair_updates": 0,        # F07e: remove block 0 (route 0) at the selected pegs, then train the whole
                                      # chain for this many updates with the block still removed
    "route_remove": "all_pegs",       # all_pegs | middle_peg
    "alt_kinds": ["mlp_large", "mlp_small", "lowrank"],   # + linear | sparse | table
    # ---- v19 interface recoding (task_kind recode; parents.chain = a trained run with uniform finite pegs)
    "recode_relabels": ["identity", "bitperm", "bitperm_symmetric", "xor_chain", "gf2_random", "codeword_perm"],
    "recode_sides": ["out", "in", "both"],   # which interface of the pearl is relabelled
    "recode_relabel_seeds": 2,        # encoding draws of each random relabelling (identity / xor_chain: one)
    "recode_fit_seeds": 2,            # v20: replacement initialisations, PAIRED across relabellings
    "recode_regimes": ["observed", "full_alphabet"],   # v20: training-reachable support (frequency-weighted) |
                                      # every incoming symbol (uniform): the whole known finite map
    "recode_classes": ["linear", "mlp16", "mlp64"],   # replacement classes (logistic per bit; 1-hidden-layer MLP)
    "recode_updates": 1000,           # full-batch Adam updates per fit
    "recode_lr": 1e-2,
    "recode_eval_every": 25,
    "recode_max_bits": 12,            # pearls whose messages exceed this many bits are skipped (tables 2^bits)
    "recode_pred_atol": 1e-5,         # v20: per-example prediction tolerance of the exact-table controls, times
                                      # max(1, max |reference prediction|)
    "recode_symmetry_rtol": 1e-6,     # v20.1: bitperm_symmetric vs identity loss curve, relative (fits in float64)
    "alt_training": "independent",    # independent | joint | shared_interface
    "code_kind": "fixed_teacher",     # fixed_teacher | learned | aligned | task_only (valid pairs checked)
    "interface_weight": 1.0,
    "local_inputs": "teacher",        # teacher | on_policy
    "heldout_assemblies": 0.25,
    "split_into": 2,                  # 2 | 4 | 8
    "split_shared": False,
    "split_budget": "matched",        # matched | unconstrained
    "cycles": 3,
    "cycle_order": "input_to_output", # input_to_output | output_to_input | center_out | leaf_inward
    "cycle_pegs": "fixed",            # fixed | relearned | none
    "cycle_peg_maps": "auto",         # V3-07 independent switches (auto = from cycle_pegs: fixed -> frozen / constant /
    "cycle_peg_width": "auto",        # no recalibration; relearned -> learned / narrowed / recalibrated):
    "cycle_peg_recalibrate": "auto",  # maps frozen | learned; width constant | narrowed; recalibrate yes | no
    "grow_width": 64,
    "replace_width": 16,
    "baseline": "expand_peg_replace", # direct_small | distill (both: the ACTUAL exported endpoint architecture
                                      # of the parent cycles run, re-initialised) | direct_small_all_pearls
                                      # (independent: every pearl replaced by a fresh small module)
                                      # | replace_no_expand | progressive_no_peg | peg_no_expand | expand_no_peg
                                      # | expand_peg_replace | shared_fold
    "local_updates": 1000,
    "global_updates": 2000,
    # ---- v5 paired interface-locality experiment (task_kind locality) ----
    "locality_interface": "finite_learned",   # none | continuous | continuous_stabilized | finite_learned |
                                              # finite_stabilized (stabilized: peg maps frozen after the anneal)
    "locality_checkpoints": [0.25, 0.5, 1.0], # co-adaptation checkpoints, fractions of the endpoint training
    "locality_repair_updates": 200,           # budget of every nested repair scope fork
    "locality_eval_points": 4,
    "locality_pearl": -1,                     # replaced pearl (-1: the middle pearl)
    "locality_controls": False,               # v13 (D4): add the exact-replacement positive control and a
                                              # code-matching repair fork (replacement trained to reproduce the
                                              # original code at the next interface instead of the task)
    "interface_enforce": "enforced",  # enforced: every replacement / adapter output passes the destination
                                      # peg quantiser (finite alphabet kept) | relaxed: continuous outputs
                                      # (a separately named condition; communication counted at float_bits)
}

PROBE_DEFAULTS = {"ridge": 1e-3}

CONTINUE_DEFAULTS = {
    "start": "baseline",              # parent role whose checkpoint is continued
    "start_stage": "baseline",        # checkpoint stage of that parent (e.g. baseline, export, after_repair, snap_<u>)
    "updates": 0,                     # budget when budget = fixed
    "budget": "fixed",                # fixed | parent_compute (C2: updates so that training MACs match the
                                      # budget parent's measured training MACs) | parent_updates
    "budget_parent": "treated",
    "budget_add_f0": False,           # add f0's own training (updates / MACs of the baseline parent) to a derived
                                      # budget: endpoint-matched controls that re-initialise the treated endpoint
    "arm": "plain",                   # plain (C1 / durability) | lr_restart | opt_reset | perturb (C7)
                                      # | distill (C4: teacher = an expanded model) | self_distill (C5: born-again)
                                      # | prune_regrow (C8)
    "teacher": "",                    # parent role of the teacher (distill)
    "teacher_stage": "final",
    "distill_alpha": 1.0,             # loss = alpha * distill + (1 - alpha) * task
    "reinit": False,                  # student re-initialised (born-again from scratch) instead of continued
    "inherit_state": True,            # continue the start checkpoint's trainer state (streams, optimizer); false
                                      # for a common continuation of different models (durability): every arm
                                      # then starts from the same fresh streams (seeds) and a fresh optimizer
    "perturb_rel": 0.01,              # perturb: Gaussian noise with norm perturb_rel * ||theta|| per tensor
    "restart_warmup": 0,              # lr_restart: warmup updates of the restarted schedule
    "prune_frac": 0.3,                # prune_regrow: fraction of channels pruned per event
    "prune_period": 200,              # updates between prune events
    "prune_duration": 50,             # updates trained while pruned, before the regrowth (orthogonal re-init)
    "eval_points": 4,
    "segments": [],                   # updates per training segment, mirroring the treated history's segments
                                      # (lr schedules and arm events restart per segment); [] = one segment
    "eval_at": [],                    # extra evaluation points (updates), e.g. the cumulative budgets of cycles
    # ---- v22: example-tied dropout comparator (arm example_tied_dropout, Maini et al. 2023)
    "etd_p_gen": 0.4,                 # fraction of each hidden layer's units always active (generalization neurons)
    "etd_p_mem": 0.2,                 # fraction of the remaining (memorization) pool active for each example
    "repair_early_eval": [],          # v23: example_tied_dropout: dense observations at these offsets after the drop
    "trainable_scope": "full",        # v29: full | first (only the first parametric layer of the compact network
                                      # learns: the compact control of a first-layer-only repair)
    "perturb_match": "none",          # v32: none | parent_frozen_deletion: at the start of segment perturb_segment, a
                                      # fixed random weight perturbation scaled (bisection) so the validation error
                                      # equals the budget parent removal's frozen joint-deletion validation error
    "perturb_segment": 1,
    "perturb_estimand": "absolute",   # v34: absolute (the perturbed validation error equals the deleted parent's) |
                                      # increment (the perturbation adds the deletion's validation-error increase)
    "perturb_match_tol": 0.005,       # v34: the achieved validation error must be within max(tol, 1 / n_val) of the
                                      # target, else the job is invalid (an unreachable target too); val_risk: tol
    "perturb_match_metric": "val_err",  # v36: val_err | val_risk (the task risk; no ceiling at chance)
    "save_eval_checkpoints": False,   # v31: save a checkpoint at every eval_at / eval_points update (traces)
    "fork_audit": False,              # v43: record the trainer (model, optimizer by name, sampler, RNG, minibatch
                                      # stream) at every fresh segment start, before its optimizer rule, and hash the
                                      # minibatch stream (compact carry / reset arms that share a prefix are audited)
    "freeze_segments": [],            # v43/v44: per segment, true = train.freeze_inputs and train.freeze_backbone
                                      # apply, false = released; a
                                      # frozen prefix only (once released, never frozen again).  Empty: every segment
                                      # follows the job's train freezes
    "segment_reset": [],              # v25: per segment, true = fresh optimizer state at its start, false = carried;
                                      # [] = the arm's rule.  Mirrors a treated history's phase boundaries (the
                                      # phase-matched compact control C1_phase)
}

TRANSPLANT_DEFAULTS = {
    "upstream": "upstream",           # parent role providing the layers up to the cut
    "downstream": "downstream",       # parent role providing the layers after the cut
    "upstream_stage": "final",
    "downstream_stage": "final",
    "cut_kind": "post_act",
    "cut_where": "middle",
    "align": "none",                  # none | symbol (finite codes) | affine; fitted on training inputs only
    "bn_recalibrate": False,          # recompute BN running statistics downstream of the cut on training inputs
    # ---- v5: the full 2 x 2 (old / new upstream x old / new downstream) with matched adapter families ----
    "design": "single",               # single (v4 rows: upstream, downstream, direct, aligned) | grid
    "align_families": ["identity", "orthogonal", "affine", "mlp"],   # grid: identity | orthogonal | affine | mlp
                                      # (activation matching) | affine_task | mlp_task (task loss through the
                                      # frozen network); the same family and budget for every combination
    "adapter_updates": 200,           # grid: steps of every iteratively fitted adapter
}

DESIGN_DEFAULTS = {
    "family": "",                     # F01..F10 | M_A..M_H | C | S7 (strengthening extension); "" elsewhere
    "variant": "",                    # registry id (F01a ...), control id (C1 ...) or mechanism arm
    "arm": "",                        # treated | C0..C8 | durability | ... : the role of this job in its contrast
    "budget_panel": "",               # updates | examples | compute | wall_time (which budget is held equal)
    "target_regime": "",              # T0 | T1
    "contrast": "",                   # label shared by a treated history and its controls (pairing key)
    "role": "",                       # v31: confirmation | exploratory | "" (legacy: role from the data draw)
}

# which sections each kind takes
KIND_SECTIONS = {
    "baseline": ("data", "model", "train", "seeds", "eval", "criteria"),
    "trajectory": ("data", "model", "train", "growth", "deletion", "seeds", "eval", "criteria"),
    "deletion": ("data", "model", "train", "growth", "deletion", "seeds", "eval", "criteria"),
    "repair": ("data", "model", "train", "growth", "deletion", "repair", "seeds", "eval", "criteria"),
    "dissipation": ("data", "model", "train", "growth", "deletion", "dissipation", "seeds", "eval", "criteria"),
    "control": ("data", "model", "growth", "seeds", "eval", "criteria", "control"),
    "finite": ("finite",),
    "cop": ("data", "model", "train", "peg", "cop", "seeds", "eval", "criteria"),
    "continue": ("data", "model", "train", "seeds", "eval", "criteria", "continue"),
    "transplant": ("data", "model", "train", "seeds", "eval", "criteria", "transplant"),
}

CONTROL_DEFAULTS = {
    "checks": ["insertions", "fold", "stationary", "resume", "deletion_pair"],
    "dtypes": ["float64", "float32"],
    "device": "cpu",      # the backend being certified; jobs only run on a matching exec device
}

SECTION_DEFAULTS = {
    "train": TRAIN_DEFAULTS, "growth": GROWTH_DEFAULTS, "deletion": DELETION_DEFAULTS, "repair": REPAIR_DEFAULTS,
    "dissipation": DISSIPATION_DEFAULTS, "criteria": CRITERIA_DEFAULTS, "eval": EVAL_DEFAULTS,
    "seeds": SEED_DEFAULTS, "peg": PEG_DEFAULTS, "cop": COP_DEFAULTS, "control": CONTROL_DEFAULTS,
    "continue": CONTINUE_DEFAULTS, "transplant": TRANSPLANT_DEFAULTS,
}

META_DEFAULTS = {"kind": None, "wp": [], "wave": 0, "block": "", "controlled": "", "note": "", "parents": FREE,
                 "tags": FREE, "design": DESIGN_DEFAULTS}

TOPOLOGIES = ("none", "layered", "parallel", "recursive", "recursive_branch", "tree_depth2", "hard_submodule",
              "recursive_descendants", "chain_in_branch", "dup_branch", "cancel_pair", "inverse_pair",
              "linear_factor", "concat_expand", "node_factorization", "complementary", "specialized",
              "known_module", "bridge",
              # v3 strengthening extension
              "node_split", "bottleneck", "chunked", "diamond", "twin_helpers")


def resolve(cfg: dict) -> dict:
    """Validate and fill a job config.  Returns a new dict."""
    from .data.registry import resolve_data_cfg
    from .graph.builders import MODEL_DEFAULTS
    if "kind" not in cfg or cfg["kind"] not in KIND_SECTIONS:
        raise ConfigError(f"kind must be one of {sorted(KIND_SECTIONS)}")
    kind = cfg["kind"]
    allowed = set(KIND_SECTIONS[kind]) | set(META_DEFAULTS)
    unknown = set(cfg) - allowed
    if unknown:
        raise ConfigError(f"kind={kind}: sections {sorted(unknown)} are not used by this kind "
                          f"(allowed {sorted(allowed)})")
    out = strict_merge(META_DEFAULTS, {k: v for k, v in cfg.items() if k in META_DEFAULTS}, "")
    for sec in KIND_SECTIONS[kind]:
        if sec == "data":
            out["data"] = resolve_data_cfg(cfg.get("data") or {})
        elif sec == "model":
            out["model"] = strict_merge(MODEL_DEFAULTS, cfg.get("model"), "model")
        elif sec == "finite":
            from .finite import resolve_finite_config
            out["finite"] = resolve_finite_config(dict(cfg.get("finite") or {}))
        else:
            out[sec] = strict_merge(SECTION_DEFAULTS[sec], cfg.get(sec), sec)
    _check_combinations(out)
    return out


def _check_combinations(c: dict) -> None:
    kind = c["kind"]
    if "train" in c:
        t = c["train"]
        check_choice(t, "optimizer", ("adamw", "sgd"), "train")
        check_choice(t, "precision", ("fp32", "fp64", "bf16_autocast"), "train")
        check_choice(t, "target", ("task", "teacher_star"), "train")
        check_choice(t, "decay_mode", ("uniform", "composite"), "train")
        check_choice(t, "bn_stats", ("follow", "frozen", "update"), "train")
        check_choice(t, "freeze_schedule", ("fixed", "alternate", "release"), "train")
        check_choice(t, "sampler", ("uniform", "group_balanced"), "train")
        if t["freeze_schedule"] == "alternate" and int(t["freeze_period"]) <= 0:
            raise ConfigError("train.freeze_schedule=alternate needs freeze_period > 0")
        if t["freeze_schedule"] == "release" and int(t["release_after"]) <= 0:
            raise ConfigError("train.freeze_schedule=release needs release_after > 0")
        if int(t["select_candidates"]) < 0:
            raise ConfigError("train.select_candidates must be >= 0")
        check_choice(t, "quant_range", ("fixed", "ema"), "train")
        if not 0.0 <= float(t["quant_range_momentum"]) < 1.0:
            raise ConfigError("train.quant_range_momentum must be in [0, 1)")
        if int(t["quant_warmup_updates"]) < 0:
            raise ConfigError("train.quant_warmup_updates must be >= 0")
        if not 0.0 <= float(t["quant_ste_margin"]) < 0.5:
            raise ConfigError("train.quant_ste_margin must be in [0, 0.5)")
        sp = str(t["select_partition"])
        if not sp.startswith("val") or sp in ("test", "shift", "rare", "train"):
            raise ConfigError(f"train.select_partition {sp!r} must be a validation partition (val or val_*)")
        if not (isinstance(t["snapshot_at"], list) and all(isinstance(u, int) and u > 0 for u in t["snapshot_at"])):
            raise ConfigError("train.snapshot_at must be a list of positive update counts")
        check_choice(t, "freeze", ("none", "original_frozen", "implants_frozen", "upstream_only", "downstream_only",
                                   "upstream_plus_implants", "downstream_plus_implants"), "train")
        check_choice(t, "opt_state_on_edit", ("preserve", "reset"), "train")
        check_choice(t, "stream", ("fixed", "fresh"), "train")
        check_choice(t, "lr_schedule", ("constant", "cosine"), "train")
        check_choice(t, "loss", ("auto", "ce", "mse"), "train")
        if t["optimizer"] == "adamw" and t["momentum"]:
            raise ConfigError("train.momentum applies to sgd only")
        check_choice(t, "freeze_inputs", ("none", "shortcut"), "train")
        if not isinstance(t.get("audit_batches", False), bool):
            raise ConfigError("train.audit_batches must be a boolean")
        if t.get("audit_batches") and t.get("stream") == "fresh":
            raise ConfigError("train.audit_batches needs a finite training set (stream=fresh has no example ids)")
        check_choice(t, "freeze_backbone", ("none", "downstream"), "train")
        if t["freeze_backbone"] != "none":
            if kind not in ("trajectory", "dissipation", "continue"):
                raise ConfigError("train.freeze_backbone applies to trajectory, dissipation and continue jobs")
            if (c.get("model") or {}).get("family") != "mlp":
                raise ConfigError("train.freeze_backbone needs an mlp backbone")
            if t["freeze_schedule"] != "fixed" or t["freeze"] != "none":
                raise ConfigError("train.freeze_backbone cannot be combined with train.freeze / freeze_schedule")
        if not isinstance(t.get("log_update_norms", False), bool):
            raise ConfigError("train.log_update_norms is a boolean")
        if t["freeze_inputs"] != "none":
            dd = c.get("data") or {}
            if kind not in ("trajectory", "dissipation", "continue"):
                raise ConfigError("train.freeze_inputs applies to trajectory, dissipation and continue jobs")
            img = dd.get("name") == "image_shortcut"        # v65: the shortcut plane is one input channel
            if not img and (dd.get("name") != "shortcut" or int((dd.get("params") or {}).get("input_rotation", 0) or 0)):
                raise ConfigError("train.freeze_inputs=shortcut needs the shortcut data with unrotated inputs (the "
                                  "shortcut feature is then one input column) or the image shortcut data")
            if (c.get("model") or {}).get("family") != ("cnn_cut" if img else "mlp"):
                raise ConfigError("train.freeze_inputs needs an mlp backbone (a cnn_cut backbone on the image "
                                  "shortcut data)")
            if t["freeze_schedule"] != "fixed" or t["freeze"] not in ("none",):
                raise ConfigError("train.freeze_inputs cannot be combined with train.freeze / freeze_schedule")
    if "growth" in c:
        gr = c["growth"]
        check_choice(gr, "topology", TOPOLOGIES, "growth")
        check_choice(gr, "schedule", ("incremental", "all_at_once", "from_scratch"), "growth")
        check_choice(gr, "shape", ("chain", "wide", "alternating", "separated"), "growth")
        check_choice(gr, "merge", ("sum", "concat", "route"), "growth")
        check_choice(gr, "order", ("breadth_first", "depth_first"), "growth")
        check_choice(gr, "policy", ("fixed", "random", "dependence_seeking", "removability_preserving"), "growth")
        check_choice(gr, "driver", ("fixed", "fresh", "changing_target", "output_constrained", "neutral_mutation",
                                    "stationary_self"), "growth")
        check_choice(gr, "aux_objective", ("none", "aligned", "antagonistic"), "growth")
        check_choice(gr, "known_module", ("none", "poly", "pretrained", "random_matched", "mixing_random",
                                          "mixing_aligned"), "growth")
        check_choice(gr, "compute_schedule", ("per_round", "total"), "growth")
        check_choice(gr, "channel_order", ("first", "random", "top_variance"), "growth")
        check_choice(gr, "specialize", ("class_halves", "class_halves_oracle", "aux"), "growth")
        check_choice(gr, "spec_partition", ("auto", "group", "observed_label", "random_matched", "redrawn_random",
                                            "all_examples", "cyclic_blocks", "matched_quota"), "growth")
        check_choice(gr, "spec_mask_route", ("gradient", "forward", "parameter"), "growth")
        if gr["spec_mask_route"] != "gradient" and gr.get("spec_partition") in ("all_examples",):
            raise ConfigError(f"growth.spec_mask_route={gr['spec_mask_route']} with all_examples masks nothing")
        if gr["spec_partition"] == "matched_quota":
            sq = gr.get("spec_quota") or {}
            if not 0.0 < float(sq.get("fraction", 0)) < 1.0 or int(sq.get("b_run", -1)) < 0:
                raise ConfigError("growth.spec_quota needs 0 < fraction < 1 and b_run >= 0")
            if gr["compute_schedule"] != "per_round":
                raise ConfigError("growth.spec_partition=matched_quota needs compute_schedule per_round (one quota "
                                  "window per growth round)")
            if (c.get("train") or {}).get("sampler", "uniform") != "uniform" or \
                    (c.get("train") or {}).get("stream") == "fresh":
                raise ConfigError("growth.spec_partition=matched_quota needs the uniform sampler on a fixed "
                                  "training set")
        if gr["spec_partition"] == "cyclic_blocks":
            if int(gr.get("spec_block_period", 0) or 0) < 2:
                raise ConfigError("growth.spec_partition=cyclic_blocks needs spec_block_period >= 2")
        elif int(gr.get("spec_block_period", 0) or 0) != 0:
            raise ConfigError("growth.spec_block_period is only used by spec_partition=cyclic_blocks")
        f_ = gr.get("spec_random_fraction")
        if f_ is not None and not 0.0 < float(f_) < 1.0:
            raise ConfigError("growth.spec_random_fraction must be in (0, 1) or null (matched to the group-0 share)")
        ra = gr.get("spec_reassign") or {}
        check_choice(ra, "mode", ("none", "abrupt", "abrupt_redraw", "periodic", "periodic_redraw", "ramp"),
                     "growth.spec_reassign")
        if ra["mode"] != "none":
            if gr["spec_partition"] != "random_matched":
                raise ConfigError("growth.spec_reassign changes a fixed random split: needs spec_partition "
                                  "random_matched")
            if int(ra["start"]) < 0 or (ra.get("end") is not None and int(ra["end"]) <= int(ra["start"])):
                raise ConfigError("growth.spec_reassign: need 0 <= start < end")
            if ra["mode"] in ("abrupt", "periodic", "ramp") and not 0.0 < float(ra["fraction"]) <= 1.0:
                raise ConfigError("growth.spec_reassign.fraction must be in (0, 1]")
            if ra["mode"] in ("periodic", "periodic_redraw", "ramp") and int(ra["period"]) < 1:
                raise ConfigError("growth.spec_reassign.period must be >= 1 for periodic / periodic_redraw / ramp")
        check_choice(gr, "tie", ("untied", "tied", "enforced", "learned"), "growth")
        check_choice(gr, "construction", ("residual_zero", "linear_factor", "concat_expand", "inverse_pair",
                                          "cancel_pair"), "growth")
        if gr["topology"] == "none" and gr["schedule"] != "incremental":
            raise ConfigError("topology none has no all_at_once/from_scratch variant (it is the continued baseline)")
        if gr["driver"] == "neutral_mutation" and gr["schedule"] != "incremental":
            raise ConfigError("driver=neutral_mutation is defined for the incremental schedule only")
        if gr["order"] == "depth_first" and gr["topology"] != "tree_depth2":
            raise ConfigError("growth.order=depth_first is defined for topology tree_depth2")
        if gr["topology"] == "known_module" and gr["known_module"] == "none":
            raise ConfigError("topology known_module needs growth.known_module")
        check_choice(gr, "width_match", ("none", "params", "macs"), "growth")
        check_choice(gr, "helper_schedule", ("both", "alternate", "single", "stochastic"), "growth")
        check_choice(gr, "contract_method", ("auto", "abrupt", "gate"), "growth")
        check_choice(gr, "contract_trigger", ("fixed", "damage", "replay"), "growth")
        check_choice(gr, "cycle_cut", ("same", "moving", "nested"), "growth")
        check_choice(gr, "mixer", ("mlp", "attention"), "growth")
        check_choice(gr, "known_access", ("x", "cut"), "growth")
        check_choice(gr, "bridge_inputs", ("all", "causal", "shortcut", "random"), "growth")
        if not 0.0 <= float(gr["nonlinearity"]) <= 1.0:
            raise ConfigError("growth.nonlinearity must be in [0, 1]")
        if not float(gr["factor_balance"]) > 0:
            raise ConfigError("growth.factor_balance must be > 0")
        if gr["inverse_cond"] is not None and not float(gr["inverse_cond"]) >= 1.0:
            raise ConfigError("growth.inverse_cond must be >= 1")
        if gr["width_match"] != "none" and int(gr["width_match_target"]) <= 0:
            raise ConfigError("growth.width_match needs width_match_target > 0")
        if gr["contract_every"] and gr["schedule"] != "incremental":
            raise ConfigError("growth.contract_every (grow / contract cycles) needs the incremental schedule")
        if gr["contract_every"] and int(gr["rounds"]) % int(gr["contract_every"]):
            raise ConfigError("growth.rounds must be a multiple of contract_every (every cycle history ends compact)")
        if gr["cycle_cut"] == "nested" and (gr["topology"] not in ("recursive", "recursive_branch", "tree_depth2",
                                                                  "chain_in_branch") or int(gr["contract_every"]) < 2):
            raise ConfigError("growth.cycle_cut=nested needs a recursive topology and contract_every >= 2")
        if gr["contract_trigger"] == "replay" and "schedule" not in (c.get("parents") or {}):
            raise ConfigError("growth.contract_trigger=replay needs parents.schedule (the run whose realised "
                              "contraction rounds are replayed)")
        if gr["contract_trigger"] in ("damage", "replay") and not gr["contract_every"]:
            raise ConfigError("growth.contract_trigger=damage needs contract_every > 0 (the latest contraction point)")
        if gr["cycle_cut"] != "same" and not gr["contract_every"]:
            raise ConfigError("growth.cycle_cut applies to grow / contract cycles (contract_every > 0)")
        if gr["compute_schedule"] == "total" and gr["total_updates"] <= 0:
            raise ConfigError("compute_schedule=total needs total_updates > 0")
        if "train" in c and gr["driver"] == "fresh" and c["train"]["stream"] != "fresh":
            raise ConfigError("driver=fresh requires train.stream=fresh")
        if "data" in c and "train" in c and c["train"]["stream"] == "fresh":
            from .data.registry import DATASETS
            if c["data"]["name"] not in ("teacher", "linear_rank", "frequency", "compose", "flat", "easy_teacher"):
                raise ConfigError("fresh-sample stream is available for continuous synthetic datasets only")
    if "repair" in c:
        check_choice(c["repair"], "region", ("none", "readout", "incident_adapters", "adjacent", "containing_pearl",
                                             "downstream", "full", "fresh_original", "fresh_smaller"), "repair")
        check_choice(c["repair"], "target", ("task", "expanded", "original"), "repair")
        check_choice(c["repair"], "extend_on", ("target", "task", "both"), "repair")
        check_choice(c["repair"], "opt_state", ("reset", "preserve"), "repair")
        check_choice(c["repair"], "data_access", ("train", "calibration", "fresh", "checkpoint"), "repair")
        if c["repair"]["data_access"] == "calibration" and c["repair"]["target"] == "task":
            raise ConfigError("repair.data_access=calibration retains inputs only: use target expanded or original")
        if c["repair"]["opt_state"] == "preserve" and c["repair"]["region"] in ("fresh_original", "fresh_smaller"):
            raise ConfigError("repair.opt_state=preserve needs surviving tensors (not a fresh model)")
    if "dissipation" in c:
        check_choice(c["dissipation"], "method", ("abrupt", "linear", "cosine", "residual_penalty", "inverse_restore",
                                                  "branch_merge", "group_removal", "peg_replacement", "fold",
                                                  "stochastic_bypass", "keep", "fold_unrouted",
                                                  # v65: keep forks from a redistributed start (cop.graph.redistribute)
                                                  "keep_swap", "keep_shift50", "keep_shift100"), "dissipation")
        check_choice(c["dissipation"], "order", ("joint", "ancestor_first", "descendant_first", "oldest_first",
                                                 "newest_first"), "dissipation")
        check_choice(c["dissipation"], "target", ("task", "expanded"), "dissipation")
        if not 0.0 < float(c["dissipation"]["bypass_keep"]) < 1.0:
            raise ConfigError("dissipation.bypass_keep must be in (0, 1)")
        hy = c["dissipation"].get("hybrid") or {}
        if hy.get("donor_role"):
            if hy["donor_role"] not in (c.get("parents") or {}) or hy["donor_role"] == "trajectory":
                raise ConfigError("dissipation.hybrid.donor_role must name a parent role other than trajectory")
            if not hy.get("slots") or not all(isinstance(x, str) for x in hy["slots"]):
                raise ConfigError("dissipation.hybrid.slots must be a non-empty list of implant slots (or ['all'])")
        dsc = c["dissipation"]
        check_choice(dsc, "removal_masks", ("released", "retained"), "dissipation")
        check_choice(dsc, "gate_schedule", ("anneal", "hold"), "dissipation")
        check_choice(dsc, "optimizer_policy", ("reset_each_phase", "carry_from_parent"), "dissipation")
        if dsc["gate_schedule"] != "anneal" and dsc["method"] not in ("linear", "cosine", "group_removal"):
            raise ConfigError("dissipation.gate_schedule other than anneal needs a gated transition (method linear, "
                              "cosine or group_removal)")
        if dsc["method"] in ("keep_swap", "keep_shift50", "keep_shift100"):
            rb_ = dsc.get("rebuild") or {}
            if dsc["optimizer_policy"] != "reset_each_phase" or int(dsc.get("split_updates", 0) or 0) or \
                    hy.get("donor_role") or dsc.get("keep_frozen_implants") or \
                    rb_.get("backbone", "receiver") != "receiver" or rb_.get("implants", "receiver") != "receiver" or \
                    dsc["targets"] != "all":
                raise ConfigError(f"dissipation.method={dsc['method']}: the redistribution fork is the single-phase "
                                  "keep fork of the parent's own model with a fresh optimizer (no split_updates, "
                                  "rebuild, hybrid or frozen additions; targets all)")
        if dsc["removal_masks"] != "released" and dsc["method"] not in ("linear", "cosine", "group_removal", "keep",
                                                                        "keep_swap", "keep_shift50", "keep_shift100"):
            raise ConfigError("dissipation.removal_masks=retained needs a gated transition (linear, cosine, "
                              "group_removal) or the keep fork (v39)")
        if dsc["optimizer_policy"] == "carry_from_parent":
            # v39: the keep fork continues the parent's optimizer state (one phase, the parent's own model)
            rb_ = dsc.get("rebuild") or {}
            if dsc["method"] != "keep" or int(dsc.get("split_updates", 0) or 0) or hy.get("donor_role") or \
                    rb_.get("backbone", "receiver") != "receiver" or rb_.get("implants", "receiver") != "receiver":
                raise ConfigError("dissipation.optimizer_policy=carry_from_parent is for the single-phase keep fork "
                                  "of the parent's own model (no split_updates, rebuild or hybrid)")
            if c["train"].get("lr_schedule") != "constant" or int(c["train"].get("warmup", 0) or 0):
                # v41: a schedule's clock (restart or continue) would need its own declaration
                raise ConfigError("dissipation.optimizer_policy=carry_from_parent needs a constant learning rate "
                                  "without warmup")
        if dsc["removal_masks"] == "retained" and hy.get("donor_role"):
            raise ConfigError("dissipation.removal_masks=retained is unsupported for hybrids: one global spec_a / "
                              "spec_b mask pair cannot express branches with different training splits")
        rbc = dsc.get("rebuild") or {}
        check_choice(rbc, "backbone", ("receiver", "f0"), "dissipation.rebuild")
        check_choice(rbc, "implants", ("receiver", "fresh"), "dissipation.rebuild")
        check_choice(dsc, "repair_scope", ("full", "readout", "top2", "first"), "dissipation")
        check_choice(dsc, "restore_before_repair", ("none", "all_but_first"), "dissipation")
        if dsc["restore_before_repair"] != "none" and dsc["method"] not in ("abrupt", "linear", "cosine",
                                                                            "group_removal"):
            raise ConfigError("dissipation.restore_before_repair needs a removal method with a repair phase")
        if int(dsc.get("split_updates", 0) or 0) and dsc["method"] not in ("keep", "abrupt"):
            raise ConfigError("dissipation.split_updates is for methods keep and abrupt")
        if dsc.get("keep_frozen_implants") and dsc["method"] not in ("keep", "linear"):
            raise ConfigError("dissipation.keep_frozen_implants is for method keep (the kept phase) or linear (the "
                              "transition / hold phase)")
        if int(dsc.get("repair_subset", 0) or 0) < 0:
            raise ConfigError("dissipation.repair_subset must be >= 0")
        if int(dsc.get("repair_subset", 0) or 0) > 0 and ((c.get("train") or {}).get("stream") == "fresh" or
                                                          (c.get("train") or {}).get("sampler", "uniform") != "uniform"):
            raise ConfigError("dissipation.repair_subset needs a fixed training set and the uniform sampler")
        if dsc["repair_scope"] != "full" and dsc["method"] not in ("abrupt", "linear", "cosine", "group_removal"):
            raise ConfigError("dissipation.repair_scope other than full needs method abrupt, linear, cosine or "
                              "group_removal")
        if any(int(u) < 1 for u in dsc.get("early_eval") or []):
            raise ConfigError("dissipation.early_eval: updates must be >= 1")
        sw = dsc.get("swap_scan") or {}
        if sw.get("donor_role") and (sw["donor_role"] not in (c.get("parents") or {}) or
                                     sw["donor_role"] == "trajectory"):
            raise ConfigError("dissipation.swap_scan.donor_role must name a parent role other than trajectory")
    if "continue" in c:
        cc = c["continue"]
        check_choice(cc, "budget", ("fixed", "parent_compute", "parent_updates"), "continue")
        check_choice(cc, "arm", ("plain", "lr_restart", "opt_reset", "perturb", "distill", "self_distill",
                                 "prune_regrow", "example_tied_dropout"), "continue")
        if cc["arm"] == "example_tied_dropout":
            if not (0.0 < float(cc["etd_p_gen"]) < 1.0 and 0.0 < float(cc["etd_p_mem"]) <= 1.0):
                raise ConfigError("continue.etd_p_gen must be in (0, 1) and etd_p_mem in (0, 1]")
            if len(cc.get("segments") or []) != 2:
                raise ConfigError("continue.arm=example_tied_dropout needs segments [dropout phase, repair]")
        check_choice(cc, "trainable_scope", ("full", "first"), "continue")
        check_choice(cc, "perturb_match", ("none", "parent_frozen_deletion"), "continue")
        check_choice(cc, "perturb_estimand", ("absolute", "increment"), "continue")
        check_choice(cc, "perturb_match_metric", ("val_err", "val_risk"), "continue")
        if not float(cc["perturb_match_tol"]) > 0:
            raise ConfigError("continue.perturb_match_tol must be positive")
        if cc["perturb_match"] != "none" and (cc["arm"] != "plain" or len(cc.get("segments") or []) <= int(cc["perturb_segment"])
                                              or int(cc["perturb_segment"]) < 1):
            raise ConfigError("continue.perturb_match needs arm plain and a later segment to perturb at")
        if cc["trainable_scope"] != "full" and cc["arm"] not in ("plain",):
            raise ConfigError("continue.trainable_scope other than full is for arm plain")
        fsg = cc.get("freeze_segments") or []
        if fsg:
            if len(fsg) != len(cc.get("segments") or []) or not all(isinstance(x, bool) for x in fsg):
                raise ConfigError("continue.freeze_segments needs one boolean per segment")
            if any(fsg[i + 1] and not fsg[i] for i in range(len(fsg) - 1)):
                raise ConfigError("continue.freeze_segments must be a frozen prefix (once released, never frozen "
                                  "again: the held values are the job's start values)")
            if c["train"].get("freeze_inputs", "none") == "none" and c["train"].get("freeze_backbone", "none") == "none":
                raise ConfigError("continue.freeze_segments needs train.freeze_inputs or train.freeze_backbone (what it "
                                  "holds)")
            if cc["arm"] != "plain":
                raise ConfigError("continue.freeze_segments is for arm plain")
        sr = cc.get("segment_reset") or []
        if sr:
            if len(sr) != len(cc.get("segments") or []) or not all(isinstance(x, bool) for x in sr):
                raise ConfigError("continue.segment_reset needs one boolean per segment")
            if cc["arm"] not in ("plain",):
                raise ConfigError("continue.segment_reset is for arm plain (the other arms have their own reset rule)")
        if cc["start"] not in (c.get("parents") or {}):
            raise ConfigError(f"continue.start={cc['start']!r} must name a parent role")
        if cc["budget"] != "fixed" and cc["budget_parent"] not in (c.get("parents") or {}):
            raise ConfigError(f"continue.budget={cc['budget']} needs parents.{cc['budget_parent']}")
        if cc["budget"] == "fixed" and int(cc["updates"]) <= 0 and not cc["segments"]:
            raise ConfigError("continue.budget=fixed needs updates > 0 (or segments)")
        if cc["segments"] and cc["budget"] == "fixed" and int(cc["updates"]) and sum(cc["segments"]) != int(cc["updates"]):
            raise ConfigError("continue.segments must sum to continue.updates")
        if cc.get("budget_add_f0") and ("baseline" not in (c.get("parents") or {}) or cc["budget"] == "fixed"):
            raise ConfigError("continue.budget_add_f0 needs parents.baseline and a derived budget")
        if cc["arm"] in ("distill", "self_distill") and cc["teacher"] not in (c.get("parents") or {}):
            raise ConfigError(f"continue.arm={cc['arm']} needs a teacher parent role (continue.teacher)")
        if not 0.0 <= float(cc["distill_alpha"]) <= 1.0:
            raise ConfigError("continue.distill_alpha must be in [0, 1]")
        if cc["arm"] == "prune_regrow" and not (0 < float(cc["prune_frac"]) < 1 and
                                                 0 < int(cc["prune_duration"]) < int(cc["prune_period"])):
            raise ConfigError("prune_regrow needs 0 < prune_frac < 1 and 0 < prune_duration < prune_period")
    if "transplant" in c:
        tp = c["transplant"]
        check_choice(tp, "align", ("none", "symbol", "affine"), "transplant")
        check_choice(tp, "design", ("single", "grid"), "transplant")
        bad = [f for f in tp["align_families"] if f not in ("identity", "orthogonal", "affine", "mlp", "affine_task",
                                                            "mlp_task")]
        if bad or not tp["align_families"]:
            raise ConfigError(f"transplant.align_families: unknown or empty {bad}")
        if int(tp["adapter_updates"]) < 1:
            raise ConfigError("transplant.adapter_updates must be >= 1")
        for role in (tp["upstream"], tp["downstream"]):
            if role not in (c.get("parents") or {}):
                raise ConfigError(f"transplant needs parents.{role}")
    d = c.get("design") or {}
    if d.get("budget_panel"):
        check_choice(d, "budget_panel", ("updates", "examples", "compute", "wall_time"), "design")
    if d.get("target_regime"):
        check_choice(d, "target_regime", ("T0", "T1"), "design")
        if "train" in c and (d["target_regime"] == "T0") != (c["train"]["target"] == "teacher_star"):
            raise ConfigError("design.target_regime T0 <=> train.target = teacher_star")
    if "peg" in c:
        check_choice(c["peg"], "mode", ("none", "uniform", "vq", "multi"), "peg")
        check_choice(c["peg"], "temp_target", ("all", "peg", "pegs", "adapter"), "peg")
        check_choice(c["peg"], "temp_on", ("all", "middle"), "peg")
        r_ = int(c["peg"]["redundancy"])
        if r_ < 1 or c["peg"]["dim"] % r_:
            raise ConfigError("peg.redundancy must divide peg.dim")
        if r_ > 1 and (c["peg"]["mode"] not in ("none", "uniform") or c["peg"]["temp_channel"]):
            raise ConfigError("peg.redundancy applies to coordinate pegs (mode none / uniform) without a temp channel")
        if r_ > 1 and "cop" in c and c["cop"]["task_kind"] != "chain":
            raise ConfigError("peg.redundancy is implemented for cop.task_kind=chain")
        if float(c["peg"]["route_dropout"]) and r_ < 2 and int(c.get("cop", {}).get("route_blocks", 0)) < 2:
            raise ConfigError("peg.route_dropout needs peg.redundancy >= 2 or cop.route_blocks >= 2")
        if not 0.0 <= float(c["peg"]["route_dropout"]) <= 1.0:
            raise ConfigError("peg.route_dropout must be in [0, 1]")
        if "cop" in c:
            check_choice(c["cop"], "route_remove", ("all_pegs", "middle_peg"), "cop")
        if "cop" in c and int(c["cop"]["route_repair_updates"]) and r_ < 2 and int(c["cop"]["route_blocks"]) < 2:
            raise ConfigError("cop.route_repair_updates needs peg.redundancy >= 2 or cop.route_blocks >= 2")
        if c["peg"]["temp_target"] == "peg" and c["peg"]["temp_on"] == "all":
            raise ConfigError("peg.temp_target=peg equals temp_target=pegs when every peg has a bridge; "
                              "use temp_on=middle")
        if (c["peg"]["temp_open_updates"] or c["peg"]["temp_target"] != "all") and not c["peg"]["temp_channel"]:
            raise ConfigError("peg.temp_open_updates / temp_target need a temporary channel (peg.temp_channel > 0)")
        if c["peg"]["temp_anneal_updates"] is not None and (not isinstance(c["peg"]["temp_anneal_updates"], int) or
                                                            c["peg"]["temp_anneal_updates"] < 1):
            raise ConfigError("peg.temp_anneal_updates must be null or a positive int")
        if c["peg"]["temp_anneal_updates"] is not None and not c["peg"]["temp_channel"]:
            raise ConfigError("peg.temp_anneal_updates needs a temporary channel (peg.temp_channel > 0)")
        if c["peg"]["mode"] == "multi" and c["peg"]["dim"] % c["peg"]["n_messages"]:
            raise ConfigError("peg.dim must be divisible by n_messages")
    if "cop" in c:
        check_choice(c["cop"], "task_kind", ("chain", "alternatives", "split", "cycles", "baseline", "locality",
                                             "recode"), "cop")
        if c["cop"]["task_kind"] == "recode":
            if "chain" not in (c.get("parents") or {}):
                raise ConfigError("cop.task_kind=recode reads a trained run with finite pegs: give parents.chain")
            rc = c["cop"]
            for k_ in ("recode_relabels", "recode_sides", "recode_classes", "recode_regimes"):
                if not isinstance(rc[k_], list) or not rc[k_] or len(set(rc[k_])) != len(rc[k_]):
                    raise ConfigError(f"cop.{k_} must be a nonempty list without repeats")
            bad = [x for x in rc["recode_relabels"] if x not in ("identity", "bitperm", "bitperm_symmetric",
                                                                 "xor_chain", "gf2_random", "codeword_perm")]
            bad += [x for x in rc["recode_sides"] if x not in ("out", "in", "both")]
            bad += [x for x in rc["recode_regimes"] if x not in ("observed", "full_alphabet")]
            bad += [x for x in rc["recode_classes"] if not (x == "linear" or (x.startswith("mlp") and
                                                                              x[3:].isdigit() and int(x[3:]) > 0))]
            if bad:
                raise ConfigError(f"cop.recode_*: unknown entries {bad}")
            if int(rc["recode_updates"]) < 1 or int(rc["recode_eval_every"]) < 1:
                raise ConfigError("cop.recode_updates and recode_eval_every must be >= 1")
            if int(rc["recode_relabel_seeds"]) < 1 or int(rc["recode_fit_seeds"]) < 1:
                raise ConfigError("cop.recode_relabel_seeds and recode_fit_seeds must be >= 1")
            import math as _m
            for k_ in ("recode_lr", "recode_pred_atol", "recode_symmetry_rtol"):
                if not (_m.isfinite(float(rc[k_])) and float(rc[k_]) > 0):
                    raise ConfigError(f"cop.{k_} must be finite and positive")
            if not 1 <= int(rc["recode_max_bits"]) <= 14:
                raise ConfigError("cop.recode_max_bits must be in [1, 14] (alphabet enumeration limit 2^14)")
            if "bitperm_symmetric" in rc["recode_relabels"] and "identity" not in rc["recode_relabels"]:
                raise ConfigError("cop.recode_relabels: bitperm_symmetric is compared with identity; include it")
        check_choice(c["cop"], "locality_interface", ("none", "continuous", "continuous_stabilized", "finite_learned",
                                                      "finite_stabilized"), "cop")
        if c["cop"]["task_kind"] == "locality":
            li = c["cop"]["locality_interface"]
            if li.startswith("continuous") and c["peg"]["mode"] != "none":
                raise ConfigError("cop.locality_interface continuous* needs peg.mode none")
            if li.startswith("finite") and c["peg"]["mode"] == "none":
                raise ConfigError("cop.locality_interface finite* needs a finite peg.mode")
            if int(c["cop"]["n_pearls"]) < 3:
                raise ConfigError("the locality experiment needs n_pearls >= 3 (a pearl with two neighbours)")
            if c["peg"]["temp_channel"]:
                raise ConfigError("the locality experiment uses pegs without a temporary channel")
            lc = c["cop"]["locality_checkpoints"]
            if not (isinstance(lc, list) and lc and all(isinstance(f, (int, float)) and 0 < f <= 1 for f in lc)):
                raise ConfigError("cop.locality_checkpoints must be fractions in (0, 1]")
            if int(c["cop"]["locality_repair_updates"]) < 1:
                raise ConfigError("cop.locality_repair_updates must be >= 1")
        check_choice(c["cop"], "placement", ("regular", "random", "known", "adaptive"), "cop")
        check_choice(c["cop"], "cycle_order", ("input_to_output", "output_to_input", "center_out", "leaf_inward"),
                     "cop")
        check_choice(c["cop"], "cycle_pegs", ("fixed", "relearned", "none"), "cop")
        check_choice(c["cop"], "cycle_peg_maps", ("auto", "frozen", "learned"), "cop")
        check_choice(c["cop"], "cycle_peg_width", ("auto", "constant", "narrowed"), "cop")
        check_choice(c["cop"], "cycle_peg_recalibrate", ("auto", "yes", "no"), "cop")
        if c["cop"]["cycle_pegs"] == "none" and any(c["cop"][k] != "auto" for k in
                                                    ("cycle_peg_maps", "cycle_peg_width", "cycle_peg_recalibrate")):
            raise ConfigError("cop.cycle_peg_* switches need pegs (cycle_pegs fixed or relearned)")
        check_choice(c["cop"], "baseline", ("direct_small", "distill", "direct_small_all_pearls", "replace_no_expand",
                                            "progressive_no_peg", "peg_no_expand", "expand_no_peg",
                                            "expand_peg_replace", "shared_fold"), "cop")
        check_choice(c["cop"], "interface_enforce", ("enforced", "relaxed"), "cop")
        if c["cop"]["task_kind"] == "baseline" and c["cop"]["baseline"] in ("direct_small", "distill") and \
                "cycles" not in (c.get("parents") or {}):
            raise ConfigError("cop baseline direct_small / distill copies the exported endpoint architecture of a "
                              "cycles run: give parents.cycles (or use direct_small_all_pearls)")
        if "train" in c and c["train"]["precision"] != "fp32":
            raise ConfigError("kind=cop runs in fp32 only (local fitting loops and code caches are fp32); "
                              f"train.precision={c['train']['precision']!r} is not supported")
        check_choice(c["cop"], "alt_training", ("independent", "joint", "shared_interface"), "cop")
        check_choice(c["cop"], "code_kind", ("fixed_teacher", "learned", "aligned", "task_only"), "cop")
        check_choice(c["cop"], "local_inputs", ("teacher", "on_policy"), "cop")
        valid_alt = {("independent", "fixed_teacher"), ("independent", "aligned"), ("joint", "learned"),
                     ("joint", "task_only"), ("shared_interface", "fixed_teacher")}
        if c["cop"]["task_kind"] == "alternatives" and (c["cop"]["alt_training"], c["cop"]["code_kind"]) not in valid_alt:
            raise ConfigError(f"cop alt_training/code_kind combination {(c['cop']['alt_training'], c['cop']['code_kind'])} "
                              f"is not defined; valid: {sorted(valid_alt)}")
        if c["cop"]["split_into"] not in (2, 4, 8):
            raise ConfigError("cop.split_into must be 2, 4 or 8")


def logical_view(cfg: dict) -> dict:
    """Scientific identity: everything except purely descriptive meta fields."""
    c = copy.deepcopy(cfg)
    for k in ("note", "block", "wave", "wp", "controlled"):   # 'tags' (e.g. parent_stage) are scientific
        c.pop(k, None)
    return c


def run_id(cfg: dict) -> str:
    return cfg["kind"][:4] + "-" + stable_hash({"v": CODE_VERSION, "cfg": logical_view(cfg)}, 20)


# -----------------------------------------------------------------------------
# Analysis cells: condition identity vs replication identity
# -----------------------------------------------------------------------------
# A CONDITION is everything that defines the experiment except replication
# draws and lineage.  Two runs belong to the same analysis cell iff their
# condition ids are equal; within a cell the replication key must be unique.
REPLICATION_FIELDS = (("data", "data_seed"), ("data", "teacher_seed"), ("seeds", "*"))
LINEAGE_FIELDS = ("parents",)
# pure I/O settings: they never change a result (bitwise resume makes checkpoint frequency irrelevant)
ADMIN_FIELDS = (("train", "checkpoint_every"), ("eval", "save_predictions"))


def replication_key(cfg: dict) -> dict:
    out = {}
    for sec, k in REPLICATION_FIELDS:
        s = cfg.get(sec) or {}
        if k == "*":
            for kk in sorted(s):
                out[f"{sec}.{kk}"] = s[kk]
        elif k in s:
            out[f"{sec}.{k}"] = s[k]
    return out


def condition_view(cfg: dict) -> dict:
    c = logical_view(cfg)
    for sec, k in REPLICATION_FIELDS:
        if sec in c:
            if k == "*":
                c.pop(sec)
            else:
                c[sec] = {kk: v for kk, v in c[sec].items() if kk != k}
    for k in LINEAGE_FIELDS:
        c.pop(k, None)
    for sec, k in ADMIN_FIELDS:
        if isinstance(c.get(sec), dict):
            c[sec].pop(k, None)
    return c


def condition_id(cfg: dict) -> str:
    return "cond-" + stable_hash(condition_view(cfg), 16)


def seed_of(cfg: dict, stream: str) -> int:
    s = cfg["seeds"]
    if stream in ("init", "minibatch", "augmentation"):
        return s[stream] if s.get(stream) is not None else s["optimizer"]
    if stream == "partition":
        return s["partition"] if s.get("partition") is not None else s["insertion"]
    return s[stream]
