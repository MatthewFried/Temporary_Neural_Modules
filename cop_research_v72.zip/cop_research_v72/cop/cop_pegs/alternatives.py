"""P3: alternatives behind the same interface, and held-out assemblies.

Reference: a trained Chain of Pearls (parent 'chain' job or trained inline),
evaluated at alpha=0.  Pearl i is the computation from code c_{i-1} (or the
input) to code c_i (or the output); teacher codes are the reference quantiser
outputs.  At each ALTERNATIVE POSITION (middle pearls) several
implementations are built: the reference pearl itself and the kinds in
cop.alt_kinds (mlp_large, mlp_small, lowrank, linear, sparse, table,
attn_block for sequences, conv_* for images).

Interface contract (cop.interface_enforce = 'enforced', the default): a peg is
its destination quantiser (mode, bits / codebook, calibrated range buffers,
shape and positions).  Every replacement output and every adapter output is
passed through the destination quantiser (straight-through gradient in
training), so finite pegs keep their finite alphabet in training and at
evaluation.  Membership is asserted on every evaluated assembly.  'relaxed'
(continuous replacement outputs) is a separately named condition whose
communication is counted at float_bits per coordinate.

Table alternatives are indexed by the canonical integer symbols of the
INCOMING quantiser (ranges / codebooks copied into the table's buffers), one
row per message, so no two distinct messages share a row.

An assembly picks one implementation per position.  A seeded fraction of
assemblies (cop.heldout_assemblies) is reserved and NEVER used in training;
inputs are also held out (test partition).  Training modes:
  independent + fixed_teacher  local regression of each module onto teacher
                               codes; inputs are teacher codes ('teacher') or the
                               outputs of trained upstream alternatives ('on_policy')
  joint / shared_interface     sampled TRAINING assemblies per minibatch; task loss
                               plus interface_weight * code matching (shared_interface)
                               or task loss with a consensus term on learned codes (joint)
  aligned                      each module trained inside one home assembly with task
                               loss only; at evaluation, least-squares affine adapters
                               (fitted on training inputs, counted as parameters)
                               map a module's output codes to its neighbour's input codes
All local loops use the `train` section's optimizer policy (LocalOpt) and are
resumable at step granularity.  Saved for review: every trained module
(architecture + state), interfaces, adapters, the assembly lists, the full
training-assembly usage counts, and the test predictions of every assembly
(alternatives_modules.pt / alternatives_predictions.pt); `reload_alternatives`
rebuilds everything in a fresh process and reproduces the predictions.
"""
from __future__ import annotations

import copy
import itertools
import math
from collections import Counter
from pathlib import Path
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from ..config import seed_of
from ..graph.graph import GraphNet
from ..graph.ops import MODULE_TYPES, Quantizer, init_module
from ..train import metrics as M
from ..train.trainer import task_loss, LocalOpt, local_policy
from ..utils import torch_gen, tensor_hash, atomic_torch_save
from ..experiments import common as C
from ..experiments.context import Unsupported, ScientificInvalid, JobState, local_loop
from .modules import make_alt, SubgraphPearl, node_values, SparseMLP
from .pegs import pegs as list_pegs, bypass_report

MEMBERSHIP_TOL = 1e-3     # in quantisation steps (uniform) / relative to the codebook scale (vq, multi)


def reference_chain(ctx, bundle) -> GraphNet:
    """Trained chain at its endpoint with bypass / temporary-channel edges
    physically removed (export without linear folding, so peg nodes persist).
    The exported reference is also saved in this run (ckpt/reference_exported)
    so trained alternatives can be reloaded without the parent."""
    from ..graph.export import export_compact
    if ctx.has_ckpt("reference_exported"):
        ck = ctx.load_ckpt("reference_exported")
        for k, v in (ck["extra"].get("work") or {}).items():     # work of an inline chain training (resume)
            ctx.work[k] = dict(v)
        return GraphNet.from_checkpoint(ck["model"], ctx.device)
    if "chain" in ctx.cfg.get("parents", {}):
        ck = ctx.parent_ckpt("chain", "final")
        g = GraphNet.from_checkpoint(ck["model"], ctx.device)
        source = {"parent_chain": ctx.cfg["parents"]["chain"], "param_hash": ck["lineage"]["param_hash"]}
    else:
        from .chain import load_f0, placement, build_chain, train_chain
        f0, _ = load_f0(ctx, bundle)
        g = f0.clone(share_params=False)
        pl = placement(ctx, g, bundle, ctx.cfg["cop"]["n_pearls"] - 1)
        g.meta["peg_indices"] = pl["indices"]
        ids = build_chain(ctx, g, bundle, pl["indices"])
        train_chain(ctx, g, bundle, ids, ctx.cfg["cop"]["global_updates"], ckpt_stage="reference_chain_train")
        ctx.save_ckpt("reference_chain", g, None, {"pegs": ids})
        source = {"inline": True}
    ref = export_compact(g, fold_linear=False)[0]
    ctx.save_ckpt("reference_exported", ref, None, {"source": source, "work": {k: dict(v) for k, v in ctx.work.items()}})
    return GraphNet.from_checkpoint(ctx.load_ckpt("reference_exported")["model"], ctx.device)


def require_code_only_pearls(ref: GraphNet, codes: list[str]) -> None:
    """Alternatives and sub-pearls read only the incoming code.  A middle pearl
    that also reads a late network input (e.g. a delayed query) would make
    every alternative structurally weaker than the reference pearl, so such
    references are refused instead of compared."""
    from .modules import external_inputs
    for i in range(1, len(codes)):
        seg = SubgraphPearl(ref, codes[i - 1], codes[i]).seg
        ext = external_inputs(ref, seg, codes[i - 1])[1:]
        if ext:
            raise Unsupported(f"middle pearl {i} reads late inputs {ext}; code-only alternatives would be "
                              "structurally handicapped")


def code_nodes(g: GraphNet) -> list[str]:
    """Peg code nodes (quantiser outputs) in data-flow order."""
    return [g.implants[p].meta["peg"]["quant"] for p in list_pegs(g)]


def quantizer_of(g: GraphNet, qnode: str) -> Quantizer:
    return g.mods[g.nodes[qnode].pkey]


def peg_levels(g: GraphNet, qnode: str) -> Optional[int]:
    q = quantizer_of(g, qnode)
    return 2 ** q.bits if q.mode == "uniform" else None


class _StraightThrough(torch.autograd.Function):
    """Forward: exactly `zq` (no floating-point reconstruction error).
    Backward: the incoming gradient passed to `z` unchanged."""

    @staticmethod
    def forward(ctx, z, zq):
        return zq.clone()

    @staticmethod
    def backward(ctx, grad):
        return grad, None


class Interface(nn.Module):
    """The destination peg contract: a frozen copy of the code node's
    quantiser.  enforce=False (or a continuous peg) passes values unchanged."""

    def __init__(self, q: Quantizer, enforce: bool = True, layout: str = "vec"):
        super().__init__()
        self.q = copy.deepcopy(q).eval()
        for p in self.q.parameters():
            p.requires_grad_(False)
        self.enforce = bool(enforce)
        self.img = layout == "img"

    @property
    def finite(self) -> bool:
        return self.q.mode != "none"

    def train(self, mode: bool = True):
        super().train(mode)
        self.q.eval()          # never collect commitment losses / change buffers
        return self

    def forward(self, z):
        """Value: the destination quantiser's code.  Gradient: identity
        (unclipped straight-through), so a fitted module whose output lies
        outside the clipping range is still pulled towards the right code."""
        if not self.enforce or not self.finite:
            return z
        with torch.no_grad():
            zq = self.q(z.movedim(1, -1)).movedim(-1, 1) if (self.img and z.dim() == 4) else self.q(z)
        return _StraightThrough.apply(z, zq)

    def distance(self, z) -> float:
        return self.q.offalphabet_distance(z.movedim(1, -1) if (self.img and z.dim() == 4) else z)


class Assembly(nn.Module):
    """Runs the reference graph but replaces the code->code map at each
    alternative position with the chosen module (+ optional adapters).
    `interfaces[i]` is the contract of code i; replacement outputs pass the
    destination interface, adapter outputs the interface of the code they
    emulate.  Reference pearls already end in their own quantiser."""

    def __init__(self, ref: GraphNet, codes: list[str], positions: list[int], choice: dict[int, nn.Module],
                 adapters: Optional[dict[int, nn.Module]] = None, interfaces: Optional[dict[int, Interface]] = None,
                 enforce: bool = True):
        super().__init__()
        self.ref, self.codes, self.positions = ref, codes, positions
        self.choice = nn.ModuleDict({str(i): m for i, m in choice.items()})
        self.adapters = nn.ModuleDict({str(i): m for i, m in (adapters or {}).items()})
        if interfaces is None:
            # default contract: every code keeps its reference quantiser (finite alphabets enforced);
            # a relaxed (continuous) condition must be asked for explicitly with enforce=False
            dev = next((p.device for p in ref.parameters()), torch.device("cpu"))
            interfaces = {i: Interface(quantizer_of(ref, cn), enforce, ref.nodes[cn].attrs.get("layout", ref.layout)
                                       ).to(dev) for i, cn in enumerate(codes)}
        self.ifaces = nn.ModuleDict({str(i): m for i, m in interfaces.items()})
        self.pearls = {i: SubgraphPearl(ref, codes[i - 1], codes[i]) for i in range(1, len(codes))}
        self.tail = SubgraphPearl(ref, codes[-1], ref.output)

    def _iface(self, i, z):
        return self.ifaces[str(i)](z) if str(i) in self.ifaces else z

    def forward(self, X, return_codes=False):
        if isinstance(X, torch.Tensor):
            X = {"x": X}
        _, v = self.ref(X, return_nodes=[self.codes[0]])
        c = v[self.codes[0]]
        out_codes = [c]
        for i in range(1, len(self.codes)):
            if str(i) in self.adapters:
                c = self._iface(i - 1, self.adapters[str(i)](c))
            m = self.choice[str(i)] if (i in self.positions and str(i) in self.choice) else None
            if m is None or isinstance(m, SubgraphPearl):
                c = (m or self.pearls[i])(c, X)
            else:
                c = self._iface(i, m(c))
            out_codes.append(c)
        y = self.tail(c, X)
        return (y, out_codes) if return_codes else y


def _module_record(m: nn.Module, attrs: dict) -> dict:
    return {"attrs": attrs, "state": {k: v.detach().cpu().clone() for k, v in m.state_dict().items()}}


def _build_from_record(rec: dict, device) -> nn.Module:
    a = rec["attrs"]
    if a["module_type"] not in MODULE_TYPES:
        from . import modules as _reg  # noqa: F401
    m = MODULE_TYPES[a["module_type"]](**a["module_args"])
    m.load_state_dict(rec["state"])
    return m.to(device)


def assembly_bits(ref: GraphNet, codes, positions, a, enforce: bool, T: int, float_bits: int) -> int:
    """Bits per example through the codes of one assembly, from the actual
    executable boundaries: a reference-produced code or an enforced finite
    interface costs its quantiser's message bits; a relaxed replacement output
    is continuous (k x float_bits per position)."""
    from ..graph.accounting import peg_messages
    msgs = {m["node"]: m for m in peg_messages(ref, T, float_bits)}
    tot = 0
    for i, cn in enumerate(codes):
        m = msgs[cn]
        replaced = i in positions and a[positions.index(i)] != "reference"
        q = quantizer_of(ref, cn)
        if replaced and (not enforce) and q.mode != "none":
            tot += q.k * float_bits * m["positions"]
        else:
            tot += m["bits_per_example"]
    return tot


def run_alternatives(ctx) -> dict:
    cfg = ctx.cfg
    cc = cfg["cop"]
    bundle = C.setup_data(ctx)
    ref = reference_chain(ctx, bundle).eval()
    for p in ref.parameters():
        p.requires_grad_(False)
    codes = code_nodes(ref)
    if len(codes) < 2:
        raise Unsupported("alternatives need at least two pegs (one middle pearl)")
    byp = bypass_report(ref)
    if any(v.get("has_bypass") for v in byp.values()):
        raise ScientificInvalid("reference chain has a path around a peg; interface experiments need bottlenecks",
                                {"bypass": byp})
    enforce = cc["interface_enforce"] == "enforced"
    ifaces = {i: Interface(quantizer_of(ref, cn), enforce, ref.nodes[cn].attrs.get("layout", ref.layout)).to(ctx.device)
              for i, cn in enumerate(codes)}
    require_code_only_pearls(ref, codes)
    positions = list(range(1, len(codes)))          # middle pearls: code_{i-1} -> code_i
    tr_X, te_X = bundle.train.X, bundle.test.X
    T_tr = node_values(ref, tr_X, codes)
    T_te = node_values(ref, te_X, codes)
    ctx.count_work("teacher_code_forward", forward_examples=len(bundle.train) + len(bundle.test))
    lay = ref.layout
    dimc = lambda n: ref.node_dim(n)
    width = cc["pearl_width"]
    alts: dict[int, dict[str, nn.Module]] = {}
    attrs_of: dict[str, dict] = {}
    unavailable: list[dict] = []
    for i in positions:
        alts[i] = {"reference": SubgraphPearl(ref, codes[i - 1], codes[i])}
        pool = 1
        if lay == "img":
            hw_in = ref.nodes[codes[i - 1]].attrs.get("hw", [1, 1])[0]
            hw_out = ref.nodes[codes[i]].attrs.get("hw", [1, 1])[0]
            pool = max(1, hw_in // max(1, hw_out))
        for kind in cc["alt_kinds"]:
            try:
                m, attrs = make_alt(kind, lay, dimc(codes[i - 1]), dimc(codes[i]), width, pool,
                                    in_quant=quantizer_of(ref, codes[i - 1]))
            except Exception as ex:
                ctx.log({"event": "alternative_unavailable", "position": i, "kind": kind, "reason": str(ex)})
                unavailable.append({"position": i, "kind": kind, "reason": str(ex)})
                continue
            if kind != "table":         # tables start at zero; their symbol buffers come from the incoming peg
                init_module(m, torch_gen(seed_of(cfg, "assembly"), "assembly", f"init/{i}/{kind}"), "default")
            alts[i][kind] = m.to(ctx.device)
            attrs_of[f"{i}:{kind}"] = attrs
    names = {i: sorted(alts[i]) for i in positions}
    if len(positions) < 2:
        ctx.log({"event": "note", "text": "only one alternative position: no unseen COMBINATIONS exist; "
                                          "use cop.n_pearls >= 4 for held-out assemblies"})
    if cc["code_kind"] == "aligned" and lay == "img":
        raise Unsupported("aligned adapters are implemented for vector/sequence codes")
    all_asm = list(itertools.product(*[names[i] for i in positions]))
    rng = torch_gen(seed_of(cfg, "assembly"), "assembly", "holdout")
    perm = torch.randperm(len(all_asm), generator=rng).tolist()
    n_hold = int(round(cc["heldout_assemblies"] * len(all_asm)))
    # never hold out an assembly whose removal would leave some module untrained in joint modes
    held, train_asm = [], []
    for j in perm:
        a = all_asm[j]
        if len(held) < n_hold:
            held.append(a)
        else:
            train_asm.append(a)
    covered = {(i, a[k]) for a in train_asm for k, i in enumerate(positions)}
    for a in list(held):
        if any((i, a[k]) not in covered for k, i in enumerate(positions)):
            held.remove(a)
            train_asm.append(a)
            covered |= {(i, a[k]) for k, i in enumerate(positions)}
    assert not set(held) & set(train_asm)
    ctx.save_json("assemblies.json", {"positions": positions, "alternatives": names, "train": train_asm,
                                      "heldout": held, "heldout_inputs": "test partition (never trained)"})
    mode = cc["alt_training"]
    code_kind = cc["code_kind"]
    n_loc = cc["local_updates"]
    B = min(cfg["train"]["batch_size"], len(bundle.train))
    N = len(bundle.train)
    js = JobState(ctx, "alt")
    usage: Counter = Counter()
    loops: dict[str, dict] = {}
    gen_for = lambda key: torch_gen(seed_of(cfg, "assembly"), "assembly", "batches", key)
    batch_idx = lambda gen: torch.randint(0, N, (B,), generator=gen).to(ctx.device)
    trainable = lambda m: [p for p in m.parameters() if p.requires_grad]

    if mode == "independent" and code_kind == "fixed_teacher":
        for i in positions:
            for kind, m in alts[i].items():
                if kind == "reference":
                    continue
                gen = gen_for(f"{i}/{kind}")
                n_refit = n_loc // 4 if isinstance(m, SparseMLP) else 0
                lopt = LocalOpt(trainable(m), cfg["train"], n_loc + n_refit)

                def step(k, m=m, i=i, gen=gen):
                    idx = batch_idx(gen)
                    if cc["local_inputs"] == "teacher" or i == positions[0]:
                        x_in = T_tr[codes[i - 1]][idx]
                    else:
                        up_kind = sorted(alts[i - 1])[int(idx[0]) % len(alts[i - 1])]
                        up = alts[i - 1][up_kind]
                        with torch.no_grad():
                            x_in = up(T_tr[codes[i - 2]][idx], {kk: v[idx] for kk, v in tr_X.items()}) \
                                if isinstance(up, SubgraphPearl) else ifaces[i - 1](up(T_tr[codes[i - 2]][idx]))
                    return F.mse_loss(ifaces[i](m(x_in)), T_tr[codes[i]][idx])
                loops[f"fit/{i}/{kind}"] = local_loop(ctx, js, f"fit/{i}/{kind}", {"m": m}, lopt, gen, n_loc, step,
                                                      phase="alt_local_fit", examples_per_step=B)
                if n_refit:
                    m.prune(0.2)

                    def step2(k, m=m, i=i, gen=gen):
                        idx = batch_idx(gen)
                        return F.mse_loss(ifaces[i](m(T_tr[codes[i - 1]][idx])), T_tr[codes[i]][idx])
                    loops[f"refit/{i}/{kind}"] = local_loop(ctx, js, f"refit/{i}/{kind}", {"m": m}, lopt, gen,
                                                            n_refit, step2, phase="alt_sparse_refit",
                                                            examples_per_step=B, k_offset=n_loc)
    elif mode in ("joint", "shared_interface"):
        all_mods = {f"{i}:{k}": m for i in positions for k, m in alts[i].items() if k != "reference"}
        w_if = cc["interface_weight"] if mode == "shared_interface" else 0.0
        w_cons = cc["interface_weight"] if (mode == "joint" and code_kind == "learned") else 0.0
        steps = cc["global_updates"]
        lopt = LocalOpt([p for m in all_mods.values() for p in trainable(m)], cfg["train"], steps)
        gen = gen_for("joint")

        def step(k):
            idx = batch_idx(gen)
            a = train_asm[int(torch.randint(0, len(train_asm), (1,), generator=gen))]
            asm = Assembly(ref, codes, positions, {i: alts[i][a[kk]] for kk, i in enumerate(positions)},
                           interfaces=ifaces)
            X = {kk: v[idx] for kk, v in tr_X.items()}
            y, cs = asm(X, return_codes=True)
            loss = task_loss(y, bundle.train.y[idx], bundle.task)
            if w_if:
                loss = loss + w_if * sum(F.mse_loss(cs[i], T_tr[codes[i]][idx]) for i in positions)
            if w_cons:
                # learned shared code: all alternatives at a position agree on the code they emit
                for i in positions:
                    x_in = cs[i - 1].detach()
                    outs = [ifaces[i](mm(x_in)) for kk, mm in alts[i].items() if kk != "reference"]
                    if len(outs) > 1:
                        st = torch.stack(outs)
                        loss = loss + w_cons * ((st - st.mean(0, keepdim=True)) ** 2).mean()
            usage[a] += 1
            return loss       # an assembly of frozen reference pearls only has no gradient: counted as skipped

        def u_get():
            return {"|".join(k): v for k, v in usage.items()}

        def u_set(d):
            usage.clear()
            usage.update({tuple(k.split("|")): v for k, v in d.items()})
        loops["joint"] = local_loop(ctx, js, "joint", all_mods, lopt, gen, steps, step, phase="alt_joint",
                                    examples_per_step=B, extra_get=u_get, extra_set=u_set)
    elif code_kind == "aligned":
        # each module trained (task loss only) inside one home training assembly
        home = {}
        for a in train_asm:
            for k, i in enumerate(positions):
                home.setdefault((i, a[k]), a)
        for (i, kind), a in sorted(home.items(), key=lambda t: (t[0][0], t[0][1])):
            if kind == "reference":
                continue
            asm = Assembly(ref, codes, positions, {j: alts[j][a[k]] for k, j in enumerate(positions)},
                           interfaces=ifaces)
            mod = alts[i][kind]
            lopt = LocalOpt(trainable(mod), cfg["train"], n_loc)
            gen = gen_for(f"aligned/{i}/{kind}")

            def step(k, asm=asm, gen=gen):
                idx = batch_idx(gen)
                X = {kk: v[idx] for kk, v in tr_X.items()}
                return task_loss(asm(X), bundle.train.y[idx], bundle.task)
            info = local_loop(ctx, js, f"aligned/{i}/{kind}", {"m": mod}, lopt, gen, n_loc, step,
                              phase="alt_aligned", examples_per_step=B)
            loops[f"aligned/{i}/{kind}"] = info
            usage[a] += n_loc          # every step executes the home assembly (deterministic count, survives resume)
    else:
        raise Unsupported(f"alt_training={mode} with code_kind={code_kind} is not a defined combination")
    if mode == "independent" and code_kind == "fixed_teacher":
        used = set()          # local regression: no assembly is ever executed in training
    else:
        used = set(usage)
    leak = used & set(held)
    if leak:
        raise ScientificInvalid(f"held-out assemblies used in training: {sorted(leak)}")
    # local matching error per module on test codes (through the destination interface)
    local, sym_acc = {}, {}
    with torch.no_grad():
        for i in positions:
            q = ifaces[i].q
            for kind, m in alts[i].items():
                x_in = T_te[codes[i - 1]]
                out = m(x_in, te_X) if isinstance(m, SubgraphPearl) else ifaces[i](m(x_in))
                tgt = T_te[codes[i]]
                local[f"{i}:{kind}"] = float(F.mse_loss(out, tgt) / tgt.var().clamp_min(1e-12))
                ctx.metric("alternatives", "test", f"local_rel_mse[{i}:{kind}]", local[f"{i}:{kind}"])
                if q.mode == "uniform" and lay != "img":
                    sa = float((q.codes(out) == q.codes(tgt)).all(-1).double().mean())
                    sym_acc[f"{i}:{kind}"] = sa
                    ctx.metric("alternatives", "test", f"symbol_accuracy[{i}:{kind}]", sa)
    # evaluate every assembly (adapters fitted on training inputs for 'aligned')
    T = C.seq_T(bundle)
    fb = cfg["peg"]["float_bits"]
    rows, preds, adapter_recs = [], {}, {}
    for a in all_asm:
        choice = {i: alts[i][a[k]] for k, i in enumerate(positions)}
        adapters = {}
        if code_kind == "aligned":
            adapters = fit_adapters(ref, codes, positions, alts, a, train_asm, tr_X, T_tr, ctx.device, ifaces)
            adapter_recs["|".join(a)] = {i: _module_record(ad, {"module_type": "linear_adapter",
                                                                "d_in": ad.in_features, "d_out": ad.out_features})
                                         for i, ad in adapters.items()}
        asm = Assembly(ref, codes, positions, choice, adapters, ifaces).eval()
        dist = [0.0] * len(codes)
        with torch.no_grad():
            ys = []
            for j in range(0, len(bundle.test), 4096):
                y_, cs = asm({k: v[j:j + 4096] for k, v in te_X.items()}, return_codes=True)
                ys.append(y_)
                for ci, cv in enumerate(cs):
                    dist[ci] = max(dist[ci], ifaces[ci].distance(cv))
            y = torch.cat(ys)
        key = "|".join(a)
        preds[key] = y.detach().cpu()
        finite_dist = max([d for ci, d in enumerate(dist) if ifaces[ci].finite] or [0.0])
        if enforce and finite_dist > MEMBERSHIP_TOL:
            raise ScientificInvalid(f"assembly {a} emitted codes outside the declared finite alphabet "
                                    f"(max distance {finite_dist:.3g})", {"assembly": list(a), "distance": dist})
        m = M.task_metrics(y, bundle.test.y, bundle.task, bundle.test.groups, bundle.target_scale)
        n_par = sum(p.numel() for i in positions for p in choice[i].parameters() if not isinstance(choice[i], SubgraphPearl)) + \
            sum(p.numel() for ad in adapters.values() for p in ad.parameters())
        row = {"assembly": list(a), "heldout": a in held, "risk": M.headline(m, bundle.task),
               **({"acc": m["acc"]} if "acc" in m else {}), "alt_params": n_par,
               "bits_per_example": assembly_bits(ref, codes, positions, a, enforce, T, fb),
               "max_offalphabet_distance": finite_dist, "pred_hash": tensor_hash(preds[key])}
        rows.append(row)
        ctx.metric("alternatives", "test", f"assembly[{key}].risk", row["risk"], heldout=row["heldout"])
    seen = [r["risk"] for r in rows if not r["heldout"]]
    unseen = [r["risk"] for r in rows if r["heldout"]]
    # artifacts: everything needed to reproduce the predictions in a fresh process
    mods = {f"{i}:{k}": _module_record(m, attrs_of[f"{i}:{k}"]) for i in positions for k, m in alts[i].items()
            if k != "reference"}
    atomic_torch_save({"positions": positions, "codes": codes, "alternatives": names, "modules": mods,
                       "interfaces": {i: {"node": codes[i], "state": {k: v.cpu() for k, v in ifaces[i].q.state_dict().items()},
                                          "attrs": dict(ref.nodes[codes[i]].attrs), "enforce": enforce}
                                      for i in ifaces},
                       "adapters": adapter_recs, "train_assemblies": train_asm, "heldout": held,
                       "training_assembly_usage": {"|".join(k): v for k, v in usage.items()},
                       "reference": {"ckpt": "reference_exported", "structural_hash": ref.structural_hash(),
                                     "param_hash": ref.param_hash()}},
                      ctx.dir / "alternatives_modules.pt")
    atomic_torch_save(preds, ctx.dir / "alternatives_predictions.pt")
    out = {"mode": mode, "code_kind": code_kind, "interface_enforce": cc["interface_enforce"],
           "n_assemblies": len(all_asm), "n_heldout": len(held),
           "mean_risk_seen": sum(seen) / max(1, len(seen)), "mean_risk_heldout": (sum(unseen) / len(unseen)) if unseen
           else None, "local": local, "symbol_accuracy": sym_acc, "rows": rows,
           "local_train_policy": local_policy(cfg["train"]), "loops": loops, "unavailable_alternatives": unavailable,
           "audit": {"training_assemblies_used": sorted(used),
                     "training_assembly_usage": {"|".join(k): v for k, v in sorted(usage.items())},
                     "heldout_disjoint": not leak, "reference_bypass": byp,
                     "membership_tolerance": MEMBERSHIP_TOL},
           "artifacts": {"modules": "alternatives_modules.pt", "predictions": "alternatives_predictions.pt",
                         "reference": "ckpt/reference_exported.pt"}}
    ctx.save_json("alternatives_result.json", out)
    return {k: v for k, v in out.items() if k not in ("rows", "local", "loops", "symbol_accuracy")}


@torch.no_grad()
def fit_adapters(ref, codes, positions, alts, a, train_asm, tr_X, T_tr, device, ifaces=None) -> dict:
    """Least-squares affine adapters (training inputs) from the code a module
    receives in assembly `a` to the code its home assembly fed it."""
    ad = {}
    for k, i in enumerate(positions[1:], start=1):
        up = alts[positions[k - 1]][a[k - 1]]
        home = next(h for h in train_asm if h[k] == a[k])
        up_home = alts[positions[k - 1]][home[k - 1]]
        if home[k - 1] == a[k - 1]:
            continue
        x_in = T_tr[codes[i - 2]] if i - 2 >= 0 else None
        if x_in is None:
            continue
        X = {kk: v for kk, v in tr_X.items()}
        ifc = (lambda z: ifaces[i - 1](z)) if ifaces else (lambda z: z)
        f = lambda m, x: m(x, X) if isinstance(m, SubgraphPearl) else ifc(m(x))
        src, dst = f(up, x_in), f(up_home, x_in)
        S = src.reshape(-1, src.shape[-1]).double()
        D = dst.reshape(-1, dst.shape[-1]).double()
        S1 = torch.cat([S, torch.ones(len(S), 1, dtype=S.dtype, device=S.device)], 1)
        W = torch.linalg.lstsq(S1, D).solution
        lin = nn.Linear(S.shape[1], D.shape[1]).to(device)
        lin.weight.copy_(W[:-1].T.float())
        lin.bias.copy_(W[-1].float())
        ad[i] = lin
    return ad


# =============================================================================
# Fresh-process reload and verification
# =============================================================================

def reload_alternatives(run_dir: str | Path, data_root: Optional[str] = None, device: str = "cpu") -> dict:
    """Rebuild the reference, every trained alternative, interfaces and
    adapters from the run directory alone, recompute the test predictions of
    every assembly and compare them with the saved predictions and risks."""
    from ..utils import read_json
    from ..data.registry import load_bundle
    run_dir = Path(run_dir)
    cfg = read_json(run_dir / "config.json")
    bundle = load_bundle(cfg["data"], data_root, device="cpu").to(device)
    ref = GraphNet.from_checkpoint(torch.load(run_dir / "ckpt" / "reference_exported.pt", map_location="cpu",
                                              weights_only=False)["model"], device).eval()
    art = torch.load(run_dir / "alternatives_modules.pt", map_location="cpu", weights_only=False)
    saved = torch.load(run_dir / "alternatives_predictions.pt", map_location="cpu", weights_only=False)
    res = read_json(run_dir / "alternatives_result.json")
    _check_ref = ref.structural_hash() == art["reference"]["structural_hash"] and \
        ref.param_hash() == art["reference"]["param_hash"]
    codes, positions = art["codes"], art["positions"]
    ifaces = {}
    for i, rec in art["interfaces"].items():
        q = quantizer_of(ref, rec["node"])
        it = Interface(q, rec["enforce"], ref.nodes[rec["node"]].attrs.get("layout", ref.layout))
        it.q.load_state_dict(rec["state"])
        ifaces[int(i)] = it.to(device)
    alts = {i: {"reference": SubgraphPearl(ref, codes[i - 1], codes[i])} for i in positions}
    for key, rec in art["modules"].items():
        i, kind = key.split(":", 1)
        alts[int(i)][kind] = _build_from_record(rec, device).eval()
    out = {"reference_matches": _check_ref, "assemblies": {}, "max_abs_diff": 0.0, "all_bitwise_equal": True}
    rows = {"|".join(r["assembly"]): r for r in res["rows"]}
    for key, y_saved in saved.items():
        a = key.split("|")
        choice = {i: alts[i][a[k]] for k, i in enumerate(positions)}
        adapters = {}
        for i, rec in (art["adapters"].get(key) or {}).items():
            lin = nn.Linear(rec["attrs"]["d_in"], rec["attrs"]["d_out"])
            lin.load_state_dict(rec["state"])
            adapters[int(i)] = lin.to(device)
        asm = Assembly(ref, codes, positions, choice, adapters, ifaces).eval()
        with torch.no_grad():
            y = torch.cat([asm({k: v[j:j + 4096] for k, v in bundle.test.X.items()})
                           for j in range(0, len(bundle.test), 4096)]).cpu()
        d = float((y - y_saved).abs().max()) if y.numel() else 0.0
        m = M.task_metrics(y, bundle.test.y.cpu(), bundle.task, None if bundle.test.groups is None else
                           bundle.test.groups.cpu(), bundle.target_scale)
        n_par = sum(p.numel() for i in positions for p in choice[i].parameters()
                    if not isinstance(choice[i], SubgraphPearl)) + sum(p.numel() for ad in adapters.values()
                                                                        for p in ad.parameters())
        bits = assembly_bits(ref, codes, positions, a, res["interface_enforce"] == "enforced", C.seq_T(bundle),
                             cfg["peg"]["float_bits"])
        out["assemblies"][key] = {"max_abs_diff": d, "bitwise_equal": bool(torch.equal(y, y_saved)),
                                  "risk_recomputed": M.headline(m, bundle.task), "risk_reported": rows[key]["risk"],
                                  "pred_hash_matches": tensor_hash(y) == rows[key]["pred_hash"],
                                  "params_match": n_par == rows[key]["alt_params"],
                                  "bits_match": bits == rows[key]["bits_per_example"]}
        out["max_abs_diff"] = max(out["max_abs_diff"], d)
        out["all_bitwise_equal"] &= out["assemblies"][key]["bitwise_equal"]
    # local matching errors of every module on test codes
    T_te = node_values(ref, bundle.test.X, codes)
    out["local_max_abs_diff"] = 0.0
    with torch.no_grad():
        for i in positions:
            for kind, mod in alts[i].items():
                x_in = T_te[codes[i - 1]]
                o = mod(x_in, bundle.test.X) if isinstance(mod, SubgraphPearl) else ifaces[i](mod(x_in))
                tgt = T_te[codes[i]]
                v = float(F.mse_loss(o, tgt) / tgt.var().clamp_min(1e-12))
                out["local_max_abs_diff"] = max(out["local_max_abs_diff"], abs(v - res["local"][f"{i}:{kind}"]))
    out["ok"] = _check_ref and out["max_abs_diff"] <= 1e-5 and out["local_max_abs_diff"] <= 1e-6 and all(
        abs(v["risk_recomputed"] - v["risk_reported"]) <= 1e-5 * max(1.0, abs(v["risk_reported"])) and
        v["params_match"] and v["bits_match"] for v in out["assemblies"].values())
    return out
