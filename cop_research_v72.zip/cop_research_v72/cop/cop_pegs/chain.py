"""P1/P2: Chain of Pearls with pegs: placement, transmission, edits, export.

Procedure (one job):
  1. f0: parent baseline checkpoint (or trained inline);
  2. choose peg cutpoints (regular | random | known | adaptive; training-only
     evidence for adaptive); for delayed-query data the last peg sits exactly
     at the query injection point so the encoder side never sees the query;
  3. insert pegs (alpha=1 bypass, exact), calibrate E/D (PCA) and quantisers on
     training calibration inputs;
  4. anneal alpha 1->0, then (if present) the temporary channel beta 1->0,
     then train at the endpoint;
  5. optional peg edit (move | split | merge) with extra training;
  6. export_compact (bypass and temporary channel physically removed, decoders
     folded into following linear maps where that reduces parameters), verify
     exported predictions against the endpoint model, bypass and query checks,
     accounting (parameters, MACs, bits per example per peg).
"""
from __future__ import annotations

import math
from typing import Optional

import torch
import torch.nn.functional as F

from ..config import seed_of
from ..graph import edits as E
from ..graph.accounting import report as acct
from ..graph.export import export_compact
from ..graph.graph import GraphNet, InvalidDeletion
from ..train import metrics as M
from ..train.trainer import Segment, Trainer, evaluate, forward_macs
from ..utils import torch_gen
from ..experiments import common as C
from ..experiments.context import Unsupported
from ..experiments.trajectory import train_baseline
from .pegs import insert_peg, calibrate_peg, peg_stats, bypass_report, query_isolation, pegs as list_pegs

PEG_CUT_KIND = {"mlp": "post_act", "cnn": "post_act", "resnet": "block_out", "transformer": "resid", "gru": "gru_out"}


def peg_cut_kind(g: GraphNet) -> str:
    return PEG_CUT_KIND[g.family]


def load_f0(ctx, bundle) -> tuple[GraphNet, dict]:
    if ctx.has_ckpt("baseline_ref"):
        ck = ctx.load_ckpt("baseline_ref")
        return GraphNet.from_checkpoint(ck["model"], ctx.device), ck["extra"]["trainer"]
    if "baseline" in ctx.cfg.get("parents", {}):
        # v13: tags.f0_stage selects which f0 state the chain starts from (e.g. best_val, the validation-selected
        # f0 of the baseline job); default the fixed-budget baseline
        ck = ctx.parent_ckpt("baseline", (ctx.cfg.get("tags") or {}).get("f0_stage", "baseline"))
        tr_state = ck["trainer"]
        src = ctx.cfg["parents"]["baseline"]
    else:
        m, tr = train_baseline(ctx, bundle)
        ck = {"model": m.checkpoint()}
        tr_state = tr.state_dict()
        src = "inline"
    g = GraphNet.from_checkpoint(ck["model"], ctx.device)
    ctx.save_ckpt("baseline_ref", g, None, {"trainer": tr_state, "source": src})
    return g, tr_state


def query_index(g: GraphNet) -> Optional[int]:
    q = (g.meta.get("arch") or {}).get("query")
    if not q:
        return None
    return int(q["at_layer"])


def placement(ctx, g: GraphNet, bundle, n_pegs: int) -> dict:
    cc = ctx.cfg["cop"]
    kind = peg_cut_kind(g)
    cps = sorted(E.cutpoints(g, kind), key=lambda c: c["index"])
    qi = query_index(g)
    if qi is not None and qi < 0:
        # query before the pegs (F09e control): the query enters with the input, so every peg may carry
        # it; pegs are placed like an ordinary chain and query_isolation reports the encoder's access
        qi = None
    if qi is not None:
        cps = [c for c in cps if c["index"] <= qi]
    n = len(cps)
    if n_pegs > n:
        raise Unsupported(f"{n_pegs} pegs requested but only {n} cutpoints available")
    pol = cc["placement"]
    info = {"policy": pol, "n_cutpoints": n}
    if pol in ("regular", "known"):
        idx = sorted({max(0, int(round((i + 1) * n / (n_pegs + 1))) - 1) for i in range(n_pegs)})
        if qi is not None:
            idx = sorted(set(idx[:-1]) | {n - 1})
    elif pol == "random":
        perm = torch.randperm(n, generator=torch_gen(seed_of(ctx.cfg, "peg"), "peg", "placement"))
        idx = sorted(perm[:n_pegs].tolist())
        if qi is not None and n - 1 not in idx:
            idx = sorted(idx[:-1] + [n - 1])
    else:  # adaptive: smallest PCA residual at k dims on TRAINING calibration activations
        X = {k: v[:ctx.cfg["eval"]["calib_size"]] for k, v in bundle.train.X.items()}
        k = ctx.cfg["peg"]["dim"]
        scores = {}
        from .modules import node_values
        for c in cps:
            src = E.resolve_edges(g, c["edges"]).source
            h = node_values(g, X, [src])[src]
            H = (h.permute(0, 2, 3, 1).reshape(-1, h.shape[1]) if g.layout == "img" else h.reshape(-1, h.shape[-1])).double()
            S = torch.linalg.svdvals(H - H.mean(0))
            scores[c["index"]] = float((S[k:] ** 2).sum() / (S ** 2).sum().clamp_min(1e-30))
        order = sorted(scores, key=lambda i: (scores[i], i))
        idx = sorted(order[:n_pegs])
        if qi is not None and (n - 1) not in idx:
            idx = sorted(idx[:-1] + [n - 1])
        info.update({"scores": scores, "selection_data": "train calibration subset",
                     "search_cost": f"{n} SVDs of calibration activations"})
    info["indices"] = idx
    return info


def build_chain(ctx, g: GraphNet, bundle, idx: list[int], k: Optional[int] = None, slot_prefix: str = "peg") -> list[str]:
    pc = ctx.cfg["peg"]
    kind = peg_cut_kind(g)
    ids = []
    mid = len(idx) // 2
    for j, i in enumerate(idx):
        cut = E.cut_at(g, kind, i)
        # mechanism H: temp_on = middle bridges one interface only (the middle peg of the chain)
        temp = pc["temp_channel"] if (pc.get("temp_on", "all") == "all" or j == mid) else 0
        pid = insert_peg(g, cut, torch_gen(seed_of(ctx.cfg, "peg"), "peg", f"{slot_prefix}{j}"), k or pc["dim"],
                         pc["mode"], pc["bits"], pc["codebook_size"], pc["n_messages"], temp,
                         slot=f"{slot_prefix}{j}", redundancy=int(pc.get("redundancy", 1)))
        ids.append(pid)
    X = {kk: v[:ctx.cfg["eval"]["calib_size"]] for kk, v in bundle.train.X.items()}
    cal = {}
    for j, pid in enumerate(ids):
        cal[pid] = calibrate_peg(g, pid, X, torch_gen(seed_of(ctx.cfg, "peg"), "peg", f"cal{j}"), pc["init"])
    g.meta["pearls"] = pearl_partition(g)
    ctx.log({"event": "pegs_inserted", "pegs": ids, "calibration": cal})
    return ids


def pearl_partition(g: GraphNet) -> list[list[str]]:
    """Backbone nodes grouped into pearls: nodes between consecutive pegs."""
    ps = list_pegs(g)
    live = g.live_nodes()
    order = [n for n in g.topo_order(live)]
    bounds = [g.implants[p].meta["peg"]["quant"] for p in ps]
    pearls, cur = [], []
    region = set()
    for p in ps:
        region |= g.region(p)
    for n in order:
        if n in bounds:
            pearls.append(cur)
            cur = []
            continue
        if n in region or g.nodes[n].pkey is None:
            continue
        cur.append(n)
    pearls.append(cur)
    return pearls


def anneal_segments(ctx, g: GraphNet, peg_ids: list[str], total: int, known_loss=None) -> list[Segment]:
    """Segments: anneal_alpha (A updates), bridge_open (mechanism H: alpha = 0, beta = 1 for
    peg.temp_open_updates), anneal_temp_channel (beta 1 -> 0 over anneal_updates), endpoint.
    With peg.temp_target = adapter the bridge is never retired (beta stays 1 in every segment;
    the same segment lengths keep the update budget equal)."""
    pc = ctx.cfg["peg"]
    A = min(pc["anneal_updates"], total) if pc["bypass"] else 0
    alphas = [g.implants[p].meta["peg"]["alpha"] for p in peg_ids]
    betas = [g.implants[p].meta["peg"]["beta"] for p in peg_ids if g.implants[p].meta["peg"]["beta"]]
    keep_bridge = pc.get("temp_target", "all") == "adapter"
    beta_end = 1.0 if keep_bridge else 0.0
    if not pc["bypass"]:
        for a in alphas:
            g.gate_vals[a] = 0.0
    segs = []

    def set_alpha(trn, step):
        v = max(0.0, 1.0 - (step + 1) / max(1, A))
        for a in alphas:
            trn.model.gate_vals[a] = v
    if A:
        segs.append(Segment("anneal_alpha", A, on_step=set_alpha, extra_loss=known_loss))
    O = min(int(pc.get("temp_open_updates", 0)), max(0, total - A)) if betas else 0

    def bridge_open(trn, step):
        for a in alphas:
            trn.model.gate_vals[a] = 0.0
        for b in betas:
            trn.model.gate_vals[b] = 1.0
    if O:
        segs.append(Segment("bridge_open", O, on_step=bridge_open, extra_loss=known_loss))
    # v5: the bridge is retired over peg.temp_anneal_updates (null = anneal_updates; 1 = abrupt removal)
    TB = pc.get("temp_anneal_updates")
    B = min(int(TB) if TB else pc["anneal_updates"], max(0, total - A - O)) if betas else 0

    def set_beta(trn, step):
        v = 1.0 if keep_bridge else max(0.0, 1.0 - (step + 1) / max(1, B))
        for a in alphas:
            trn.model.gate_vals[a] = 0.0
        for b in betas:
            trn.model.gate_vals[b] = v
    if B:
        segs.append(Segment("anneal_temp_channel", B, on_step=set_beta, extra_loss=known_loss))
    rest = total - A - O - B

    def endpoint(trn, step):
        for a in alphas:
            trn.model.gate_vals[a] = 0.0
        for b in betas:
            trn.model.gate_vals[b] = beta_end
    if rest > 0:
        segs.append(Segment("endpoint", rest, on_step=endpoint, extra_loss=known_loss))
    return segs


def known_interface_loss(ctx, g: GraphNet, bundle, peg_ids: list[str]):
    """'known' placement: supervise peg codes toward the dataset's known
    intermediates through training-only linear readouts (access to teacher
    intermediates is recorded; readouts are not part of the export)."""
    vars_ = [v for v in ("z", "u") if v in bundle.train.aux]
    if not vars_:
        raise Unsupported("placement 'known' needs a dataset with known intermediates (D03 compose)")
    readouts = {}
    from ..graph.ops import init_module
    for j, pid in enumerate(peg_ids[:len(vars_)]):
        q = g.implants[pid].meta["peg"]["quant"]
        dv = bundle.train.aux[vars_[j]].shape[1]
        ro = torch.nn.Linear(g.node_dim(q), dv)
        init_module(ro, torch_gen(seed_of(ctx.cfg, "peg"), "peg", f"known_readout{j}"), "default")
        readouts[q] = (ro.to(ctx.device), vars_[j])   # training-only; never part of the graph or the export
    w = ctx.cfg["cop"]["interface_weight"]

    def loss(m, c, batch, step):
        col = c.get("collected", {})
        tot = 0.0
        for q, (ro, var) in readouts.items():
            if q in col and var in batch.aux:
                tot = tot + F.mse_loss(ro(col[q]), batch.aux[var].to(col[q].dtype))
        return w * tot
    return loss, set(readouts), readouts


def _restore_into(g: GraphNet, ck_model: dict) -> None:
    """Load a checkpoint of the SAME graph structure into the live object g
    (callers keep references to g)."""
    if ck_model["spec"]["nodes"] != g.to_spec()["nodes"]:
        raise RuntimeError("checkpoint graph structure differs from the rebuilt graph; cannot resume in place")
    g.load_state_dict(ck_model["state"])
    g.gate_vals.update(ck_model["spec"]["gate_vals"])
    g._plan = None


def temp_target_nodes(ctx, g: GraphNet, peg_ids: list[str]) -> Optional[set[str]]:
    """Nodes allowed to learn while the temporary channel is retired (None: everything trains).
    peg: the bridged peg(s) with their bridge; pegs: every peg and the bridge."""
    tt = ctx.cfg["peg"].get("temp_target", "all")
    if tt in ("all", "adapter"):
        return None
    sel = [p for p in peg_ids if p in g.implants and
           (tt == "pegs" or g.implants[p].meta["peg"]["beta"] is not None)]
    out = {n for p in sel for n in g.implants[p].nodes if n in g.nodes}
    if not any(g.nodes[n].pkey is not None for n in out):
        raise Unsupported("temp_target selects no parameters")
    return out


def _route_blocks(ctx, pm: dict) -> int:
    r = int(pm.get("redundancy", 1))
    return r if r > 1 else int(ctx.cfg["cop"].get("route_blocks", 0))


@torch.no_grad()
def route_erasure(ctx, g: GraphNet, bundle, peg_ids: list[str], tr: Trainer):
    """F07e training-time erasure: per update, with probability peg.route_dropout, one random
    block of one peg's quantised code is replaced by that block's training mean (computed once,
    on the freshly calibrated chain, so a resumed job recomputes the same values).  The draw is a
    pure function of (peg seed, global step): resumption needs no extra generator state."""
    p = float(ctx.cfg["peg"].get("route_dropout", 0.0))
    if p <= 0:
        return None
    from ..utils import stream_seed
    batch = ctx.cfg["train"]["eval_batch"]
    dev = next(iter(bundle.train.X.values())).device
    n_cal = min(int(ctx.cfg["eval"]["calib_size"]), len(bundle.train))
    cal = bundle.train.index(torch.arange(n_cal, device=dev))
    targets = []
    for pid in peg_ids:
        pm = g.implants[pid].meta["peg"]
        nb = _route_blocks(ctx, pm)
        if nb < 2 or pm["dim"] % nb:
            continue
        q = pm["quant"]
        mean = _flat(_node_values(g, cal, [q], batch)[q], g.layout).mean(0)
        targets.append((q, nb, pm["dim"] // nb, mean))
    if not targets:
        return None
    base = seed_of(ctx.cfg, "peg")
    lay = g.layout

    def patch_for_step(step: int):
        u = (stream_seed(base, "peg", "route_dropout", step) % 1_000_000) / 1_000_000
        if u >= p:
            return None
        q, nb, m, mean = targets[stream_seed(base, "peg", "route_dropout_peg", step) % len(targets)]
        j = stream_seed(base, "peg", "route_dropout_block", step) % nb
        sl = slice(j * m, (j + 1) * m)

        def erase(t, sl=sl, mean=mean):
            t = t.clone()
            if lay == "img":
                t[:, sl] = mean[sl].view(1, -1, 1, 1).to(t)
            else:
                t[..., sl] = mean[sl].to(t)
            return t
        return {q: erase}
    return patch_for_step


def train_chain(ctx, g: GraphNet, bundle, peg_ids: list[str], total: int, trainer_state: Optional[dict] = None,
                stream_key: str = "cop", ckpt_stage: Optional[str] = None, phase_eval=None,
                mac_target: Optional[int] = None, selector=None) -> Trainer:
    """Anneal alpha (and beta) and train at the endpoint.  With ckpt_stage the
    training is resumable at update granularity (ckpt/<stage>_partial.pt:
    model, Trainer state incl. generators, training-only readouts) and
    idempotent (ckpt/<stage>_done.pt is loaded instead of retraining)."""
    tr = Trainer(g, bundle, ctx.cfg["train"], C.seeds(ctx.cfg), ctx.device, ctx.log, stream_key)
    known = None
    collect = set()
    readouts = {}
    if ctx.cfg["cop"]["placement"] == "known":
        known, collect, readouts = known_interface_loss(ctx, g, bundle, peg_ids)
        tr.extra_params = [p for ro, _ in readouts.values() for p in ro.parameters()]
    ro_state = lambda: {q: {k: v.detach().cpu().clone() for k, v in ro.state_dict().items()}
                        for q, (ro, _) in readouts.items()}

    def ro_load(d):
        for q, (ro, _) in readouts.items():
            if q in d:
                ro.load_state_dict(d[q])
    segs = anneal_segments(ctx, g, peg_ids, total, known) if peg_ids else [Segment("endpoint", total)]
    # erasure fill values come from the freshly calibrated chain, BEFORE any checkpoint is restored
    erasure = route_erasure(ctx, g, bundle, peg_ids, tr) if peg_ids else None
    phase_rec: dict = {}          # v5: evaluations at segment ends (bridge before / after removal), resumable
    tr.phase_evals = phase_rec
    # v13 MAC-matched panel: the endpoint segment (fixed gates, so a constant cost per update) gets the updates
    # that bring this trainer's MACs to mac_target; planned once when the segment starts, checkpointed for resume
    tr.mac_plan = None
    if ckpt_stage and ctx.has_ckpt(f"{ckpt_stage}_done"):
        ck = ctx.load_ckpt(f"{ckpt_stage}_done")
        _restore_into(g, ck["model"])
        tr.load_state_dict(ck["trainer"])
        ro_load(ck["extra"].get("readouts", {}))
        phase_rec.update(ck["extra"].get("phase_evals", {}))
        tr.mac_plan = ck["extra"].get("mac_plan")
        ctx.note_trainer(tr, f"chain_train:{stream_key}")
        n_done = int(tr.state["global_step"])           # actual updates (fewer than requested after divergence)
        ctx.count_work(f"chain_train:{stream_key}", updates=n_done, examples=n_done * tr.B,
                       seconds=tr.timing["train_seconds"],
                       macs=int(tr.state.get("train_macs", 0)), macs_bwd=int(tr.state.get("train_macs_bwd", 0)))
        return tr
    start = 0
    if ckpt_stage and ctx.has_ckpt(f"{ckpt_stage}_partial"):
        ck = ctx.load_ckpt(f"{ckpt_stage}_partial")
        _restore_into(g, ck["model"])
        tr.load_state_dict(ck["trainer"])
        ro_load(ck["extra"].get("readouts", {}))
        names = [s_.name for s_ in segs]
        start = names.index(tr.state["segment"]) if tr.state["segment"] in names else 0
        phase_rec.update(ck["extra"].get("phase_evals", {}))
        tr.mac_plan = ck["extra"].get("mac_plan")
        ctx.log({"event": "resume", "stage": ckpt_stage, "segment": tr.state["segment"],
                 "seg_step": tr.state["seg_step"]})
    else:
        tr.configure("none", None, reset_state=True)
    cb = (lambda: ctx.save_ckpt(f"{ckpt_stage}_partial", g, tr, {"readouts": ro_state(), "pegs": peg_ids,
                                                                  "phase_evals": dict(phase_rec),
                                                                  "mac_plan": tr.mac_plan})) \
        if ckpt_stage else None
    retire_set = temp_target_nodes(ctx, g, peg_ids)
    for s in segs[start:]:
        if collect or erasure:
            def bctx(b, collect=collect, erasure=erasure):
                d = {"collect": collect} if collect else {}
                if erasure is not None:
                    pt = erasure(tr.state["global_step"])
                    if pt:
                        d["patch"] = pt
                return d
            s.batch_ctx = bctx
        # mechanism H: while the bridge is retired only the declared interfaces learn.  The optimizer keeps
        # covering every tensor (the rest get no gradient and keep their optimizer state), as in the 'all' arm
        if retire_set is not None and s.name in ("anneal_temp_channel", "endpoint"):
            if s.name == "anneal_temp_channel":
                s.trainable = {g.nodes[n].pkey for n in retire_set if n in g.nodes and g.nodes[n].pkey is not None}
            pks = s.trainable if s.trainable is not None else set(tr.state["pkeys"] or [])
            ctx.log({"event": "trainable_set", "segment": s.name, "temp_target": ctx.cfg["peg"].get("temp_target"),
                     "n_trainable_params": sum(p_.numel() for pk in pks for p_ in g.mods[pk].parameters())})
        if mac_target is not None and s.name == "endpoint":
            if tr.mac_plan is None:
                s.on_step(tr, 0)                                       # the endpoint gate values
                per = 3 * forward_macs(g, C.seq_T(bundle), {}) * tr.B
                have = int(tr.state.get("train_macs", 0))
                tr.mac_plan = {"target_macs": int(mac_target), "macs_before_endpoint": have,
                               "macs_per_endpoint_update": int(per),
                               "endpoint_updates": max(0, int(math.ceil((int(mac_target) - have) / max(1, per))))}
            s.updates = int(tr.mac_plan["endpoint_updates"])
            if s.updates == 0:
                continue
        if selector is not None and selector.enabled and s.name == "endpoint":
            # v13 (audit C2): validation-selection candidates over the endpoint segment only (the gates are at
            # their endpoint values, so every candidate is exported to the job's final compact architecture)
            s.eval_points = selector.points(int(s.updates))
            s.eval_fn = selector.eval_fn("chain_endpoint")
        tr.run(s, checkpoint_cb=cb)
        if phase_eval is not None and s.name not in phase_rec:
            phase_rec[s.name] = {"after_updates": int(tr.state["global_step"]), **phase_eval(g, s.name)}
    ctx.note_trainer(tr, f"chain_train:{stream_key}")
    n_done = int(tr.state["global_step"])               # actual updates (fewer than requested after divergence)
    ctx.count_work(f"chain_train:{stream_key}", updates=n_done, examples=n_done * tr.B,
                   seconds=tr.timing["train_seconds"],
                   macs=int(tr.state.get("train_macs", 0)), macs_bwd=int(tr.state.get("train_macs_bwd", 0)))
    if ckpt_stage:
        ctx.save_ckpt(f"{ckpt_stage}_done", g, tr, {"readouts": ro_state(), "pegs": peg_ids,
                                                     "phase_evals": dict(phase_rec), "mac_plan": tr.mac_plan})
        ctx.ckpt_path(f"{ckpt_stage}_partial").unlink(missing_ok=True)
    return tr


def evaluate_chain(ctx, g: GraphNet, bundle, stage: str, peg_ids: list[str]) -> dict:
    T = C.seq_T(bundle)
    res, preds = C.eval_log(ctx, g, bundle, stage)
    Xv = {k: v[:ctx.cfg["eval"]["calib_size"]] for k, v in bundle.val.X.items()}
    stats = {}
    for pid in peg_ids:
        if pid in g.implants:
            stats[pid] = peg_stats(g, pid, Xv, T, ctx.cfg["peg"]["float_bits"])
            ctx.metrics(stage, "val", {k: v for k, v in stats[pid].items() if isinstance(v, (int, float))},
                        prefix=f"peg[{pid}].")
    return {"metrics": {p: {k: v for k, v in m.items() if isinstance(v, (int, float))} for p, m in res.items()},
            "pegs": stats}


def export_and_verify(ctx, g: GraphNet, bundle, stage: str) -> tuple[GraphNet, dict]:
    T = C.seq_T(bundle)
    Xf = {k: v[:ctx.cfg["eval"]["calib_size"]] for k, v in bundle.val.X.items()}
    exp, rep = export_compact(g, Xf, fold_linear=True)
    byp = bypass_report(exp)
    qiso = query_isolation(exp)
    a = acct(exp, T, ctx.cfg["peg"]["float_bits"])
    res, _ = evaluate(exp, bundle, ["val", "test"] + [p for p in bundle.extra], ctx.cfg["train"]["eval_batch"])
    out = {"export_max_abs_err_vs_endpoint": rep.get("max_abs_err"), "export_rel_err": rep.get("rel_err"),
           "params": a["params"], "macs": a["macs"], "messages": a["messages"],
           "bits_per_example_total": sum(m["bits_per_example"] for m in a["messages"]),
           "bypass": byp, "query_isolation": qiso, "notes": rep["notes"],
           "test": {k: v for k, v in res["test"].items() if isinstance(v, (int, float))},
           "val": {k: v for k, v in res["val"].items() if isinstance(v, (int, float))}}
    for p, m in res.items():
        ctx.metrics(stage, p, m, graph_hash=exp.structural_hash())
    ctx.metric(stage, "none", "export_params", a["params"], exp.structural_hash())
    ctx.metric(stage, "none", "bits_per_example", out["bits_per_example_total"], exp.structural_hash())
    ctx.metric(stage, "fresh", "export_max_abs_err", rep.get("max_abs_err"), exp.structural_hash())
    ctx.metric(stage, "none", "any_bypass", any(v.get("has_bypass") for v in byp.values()), exp.structural_hash())
    ctx.save_graph(stage, exp)
    ctx.save_ckpt(stage, exp)
    if stage == "export":
        C.record_endpoint(ctx, bundle, "export", bool(ctx.numerics["diverged"]), ctx.numerics["reason"],
                          {"any_bypass": bool(any(v.get("has_bypass") for v in byp.values())),
                           "query_reaches_encoder": bool((qiso or {}).get("query_reaches_encoder")),
                           "interface_bits_per_example": int(out["bits_per_example_total"])})
    return exp, out


def peg_edit(ctx, g: GraphNet, bundle, peg_ids: list[str], tr: Trainer) -> dict:
    """P1 edits: move a peg one cutpoint later, split the largest pearl with an
    extra peg, or merge two pearls by deleting the peg between them."""
    edit = ctx.cfg["cop"]["peg_edit"]
    kind = peg_cut_kind(g)
    upd = ctx.cfg["cop"]["local_updates"]
    before, _ = evaluate(g, bundle, ["val"], ctx.cfg["train"]["eval_batch"])
    info = {"edit": edit}
    if edit == "merge":
        target = peg_ids[0]
        h = E.delete(g, [target], share_params=False)
        new_ids = [p for p in peg_ids if p != target]
    elif edit in ("move", "split"):
        cps = sorted(E.cutpoints(g, kind), key=lambda c: c["index"])
        used = set(g.meta.get("peg_indices", []))
        if edit == "move":
            target = peg_ids[0]
            old_i = g.meta["peg_indices"][0]
            new_i = min(len(cps) - 1, old_i + 1)
            if new_i in used:
                raise Unsupported("no free cutpoint to move the peg to")
            h = E.delete(g, [target], share_params=False)
            new_ids = [p for p in peg_ids if p != target]
            info.update({"from": old_i, "to": new_i})
        else:
            free = [c["index"] for c in cps if c["index"] not in used]
            if not free:
                raise Unsupported("no free cutpoint to split a pearl")
            new_i = free[len(free) // 2]
            h = g.clone(share_params=False)
            new_ids = list(peg_ids)
            info.update({"at": new_i})
        nid = build_chain(ctx, h, bundle, [new_i], slot_prefix="edit")
        new_ids += nid
    else:
        return {"edit": "none"}, g, peg_ids
    fresh = [p for p in new_ids if p in h.implants and h.gate_vals[h.implants[p].meta["peg"]["alpha"]] > 0]
    tr2 = train_chain(ctx, h, bundle, fresh, upd, stream_key="cop_edit",
                      ckpt_stage="edit_train")   # only NEW pegs are annealed
    after, _ = evaluate(h, bundle, ["val"], ctx.cfg["train"]["eval_batch"])
    info.update({"val_risk_before": M.headline(before["val"], bundle.task),
                 "val_risk_after": M.headline(after["val"], bundle.task), "extra_updates": upd})
    ctx.metrics("peg_edit", "val", {k: v for k, v in info.items() if isinstance(v, (int, float))})
    return info, h, [p for p in new_ids if p in h.implants]


def _flat(t: torch.Tensor, layout: str) -> torch.Tensor:
    return t.permute(0, 2, 3, 1).reshape(-1, t.shape[1]) if layout == "img" else t.reshape(-1, t.shape[-1])


@torch.no_grad()
def _node_values(g: GraphNet, part, nodes: list[str], batch: int) -> dict:
    from ..train.trainer import model_dtype
    dt = model_dtype(g)
    was = g.training
    g.eval()
    out = {n: [] for n in nodes}
    N = len(part)
    for i in range(0, N, batch):
        X = {k: (v[i:i + batch].to(dt) if v.is_floating_point() else v[i:i + batch]) for k, v in part.X.items()}
        _, v = g(X, return_nodes=nodes)
        for n in nodes:
            out[n].append(v[n])
    g.train(was)
    return {n: torch.cat(v) for n, v in out.items()}


@torch.no_grad()
def route_damage(ctx, g: GraphNet, bundle, peg_ids: list[str]) -> dict:
    """F07e: damage from losing one block of transmitted coordinates at a peg.  Block j of a
    peg with redundancy r is route j (dim / r coordinates); an ordinary peg is cut into
    cop.route_blocks equal blocks.  'impute': the block's quantised values are replaced by their
    training mean (the decoder is unchanged); 'renorm' (redundancy > 1 only): the lost route's
    decoder term is dropped and the remaining routes are re-averaged (the repetition decoder)."""
    batch = ctx.cfg["train"]["eval_batch"]
    parts = [p for p in ("val", "test") if p in bundle.partitions()]
    base, _ = evaluate(g, bundle, parts, batch)
    out = {}
    for pid in peg_ids:
        if pid not in g.implants:
            continue
        pm = g.implants[pid].meta["peg"]
        r = int(pm.get("redundancy", 1))
        nb = _route_blocks(ctx, pm)
        if nb < 2 or pm["dim"] % nb:
            continue
        q = pm["quant"]
        k = pm["dim"]
        n_cal = min(int(ctx.cfg["eval"]["calib_size"]), len(bundle.train))
        dev = next(iter(bundle.train.X.values())).device
        Q = _node_values(g, bundle.train.index(torch.arange(n_cal, device=dev)), [q], batch)[q]
        mean = _flat(Q, g.layout).mean(0)
        m = k // nb
        rows = []
        for j in range(nb):
            sl = slice(j * m, (j + 1) * m)

            def imp(t, sl=sl):
                t = t.clone()
                if g.layout == "img":
                    t[:, sl] = mean[sl].view(1, -1, 1, 1).to(t)
                else:
                    t[..., sl] = mean[sl].to(t)
                return t
            g.value_patch = {q: imp}
            try:
                res, _ = evaluate(g, bundle, parts, batch)
            finally:
                g.value_patch = None
            row = {"block": j, "coords": [j * m, (j + 1) * m],
                   "impute": {p: M.headline(res[p], bundle.task) for p in parts}}
            if r > 1:
                dn = g.nodes[pm["dec"]]
                saved = list(dn.attrs["coefs"])
                dn.attrs["coefs"] = [0.0 if i == j else 1.0 / (r - 1) for i in range(r)]
                try:
                    res2, _ = evaluate(g, bundle, parts, batch)
                finally:
                    dn.attrs["coefs"] = saved
                row["renorm"] = {p: M.headline(res2[p], bundle.task) for p in parts}
            rows.append(row)
        out[pid] = {"redundancy": r, "blocks": nb, "base": {p: M.headline(base[p], bundle.task) for p in parts},
                    "rows": rows}
        for row in rows:
            for kind in ("impute", "renorm"):
                if kind in row:
                    for p in parts:
                        ctx.metric("route_damage", p, f"peg[{pid}].block{row['block']}.{kind}.risk", row[kind][p],
                                   g.structural_hash())
    return out


def route_repair(ctx, g: GraphNet, bundle, peg_ids: list[str]) -> Optional[dict]:
    """F07e 'selectively remove redundancy': block 0 (route 0) is removed at the selected pegs
    (repetition pegs: its decoder term is dropped and the other routes re-averaged; ordinary pegs:
    the block is held at its training mean), then the whole chain trains for
    cop.route_repair_updates with the block still removed.  Reported: risk immediately after the
    removal and after repair, and the bits per example that remain transmitted (analytic: the
    removed coordinates are not sent)."""
    n_upd = int(ctx.cfg["cop"].get("route_repair_updates", 0))
    if n_upd <= 0:
        return None
    batch = ctx.cfg["train"]["eval_batch"]
    parts = [p for p in ("val", "test") if p in bundle.partitions()]
    h = g.clone(share_params=False)
    cand = [p for p in peg_ids if p in h.implants and _route_blocks(ctx, h.implants[p].meta["peg"]) >= 2]
    if ctx.cfg["cop"].get("route_remove", "all_pegs") == "middle_peg" and cand:
        cand = [cand[len(cand) // 2]]
    if not cand:
        raise Unsupported("no peg with removable routes")
    dev = next(iter(bundle.train.X.values())).device
    n_cal = min(int(ctx.cfg["eval"]["calib_size"]), len(bundle.train))
    cal = bundle.train.index(torch.arange(n_cal, device=dev))
    patch, removed, fill = {}, {}, {}
    for pid in cand:
        pm = h.implants[pid].meta["peg"]
        nb, r, k = _route_blocks(ctx, pm), int(pm.get("redundancy", 1)), pm["dim"]
        m = k // nb
        if r > 1:
            dn = h.nodes[pm["dec"]]
            dn.attrs["coefs"] = [0.0] + [1.0 / (r - 1)] * (r - 1)
            h._plan = None
        else:
            q = pm["quant"]
            mean = _flat(_node_values(h, cal, [q], batch)[q], h.layout).mean(0)

            def erase(t, mean=mean, m=m):
                t = t.clone()
                if h.layout == "img":
                    t[:, :m] = mean[:m].view(1, -1, 1, 1).to(t)
                else:
                    t[..., :m] = mean[:m].to(t)
                return t
            patch[q] = erase
            fill[q] = {"n_coords": int(m), "mean": mean[:m].detach().cpu().clone(), "layout": h.layout}
        removed[pid] = {"coords": [0, m], "kind": "route dropped, re-averaged" if r > 1 else "held at training mean"}
    T = C.seq_T(bundle)
    msgs = {m_["node"]: m_ for m_ in acct(h, T, ctx.cfg["peg"]["float_bits"])["messages"]}
    bits_before = sum(m_["bits_per_example"] for m_ in msgs.values())
    bits_removed = 0
    for pid in cand:
        pm = h.implants[pid].meta["peg"]
        mq = msgs.get(pm["quant"])
        if mq:
            bits_removed += mq["bits_per_example"] * removed[pid]["coords"][1] / pm["dim"]

    def ev():
        h.value_patch = patch or None
        try:
            res, _ = evaluate(h, bundle, parts, batch)
        finally:
            h.value_patch = None
        return {p: M.headline(res[p], bundle.task) for p in parts}
    immediate = ev()
    tr = Trainer(h, bundle, ctx.cfg["train"], C.seeds(ctx.cfg), ctx.device, ctx.log, "route_repair")
    tr.configure("none", None, reset_state=True)
    tr.run(Segment("route_repair", n_upd, batch_ctx=(lambda b: {"patch": patch}) if patch else None))
    # the repaired clone is not the exported chain: its work is diagnostic (never in C1 / C2 budgets)
    n_done = int(tr.state["global_step"])
    ctx.count_work("diagnostic:route_repair", updates=n_done, examples=n_done * tr.B, seconds=tr.timing["train_seconds"],
                   macs=int(tr.state.get("train_macs", 0)), macs_bwd=int(tr.state.get("train_macs_bwd", 0)))
    repaired = ev()
    # a DIAGNOSTIC model: the removed coordinates are still computed (held at the mean / re-averaged), the
    # quantiser is not physically narrowed; saved with the erasure fill values (training means of the held
    # coordinates, computed on the pre-repair clone), so the reported numbers can be reproduced from the file
    ctx.save_ckpt("diagnostic_route_repair", h, None, {"patch_coords": {k: v["coords"] for k, v in removed.items()},
                                                       "patch_fill": fill,
                                                       "diverged": bool(tr.state.get("diverged"))})
    for p in parts:
        ctx.metric("route_removed", p, "risk", immediate[p], h.structural_hash())
        ctx.metric("route_repaired", p, "risk", repaired[p], h.structural_hash())
    return {"removed": removed, "immediate": immediate, "repaired": repaired, "repair_updates": n_done,
            "repair_updates_requested": n_upd,
            "bits_per_example_before": bits_before, "bits_per_example_after": bits_before - bits_removed,
            "diverged": bool(tr.state.get("diverged"))}


@torch.no_grad()
def later_queries(ctx, g: GraphNet, bundle, peg_ids: list[str], stage: str = "later_queries",
                  checkpoint: str = "final") -> Optional[dict]:
    """Mechanism E: how much of the input survives at each peg for a predeclared family of
    later queries (bundle aux 'later': N x n bits).  Decoders are fitted on TRAINING codes
    only and evaluated on val / test:
      finite codes (peg.mode != none): a majority table per transmitted message (unseen
          messages get the training majority of that query);
      continuous codes: least squares with intercept, thresholded at 1/2.
    Input re-access control: the same least-squares decoder fitted on the raw input."""
    if "later" not in bundle.train.aux:
        return None
    if g.layout != "vec":
        raise Unsupported("later-query decoding is implemented for vector inputs")
    batch = ctx.cfg["train"]["eval_batch"]
    parts = {p: bundle.partitions()[p] for p in ("val", "test") if p in bundle.partitions()}
    tr = bundle.train
    Yt = tr.aux["later"].double().cpu()          # decoders are fitted and applied on CPU (V3-05)
    nq = Yt.shape[1]

    def lsq(Ztr, Zev):
        A = torch.cat([Ztr.double(), torch.ones(len(Ztr), 1, dtype=torch.float64, device=Ztr.device)], 1)
        sol = torch.linalg.lstsq(A.cpu(), Yt.cpu()).solution
        Ae = torch.cat([Zev.double(), torch.ones(len(Zev), 1, dtype=torch.float64, device=Zev.device)], 1)
        return (Ae.cpu() @ sol > 0.5).double()

    def acc(pred, Y):
        return (pred.cpu() == Y.double().cpu()).double().mean(0)
    out = {"queries": nq, "decoder_fit": "training partition", "pegs": {}, "checkpoint": checkpoint}
    maj = (Yt.mean(0) >= 0.5).double()
    out["chance"] = {p: acc(maj.expand(len(P), nq), P.aux["later"]).tolist() for p, P in parts.items()}
    out["input_reaccess"] = {p: acc(lsq(tr.X["x"], P.X["x"]), P.aux["later"]).tolist() for p, P in parts.items()}
    for pid in peg_ids:
        if pid not in g.implants:
            continue
        pm = g.implants[pid].meta["peg"]
        qmod = g.mods[g.nodes[pm["quant"]].pkey]
        node = pm["quant"] if qmod.mode == "none" else pm.get("code_in", pm["enc"])
        Ztr = _node_values(g, tr, [node], batch)[node]
        # the probe-fit budget: closed-form fits on every training example of the peg's value (no iterations)
        row = {"mode": qmod.mode, "fit_examples": int(Ztr.shape[0]), "code_dim": int(Ztr.reshape(len(Ztr), -1).shape[1])}
        if qmod.mode == "none":
            row["decoder"] = "least squares"
            for p, P in parts.items():
                Zev = _node_values(g, P, [node], batch)[node]
                row[p] = acc(lsq(Ztr, Zev), P.aux["later"]).tolist()
        else:
            row["decoder"] = "majority table per message"

            def msgs(Z):
                c = qmod.codes(Z)
                return c[:, None] if c.dim() == 1 else c
            Ctr = msgs(Ztr).cpu()
            keys, inv = torch.unique(Ctr, dim=0, return_inverse=True)
            cnt = torch.zeros(len(keys), dtype=torch.float64).index_add_(0, inv, torch.ones(len(inv), dtype=torch.float64))
            ones = torch.zeros(len(keys), nq, dtype=torch.float64).index_add_(0, inv, Yt.cpu())
            table = (ones / cnt[:, None] >= 0.5).double()
            lut = {tuple(k_.tolist()): i for i, k_ in enumerate(keys)}
            row["train_messages"] = int(len(keys))
            for p, P in parts.items():
                Cev = msgs(_node_values(g, P, [node], batch)[node]).cpu()
                idx = [lut.get(tuple(c.tolist()), -1) for c in Cev]
                pred = torch.stack([table[i] if i >= 0 else maj for i in idx])
                row[p] = acc(pred, P.aux["later"]).tolist()
                row[f"{p}_unseen_message_frac"] = float(sum(i < 0 for i in idx) / max(1, len(idx)))
        out["pegs"][pid] = row
        for p in parts:
            ctx.metric(stage, p, f"peg[{pid}].mean_acc", float(sum(row[p]) / nq), g.structural_hash())
    for p in parts:
        ctx.metric(stage, p, "input_reaccess.mean_acc", float(sum(out["input_reaccess"][p]) / nq),
                   g.structural_hash())
    return out


def adapter_accounting(ctx, g: GraphNet, peg_ids: list[str], T: int) -> dict:
    """Mechanism H, temp_target = adapter: the retained bridge is a continuous side channel of
    width temp_channel around its peg; its parameters and float bits per example are counted."""
    if ctx.cfg["peg"].get("temp_target", "all") != "adapter":
        return {}
    fb = int(ctx.cfg["peg"]["float_bits"])
    out = {}
    for pid in peg_ids:
        pm = g.implants[pid].meta["peg"] if pid in g.implants else None
        if not pm or pm["beta"] is None or g.gate_vals.get(pm["beta"], 0.0) == 0.0:
            continue
        width = g.node_dim(pm["temp"][0]) if pm["temp"] else int(ctx.cfg["peg"]["temp_channel"])
        params = sum(p.numel() for n in pm["temp"] for p in g.mods[g.nodes[n].pkey].parameters())
        positions = T if g.layout == "seq" else 1
        if g.layout == "img":
            hw = g.nodes[pm["temp"][0]].attrs.get("hw")
            positions = int(hw[0] * hw[1]) if hw else 1
        out[pid] = {"width": width, "params": int(params), "bits_per_example": width * fb * positions,
                    "positions": positions}
    return out


def decoder_refit(ctx, exp: GraphNet, bundle, updates: int) -> dict:
    """v13 (audit D3): freeze the code and refit only the decoder.  On a clone of the export, every tensor on the
    encoder side of the bottleneck peg (the peg's quantiser and its ancestors) is frozen; the rest trains on the
    task for `updates` updates with a fresh optimizer and its own named stream.  The code is unchanged (checked),
    so e_oracle is fixed; the change in e_model measures how much of the gap was decoder optimisation.  Counted as
    diagnostic work (it is not part of the chain)."""
    from .finite_interface import finite_interface_scores, bottleneck, _messages
    T_ = C.seq_T(bundle)
    h = exp.clone(share_params=False)
    bn = bottleneck(h, T_)
    before = finite_interface_scores(h, bundle, T_, ctx.cfg["train"]["eval_batch"])
    enc = h.ancestors(bn["quant"]) | {bn["quant"]}
    dec_pkeys = {h.nodes[n].pkey for n in h.live_nodes() if n not in enc and h.nodes[n].pkey is not None}
    X = bundle.extra["complete_domain"].X
    code0 = _messages(h, bn["quant"], X)
    tr = Trainer(h, bundle, ctx.cfg["train"], C.seeds(ctx.cfg), ctx.device, ctx.log, "decoder_refit")
    tr.configure("none", None, reset_state=True)
    tr.run(Segment("decoder_refit", updates, trainable=dec_pkeys))
    code1 = _messages(h, bn["quant"], X)
    after = finite_interface_scores(h, bundle, T_, ctx.cfg["train"]["eval_batch"])
    ctx.count_work("diagnostic:decoder_refit", updates=int(tr.state["global_step"]),
                   examples=int(tr.state["examples"]), seconds=tr.timing["train_seconds"],
                   macs=int(tr.state.get("train_macs", 0)))
    keys = ("e_model", "e_oracle", "e_star", "e_task_model", "e_task_oracle", "e_later_oracle")
    return {"updates": int(tr.state["global_step"]), "code_unchanged": bool(torch.equal(code0, code1)),
            "trainable_modules": sorted(dec_pkeys), "before": {k: before.get(k) for k in keys if k in before},
            "after": {k: after.get(k) for k in keys if k in after},
            "note": "decoder-only refit with the encoder frozen; e_oracle is the optimal decoder of the frozen code"}


def run_chain(ctx) -> dict:
    cfg = ctx.cfg
    cc = cfg["cop"]
    bundle = C.setup_data(ctx)
    f0, f0_tr = load_f0(ctx, bundle)
    res0, _ = C.eval_log(ctx, f0, bundle, "baseline")
    # The structure is rebuilt deterministically on every attempt and training goes
    # through the idempotent 'chain_train' stage, so a resumed job re-counts the
    # chain-training work and restores the exposure counters (no shortcut via 'final').
    g = f0.clone(share_params=False)
    pl = placement(ctx, g, bundle, cc["n_pearls"] - 1)
    g.meta["peg_indices"] = pl["indices"]
    ctx.save_json("placement.json", pl)
    if cc["branch_pegs"] != "none":
        peg_ids = branch_pegs(ctx, g, bundle)
    else:
        peg_ids = build_chain(ctx, g, bundle, pl["indices"])
    from .finite_interface import finite_interface_scores
    T_ = C.seq_T(bundle)
    has_bridge = any(g.implants[p].meta["peg"]["beta"] for p in peg_ids if p in g.implants)

    def phase_eval(model, seg_name):
        # bridge phases (v5): risk at the end of every segment (bridge open = before removal, temp-channel
        # anneal = immediately after, endpoint = after recovery) and the finite-interface score where it applies
        res_, _ = evaluate(model, bundle, ["val"], cfg["train"]["eval_batch"])
        rec = {"val_risk": float(M.headline(res_["val"], bundle.task))}
        fi_ = finite_interface_scores(model, bundle, T_, cfg["train"]["eval_batch"])
        if fi_ is not None:
            rec["finite_interface"] = {k: fi_.get(k) for k in ("applicable", "reason", "e_model", "e_oracle", "e_star",
                                                               "e_task_oracle", "e_later_oracle", "K_bits")}
        return rec
    total = int(cc["global_updates"])
    mac_match, mac_target = None, None
    if cc["global_match_macs_of"]:
        # v13 MAC-matched panel: deterministic at this point of every attempt (the structure and the work counted
        # before global training are rebuilt identically), so a resumed job plans the same number of updates
        from ..experiments.continuation import run_work
        from ..train.trainer import forward_macs
        ref = run_work(ctx.parent_dir(cc["global_match_macs_of"]))
        have = sum(int(w.get("macs", 0)) for ph, w in ctx.work.items() if not ph.startswith(("diagnostic:", "search:")))
        # the endpoint segment's length is set inside train_chain from the measured cost of the earlier
        # segments (anneal / bridge phases cost more per update); `total` only has to keep every earlier segment
        # at its declared length.  The trainer's effective batch is min(batch_size, n_train).
        per = 3 * forward_macs(g, T_, {}) * min(int(cfg["train"]["batch_size"]), len(bundle.train))
        est = max(0, int(math.ceil((int(ref["macs"]) - have) / max(1, per))))
        total = int(cc["global_updates"]) + est + 1
        mac_target = int(ref["macs"]) - have
        mac_match = {"reference_role": cc["global_match_macs_of"], "reference_macs": int(ref["macs"]),
                     "reference_macs_complete": bool(ref["macs_complete"]), "macs_before_global": have,
                     "macs_per_update": int(per), "declared_global_updates": int(cc["global_updates"])}
    Xsel = {k: v[:cfg["eval"]["calib_size"]] for k, v in bundle.val.X.items()}
    sel = C.Selector(ctx, bundle, "chain_endpoint",
                     compact_fn=lambda m: export_compact(m, Xsel, fold_linear=True)[0])
    tr = train_chain(ctx, g, bundle, peg_ids, total, ckpt_stage="chain_train",
                     phase_eval=phase_eval if has_bridge else None,
                     mac_target=mac_target if cc["global_match_macs_of"] else None, selector=sel)
    if tr.state.get("segment") == "endpoint":
        sel.ensure_final(g, int(tr.state["global_step"]), int(tr.state["seg_step"]), "chain_endpoint_final")
    if mac_match is not None:
        mac_match.update({"endpoint_plan": tr.mac_plan, "planned_global_updates": int(tr.state["global_step"]),
                          "macs_per_update": int((tr.mac_plan or {}).get("macs_per_endpoint_update", per))})
        ctx.save_json("mac_matching.json", mac_match)
    if has_bridge:
        ctx.save_json("bridge_phases.json", tr.phase_evals)
    ctx.updates = tr.state["global_step"]
    ctx.examples = tr.state["examples"]
    ctx.save_ckpt("final", g, tr, {"pegs": peg_ids})   # artifact read by P3 (alternatives)
    out = {"baseline": {p: M.headline(m, bundle.task) for p, m in res0.items()}}
    # metric stage 'chain_trained' (the trained chain before export); stage 'endpoint' is reserved for the
    # job's reloaded endpoint (record_endpoint), so no reader can confuse the two models
    out["endpoint"] = evaluate_chain(ctx, g, bundle, "chain_trained", peg_ids)
    if cc["peg_edit"] != "none":
        info, g2, ids2 = peg_edit(ctx, g, bundle, peg_ids, None)
        out["edit"] = info
        out["edit_export"] = export_and_verify(ctx, g2, bundle, "edit_export")[1]
    rd = route_damage(ctx, g, bundle, peg_ids)
    if rd:
        out["route_damage"] = rd
    rr = route_repair(ctx, g, bundle, peg_ids)
    if rr is not None:
        out["route_repair"] = rr
    lq = later_queries(ctx, g, bundle, peg_ids, checkpoint="final")
    if lq is not None:
        out["later_queries"] = lq
    exp, ex = export_and_verify(ctx, g, bundle, "export")
    has_q = any(exp.nodes[q].op == "quant" for q in exp.live_nodes())
    if has_q:
        from ..experiments.continuation import quantizer_audit, quant_recipe_name, gradient_audit
        out["quantizers_at_export"] = quantizer_audit(exp, bundle)
        out["gradients_at_export"] = gradient_audit(exp, bundle, ste_margin=cfg["train"].get("quant_ste_margin", 0.0))
        out["quant_recipe"] = {"recipe": quant_recipe_name(cfg["train"]),
                               "warmup_updates": int(cfg["train"].get("quant_warmup_updates", 0) or 0)}
    sel.record(bundle, bool(ctx.numerics["diverged"]), ctx.numerics["reason"], tr.state.get("diverged_at"))
    # v17: the treated chain's validation-selected checkpoint gets the same diagnostics as the scratch arms'
    if ctx.has_ckpt("best_val") and (has_q or lq is not None):
        from ..experiments.continuation import quantizer_audit, gradient_audit
        msel = GraphNet.from_checkpoint(ctx.load_ckpt("best_val")["model"], ctx.device)
        if any(msel.nodes[q].op == "quant" for q in msel.live_nodes()):
            out["quantizers_at_selected"] = quantizer_audit(msel, bundle)
            out["gradients_at_selected"] = gradient_audit(msel, bundle, ste_margin=cfg["train"].get("quant_ste_margin", 0.0))
        pids = [i for i, imp in msel.implants.items() if "peg" in (imp.meta or {})]
        if lq is not None:
            out["later_queries_selected"] = (later_queries(ctx, msel, bundle, pids, stage="later_queries_best_val",
                                                           checkpoint="best_val") if pids else
                                             {"checkpoint": "best_val", "unavailable":
                                              "the selected (exported) model keeps no peg implant records"})
    fi = finite_interface_scores(exp, bundle, C.seq_T(bundle), cfg["train"]["eval_batch"])
    if mac_match is not None:
        mac_match["achieved_macs_before_export"] = int(have_after := sum(
            int(w.get("macs", 0)) for ph, w in ctx.work.items() if not ph.startswith(("diagnostic:", "search:"))))
        mac_match["achieved_over_reference"] = have_after / max(1, mac_match["reference_macs"])
        out["mac_matching"] = mac_match
    if fi is not None and fi.get("applicable") and int(cc["decoder_refit_updates"]) > 0:
        out["decoder_refit"] = decoder_refit(ctx, exp, bundle, int(cc["decoder_refit_updates"]))
    if fi is not None:
        out["finite_interface"] = fi
        for k_ in ("e_model", "e_oracle", "e_star", "e_task_oracle", "e_later_oracle", "e_later_star_task_preserving"):
            if isinstance(fi.get(k_), int):
                ctx.metric("finite_interface", "complete_domain", k_, fi[k_], exp.structural_hash())
    if has_bridge:
        out["bridge_phases"] = tr.phase_evals
    ad = adapter_accounting(ctx, g, peg_ids, C.seq_T(bundle))
    if ad:
        ex["retained_adapters"] = ad
        ex["adapter_params"] = sum(v["params"] for v in ad.values())
        ex["adapter_bits_per_example"] = sum(v["bits_per_example"] for v in ad.values())
        ex["bits_per_example_with_adapters"] = ex["bits_per_example_total"] + ex["adapter_bits_per_example"]
        ctx.metric("export", "none", "bits_per_example_with_adapters", ex["bits_per_example_with_adapters"],
                   exp.structural_hash())
    out["export"] = ex
    ctx.save_json("cop_chain_result.json", out)
    return {"export_params": ex["params"], "bits_per_example": ex["bits_per_example_total"],
            "export_err": ex["export_max_abs_err_vs_endpoint"], "any_bypass": any(v.get("has_bypass")
                                                                             for v in ex["bypass"].values()),
            "test": ex["test"]}


def branch_pegs(ctx, g: GraphNet, bundle) -> list[str]:
    """Two parallel branches at the middle cut, with ONE shared peg before the
    group ('shared') or one peg on each branch input ('separate').  The group's
    skip path is a bypass by construction and is reported as such."""
    from ..experiments.growth import Grower
    kind = peg_cut_kind(g)
    cut = E.cut_at(g, kind, "middle")
    G = E.insert_group(g, cut, torch_gen(seed_of(ctx.cfg, "peg"), "peg", "bgroup"), merge="sum")
    bs = [E.add_branch(g, G, torch_gen(seed_of(ctx.cfg, "peg"), "peg", f"b{k}"), width=ctx.cfg["cop"]["pearl_width"])
          for k in range(2)]
    pc = ctx.cfg["peg"]
    ids = []
    if ctx.cfg["cop"]["branch_pegs"] == "shared":
        c = E.Cut(source=g.implants[G].entry)
        ids.append(insert_peg(g, c, torch_gen(seed_of(ctx.cfg, "peg"), "peg", "shared"), pc["dim"], pc["mode"],
                              pc["bits"], pc["codebook_size"], pc["n_messages"], pc["temp_channel"]))
    else:
        for k, b in enumerate(bs):
            a = next(n for n in g.implants[b].nodes if g.nodes[n].role == "A")
            c = E.Cut(source=g.nodes[a].inputs[0], consumers=[(a, 0)])
            ids.append(insert_peg(g, c, torch_gen(seed_of(ctx.cfg, "peg"), "peg", f"sep{k}"), pc["dim"], pc["mode"],
                                  pc["bits"], pc["codebook_size"], pc["n_messages"], pc["temp_channel"]))
    X = {kk: v[:ctx.cfg["eval"]["calib_size"]] for kk, v in bundle.train.X.items()}
    for j, pid in enumerate(ids):
        calibrate_peg(g, pid, X, torch_gen(seed_of(ctx.cfg, "peg"), "peg", f"bcal{j}"), pc["init"])
    return ids
