"""P5 expand-narrow-replace cycles and the section-10 baseline comparisons.

Cycle on pearl p (order: input_to_output | output_to_input | center_out | leaf_inward):
  grow     residual implants inside pearl p, trained globally (pegs frozen if
           cycle_pegs='fixed', trainable if 'relearned')
  fit peg  'relearned': narrow the adjacent peg (PCA on training data), re-fit
           all quantisers on training data
  replace  a small module fitted locally (training inputs) from the pearl's input
           (peg code, or full activation without pegs, plus any late input) to its
           output (peg pre-quantisation code / activation / model output), then
           swapped in with replace_segment (physical removal of the old pearl,
           including grown implants)
  scaffold export_compact; short global fine-tune
Recorded per cycle: params, MACs, risk, interface drift at every peg
(validation codes relative to the previous cycle).  Recorded per run: the
route, the MEASURED work by phase (updates, examples, forward examples for
code caches, seconds) and the final exported architecture.

Baselines (cop.task_kind='baseline', cop.baseline=...):
  direct_small        the ACTUAL exported endpoint architecture of the parent cycles run
                      (parents.cycles), every trainable tensor re-initialised and every
                      quantiser re-calibrated on training data of the re-initialised
                      network, trained from scratch on the task for the parent's measured
                      training updates + the baseline's updates (it has no pretrained parent)
  distill             the same architecture, re-initialised, distilled from f0 for the
                      parent's measured training updates
                      (both assert structural-hash and parameter equality with the parent's
                      endpoint before training and after export)
  direct_small_all_pearls  independent baseline: every pearl replaced by a fresh small module
                      (NOT the cycle endpoint; nominal exposure formula, labelled as such)
  replace_no_expand   BERT-of-Theseus adaptation: per-batch random replacement of
                      frozen pearls by successors (no pegs, no growth); then all successors
  progressive_no_peg  cycles without growth and without pegs
  peg_no_expand       cycles with pegs, no growth
  expand_no_peg       cycles with growth, no pegs
  expand_peg_replace  full cycles (this is also task_kind='cycles')
  shared_fold         pegs + ONE shared small module for all middle pearls, folded export
Equal updates are not equal FLOPs: work is reported per phase, including local
fits and the forward passes that build code caches.

Resume: the setup (chain training and export) and every finished cycle are
checkpointed with their bookkeeping; inside a cycle the grow training and the
fine-tune resume at update granularity and the local fit at step granularity,
so an interrupted job reproduces the uninterrupted one.
"""
from __future__ import annotations

import math
import time
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from ..config import seed_of
from ..graph import edits as E
from ..graph.accounting import report as acct
from ..graph.export import export_compact
from ..graph.graph import GraphNet
from ..graph.ops import init_module
from ..train import metrics as M
from ..train.trainer import Segment, Trainer, evaluate, predict, LocalOpt, local_policy, task_loss
from ..utils import torch_gen
from ..experiments import common as C
from ..experiments.context import Unsupported, ScientificInvalid, JobState, local_loop
from .chain import load_f0, placement, build_chain, train_chain, peg_cut_kind, export_and_verify, _restore_into
from .modules import make_alt, replace_segment, segment_between, external_inputs, node_values, SubgraphPearl
from .pegs import pegs as list_pegs, calibrate_peg


def cycle_order(n: int, kind: str) -> list[int]:
    if kind == "input_to_output":
        return list(range(n))
    if kind == "output_to_input":
        return list(range(n))[::-1]
    if kind == "center_out":
        c = (n - 1) // 2
        out = [c]
        for d in range(1, n):
            for j in (c - d, c + d):
                if 0 <= j < n and j not in out:
                    out.append(j)
        return out
    out, lo, hi = [], 0, n - 1
    while lo <= hi:
        out.append(lo)
        if hi != lo:
            out.append(hi)
        lo, hi = lo + 1, hi - 1
    return out


OUT = "__output__"


def boundaries(g: GraphNet, use_pegs: bool, idx: list[int]) -> list[list[str]]:
    """[in_node, out_node] per pearl, computed ONCE before any replacement and
    then maintained with update_bounds.  With pegs: pearl i maps code_{i-1}
    (quantiser output) to the next encoder output (or the model output);
    without pegs: activation at boundary i-1 to activation at boundary i.
    OUT stands for the current graph output."""
    x = g.inputs["x"]
    if use_pegs:
        ps = list_pegs(g)
        qs = [g.implants[p].meta["peg"]["quant"] for p in ps]
        es = [g.implants[p].meta["peg"]["enc"] for p in ps]
        ins = [x] + qs
        outs = es + [OUT]
    else:
        kind = peg_cut_kind(g)
        srcs = [E.resolve_edges(g, E.pick_cutpoint(g, kind, i)["edges"]).source for i in idx]
        ins = [x] + srcs
        outs = srcs + [OUT]
    return [list(t) for t in zip(ins, outs)]


def resolve_bound(g: GraphNet, b: list[str]) -> tuple[str, str]:
    return b[0], (g.output if b[1] == OUT else b[1])


def update_bounds(g: GraphNet, bnds: list[list[str]], p: int, old_out: str, rid: str) -> None:
    """After replacing pearl p (whose output node old_out became rid)."""
    if bnds[p][1] != OUT:
        bnds[p][1] = rid
    for q in range(len(bnds)):
        if bnds[q][0] == old_out:
            bnds[q][0] = rid
    for pid in list_pegs(g):
        pm = g.implants[pid].meta["peg"]
        if pm["enc"] == old_out:
            pm["enc"] = rid


def _small_module(g: GraphNet, in_dim: int, out_dim: int, width: int, in_node: str, out_node: str, gen):
    lay = g.layout
    pool = 1
    if lay == "img":
        hi = g.nodes[in_node].attrs.get("hw", [1, 1])[0]
        ho = g.nodes[out_node].attrs.get("hw", [1, 1])[0]
        pool = max(1, hi // max(1, ho))
        if g.nodes[out_node].attrs.get("layout") == "vec":
            from .modules import ConvHead
            m = ConvHead(in_dim, width, out_dim, int(hi) * int(hi))
            init_module(m, gen, "default")
            return m, {"module_type": "convhead", "module_args": {"c_in": in_dim, "width": width, "n_out": out_dim,
                                                                  "hw_hint": int(hi) * int(hi)}}
    m, attrs = make_alt("mlp_small", lay if g.nodes[out_node].attrs.get("layout", lay) == lay else "vec",
                        in_dim, out_dim, width * 4 if lay != "img" else width * 4, pool)
    init_module(m, gen, "default")
    return m, attrs


def fit_replacement(ctx, js: JobState, g: GraphNet, bundle, in_node: str, out_node: str, width: int, n: int,
                    key: str, module: Optional[nn.Module] = None):
    """Local distillation: module(concat(external inputs)) ~= value(out_node) on
    TRAINING inputs, with the train section's optimizer policy; resumable."""
    seg = segment_between(g, in_node, out_node)
    ins = external_inputs(g, seg, in_node)
    if g.layout == "seq" and any(g.nodes[i].op == "input" for i in ins):
        raise Unsupported("a sequence pearl reading raw tokens needs an embedding pearl; replace middle pearls only")
    t0 = time.time()
    vals = node_values(g, bundle.train.X, ins + [out_node])
    ctx.count_work("code_cache_forward", forward_examples=len(bundle.train), seconds=time.time() - t0)
    Xin = torch.cat([vals[i].to(torch.float32) for i in ins], dim=1 if g.layout in ("vec", "img") else -1)
    Y = vals[out_node]
    gen = torch_gen(seed_of(ctx.cfg, "peg"), "peg", f"replace/{key}")
    if module is None:
        module, attrs = _small_module(g, Xin.shape[1] if g.layout != "seq" else Xin.shape[-1],
                                      Y.shape[1] if g.layout != "seq" else Y.shape[-1], width, in_node, out_node, gen)
    else:
        attrs = None
    module.to(ctx.device)
    N = Xin.shape[0]
    B = min(ctx.cfg["train"]["batch_size"], N)
    lopt = LocalOpt(list(module.parameters()), ctx.cfg["train"], n)

    def step(k):
        idx = torch.randint(0, N, (B,), generator=gen).to(ctx.device)
        return F.mse_loss(module(Xin[idx]), Y[idx])
    info = local_loop(ctx, js, f"replace/{key}", {"m": module}, lopt, gen, n, step, phase="replacement_local_fit",
                      examples_per_step=B)
    with torch.no_grad():
        err = float(F.mse_loss(module(Xin[:4096]), Y[:4096]) / Y[:4096].var().clamp_min(1e-12))
    return module, attrs, {"train_local_rel_mse": err, "inputs": ins, "updates": info["updates"]}


def _peg_pkeys(g: GraphNet) -> set[str]:
    """Parameters of the peg maps themselves (encoder, decoder, narrowing
    projections, codebooks): nodes OWNED by the peg.  After a pearl replacement
    absorbs an encoder, that replacement is a pearl and stays trainable."""
    out = set()
    for p in list_pegs(g):
        for n in g.nodes.values():
            if n.owner == p and n.pkey:
                out.add(n.pkey)
    return out


def _train(ctx, g, bundle, n, freeze_pkeys=frozenset(), key="cyc", target="task", teacher=None,
           ckpt_stage: Optional[str] = None, phase: str = "global_train", on_step=None):
    """Global training of the live graph; resumable when ckpt_stage is given
    (the graph structure at call time must equal the checkpointed one)."""
    if n <= 0:
        return None
    tr = Trainer(g, bundle, ctx.cfg["train"], C.seeds(ctx.cfg), ctx.device, ctx.log, key)
    tr.policy_extra_frozen = set(freeze_pkeys)
    if ckpt_stage and ctx.has_ckpt(f"{ckpt_stage}_partial"):
        ck = ctx.load_ckpt(f"{ckpt_stage}_partial")
        _restore_into(g, ck["model"])
        tr.load_state_dict(ck["trainer"])
        ctx.log({"event": "resume", "stage": ckpt_stage, "seg_step": tr.state["seg_step"]})
    else:
        tr.configure("none", None, reset_state=True)
    cb = (lambda: ctx.save_ckpt(f"{ckpt_stage}_partial", g, tr)) if ckpt_stage else None
    tr.run(Segment(key, n, target=target, teacher=teacher, on_step=on_step), checkpoint_cb=cb)
    ctx.note_trainer(tr, phase)
    n_done = int(tr.state["global_step"])               # actual updates (fewer than n after divergence)
    ctx.count_work(phase, updates=n_done, examples=n_done * tr.B, seconds=tr.timing["train_seconds"],
                   macs=int(tr.state.get("train_macs", 0)), macs_bwd=int(tr.state.get("train_macs_bwd", 0)), teacher_macs=int(tr.state.get("teacher_macs", 0)))
    if ckpt_stage:
        ctx.ckpt_path(f"{ckpt_stage}_partial").unlink(missing_ok=True)
    return tr


@torch.no_grad()
def peg_codes(g: GraphNet, X: dict) -> dict:
    qs = [g.implants[p].meta["peg"]["quant"] for p in list_pegs(g) if g.implants[p].meta["peg"]["quant"] in g.nodes]
    return node_values(g, X, qs) if qs else {}


def _work_total(work: dict) -> dict:
    tot = {"updates": 0, "examples": 0, "forward_examples": 0, "seconds": 0.0, "macs": 0, "teacher_macs": 0}
    for w in work.values():
        for k in tot:
            tot[k] += w.get(k, 0)
    return tot


def _cycle_meta(bnds, replaced, created, log, ctx) -> dict:
    return {"bnds": [list(b) for b in bnds], "replaced": sorted(replaced), "created": created, "log": log,
            "work": {k: dict(v) for k, v in ctx.work.items()}}


def run_cycles(ctx, variant: Optional[str] = None) -> dict:
    cfg = ctx.cfg
    cc = cfg["cop"]
    variant = variant or "expand_peg_replace"
    bundle = C.setup_data(ctx)
    f0, _ = load_f0(ctx, bundle)
    grow = variant in ("expand_peg_replace", "expand_no_peg")
    pegs_mode = "none" if variant in ("expand_no_peg", "progressive_no_peg") else cc["cycle_pegs"]
    if variant == "peg_no_expand":
        grow = False
    use_pegs = pegs_mode != "none"
    # V3-07: three independent switches (the presets fixed / relearned set all three together)
    preset = {"fixed": ("frozen", "constant", "no"), "relearned": ("learned", "narrowed", "yes")}.get(pegs_mode,
                                                                                                  ("-", "-", "-"))
    peg_maps = cc.get("cycle_peg_maps", "auto") if cc.get("cycle_peg_maps", "auto") != "auto" else preset[0]
    peg_width = cc.get("cycle_peg_width", "auto") if cc.get("cycle_peg_width", "auto") != "auto" else preset[1]
    peg_recal = cc.get("cycle_peg_recalibrate", "auto") if cc.get("cycle_peg_recalibrate", "auto") != "auto" \
        else preset[2]
    js = JobState(ctx, "cyc")
    n = cc["n_pearls"]
    order = cycle_order(n, cc["cycle_order"])
    route = [order[c % n] for c in range(cc["cycles"])]
    if f0.layout == "seq":
        route = [p for p in route if p != 0] or [1]
    Xv = {k: v[:cfg["eval"]["calib_size"]] for k, v in bundle.val.X.items()}
    done = [c for c in range(len(route)) if ctx.has_ckpt(f"cyc{c}_done")]
    start = (max(done) + 1) if done else 0
    if done:
        ck = ctx.load_ckpt(f"cyc{max(done)}_done")
        g = GraphNet.from_checkpoint(ck["model"], ctx.device)
        meta = ck["extra"]
        idx = meta["idx"]
    elif ctx.has_ckpt("cyc_setup"):
        ck = ctx.load_ckpt("cyc_setup")
        g = GraphNet.from_checkpoint(ck["model"], ctx.device)
        meta = ck["extra"]
        idx = meta["idx"]
    else:
        g = f0.clone(share_params=False)
        pl = placement(ctx, g, bundle, n - 1)
        idx = pl["indices"]
        if use_pegs:
            ids = build_chain(ctx, g, bundle, idx)
            train_chain(ctx, g, bundle, ids, cc["global_updates"], ckpt_stage="cycles_chain_train")
            g, _ = export_compact(g, fold_linear=False)       # bypass edges physically removed before replacement
        meta = {**_cycle_meta(boundaries(g, use_pegs, idx), set(), {}, [], ctx), "idx": idx}
        ctx.save_ckpt("cyc_setup", g, None, meta)
    ctx.work = {k: dict(v) for k, v in meta["work"].items()}
    ctx.updates = _work_total(ctx.work)["updates"]        # exposure restored on any resume point
    ctx.examples = _work_total(ctx.work)["examples"]
    bnds = [list(b) for b in meta["bnds"]]
    replaced = set(meta["replaced"])
    created = dict(meta["created"])
    log = list(meta["log"])
    for c in range(start, len(route)):
        p = route[c]
        prev_codes = peg_codes(g, Xv)
        prev_test = predict(g, bundle.partitions()["test"], cfg["train"]["eval_batch"])     # for the per-cycle prediction change
        if ctx.has_ckpt(f"cyc{c}_grown"):
            ck = ctx.load_ckpt(f"cyc{c}_grown")
            g = GraphNet.from_checkpoint(ck["model"], ctx.device)
            bnds = [list(b) for b in ck["extra"]["bnds"]]
            rec = dict(ck["extra"]["rec"])
            ctx.work = {k: dict(v) for k, v in ck["extra"]["work"].items()}
        else:
            rec = {"cycle": c, "pearl": p}
            in_node, out_node = resolve_bound(g, bnds[p])
            if grow:
                seg = segment_between(g, in_node, out_node) - {out_node}
                kind = peg_cut_kind(g)
                cands = []
                for cp in E.cutpoints(g, kind):
                    try:
                        if E.resolve_edges(g, cp["edges"]).source in seg:
                            cands.append(cp)
                    except Exception:
                        continue
                if p not in replaced and cands:
                    cut = E.resolve_edges(g, cands[len(cands) // 2]["edges"])
                    iid = E.insert_residual_zero(g, cut, torch_gen(seed_of(cfg, "insertion"), "insertion", f"cyc{c}"),
                                                 width=cc["grow_width"], slot=f"cycle{c}/grow")
                    rec["grown_implant"] = iid
                elif p in replaced:
                    # reopen a replaced pearl: a residual implant on the replacement's output (node cut);
                    # the pearl boundary moves to the implant exit so the next replacement absorbs it
                    iid = E.insert_residual_zero(g, E.Cut(source=out_node), torch_gen(seed_of(cfg, "insertion"),
                                                 "insertion", f"cyc{c}"), width=cc["grow_width"], slot=f"cycle{c}/reopen")
                    update_bounds(g, bnds, p, out_node, g.implants[iid].exit)
                    rec["grown_implant"] = iid
                frz = _peg_pkeys(g) if peg_maps == "frozen" else set()
                _train(ctx, g, bundle, cc["local_updates"], frz, key=f"grow{c}", ckpt_stage=f"cyc{c}_grow",
                       phase="grow_train")
            ctx.save_ckpt(f"cyc{c}_grown", g, None, {"bnds": bnds, "rec": rec,
                                                      "work": {k: dict(v) for k, v in ctx.work.items()}})
        if use_pegs and (peg_width == "narrowed" or peg_recal == "yes"):
            X = {k: v[:cfg["eval"]["calib_size"]] for k, v in bundle.train.X.items()}
            # narrow the peg at this pearl's output by half (training data), then re-fit all pegs
            ps = list_pegs(g)
            if peg_width == "narrowed" and p < len(ps):
                from .pegs import narrow_peg
                pid = ps[p]
                k_old = g.node_dim(g.implants[pid].meta["peg"]["quant"])
                info_n = narrow_peg(g, pid, max(1, k_old // 2), X, torch_gen(seed_of(cfg, "peg"), "peg", f"narrow{c}"))
                if info_n.get("narrowed"):
                    for b in bnds:
                        if b[0] == info_n["old_quant"]:
                            b[0] = info_n["new_quant"]
                rec["narrowing"] = {k: v for k, v in info_n.items() if k in ("narrowed", "from", "to", "explained")}
            for j, pid in enumerate(list_pegs(g) if peg_recal == "yes" else []):
                if g.implants[pid].meta["peg"]["quant"] in g.nodes:
                    qn = g.implants[pid].meta["peg"]["quant"]
                    q = g.mods[g.nodes[qn].pkey]
                    zin = g.nodes[qn].inputs[0]          # whatever currently feeds the quantiser
                    with torch.no_grad():
                        _, vals = g(X, return_nodes=[zin])
                    z = vals[zin]
                    q.calibrate(z.reshape(-1, q.k) if g.layout != "img" else z.permute(0, 2, 3, 1).reshape(-1, q.k),
                                gen=torch_gen(seed_of(cfg, "peg"), "peg", f"recal{c}{j}"))
            ctx.count_work("peg_refit_forward", forward_examples=2 * len(next(iter(X.values()))))
        in_node, out_node = resolve_bound(g, bnds[p])
        mod, attrs, info = fit_replacement(ctx, js, g, bundle, in_node, out_node, cc["replace_width"],
                                           cc["local_updates"], f"c{c}p{p}")
        out_dim = g.node_dim(out_node)
        rid = replace_segment(g, in_node, out_node, mod, attrs, out_dim, owner_tag=f"replacement_c{c}_p{p}")
        update_bounds(g, bnds, p, out_node, rid)
        created[rid] = {k: v.detach().cpu().clone() for k, v in g.mods[g.nodes[rid].pkey].state_dict().items()}
        replaced.add(p)
        rec.update(info)
        g, _ = export_compact(g, fold_linear=False)
        # immediate effect of the replacement, before the global fine-tune
        pre, _ = evaluate(g, bundle, ["val", "test"], cfg["train"]["eval_batch"])
        rec["pre_finetune_val_risk"] = M.headline(pre["val"], bundle.task)
        rec["pre_finetune_test_risk"] = M.headline(pre["test"], bundle.task)
        frz = _peg_pkeys(g) if peg_maps == "frozen" else set()
        n_ft = max(1, cc["global_updates"] // max(1, cc["cycles"]))
        _train(ctx, g, bundle, n_ft, frz, key=f"ft{c}", ckpt_stage=f"cyc{c}_ft", phase="finetune")
        res, _ = evaluate(g, bundle, ["val", "test"], cfg["train"]["eval_batch"])
        a = acct(g, C.seq_T(bundle))
        cur_codes = peg_codes(g, Xv)
        drift = {k: float(((cur_codes[k] - prev_codes[k]) ** 2).mean() / prev_codes[k].var().clamp_min(1e-12))
                 for k in cur_codes if k in prev_codes}
        now_test = predict(g, bundle.partitions()["test"], cfg["train"]["eval_batch"])
        if bundle.task == "classification":
            rec["test_prediction_flip_rate_vs_prev_cycle"] = float((now_test.argmax(-1) != prev_test.argmax(-1))
                                                                   .double().mean())
        else:
            rec["test_prediction_change_nmse_vs_prev_cycle"] = float(((now_test - prev_test) ** 2).mean() /
                                                                     prev_test.var().clamp_min(1e-12))
        qn = [n for n in g.topo_order(g.live_nodes()) if g.nodes[n].op == "quant"]
        rec["peg_dims"] = [int(g.mods[g.nodes[n].pkey].k) for n in qn]
        rec["peg_bits_per_example"] = [int(m_["bits_per_example"]) for m_ in a["messages"]]
        rec.update({"val_risk": M.headline(res["val"], bundle.task), "test_risk": M.headline(res["test"], bundle.task),
                    "params": a["params"], "macs": a["macs"], "interface_drift": drift,
                    "work_so_far": _work_total(ctx.work)})
        ctx.updates = _work_total(ctx.work)["updates"]
        ctx.examples = _work_total(ctx.work)["examples"]
        ctx.metrics(f"cycle_{c}", "val", {k: v for k, v in rec.items() if isinstance(v, (int, float))})
        log.append(rec)
        ctx.save_ckpt(f"cyc{c}_done", g, None, {**_cycle_meta(bnds, replaced, created, log, ctx), "idx": idx})
        for st in (f"cyc{c}_grown",):
            ctx.ckpt_path(st).unlink(missing_ok=True)
    swap = swappability(g, bundle, created, cfg["train"]["eval_batch"])
    exp, ex = export_and_verify(ctx, g, bundle, "export")
    work = {k: dict(v) for k, v in ctx.work.items()}
    out = {"variant": variant, "pegs": pegs_mode, "peg_maps": peg_maps, "peg_width": peg_width,
           "peg_recalibrate": peg_recal, "grow": grow, "route": route, "order": cc["cycle_order"],
           "swappability": swap, "cycles": log, "export": ex,
           "export_structural_hash": exp.structural_hash(),
           "work": work, "work_total": _work_total(work),
           "exposure_updates": _work_total(work)["updates"],
           "exposure_note": "measured training updates over all phases (chain training, growth, local fits, "
                            "fine-tunes); forward_examples counts code-cache passes; equal updates are not equal FLOPs",
           "local_train_policy": local_policy(cfg["train"]),
           "f0_params": acct(f0, C.seq_T(bundle))["params"]}
    ctx.save_json("cycles_result.json", out)
    return {"variant": variant, "export_params": ex["params"], "test": ex["test"],
            "exposure_updates": out["exposure_updates"]}


@torch.no_grad()
def swappability(g: GraphNet, bundle, created: dict, batch: int) -> dict:
    """Does a replacement still fit after later cycles changed its neighbours?
    Each surviving replacement module is temporarily reset to its weights at
    creation; the change in test risk is recorded (0 = still swappable)."""
    base = M.headline(evaluate(g, bundle, ["test"], batch)[0]["test"], bundle.task)
    out = {}
    for rid, sd in created.items():
        if rid not in g.nodes or g.nodes[rid].pkey is None or rid not in g.live_nodes():
            continue
        mod = g.mods[g.nodes[rid].pkey]
        cur = {k: v.detach().clone() for k, v in mod.state_dict().items()}
        mod.load_state_dict(sd)
        r = M.headline(evaluate(g, bundle, ["test"], batch)[0]["test"], bundle.task)
        mod.load_state_dict(cur)
        out[rid] = {"test_risk_with_creation_weights": r, "test_risk_current": base, "delta": r - base}
    return out


# =============================================================================
# Baselines
# =============================================================================

@torch.no_grad()
def recalibrate_quantizers(ctx, g: GraphNet, bundle, key: str) -> list[dict]:
    """Re-fit every quantiser's clipping range / codebook on TRAINING
    calibration activations of THIS network, upstream first."""
    X = {k: v[:ctx.cfg["eval"]["calib_size"]] for k, v in bundle.train.X.items()}
    out = []
    g.eval()
    for j, nid in enumerate([n for n in g.topo_order() if g.nodes[n].op == "quant"]):
        q = g.mods[g.nodes[nid].pkey]
        zin = g.nodes[nid].inputs[0]
        _, v = g(X, return_nodes=[zin])
        z = v[zin]
        q.calibrate(z.permute(0, 2, 3, 1).reshape(-1, q.k) if z.dim() == 4 else z.reshape(-1, q.k),
                    gen=torch_gen(seed_of(ctx.cfg, "init"), "init", f"{key}/recal{j}"))
        out.append({"node": nid, "mode": q.mode})
    return out


def matched_endpoint(ctx, bundle) -> tuple[GraphNet, dict]:
    """The parent cycles run's exported endpoint, every trainable tensor
    re-initialised (named init stream) and every quantiser re-calibrated on the
    re-initialised network's training activations: same topology, sharing,
    dimensions, quantisers, retained original pearls and late-input paths;
    no trained information carried over.  Equality of architecture and
    parameter accounting is asserted."""
    ck = ctx.parent_ckpt("cycles", "export")
    g = GraphNet.from_checkpoint(ck["model"], ctx.device)
    T = C.seq_T(bundle)
    h0, a0 = g.structural_hash(), acct(g, T)
    before = {k: v.detach().clone() for k, v in g.state_dict().items()}
    C.reinit_all(g, torch_gen(seed_of(ctx.cfg, "init"), "init", "matched_control"))
    for m in g.mods.values():               # tables are not covered by the generic initialiser
        for mm in m.modules():
            if hasattr(mm, "table") and isinstance(getattr(mm, "table"), nn.Parameter):
                with torch.no_grad():
                    mm.table.zero_()
    recal = recalibrate_quantizers(ctx, g, bundle, "matched_control")
    carried = [k for k, v in g.state_dict().items() if v.is_floating_point() and v.numel() > 1 and
               torch.equal(v, before[k]) and not k.endswith(("running_mean", "running_var"))]
    h1, a1 = g.structural_hash(), acct(g, T)
    if h1 != h0 or a1["params"] != a0["params"] or a1["macs"] != a0["macs"]:
        raise ScientificInvalid("matched control architecture differs from the parent endpoint",
                                {"parent_hash": h0, "control_hash": h1, "parent_params": a0["params"],
                                 "control_params": a1["params"]})
    info = {"parent_cycles_run": ctx.cfg["parents"]["cycles"], "endpoint_structural_hash": h0,
            "params": a0["params"], "macs": a0["macs"], "quantizers_recalibrated": recal,
            "tensors_equal_to_parent_after_reinit": carried,
            "init": "named init stream 'matched_control'; tables zeroed; quantiser ranges / codebooks re-fitted on "
                    "training calibration activations of the re-initialised network"}
    if carried:
        info["warning"] = "some tensors still equal the parent's after re-initialisation (see list)"
    return g, info


def small_architecture(ctx, bundle, f0: GraphNet, use_pegs: bool, shared: bool = False):
    """Independent baseline: pegs (optional) + every pearl replaced by a fresh
    small module, freshly initialised.  This is NOT the endpoint of a cycle
    history (cycles may replace only some pearls, narrow pegs, or skip the
    embedding pearl); matched comparisons use matched_endpoint instead."""
    cc = ctx.cfg["cop"]
    g = f0.clone(share_params=False)
    pl = placement(ctx, g, bundle, cc["n_pearls"] - 1)
    idx = pl["indices"]
    if use_pegs:
        build_chain(ctx, g, bundle, idx)
        for p in list_pegs(g):
            g.gate_vals[g.implants[p].meta["peg"]["alpha"]] = 0.0
        g, _ = export_compact(g, fold_linear=False)
    n = cc["n_pearls"]
    bnds = boundaries(g, use_pegs, idx)
    for p in range(n):
        if g.layout == "seq" and p == 0:
            continue
        in_node, out_node = resolve_bound(g, bnds[p])
        seg = segment_between(g, in_node, out_node)
        ins = external_inputs(g, seg, in_node)
        d_in = sum(g.node_dim(i) for i in ins)
        gen = torch_gen(seed_of(ctx.cfg, "init"), "init", f"small{p}")
        mod, attrs = _small_module(g, d_in, g.node_dim(out_node), cc["replace_width"], in_node, out_node, gen)
        rid = replace_segment(g, in_node, out_node, mod, attrs, g.node_dim(out_node), owner_tag=f"small_p{p}")
        update_bounds(g, bnds, p, out_node, rid)
    C.reinit_all(g, torch_gen(seed_of(ctx.cfg, "init"), "init", "small_arch"))
    recalibrate_quantizers(ctx, g, bundle, "small_arch")
    return g, idx


def nominal_exposure(cc: dict) -> int:
    """Nominal update count of a full cycle history (used ONLY for the
    independent direct_small_all_pearls baseline, which has no parent)."""
    per_cycle = cc["local_updates"] * 2 + max(1, cc["global_updates"] // max(1, cc["cycles"]))
    return cc["global_updates"] + cc["cycles"] * per_cycle


def run_baseline_cop(ctx) -> dict:
    cfg = ctx.cfg
    cc = cfg["cop"]
    b = cc["baseline"]
    if b in ("expand_peg_replace", "peg_no_expand", "expand_no_peg", "progressive_no_peg"):
        return run_cycles(ctx, b)
    bundle = C.setup_data(ctx)
    f0, _ = load_f0(ctx, bundle)
    info: dict = {}
    if b in ("direct_small", "distill"):
        g, info = matched_endpoint(ctx, bundle)
        parent = ctx.parent_json("cycles", "cycles_result.json")
        n_parent = int(parent["work_total"]["updates"])
        n_upd = n_parent + (cfg["train"]["baseline_updates"] if b == "direct_small" else 0)
        # the parent's quantisers were fitted on trained activations (and re-fitted every cycle when
        # relearned); the control's are re-fitted on its OWN training activations at the parent's
        # K = cycles evenly spaced points of one continuous run (optimizer and schedule not reset)
        K = max(1, int(cc["cycles"]))
        pts = sorted({int(round(n_upd * j / K)) for j in range(1, K)} - {0, n_upd})

        def recal(trn, k):
            if k in pts:
                recalibrate_quantizers(ctx, g, bundle, f"{b}_recal@{k}")
                g.train()
        _train(ctx, g, bundle, n_upd, key=b, target="task" if b == "direct_small" else "original",
               teacher=None if b == "direct_small" else f0, ckpt_stage=f"{b}_train", phase="control_train",
               on_step=recal)
        n_q = sum(1 for n_ in g.live_nodes() if g.nodes[n_].op == "quant")
        if pts and n_q:
            ctx.count_work("control_recalibration_forward",
                           forward_examples=len(pts) * n_q * min(cfg["eval"]["calib_size"], len(bundle.train)))
        info["quantizer_recalibration_at_updates"] = pts
        exposure = n_upd
        info.update({"parent_work_total": parent["work_total"], "parent_export_params": parent["export"]["params"],
                     "exposure_basis": "parent's measured training updates" +
                     (" + baseline_updates (no pretrained parent)" if b == "direct_small" else "")})
    elif b == "direct_small_all_pearls":
        g, _ = small_architecture(ctx, bundle, f0, use_pegs=True)
        n_upd = nominal_exposure(cc) + cfg["train"]["baseline_updates"]
        _train(ctx, g, bundle, n_upd, key=b, ckpt_stage=f"{b}_train", phase="control_train")
        exposure = n_upd
        info["exposure_basis"] = "nominal formula (independent baseline, no parent history)"
    elif b == "replace_no_expand":
        g, exposure = theseus(ctx, bundle, f0, nominal_exposure(cc))
        info["exposure_basis"] = "nominal formula"
    elif b == "shared_fold":
        g, exposure = shared_fold(ctx, bundle, f0)
        info["exposure_basis"] = "measured updates of this job"
    else:
        raise Unsupported(b)
    exp, ex = export_and_verify(ctx, g, bundle, "export")
    if b in ("direct_small", "distill"):
        if exp.structural_hash() != ctx.parent_json("cycles", "cycles_result.json").get("export_structural_hash") or \
                ex["params"] != info["parent_export_params"]:
            raise ScientificInvalid("exported matched control differs from the parent's exported endpoint",
                                    {"control_params": ex["params"], "parent_params": info["parent_export_params"]})
        info["architecture_equal_to_parent_endpoint"] = True
    work = {k: dict(v) for k, v in ctx.work.items()}
    out = {"baseline": b, "export": ex, "exposure_updates": exposure, "work": work, "work_total": _work_total(work),
           "control": info, "export_structural_hash": exp.structural_hash(),
           "local_train_policy": local_policy(cfg["train"])}
    ctx.save_json("baseline_result.json", out)
    return {"baseline": b, "export_params": ex["params"], "test": ex["test"], "exposure_updates": exposure}


class _Theseus(nn.Module):
    def __init__(self, g, bnds, succ, p_replace=0.5):
        super().__init__()
        self.g, self.bnds = g, bnds
        self.succ = nn.ModuleList(succ)
        self.pearls = [SubgraphPearl(g, a, b) for a, b in bnds]
        self.p = p_replace
        self.mask = None
        self.ins = [external_inputs(g, pl.seg, pl.in_node) for pl in self.pearls]

    def forward(self, X, ctx=None):
        h = X["x"]
        m = self.mask if self.mask is not None else [True] * len(self.pearls)
        for i, (pearl, s) in enumerate(zip(self.pearls, self.succ)):
            extra = [X[self.g.nodes[k].attrs["stream"]] for k in self.ins[i][1:] if self.g.nodes[k].op == "input"]
            if m[i]:
                h = s(torch.cat([h] + extra, dim=1) if extra else h)
            else:
                h = pearl(h, X)
        return h


def theseus(ctx, bundle, f0: GraphNet, n_upd: int):
    """BERT-of-Theseus adaptation (labelled as an adaptation): frozen
    predecessors, successors chosen per minibatch with probability 0.5, task loss;
    then all successors, then the successors are written into the graph."""
    if f0.layout != "vec":
        raise Unsupported("Theseus baseline implemented for vector models")
    cc = ctx.cfg["cop"]
    g = f0.clone(share_params=False).eval()
    for p in g.parameters():
        p.requires_grad_(False)
    idx = placement(ctx, g, bundle, cc["n_pearls"] - 1)["indices"]
    bnds = [resolve_bound(g, b) for b in boundaries(g, False, idx)]
    succ = []
    for i, (a, b) in enumerate(bnds):
        seg = segment_between(g, a, b)
        ins = external_inputs(g, seg, a)
        d_in = sum(g.node_dim(k) for k in ins)
        m, attrs = _small_module(g, d_in, g.node_dim(b), cc["replace_width"], a, b,
                                 torch_gen(seed_of(ctx.cfg, "init"), "init", f"succ{i}"))
        succ.append(m.to(ctx.device))
    gen = torch_gen(seed_of(ctx.cfg, "assembly"), "assembly", "theseus")
    model = _Theseus(g, bnds, succ)
    lopt = LocalOpt([p for s in succ for p in s.parameters()], ctx.cfg["train"], n_upd)
    N = len(bundle.train)
    B = min(ctx.cfg["train"]["batch_size"], N)
    js = JobState(ctx, "theseus")

    def step(t):
        idxb = torch.randint(0, N, (B,), generator=gen).to(ctx.device)
        if t < n_upd * 3 // 4:
            mask = (torch.rand(len(succ), generator=gen) < 0.5).tolist()
            if not any(mask):   # at least one successor per step (otherwise nothing is trainable)
                mask[int(torch.randint(0, len(succ), (1,), generator=gen))] = True
        else:
            mask = [True] * len(succ)
        model.mask = mask
        X = {k: v[idxb] for k, v in bundle.train.X.items()}
        return task_loss(model(X), bundle.train.y[idxb], bundle.task)
    local_loop(ctx, js, "theseus", {f"s{i}": s for i, s in enumerate(succ)}, lopt, gen, n_upd, step,
               phase="theseus_train", examples_per_step=B)
    h = f0.clone(share_params=False)
    bnds = boundaries(h, False, idx)
    for j in range(len(bnds)):
        a2, b2 = resolve_bound(h, bnds[j])
        seg = segment_between(h, a2, b2)
        ins = external_inputs(h, seg, a2)
        attrs = {"module_type": "mlp", "module_args": {"d_in": sum(h.node_dim(k) for k in ins),
                 "hidden": [succ[j].layers[0].out_features], "d_out": h.node_dim(b2), "act": "relu", "layout": "vec"}}
        rid = replace_segment(h, a2, b2, succ[j], attrs, h.node_dim(b2), owner_tag=f"theseus_p{j}")
        update_bounds(h, bnds, j, b2, rid)
    return h, n_upd


def shared_fold(ctx, bundle, f0: GraphNet):
    """Pegs of equal width + one SHARED small module replacing every middle pearl
    (fitted on the union of their code pairs), then folded export."""
    cc = ctx.cfg["cop"]
    g = f0.clone(share_params=False)
    idx = placement(ctx, g, bundle, cc["n_pearls"] - 1)["indices"]
    ids = build_chain(ctx, g, bundle, idx)
    train_chain(ctx, g, bundle, ids, cc["global_updates"], ckpt_stage="shared_fold_chain_train")
    g, _ = export_compact(g, fold_linear=False)
    bnds = boundaries(g, True, idx)
    middle = list(range(1, len(bnds) - 1))
    if not middle:
        raise Unsupported("shared_fold needs at least one middle pearl (n_pearls >= 3)")
    Xs, Ys = [], []
    for p in middle:
        a, b = resolve_bound(g, bnds[p])
        seg = segment_between(g, a, b)
        if len(external_inputs(g, seg, a)) > 1:
            raise Unsupported("shared module cannot take late inputs")
        v = node_values(g, bundle.train.X, [a, b])
        Xs.append(v[a])
        Ys.append(v[b])
    ctx.count_work("code_cache_forward", forward_examples=len(middle) * len(bundle.train))
    k_in, k_out = Xs[0].shape[-1], Ys[0].shape[-1]
    if any(x.shape[-1] != k_in for x in Xs) or any(y.shape[-1] != k_out for y in Ys):
        raise Unsupported("shared module needs equal code widths at all middle pearls")
    gen = torch_gen(seed_of(ctx.cfg, "peg"), "peg", "shared")
    mod, attrs = make_alt("mlp_small", g.layout, k_in, k_out, cc["replace_width"] * 4)
    init_module(mod, gen, "default")
    mod.to(ctx.device)
    X, Y = torch.cat(Xs), torch.cat(Ys)
    B = min(ctx.cfg["train"]["batch_size"], len(X))
    lopt = LocalOpt(list(mod.parameters()), ctx.cfg["train"], cc["local_updates"])
    js = JobState(ctx, "shared")

    def step(k):
        i = torch.randint(0, len(X), (B,), generator=gen).to(ctx.device)
        return F.mse_loss(mod(X[i]), Y[i])
    local_loop(ctx, js, "shared_fit", {"m": mod}, lopt, gen, cc["local_updates"], step, phase="shared_local_fit",
               examples_per_step=B)
    first = None
    for p in middle:
        a, b = resolve_bound(g, bnds[p])
        if first is None:
            first = replace_segment(g, a, b, mod, attrs, g.node_dim(b), owner_tag="shared_pearl")
            update_bounds(g, bnds, p, b, first)
        else:
            seg = segment_between(g, a, b)
            nid = g.add_node("module", [a], {**attrs, "dim": g.node_dim(b),
                                             "layout": g.nodes[b].attrs.get("layout", g.layout)},
                             role="shared_pearl", pkey=g.nodes[first].pkey)
            g.replace_uses(b, nid, exclude=seg | {nid})
            E.prune_dead(g)
            update_bounds(g, bnds, p, b, nid)
    _train(ctx, g, bundle, cc["global_updates"] // 2, key="shared_ft", ckpt_stage="shared_ft", phase="finetune")
    return g, _work_total(ctx.work)["updates"]
