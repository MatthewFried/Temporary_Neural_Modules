"""Finite-interface scores against exact communication bounds (v5, P2).

Two benchmark families on a complete finite cube (data split_mode = complete):

  A. direct delayed-query learning (delayed_query, query_op bit): the network is trained to
     answer x_q; the encoder side sees x only (query isolation is checked), the decoder side
     sees the peg message and q.  Scored against the global optimum of that communication model.
  B. original-task preservation and later-query retention (later_query): the network is trained
     on the original task t(x) (x_0, or a parity) only; the later-query family is every bit x_j.
     The learned code is scored for later queries with the optimal decoder of that frozen code,
     and compared with the unconstrained optimum and with the exact optimum among codes that
     answer t with zero error (and the full trade-off frontier where encoder enumeration is
     small).  The constrained optimum is the relevant ceiling when the code is pure in t.

The code is read at the BOTTLENECK peg: the finite peg with the fewest total bits per example
(dim x bits for uniform pegs) whose quantiser every path from x to the output must cross
(has_bypass is False).  Total bits count every coordinate.  Scores are computed only when no
bypass exists at that peg (a bridge or retained adapter around it invalidates the premise)
and, for A, when the query cannot reach the encoder.  For a frozen code:
    e_model - e_star = [e_model - e_oracle(code)] + [e_oracle(code) - e_star]
splits the excess error into the decoder-learning gap and the gap between the learned code and
an optimal code.  These are full-domain analysis diagnostics with known ground truth, not
held-out generalisation results; architecture limits can also contribute to the code gap.
"""
from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Optional

import numpy as np
import torch

from ..finite import codebook as CB
from ..graph.accounting import has_bypass, peg_messages
from ..graph.graph import GraphNet
from ..train.trainer import predict
from .pegs import pegs as list_pegs, query_isolation

OPTIMA_FILE = Path(__file__).resolve().parents[2] / "configs" / "finite_interface_optima.json"


@lru_cache(maxsize=1)
def _table() -> dict:
    return json.loads(OPTIMA_FILE.read_text()) if OPTIMA_FILE.exists() else {}


def optimum(kind: str, n: int, k: int, task: Optional[str] = None, messages: Optional[int] = None) -> dict:
    """Exact optimum from the shipped table (generated and verified by audit_v5/tools/finite_optima.py),
    or computed now; never approximated (complete = False means unknown).  `messages`: an alphabet size
    that is not a power of two (then k = ceil(log2 messages) only labels the row)."""
    if messages is not None and (messages >= 2 ** n or messages == 2 ** k):
        messages = None
    key = f"{kind}|n{n}|k{k}" + (f"|{task}" if task else "")
    t = _table().get(key) if messages is None else None
    if t is not None:
        return t
    if kind == "delayed":
        r = CB.delayed_query_optimum(n, k, time_limit=120, messages=messages)
    elif kind == "retention":
        r = CB.retention_optimum(n, k, task, time_limit=120, messages=messages)
    else:
        raise ValueError(kind)
    return {k_: r[k_] for k_ in ("n", "k_bits", "messages", "errors", "answers", "accuracy", "complete", "method")}


def _bits_cube(n: int) -> torch.Tensor:
    return torch.from_numpy(CB.cube(n).astype(np.int64))


@torch.no_grad()
def _messages(g: GraphNet, qnode: str, X: dict) -> torch.Tensor:
    """Integer message per row at the quantiser node (joint over all coordinates)."""
    q = g.mods[g.nodes[qnode].pkey]
    zin = g.nodes[qnode].inputs[0]
    was = g.training
    g.eval()
    _, v = g(X, return_nodes=[zin])
    g.train(was)
    c = q.codes(v[zin].reshape(-1, q.k))
    c = c[:, None] if c.dim() == 1 else c
    c = c.long().cpu()
    _, inv = torch.unique(c, dim=0, return_inverse=True)
    return inv


def bottleneck(g: GraphNet, T: int = 1) -> Optional[dict]:
    msgs = {m["node"]: m for m in peg_messages(g, T)}
    xin = g.inputs.get("x")
    cands = []
    order = {n: i for i, n in enumerate(g.topo_order(g.live_nodes()))}
    for pid in list_pegs(g):
        qn = g.implants[pid].meta["peg"]["quant"]
        if qn not in msgs or qn not in order:
            continue
        m = msgs[qn]
        q = g.mods[g.nodes[qn].pkey]
        # exact alphabet only while it is small enough to matter (<= 2^62); beyond that 2^bits is used
        sym = q.n_symbols() if (hasattr(q, "n_symbols") and int(m["bits_per_example"]) <= 62) else None
        alphabet = (int(sym) ** int(m.get("positions", 1))) if sym is not None else None
        if alphabet is not None and alphabet > 2 ** 62:
            alphabet = None
        cands.append({"peg": pid, "quant": qn, "mode": m["mode"], "bits": int(m["bits_per_example"]),
                      "alphabet": alphabet, "redundancy": int(g.implants[pid].meta["peg"].get("redundancy", 1)),
                      "bypass": bool(has_bypass(g, {qn}, sources=[xin])), "topo": order[qn]})
    if not cands:
        return None
    valid = [c for c in cands if not c["bypass"]]
    pool = valid or cands
    best = min(pool, key=lambda c: (c["bits"], -c["topo"]))
    return {**best, "all_pegs": cands}


def finite_interface_scores(g: GraphNet, bundle, T: int = 1, batch: int = 4096) -> Optional[dict]:
    name = bundle.name
    p = bundle.meta.get("params") or {}
    if name not in ("delayed_query", "later_query") or "complete_domain" not in bundle.extra:
        return None
    if name == "delayed_query" and p.get("query_op", "bit") != "bit":
        return {"applicable": False, "reason": "the exact bound is for query_op = bit"}
    n = int(p["n_bits"])
    bn = bottleneck(g, T)
    if bn is None:
        return {"applicable": False, "reason": "no peg"}
    out = {"family": "A_direct_delayed_query" if name == "delayed_query" else "B_retention", "n": n,
           "bottleneck": {k: v for k, v in bn.items() if k != "all_pegs"}, "pegs": bn["all_pegs"]}
    if bn["mode"] == "none":
        out.update({"applicable": False, "reason": "bottleneck peg is continuous: no finite message bound"})
        return out
    if bn["bypass"]:
        out.update({"applicable": False, "reason": "information can reach the output around the bottleneck peg "
                                                     "(bridge / adapter / skip): the bound does not apply"})
        return out
    if name == "delayed_query":
        qi = query_isolation(g)
        out["query_isolation"] = qi
        if qi.get("query_reaches_encoder"):
            out.update({"applicable": False, "reason": "the query reaches the encoder"})
            return out
    K = int(bn["bits"])
    part = bundle.extra["complete_domain"]
    X = part.X
    bits = ((X["x"] > 0).long()).cpu()
    xcode = (bits * (2 ** torch.arange(n))).sum(1)
    msg = _messages(g, bn["quant"], X)
    # one message per x (query-blind encoder): every row of the same x must carry the same message
    lab = torch.full((2 ** n,), -1, dtype=torch.long)
    blind = True
    for xc, m in zip(xcode.tolist(), msg.tolist()):
        if lab[xc] < 0:
            lab[xc] = m
        elif lab[xc] != m:
            blind = False
    if (lab < 0).any():
        out.update({"applicable": False, "reason": "complete domain does not cover every x"})
        return out
    out["encoder_query_blind_empirical"] = blind
    if not blind:
        out.update({"applicable": False, "reason": "messages depend on the query: encoder is not query-blind"})
        return out
    labels = lab.numpy()
    out["distinct_messages"] = int(len(np.unique(labels)))
    # capacity = the quantiser's alphabet (exact for alphabets that are not a power of two, e.g. a VQ codebook
    # of 3 words), capped by 2^n; K = ceil(log2) of it per coordinate is only the bit count
    A = bn.get("alphabet")
    cap = min(int(A), 2 ** n) if A is not None else min(2 ** min(K, 62), 2 ** n)
    msg_arg = cap if cap != min(2 ** min(K, 62), 2 ** n) else None
    out["message_capacity"] = int(cap)
    if bn.get("redundancy", 1) > 1:
        out["capacity_note"] = ("repetition peg: capacity counted over every transmitted coordinate, an upper "
                                "bound (repeated coordinates are copies before quantisation)")
    pred = predict(g, part, batch).argmax(-1).cpu()
    y = part.y.cpu()
    if name == "delayed_query":
        e_model = int((pred != y).sum())
        e_oracle = CB.oracle_errors(labels, n)
        star = optimum("delayed", n, min(K, 62), messages=msg_arg)
        out.update({"applicable": True, "K_bits": K, "answers": n * 2 ** n, "e_model": e_model, "e_oracle": e_oracle,
                    "e_star": star.get("errors"), "optimum": star})
        if e_model < e_oracle:
            out["protocol_violation"] = "model beats the optimal decoder of its own code: leakage or a bug"
        if star.get("errors") is not None:
            out["decomposition"] = CB.decomposition(e_model, e_oracle, int(star["errors"]))
        return out
    tb = int(p["task_bits"])
    task = "bit:0" if tb == 1 else f"parity:{tb}"
    t = CB.task_vector(n, task)
    # the model's own original-task decoder on the cube (one row per x in the complete partition)
    e_task_model = int((pred != y).sum())
    e_task_oracle = CB.task_purity_errors(labels, t)
    e_later = CB.oracle_errors(labels, n)
    unc = optimum("delayed", n, min(K, 62), messages=msg_arg)
    con = optimum("retention", n, min(K, 62), task, messages=msg_arg)
    out.update({"applicable": True, "K_bits": K, "task": task, "answers_later": n * 2 ** n, "answers_task": 2 ** n,
                "e_task_model": e_task_model, "e_task_oracle": e_task_oracle, "e_later_oracle": e_later,
                "e_later_star_unconstrained": unc.get("errors"),
                "e_later_star_task_preserving": con.get("errors"), "optimum_unconstrained": unc,
                "optimum_task_preserving": con,
                "relevant_ceiling": ("task-preserving optimum (the code is pure in the original task)"
                                     if e_task_oracle == 0 else
                                     "frontier at this original-task error (the code is not pure in the task)")})
    bf = CB.brute_force(n, min(K, n), task, max_encoders=1 << 17, messages=msg_arg)
    if bf.get("complete"):
        out["frontier"] = bf["frontier"]
        best = [pt["later_errors"] for pt in bf["frontier"] if pt["task_errors"] <= e_task_oracle]
        out["e_later_star_at_task_error"] = min(best) if best else None
    if e_task_oracle == 0 and con.get("errors") is not None:
        out["retention_gap"] = e_later - int(con["errors"])
        if e_later < int(con["errors"]):
            out["protocol_violation"] = "a task-pure code beats the task-preserving optimum: leakage or a bug"
    return out
