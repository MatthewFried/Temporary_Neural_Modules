"""Dispatch for kind='cop' jobs (P1-P5 and section-10 baselines)."""
from __future__ import annotations


def run_cop(ctx) -> dict:
    tk = ctx.cfg["cop"]["task_kind"]
    if tk == "chain":
        from .chain import run_chain
        return run_chain(ctx)
    if tk == "alternatives":
        from .alternatives import run_alternatives
        return run_alternatives(ctx)
    if tk == "split":
        from .split import run_split
        return run_split(ctx)
    if tk == "cycles":
        from .cycles import run_cycles
        return run_cycles(ctx)
    if tk == "locality":
        from .locality import run_locality
        return run_locality(ctx)
    if tk == "recode":
        from .recode import run_recode
        return run_recode(ctx)
    if tk == "baseline":
        from .cycles import run_baseline_cop
        return run_baseline_cop(ctx)
    raise ValueError(tk)
