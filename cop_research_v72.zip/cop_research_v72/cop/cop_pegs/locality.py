"""Paired interface-locality experiment (v5, P3; cop.task_kind = 'locality').

Question: does stabilising an interface reduce the smallest tested repair region (and the work)
needed to recover a stated tolerance after a module is replaced, as co-adaptation time grows?

One job = one interface arm on a shared f0 and placement (pairing across arms by contrast and
seed):
  none                   no pegs: an ordinary network cut at the same cut indices
  continuous             pegs with continuous codes (peg.mode none) of width peg.dim
  continuous_stabilized  the same, peg maps frozen after the bypass anneal
  finite_learned         finite pegs (peg.mode uniform / vq / multi), maps learned throughout
  finite_stabilized      finite pegs, peg maps frozen after the bypass anneal
Training: the chain anneal (pegged arms) and then cop.global_updates of endpoint training
(the none arm trains the same total updates), split at cop.locality_checkpoints (fractions of
the endpoint training); a checkpoint 'loc_snap<j>' is saved at each split (co-adaptation time).

At every checkpoint the replaced pearl p (cop.locality_pearl, default the middle pearl) is
the backbone between the previous peg's decoder output and the next peg's entry (between the
two cut activations for the none arm).  It is replaced by a fresh small module fitted locally
(training inputs, local distillation to the pearl's output), and then FORKS are repaired, each
from the same post-fit state, with nested trainable scopes:
  0  no training (the locally fitted replacement assembled as is)
  1  the replacement only
  2  the replacement and the incident interface maps (previous peg's decoder, next peg's
     encoder); for the none arm there are no interface maps, so scope 2 equals scope 1 and is
     recorded as such (not trained twice)
  3  scope 2 plus the neighbouring pearls p-1 and p+1 and, for pegged arms, the rest of the two incident
     pegs (the contiguous region from pearl p-1 to pearl p+1 in every arm)
  4  the whole network
each for cop.locality_repair_updates updates with the same data (training partition, task
target), schedule and fresh optimizer.  Success at a tolerance: the validation task risk is
within the declared criterion of the checkpoint's own (exported) model: regression
(risk - risk_ref) / target_scale^2 <= criteria.nmse; classification accuracy drop <=
criteria.acc_drop_pp.  Fidelity to the checkpoint's function (drift) is recorded separately.
Reported: per tolerance, the SMALLEST SUCCESSFUL TESTED SCOPE (diverged forks never count;
none successful = censored at scope 4 within the budget, not infinite cost), the first update
reaching the tolerance in each fork, and the work of every fork.

Also per checkpoint: code stability at every interface between consecutive checkpoints
(literal message change and the change left after the best one-to-one relabelling for finite
codes; relative change and affine-aligned residual for continuous codes), and for finite
pegs an incoming-table certificate of the replacement after scope 0 and scope 1: the outgoing
code of the pearl (code in -> next peg's code) for EVERY incoming code, compared with the
original pearl.  Equality certifies that the whole network's output is unchanged on every
input whose incoming code is covered, all else frozen and no bypass (composition); it is not
a statement that SGD finds such a replacement.  Codes on quantisation-cell boundaries are
evaluated at the cell's canonical value.
"""
from __future__ import annotations

import math
import time
from typing import Optional

import numpy as np
import torch

from ..config import seed_of
from ..graph import edits as E
from ..graph.export import export_compact
from ..graph.graph import GraphNet
from ..train import metrics as M
from ..train.trainer import Segment, Trainer, evaluate, predict
from ..utils import torch_gen
from ..experiments import common as C
from ..experiments.context import Unsupported, JobState
from .chain import load_f0, placement, build_chain, anneal_segments, peg_cut_kind, _restore_into
from .cycles import fit_replacement, _peg_pkeys
from .modules import replace_segment, segment_between, external_inputs, SubgraphPearl, node_values
from .pegs import pegs as list_pegs

ARMS = ("none", "continuous", "continuous_stabilized", "finite_learned", "finite_stabilized")


# ----------------------------------------------------------------------------- interfaces and pearls

def interfaces(g: GraphNet, use_pegs: bool, idx: list[int]) -> list[dict]:
    """Per interface i (between pearl i and pearl i+1): the nodes the experiment needs."""
    out = []
    if use_pegs:
        for pid in list_pegs(g):
            pm = g.implants[pid].meta["peg"]
            out.append({"peg": pid, "entry": g.implants[pid].entry, "enc": pm["enc"], "quant": pm["quant"],
                        "dec": pm["dec"], "out": pm["dec"]})
    else:
        kind = peg_cut_kind(g)
        for i in idx:
            src = E.resolve_edges(g, E.pick_cutpoint(g, kind, i)["edges"]).source
            out.append({"peg": None, "entry": src, "enc": None, "quant": None, "dec": None, "out": src})
    return out


def pearl_bounds(g: GraphNet, itf: list[dict], p: int) -> tuple[str, str]:
    """Pearl p reads interface p-1's output (or the input) and ends at interface p's entry (or the output)."""
    a = g.inputs["x"] if p == 0 else itf[p - 1]["out"]
    b = g.output if p >= len(itf) else itf[p]["entry"]
    return a, b


def pearl_pkeys(g: GraphNet, itf: list[dict], p: int) -> set[str]:
    a, b = pearl_bounds(g, itf, p)
    seg = segment_between(g, a, b)
    peg_owned = {n for d in itf if d["peg"] for n in g.implants[d["peg"]].nodes} if itf and itf[0]["peg"] else set()
    return {g.nodes[n].pkey for n in seg if n not in peg_owned and g.nodes[n].pkey is not None}


def interface_pkeys(g: GraphNet, itf: list[dict], p: int) -> set[str]:
    out = set()
    for d, role in ((itf[p - 1] if p - 1 >= 0 else None, "dec"), (itf[p] if p < len(itf) else None, "enc")):
        if d is not None and d.get(role) and d[role] in g.nodes and g.nodes[d[role]].pkey is not None:
            out.add(g.nodes[d[role]].pkey)
    return out


# ----------------------------------------------------------------------------- code stability

def _messages(q, z: torch.Tensor) -> np.ndarray:
    """(N, coords) integer code vectors (the literal transmitted symbols)."""
    c = q.codes(z.reshape(-1, q.k))
    c = c[:, None] if c.dim() == 1 else c
    return c.long().cpu().numpy()


def code_change(prev: dict, cur: dict) -> dict:
    """prev / cur: {'messages': ints (N,)} for finite codes or {'values': (N, k)} for continuous ones."""
    if "messages" in prev:
        a, b = prev["messages"], cur["messages"]
        N = len(a)
        lit = float((a != b).any(axis=1).mean())        # literal: the transmitted symbol vector changed
        from scipy.optimize import linear_sum_assignment
        ua, ia = np.unique(a, axis=0, return_inverse=True)
        ub, ib = np.unique(b, axis=0, return_inverse=True)
        cont = np.zeros((len(ua), len(ub)), dtype=np.int64)
        np.add.at(cont, (ia.reshape(-1), ib.reshape(-1)), 1)
        r, c = linear_sum_assignment(-cont)
        matched = int(cont[r, c].sum())
        # the best ONE-TO-ONE relabelling of messages: a harmless permutation of code labels is not counted
        return {"literal_change": lit, "change_after_best_relabelling": 1.0 - matched / max(1, N),
                "n_messages_prev": int(len(ua)), "n_messages_cur": int(len(ub))}
    A, B = prev["values"].double(), cur["values"].double()
    rel = float(((B - A) ** 2).sum(1).mean() / ((A - A.mean(0)) ** 2).sum(1).mean().clamp_min(1e-30))
    Xa = torch.cat([A, torch.ones(len(A), 1, dtype=torch.float64)], 1)
    sol = torch.linalg.lstsq(Xa, B).solution
    res = float(((Xa @ sol - B) ** 2).sum(1).mean() / ((B - B.mean(0)) ** 2).sum(1).mean().clamp_min(1e-30))
    return {"relative_change": rel, "residual_after_affine_alignment": res}


@torch.no_grad()
def interface_codes(g: GraphNet, itf: list[dict], X: dict) -> dict:
    nodes = []
    for d in itf:
        if d["quant"]:
            nodes.append(g.nodes[d["quant"]].inputs[0])
        else:
            nodes.append(d["entry"])
    vals = node_values(g, X, nodes)
    out = {}
    for d, n in zip(itf, nodes):
        key = d["peg"] or d["entry"]
        if d["quant"]:
            q = g.mods[g.nodes[d["quant"]].pkey]
            out[key] = {"messages": _messages(q, vals[n])} if q.mode != "none" else {"values": vals[n].reshape(len(vals[n]), -1).cpu()}
        else:
            out[key] = {"values": vals[n].reshape(len(vals[n]), -1).cpu()}
    return out


# ----------------------------------------------------------------------------- certificate

@torch.no_grad()
def incoming_table_certificate(g_ref: GraphNet, g_new: GraphNet, q_in: str, enc_out: str, q_out: str,
                               observed: Optional[torch.Tensor] = None, max_codes: int = 1 << 16) -> dict:
    """Compare the pearl's code-to-code map (incoming peg message -> outgoing peg message) of g_new
    with g_ref for every incoming code (all of them when the alphabet has at most max_codes
    messages; otherwise only `observed`).  The pearl must read nothing but the incoming code."""
    qi = g_ref.mods[g_ref.nodes[q_in].pkey]
    qo = g_ref.mods[g_ref.nodes[q_out].pkey]
    qo_new = g_new.mods[g_new.nodes[q_out].pkey]
    if qi.mode != "uniform" or qo.mode != "uniform":
        return {"applicable": False, "reason": "certificate implemented for uniform finite pegs"}
    for gg in (g_ref, g_new):
        seg = segment_between(gg, q_in, enc_out)
        if external_inputs(gg, seg, q_in) != [q_in]:
            return {"applicable": False, "reason": "the pearl reads inputs other than the incoming code"}
    L = 2 ** qi.bits - 1
    n_codes = (L + 1) ** qi.k
    if n_codes <= max_codes:
        grid = torch.cartesian_prod(*[torch.arange(L + 1)] * qi.k) if qi.k > 1 else torch.arange(L + 1)[:, None]
        coverage = "every incoming code"
    elif observed is not None:
        grid = torch.unique(observed.long().cpu(), dim=0)
        coverage = "observed calibration codes only (coverage-conditional)"
    else:
        return {"applicable": False, "reason": f"{n_codes} incoming codes and no observed set"}
    dev = qi.lo.device
    z = grid.to(dev).to(qi.lo.dtype) / L * (qi.hi - qi.lo) + qi.lo
    z = qi(z)                                                       # canonical representation of each code
    outs = []
    for gg, qq in ((g_ref, qo), (g_new, qo_new)):
        was = gg.training
        gg.eval()
        sp = SubgraphPearl(gg, q_in, enc_out)
        v = sp(z.to(next(gg.parameters()).dtype))
        gg.train(was)
        c = qq.codes(v.reshape(-1, qq.k))
        outs.append((c[:, None] if c.dim() == 1 else c).long().cpu())
    eq = (outs[0] == outs[1]).all(1)
    return {"applicable": True, "coverage": coverage, "n_codes": int(len(grid)), "all_equal": bool(eq.all()),
            "n_mismatched": int((~eq).sum()), "mismatched_codes": grid[~eq.cpu()][:64].tolist(),
            "scope": ("output preserved for every input whose incoming code is covered, all other modules and "
                      "state frozen, no bypass; uses the reference outgoing quantiser for the reference map and "
                      "the new one for the new map")}


class OriginalPearl(torch.nn.Module):
    """The original pearl a -> b of a (copied) graph as a stand-alone module, for the exact local replacement
    control: spliced in with replace_segment exactly like a fitted replacement."""

    def __init__(self, g: GraphNet, a: str, b: str):
        super().__init__()
        self.sp = SubgraphPearl(g, a, b)

    def forward(self, x):
        return self.sp(x)


def _same_risk(r: dict, ref: dict, rel: float = 1e-6) -> tuple[bool, bool]:
    ks = [k for k in ref if isinstance(ref[k], (int, float)) and isinstance(r.get(k), (int, float))]
    bit = all(float(r[k]) == float(ref[k]) for k in ks)
    close = all(abs(float(r[k]) - float(ref[k])) <= rel * max(1.0, abs(float(ref[k]))) for k in ks)
    return bit, close


@torch.no_grad()
def frozen_code_lookup(g_ref: GraphNet, g_target: GraphNet, q_in: str, enc_out: str, q_out: str,
                       max_codes: int = 1 << 16):
    """v13 (audit D4) literal frozen-code control: a clone of g_target (the network with the REPLACED pearl)
    whose outgoing peg message is overwritten by a lookup of the reference's code table (incoming code ->
    outgoing canonical message of g_ref, enumerated over every incoming code).  Whatever the replacement
    computes, downstream then sees exactly the old code.  Agreement with the reference shows that holding the
    code fixed restores the function, i.e. downstream reads nothing but the message; a difference means the
    locality measurement is invalid for this interface.  Returns (clone with forward hooks, info) or
    (None, info with the reason)."""
    if g_ref.layout == "img":
        return None, {"applicable": False, "reason": "implemented for vector / sequence layouts"}
    qi = g_ref.mods[g_ref.nodes[q_in].pkey]
    qo = g_ref.mods[g_ref.nodes[q_out].pkey]
    if qi.mode != "uniform" or qo.mode != "uniform":
        return None, {"applicable": False, "reason": "implemented for uniform finite pegs"}
    seg = segment_between(g_ref, q_in, enc_out)
    if external_inputs(g_ref, seg, q_in) != [q_in]:
        return None, {"applicable": False, "reason": "the pearl reads inputs other than the incoming code"}
    L = 2 ** qi.bits - 1
    n_codes = (L + 1) ** qi.k
    if n_codes > max_codes:
        return None, {"applicable": False, "reason": f"{n_codes} incoming codes exceed the enumeration limit"}
    grid = torch.cartesian_prod(*[torch.arange(L + 1)] * qi.k) if qi.k > 1 else torch.arange(L + 1)[:, None]
    dev = qi.lo.device
    z = qi(grid.to(dev).to(qi.lo.dtype) / L * (qi.hi - qi.lo) + qi.lo)
    was = g_ref.training
    g_ref.eval()
    v = SubgraphPearl(g_ref, q_in, enc_out)(z.to(next(g_ref.parameters()).dtype))
    g_ref.train(was)
    table = qo(v.reshape(-1, qo.k)).detach()                         # canonical outgoing message per incoming code
    radix = torch.tensor([(L + 1) ** (qi.k - 1 - j) for j in range(qi.k)], device=dev)
    h = g_target.clone(share_params=False)
    if q_in not in h.nodes or q_out not in h.nodes:
        return None, {"applicable": False, "reason": "the interface quantisers are not both present in the target"}
    hqi, hqo = h.mods[h.nodes[q_in].pkey], h.mods[h.nodes[q_out].pkey]
    box = {}

    def grab(mod, inp, out):
        c = hqi.codes(out.reshape(-1, hqi.k))
        box["idx"] = (c.reshape(-1, hqi.k) * radix).sum(-1)

    def put(mod, inp, out):
        return table.to(out.dtype)[box["idx"]].reshape(out.shape)
    h.hooks = [hqi.register_forward_hook(grab), hqo.register_forward_hook(put)]
    return h, {"applicable": True, "n_codes": int(n_codes)}


# ----------------------------------------------------------------------------- the job

def _risk_rows(model, bundle, batch, refp=None):
    parts = [p for p in ("val", "test") if p in bundle.partitions()]
    res, preds = evaluate(model, bundle, parts, batch, return_preds=True)
    out = {p: {k: v for k, v in res[p].items() if isinstance(v, (int, float))} for p in parts}
    if refp is not None:
        for p in parts:
            out[p]["drift_vs_checkpoint"] = M.drift(preds[p], refp[p], bundle.task, bundle.partitions()[p].y,
                                                    bundle.target_scale)
    return out, preds


def _success(task, ref: dict, cur: dict, tol: float, scale: float) -> bool:
    if task == "regression":
        return (cur["mse"] - ref["mse"]) / (scale ** 2 + 1e-12) <= tol
    return (ref["acc"] - cur["acc"]) * 100.0 <= tol


@torch.no_grad()
def interface_agreement(g_ref: GraphNet, g_new: GraphNet, q_node: Optional[str], X: dict) -> Optional[dict]:
    """v15: agreement of the transmitted message at an interface between the reference and a repaired network on
    the same inputs: the fraction of examples whose whole integer code is identical, and the largest difference of
    the canonical (quantised) values.  Uniform finite pegs only (None otherwise)."""
    if q_node is None or q_node not in g_ref.nodes or q_node not in g_new.nodes:
        return None
    qr, qn = g_ref.mods[g_ref.nodes[q_node].pkey], g_new.mods[g_new.nodes[q_node].pkey]
    if qr.mode != "uniform" or qn.mode != "uniform":
        return None
    zin = g_ref.nodes[q_node].inputs[0]
    outs = []
    for g, q in ((g_ref, qr), (g_new, qn)):
        was = g.training
        g.eval()
        _, v = g(X, return_nodes=[q_node, g.nodes[q_node].inputs[0]])
        g.train(was)
        z = v[g.nodes[q_node].inputs[0]].reshape(-1, q.k)
        outs.append((q.codes(z).cpu(), v[q_node].reshape(-1, q.k).double().cpu()))
    (cr, vr), (cn, vn) = outs
    return {"code_agreement": float((cr == cn).all(1).double().mean()),
            "canonical_max_abs_diff": float((vr - vn).abs().max()), "n": int(cr.shape[0]),
            "same_quantiser_range": bool(torch.equal(qr.lo.cpu(), qn.lo.cpu()) and torch.equal(qr.hi.cpu(), qn.hi.cpu()))}


def scope_summary(rows: dict, ok_fn) -> dict:
    """rows: {scope: {"curve": [{"update", "val": metrics}], "final": {"val": metrics}, "diverged"}}.
    A scope succeeds when it did not diverge and its FINAL validation metrics pass ok_fn; the
    smallest successful tested scope is the smallest such scope (diverged or failed forks never
    count; scopes that were not run are absent).  No success: censored (None), which means 'not
    reached within the tested scopes and budget', not an infinite cost."""
    per = {}
    for s, r in rows.items():
        hits = [c["update"] for c in r["curve"] if "val" in c and ok_fn(c["val"])]
        div = bool(r.get("diverged"))
        fin_ok = (not div) and ok_fn(r["final"]["val"])
        after = [c for c in r["curve"] if "val" in c and hits and c["update"] >= min(hits)]
        sustained = bool(hits) and fin_ok and all(ok_fn(c["val"]) for c in after)
        per[s] = {"first_update_reaching": (min(hits) if hits else None), "diverged": div,
                  "success_at_end": fin_ok,
                  # v15: first passage, final success and sustained success (every evaluated point from the first
                  # passage on) are different outcomes; a tolerance can be reached and then lost
                  "sustained_from_first_passage": sustained,
                  "dipped_after_first_passage": bool(hits) and not sustained,   # incl. dips that recovered
                  "lost_at_end": bool(hits) and not fin_ok}
    ok = [s for s in sorted(per) if per[s]["success_at_end"]]
    return {"per_scope": per, "smallest_successful_tested_scope": ok[0] if ok else None, "censored": not ok,
            "tested_scopes": sorted(per),
            "note": "None = no tested scope reached the tolerance within the budget (censored)"}


def run_locality(ctx) -> dict:
    cfg = ctx.cfg
    cc, pc = cfg["cop"], cfg["peg"]
    arm = cc["locality_interface"]
    bundle = C.setup_data(ctx)
    if bundle.layout != "vec":
        raise Unsupported("the locality experiment is implemented for vector models")
    f0, _ = load_f0(ctx, bundle)
    use_pegs = arm != "none"
    stabilized = arm.endswith("_stabilized")
    batch = cfg["train"]["eval_batch"]
    crit = cfg["criteria"]
    tols = crit["nmse"] if bundle.task == "regression" else crit["acc_drop_pp"]
    js = JobState(ctx, "loc")

    # ---- training with co-adaptation checkpoints (rebuilt deterministically on every attempt)
    g = f0.clone(share_params=False)
    idx = placement(ctx, g, bundle, cc["n_pearls"] - 1)["indices"]
    peg_ids = build_chain(ctx, g, bundle, idx) if use_pegs else []
    total = int(cc["global_updates"])
    if use_pegs:
        segs = anneal_segments(ctx, g, peg_ids, total)
        if segs and segs[-1].name == "endpoint":
            endpoint = segs.pop()
        else:
            raise Unsupported("no endpoint training left after the anneal")
    else:
        # the none arm trains the same updates before its first piece as the pegged arms spend on the bypass
        # anneal, so checkpoint j sits at the same global update in every arm
        A = min(int(pc["anneal_updates"]), total) if pc["bypass"] else 0
        segs = [Segment("pre_anneal_matched", A)] if A else []
        endpoint = Segment("endpoint", total - A)
    n_end = endpoint.updates
    if n_end < 1:
        raise Unsupported("no endpoint training left after the anneal")
    fr = sorted({float(f) for f in cc["locality_checkpoints"]})
    cuts = sorted({max(1, min(n_end, int(round(f * n_end)))) for f in fr})
    pieces, prev = [], 0
    for j, u in enumerate(cuts):
        pieces.append(Segment(f"endpoint_part{j}", u - prev, on_step=endpoint.on_step))
        prev = u
    segs = segs + pieces
    stab_keys = None
    if stabilized:
        stab_keys = {pk for pk, m in g.mods.items() if any(p_.requires_grad for p_ in m.parameters())} - _peg_pkeys(g)
        for s in pieces:
            s.trainable = set(stab_keys)
    tr = Trainer(g, bundle, cfg["train"], C.seeds(cfg), ctx.device, ctx.log, "locality")
    names = [s.name for s in segs]
    done_snaps = [j for j in range(len(pieces)) if ctx.has_ckpt(f"loc_snap{j}")]
    start = 0
    if ctx.has_ckpt("loc_partial"):
        ck = ctx.load_ckpt("loc_partial")
        _restore_into(g, ck["model"])
        tr.load_state_dict(ck["trainer"])
        start = names.index(tr.state["segment"]) if tr.state["segment"] in names else 0
    elif done_snaps:
        jl = max(done_snaps)
        ck = ctx.load_ckpt(f"loc_snap{jl}")
        _restore_into(g, ck["model"])
        tr.load_state_dict(ck["trainer"])
        start = names.index(f"endpoint_part{jl}") + 1
    else:
        tr.configure("none", None, reset_state=True)
    cb = lambda: ctx.save_ckpt("loc_partial", g, tr)
    for s in segs[start:]:
        tr.run(s, checkpoint_cb=cb)
        if s.name.startswith("endpoint_part"):
            j = int(s.name[len("endpoint_part"):])
            ctx.save_ckpt(f"loc_snap{j}", g, tr, {"updates": int(tr.state["global_step"])})
            ctx.ckpt_path("loc_partial").unlink(missing_ok=True)
    ctx.note_trainer(tr, "locality_train")
    train_updates = int(tr.state["global_step"])

    # ---- per checkpoint: replacement, nested repair scopes, code stability, certificate
    n_pearls = int(cc["n_pearls"])
    p = int(cc["locality_pearl"]) if int(cc["locality_pearl"]) >= 0 else n_pearls // 2
    if not 1 <= p <= n_pearls - 2:
        raise Unsupported("the replaced pearl needs a neighbour on each side (1 <= pearl <= n_pearls - 2)")
    n_rep = int(cc["locality_repair_updates"])
    n_pts = max(1, int(cc["locality_eval_points"]))
    eval_pts = sorted({max(1, int(round(n_rep * (i + 1) / n_pts))) for i in range(n_pts)})
    Xv = {k: v[:cfg["eval"]["calib_size"]] for k, v in bundle.val.X.items()}
    store_key = "locality_results"
    store = js.get(store_key) or {"snapshots": {}}
    prev_codes = None
    snaps_out = []
    for j in range(len(pieces)):
        ck = ctx.load_ckpt(f"loc_snap{j}")
        gj = GraphNet.from_checkpoint(ck["model"], ctx.device)
        gx = export_compact(gj, fold_linear=False)[0] if use_pegs else gj
        gx.eval()
        itf = interfaces(gx, use_pegs, idx)
        cur_codes = interface_codes(gx, itf, Xv)
        stab = {k: code_change(prev_codes[k], cur_codes[k]) for k in cur_codes if prev_codes and k in prev_codes}
        prev_codes = cur_codes
        if str(j) in store["snapshots"]:
            rec = store["snapshots"][str(j)]
            snaps_out.append(rec)
            continue
        ref, refp = _risk_rows(gx, bundle, batch)
        a, b = pearl_bounds(gx, itf, p)
        seg = segment_between(gx, a, b)
        if external_inputs(gx, seg, a) != [a]:
            raise Unsupported("the replaced pearl reads late inputs")
        work = gx.clone(share_params=False)
        mod, attrs, finfo = fit_replacement(ctx, js, work, bundle, a, b, cc["replace_width"], cc["local_updates"],
                                            f"s{j}")
        rid = replace_segment(work, a, b, mod, attrs, work.node_dim(b), owner_tag=f"locality_replacement_s{j}")
        # the replaced pearl's output node b is now the replacement rid (peg entries are updated by replace_segment)
        itf_w = [{k: (rid if v == b else v) for k, v in d.items()} for d in itf]
        scopes = {1: {work.nodes[rid].pkey}}
        scopes[2] = scopes[1] | interface_pkeys(work, itf_w, p)
        # scope 3 is the contiguous region from pearl p-1 to pearl p+1: the neighbouring pearls and, for pegged
        # arms, the far halves of the two incident pegs (encoder of peg p-1, decoder of peg p), so it covers the
        # same stretch of network in every arm
        far = set()
        for d in (itf_w[p - 1], itf_w[p] if p < len(itf_w) else None):
            if d is not None and d.get("peg") and d["peg"] in work.implants:
                far |= {work.nodes[n].pkey for n in work.implants[d["peg"]].nodes
                        if n in work.nodes and work.nodes[n].pkey is not None
                        and any(True for _ in work.mods[work.nodes[n].pkey].parameters())}
        scopes[3] = scopes[2] | pearl_pkeys(work, itf_w, p - 1) | pearl_pkeys(work, itf_w, p + 1) | far
        scopes[4] = {pk for pk, m in work.mods.items() if any(True for _ in m.parameters())}
        rows = {}
        r0, _ = _risk_rows(work, bundle, batch, refp)
        rows[0] = {"scope": 0, "trainable": [], "n_trainable": 0, "curve": [{"update": 0, **{q: r0[q] for q in r0}}],
                   "final": r0, "updates": 0, "diverged": False,
                   "interface_agreement": interface_agreement(gx, work, itf[p]["quant"] if use_pegs and p < len(itf)
                                                              else None, Xv)}
        cert = {}
        if use_pegs and itf_w[p - 1]["quant"] and itf_w[p]["quant"]:
            q_in, enc, q_out = itf_w[p - 1]["quant"], itf_w[p]["enc"], itf_w[p]["quant"]
            # incoming codes seen on the calibration inputs: used only when the full table is too large
            cin = cur_codes.get(itf[p - 1]["peg"]) or {}
            seen_in = torch.from_numpy(cin["messages"]) if "messages" in cin else None   # None: continuous peg
            cert["scope0"] = incoming_table_certificate(gx, work, q_in, enc, q_out, observed=seen_in)
        for s in (1, 2, 3, 4):
            if s == 2 and scopes[2] == scopes[1]:
                rows[2] = {**rows[1], "scope": 2, "same_as_scope": 1}
                continue
            h = work.clone(share_params=False)
            # one data stream for every fork and checkpoint: scopes differ only in what may learn
            t2 = Trainer(h, bundle, cfg["train"], C.seeds(cfg), ctx.device, ctx.log, "locality_repair")
            t2.configure("none", None, reset_state=True)
            curve = [rows[0]["curve"][0]]

            def ev(trn, k, curve=curve, h=h):
                rr, _ = _risk_rows(h, bundle, batch, refp)
                curve.append({"update": int(k), **rr})
                h.train()
                return {}
            seg_ = Segment(f"repair_scope{s}", n_rep, trainable=set(scopes[s]), eval_points=eval_pts, eval_fn=ev)
            t2.run(seg_)
            fin, _ = _risk_rows(h, bundle, batch, refp)
            ia = interface_agreement(gx, h, itf[p]["quant"] if use_pegs and p < len(itf) else None, Xv)
            rows[s] = {"scope": s, "trainable": sorted(scopes[s]), "n_trainable": int(sum(
                p_.numel() for pk in scopes[s] for p_ in h.mods[pk].parameters())), "curve": curve, "final": fin,
                "updates": int(t2.state["global_step"]), "examples": int(t2.state["examples"]),
                "train_macs": int(t2.state.get("train_macs", 0)), "diverged": bool(t2.state.get("diverged")),
                "diverged_reason": t2.state.get("diverged_reason"), "interface_agreement": ia}
            if s == 1 and "scope0" in cert:
                cert["scope1"] = incoming_table_certificate(gx, h, itf_w[p - 1]["quant"], itf_w[p]["enc"],
                                                            itf_w[p]["quant"], observed=seen_in)
        controls = {}
        if cc["locality_controls"]:
            # positive control 1, exact local replacement: a copy of the ORIGINAL pearl spliced into the network
            # through replace_segment, exactly like a fitted replacement; the incoming-table certificate must hold
            # and the risk must equal the reference, or the replacement / measurement machinery is broken
            gex = gx.clone(share_params=False)
            rid_ex = replace_segment(gex, a, b, OriginalPearl(gx.clone(share_params=False), a, b).eval(),
                                     {"kind": "original_pearl_copy"}, gex.node_dim(b),
                                     owner_tag=f"locality_exact_s{j}")
            itf_ex = [{k: (rid_ex if v == b else v) for k, v in d.items()} for d in itf]
            gex.eval()
            ex_cert = None
            if use_pegs and itf_ex[p - 1]["quant"] and itf_ex[p]["quant"]:
                ex_cert = incoming_table_certificate(gx, gex, itf_ex[p - 1]["quant"], itf_ex[p]["enc"],
                                                     itf_ex[p]["quant"])
            r_ex, _ = _risk_rows(gex, bundle, batch, refp)
            bit, close = _same_risk(r_ex["val"], ref["val"])
            controls["exact_local_replacement"] = {"certificate": ex_cert, "risk": r_ex, "bitwise_equal": bit,
                                                   "matches_reference": close,
                                                   "match_rule": "every val metric within 1e-6 relative"}
            # positive control 2, literal frozen code: the network WITH the fitted replacement (before repair),
            # its outgoing message overwritten by the reference code table
            if use_pegs and itf_w[p - 1]["quant"] and itf_w[p]["quant"]:
                hfc, fc_info = frozen_code_lookup(gx, work, itf_w[p - 1]["quant"], itf[p]["enc"], itf_w[p]["quant"])
                if hfc is not None:
                    hfc.eval()
                    r_fc, _ = _risk_rows(hfc, bundle, batch, refp)
                    for hk in hfc.hooks:
                        hk.remove()
                    bit, close = _same_risk(r_fc["val"], ref["val"])
                    fc_info.update({"risk": r_fc, "bitwise_equal": bit, "matches_reference": close,
                                    "replacement_risk_without_lookup": r0})
                controls["frozen_code_lookup"] = fc_info
            # representation matching (v15 name; was "code matching"): the replacement alone trained on MSE to the
            # ORIGINAL network's PRE-quantiser values at the next interface's entry (the next peg's encoder output;
            # the cut activation b for the none arm) on training inputs, the same updates and data stream as the
            # task-repair forks; then judged on the task, the function and the transmitted integer code.  It is a
            # learned repair objective, not an exact code-matching certificate
            node_new = itf_w[p]["enc"] if (use_pegs and p < len(itf_w) and itf_w[p].get("enc")) else rid
            node_ref = itf[p]["enc"] if (use_pegs and p < len(itf) and itf[p].get("enc")) else b
            hcm = work.clone(share_params=False)
            tcm = Trainer(hcm, bundle, cfg["train"], C.seeds(cfg), ctx.device, ctx.log, "locality_repair")
            tcm.configure("none", None, reset_state=True)

            def code_target(out, batch_, X, hcm=hcm, node_new=node_new, node_ref=node_ref):
                with torch.no_grad():
                    _, vr = gx(X, return_nodes=[node_ref])
                _, vn = hcm(X, return_nodes=[node_new])
                return torch.nn.functional.mse_loss(vn[node_new], vr[node_ref])
            tcm.run(Segment("repair_scope1_representation_match", n_rep, trainable={hcm.nodes[rid].pkey}, target="custom",
                            target_fn=code_target))
            fin_cm, _ = _risk_rows(hcm, bundle, batch, refp)
            controls["representation_match_scope1"] = {
                "objective": "MSE to the reference pre-quantiser values at the next interface entry",
                "interface_agreement": interface_agreement(gx, hcm, itf[p]["quant"] if use_pegs and p < len(itf)
                                                           else None, Xv),
                "final": fin_cm, "updates": int(tcm.state["global_step"]), "train_macs": int(tcm.state.get("train_macs", 0)),
                "matched_node": node_ref, "diverged": bool(tcm.state.get("diverged")),
                "success": {str(tol): _success(bundle.task, ref["val"], fin_cm["val"], float(tol), bundle.target_scale)
                            for tol in tols}}
        summary = {str(tol): scope_summary(rows, lambda m, tol=float(tol): _success(
            bundle.task, ref["val"], m, tol, bundle.target_scale)) for tol in tols}
        rec = {"checkpoint": j, "updates_at_checkpoint": int(ck["extra"]["updates"]), "reference": ref,
               "pearl": p, "replaced_nodes": len(seg), "local_fit": finfo, "scopes": {str(s): r for s, r in rows.items()},
               "tolerances": summary, "certificate": cert, "code_stability_vs_previous": stab,
               "controls": controls,
               "censoring_note": "a tolerance not reached at scope 4 within the budget is censored, not irreducible"}
        store["snapshots"][str(j)] = rec
        js.put(store_key, store)
        snaps_out.append(rec)
    # ---- work, rebuilt from the records so a resumed job counts every phase exactly once
    ctx.work = {}
    ctx.count_work("locality_train", updates=train_updates, examples=int(tr.state["examples"]),
                   seconds=tr.timing["train_seconds"], macs=int(tr.state.get("train_macs", 0)),
                   macs_bwd=int(tr.state.get("train_macs_bwd", 0)))
    for rec in snaps_out:
        ctx.count_work("diagnostic:locality_local_fit", updates=int(rec["local_fit"]["updates"]),
                       macs_complete=False)
        for s, r in rec["scopes"].items():
            if int(s) in (1, 2, 3, 4) and not r.get("same_as_scope"):
                ctx.count_work(f"diagnostic:locality_scope{s}", updates=r["updates"], examples=r.get("examples", 0),
                               macs=r.get("train_macs", 0))
        cm = (rec.get("controls") or {}).get("representation_match_scope1")
        if cm:
            ctx.count_work("diagnostic:locality_representation_match", updates=cm["updates"],
                           macs=cm.get("train_macs", 0))
    ctx.updates, ctx.examples = train_updates, int(tr.state["examples"])
    out = {"interface": arm, "stabilized": stabilized, "pegs": peg_ids, "cut_indices": idx, "pearl": p,
           "checkpoints_fraction_requested": fr,
           "checkpoints_fraction_of_endpoint": [u / n_end for u in cuts], "checkpoint_updates": cuts, "repair_updates": n_rep,
           "eval_points": eval_pts, "tolerances": [float(t) for t in tols], "snapshots": snaps_out,
           "train_updates": train_updates}
    ctx.save_json("locality_result.json", out)
    for rec in snaps_out:
        for tol, sm in rec["tolerances"].items():
            v = sm["smallest_successful_tested_scope"]
            ctx.metric(f"locality_ckpt{rec['checkpoint']}", "val", f"smallest_scope@{tol}",
                       -1 if v is None else v, "")
    return {"interface": arm, "n_checkpoints": len(snaps_out)}
