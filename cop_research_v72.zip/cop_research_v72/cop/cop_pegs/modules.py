"""Pearl implementations (alternatives behind the same interface), segment
replacement in a GraphNet, and evaluation of an existing pearl in code space.
"""
from __future__ import annotations

import copy
import math
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from ..graph import edits as E
from ..graph.graph import GraphNet, GraphError
from ..graph.ops import (MODULE_TYPES, MLPModule, TableModule, SelfAttention, feat_linear, init_module, ACTS,
                         FORWARD)


class SparseMLP(MLPModule):
    """MLP whose weights carry fixed binary masks after magnitude pruning."""

    def __init__(self, d_in, hidden, d_out, act="relu", layout="vec"):
        super().__init__(d_in, hidden, d_out, act, layout)
        for i, l in enumerate(self.layers):
            self.register_buffer(f"mask{i}", torch.ones_like(l.weight))

    def forward(self, x):
        for i, l in enumerate(self.layers):
            x = feat_linear(x, l.weight * getattr(self, f"mask{i}"), l.bias, self.layout)
            if i < len(self.layers) - 1:
                x = ACTS[self.act](x)
        return x

    @torch.no_grad()
    def prune(self, density: float) -> None:
        for i, l in enumerate(self.layers):
            w = l.weight.abs().flatten()
            k = max(1, int(round(density * w.numel())))
            thr = w.topk(k).values.min()
            getattr(self, f"mask{i}").copy_((l.weight.abs() >= thr).to(l.weight))

    def macs_per_position(self) -> int:
        return int(sum(getattr(self, f"mask{i}").sum().item() for i in range(len(self.layers))))

    def n_effective_params(self) -> int:
        return self.macs_per_position() + sum(l.bias.numel() for l in self.layers)


class ConvPearl(nn.Module):
    def __init__(self, c_in, hidden, c_out, pool: int = 1, k: int = 3, act: str = "relu"):
        super().__init__()
        dims = [c_in] + list(hidden) + [c_out]
        self.convs = nn.ModuleList()
        for i, (a, b) in enumerate(zip(dims[:-1], dims[1:])):
            ks = k if i < len(dims) - 2 else 1
            self.convs.append(nn.Conv2d(a, b, ks, padding=ks // 2))
        self.pool, self.act, self.k = pool, act, k

    def forward(self, x):
        for i, c in enumerate(self.convs):
            x = c(x)
            if i < len(self.convs) - 1:
                x = ACTS[self.act](x)
                if i == 0 and self.pool > 1:
                    x = F.max_pool2d(x, self.pool)
        if len(self.convs) == 1 and self.pool > 1:
            x = F.max_pool2d(x, self.pool)
        return x

    def macs_per_position(self) -> int:
        """MACs per OUTPUT position (first conv runs at input resolution)."""
        tot = 0
        for i, c in enumerate(self.convs):
            m = c.in_channels * c.out_channels * c.kernel_size[0] * c.kernel_size[1]
            tot += m * (self.pool ** 2 if (i == 0 and self.pool > 1 and len(self.convs) > 1) else 1)
        return tot


class AttnPearl(nn.Module):
    """Small causal Transformer block in code space (sequence pearls)."""

    def __init__(self, k_in, d, k_out, heads=2):
        super().__init__()
        d = max(heads, d - d % heads)
        self.inp = nn.Linear(k_in, d)
        self.ln1, self.ln2 = nn.LayerNorm(d), nn.LayerNorm(d)
        self.attn = SelfAttention(d, heads, True)
        self.fc1, self.fc2 = nn.Linear(d, 2 * d), nn.Linear(2 * d, d)
        self.out = nn.Linear(d, k_out)
        self.d = d

    def forward(self, x):
        h = self.inp(x)
        h = h + self.attn(self.ln1(h))
        h = h + self.fc2(F.gelu(self.fc1(self.ln2(h))))
        return self.out(h)

    def macs_per_position(self) -> int:
        d = self.d
        return self.inp.in_features * d + 4 * d * d + 4 * d * d + d * self.out.out_features


class ChainModule(nn.Module):
    """s sub-pearls with intermediate codes (P4).  shared=True applies ONE
    module s times between in/out projections (parameters once, compute s times)."""

    def __init__(self, k_in, k_mid, k_out, s, width, layout="vec", shared=False, act="relu"):
        super().__init__()
        self.s, self.shared, self.layout = s, shared, layout
        self.k_in, self.k_mid, self.k_out, self.width = k_in, k_mid, k_out, width
        if shared:
            self.inp = MLPModule(k_in, [], k_mid, act, layout)
            self.core = MLPModule(k_mid, [width], k_mid, act, layout)
            self.outp = MLPModule(k_mid, [], k_out, act, layout)
        else:
            dims = [k_in] + [k_mid] * (s - 1) + [k_out]
            self.parts = nn.ModuleList(MLPModule(a, [width], b, act, layout) for a, b in zip(dims[:-1], dims[1:]))

    def forward(self, x, return_codes: bool = False):
        codes = []
        if self.shared:
            h = self.inp(x)
            for _ in range(self.s):
                h = self.core(h)
                codes.append(h)
            out = self.outp(h)
        else:
            h = x
            for i, p in enumerate(self.parts):
                h = p(h)
                if i < len(self.parts) - 1:
                    codes.append(h)
            out = h
        return (out, codes) if return_codes else out

    def macs_per_position(self) -> int:
        if self.shared:
            return self.inp.macs_per_position() + self.s * self.core.macs_per_position() + self.outp.macs_per_position()
        return sum(p.macs_per_position() for p in self.parts)


class ConvHead(nn.Module):
    """Image head pearl replacement: conv3x3 -> relu -> global average pool -> linear."""

    def __init__(self, c_in, width, n_out, hw_hint: int = 1):
        super().__init__()
        self.conv = nn.Conv2d(c_in, width, 3, padding=1)
        self.fc = nn.Linear(width, n_out)
        self.hw_hint = hw_hint

    def forward(self, x):
        return self.fc(F.relu(self.conv(x)).mean(dim=(2, 3)))

    def macs_per_position(self) -> int:
        # counted per OUTPUT position (the head has one); conv cost needs the input map size
        return self.fc.in_features * self.fc.out_features + self.conv.in_channels * self.conv.out_channels * 9 * \
            self.hw_hint


MODULE_TYPES.update({"sparse_mlp": SparseMLP, "convnet": ConvPearl, "attn_pearl": AttnPearl, "chain": ChainModule,
                     "convhead": ConvHead})
from .transplant import ALIGN_MODULE_TYPES  # noqa: E402  (fitted cut alignments are checkpointable graph modules)
MODULE_TYPES.update(ALIGN_MODULE_TYPES)


def make_alt(kind: str, layout: str, k_in: int, k_out: int, width: int, pool: int = 1,
             in_quant=None) -> tuple[nn.Module, dict]:
    """Return (module, serialisable attrs).  `in_quant` is the incoming peg's
    quantiser (needed by 'table': the table is indexed by its symbols)."""
    if layout == "img":
        spec = {"conv_large": ("convnet", {"c_in": k_in, "hidden": [width, width], "c_out": k_out, "pool": pool}),
                "mlp_large": ("convnet", {"c_in": k_in, "hidden": [width, width], "c_out": k_out, "pool": pool}),
                "conv_small": ("convnet", {"c_in": k_in, "hidden": [max(2, width // 4)], "c_out": k_out, "pool": pool}),
                "mlp_small": ("convnet", {"c_in": k_in, "hidden": [max(2, width // 4)], "c_out": k_out, "pool": pool}),
                "lowrank": ("convnet", {"c_in": k_in, "hidden": [max(1, min(k_in, k_out) // 2)], "c_out": k_out,
                                        "pool": pool, "k": 1, "act": "identity"}),
                "linear": ("convnet", {"c_in": k_in, "hidden": [], "c_out": k_out, "pool": pool, "k": 1})}
        if kind not in spec:
            raise GraphError(f"alternative {kind} not available for image pearls")
        t, args = spec[kind]
    else:
        if kind == "table":
            if in_quant is None or in_quant.mode == "none":
                raise GraphError("table pearls need a finite (quantised) input code")
            if in_quant.n_symbols() > 2 ** 16:
                raise GraphError(f"table would need {in_quant.n_symbols()} rows (> 2^16)")
            mod = TableModule.from_quantizer(in_quant, k_out)
            args = {"k": mod.k, "levels": mod.levels, "d_out": k_out, "mode": mod.mode, "n_messages": mod.n_messages}
            return mod, {"module_type": "table", "module_args": args}
        elif kind == "attn_block":
            if layout != "seq":
                raise GraphError("attn_block is for sequence pearls")
            t, args = "attn_pearl", {"k_in": k_in, "d": width, "k_out": k_out}
        else:
            spec = {"mlp_large": ("mlp", {"d_in": k_in, "hidden": [width, width], "d_out": k_out, "act": "relu"}),
                    "mlp_small": ("mlp", {"d_in": k_in, "hidden": [max(2, width // 4)], "d_out": k_out, "act": "relu"}),
                    "lowrank": ("mlp", {"d_in": k_in, "hidden": [max(1, min(k_in, k_out) // 2)], "d_out": k_out,
                                        "act": "identity"}),
                    "linear": ("mlp", {"d_in": k_in, "hidden": [], "d_out": k_out, "act": "relu"}),
                    "sparse": ("sparse_mlp", {"d_in": k_in, "hidden": [width], "d_out": k_out, "act": "relu"})}
            if kind not in spec:
                raise GraphError(f"unknown alternative {kind}")
            t, args = spec[kind]
            args = dict(args, layout=layout)
    mod = MODULE_TYPES[t](**args)
    return mod, {"module_type": t, "module_args": args}


def segment_between(g: GraphNet, in_node: str, out_node: str) -> set[str]:
    """Nodes strictly after in_node up to and including out_node."""
    return (g.descendants(in_node) & (g.ancestors(out_node) | {out_node}))


def external_inputs(g: GraphNet, seg: set[str], in_node: str) -> list[str]:
    ext = []
    for n in sorted(seg, key=lambda s: int(s[1:])):
        for i in g.nodes[n].inputs:
            if i not in seg and i != in_node and i not in ext:
                ext.append(i)
    return [in_node] + ext


def replace_segment(g: GraphNet, in_node: str, out_node: str, module: nn.Module, attrs: dict, out_dim: int,
                    owner_tag: str = "replacement") -> str:
    """Replace the computation between in_node and out_node by `module` reading
    the concatenation of all external inputs of the segment (e.g. a late query).
    Refuses if any interior node is consumed outside the segment (a bypass)."""
    seg = segment_between(g, in_node, out_node)
    live = g.live_nodes()
    for n in seg - {out_node}:
        for c, _ in g.consumers(n):
            if c not in seg and c in live:
                raise GraphError(f"segment node {n} feeds {c} outside the segment (bypass); cannot replace")
    ins = external_inputs(g, seg, in_node)
    src = ins[0]
    if len(ins) > 1:
        dim = sum(g.node_dim(i) for i in ins)
        src = g.add_node("concat", ins, {"dim": dim, **{k: v for k, v in g.nodes[in_node].attrs.items()
                                                        if k in ("hw", "T")}}, role=f"{owner_tag}.in")
    attrs = dict(attrs)
    attrs.update({"dim": out_dim, "layout": g.nodes[out_node].attrs.get("layout", g.layout)})
    for k in ("hw", "T"):
        if k in g.nodes[out_node].attrs:
            attrs[k] = g.nodes[out_node].attrs[k]
    dev, dt = g._dev_dtype()
    module.to(dev, dt)
    nid = g.add_node("module", [src], attrs, role=owner_tag, module=module)
    g.replace_uses(out_node, nid, exclude=seg | {nid})
    for imp in g.implants.values():
        if imp.entry == out_node:
            imp.entry = nid
    E.prune_dead(g)
    g.meta.setdefault("replacements", []).append({"node": nid, "in": ins, "replaced_out": out_node,
                                                   "n_replaced_nodes": len(seg)})
    return nid


@torch.no_grad()
def node_values(g: GraphNet, X: dict, nodes: list[str], batch: int = 4096) -> dict:
    was = g.training
    g.eval()
    N = next(iter(X.values())).shape[0]
    out = {n: [] for n in nodes}
    for i in range(0, N, batch):
        xb = {k: v[i:i + batch] for k, v in X.items()}
        _, vals = g(xb, return_nodes=nodes)
        for n in nodes:
            out[n].append(vals[n])
    g.train(was)
    return {n: torch.cat(v) for n, v in out.items()}


class SubgraphPearl(nn.Module):
    """Evaluate an existing pearl of a GraphNet in code space: inject `code`
    at in_node and read out_node.  Other external inputs (late query) come
    from X.  Parameters are shared with the source graph (frozen by caller)."""

    def __init__(self, g: GraphNet, in_node: str, out_node: str):
        super().__init__()
        self.g = g
        self.in_node, self.out_node = in_node, out_node
        self.seg = segment_between(g, in_node, out_node)
        self.order = [n for n in g.topo_order(self.seg | {out_node}) if n in self.seg]

    def forward(self, code, X: Optional[dict] = None):
        vals = {self.in_node: code}
        g = self.g
        ctx = {"X": X if X is not None else {}}
        for nid in self.order:
            n = g.nodes[nid]
            xs = []
            for i in n.inputs:
                if i not in vals:
                    if g.nodes[i].op == "input":
                        vals[i] = (X if X is not None else {})[g.nodes[i].attrs["stream"]]
                    else:
                        raise GraphError(f"pearl node {nid} needs {i} from outside")
                xs.append(vals[i])
            vals[nid] = FORWARD[n.op](n, xs, g.mods[n.pkey] if n.pkey else None, g, ctx)
        return vals[self.out_node]
