"""Pegs: explicit interfaces between pearls.

A peg is a series implant
    z_out = alpha * h + (1 - alpha) * [ D(Q(E h)) + beta * R(h) ]
with an explicitly recorded bypass alpha (starts at 1, so insertion is an
identity BECAUSE of the bypass, not because the code is sufficient) and an
optional temporary residual channel R (width r, retired by annealing beta to 0
and physically removed at export).  E: d->k encoder, Q: quantiser (continuous,
uniform bits, codebook, or several messages), D: k->d decoder.  The endpoint
alpha = 0, beta = 0 is tested after export, where bypass edges no longer exist.
"""
from __future__ import annotations

import math
from typing import Optional

import torch

from ..graph import edits as E
from ..graph.accounting import has_bypass, peg_messages
from ..graph.graph import GraphNet
from ..graph.ops import init_module


def insert_peg(g: GraphNet, cut: E.Cut, gen: torch.Generator, k: int, mode: str = "none", bits: int = 8,
               codebook_size: int = 16, n_messages: int = 1, temp_channel: int = 0, slot: str = "", rnd=None,
               redundancy: int = 1) -> str:
    def body(g, h, iid, d, gen_, p):
        routes = []
        if redundancy > 1:
            # repetition code (F07e): m = k / r distinct coordinates, each transmitted r times (k coordinates
            # in total: equal bits to an ordinary k-dim peg); r route decoders, averaged
            m = k // redundancy
            e = E._linear(g, h, d, m, iid, "peg_enc", gen, base_attrs=E._dimattrs(g, h, m))
            code_in = g.add_node("select", [e], {"idx": [i % m for i in range(k)], **E._dimattrs(g, h, k)},
                                 owner=iid, role="peg_repeat")
        else:
            e = E._linear(g, h, d, k, iid, "peg_enc", gen, base_attrs=E._dimattrs(g, h, k))
            code_in = e
        q = g.add_node("quant", [code_in], {"dim": k, "mode": mode, "bits": bits, "codebook_size": codebook_size,
                                            "n_messages": n_messages, **E._dimattrs(g, h, k)}, owner=iid,
                       role="peg_quant", build=True)
        if redundancy > 1:
            m = k // redundancy
            for j in range(redundancy):
                sj = g.add_node("select", [q], {"idx": list(range(j * m, (j + 1) * m)), **E._dimattrs(g, h, m)},
                                owner=iid, role=f"peg_route{j}")
                routes.append(E._linear(g, sj, m, d, iid, f"peg_dec{j}", gen, base_attrs=E._dimattrs(g, h, d)))
            dnode = g.add_node("add", routes, {"coefs": [1.0 / redundancy] * redundancy,
                                               "terms": [f"route{j}" for j in range(redundancy)],
                                               **E._dimattrs(g, h, d)}, owner=iid, role="peg_dec")
        else:
            dnode = E._linear(g, q, k, d, iid, "peg_dec", gen, base_attrs=E._dimattrs(g, h, d))
        core = dnode
        beta = None
        rnodes = []
        if temp_channel:
            r1 = E._linear(g, h, d, temp_channel, iid, "temp_in", gen, base_attrs=E._dimattrs(g, h, temp_channel))
            r2 = E._linear(g, r1, temp_channel, d, iid, "temp_out", gen, scheme="zero", base_attrs=E._dimattrs(g, h, d))
            beta = g.new_gate(1.0)
            core = g.add_node("add", [dnode, r2], {"coefs": [1.0, 1.0], "terms": ["core", "temp"],
                                                   "gates": [None, beta], **E._dimattrs(g, h, d)}, owner=iid,
                              role="peg_sum")
            rnodes = [r1, r2]
        alpha = g.new_gate(1.0)
        mix = g.add_node("gate_mix", [core, h], {"gate": alpha, **E._dimattrs(g, h, d)}, owner=iid, role="peg_bypass")
        g.implants[iid].meta["peg"] = {"enc": e, "quant": q, "dec": dnode, "alpha": alpha, "beta": beta,
                                       "temp": rnodes, "mix": mix, "dim": k, "mode": mode, "bits": bits,
                                       "codebook_size": codebook_size, "n_messages": n_messages,
                                       "redundancy": int(redundancy), "routes": routes, "code_in": code_in}
        g.implants[iid].meta["cutpoints"] = {"code": [[dnode, 0]]}
        return mix

    return E.insert_series(g, cut, "peg", body, {"k": k, "mode": mode, "bits": bits, "temp": temp_channel,
                                                 "redundancy": int(redundancy)}, gen, "exact_identity", slot, rnd)


def pegs(g: GraphNet) -> list[str]:
    return sorted([k for k, v in g.implants.items() if v.construction == "peg"], key=lambda s: int(s[1:]))


@torch.no_grad()
def calibrate_peg(g: GraphNet, iid: str, X: dict, gen: torch.Generator, init: str = "pca") -> dict:
    """PCA initialisation of E/D (D E = projection on the top-k principal
    subspace of the TRAINING calibration activations) and quantiser range /
    codebook calibration.  Only training data may be passed here."""
    pm = g.implants[iid].meta["peg"]
    imp = g.implants[iid]
    was = g.training
    g.eval()
    _, vals = g(X, return_nodes=[imp.entry])
    h = vals[imp.entry]
    lay = g.layout
    H = h.permute(0, 2, 3, 1).reshape(-1, h.shape[1]) if lay == "img" else h.reshape(-1, h.shape[-1])
    H = H.double()
    mu = H.mean(0)
    k = pm["dim"]
    info = {}
    if init == "pca" and k > H.shape[1]:
        info["pca_skipped"] = f"peg dim {k} exceeds activation dim {H.shape[1]}; random init kept"
    elif init == "pca":
        U, S, Vh = torch.linalg.svd(H - mu, full_matrices=False)
        r = int(pm.get("redundancy", 1))
        kk = k // r                             # distinct coordinates (k / redundancy)
        V = Vh[:kk]                             # kk x d
        enc = g.mods[g.nodes[pm["enc"]].pkey]
        enc.weight.copy_(V.to(enc.weight))
        enc.bias.copy_((-V @ mu).to(enc.bias))
        decs = [g.mods[g.nodes[n_].pkey] for n_ in (pm.get("routes") or [pm["dec"]])]
        for dec in decs:                        # every route decodes the same coordinates (averaged when r > 1)
            dec.weight.copy_(V.T.to(dec.weight))
            dec.bias.copy_(mu.to(dec.bias))
        tot = (S ** 2).sum().clamp_min(1e-30)
        info["pca_explained"] = float((S[:kk] ** 2).sum() / tot)
        info["spectrum_top"] = (S[: min(32, len(S))] ** 2 / tot).tolist()
    code_node = pm.get("code_in", pm["enc"])
    _, vals = g(X, return_nodes=[code_node])
    z = vals[code_node]
    Z = z.permute(0, 2, 3, 1).reshape(-1, k) if lay == "img" else z.reshape(-1, k)
    q = g.mods[g.nodes[pm["quant"]].pkey]
    q.calibrate(Z, gen=gen)
    info["calibrated_on"] = "training calibration inputs"
    g.train(was)
    return info


@torch.no_grad()
def peg_stats(g: GraphNet, iid: str, X: dict, T: int = 1, float_bits: int = 32) -> dict:
    """Code statistics on given inputs: effective rank (continuous), occupancy and
    empirical message entropy (finite codes), reconstruction error ||D(Q(E h)) - h||."""
    pm = g.implants[iid].meta["peg"]
    imp = g.implants[iid]
    was = g.training
    g.eval()
    code_node = pm.get("code_in", pm["enc"])    # k-dim code before quantisation (repeated when redundancy > 1)
    _, v = g(X, return_nodes=[imp.entry, code_node, pm["dec"]])
    h, z, rec = v[imp.entry], v[code_node], v[pm["dec"]]
    k = pm["dim"]
    lay = g.layout
    flat = lambda t, c: t.permute(0, 2, 3, 1).reshape(-1, c) if lay == "img" else t.reshape(-1, c)
    Z = flat(z, k).double()
    S = torch.linalg.svdvals(Z - Z.mean(0))
    p = (S ** 2) / (S ** 2).sum().clamp_min(1e-30)
    eff_rank = float(torch.exp(-(p * (p + 1e-30).log()).sum()))
    d = h.shape[1] if lay == "img" else h.shape[-1]
    err = float(((flat(rec, d) - flat(h, d)) ** 2).mean() / flat(h, d).var().clamp_min(1e-12))
    out = {"effective_rank": eff_rank, "relative_reconstruction_mse": err, "dim": k, "mode": pm["mode"]}
    q = g.mods[g.nodes[pm["quant"]].pkey]
    if q.mode != "none":
        codes = q.codes(flat(z, k))
        if codes.dim() == 1:
            codes = codes[:, None]
        if q.mode == "uniform":
            # occupancy per coordinate and joint message entropy
            occ = [int(torch.unique(codes[:, j]).numel()) for j in range(codes.shape[1])]
            out["occupancy_per_coord"] = occ
            out["levels_per_coord"] = 2 ** q.bits
        joint = torch.unique(codes, dim=0, return_counts=True)[1].double()
        pr = joint / joint.sum()
        out["distinct_messages"] = int(joint.numel())
        out["message_entropy_bits"] = float(-(pr * pr.log2()).sum())
        if q.mode in ("vq", "multi"):
            out["codebook_size"] = q.codebook_size
    msgs = [m for m in peg_messages(g, T, float_bits) if m["node"] == pm["quant"]]
    if msgs:
        out["bits_per_example"] = msgs[0]["bits_per_example"]
        out["positions"] = msgs[0]["positions"]
    g.train(was)
    return out


def bypass_report(g: GraphNet) -> dict:
    """For every peg: can information reach the output while avoiding it?
    Uses effective edges (gates at 0/1 remove edges); a bottleneck claim needs
    has_bypass == False."""
    out = {}
    for iid in pegs(g):
        q = g.implants[iid].meta["peg"]["quant"]
        if q not in g.nodes:
            out[iid] = {"present": False}
            continue
        out[iid] = {"present": True, "has_bypass": has_bypass(g, {q}, sources=[g.inputs.get("x")]),
                    "alpha": g.gate_vals.get(g.implants[iid].meta["peg"]["alpha"]),
                    "beta": g.gate_vals.get(g.implants[iid].meta["peg"]["beta"]) if g.implants[iid].meta["peg"]["beta"]
                    else None}
    return out


def query_isolation(g: GraphNet) -> dict:
    """T12: the late query stream 'q' must not reach any node that feeds a peg
    encoder (no path from q into the encoder side)."""
    if "q" not in g.inputs:
        return {"applicable": False}
    qn = g.inputs["q"]
    reach = g.descendants(qn) | {qn}
    bad = {}
    for iid in pegs(g):
        enc = g.implants[iid].meta["peg"]["enc"]
        if enc in g.nodes:
            anc = g.ancestors(enc) | {enc}
            if anc & reach:
                bad[iid] = sorted(anc & reach)
    return {"applicable": True, "query_reaches_encoder": bool(bad), "details": bad}


@torch.no_grad()
def narrow_peg(g: GraphNet, iid: str, k_new: int, X: dict, gen: torch.Generator) -> dict:
    """Narrow a peg from k to k_new coordinates (P5 'fit or narrow a peg').
    The code z (pre-quantisation) is projected on its top-k_new principal
    directions, measured on TRAINING calibration inputs X:
        z' = P (z - mu),   z_rec = P^T z' + mu
    A new quantiser of width k_new (same mode, recalibrated) replaces the old
    one; the decoder reads z_rec.  The projection is lossy by design; training
    afterwards recovers what it can.  Works after export (no bypass edges)."""
    from ..graph.ops import build_module
    from ..graph import edits as E
    pm = g.implants[iid].meta["peg"]
    q_old = pm["quant"]
    src = g.nodes[q_old].inputs[0]                 # encoder output (or a replacement module that emits codes)
    k = g.node_dim(q_old)
    if k_new >= k:
        return {"narrowed": False, "k": k}
    _, vals = g(X, return_nodes=[src])
    z = vals[src]
    Z = (z.permute(0, 2, 3, 1).reshape(-1, k) if g.layout == "img" else z.reshape(-1, k)).double()
    mu = Z.mean(0)
    _, S, Vh = torch.linalg.svd(Z - mu, full_matrices=False)
    P = Vh[:k_new]                                 # k_new x k
    dims = {kk: v for kk, v in g.nodes[q_old].attrs.items() if kk in ("hw", "T", "layout")}
    proj = g.add_node("linear", [src], {"in": k, "out": k_new, "bias": True, "dim": k_new, **dims}, owner=iid,
                      role="peg_narrow", build=True)
    E._set_weight(g, proj, P, -(P @ mu))
    qa = dict(g.nodes[q_old].attrs)
    qa["dim"] = k_new
    qn = g.add_node("quant", [proj], qa, owner=iid, role="peg_quant", build=True)
    unp = g.add_node("linear", [qn], {"in": k_new, "out": k, "bias": True, "dim": k, **dims}, owner=iid,
                     role="peg_unnarrow", build=True)
    E._set_weight(g, unp, P.T.contiguous(), mu)
    g.replace_uses(q_old, unp, exclude={unp})
    _, vals = g(X, return_nodes=[proj])
    zp = vals[proj]
    g.mods[g.nodes[qn].pkey].calibrate(zp.permute(0, 2, 3, 1).reshape(-1, k_new) if g.layout == "img"
                                       else zp.reshape(-1, k_new), gen=gen)
    E.prune_dead(g)
    pm.update({"quant": qn, "dim": k_new})
    g.implants[iid].nodes = [n for n in g.nodes if g.nodes[n].owner == iid]
    tot = (S ** 2).sum().clamp_min(1e-30)
    return {"narrowed": True, "from": k, "to": k_new, "explained": float((S[:k_new] ** 2).sum() / tot),
            "old_quant": q_old, "new_quant": qn}
