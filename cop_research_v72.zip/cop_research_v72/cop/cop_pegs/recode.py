"""v19 / v20 interface recoding (review: "change the internal code without changing its information").

For every middle pearl of a trained chain with uniform finite pegs (code_{i-1} -> code_i, the pearl reading
nothing but the incoming code), the pearl IS an exact finite map h from incoming to outgoing messages.  The job

  1. enumerates h over the whole incoming alphabet and checks it against the network's own outgoing codes on
     train / val / test, and checks that the exact table spliced back reproduces the reference network's
     per-example predictions (not only its loss).  Any failed check makes the run scientifically invalid
     before anything is fitted;
  2. relabels the messages by invertible maps of their bit vectors, P on the incoming side and / or Q on the
     outgoing side (identity, a bit permutation, the XOR chain y_j = x_j xor x_{j-1}, a random invertible GF(2)
     matrix, a random permutation of all codewords).  For every P, Q the finite identity
     Q^-1(h'(P(z))) = h(z) with h' = Q o h o P^-1 is verified for every input symbol, and the exact transformed
     table spliced back must reproduce the reference predictions;
  3. fits small replacement classes (logistic per output bit, one-hidden-layer MLPs) to the relabelled map in two
     regimes: `observed` (the training-reachable incoming messages, weighted by training frequency) and
     `full_alphabet` (every incoming message, uniform weights: the whole known finite map, a separate
     source-information condition, not a generalisation test).  Replacement initialisation has its own seed
     axis, paired across relabellings; `bitperm_symmetric` starts from the identity condition's initial model
     with its input columns and output rows permuted, so its trajectory must equal the identity condition's up
     to floating point (a symmetry control);
  4. splices every fit back as a lookup over the whole alphabet (incoming message -> P -> replacement -> Q^-1 ->
     canonical outgoing message).  This is a FUNCTIONAL EMULATOR: the original pearl still runs and its output
     is overridden; it is not a deployed compact network and says nothing about inference cost.

Every fit is saved (relabelling tables, architecture, weights, compiled table, test predictions) and reloadable;
the job is interruptible between and inside fits.  For the linear class, each output bit's linear separability
on the regime's support is decided by a linear program, so a failed fit can be read as optimisation / budget
(separable) or representation (not separable, for that class and support)."""
from __future__ import annotations

import math
import time
from pathlib import Path
from typing import Callable, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from ..config import seed_of
from ..experiments import common as C
from ..experiments.context import ScientificInvalid, Unsupported
from ..train.trainer import evaluate, predict
from ..utils import atomic_torch_save, interrupted, read_json, stable_hash, torch_gen
from .alternatives import code_nodes, quantizer_of, reference_chain, require_code_only_pearls
from .modules import SubgraphPearl, node_values
from .pegs import bypass_report

RELABELS = ("identity", "bitperm", "bitperm_symmetric", "xor_chain", "gf2_random", "codeword_perm")
SIDES = ("out", "in", "both")
REGIMES = ("observed", "full_alphabet")
MAX_ALPHABET = 1 << 14          # hard cap on enumerated alphabets (tables and LPs scale with it)


# ----------------------------------------------------------------------------- message <-> bits

def codes_to_index(c: torch.Tensor, levels: int) -> torch.Tensor:
    """(N, k) per-coordinate levels -> message index (first coordinate most significant)."""
    k = c.shape[1]
    radix = torch.tensor([levels ** (k - 1 - j) for j in range(k)], dtype=torch.long, device=c.device)
    return (c.long() * radix).sum(-1)


def index_to_levels(idx: torch.Tensor, levels: int, k: int) -> torch.Tensor:
    return torch.stack([(idx // (levels ** (k - 1 - j))) % levels for j in range(k)], 1)


def index_to_bits(idx: torch.Tensor, n_bits: int) -> torch.Tensor:
    """message index -> bit vector (most significant bit first); with levels = 2^b per coordinate the bits of a
    coordinate are contiguous, so a coordinate's binary code is a block of the vector."""
    sh = torch.arange(n_bits - 1, -1, -1, device=idx.device)
    return ((idx[:, None] >> sh) & 1).to(torch.uint8)


def bits_to_index(b: torch.Tensor) -> torch.Tensor:
    n = b.shape[1]
    w = (1 << torch.arange(n - 1, -1, -1, device=b.device)).long()
    return (b.long() * w).sum(-1)


def gf2_inverse(A: torch.Tensor) -> Optional[torch.Tensor]:
    """inverse of a square 0/1 matrix over GF(2), or None if singular (Gauss-Jordan)."""
    n = A.shape[0]
    M = torch.cat([A.clone().to(torch.uint8), torch.eye(n, dtype=torch.uint8)], 1)
    r = 0
    for c in range(n):
        piv = next((i for i in range(r, n) if M[i, c]), None)
        if piv is None:
            return None
        if piv != r:
            M[[r, piv]] = M[[piv, r]]
        for i in range(n):
            if i != r and M[i, c]:
                M[i] ^= M[r]
        r += 1
    return M[:, n:].clone()


class Relabel:
    """An invertible map on the n-bit messages, stored as a full permutation of the 2^n message indices
    (forward) with its inverse.  spec_bits: the compact specification a deployment could store (identity 0, a
    bit permutation n ceil(log2 n), a GF(2) matrix n^2, a codeword permutation 2^n n); table_bits: the two full
    lookup tables this implementation holds (2 x 2^n x n), reported separately."""

    def __init__(self, kind: str, n: int, gen: Optional[torch.Generator]):
        self.kind, self.n = kind, n
        N = 1 << n
        idx = torch.arange(N)
        b = index_to_bits(idx, n)
        self.perm = None
        if kind == "identity":
            fwd = idx.clone()
            self.spec_bits = 0
        elif kind in ("bitperm", "bitperm_symmetric"):
            self.perm = torch.randperm(n, generator=gen)          # new bit j = old bit perm[j]
            fwd = bits_to_index(b[:, self.perm])
            self.spec_bits = n * max(1, math.ceil(math.log2(max(2, n))))
        elif kind == "xor_chain":
            y = b.clone()
            y[:, 1:] = b[:, 1:] ^ b[:, :-1]
            fwd = bits_to_index(y)
            self.spec_bits = n * n
        elif kind == "gf2_random":
            for _ in range(1000):
                A = (torch.rand(n, n, generator=gen) < 0.5).to(torch.uint8)
                if gf2_inverse(A) is not None:
                    break
            else:
                raise RuntimeError("no invertible GF(2) matrix found")
            fwd = bits_to_index((b.long() @ A.T.long()) % 2)
            self.spec_bits = n * n
        elif kind == "codeword_perm":
            fwd = torch.randperm(N, generator=gen)
            self.spec_bits = N * n
        else:
            raise ValueError(kind)
        inv = torch.empty_like(fwd)
        inv[fwd] = idx
        if not torch.equal(torch.sort(fwd).values, idx):
            raise RuntimeError(f"relabel {kind} is not a bijection")
        self.fwd, self.inv = fwd, inv
        self.table_bits = 2 * N * n


# ----------------------------------------------------------------------------- replacement classes

def make_replacement(kind: str, n_in: int, n_out: int, gen: torch.Generator) -> nn.Module:
    if kind == "linear":
        m = nn.Linear(n_in, n_out)
    elif kind.startswith("mlp"):
        w = int(kind[3:])
        if w < 1:
            raise ValueError(f"MLP width must be positive: {kind}")
        m = nn.Sequential(nn.Linear(n_in, w), nn.ReLU(), nn.Linear(w, n_out))
    else:
        raise ValueError(kind)
    with torch.no_grad():
        for p in m.parameters():
            if p.dim() == 2:
                bound = 1.0 / math.sqrt(p.shape[1])
                p.copy_((torch.rand(p.shape, generator=gen) * 2 - 1) * bound)
            else:
                p.zero_()
    return m


def replacement_macs(kind: str, n_in: int, n_out: int) -> int:
    """analytic forward multiply-accumulates per example."""
    if kind == "linear":
        return n_in * n_out
    w = int(kind[3:])
    return n_in * w + w * n_out


def permute_model(m: nn.Module, perm_in: Optional[torch.Tensor], perm_out: Optional[torch.Tensor]) -> nn.Module:
    """the same function in permuted coordinates: M'(x[:, perm_in]) = M(x)[:, perm_out] (input columns of the
    first layer and output rows / biases of the last layer permuted)."""
    import copy
    m2 = copy.deepcopy(m)
    lins = [x for x in m2.modules() if isinstance(x, nn.Linear)]
    with torch.no_grad():
        if perm_in is not None:
            lins[0].weight.copy_(lins[0].weight[:, perm_in.to(lins[0].weight.device)])
        if perm_out is not None:
            po = perm_out.to(lins[-1].weight.device)
            lins[-1].weight.copy_(lins[-1].weight[po])
            lins[-1].bias.copy_(lins[-1].bias[po])
    return m2


def _validate_fit_inputs(X, Y, w) -> None:
    if X.dim() != 2 or Y.dim() != 2 or w.dim() != 1 or not (len(X) == len(Y) == len(w)):
        raise ValueError(f"recode fit: inconsistent shapes X {tuple(X.shape)} Y {tuple(Y.shape)} w {tuple(w.shape)}")
    if len(X) == 0:
        raise ValueError("recode fit: empty support")
    if not torch.isfinite(X.float()).all() or not torch.isfinite(w.double()).all():
        raise ValueError("recode fit: non-finite inputs or weights")
    if not bool(((Y == 0) | (Y == 1)).all()):
        raise ValueError("recode fit: targets are not bits")
    if bool((w < 0).any()) or not float(w.sum()) > 0:
        raise ValueError("recode fit: weights must be non-negative with a positive sum")


def curve_exact(c: dict, n_support: Optional[int] = None) -> bool:
    """v25: is a fit-curve evaluation exact?  From the integer count of wrong support messages when recorded;
    for records written before v25 (no count), from the unweighted exact fraction rounded to a count with the
    support size (exact iff fewer than half an example is wrong), never by comparing a float mean with 1.0."""
    if c.get("n_wrong") is not None:
        return int(c["n_wrong"]) == 0
    n = c.get("n_support") or n_support
    fr = c.get("exact_unweighted")
    if fr is None:
        return False
    if n:
        return int(round((1.0 - float(fr)) * int(n))) == 0
    return float(fr) >= 1.0 - 1e-9


def fit_replacement(kind: str, Xb: torch.Tensor, Yb: torch.Tensor, w: torch.Tensor, updates: int, lr: float,
                    every: int, gen: Optional[torch.Generator], device, init: Optional[nn.Module] = None,
                    resume: Optional[dict] = None, poll: Optional[Callable[[], bool]] = None,
                    save_partial: Optional[Callable[[dict], None]] = None) -> dict:
    """Full-batch Adam on weighted binary cross-entropy.  Exact = every output bit right; status:
      exact              some evaluation had every support message exact (first_exact_update)
      censored           finite throughout, never all exact within the budget
      numerical_failure  a non-finite logit, loss, gradient or parameter (failed step and cause recorded);
                         never scored as exact or as censoring
    poll / save_partial: interruption inside the fit (state saved, then KeyboardInterrupt); resume restores it."""
    _validate_fit_inputs(Xb, Yb, w)
    # v20.1: float64 throughout.  In float32 the summation order (which a coordinate permutation changes) gives
    # 1e-7 differences that Adam amplifies chaotically over hundreds of updates (an MLP's permuted and unpermuted
    # loss curves drift apart by ~1e-3); in float64 the drift stays far below the symmetry tolerance
    m = (init if init is not None else make_replacement(kind, Xb.shape[1], Yb.shape[1], gen)).to(
        device=device, dtype=torch.float64)
    X, Y, W = Xb.double().to(device), Yb.double().to(device), (w.double() / w.double().sum()).to(device)
    opt = torch.optim.Adam(m.parameters(), lr=lr)
    curve, first, u0, failure, seconds = [], None, 0, None, 0.0
    if resume is not None:
        m.load_state_dict(resume["state_dict"])
        opt.load_state_dict(resume["opt"])
        curve, first, u0, seconds = list(resume["curve"]), resume["first"], int(resume["u"]), float(resume["seconds"])
    t0 = time.time()

    def state(u):
        return {"state_dict": {k: v.detach().cpu().clone() for k, v in m.state_dict().items()},
                "opt": opt.state_dict(), "curve": list(curve), "first": first, "u": u,
                "seconds": seconds + time.time() - t0}
    u = u0
    while u <= updates:
        if poll is not None and poll():
            if save_partial is not None:
                save_partial(state(u))
            raise KeyboardInterrupt("interrupted inside a recode fit; state written")
        if u % every == 0 or u == updates:
            with torch.no_grad():
                lg = m(X)
                if not torch.isfinite(lg).all():
                    failure = {"update": u, "cause": "non-finite logits at evaluation"}
                    break
                okb = ((lg > 0) == (Y > 0.5)).all(1)
                ok = okb.double()
                # v25: exactness from an INTEGER count of wrong support messages (a floating mean of ones can come
                # out as 0.9999999999999999 on some devices)
                n_wrong = int((~okb).sum())
                lv = float((F.binary_cross_entropy_with_logits(lg, Y, reduction="none").mean(1) * W).sum())
            curve.append({"update": u, "exact_weighted": float((ok * W).sum()), "exact_unweighted": float(ok.mean()),
                          "n_wrong": n_wrong, "n_support": int(okb.numel()),
                          "loss": lv, "min_abs_logit": float(lg.abs().min())})
            if first is None and n_wrong == 0:
                first = u
        if u == updates:
            break
        lg = m(X)
        loss = (F.binary_cross_entropy_with_logits(lg, Y, reduction="none").mean(1) * W).sum()
        if not torch.isfinite(loss):
            failure = {"update": u, "cause": "non-finite loss"}
            break
        opt.zero_grad(set_to_none=True)
        loss.backward()
        if any(p.grad is not None and not torch.isfinite(p.grad).all() for p in m.parameters()):
            failure = {"update": u, "cause": "non-finite gradient"}
            break
        try:
            opt.step()
        except RuntimeError as ex:                             # e.g. an overflowing step size
            failure = {"update": u, "cause": f"optimizer step failed: {ex}"}
            break
        if any(not torch.isfinite(p).all() for p in m.parameters()):
            failure = {"update": u, "cause": "non-finite parameter after the update"}
            break
        u += 1
    seconds += time.time() - t0
    n_par = sum(p.numel() for p in m.parameters())
    exact_ev = [c["update"] for c in curve if curve_exact(c)]
    sustained = None
    if curve and curve_exact(curve[-1]):
        sustained = curve[-1]["update"]
        for c in reversed(curve):
            if not curve_exact(c):
                break
            sustained = c["update"]
    if failure is not None:
        status = "numerical_failure"
    else:
        status = "exact" if first is not None else "censored"
    last = curve[-1] if curve else {}
    return {"module": m, "curve": curve, "status": status, "failure": failure,
            "first_exact_update": first if failure is None else None,
            "sustained_exact_from": sustained if failure is None else None,
            "exact_lost_after_first": bool(failure is None and first is not None and sustained is None),
            "n_exact_evaluations": len(exact_ev),
            "final_exact_weighted": last.get("exact_weighted") if failure is None else None,
            "final_exact_unweighted": last.get("exact_unweighted") if failure is None else None,
            "updates_run": int(u), "params": int(n_par), "seconds": seconds}


def lp_separable(X: torch.Tensor, y: torch.Tensor) -> bool:
    """Is the 0/1 labelling y of the rows of X linearly separable (some w, b with (2y-1)(w.x + b) >= 1)?
    A linear-program feasibility check (scipy HiGHS).  Constant labellings are separable."""
    import numpy as np
    from scipy.optimize import linprog
    y = y.long().cpu().numpy()
    if y.min() == y.max():
        return True
    Xn = X.double().cpu().numpy()
    s = 2 * y - 1
    A = -(s[:, None] * np.hstack([Xn, np.ones((len(Xn), 1))]))
    res = linprog(np.zeros(Xn.shape[1] + 1), A_ub=A, b_ub=-np.ones(len(Xn)), bounds=[(None, None)] * (Xn.shape[1] + 1),
                  method="highs")
    if res.status not in (0, 2):
        raise RuntimeError(f"LP solver status {res.status}: {res.message}")
    return res.status == 0


def lp_controls() -> dict:
    """positive / negative controls of the separability check: copying a bit is separable; the parity of two bits
    over the whole 2-bit alphabet is not; the same parity restricted to the support {00, 01, 10} is."""
    X = index_to_bits(torch.arange(4), 2)
    copy = lp_separable(X, X[:, 0])
    xor_full = lp_separable(X, X[:, 0] ^ X[:, 1])
    xor_sub = lp_separable(X[:3], (X[:3, 0] ^ X[:3, 1]))
    return {"copy_separable": copy, "xor_full_alphabet_separable": xor_full, "xor_on_3_of_4_separable": xor_sub,
            "passed": copy and not xor_full and xor_sub}


# ----------------------------------------------------------------------------- splice, comparisons

def splice(ref, q_in: str, q_out: str, out_levels_table: torch.Tensor):
    """a clone of ref whose outgoing peg message is the lookup out_levels_table[incoming message index]
    (per-coordinate levels), turned into canonical values with the outgoing quantiser's range (the same formula
    as Quantizer.forward).  A functional emulator: the original pearl still runs, its output is overridden."""
    h = ref.clone(share_params=False)
    hqi, hqo = h.mods[h.nodes[q_in].pkey], h.mods[h.nodes[q_out].pkey]
    Li, Lo = 2 ** hqi.bits, 2 ** hqo.bits
    vals = out_levels_table.to(hqo.lo.dtype).to(hqo.lo.device) / (Lo - 1) * (hqo.hi - hqo.lo) + hqo.lo
    box = {}

    def grab(mod, inp, out):
        box["idx"] = codes_to_index(hqi.codes(out.reshape(-1, hqi.k)).reshape(-1, hqi.k), Li)

    def put(mod, inp, out):
        return vals.to(out.dtype)[box["idx"]].reshape(out.shape)
    h.hooks = [hqi.register_forward_hook(grab), hqo.register_forward_hook(put)]
    return h


_splice = splice      # v19 name


def compare_predictions(a: torch.Tensor, b: torch.Tensor, task: str, atol: float) -> dict:
    """per-example comparison of two prediction tensors on the same examples: maximum absolute difference,
    normalised by the reference's scale, and (classification) the fraction of examples whose predicted class
    differs.  passed: every example within atol x max(1, max |reference|)."""
    a, b = a.double().cpu(), b.double().cpu()
    if a.shape != b.shape:
        return {"passed": False, "reason": f"shape {tuple(a.shape)} vs {tuple(b.shape)}"}
    if not (torch.isfinite(a).all() and torch.isfinite(b).all()):
        return {"passed": False, "reason": "non-finite predictions"}
    d = (a - b).abs()
    scale = max(1.0, float(b.abs().max())) if b.numel() else 1.0
    out = {"max_abs_diff": float(d.max()) if d.numel() else 0.0,
           "max_abs_diff_normalised": (float(d.max()) / (float(b.std()) + 1e-12)) if d.numel() > 1 else 0.0,
           "tolerance": atol * scale}
    if task == "classification" and a.dim() == 2:
        out["class_disagreement"] = float((a.argmax(-1) != b.argmax(-1)).double().mean())
    out["passed"] = out["max_abs_diff"] <= out["tolerance"]
    return out


# ----------------------------------------------------------------------------- the plan

def plan_fits(cc: dict, pearls: list[int]) -> list[dict]:
    """every fit of the job, in a fixed order (resume and the result checker rely on it)."""
    out = []
    for i in pearls:
        for regime in cc["recode_regimes"]:
            for kind in cc["recode_relabels"]:
                rseeds = [0] if kind in ("identity", "xor_chain") else list(range(int(cc["recode_relabel_seeds"])))
                sides = ["none"] if kind == "identity" else list(cc["recode_sides"])
                for rs in rseeds:
                    for side in sides:
                        for cls in cc["recode_classes"]:
                            for fs in range(int(cc["recode_fit_seeds"])):
                                key = {"pearl": i, "regime": regime, "relabel": kind, "relabel_seed": rs,
                                       "side": side, "class": cls, "fit_seed": fs}
                                key["key"] = "|".join(str(key[k]) for k in ("pearl", "regime", "relabel",
                                                                            "relabel_seed", "side", "class",
                                                                            "fit_seed"))
                                out.append(key)
    return out


def relabels_for(cfg, i: int, kind: str, rs: int, side: str, n_in: int, n_out: int) -> tuple:
    """P (incoming) and Q (outgoing) for one condition.  The generator depends on the relabelling family (the
    symmetric control shares the bit permutation of `bitperm`), seed, pearl and side, never on regime, class or
    fit seed, so every fit of one condition sees the same code."""
    base = "bitperm" if kind == "bitperm_symmetric" else kind
    g_in = torch_gen(seed_of(cfg, "repair"), "repair", f"recode/p{i}/{base}/{rs}/in")
    g_out = torch_gen(seed_of(cfg, "repair"), "repair", f"recode/p{i}/{base}/{rs}/out")
    P = Relabel(kind if side in ("in", "both") else "identity", n_in, g_in)
    Q = Relabel(kind if side in ("out", "both") else "identity", n_out, g_out)
    return P, Q


def _fit_path(rd: Path, key: str) -> Path:
    return rd / "recode" / "fits" / f"{stable_hash(key, 20)}.pt"


# ----------------------------------------------------------------------------- the job

def run_recode(ctx) -> dict:
    cfg = ctx.cfg
    cc = cfg["cop"]
    bundle = C.setup_data(ctx)
    ref = reference_chain(ctx, bundle).eval()
    for p in ref.parameters():
        p.requires_grad_(False)
    codes = code_nodes(ref)
    if len(codes) < 2:
        raise Unsupported("recoding needs at least two pegs (one middle pearl)")
    if any(v.get("has_bypass") for v in bypass_report(ref).values()):
        raise Unsupported("recoding needs pegs without a path around them")
    require_code_only_pearls(ref, codes)
    qs = [quantizer_of(ref, c) for c in codes]
    if any(q.mode != "uniform" for q in qs):
        raise Unsupported("recoding is implemented for uniform finite pegs")
    batch = cfg["train"]["eval_batch"]
    task = bundle.task
    parts = ["train"] + [p for p in ("val", "test") if p in bundle.partitions()]
    allparts = bundle.partitions()
    ref_pred = {p: predict(ref, allparts[p], batch).detach().cpu() for p in parts}
    base_res, _ = evaluate(ref, bundle, [p for p in parts if p != "train"], batch)
    reference = {p: {k: v for k, v in base_res[p].items() if isinstance(v, (int, float))} for p in base_res}
    vals = {p: node_values(ref, allparts[p].X, codes) for p in parts}
    dev = qs[0].lo.device
    atol = float(cc["recode_pred_atol"])
    rd = ctx.dir
    (rd / "recode" / "fits").mkdir(parents=True, exist_ok=True)
    src = ctx.load_ckpt("reference_exported")
    source = {"chain_run": (cfg.get("parents") or {}).get("chain"), "stage": "final checkpoint of the parent job (its training endpoint; not validation-selected)",
              "reference_param_hash": src["lineage"].get("param_hash"), "graph_hash": ref.structural_hash()}
    checks = {"lp_controls": lp_controls(), "pearls": {}}
    pearls, rows, maps = [], [], {}
    for i in range(1, len(codes)):
        qi, qo = qs[i - 1], qs[i]
        Li, Lo = 2 ** qi.bits, 2 ** qo.bits
        n_in, n_out = qi.k * qi.bits, qo.k * qo.bits
        if n_in > int(cc["recode_max_bits"]) or n_out > int(cc["recode_max_bits"]) or (1 << n_in) > MAX_ALPHABET:
            rows.append({"pearl": i, "status": "skipped",
                         "reason": f"messages of {n_in} / {n_out} bits exceed recode_max_bits / the alphabet cap"})
            continue
        # 1. the exact map over the whole incoming alphabet and the network's own codes
        grid_idx = torch.arange(Li ** qi.k, device=dev)
        lev = index_to_levels(grid_idx, Li, qi.k)
        z = lev.to(qi.lo.dtype) / (Li - 1) * (qi.hi - qi.lo) + qi.lo
        with torch.no_grad():
            v = SubgraphPearl(ref, codes[i - 1], codes[i])(z.to(next(ref.parameters()).dtype))
        h_lev = qo.codes(v.reshape(-1, qo.k)).reshape(-1, qo.k)
        h_idx = codes_to_index(h_lev, Lo)
        cin, cout = {}, {}
        for p in parts:
            cin[p] = codes_to_index(qi.codes(vals[p][codes[i - 1]].reshape(-1, qi.k)).reshape(-1, qi.k), Li)
            cout[p] = codes_to_index(qo.codes(vals[p][codes[i]].reshape(-1, qo.k)).reshape(-1, qo.k), Lo)
        agree = {p: float((h_idx[cin[p]] == cout[p]).double().mean()) for p in parts}
        mism = {p: int((h_idx[cin[p]] != cout[p]).sum()) for p in parts}       # v25: integer counts decide
        reach, cnt = torch.unique(cin["train"], return_counts=True)
        Yr = index_to_bits(h_idx[reach], n_out).double()
        frq = cnt.double() / cnt.sum()
        pearl = {"pearl": i, "in_bits": n_in, "out_bits": n_out, "in_alphabet": int(Li ** qi.k),
                 "reachable_in_messages_train": int(len(reach)),
                 "distinct_out_messages_train": int(len(torch.unique(cout["train"]))),
                 "support_frequency_entropy_bits": float(-(frq * frq.log2()).sum()),
                 "target_bit_balance_observed": [float(x) for x in (frq[:, None] * Yr).sum(0)],
                 "map_agreement": agree, "map_mismatches": mism,
                 **{f"{p}_messages_unseen_in_train": float((~torch.isin(cin[p], reach)).double().mean())
                    for p in parts if p != "train"}}
        # the exact table spliced back must reproduce the reference per example
        ex = splice(ref, codes[i - 1], codes[i], h_lev)
        cmp_exact = {p: compare_predictions(predict(ex, allparts[p], batch).detach(), ref_pred[p], task, atol)
                     for p in parts}
        pc = {"map_matches_network_codes": all(v == 0 for v in mism.values()),
              "exact_table_reproduces_predictions": all(c["passed"] for c in cmp_exact.values()),
              "exact_splice": cmp_exact, "transformed_identities": {}}
        # 2. every P, Q of the plan: Q^-1(h'(P(z))) = h(z) for every symbol, and the exact transformed table
        conds = sorted({(k["relabel"], k["relabel_seed"], k["side"]) for k in plan_fits(cc, [i])})
        for kind, rs, side in conds:
            P, Q = relabels_for(cfg, i, kind, rs, side, n_in, n_out)
            Pf, Pi, Qf, Qi = P.fwd.to(dev), P.inv.to(dev), Q.fwd.to(dev), Q.inv.to(dev)
            hprime = Qf[h_idx[Pi[grid_idx]]]                      # h' indexed by the transformed incoming symbol
            back = Qi[hprime[Pf[grid_idx]]]
            ok_id = bool(torch.equal(back, h_idx))
            spl = splice(ref, codes[i - 1], codes[i], index_to_levels(back, Lo, qo.k))
            cmp_t = compare_predictions(predict(spl, allparts["test"] if "test" in allparts else allparts["val"],
                                                batch).detach(),
                                        ref_pred["test" if "test" in ref_pred else "val"], task, atol)
            pc["transformed_identities"][f"{kind}/{rs}/{side}"] = {"identity_holds": ok_id,
                                                                    "splice_reproduces": cmp_t["passed"],
                                                                    "max_abs_diff": cmp_t.get("max_abs_diff")}
        pc["passed"] = pc["map_matches_network_codes"] and pc["exact_table_reproduces_predictions"] and all(
            x["identity_holds"] and x["splice_reproduces"] for x in pc["transformed_identities"].values())
        checks["pearls"][str(i)] = pc
        pearls.append(pearl)
        maps[i] = {"h_lev": h_lev.cpu(), "h_idx": h_idx.cpu(), "reach": reach.cpu(), "count": cnt.cpu(),
                   "cin": {p: cin[p].cpu() for p in parts}, "q_in": [codes[i - 1], int(qi.bits), int(qi.k)],
                   "q_out": [codes[i], int(qo.bits), int(qo.k)],
                   "ranges": {"in_lo": qi.lo.cpu(), "in_hi": qi.hi.cpu(), "out_lo": qo.lo.cpu(), "out_hi": qo.hi.cpu()}}
        atomic_torch_save({"source": source, **maps[i]}, rd / "recode" / f"map_p{i}.pt")
    checks["passed"] = checks["lp_controls"]["passed"] and bool(pearls) and all(
        pc["passed"] for pc in checks["pearls"].values())
    ctx.save_json("recode_checks.json", checks)
    if not pearls:
        raise Unsupported("no middle pearl could be recoded (all skipped)")
    if not checks["passed"]:
        raise ScientificInvalid("recoding validity checks failed (map / exact splice / transformed identity / LP "
                                "controls); nothing was fitted", {"recode_checks": checks})
    # 3-4. fits, persisted one by one; resumable between and inside fits
    plan = plan_fits(cc, [p["pearl"] for p in pearls])
    ctx.save_json("recode_plan.json", {"n_fits": len(plan), "fits": [k["key"] for k in plan]})
    lp_cache, init_cache = {}, {}
    records = {}
    for k in plan:
        fp = _fit_path(rd, k["key"])
        if fp.exists():
            records[k["key"]] = torch.load(fp, map_location="cpu", weights_only=False)["record"]
            continue
        i = k["pearl"]
        mp = maps[i]
        qi, qo = qs[i - 1], qs[i]
        Li, Lo = 2 ** qi.bits, 2 ** qo.bits
        n_in, n_out = qi.k * qi.bits, qo.k * qo.bits
        P, Q = relabels_for(cfg, i, k["relabel"], k["relabel_seed"], k["side"], n_in, n_out)
        Pf, Qf, Qi = P.fwd.to(dev), Q.fwd.to(dev), Q.inv.to(dev)
        h_idx = mp["h_idx"].to(dev)
        if k["regime"] == "observed":
            sup, wts = mp["reach"].to(dev), mp["count"].double().to(dev)
        else:
            sup = torch.arange(Li ** qi.k, device=dev)
            wts = torch.ones(len(sup), dtype=torch.float64, device=dev)
        Xb = index_to_bits(Pf[sup], n_in)
        Yb = index_to_bits(Qf[h_idx[sup]], n_out)
        cls = k["class"]
        ik = (i, k["regime"], cls, k["fit_seed"])
        if ik not in init_cache:
            gtr = torch_gen(seed_of(cfg, "repair"), "repair", f"recode/p{i}/{k['regime']}/{cls}/fit{k['fit_seed']}")
            init_cache[ik] = make_replacement(cls, n_in, n_out, gtr)
        init = init_cache[ik]
        if k["relabel"] == "bitperm_symmetric":
            init = permute_model(init, P.perm, Q.perm)               # the identity condition's model, permuted
        else:
            import copy
            init = copy.deepcopy(init)                              # paired initialisation across relabellings
        partial = fp.with_suffix(".partial.pt")
        resume = torch.load(partial, map_location="cpu", weights_only=False) if partial.exists() else None
        try:
            fit = fit_replacement(cls, Xb, Yb, wts, int(cc["recode_updates"]), float(cc["recode_lr"]),
                                  int(cc["recode_eval_every"]), None, dev, init=init, resume=resume,
                                  poll=interrupted, save_partial=lambda st: atomic_torch_save(st, partial))
        except ValueError as ex:
            raise ScientificInvalid(f"recode fit inputs invalid for {k['key']}: {ex}", {"fit": k})
        # full-alphabet replacement output -> compiled table, with its own finiteness check
        with torch.no_grad():
            lg = fit["module"](index_to_bits(Pf[torch.arange(Li ** qi.k, device=dev)], n_in).double())
        compiled = None
        if fit["status"] != "numerical_failure" and not torch.isfinite(lg).all():
            fit["status"], fit["failure"] = "numerical_failure", {"update": fit["updates_run"],
                                                                  "cause": "non-finite full-alphabet output"}
            for f_ in ("first_exact_update", "sustained_exact_from", "final_exact_weighted", "final_exact_unweighted"):
                fit[f_] = None
        rec = {**{x: k[x] for x in ("key", "pearl", "regime", "relabel", "relabel_seed", "side", "class", "fit_seed")},
               "status": fit["status"], "failure": fit["failure"], "params": fit["params"],
               "updates": int(cc["recode_updates"]), "updates_run": fit["updates_run"],
               "support_size": int(len(sup)), "first_exact_update": fit["first_exact_update"],
               "sustained_exact_from": fit["sustained_exact_from"], "exact_lost_after_first": fit["exact_lost_after_first"],
               "censored": fit["status"] == "censored", "n_exact_evaluations": fit["n_exact_evaluations"],
               "final_exact_weighted": fit["final_exact_weighted"], "final_exact_unweighted": fit["final_exact_unweighted"],
               "compensation_spec_bits_in": P.spec_bits, "compensation_spec_bits_out": Q.spec_bits,
               "compensation_table_bits_in": P.table_bits if P.kind != "identity" else 0,
               "compensation_table_bits_out": Q.table_bits if Q.kind != "identity" else 0,
               "fit_seconds": fit["seconds"], "fit_examples": int(fit["updates_run"]) * int(len(sup)),
               # v22: the smallest |logit| (a bit decided by a tiny margin can flip under tiny numerical changes)
               "final_min_abs_logit_support": fit["curve"][-1].get("min_abs_logit") if fit["curve"] else None,
               "min_abs_logit_full_alphabet": float(lg.abs().min()) if bool(torch.isfinite(lg).all()) else None,
               "replacement_dtype": str(next(fit["module"].parameters()).dtype).replace("torch.", ""),
               "reference_dtype": str(next(ref.parameters()).dtype).replace("torch.", ""), "device": str(dev),
               "fit_macs": 3 * replacement_macs(cls, n_in, n_out) * int(fit["updates_run"]) * int(len(sup)),
               "curve": fit["curve"]}
        test_pred = None
        if fit["status"] != "numerical_failure":
            pb = (lg > 0).to(torch.uint8)
            out_idx = Qi[bits_to_index(pb)]
            compiled = index_to_levels(out_idx, Lo, qo.k).to(torch.int16).cpu()
            spl = splice(ref, codes[i - 1], codes[i], compiled.to(dev).long())
            res_s, preds = evaluate(spl, bundle, [p for p in parts if p != "train"], batch, return_preds=True)
            for p in [p for p in parts if p != "train"]:
                rec[f"{p}_messages_exact"] = float((out_idx[mp["cin"][p].to(dev)] ==
                                                    h_idx[mp["cin"][p].to(dev)]).double().mean())
                for k_, v_ in res_s[p].items():
                    if isinstance(v_, (int, float)):
                        rec[f"{p}_{k_}"] = v_
                # v25: downstream-output preservation beside message exactness: does the spliced network make the
                # reference network's decisions (classification) / outputs (regression) on this partition?
                if p in ref_pred and p in preds:
                    a_, b_ = preds[p].detach().double().cpu(), ref_pred[p].double()
                    if a_.shape == b_.shape:
                        if task == "classification" and a_.dim() == 2:
                            rec[f"{p}_decision_agreement_with_reference"] = float((a_.argmax(-1) == b_.argmax(-1))
                                                                                  .double().mean())
                            rec[f"{p}_decision_mismatches_with_reference"] = int((a_.argmax(-1) != b_.argmax(-1)).sum())
                        rec[f"{p}_output_rms_diff_from_reference"] = float(((a_ - b_) ** 2).mean().sqrt())
            tp = "test" if "test" in preds else "val"
            test_pred = preds[tp].detach().cpu()
            rec["saved_prediction_partition"] = tp
            rec["eval_batch"] = int(batch)
        if cls == "linear":
            lk = (i, k["regime"], k["relabel"], k["relabel_seed"], k["side"])
            if lk not in lp_cache:
                lp_cache[lk] = [lp_separable(Xb, Yb[:, j]) for j in range(Yb.shape[1])]
            sep = lp_cache[lk]
            rec["lp_separable_bits"] = int(sum(sep))
            rec["lp_all_bits_separable"] = bool(all(sep))
            if fit["status"] in ("exact", "censored"):
                rec["linear_reading"] = ("fits" if fit["status"] == "exact" else
                                         "optimisation / budget (every bit separable)" if all(sep) else
                                         "representational for the linear class on this support")
        art = {"record": rec, "key": k, "P_fwd": P.fwd.to(torch.int32), "P_inv": P.inv.to(torch.int32),
               "Q_fwd": Q.fwd.to(torch.int32), "Q_inv": Q.inv.to(torch.int32),
               "relabel_spec": {"kind": k["relabel"], "seed": k["relabel_seed"], "side": k["side"],
                                "bit_perm_in": None if P.perm is None else P.perm.tolist(),
                                "bit_perm_out": None if Q.perm is None else Q.perm.tolist()},
               "arch": {"class": cls, "n_in": n_in, "n_out": n_out, "dtype": "float64"},
               "state_dict": {x: y.detach().cpu() for x, y in fit["module"].state_dict().items()},
               "compiled_table": compiled, "test_predictions": test_pred,
               "map_source": str(Path("recode") / f"map_p{i}.pt")}
        atomic_torch_save(art, fp)
        partial.unlink(missing_ok=True)
        records[k["key"]] = rec
    rows += [records[k["key"]] for k in plan]
    # the symmetry control: bitperm_symmetric must follow the identity condition's trajectory.  v23: every
    # expected pair is accounted for: checked (passed / failed / inconclusive) or unavailable (a numerical failure
    # on either side, or no identity fit); an empty or partly unavailable set is never a pass by default
    sym, unavailable = [], []
    tol = float(cc["recode_symmetry_rtol"])
    ident_all = {(r["pearl"], r["regime"], r["class"], r["fit_seed"]): r for r in rows if r.get("relabel") == "identity"}
    expected = [r for r in rows if r.get("relabel") == "bitperm_symmetric"]
    for r in expected:
        base = ident_all.get((r["pearl"], r["regime"], r["class"], r["fit_seed"]))
        if base is None or base.get("status") == "numerical_failure" or r.get("status") == "numerical_failure":
            unavailable.append({"key": r["key"], "reason": "no identity fit" if base is None else
                                "numerical failure of the identity fit" if base.get("status") == "numerical_failure"
                                else "numerical failure of the permuted fit"})
            continue
        la = [c["loss"] for c in r["curve"]]
        lb = [c["loss"] for c in base["curve"]]
        diff = max((abs(x - y) for x, y in zip(la, lb)), default=0.0) if len(la) == len(lb) else float("inf")
        scale_l = max(1e-12, max(abs(y) for y in lb)) if lb else 1.0
        rel = diff / scale_l if lb else 0.0
        r["symmetry_max_loss_diff"] = diff
        # the final PARAMETERS too: the permuted fit's weights must equal the identity fit's weights with the same
        # permutation applied.  This is a necessary consequence of covariant gradients and optimizer steps, not a
        # proof that they agreed at every update (tests/test_v23 checks gradients and Adam moments directly)
        pdiff = None
        try:
            A = torch.load(_fit_path(rd, base["key"]), map_location="cpu", weights_only=False)
            Bf = torch.load(_fit_path(rd, r["key"]), map_location="cpu", weights_only=False)
            spec = Bf["relabel_spec"]
            ma = make_replacement(A["arch"]["class"], A["arch"]["n_in"], A["arch"]["n_out"],
                                  torch.Generator().manual_seed(0)).double()
            ma.load_state_dict(A["state_dict"])
            pin = None if spec["bit_perm_in"] is None else torch.tensor(spec["bit_perm_in"])
            pout = None if spec["bit_perm_out"] is None else torch.tensor(spec["bit_perm_out"])
            sa = permute_model(ma, pin, pout).state_dict()
            sb = Bf["state_dict"]
            scale = max(1e-12, max(float(v.double().abs().max()) for v in sa.values()))
            pdiff = max(float((sa[k].double() - sb[k].double()).abs().max()) for k in sa) / scale
        except (OSError, KeyError, RuntimeError) as ex:
            pdiff = None
            r["symmetry_param_check_error"] = f"{type(ex).__name__}: {ex}"
        r["symmetry_param_rel_diff"] = pdiff
        cont_ok = rel <= tol and pdiff is not None and pdiff <= tol
        same_status = r["status"] == base["status"]
        same_first = r["first_exact_update"] == base["first_exact_update"]
        # discrete outcomes: a different status or first observed exact update with continuous agreement can only
        # come from a bit decided by a tiny margin; it is INCONCLUSIVE when the smallest |logit| of either fit was
        # below 1e-6 at some evaluation, otherwise a failure
        min_margin = min([c.get("min_abs_logit", float("inf")) for c in r["curve"] + base["curve"]] or [float("inf")])
        discrete_ok = same_status and same_first
        verdict = ("passed" if cont_ok and discrete_ok else
                   "inconclusive_tiny_margin" if cont_ok and min_margin < 1e-6 else "failed")
        sym.append({"key": r["key"], "max_loss_diff": diff, "loss_scale": scale_l, "relative": rel,
                    "param_relative": pdiff, "tolerance": f"relative <= {tol} (loss: by the identity curve's largest "
                                                          f"loss; parameters: by the largest identity weight)",
                    "same_status": same_status, "same_first_exact_update": same_first,
                    "min_abs_logit_either_fit": min_margin, "verdict": verdict, "passed": verdict == "passed"})
    n_failed = sum(x["verdict"] == "failed" for x in sym)
    checks["symmetry_control"] = {"n_expected": len(expected), "n": len(sym), "n_checked": len(sym),
                                  "n_failed": n_failed,
                                  "n_inconclusive": sum(x["verdict"] == "inconclusive_tiny_margin" for x in sym),
                                  "n_unavailable": len(unavailable), "unavailable": unavailable,
                                  "passed": bool(n_failed == 0 and (len(expected) == 0 or len(sym) > 0)),
                                  "complete": len(sym) == len(expected), "rows": sym}
    ctx.save_json("recode_checks.json", checks)
    fits = [r for r in rows if "class" in r]
    ctx.set_work("recode_fits", {"updates": sum(r["updates_run"] for r in fits),
                                 "examples": sum(r["fit_examples"] for r in fits),
                                 "macs": sum(r["fit_macs"] for r in fits),
                                 "seconds": sum(r["fit_seconds"] for r in fits), "macs_complete": True,
                                 "recorded_from": "completed fit records (idempotent across resumes)"})
    out = {"reference": reference, "source": source, "pearls": pearls, "checks": checks, "n_planned_fits": len(plan),
           "rows": rows,
           "note": "relabelled maps of ONE reference carry the same information; compensation reported as compact "
                   "specification bits and as full table bits; an exact lookup always fits, so the comparison is the "
                   "fitting difficulty of the same information. Spliced replacements are functional emulators, not "
                   "deployed compact networks."}
    ctx.save_json("recode_result.json", out)
    for r in fits:
        if r.get("final_exact_weighted") is not None:
            ctx.metric(f"recode_p{r['pearl']}", r["regime"],
                       f"{r['relabel']}/{r['relabel_seed']}/{r['side']}/{r['class']}/f{r['fit_seed']}.exact_weighted",
                       r["final_exact_weighted"], ref.structural_hash())
    if not checks["symmetry_control"]["passed"]:
        raise ScientificInvalid("recoding symmetry control failed: the permuted fit did not follow the identity fit",
                                {"symmetry_control": checks["symmetry_control"]})
    return {"n_rows": len(fits), "n_pearls": len(pearls)}


# ----------------------------------------------------------------------------- verification (checker, reload)

def verify_recode_result(rd: Path) -> dict:
    """acceptance check of one complete recode job: controls present and passed, a nonempty plan, at least one
    checked pearl, every planned fit with a record and a saved artifact, and no record outside the declared
    statuses.  Returns {"passed", "failures", counts}."""
    rd = Path(rd)
    fails = []
    p = rd / "recode_result.json"
    if not p.exists():
        return {"passed": False, "failures": ["recode_result.json missing"]}
    j = read_json(p)
    ch = j.get("checks") or {}
    if not ch.get("passed"):
        fails.append("validity checks missing or failed")
    if not (ch.get("lp_controls") or {}).get("passed"):
        fails.append("LP controls missing or failed")
    sc = ch.get("symmetry_control") or {}
    if not sc.get("passed", False):
        fails.append("symmetry control missing or failed")
    if sc.get("n_unavailable"):
        fails.append(f"symmetry control unavailable for {sc['n_unavailable']} expected pairs (numerical failure or "
                     f"missing identity fit): not a passed check")
    if not j.get("pearls"):
        fails.append("no checked pearl")
    plan = read_json(rd / "recode_plan.json") if (rd / "recode_plan.json").exists() else None
    if not plan or not plan.get("n_fits"):
        fails.append("empty or missing fit plan")
    fits = [r for r in j.get("rows") or [] if "class" in r]
    if plan and len(fits) != plan["n_fits"]:
        fails.append(f"{len(fits)} fit records for {plan['n_fits']} planned fits")
    bad_status = [r["key"] for r in fits if r.get("status") not in ("exact", "censored", "numerical_failure")]
    if bad_status:
        fails.append(f"undeclared fit status in {bad_status[:3]}")
    missing = [r["key"] for r in fits if not _fit_path(rd, r["key"]).exists()]
    if missing:
        fails.append(f"{len(missing)} fit artifacts missing, e.g. {missing[:2]}")
    return {"passed": not fails, "failures": fails, "n_fits": len(fits),
            "n_numerical_failures": sum(r.get("status") == "numerical_failure" for r in fits),
            "n_pearls": len(j.get("pearls") or []),
            "n_skipped_pearls": sum(1 for r in j.get("rows") or [] if r.get("status") == "skipped")}


def reload_recode(rd: Path, bundle, device="cpu", atol: float = 0.0) -> dict:
    """fresh-process reload of every saved fit: rebuild the replacement from its architecture and weights,
    recompute its full-alphabet output and compare with the saved compiled table, then splice that table into
    the saved reference network and reproduce the saved predictions.  Missing or altered artifacts fail.
    v25: device="recorded" reloads every fit on the device that fit was computed on (its record's `device`; a job
    resumed on another device has fits from both): the comparison is bitwise by default, and a different device
    is a different computation.  A recorded device that is unavailable here fails that fit with its reason."""
    from ..graph.graph import GraphNet
    rd = Path(rd)
    plan = read_json(rd / "recode_plan.json")
    ref_ck = torch.load(rd / "ckpt" / "reference_exported.pt", map_location="cpu", weights_only=False)
    refs: dict = {}

    def ref_on(dev):
        if dev not in refs:
            refs[dev] = GraphNet.from_checkpoint(ref_ck["model"], dev).eval()
        return refs[dev]
    n_checked, n_skipped, failures, by_device = 0, 0, [], {}
    batch = 4096
    for key in plan["fits"]:
        fp = _fit_path(rd, key)
        if not fp.exists():
            failures.append({"fit": key, "reason": "artifact missing"})
            continue
        a = torch.load(fp, map_location="cpu", weights_only=False)
        rec = a["record"]
        if rec.get("status") == "numerical_failure":
            n_skipped += 1
            continue
        dev = str(rec.get("device") or "cpu") if device == "recorded" else str(device)
        if dev.startswith("cuda") and not torch.cuda.is_available():
            failures.append({"fit": key, "reason": f"recorded device {dev} is not available here"})
            continue
        by_device[dev] = by_device.get(dev, 0) + 1
        mp = torch.load(rd / a["map_source"], map_location="cpu", weights_only=False)
        ar = a["arch"]
        m = make_replacement(ar["class"], ar["n_in"], ar["n_out"], torch.Generator().manual_seed(0))
        sd_dt = next(iter(a["state_dict"].values())).dtype if a["state_dict"] else torch.float32
        m = m.to(sd_dt)                                          # the fit's own precision (float64 from v20.1)
        try:
            m.load_state_dict(a["state_dict"])
        except Exception as ex:                                  # noqa: BLE001
            failures.append({"fit": key, "reason": f"weights do not load: {ex}"})
            continue
        m = m.to(dev)
        qin, qout = mp["q_in"], mp["q_out"]
        Li, Lo = 2 ** qin[1], 2 ** qout[1]
        n_sym = Li ** qin[2]
        with torch.no_grad():
            lg = m(index_to_bits(a["P_fwd"].long()[torch.arange(n_sym)], ar["n_in"]).to(device=dev, dtype=sd_dt))
        out_idx = a["Q_inv"].long()[bits_to_index((lg > 0).to(torch.uint8)).cpu()]
        table = index_to_levels(out_idx, Lo, qout[2]).to(torch.int16)
        if a["compiled_table"] is None or not torch.equal(table.cpu(), a["compiled_table"]):
            failures.append({"fit": key, "device": dev,
                             "reason": "replacement output differs from the saved compiled table"})
            continue
        part = bundle.partitions()[rec.get("saved_prediction_partition", "test")].to(dev)
        spl = splice(ref_on(dev), qin[0], qout[0], table.to(dev).long())
        pr = predict(spl, part, int(rec.get("eval_batch", batch))).detach().cpu()
        if a["test_predictions"] is None or pr.shape != a["test_predictions"].shape or \
                float((pr.double() - a["test_predictions"].double()).abs().max()) > atol:
            failures.append({"fit": key, "device": dev, "reason": "spliced predictions differ from the saved ones"})
            continue
        n_checked += 1
    return {"expected": len(plan["fits"]), "checked": n_checked, "skipped_numerical_failure": n_skipped,
            "failed": len(failures), "failures": failures[:20], "checked_by_device": by_device,
            "device_policy": "each fit on its recorded device" if device == "recorded" else f"all fits on {device}"}
