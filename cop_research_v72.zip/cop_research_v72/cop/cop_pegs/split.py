"""P4: recursively split a difficult pearl.

1. Hard pearl: for each middle pearl, a small replacement is fitted locally on
   TRAINING teacher codes; the pearl with the largest VALIDATION local error is
   selected (selection never uses test data).
2. Variants for that pearl, all trained locally (teacher input code -> teacher
   output code) with equal update budgets:
     one_large       a single MLP
     chain_s         s sub-pearls with (s-1) intermediate codes of width peg.dim
     chain_s_shared  one sub-pearl module applied s times (parameters once,
                     compute s times) between input/output projections
   split_budget='matched': one_large width chosen so its parameters match the
   chain; 'unconstrained': a width sweep for both, reported as a frontier.
   The variant's OUTPUT passes the destination peg's interface (its quantiser,
   straight-through in training) when cop.interface_enforce='enforced'.  The
   intermediate codes inside a chain variant are continuous and are accounted
   at peg.float_bits per coordinate.
3. Each variant is swapped into the reference chain (test risk) and its total
   cost is reported: parameters, MACs per position (repeated execution counted),
   internal communication.
4. Local learnability: every sub-pearl of a trained chain is re-fitted from
   scratch on its own (input, output) codes; its validation error indicates
   whether the decomposition made each local map easier.
All local fits use the `train` section's optimizer policy and are resumable at
step granularity.  Every trained variant, sub-pearl refit and the swapped test
predictions are saved (split_modules.pt / split_predictions.pt) and can be
reloaded in a fresh process with `reload_split`.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import torch
import torch.nn.functional as F

from ..config import seed_of
from ..graph.ops import MLPModule, init_module
from ..train import metrics as M
from ..train.trainer import LocalOpt, local_policy
from ..utils import torch_gen, tensor_hash, atomic_torch_save
from ..experiments import common as C
from ..experiments.context import Unsupported, ScientificInvalid, JobState, local_loop
from .alternatives import reference_chain, code_nodes, require_code_only_pearls, Assembly, Interface, \
    quantizer_of, MEMBERSHIP_TOL, _module_record, _build_from_record
from .modules import ChainModule, node_values, make_alt


def _fit(ctx, js, key, mod, Xin, Y, n, gen, iface=None):
    """Local regression mod(Xin) -> Y (through the destination interface)."""
    tcfg = ctx.cfg["train"]
    N = Xin.shape[0]
    B = min(tcfg["batch_size"], N)
    lopt = LocalOpt([p for p in mod.parameters() if p.requires_grad], tcfg, n)
    f = (lambda x: iface(mod(x))) if iface is not None else mod

    def step(k):
        idx = torch.randint(0, N, (B,), generator=gen).to(Xin.device)
        return F.mse_loss(f(Xin[idx]), Y[idx])
    return local_loop(ctx, js, key, {"m": mod}, lopt, gen, n, step, phase="split_local_fit", examples_per_step=B)


@torch.no_grad()
def _rel(f, Xin, Y):
    return float(F.mse_loss(f(Xin), Y) / Y.var().clamp_min(1e-12))


def mlp_params(k_in, w, k_out):
    return k_in * w + w + w * k_out + k_out


def _variant_attrs(name: str, mod) -> dict:
    if isinstance(mod, ChainModule):
        return {"module_type": "chain", "module_args": {"k_in": mod.k_in, "k_mid": mod.k_mid, "k_out": mod.k_out,
                                                        "s": mod.s, "width": mod.width, "layout": mod.layout,
                                                        "shared": mod.shared}}
    return {"module_type": "mlp", "module_args": {"d_in": mod.layers[0].in_features,
                                                  "hidden": [l.out_features for l in mod.layers[:-1]],
                                                  "d_out": mod.layers[-1].out_features, "act": mod.act,
                                                  "layout": mod.layout}}


def run_split(ctx) -> dict:
    cfg = ctx.cfg
    cc = cfg["cop"]
    bundle = C.setup_data(ctx)
    ref = reference_chain(ctx, bundle).eval()
    for p in ref.parameters():
        p.requires_grad_(False)
    if ref.layout == "img":
        raise Unsupported("P4 split is implemented for vector/sequence pearls (per-position modules)")
    codes = code_nodes(ref)
    if len(codes) < 2:
        raise Unsupported("need at least one middle pearl (two pegs)")
    require_code_only_pearls(ref, codes)
    enforce = cc["interface_enforce"] == "enforced"
    ifaces = {i: Interface(quantizer_of(ref, cn), enforce, ref.layout).to(ctx.device) for i, cn in enumerate(codes)}
    T_tr = node_values(ref, bundle.train.X, codes)
    T_va = node_values(ref, bundle.val.X, codes)
    ctx.count_work("teacher_code_forward", forward_examples=len(bundle.train) + len(bundle.val))
    dev = ctx.device
    n_loc = cc["local_updates"]
    js = JobState(ctx, "split")
    gen = lambda key: torch_gen(seed_of(cfg, "peg"), "peg", "split", key)
    # 1. hard pearl selection on validation
    sel = {}
    for i in range(1, len(codes)):
        m, _ = make_alt("mlp_small", ref.layout, ref.node_dim(codes[i - 1]), ref.node_dim(codes[i]), cc["pearl_width"])
        init_module(m, gen(f"sel{i}"), "default")
        m.to(dev)
        _fit(ctx, js, f"sel/{i}", m, T_tr[codes[i - 1]], T_tr[codes[i]], n_loc, gen(f"selb{i}"), ifaces[i])
        sel[i] = _rel(lambda x: ifaces[i](m(x)), T_va[codes[i - 1]], T_va[codes[i]])
    hard = max(sel, key=lambda i: (sel[i], -i))
    ctx.save_json("split_selection.json", {"val_local_error": sel, "hard": hard, "selection_data": "validation codes"})
    k_in, k_out = ref.node_dim(codes[hard - 1]), ref.node_dim(codes[hard])
    k_mid = cfg["peg"]["dim"]
    s = cc["split_into"]
    Xtr, Ytr = T_tr[codes[hard - 1]], T_tr[codes[hard]]
    Xva, Yva = T_va[codes[hard - 1]], T_va[codes[hard]]
    T = C.seq_T(bundle)
    fb = cfg["peg"]["float_bits"]
    out_if = ifaces[hard]
    variants = []
    widths = [cc["pearl_width"]] if cc["split_budget"] == "matched" else [8, 16, 32, 64, 128]
    for ws in widths:
        ch = ChainModule(k_in, k_mid, k_out, s, ws, ref.layout, shared=False)
        P_ch = sum(p.numel() for p in ch.parameters())
        variants.append((f"chain_{s}_w{ws}", ch, (s - 1) * k_mid * fb * T))
        variants.append((f"chain_{s}_shared_w{ws}", ChainModule(k_in, k_mid, k_out, s, ws, ref.layout, shared=True),
                         s * k_mid * fb * T))
        if cc["split_budget"] == "matched":
            wl = max(1, int(round((P_ch - k_out) / (k_in + 1 + k_out))))
            variants.append((f"one_large_matched_w{wl}", MLPModule(k_in, [wl], k_out, "relu", ref.layout), 0))
        else:
            variants.append((f"one_large_w{ws}", MLPModule(k_in, [ws], k_out, "relu", ref.layout), 0))
    rows, preds, records = [], {}, {}
    for name, mod, comm in variants:
        init_module(mod, gen(f"init/{name}"), "default")
        mod.to(dev)
        info = _fit(ctx, js, f"variant/{name}", mod, Xtr, Ytr, n_loc, gen(f"b/{name}"), out_if)
        loc = _rel(lambda x: out_if(mod(x)), Xva, Yva)
        asm = Assembly(ref, codes, [hard], {hard: mod}, interfaces=ifaces).eval()
        dist = 0.0
        with torch.no_grad():
            ys = []
            for j in range(0, len(bundle.test), 4096):
                y_, cs = asm({k: v[j:j + 4096] for k, v in bundle.test.X.items()}, return_codes=True)
                ys.append(y_)
                dist = max(dist, out_if.distance(cs[hard]))
            y = torch.cat(ys)
        if enforce and out_if.finite and dist > MEMBERSHIP_TOL:
            raise ScientificInvalid(f"split variant {name} emitted codes outside the declared alphabet ({dist:.3g})")
        preds[name] = y.detach().cpu()
        m = M.task_metrics(y, bundle.test.y, bundle.task, bundle.test.groups, bundle.target_scale)
        row = {"variant": name, "params": sum(p.numel() for p in mod.parameters()),
               "macs_per_position": mod.macs_per_position(), "internal_bits_per_example": comm,
               "internal_codes": "continuous (float_bits per coordinate)" if isinstance(mod, ChainModule) else "none",
               "output_interface": ("enforced " + out_if.q.mode) if (enforce and out_if.finite) else "continuous",
               "val_local_rel_mse": loc, "test_risk_swapped": M.headline(m, bundle.task),
               "max_offalphabet_distance": dist, "pred_hash": tensor_hash(preds[name]), "local_updates": info["updates"],
               **({"test_acc_swapped": m["acc"]} if "acc" in m else {})}
        records[name] = _module_record(mod, _variant_attrs(name, mod))
        if isinstance(mod, ChainModule) and not mod.shared:
            # local learnability of each sub-pearl, re-fitted from scratch on its own codes
            with torch.no_grad():
                _, cs_tr = mod(Xtr, return_codes=True)
                _, cs_va = mod(Xva, return_codes=True)
            ins_tr, outs_tr = [Xtr] + cs_tr, cs_tr + [mod(Xtr).detach()]
            ins_va, outs_va = [Xva] + cs_va, cs_va + [mod(Xva).detach()]
            sub = []
            for j, part in enumerate(mod.parts):
                fresh = MLPModule(part.layers[0].in_features, [part.layers[0].out_features],
                                  part.layers[-1].out_features, "relu", ref.layout)
                init_module(fresh, gen(f"sub/{name}/{j}"), "default")
                fresh.to(dev)
                _fit(ctx, js, f"sub/{name}/{j}", fresh, ins_tr[j].detach(), outs_tr[j].detach(), n_loc,
                     gen(f"subb/{name}/{j}"))
                sub.append(_rel(fresh, ins_va[j].detach(), outs_va[j].detach()))
                records[f"{name}/sub{j}"] = _module_record(fresh, _variant_attrs("", fresh))
            row["subpearl_refit_val_rel_mse"] = sub
        rows.append(row)
        ctx.metrics("split", "val", {k: v for k, v in row.items() if isinstance(v, (int, float))}, prefix=f"{name}.")
    atomic_torch_save({"hard": hard, "codes": codes, "modules": records,
                       "interfaces": {i: {"node": codes[i], "state": {k: v.cpu() for k, v in ifaces[i].q.state_dict().items()},
                                          "enforce": enforce} for i in ifaces},
                       "reference": {"ckpt": "reference_exported", "structural_hash": ref.structural_hash(),
                                     "param_hash": ref.param_hash()}}, ctx.dir / "split_modules.pt")
    atomic_torch_save(preds, ctx.dir / "split_predictions.pt")
    out = {"hard_pearl": hard, "selection": sel, "s": s, "k_mid": k_mid, "budget": cc["split_budget"], "rows": rows,
           "interface_enforce": cc["interface_enforce"], "local_train_policy": local_policy(cfg["train"]),
           "note": "MACs count repeated execution of shared modules; internal bits use float_bits per coordinate",
           "artifacts": {"modules": "split_modules.pt", "predictions": "split_predictions.pt",
                         "reference": "ckpt/reference_exported.pt"}}
    ctx.save_json("split_result.json", out)
    return {"hard_pearl": hard, "n_variants": len(rows)}


def reload_split(run_dir: str | Path, data_root: Optional[str] = None, device: str = "cpu") -> dict:
    """Fresh-process check: rebuild every saved split variant, swap it into the
    saved reference and reproduce the saved test predictions and risks."""
    from ..utils import read_json
    from ..data.registry import load_bundle
    from ..graph.graph import GraphNet
    run_dir = Path(run_dir)
    cfg = read_json(run_dir / "config.json")
    bundle = load_bundle(cfg["data"], data_root, device="cpu").to(device)
    ref = GraphNet.from_checkpoint(torch.load(run_dir / "ckpt" / "reference_exported.pt", map_location="cpu",
                                              weights_only=False)["model"], device).eval()
    art = torch.load(run_dir / "split_modules.pt", map_location="cpu", weights_only=False)
    saved = torch.load(run_dir / "split_predictions.pt", map_location="cpu", weights_only=False)
    res = read_json(run_dir / "split_result.json")
    ok_ref = ref.structural_hash() == art["reference"]["structural_hash"] and \
        ref.param_hash() == art["reference"]["param_hash"]
    codes, hard = art["codes"], art["hard"]
    ifaces = {}
    for i, rec in art["interfaces"].items():
        it = Interface(quantizer_of(ref, rec["node"]), rec["enforce"], ref.layout)
        it.q.load_state_dict(rec["state"])
        ifaces[int(i)] = it.to(device)
    rows = {r["variant"]: r for r in res["rows"]}
    out = {"reference_matches": ok_ref, "variants": {}, "max_abs_diff": 0.0, "all_bitwise_equal": True}
    for name, y_saved in saved.items():
        mod = _build_from_record(art["modules"][name], device).eval()
        asm = Assembly(ref, codes, [hard], {hard: mod}, interfaces=ifaces).eval()
        with torch.no_grad():
            y = torch.cat([asm({k: v[j:j + 4096] for k, v in bundle.test.X.items()})
                           for j in range(0, len(bundle.test), 4096)]).cpu()
        d = float((y - y_saved).abs().max()) if y.numel() else 0.0
        m = M.task_metrics(y, bundle.test.y.cpu(), bundle.task, None, bundle.target_scale)
        out["variants"][name] = {"max_abs_diff": d, "bitwise_equal": bool(torch.equal(y, y_saved)),
                                 "risk_recomputed": M.headline(m, bundle.task),
                                 "risk_reported": rows[name]["test_risk_swapped"],
                                 "pred_hash_matches": tensor_hash(y) == rows[name]["pred_hash"],
                                 "params_match": sum(p.numel() for p in mod.parameters()) == rows[name]["params"],
                                 "macs_match": mod.macs_per_position() == rows[name]["macs_per_position"]}
        out["max_abs_diff"] = max(out["max_abs_diff"], d)
        out["all_bitwise_equal"] &= out["variants"][name]["bitwise_equal"]
    out["ok"] = ok_ref and out["max_abs_diff"] <= 1e-5 and all(
        abs(v["risk_recomputed"] - v["risk_reported"]) <= 1e-5 * max(1.0, abs(v["risk_reported"])) and
        v["params_match"] and v["macs_match"] for v in out["variants"].values())
    return out
