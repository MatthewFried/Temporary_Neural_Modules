"""Cut-level transplants and low-cost code alignment (mechanism C, F07d, F08).

A transplant combines an upstream part (encoder side) of one network with the
downstream part (decoder side) of another at a shared cut.  Equivalent networks
may use incompatible conventions at that cut (for example a permutation of a
finite code), so a direct transplant can fail without any information being
lost.  An alignment map fitted on TRAINING inputs only, from paired cut
activations (source convention -> target convention), separates "incompatible
convention" from "information absent".

Alignments:
  symbol  finite codes: every distinct code vector of the source is mapped to the
          target code it co-occurs with most often (ties: lowest target index,
          deterministic).  Exact for a relabelling.  Source codes never seen in
          training map to the nearest seen source code.
  affine  continuous codes: least-squares affine map with a small ridge term.
  none    identity (the direct transplant).

Every alignment reports its parameter count (charged to inference and
replacement cost) and the number of paired training examples used.
"""
from __future__ import annotations

from typing import Optional

import torch
from torch import nn


def _flat_last(z: torch.Tensor, image: bool):
    """(N, k, H, W) -> (N*H*W, k) for image cuts (alignment per spatial position), else (..., k)."""
    if image:
        return z.movedim(1, -1)
    return z


def _unflat_last(y: torch.Tensor, image: bool):
    return y.movedim(-1, 1) if image else y


class SymbolAlignment(nn.Module):
    """Lookup from source code vectors to target code vectors (finite codes).  Serialisable:
    module_type 'align_symbol' with args (n_codes, k_in, k_out, image); the table is in buffers."""

    def __init__(self, n_codes: int, k_in: int, k_out: int, image: bool = False):
        super().__init__()
        self.image = bool(image)
        self.register_buffer("src", torch.zeros(int(n_codes), int(k_in), dtype=torch.float64))
        self.register_buffer("dst", torch.zeros(int(n_codes), int(k_out), dtype=torch.float64))

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        zz = _flat_last(z, self.image)
        flat = zz.reshape(-1, zz.shape[-1]).to(self.src.dtype)
        d = torch.cdist(flat, self.src)                      # nearest stored source code (exact match: distance 0)
        idx = d.argmin(1)
        y = self.dst[idx].reshape(*zz.shape[:-1], self.dst.shape[-1]).to(z.dtype)
        return _unflat_last(y, self.image)

    def n_params(self) -> int:
        return int(self.src.numel() + self.dst.numel())       # table entries count as inference storage

    def macs_per_position(self) -> int:
        return int(self.src.numel())                         # one distance per stored code coordinate


class AffineAlignment(nn.Module):
    """y = W z + b.  Serialisable: module_type 'align_affine' with args (k_in, k_out, image)."""

    def __init__(self, k_in: int, k_out: int, image: bool = False):
        super().__init__()
        self.image = bool(image)
        self.lin = nn.Linear(int(k_in), int(k_out))

    def forward(self, z):
        return _unflat_last(self.lin(_flat_last(z, self.image)), self.image)

    def n_params(self) -> int:
        return sum(p.numel() for p in self.lin.parameters())

    def macs_per_position(self) -> int:
        return int(self.lin.in_features * self.lin.out_features)


class IdentityAlignment(nn.Module):
    def __init__(self, image: bool = False):
        super().__init__()
        self.image = bool(image)

    def forward(self, z):
        return z

    def n_params(self) -> int:
        return 0


class ResidualMLPAlignment(nn.Module):
    """z + W2 relu(W1 z + b1) + b2 (a small nonlinear adapter; W2, b2 start at zero, so it starts as the
    identity).  Serialisable: module_type 'align_mlp' with args (k, hidden, image)."""

    def __init__(self, k: int, hidden: int, image: bool = False):
        super().__init__()
        self.image = bool(image)
        self.l1 = nn.Linear(int(k), int(hidden))
        self.l2 = nn.Linear(int(hidden), int(k))
        with torch.no_grad():
            self.l2.weight.zero_()
            self.l2.bias.zero_()

    def forward(self, z):
        zz = _flat_last(z, self.image)
        return _unflat_last(zz + self.l2(torch.relu(self.l1(zz))), self.image)

    def n_params(self) -> int:
        return sum(p.numel() for p in self.parameters())

    def macs_per_position(self) -> int:
        return int(self.l1.in_features * self.l1.out_features * 2)


ALIGN_MODULE_TYPES = {"align_symbol": SymbolAlignment, "align_affine": AffineAlignment,
                      "align_identity": IdentityAlignment, "align_mlp": ResidualMLPAlignment}


@torch.no_grad()
def fit_symbol_alignment(src: torch.Tensor, dst: torch.Tensor, image: bool = False) -> tuple[SymbolAlignment, dict]:
    """src, dst: (N, k) paired finite codes on the same TRAINING inputs.  The fit runs on CPU in
    float64 whatever the inputs' device (V3-05); the returned module is on CPU: move it with .to()."""
    if src.shape[0] != dst.shape[0]:
        raise ValueError("paired codes must have the same number of rows")
    S = src.detach().reshape(src.shape[0], -1).to("cpu", torch.float64)
    D = dst.detach().reshape(dst.shape[0], -1).to("cpu", torch.float64)
    s_u, s_inv = torch.unique(S, dim=0, return_inverse=True)
    d_u, d_inv = torch.unique(D, dim=0, return_inverse=True)
    counts = torch.zeros(len(s_u), len(d_u), dtype=torch.long)
    counts.index_put_((s_inv, d_inv), torch.ones_like(s_inv), accumulate=True)
    best = counts.argmax(1)                                  # first maximum: lowest target index on ties
    agree = int(counts.max(1).values.sum())
    info = {"kind": "symbol", "n_pairs": int(S.shape[0]), "n_source_codes": int(len(s_u)),
            "n_target_codes": int(len(d_u)), "training_pair_agreement": agree / max(1, int(S.shape[0])),
            "one_to_one": bool(len(set(best.tolist())) == len(s_u)), "fit_device": "cpu", "fit_dtype": "float64"}
    m = SymbolAlignment(len(s_u), S.shape[1], D.shape[1], image)
    m.src.copy_(s_u)
    m.dst.copy_(d_u[best])
    info["params"] = m.n_params()
    return m, info


@torch.no_grad()
def fit_affine_alignment(src: torch.Tensor, dst: torch.Tensor, ridge: float = 1e-10,
                         image: bool = False) -> tuple[AffineAlignment, dict]:
    """Least squares with a ridge relative to the mean diagonal of the Gram matrix, solved on CPU
    in float64 whatever the inputs' device (V3-05); the module takes the source dtype and is on CPU."""
    X = src.detach().reshape(src.shape[0], -1).to("cpu", torch.float64)
    Y = dst.detach().reshape(dst.shape[0], -1).to("cpu", torch.float64)
    Xa = torch.cat([X, torch.ones(len(X), 1, dtype=torch.float64)], 1)
    G = Xa.T @ Xa
    A = G + ridge * float(G.diagonal().mean()) * torch.eye(Xa.shape[1], dtype=torch.float64)
    sol = torch.linalg.solve(A, Xa.T @ Y)                   # (k_in + 1, k_out)
    W, b = sol[:-1].T, sol[-1]
    m = AffineAlignment(X.shape[1], Y.shape[1], image).to(src.dtype)
    m.lin.weight.copy_(W.to(src.dtype))
    m.lin.bias.copy_(b.to(src.dtype))
    res = ((Xa @ sol - Y) ** 2).mean() / Y.var().clamp_min(1e-12)
    return m, {"kind": "affine", "n_pairs": int(len(X)), "ridge": ridge, "train_nmse": float(res),
               "params": m.n_params(), "fit_device": "cpu", "fit_dtype": "float64"}


@torch.no_grad()
def fit_orthogonal_alignment(src: torch.Tensor, dst: torch.Tensor, image: bool = False) -> tuple[AffineAlignment, dict]:
    """Orthogonal Procrustes with centring: y = R (z - mu_z) + mu_y, R orthogonal (equal widths); CPU float64."""
    X = src.detach().reshape(src.shape[0], -1).to("cpu", torch.float64)
    Y = dst.detach().reshape(dst.shape[0], -1).to("cpu", torch.float64)
    if X.shape[1] != Y.shape[1]:
        raise ValueError("orthogonal alignment needs equal widths")
    mx, my = X.mean(0), Y.mean(0)
    U, _, Vh = torch.linalg.svd((X - mx).T @ (Y - my))
    R = U @ Vh                                          # z_c R ~= y_c
    W = R.T
    b = my - W @ mx
    m = AffineAlignment(X.shape[1], Y.shape[1], image).to(src.dtype)
    m.lin.weight.copy_(W.to(src.dtype))
    m.lin.bias.copy_(b.to(src.dtype))
    res = (((X - mx) @ R + my - Y) ** 2).mean() / Y.var().clamp_min(1e-12)
    return m, {"kind": "orthogonal", "n_pairs": int(len(X)), "train_nmse": float(res), "params": m.n_params(),
               "fit_device": "cpu", "fit_dtype": "float64", "note": "parameters counted as a full affine map"}


def fit_mlp_alignment(src: torch.Tensor, dst: torch.Tensor, tcfg: dict, n_updates: int, gen: torch.Generator,
                      image: bool = False, hidden: Optional[int] = None) -> tuple[ResidualMLPAlignment, dict]:
    """Residual MLP adapter fitted by activation matching (MSE to the target convention) with the train
    section's optimizer policy for n_updates minibatch steps (CPU float32; deterministic generator)."""
    from ..train.trainer import LocalOpt
    X = src.detach().reshape(src.shape[0], -1).to("cpu", torch.float32)
    Y = dst.detach().reshape(dst.shape[0], -1).to("cpu", torch.float32)
    if X.shape[1] != Y.shape[1]:
        raise ValueError("the residual adapter needs equal widths")
    devs = [torch.cuda.current_device()] if torch.cuda.is_available() else []
    with torch.random.fork_rng(devices=devs):
        torch.manual_seed(int(torch.randint(0, 2 ** 31 - 1, (1,), generator=gen)))
        m = ResidualMLPAlignment(X.shape[1], hidden or X.shape[1], image)
    lo = LocalOpt(list(m.parameters()), tcfg, n_updates)
    B = min(int(tcfg["batch_size"]), len(X))
    for k in range(n_updates):
        i = torch.randint(0, len(X), (B,), generator=gen)
        z = X[i]
        loss = ((z + m.l2(torch.relu(m.l1(z))) - Y[i]) ** 2).mean()
        lo.step(loss, k)
    with torch.no_grad():
        res = ((X + m.l2(torch.relu(m.l1(X))) - Y) ** 2).mean() / Y.var().clamp_min(1e-12)
    m = m.to(src.dtype)
    return m, {"kind": "mlp", "n_pairs": int(len(X)), "updates": int(n_updates), "train_nmse": float(res),
               "params": m.n_params(), "fit_device": "cpu", "objective": "activation matching (MSE)"}


def fit_alignment(kind: str, src: torch.Tensor, dst: torch.Tensor, image: bool = False) -> tuple[nn.Module, dict]:
    if kind == "none":
        return IdentityAlignment(image), {"kind": "none", "params": 0, "n_pairs": 0}
    if kind == "symbol":
        return fit_symbol_alignment(src, dst, image=image)
    if kind == "affine":
        return fit_affine_alignment(src, dst, image=image)
    raise ValueError(f"unknown alignment kind {kind!r}")


def alignment_spec(m: nn.Module) -> tuple[str, dict]:
    """(module_type, module_args) that rebuild an alignment module for a checkpoint."""
    if isinstance(m, SymbolAlignment):
        return "align_symbol", {"n_codes": int(m.src.shape[0]), "k_in": int(m.src.shape[1]),
                                "k_out": int(m.dst.shape[1]), "image": m.image}
    if isinstance(m, AffineAlignment):
        return "align_affine", {"k_in": int(m.lin.in_features), "k_out": int(m.lin.out_features), "image": m.image}
    if isinstance(m, ResidualMLPAlignment):
        return "align_mlp", {"k": int(m.l1.in_features), "hidden": int(m.l1.out_features), "image": m.image}
    return "align_identity", {"image": bool(getattr(m, "image", False))}


class Transplant(nn.Module):
    """upstream (source network, up to the cut) -> alignment -> downstream (target network)."""

    def __init__(self, upstream: nn.Module, downstream: nn.Module, align: Optional[nn.Module] = None):
        super().__init__()
        self.up, self.down = upstream, downstream
        self.align = align if align is not None else IdentityAlignment()

    def forward(self, x):
        return self.down(self.align(self.up(x)))
