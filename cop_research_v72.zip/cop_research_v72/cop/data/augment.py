"""Vectorised, reproducible image augmentation.

All random draws come from a CPU torch.Generator (so the sequence is identical
on CPU and GPU and can be checkpointed with generator.get_state()); the
transformation itself runs on x.device with no per-example Python loop.
"""
from __future__ import annotations

import torch

AUGMENT_KINDS = ("none", "flip", "crop_flip")


def augment_batch(x: torch.Tensor, kind: str, gen: torch.Generator, pad_value: torch.Tensor | None = None,
                  pad: int = 4) -> torch.Tensor:
    """x: (B, C, H, W).  'flip' = random horizontal flip (p=1/2);
    'crop_flip' = random crop after `pad`-pixel padding filled with pad_value
    (per-channel, normally the normalised black value) followed by flip.
    Draw order per call: crop offsets (rows, cols) then flip mask."""
    if kind == "none":
        return x
    if kind not in AUGMENT_KINDS:
        raise ValueError(f"unknown augmentation {kind!r}")
    B, C, H, W = x.shape
    dev = x.device
    out = x
    if kind == "crop_flip":
        oy = torch.randint(0, 2 * pad + 1, (B,), generator=gen)
        ox = torch.randint(0, 2 * pad + 1, (B,), generator=gen)
        pv = torch.zeros(C) if pad_value is None else pad_value.detach().float().cpu()
        padded = pv.to(dev, x.dtype).view(1, C, 1, 1).expand(B, C, H + 2 * pad, W + 2 * pad).clone()
        padded[:, :, pad:pad + H, pad:pad + W] = x
        rows = (oy.to(dev).unsqueeze(1) + torch.arange(H, device=dev)).view(B, 1, H, 1)
        cols = (ox.to(dev).unsqueeze(1) + torch.arange(W, device=dev)).view(B, 1, 1, W)
        tmp = padded.gather(2, rows.expand(B, C, H, W + 2 * pad))
        out = tmp.gather(3, cols.expand(B, C, H, W))
    flip = (torch.rand(B, generator=gen) < 0.5).to(dev).view(B, 1, 1, 1)
    return torch.where(flip, out.flip(3), out)
