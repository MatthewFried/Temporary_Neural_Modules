"""Data containers shared by every dataset family.

A `Partition` holds named input streams (always 'x'; 'q' for delayed-query
inputs that must enter the network late), targets, optional clean targets
(train only, diagnostics only), optional group ids (from the generator, never
inferred from labels) and optional auxiliary known intermediates.

A `DataBundle` holds the selected training subset plus fixed validation/test
partitions and named extra evaluation partitions.  Validation and test do not
change with n_train (nested-subset design, spec section 5).
"""
from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

import torch

from ..utils import tensor_hash, stable_hash


@dataclass
class Partition:
    X: dict[str, torch.Tensor]
    y: torch.Tensor
    y_clean: Optional[torch.Tensor] = None
    groups: Optional[torch.Tensor] = None
    aux: dict[str, torch.Tensor] = field(default_factory=dict)
    meta: dict[str, Any] = field(default_factory=dict)

    def __len__(self) -> int:
        return int(self.y.shape[0])

    def to(self, device) -> "Partition":
        mv = lambda t: None if t is None else t.to(device, non_blocking=True)
        return Partition({k: v.to(device, non_blocking=True) for k, v in self.X.items()}, mv(self.y),
                         mv(self.y_clean), mv(self.groups), {k: v.to(device) for k, v in self.aux.items()},
                         dict(self.meta))

    def index(self, idx: torch.Tensor) -> "Partition":
        sel = lambda t: None if t is None else t[idx]
        return Partition({k: v[idx] for k, v in self.X.items()}, self.y[idx], sel(self.y_clean),
                         sel(self.groups), {k: v[idx] for k, v in self.aux.items()}, dict(self.meta))

    def hash(self) -> str:
        parts = {k: tensor_hash(v) for k, v in sorted(self.X.items())}
        parts["y"] = tensor_hash(self.y)
        if self.groups is not None:
            parts["groups"] = tensor_hash(self.groups)
        return stable_hash(parts)


@dataclass
class DataBundle:
    name: str
    family: str                      # 'D01'..'D08'
    task: str                        # 'classification' | 'regression' | 'seq_classification'
    layout: str                      # 'vec' | 'img' | 'seq'
    input_spec: dict[str, dict]      # stream -> {'shape': per-example shape, 'dtype': 'float'|'long', 'vocab': int?}
    out_dim: int                     # classes, regression dim, or vocab for seq outputs
    train: Partition                 # selected training subset (targets possibly noisy)
    val: Partition
    test: Partition
    extra: dict[str, Partition] = field(default_factory=dict)
    pool_size: int = 0               # size of the training pool the subset was drawn from
    train_indices: Optional[torch.Tensor] = None  # indices of the subset inside the pool
    preprocess: dict[str, Any] = field(default_factory=dict)   # fitted on the training subset only
    target_scale: float = 1.0        # documented scale for normalised regression drift
    augment: str = "none"            # 'none' | 'crop_flip' | 'flip'
    fresh_sampler: Optional[Callable[[int, torch.Generator], Partition]] = None
    meta: dict[str, Any] = field(default_factory=dict)

    @property
    def loss(self) -> str:
        return {"classification": "ce", "regression": "mse", "seq_classification": "seq_ce"}[self.task]

    def partitions(self) -> dict[str, Partition]:
        d = {"train": self.train, "val": self.val, "test": self.test}
        d.update(self.extra)
        return d

    def to(self, device) -> "DataBundle":
        b = dataclasses.replace(self)
        b.train, b.val, b.test = self.train.to(device), self.val.to(device), self.test.to(device)
        b.extra = {k: v.to(device) for k, v in self.extra.items()}
        return b

    def hashes(self) -> dict[str, str]:
        h = {k: p.hash() for k, p in self.partitions().items()}
        if self.train_indices is not None:
            h["train_indices"] = tensor_hash(self.train_indices)
        return h
