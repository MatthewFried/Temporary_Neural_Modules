"""Assembly of a DataBundle from a fixed pool + fixed val/test (+ extras)."""
from __future__ import annotations

from typing import Callable, Optional

import torch

from .bundle import DataBundle, Partition
from .splits import nested_order, pool_label_corruption, pool_target_noise, select_subset


def check_params(name: str, given: dict, defaults: dict) -> dict:
    unknown = set(given) - set(defaults)
    if unknown:
        raise ValueError(f"dataset {name!r}: unknown params {sorted(unknown)}; allowed {sorted(defaults)}")
    p = dict(defaults)
    p.update(given)
    return p


def finalize_bundle(*, cfg: dict, name: str, family: str, task: str, layout: str, input_spec: dict,
                    out_dim: int, pool: Partition, val: Partition, test: Partition,
                    extra: Optional[dict] = None, balanced: bool = True,
                    preprocess_fn: Optional[Callable[[Partition], tuple[dict, Callable[[Partition], Partition]]]] = None,
                    target_scale: float = 1.0, augment: str = "none", fresh_sampler=None,
                    meta: Optional[dict] = None, seq_n_symbols: Optional[int] = None,
                    noise_scale: Optional[float] = None) -> DataBundle:
    """Select the nested training subset, apply train-only corruption,
    fit preprocessing on the training subset, and assemble the bundle.

    Corruption is drawn per pool element (stream 'noise', data_seed) so the
    same example has the same training label for every n_train.
    """
    data_seed = int(cfg["data_seed"])
    extra = dict(extra or {})
    meta = dict(meta or {})
    pool_y_clean = pool.y
    pool_y = pool.y
    label_noise = float(cfg.get("label_noise", 0.0))
    target_noise = float(cfg.get("target_noise", 0.0))
    if task == "regression":
        if label_noise > 0:
            raise ValueError("label_noise is for classification; use target_noise for regression")
        if target_noise > 0:
            pool_y = pool.y + pool_target_noise(tuple(pool.y.shape),
                                                    target_noise * (target_scale if noise_scale is None else noise_scale),
                                                    data_seed, name)
    else:
        if target_noise > 0:
            raise ValueError("target_noise is for regression; use label_noise for classification")
        if label_noise > 0:
            n_cls = seq_n_symbols if task == "seq_classification" else out_dim
            pool_y = pool_label_corruption(pool.y, n_cls, label_noise, data_seed, name,
                                           ignore_index=-100 if task == "seq_classification" else None)

    order = nested_order(pool.y if task == "classification" else None, len(pool), data_seed, name,
                         balanced=balanced and task == "classification")
    idx = select_subset(order, cfg["n_train"])
    train = pool.index(idx)
    train.y = pool_y[idx]
    train.y_clean = pool_y_clean[idx]
    if task != "regression":
        changed = (train.y != train.y_clean)
        if task == "seq_classification":
            denom = int((train.y_clean != -100).sum())
        else:
            denom = len(train)
        meta["realised_label_noise_fraction"] = float(changed.sum()) / max(1, denom)
    preprocess = {"type": "none", "fitted_on": None}
    if preprocess_fn is not None:
        preprocess, apply = preprocess_fn(train)
        preprocess["fitted_on"] = "train_subset"
        train = apply(train)
        val = apply(val)
        test = apply(test)
        extra = {k: apply(v) for k, v in extra.items()}
    meta.setdefault("label_noise", label_noise)
    meta.setdefault("target_noise", target_noise)
    meta["n_train"] = len(train)
    meta["pool_size"] = len(pool)
    return DataBundle(name=name, family=family, task=task, layout=layout, input_spec=input_spec,
                      out_dim=int(out_dim), train=train, val=val, test=test, extra=extra,
                      pool_size=len(pool), train_indices=idx, preprocess=preprocess,
                      target_scale=float(target_scale), augment=augment, fresh_sampler=fresh_sampler,
                      meta=meta)
