"""D07 images: Fashion-MNIST, CIFAR-10, CIFAR-100 (end-to-end training data).

Validation is reserved from the OFFICIAL TRAIN split (stratified, fixed by
params.split_seed); the official test split is untouched and used only for
evaluation.  Pixels are scaled to [0,1] and normalised per channel with
mean/std computed from the selected TRAIN SUBSET only.
"""
from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import torch

from .bundle import Partition
from .common import check_params, finalize_bundle
from .splits import stratified_split

IMAGE_DEFAULTS = {"n_val": None, "split_seed": 0}
VAL_SIZE = {"fashion_mnist": 6000, "cifar10": 5000, "cifar100": 5000}
N_CLASSES = {"fashion_mnist": 10, "cifar10": 10, "cifar100": 100}
DEFAULT_AUGMENT = {"fashion_mnist": "none", "cifar10": "crop_flip", "cifar100": "crop_flip"}
TV_CLASS = {"fashion_mnist": "FashionMNIST", "cifar10": "CIFAR10", "cifar100": "CIFAR100"}


def _to_nchw_uint8(a) -> torch.Tensor:
    t = torch.as_tensor(np.asarray(a))
    if t.dim() == 3:                       # (N, H, W) grayscale
        t = t.unsqueeze(1)
    elif t.dim() == 4 and t.shape[-1] in (1, 3):   # (N, H, W, C)
        t = t.permute(0, 3, 1, 2)
    return t.contiguous().to(torch.uint8)


def image_bundle_from_arrays(cfg: dict, name: str, train_x, train_y, test_x, test_y, augment: str,
                             n_classes: int, n_val: int, split_seed: int, meta: dict):
    """Shared path (also used by tests with fake arrays)."""
    trx, tex = _to_nchw_uint8(train_x), _to_nchw_uint8(test_x)
    try_ = torch.as_tensor(np.asarray(train_y)).long()
    tey = torch.as_tensor(np.asarray(test_y)).long()
    parts = stratified_split(try_.numpy(), {"val": n_val, "pool": None}, split_seed, name)
    vi, pi = torch.from_numpy(parts["val"]), torch.from_numpy(parts["pool"])
    pool = Partition({"x": trx[pi]}, try_[pi], None, None, {}, {})
    val = Partition({"x": trx[vi]}, try_[vi], None, None, {}, {})
    test = Partition({"x": tex}, tey, None, None, {}, {"note": "official test split, untouched"})

    def preprocess_fn(train: Partition):
        x = train.X["x"].double() / 255.0
        mean = x.mean(dim=(0, 2, 3))
        std = x.std(dim=(0, 2, 3), unbiased=False).clamp_min(1e-6)
        mean_f, std_f = mean.float(), std.float()
        black = (-mean_f / std_f)

        def apply(p: Partition) -> Partition:
            xx = (p.X["x"].float() / 255.0 - mean_f.view(1, -1, 1, 1)) / std_f.view(1, -1, 1, 1)
            return Partition({"x": xx}, p.y, p.y_clean, p.groups, dict(p.aux), dict(p.meta))
        return {"type": "per_channel_standardise", "mean": mean_f.tolist(), "std": std_f.tolist(),
                "pad_value": black.tolist(), "pixel_scale": "x/255"}, apply

    C, H, W = trx.shape[1:]
    meta = dict(meta)
    meta.update({"n_val": int(len(vi)), "pool": int(len(pi)), "n_test": int(len(tey)),
                 "val_source": "stratified from official train split", "split_seed": split_seed})
    return finalize_bundle(cfg=cfg, name=name, family="D07", task="classification", layout="img",
                           input_spec={"x": {"shape": [int(C), int(H), int(W)], "dtype": "float"}},
                           out_dim=n_classes, pool=pool, val=val, test=test, preprocess_fn=preprocess_fn,
                           augment=augment, meta=meta)


def _load_tv(name: str, root, download: bool = True):
    import torchvision
    cls = getattr(torchvision.datasets, TV_CLASS[name])
    r = str(Path(root) / "torchvision")
    tr = cls(r, train=True, download=download)
    te = cls(r, train=False, download=download)
    tx = tr.data.numpy() if isinstance(tr.data, torch.Tensor) else tr.data
    ex = te.data.numpy() if isinstance(te.data, torch.Tensor) else te.data
    return tx, np.asarray(tr.targets), ex, np.asarray(te.targets)


def _builder(name: str):
    def build(cfg: dict, root=None):
        p = check_params(name, cfg.get("params", {}), IMAGE_DEFAULTS)
        if root is None:
            raise ValueError("image datasets need a data root")
        aug = cfg.get("augment", "default")
        aug = DEFAULT_AUGMENT[name] if aug == "default" else aug
        trx, tr_y, tex, te_y = _load_tv(name, root)
        n_val = VAL_SIZE[name] if p["n_val"] is None else int(p["n_val"])
        return image_bundle_from_arrays(cfg, name, trx, tr_y, tex, te_y, aug, N_CLASSES[name], n_val,
                                        int(p["split_seed"]),
                                        {"source": f"torchvision.datasets.{TV_CLASS[name]}", "params": p})
    return build


build_fashion_mnist = _builder("fashion_mnist")
build_cifar10 = _builder("cifar10")
build_cifar100 = _builder("cifar100")


TOY_DEFAULTS = {"n_classes": 4, "hw": 16, "channels": 3, "n_train_pool": 2000, "n_test_images": 1000, "n_val": 400,
                "split_seed": 0}


def build_toy_images(cfg: dict, root=None):
    """ENGINEERING TEST DATA ONLY (not a scientific dataset): class-dependent
    oriented stripe patterns plus noise, so CNN/ResNet code paths can be tested
    without downloads.  Generated from the 'data' stream."""
    from ..utils import torch_gen
    p = check_params("toy_images", cfg.get("params", {}), TOY_DEFAULTS)
    C, H, K = int(p["channels"]), int(p["hw"]), int(p["n_classes"])

    def make(n, key):
        g = torch_gen(int(cfg["data_seed"]), "data", "toy_images", key)
        y = torch.randint(0, K, (n,), generator=g)
        yy, xx = torch.meshgrid(torch.arange(H), torch.arange(H), indexing="ij")
        ang = (y.float() / K * math.pi)[:, None, None]
        stripes = torch.sin((xx[None] * torch.cos(ang) + yy[None] * torch.sin(ang)) * 1.3)
        img = stripes[:, None].repeat(1, C, 1, 1) * 60 + 128 + torch.randn(n, C, H, H, generator=g) * 40
        return img.clamp(0, 255).to(torch.uint8).numpy(), y.numpy()
    trx, tr_y = make(int(p["n_train_pool"]) + int(p["n_val"]), "train")
    tex, te_y = make(int(p["n_test_images"]), "test")
    aug = cfg.get("augment", "default")
    aug = "flip" if aug == "default" else aug
    return image_bundle_from_arrays(cfg, "toy_images", trx, tr_y, tex, te_y, aug, K, int(p["n_val"]),
                                    int(p["split_seed"]), {"source": "synthetic engineering test images", "params": p})


# ----------------------------------------------------------------------------- v65: image shortcut task
IMAGE_SHORTCUT_DEFAULTS = {
    "base": "cifar10",              # cifar10 | toy (toy: synthetic stripes, ENGINEERING TESTS ONLY)
    "positive_classes": [0, 1, 8, 9],   # label 1 (CIFAR-10: airplane, automobile, ship, truck)
    "negative_classes": [3, 4, 5, 7],   # label 0 (CIFAR-10: cat, deer, dog, horse)
    "rho_train": 0.95,              # train pool and val: the shortcut agrees with the label with this probability
    "shortcut_strength": 1.0,       # the shortcut plane's value: strength x (2a - 1) + noise x N(0, 1), per image
    "shortcut_noise": 0.5,
    "n_val": 2000,                  # each validation partition (val, val_indep, val_reversed): from the official train split
    "n_cf": 2000,                   # the counterfactual pair (cf_base, cf_shortcut): the first n_cf test images
    "split_seed": 0,
    "toy_hw": [12, 10],             # toy only: image height, width (rectangular on purpose)
    "toy_pool": 1200,               # toy only: training images per class (official-train stand-in)
    "toy_test": 300,                # toy only: test images per class
}


def _toy_two_class(n_per: int, hw, key: str, data_seed: int):
    """ENGINEERING TEST DATA ONLY: two classes of oriented stripes (class 0 horizontal-ish, 1 vertical-ish) plus
    noise, 3 channels, uint8 (N, H, W, 3)."""
    from ..utils import torch_gen
    H, W = int(hw[0]), int(hw[1])
    g = torch_gen(int(data_seed), "data", "image_shortcut_toy", key)
    y = torch.arange(2).repeat_interleave(n_per)
    ang = (0.15 + 1.2 * y.float() + 0.25 * torch.rand(len(y), generator=g))[:, None, None]
    yy, xx = torch.meshgrid(torch.arange(H).float(), torch.arange(W).float(), indexing="ij")
    st = torch.sin((xx[None] * torch.cos(ang) + yy[None] * torch.sin(ang)) * 1.4)
    img = st[:, :, :, None].repeat(1, 1, 1, 3) * 45 + 128 + torch.randn(len(y), H, W, 3, generator=g) * 50
    return img.clamp(0, 255).to(torch.uint8).numpy(), y.numpy()


def build_image_shortcut(cfg: dict, root=None):
    """v65 (D07): a binary image task with a shortcut input channel, the image counterpart of the shortcut task.
    Label 1: an image of the positive classes, 0: of the negative classes (CIFAR-10 by default: vehicles against
    four animal classes, balanced).  The network sees 4 channels: the 3 colour channels (standardised per channel
    with the training subset's statistics) and a SHORTCUT PLANE, constant over the image, of value
    s = strength x (2a - 1) + noise x N(0, 1) per image, where
      pool (training) / val / val_reversed... : a = y with probability rho_train else 1 - y (val), and
      test, val_indep : a ~ Bernoulli(1/2), independent of y
      shift, val_reversed : a = y with probability 1 - rho_train (reversed correlation)
      cf_base / cf_shortcut : the first n_cf test images with a = y / a = 1 - y (the same noise): a paired
                              intervention on the shortcut alone (shortcut_flip_rate)
    Validation partitions are disjoint parts of the official train split (stratified); test, shift and the
    counterfactual pair use the official test images (untouched otherwise).  The shortcut assignment and noise of
    each pool image come from its own key (data_seed), so an image keeps its shortcut for every n_train.  The
    feature layout names the channels: causal = the colour channels [0, 3) (the image content carries the label's
    causal signal), shortcut = channel 3.  No augmentation by default (a horizontal flip leaves the plane unchanged
    and may be requested)."""
    from ..utils import torch_gen
    name = "image_shortcut"
    p = check_params(name, cfg.get("params", {}), IMAGE_SHORTCUT_DEFAULTS)
    pos, neg = [int(c) for c in p["positive_classes"]], [int(c) for c in p["negative_classes"]]
    if not pos or not neg or set(pos) & set(neg):
        raise ValueError("image_shortcut: positive and negative classes must be non-empty and disjoint")
    rho, mu, sn = float(p["rho_train"]), float(p["shortcut_strength"]), float(p["shortcut_noise"])
    ds = int(cfg["data_seed"])
    if p["base"] == "cifar10":
        if root is None:
            raise ValueError("image_shortcut on cifar10 needs a data root")
        trx, tr_y, tex, te_y = _load_tv("cifar10", root)
    elif p["base"] == "toy":
        if sorted(pos + neg) != [0, 1] or len(pos) != 1:
            raise ValueError("image_shortcut toy: classes are 0 and 1")
        trx, tr_y = _toy_two_class(int(p["toy_pool"]), p["toy_hw"], "train", int(p["split_seed"]))
        tex, te_y = _toy_two_class(int(p["toy_test"]), p["toy_hw"], "test", int(p["split_seed"]))
    else:
        raise ValueError("image_shortcut: base must be cifar10 or toy")

    def binary(x, y):
        y = np.asarray(y)
        keep = np.isin(y, pos + neg)
        return _to_nchw_uint8(np.asarray(x)[keep]), torch.as_tensor(np.isin(y[keep], pos).astype(np.int64))
    trx_, try_ = binary(trx, tr_y)
    tex_, tey_ = binary(tex, te_y)
    nv = int(p["n_val"])
    parts = stratified_split(try_.numpy(), {"val": nv, "val_indep": nv, "val_reversed": nv, "pool": None},
                             int(p["split_seed"]), name)

    def plane(y, key: str, agree):
        """the shortcut value per image from its own key: agree = None (independent), else the agreement
        probability; returns (a, s)."""
        g = torch_gen(ds, "data", name, key)
        n = len(y)
        if agree is None:
            a = (torch.rand(n, generator=g) < 0.5).long()
        else:
            ag = torch.rand(n, generator=g) < agree
            a = torch.where(ag, y, 1 - y)
        s = mu * (2 * a - 1).float() + sn * torch.randn(n, generator=g)
        return a, s

    def part(x, y, key, agree, note=""):
        a, s = plane(y, key, agree)
        return Partition({"x": x}, y, None, None, {"_shortcut_a": a, "_shortcut_value": s}, {"note": note} if note else {})

    sel = {k: torch.from_numpy(v) for k, v in parts.items()}
    pool = part(trx_[sel["pool"]], try_[sel["pool"]], "pool", rho)
    val = part(trx_[sel["val"]], try_[sel["val"]], "val", rho)
    val_indep = part(trx_[sel["val_indep"]], try_[sel["val_indep"]], "val_env_indep", None,
                     "validation environment: shortcut independent of the label (selection only)")
    val_reversed = part(trx_[sel["val_reversed"]], try_[sel["val_reversed"]], "val_env_reversed", 1.0 - rho,
                        "validation environment: shortcut correlation reversed (selection only)")
    test = part(tex_, tey_, "test", None, "official test images, shortcut independent of the label")
    shift = part(tex_, tey_, "shift", 1.0 - rho, "official test images, shortcut correlation reversed")
    ncf = min(int(p["n_cf"]), len(tey_))
    gcf = torch_gen(ds, "data", name, "counterfactual")
    eps = sn * torch.randn(ncf, generator=gcf)
    ycf = tey_[:ncf]
    cf_base = Partition({"x": tex_[:ncf]}, ycf, None, None,
                        {"_shortcut_a": ycf.clone(), "_shortcut_value": mu * (2 * ycf - 1).float() + eps},
                        {"note": "counterfactual base: shortcut agrees with the label"})
    cf_shortcut = Partition({"x": tex_[:ncf]}, ycf, None, None,
                            {"_shortcut_a": 1 - ycf, "_shortcut_value": -mu * (2 * ycf - 1).float() + eps},
                            {"note": "shortcut flipped; image and label unchanged (paired with cf_base)"})

    def preprocess_fn(train: Partition):
        x = train.X["x"].double() / 255.0
        mean = x.mean(dim=(0, 2, 3))
        std = x.std(dim=(0, 2, 3), unbiased=False).clamp_min(1e-6)
        mean_f, std_f = mean.float(), std.float()

        def apply(q: Partition) -> Partition:
            xx = (q.X["x"].float() / 255.0 - mean_f.view(1, -1, 1, 1)) / std_f.view(1, -1, 1, 1)
            sp = q.aux["_shortcut_value"].float().view(-1, 1, 1, 1).expand(-1, 1, xx.shape[2], xx.shape[3])
            return Partition({"x": torch.cat([xx, sp], 1).contiguous()}, q.y, q.y_clean, q.groups, dict(q.aux),
                             dict(q.meta))
        return {"type": "per_channel_standardise_plus_shortcut_plane", "mean": mean_f.tolist(), "std": std_f.tolist(),
                "pixel_scale": "x/255", "shortcut_channel": 3, "shortcut_channel_scale": "raw (not standardised)"}, \
            apply

    C, H, W = trx_.shape[1:]
    meta = {"source": ("torchvision.datasets.CIFAR10" if p["base"] == "cifar10" else
                       "synthetic stripes (engineering tests only)"), "params": p,
            "generator": "image + shortcut plane (see docstring)",
            "feature_layout": {"causal": [0, int(C)], "shortcut": int(C),
                               "note": "input CHANNELS: the colour channels and the shortcut plane"},
            "n_val": nv, "pool": len(pool), "n_test": len(test), "split_seed": int(p["split_seed"])}
    aug = cfg.get("augment", "default")
    aug = "none" if aug == "default" else aug
    if aug == "crop_flip":
        raise ValueError("image_shortcut: crop_flip would pad the shortcut plane; use none or flip")
    return finalize_bundle(cfg=cfg, name=name, family="D07", task="classification", layout="img",
                           input_spec={"x": {"shape": [int(C) + 1, int(H), int(W)], "dtype": "float"}},
                           out_dim=2, pool=pool, val=val, test=test,
                           extra={"shift": shift, "val_indep": val_indep, "val_reversed": val_reversed,
                                  "cf_base": cf_base, "cf_shortcut": cf_shortcut},
                           preprocess_fn=preprocess_fn, augment=aug, meta=meta)
