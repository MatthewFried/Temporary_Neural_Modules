"""Dataset registry and the `data:` config section schema."""
from __future__ import annotations

from pathlib import Path
from typing import Callable, Optional

from .augment import AUGMENT_KINDS
from .bundle import DataBundle
from . import images, sequence, synthetic, tabular

# Schema of the `data:` config section (unknown keys are rejected).
DATA_DEFAULTS = {
    "name": None,            # required; key of DATASETS
    "n_train": 512,          # int or 'full' (whole training pool)
    "data_seed": 0,          # inputs, nested-subset order, train-only corruption
    "teacher_seed": 0,       # target-function parameters
    "label_noise": 0.0,      # classification: fraction of TRAIN labels -> random different class
    "target_noise": 0.0,     # regression: Gaussian std (standardised units) on TRAIN targets
    "n_val": 2048,           # synthetic / sequence sizes (real datasets use their own fixed splits)
    "n_test": 8192,
    "augment": "default",    # 'default' | 'none' | 'crop_flip' | 'flip' (images only)
    "params": {},            # dataset-specific, validated by the builder
}

# name -> (family, builder, default params)
DATASETS: dict[str, tuple[str, Callable, dict]] = {
    "linear_rank": ("D01", synthetic.build_linear_rank, synthetic.LINEAR_RANK_DEFAULTS),
    "teacher": ("D02", synthetic.build_teacher, synthetic.TEACHER_DEFAULTS),
    "frequency": ("D03", synthetic.build_frequency, synthetic.FREQUENCY_DEFAULTS),
    "compose": ("D03", synthetic.build_compose, synthetic.COMPOSE_DEFAULTS),
    "flat": ("D03", synthetic.build_flat, synthetic.FLAT_DEFAULTS),
    "easy_teacher": ("D03", synthetic.build_easy_teacher, synthetic.EASY_TEACHER_DEFAULTS),
    "parity": ("D04", synthetic.build_parity, synthetic.PARITY_DEFAULTS),
    "multiplexer": ("D04", synthetic.build_multiplexer, synthetic.MULTIPLEXER_DEFAULTS),
    "delayed_query": ("D04", synthetic.build_delayed_query, synthetic.DELAYED_QUERY_DEFAULTS),
    "later_query": ("D04", synthetic.build_later_query, synthetic.LATER_QUERY_DEFAULTS),
    "shortcut": ("D05", synthetic.build_shortcut, synthetic.SHORTCUT_DEFAULTS),
    "digits": ("D06", tabular.build_digits, tabular.DIGITS_DEFAULTS),
    "covertype": ("D06", tabular.build_covertype, tabular.COVERTYPE_DEFAULTS),
    "california": ("D06", tabular.build_california, tabular.CALIFORNIA_DEFAULTS),
    "fashion_mnist": ("D07", images.build_fashion_mnist, images.IMAGE_DEFAULTS),
    "cifar10": ("D07", images.build_cifar10, images.IMAGE_DEFAULTS),
    "cifar100": ("D07", images.build_cifar100, images.IMAGE_DEFAULTS),
    "toy_images": ("D07", images.build_toy_images, images.TOY_DEFAULTS),   # engineering tests only
    "image_shortcut": ("D07", images.build_image_shortcut, images.IMAGE_SHORTCUT_DEFAULTS),   # v65
    "seq_copy": ("D08", sequence.build_seq_copy, sequence.SEQ_COPY_DEFAULTS),
    "seq_select": ("D08", sequence.build_seq_select, sequence.SEQ_SELECT_DEFAULTS),
    "seq_compose": ("D08", sequence.build_seq_compose, sequence.SEQ_COMPOSE_DEFAULTS),
}

NEEDS_DOWNLOAD = ("covertype", "california", "fashion_mnist", "cifar10", "cifar100")


def dataset_param_defaults(name: str) -> dict:
    if name not in DATASETS:
        raise ValueError(f"unknown dataset {name!r}; known: {sorted(DATASETS)}")
    return dict(DATASETS[name][2])


def resolve_data_cfg(data_cfg: dict) -> dict:
    """Merge with defaults, reject unknown keys, fill dataset params."""
    unknown = set(data_cfg) - set(DATA_DEFAULTS)
    if unknown:
        raise ValueError(f"unknown data config keys {sorted(unknown)}; allowed {sorted(DATA_DEFAULTS)}")
    cfg = dict(DATA_DEFAULTS)
    cfg.update(data_cfg)
    if cfg["name"] not in DATASETS:
        raise ValueError(f"unknown dataset {cfg['name']!r}; known: {sorted(DATASETS)}")
    if cfg["n_train"] != "full" and not (isinstance(cfg["n_train"], int) and cfg["n_train"] > 0):
        raise ValueError("n_train must be a positive int or 'full'")
    if cfg["augment"] not in ("default",) + AUGMENT_KINDS:
        raise ValueError(f"augment must be one of {('default',) + AUGMENT_KINDS}")
    fam = DATASETS[cfg["name"]][0]
    if fam != "D07" and cfg["augment"] not in ("default", "none"):
        raise ValueError("image augmentation requested for a non-image dataset")
    params = dict(cfg.get("params") or {})
    unknown = set(params) - set(DATASETS[cfg["name"]][2])
    if unknown:
        raise ValueError(f"dataset {cfg['name']!r}: unknown params {sorted(unknown)}")
    full = dataset_param_defaults(cfg["name"])
    full.update(params)
    cfg["params"] = full
    for k in ("label_noise", "target_noise"):
        cfg[k] = float(cfg[k])
        if not 0.0 <= cfg[k] < (1.0 if k == "label_noise" else 1e9):
            raise ValueError(f"{k} out of range")
    return cfg


def load_bundle(data_cfg: dict, root: str | Path | None = None, device="cpu") -> DataBundle:
    cfg = resolve_data_cfg(data_cfg)
    family, builder, _ = DATASETS[cfg["name"]]
    b = builder(cfg, Path(root) if root is not None else None)
    if b.family != family:
        raise RuntimeError("family mismatch")
    if b.layout != "img":
        b.augment = "none"
    b.meta["resolved_data_cfg"] = {k: v for k, v in cfg.items()}
    return b.to(device) if str(device) != "cpu" else b


def fetch_all(root: str | Path, names: Optional[list[str]] = None) -> dict:
    """Download every dataset that needs network access into root (for offline runs)."""
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    names = list(NEEDS_DOWNLOAD) if names is None else names
    report = {}
    for n in names:
        try:
            if n in ("fashion_mnist", "cifar10", "cifar100"):
                images._load_tv(n, root, download=True)
            elif n == "covertype":
                from sklearn.datasets import fetch_covtype
                fetch_covtype(data_home=str(root / "sklearn"), download_if_missing=True)
            elif n == "california":
                from sklearn.datasets import fetch_california_housing
                fetch_california_housing(data_home=str(root / "sklearn"), download_if_missing=True)
            else:
                report[n] = "no download needed"
                continue
            report[n] = "ok"
        except Exception as e:  # keep going; report every failure
            report[n] = f"failed: {type(e).__name__}: {e}"
    return report
