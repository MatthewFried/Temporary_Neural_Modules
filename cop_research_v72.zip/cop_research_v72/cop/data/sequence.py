"""D08 generated sequence computation.

Token layout: symbols 0..V-1, PAD=V, DELIM=V+1, BLANK=V+2, task tokens from V+3.
X = {'x': tokens (N, T) long}; y = (N, T) long with -100 at non-target
positions; out_dim = total vocabulary (targets are always symbols < V).
Models are expected to be causal (or at least to respect that the query
arrives at the end); the data contain no early copy of the query.

  seq_copy   : [s_1..s_l, DELIM, BLANK x (l-1), PAD..]; targets s_1..s_l at positions l..2l-1.
  seq_select : [s_1..s_l, QUERY_p, PAD..]; target at position l is s_p (late selection).
  seq_compose: [a, OP_o1, .., OP_ok, PAD..]; state_j = perm[o_j][state_{j-1}];
               target state_k at the last op position (all intermediate states if
               intermediate_targets=True).
Lengths l are uniform in [min_length, length] for train/val/test and uniform
in [length+1, extrap_length] for the separately named 'extrap' partition.
Pool rows identical (as token rows) to any val/test row are removed, so the
training pool is disjoint from val/test.
"""
from __future__ import annotations

import torch

from ..utils import torch_gen
from .bundle import Partition
from .common import check_params, finalize_bundle
from .splits import row_codes

SEQ_COPY_DEFAULTS = {"vocab": 16, "length": 8, "min_length": None, "extrap_length": 16, "pool_size": 32768,
                     "n_extrap": 4096}
SEQ_SELECT_DEFAULTS = dict(SEQ_COPY_DEFAULTS)
SEQ_COMPOSE_DEFAULTS = {"vocab": 8, "n_ops": 4, "length": 8, "min_length": None, "extrap_length": 16,
                        "intermediate_targets": False, "pool_size": 32768, "n_extrap": 4096}


def _lengths(n, lo, hi, g):
    return torch.randint(lo, hi + 1, (n,), generator=g)


def _gen_copy(n, lo, hi, V, g):
    T = 2 * hi
    l = _lengths(n, lo, hi, g).unsqueeze(1)
    s = torch.randint(0, V, (n, T), generator=g)
    pos = torch.arange(T).unsqueeze(0)
    PAD, DELIM, BLANK = V, V + 1, V + 2
    x = torch.full((n, T), PAD, dtype=torch.long)
    x = torch.where(pos < l, s, x)
    x = torch.where(pos == l, torch.full_like(x, DELIM), x)
    x = torch.where((pos > l) & (pos < 2 * l), torch.full_like(x, BLANK), x)
    src = (pos - l).clamp(0, T - 1).expand(n, T)
    y = torch.where((pos >= l) & (pos < 2 * l), s.gather(1, src), torch.full((n, T), -100, dtype=torch.long))
    return x, y


def _gen_select(n, lo, hi, V, g):
    T = hi + 1
    l = _lengths(n, lo, hi, g)
    s = torch.randint(0, V, (n, T), generator=g)
    p = (torch.rand(n, generator=g) * l).long().clamp_max(l - 1)   # uniform in [0, l)
    pos = torch.arange(T).unsqueeze(0)
    L1 = l.unsqueeze(1)
    x = torch.full((n, T), V, dtype=torch.long)
    x = torch.where(pos < L1, s, x)
    x = torch.where(pos == L1, (V + 3 + p).unsqueeze(1).expand(n, T), x)
    y = torch.full((n, T), -100, dtype=torch.long)
    y[torch.arange(n), l] = s.gather(1, p.unsqueeze(1)).squeeze(1)
    return x, y


def _gen_compose(n, lo, hi, V, perms, intermediate, g):
    n_ops = perms.shape[0]
    T = hi + 1
    l = _lengths(n, lo, hi, g)
    a = torch.randint(0, V, (n,), generator=g)
    ops = torch.randint(0, n_ops, (n, hi), generator=g)
    x = torch.full((n, T), V, dtype=torch.long)
    x[:, 0] = a
    y = torch.full((n, T), -100, dtype=torch.long)
    state = a.clone()
    for j in range(1, hi + 1):
        active = j <= l
        o = ops[:, j - 1]
        x[:, j] = torch.where(active, V + 3 + o, x[:, j])
        nxt = perms[o, state]
        state = torch.where(active, nxt, state)
        if intermediate:
            y[:, j] = torch.where(active, state, y[:, j])
    y[torch.arange(n), l] = state
    return x, y


def _seq_bundle(cfg, name, p, gen_fn, vocab_total, V, meta):
    L = int(p["length"])
    lo = L if p["min_length"] is None else int(p["min_length"])
    Le = int(p["extrap_length"])
    if not 1 <= lo <= L < Le:
        raise ValueError("need 1 <= min_length <= length < extrap_length")
    ds = int(cfg["data_seed"])

    def mk(n, key, lo_, hi_, pmeta=None):
        x, y = gen_fn(n, lo_, hi_, torch_gen(ds, "data", name, key))
        return Partition({"x": x}, y, None, None, {}, pmeta or {})

    val = mk(int(cfg["n_val"]), "val", lo, L)
    test = mk(int(cfg["n_test"]), "test", lo, L)
    pool = mk(int(p["pool_size"]), "pool", lo, L)
    held = torch.cat([row_codes(val.X["x"], vocab_total), row_codes(test.X["x"], vocab_total)])
    keep = ~torch.isin(row_codes(pool.X["x"], vocab_total), held)
    n_removed = int((~keep).sum())
    pool = pool.index(torch.nonzero(keep).flatten())
    extrap = mk(int(p["n_extrap"]), "extrap", L + 1, Le,
                {"note": f"length extrapolation: lengths {L + 1}..{Le} (train {lo}..{L})"})
    meta.update({"params": p, "vocab_total": vocab_total, "n_symbols": V,
                 "specials": {"PAD": V, "DELIM": V + 1, "BLANK": V + 2, "task_tokens_from": V + 3},
                 "train_lengths": [lo, L], "extrap_lengths": [L + 1, Le],
                 "pool_rows_removed_overlapping_val_test": n_removed, "pool_size_realised": len(pool)})
    return finalize_bundle(cfg=cfg, name=name, family="D08", task="seq_classification", layout="seq",
                           input_spec={"x": {"shape": [int(pool.X["x"].shape[1])], "dtype": "long",
                                             "vocab": vocab_total}},
                           out_dim=vocab_total, pool=pool, val=val, test=test, extra={"extrap": extrap},
                           meta=meta, seq_n_symbols=V)


def build_seq_copy(cfg: dict, root=None):
    p = check_params("seq_copy", cfg.get("params", {}), SEQ_COPY_DEFAULTS)
    V = int(p["vocab"])
    return _seq_bundle(cfg, "seq_copy", p, lambda n, lo, hi, g: _gen_copy(n, lo, hi, V, g), V + 3, V,
                       {"generator": "copy after delimiter (see module docstring)"})


def build_seq_select(cfg: dict, root=None):
    p = check_params("seq_select", cfg.get("params", {}), SEQ_SELECT_DEFAULTS)
    V = int(p["vocab"])
    P = max(int(p["length"]), int(p["extrap_length"]))
    return _seq_bundle(cfg, "seq_select", p, lambda n, lo, hi, g: _gen_select(n, lo, hi, V, g), V + 3 + P, V,
                       {"generator": "late selection: query token at the end names a position",
                        "query_token_range": [V + 3, V + 3 + P]})


def build_seq_compose(cfg: dict, root=None):
    p = check_params("seq_compose", cfg.get("params", {}), SEQ_COMPOSE_DEFAULTS)
    V, n_ops = int(p["vocab"]), int(p["n_ops"])
    g = torch_gen(int(cfg["teacher_seed"]), "teacher", "seq_compose", "perms")
    perms = torch.stack([torch.randperm(V, generator=g) for _ in range(n_ops)])
    inter = bool(p["intermediate_targets"])
    return _seq_bundle(cfg, "seq_compose", p,
                       lambda n, lo, hi, gg: _gen_compose(n, lo, hi, V, perms, inter, gg), V + 3 + n_ops, V,
                       {"generator": "state tracking under fixed permutations", "perms": perms.tolist()})
