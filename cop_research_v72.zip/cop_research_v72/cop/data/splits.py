"""Split, subset, corruption and preprocessing helpers shared by all data families.

Design rules (spec section 5):
  * validation/test partitions never depend on n_train;
  * training subsets are nested: subset(n) is a prefix of subset(m) for n < m;
  * corruption is decided per *pool element* so the same example carries the
    same (possibly corrupted) label at every sample size;
  * preprocessing statistics are fitted on the selected training subset only.
"""
from __future__ import annotations

import math
from typing import Optional

import numpy as np
import torch

from ..utils import np_gen, torch_gen

DIRECT_ENUMERATION_LIMIT = 2 ** 22   # enumerate/permute a finite domain directly below this size
COMPLETE_DOMAIN_LIMIT = 2 ** 16      # attach a 'complete_domain' evaluation partition below this size


# ----------------------------------------------------------------------------
# Stratified / random splits of a fixed array of examples
# ----------------------------------------------------------------------------

def stratified_split(labels: np.ndarray, sizes: dict[str, int], seed: int, *keys) -> dict[str, np.ndarray]:
    """Split indices 0..N-1 into named parts with (approximately) the label
    proportions of the whole set.  Parts with size None/-1 take the remainder
    (at most one).  Deterministic given (seed, keys)."""
    labels = np.asarray(labels)
    N = len(labels)
    rng = np_gen(seed, "split", "stratified", *keys)
    classes = np.unique(labels)
    fixed = {k: v for k, v in sizes.items() if v is not None and v >= 0}
    rest = [k for k, v in sizes.items() if v is None or v < 0]
    if len(rest) > 1:
        raise ValueError("at most one remainder part")
    if sum(fixed.values()) > N:
        raise ValueError(f"split sizes {sizes} exceed N={N}")
    # per-class shuffled index lists
    per_class = {c: rng.permutation(np.flatnonzero(labels == c)) for c in classes}
    frac = {c: len(per_class[c]) / N for c in classes}
    out: dict[str, list] = {k: [] for k in sizes}
    cursor = {c: 0 for c in classes}
    for part, size in fixed.items():
        # largest-remainder allocation of `size` across classes
        raw = {c: size * frac[c] for c in classes}
        alloc = {c: int(math.floor(raw[c])) for c in classes}
        short = size - sum(alloc.values())
        order = sorted(classes, key=lambda c: (-(raw[c] - alloc[c]), c))
        for c in order[:short]:
            alloc[c] += 1
        for c in classes:
            avail = len(per_class[c]) - cursor[c]
            take = min(alloc[c], avail)
            out[part].extend(per_class[c][cursor[c]:cursor[c] + take].tolist())
            cursor[c] += take
        missing = size - len(out[part])
        if missing > 0:  # some class exhausted: fill from others deterministically
            for c in classes:
                avail = len(per_class[c]) - cursor[c]
                take = min(avail, missing)
                out[part].extend(per_class[c][cursor[c]:cursor[c] + take].tolist())
                cursor[c] += take
                missing -= take
                if missing == 0:
                    break
    if rest:
        left = []
        for c in classes:
            left.extend(per_class[c][cursor[c]:].tolist())
        out[rest[0]] = left
    return {k: np.sort(np.asarray(v, dtype=np.int64)) for k, v in out.items()}


def random_split(N: int, sizes: dict[str, int], seed: int, *keys) -> dict[str, np.ndarray]:
    rng = np_gen(seed, "split", "random", *keys)
    perm = rng.permutation(N)
    out, pos = {}, 0
    rest = [k for k, v in sizes.items() if v is None or v < 0]
    for k, v in sizes.items():
        if v is None or v < 0:
            continue
        out[k] = np.sort(perm[pos:pos + v])
        pos += v
    if pos > N:
        raise ValueError(f"split sizes {sizes} exceed N={N}")
    if rest:
        out[rest[0]] = np.sort(perm[pos:])
    return out


# ----------------------------------------------------------------------------
# Nested training subsets
# ----------------------------------------------------------------------------

def nested_order(pool_labels: Optional[torch.Tensor], pool_size: int, seed: int, *keys,
                 balanced: bool = True) -> torch.Tensor:
    """Global order of pool indices; the training subset of size n is the
    prefix of length n.  For classification with balanced=True the order is a
    round-robin over classes (class visiting order itself a fixed random
    permutation), each class contributing the next element of its own fixed
    random permutation; exhausted classes are skipped.  Hence every prefix is
    as class-balanced as the pool allows, and prefixes are nested."""
    g = torch_gen(seed, "subset", "nested_order", *keys)
    if pool_labels is None or not balanced:
        return torch.randperm(pool_size, generator=g)
    labels = pool_labels.cpu().long()
    classes = torch.unique(labels)
    C = len(classes)
    class_order = classes[torch.randperm(C, generator=g)]
    lists = []
    for c in class_order.tolist():
        idx = torch.nonzero(labels == c, as_tuple=False).flatten()
        lists.append(idx[torch.randperm(len(idx), generator=g)])
    maxlen = max(len(l) for l in lists)
    # (C, maxlen) padded matrix, read column by column = round robin
    mat = torch.full((C, maxlen), -1, dtype=torch.long)
    for i, l in enumerate(lists):
        mat[i, :len(l)] = l
    flat = mat.t().reshape(-1)
    return flat[flat >= 0]


def select_subset(order: torch.Tensor, n_train) -> torch.Tensor:
    if n_train == "full":
        return order.clone()
    n = int(n_train)
    if n <= 0:
        raise ValueError("n_train must be positive")
    if n > len(order):
        raise ValueError(f"n_train={n} exceeds the available training pool ({len(order)})")
    return order[:n].clone()


# ----------------------------------------------------------------------------
# Train-only corruption (decided per pool element => consistent across n_train)
# ----------------------------------------------------------------------------

def pool_label_corruption(pool_y: torch.Tensor, n_classes: int, frac: float, seed: int, *keys,
                          ignore_index: Optional[int] = None) -> torch.Tensor:
    """Return corrupted copy of pool labels.  Each element is corrupted
    independently with probability `frac`; a corrupted element gets a
    uniformly random *different* class.  Works for (N,) and (N,T) labels;
    entries equal to ignore_index are never touched."""
    if frac <= 0:
        return pool_y.clone()
    if n_classes < 2:
        raise ValueError("label corruption needs >= 2 classes")
    g = torch_gen(seed, "noise", "labels", *keys)
    u = torch.rand(pool_y.shape, generator=g)
    off = torch.randint(1, n_classes, pool_y.shape, generator=g)
    y = pool_y.clone()
    mask = u < frac
    if ignore_index is not None:
        mask &= pool_y != ignore_index
    y[mask] = (pool_y[mask] + off[mask]) % n_classes
    return y


def pool_target_noise(pool_shape, std: float, seed: int, *keys) -> torch.Tensor:
    g = torch_gen(seed, "noise", "targets", *keys)
    return torch.randn(pool_shape, generator=g) * std


# ----------------------------------------------------------------------------
# Standardisation fitted on the training subset only
# ----------------------------------------------------------------------------

def standardise_fit(x: torch.Tensor, cols: Optional[list[int]] = None, eps: float = 1e-8) -> dict:
    x = x.double()
    D = x.shape[1]
    mean = torch.zeros(D, dtype=torch.float64)
    std = torch.ones(D, dtype=torch.float64)
    cols = list(range(D)) if cols is None else list(cols)
    if cols:
        c = torch.tensor(cols)
        mean[c] = x[:, c].mean(0)
        s = x[:, c].std(0, unbiased=False)
        s[s < eps] = 1.0
        std[c] = s
    return {"mean": mean.float(), "std": std.float(), "cols": cols}


def standardise_apply(x: torch.Tensor, stats: dict) -> torch.Tensor:
    return (x.float() - stats["mean"]) / stats["std"]


# ----------------------------------------------------------------------------
# Finite domains: disjoint sampling of integer codes
# ----------------------------------------------------------------------------

def finite_domain_split(domain_size: int, n_pool: int, n_val: int, n_test: int, seed: int, *keys
                        ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, dict]:
    """Draw pool/val/test integer codes from {0..domain_size-1} WITHOUT
    replacement, so the three are disjoint.  If the requested sizes exceed the
    domain, val/test are shrunk to 15%/25% of the domain and the pool takes the
    rest (recorded in the returned meta)."""
    meta = {"domain_size": int(domain_size), "requested": {"pool": n_pool, "val": n_val, "test": n_test}}
    if n_pool + n_val + n_test > domain_size:
        n_val = min(n_val, int(0.15 * domain_size))
        n_test = min(n_test, int(0.25 * domain_size))
        n_pool = min(n_pool, domain_size - n_val - n_test)
        meta["shrunk_to_domain"] = True
    total = n_pool + n_val + n_test
    if domain_size <= DIRECT_ENUMERATION_LIMIT:
        g = torch_gen(seed, "data", "finite_domain", *keys)
        codes = torch.randperm(domain_size, generator=g)[:total]
        meta["mode"] = "permutation_of_complete_domain"
    else:
        rng = np_gen(seed, "data", "finite_domain", *keys)
        got = np.empty(0, dtype=np.int64)
        while len(got) < total:
            k = int((total - len(got)) * 1.2) + 128
            draw = rng.integers(0, domain_size, size=k, dtype=np.int64)
            allc = np.concatenate([got, draw])
            _, first = np.unique(allc, return_index=True)
            got = allc[np.sort(first)]
        codes = torch.from_numpy(got[:total].copy())
        meta["mode"] = "sampled_unique_codes"
    val = codes[:n_val]
    test = codes[n_val:n_val + n_test]
    pool = codes[n_val + n_test:]
    meta.update({"pool": int(len(pool)), "val": int(len(val)), "test": int(len(test))})
    return pool, val, test, meta


def codes_to_bits(codes: torch.Tensor, n_bits: int) -> torch.Tensor:
    """Integer codes -> (N, n_bits) {0,1} long tensor; bit j = (code >> j) & 1."""
    shifts = torch.arange(n_bits, dtype=torch.long)
    return (codes.long().unsqueeze(1) >> shifts) & 1


def row_codes(tokens: torch.Tensor, base: int) -> torch.Tensor:
    """Exact-equality-preserving 64-bit rolling hash of integer rows (identical
    rows always collide, so excluding by code gives exact disjointness; a
    spurious collision can only remove extra rows)."""
    t = tokens.long()
    h = torch.zeros(t.shape[0], dtype=torch.long)
    mult = 1000003
    for j in range(t.shape[1]):
        h = h * mult + (t[:, j] + 1)  # int64 wrap-around is fine for hashing
    return h * 31 + t.shape[1]
