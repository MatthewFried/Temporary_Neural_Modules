"""Synthetic data families D01-D05.

Stream discipline (all keyed additionally by the dataset name):
  inputs (pool/val/test)            -> 'data'    stream, data_seed
  target-function parameters        -> 'teacher' stream, teacher_seed
  reference sample for target scale -> 'teacher' stream, teacher_seed ('reference')
  fresh-sample streams (I2)         -> caller-supplied generator (use 'fresh')
  train-only corruption             -> 'noise'   stream, data_seed (in common.finalize_bundle)
Changing teacher_seed never changes inputs; changing data_seed never changes
the target function.

Regression targets are standardised per output dimension with mean/std taken
from a separate reference sample of REFERENCE_N inputs drawn from the
'teacher' stream (never from train/val/test).  After standardisation targets
have ~unit variance, so target_scale = 1.0; the raw scale is in meta.
D01 uses an exact analytic scalar scale instead (to keep y = M_eff x linear).
"""
from __future__ import annotations

import math
from typing import Callable

import torch
import torch.nn.functional as F

from ..utils import torch_gen
from .bundle import Partition
from .common import check_params, finalize_bundle
from .splits import COMPLETE_DOMAIN_LIMIT, codes_to_bits, finite_domain_split

REFERENCE_N = 65536
DEFAULT_GAIN = {"relu": math.sqrt(2.0), "gelu": math.sqrt(2.0), "tanh": 1.5}
ACTS = {"relu": torch.relu, "gelu": F.gelu, "tanh": torch.tanh}


def _vec_spec(d: int) -> dict:
    return {"x": {"shape": [int(d)], "dtype": "float"}}


def _part(x, y, aux=None, groups=None, meta=None, X=None) -> Partition:
    return Partition(X if X is not None else {"x": x}, y, None, groups, aux or {}, meta or {})


# ----------------------------------------------------------------------------
# Generic continuous-input builder
# ----------------------------------------------------------------------------

def _continuous_bundle(cfg: dict, name: str, family: str, d_in: int, out_dim: int, task: str,
                       target_fn: Callable[[torch.Tensor], tuple[torch.Tensor, dict]],
                       pool_size: int, meta: dict, standardise: bool = True,
                       analytic_scale: float | None = None, fresh: bool = True):
    """x ~ N(0, I_d_in); target_fn(x) -> (raw targets, aux dict).  For
    regression the raw targets are standardised with reference statistics."""
    ds, ts = int(cfg["data_seed"]), int(cfg["teacher_seed"])
    g_ref = torch_gen(ts, "teacher", name, "reference")
    if task == "regression":
        if analytic_scale is not None:
            mu = torch.zeros(out_dim)
            sd = torch.full((out_dim,), float(analytic_scale))
        elif standardise:
            x_ref = torch.randn(REFERENCE_N, d_in, generator=g_ref)
            y_ref, _ = target_fn(x_ref)
            mu = y_ref.mean(0)
            sd = y_ref.std(0, unbiased=False).clamp_min(1e-8)
        else:
            mu, sd = torch.zeros(out_dim), torch.ones(out_dim)
        meta["target_standardisation"] = {"mean": mu.tolist(), "std": sd.tolist(),
                                          "source": "analytic" if analytic_scale is not None else
                                          f"reference sample n={REFERENCE_N} from teacher stream"}
    else:
        mu = sd = None

    def make(x):
        y, aux = target_fn(x)
        if task == "regression":
            y = ((y - mu) / sd).float()
        return y, aux

    def gen_part(n, g):
        x = torch.randn(n, d_in, generator=g)
        y, aux = make(x)
        return _part(x, y, aux)

    pool = gen_part(pool_size, torch_gen(ds, "data", name, "pool"))
    val = gen_part(int(cfg["n_val"]), torch_gen(ds, "data", name, "val"))
    test = gen_part(int(cfg["n_test"]), torch_gen(ds, "data", name, "test"))

    fresh_sampler = None
    if fresh:
        ln, tn = float(cfg.get("label_noise", 0.0)), float(cfg.get("target_noise", 0.0))
        n_cls = out_dim

        def fresh_sampler(n: int, g: torch.Generator) -> Partition:
            p = gen_part(n, g)
            p.y_clean = p.y.clone()
            if task == "regression" and tn > 0:
                p.y = p.y + torch.randn(p.y.shape, generator=g) * tn
            if task == "classification" and ln > 0:
                u = torch.rand(p.y.shape, generator=g)
                off = torch.randint(1, n_cls, p.y.shape, generator=g)
                m = u < ln
                p.y = p.y.clone()
                p.y[m] = (p.y[m] + off[m]) % n_cls
            return p

    meta["input_distribution"] = f"N(0, I_{d_in})"
    return finalize_bundle(cfg=cfg, name=name, family=family, task=task, layout="vec",
                           input_spec=_vec_spec(d_in), out_dim=out_dim, pool=pool, val=val, test=test,
                           target_scale=1.0, fresh_sampler=fresh_sampler, meta=meta)


# ----------------------------------------------------------------------------
# D01 linear / low-rank
# ----------------------------------------------------------------------------

LINEAR_RANK_DEFAULTS = {"d_in": 32, "d_out": 16, "rank": 4, "spectrum": "flat", "pool_size": 32768}


def build_linear_rank(cfg: dict, root=None):
    name = "linear_rank"
    p = check_params(name, cfg.get("params", {}), LINEAR_RANK_DEFAULTS)
    d_in, d_out, r = int(p["d_in"]), int(p["d_out"]), int(p["rank"])
    if not 1 <= r <= min(d_in, d_out):
        raise ValueError(f"rank must be in [1, min(d_in,d_out)]; got {r}")
    g = torch_gen(int(cfg["teacher_seed"]), "teacher", name, "matrix")
    U, _ = torch.linalg.qr(torch.randn(d_out, r, generator=g, dtype=torch.float64))
    V, _ = torch.linalg.qr(torch.randn(d_in, r, generator=g, dtype=torch.float64))
    if p["spectrum"] == "flat":
        s = torch.ones(r, dtype=torch.float64)
    elif p["spectrum"] == "decay":
        s = 1.0 / torch.arange(1, r + 1, dtype=torch.float64)
    else:
        raise ValueError("spectrum must be 'flat' or 'decay'")
    M = U @ torch.diag(s) @ V.T                                  # (d_out, d_in)
    # E||Mx||^2 / d_out = ||M||_F^2 / d_out for x ~ N(0,I)
    scale = math.sqrt(float((M ** 2).sum()) / d_out)
    M_eff = M / scale
    sv_eff = (s / scale)

    def target(x):
        return (x.double() @ M.T).float(), {}

    meta = {"generator": "y = M x, x~N(0,I)", "params": p, "M_effective": M_eff.tolist(),
            "singular_values_effective": sv_eff.tolist(), "rank": r,
            "note": "targets are y_raw/scale with scale = sqrt(||M||_F^2/d_out) so y = M_effective x; "
                    "Eckart-Young: best rank-k linear predictor has excess MSE sum_{i>k} sv_eff_i^2 / d_out per dim"}
    return _continuous_bundle(cfg, name, "D01", d_in, d_out, "regression", target, int(p["pool_size"]),
                              meta, analytic_scale=scale)


# ----------------------------------------------------------------------------
# D02 neural teacher (also used by D03 'easy_teacher')
# ----------------------------------------------------------------------------

TEACHER_DEFAULTS = {"teacher_width": 48, "teacher_depth": 3, "activation": "tanh", "d_in": 16,
                    "out_dim": 4, "task": "regression", "gain": None, "bias_std": 0.1, "pool_size": 32768}


def make_teacher(seed: int, name: str, d_in: int, width: int, depth: int, out_dim: int, act: str,
                 gain=None, bias_std: float = 0.1) -> dict:
    if act not in ACTS:
        raise ValueError(f"activation must be one of {sorted(ACTS)}")
    gain = DEFAULT_GAIN[act] if gain is None else float(gain)
    g = torch_gen(seed, "teacher", name, "weights")
    dims = [d_in] + [width] * depth + [out_dim]
    Ws, bs = [], []
    for i in range(len(dims) - 1):
        fan_in = dims[i]
        lg = gain if i < len(dims) - 2 else 1.0   # readout uses unit gain
        Ws.append(torch.randn(dims[i + 1], fan_in, generator=g) * (lg / math.sqrt(fan_in)))
        bs.append(torch.randn(dims[i + 1], generator=g) * bias_std)
    return {"weights": Ws, "biases": bs, "act": act, "gain": gain, "bias_std": bias_std, "dims": dims}


def teacher_raw(teacher: dict, x: torch.Tensor) -> torch.Tensor:
    f = ACTS[teacher["act"]]
    h = x.float()
    n = len(teacher["weights"])
    for i, (W, b) in enumerate(zip(teacher["weights"], teacher["biases"])):
        h = h @ W.to(h.device).T + b.to(h.device)
        if i < n - 1:
            h = f(h)
    return h


def teacher_forward(teacher: dict, x: torch.Tensor) -> torch.Tensor:
    """True (noiseless) target in the same units as bundle targets:
    standardised outputs for regression, logits for classification."""
    y = teacher_raw(teacher, x)
    if "target_mean" in teacher:
        y = (y - teacher["target_mean"].to(y.device)) / teacher["target_std"].to(y.device)
    return y


def _build_teacher_like(cfg, name, family, p):
    task = p["task"]
    if task not in ("regression", "classification"):
        raise ValueError("task must be regression or classification")
    t = make_teacher(int(cfg["teacher_seed"]), name, int(p["d_in"]), int(p["teacher_width"]),
                     int(p["teacher_depth"]), int(p["out_dim"]), p["activation"], p["gain"], float(p["bias_std"]))

    if task == "regression":
        def target(x):
            return teacher_raw(t, x), {}
    else:
        def target(x):
            return teacher_raw(t, x).argmax(1).long(), {}
    meta = {"generator": "frozen MLP teacher", "params": p, "teacher": t,
            "teacher_note": "weights ~ N(0, gain^2/fan_in) (readout gain 1), biases ~ N(0, bias_std^2); "
                            "default gain: relu/gelu sqrt(2), tanh 1.5"}
    b = _continuous_bundle(cfg, name, family, int(p["d_in"]), int(p["out_dim"]), task, target,
                           int(p["pool_size"]), meta)
    if task == "regression":
        st = b.meta["target_standardisation"]
        t["target_mean"] = torch.tensor(st["mean"])
        t["target_std"] = torch.tensor(st["std"])
    return b


def build_teacher(cfg: dict, root=None):
    p = check_params("teacher", cfg.get("params", {}), TEACHER_DEFAULTS)
    return _build_teacher_like(cfg, "teacher", "D02", p)


EASY_TEACHER_DEFAULTS = dict(TEACHER_DEFAULTS, teacher_width=4, teacher_depth=1, activation="relu", d_in=8,
                             out_dim=1)


def build_easy_teacher(cfg: dict, root=None):
    p = check_params("easy_teacher", cfg.get("params", {}), EASY_TEACHER_DEFAULTS)
    return _build_teacher_like(cfg, "easy_teacher", "D03", p)


# ----------------------------------------------------------------------------
# D03 frequency / composition / flat interaction
# ----------------------------------------------------------------------------

FREQUENCY_DEFAULTS = {"d_in": 8, "n_terms": 8, "omega": 2.0, "pool_size": 32768}


def build_frequency(cfg: dict, root=None):
    name = "frequency"
    p = check_params(name, cfg.get("params", {}), FREQUENCY_DEFAULTS)
    d, m, om = int(p["d_in"]), int(p["n_terms"]), float(p["omega"])
    g = torch_gen(int(cfg["teacher_seed"]), "teacher", name, "terms")
    w = torch.randn(m, d, generator=g)
    w = w / w.norm(dim=1, keepdim=True)
    a = torch.randn(m, generator=g)
    phi = torch.rand(m, generator=g) * 2 * math.pi

    def target(x):
        return (torch.sin(om * (x @ w.T) + phi) @ a).unsqueeze(1), {}

    meta = {"generator": "y = sum_j a_j sin(omega * w_j.x + phi_j), |w_j|=1", "params": p}
    return _continuous_bundle(cfg, name, "D03", d, 1, "regression", target, int(p["pool_size"]), meta)


COMPOSE_DEFAULTS = {"d_in": 8, "coef_scale": 1.5, "pool_size": 32768}


def _pair_feats(a, b):
    return torch.stack([a, b, a * b], dim=-1)


def build_compose(cfg: dict, root=None):
    """Balanced binary composition with known intermediates:
       z_k = tanh(P_k . [x_{2k}, x_{2k+1}, x_{2k} x_{2k+1}])        k = 0..d/2-1
       u_m = tanh(Q_m . [z_{2m}, z_{2m+1}, z_{2m} z_{2m+1}])        m = 0..d/4-1
       y   = R . [u_0, u_1, u_0 u_1]  (d=8)   -- generally a tree reduction.
    aux['z'] (N, d/2) and aux['u'] (N, d/4) are the known intermediate variables."""
    name = "compose"
    p = check_params(name, cfg.get("params", {}), COMPOSE_DEFAULTS)
    d = int(p["d_in"])
    if d < 8 or d & (d - 1):
        raise ValueError("compose needs d_in a power of two >= 8")
    cs = float(p["coef_scale"])
    g = torch_gen(int(cfg["teacher_seed"]), "teacher", name, "coefs")
    nz, nu = d // 2, d // 4
    P = torch.randn(nz, 3, generator=g) * cs
    Q = torch.randn(nu, 3, generator=g) * cs
    levels = []
    k = nu
    while k > 1:
        levels.append(torch.randn(k // 2, 3, generator=g) * cs)
        k //= 2
    R = torch.randn(3, generator=g)

    def target(x):
        z = torch.tanh((_pair_feats(x[:, 0::2], x[:, 1::2]) * P).sum(-1))
        u = torch.tanh((_pair_feats(z[:, 0::2], z[:, 1::2]) * Q).sum(-1))
        h = u
        for L in levels:
            if h.shape[1] == 2:
                break
            h = torch.tanh((_pair_feats(h[:, 0::2], h[:, 1::2]) * L).sum(-1))
        y = (_pair_feats(h[:, 0], h[:, 1]) * R).sum(-1, keepdim=True)
        return y, {"z": z, "u": u}

    def from_z(z):
        """Downstream map from level-1 intermediates to the RAW target (before
        standardisation); used for interchange-intervention diagnostics."""
        u = torch.tanh((_pair_feats(z[:, 0::2], z[:, 1::2]) * Q.to(z.device)).sum(-1))
        h = u
        for L in levels:
            if h.shape[1] == 2:
                break
            h = torch.tanh((_pair_feats(h[:, 0::2], h[:, 1::2]) * L.to(z.device)).sum(-1))
        return (_pair_feats(h[:, 0], h[:, 1]) * R.to(z.device)).sum(-1, keepdim=True)

    meta = {"generator": "balanced binary composition (see build_compose docstring)", "params": p,
            "from_z": from_z,
            "known_intermediates": {"z": f"level-1, from input pairs (2k,2k+1), k<{nz}",
                                    "u": f"level-2, from z pairs, m<{nu}"},
            "intermediate_input_groups": {"z": [[2 * k, 2 * k + 1] for k in range(nz)],
                                          "u": [[4 * m + j for j in range(4)] for m in range(nu)]}}
    return _continuous_bundle(cfg, name, "D03", d, 1, "regression", target, int(p["pool_size"]), meta)


FLAT_DEFAULTS = {"d_in": 8, "n_pair_terms": 8, "n_triple_terms": 8, "pool_size": 32768}


def build_flat(cfg: dict, root=None):
    """Flat interactions over the same input dimensions as 'compose': a random
    sparse polynomial of pair and triple products whose monomials cut across the
    compose pairs (no hierarchical intermediate).  Same input distribution and
    the same target standardisation rule as 'compose'."""
    name = "flat"
    p = check_params(name, cfg.get("params", {}), FLAT_DEFAULTS)
    d = int(p["d_in"])
    g = torch_gen(int(cfg["teacher_seed"]), "teacher", name, "monomials")
    pairs = torch.stack([torch.randperm(d, generator=g)[:2] for _ in range(int(p["n_pair_terms"]))])
    triples = torch.stack([torch.randperm(d, generator=g)[:3] for _ in range(int(p["n_triple_terms"]))])
    cp = torch.randn(len(pairs), generator=g)
    ct = torch.randn(len(triples), generator=g)

    def target(x):
        yp = (x[:, pairs[:, 0]] * x[:, pairs[:, 1]]) @ cp
        yt = (x[:, triples[:, 0]] * x[:, triples[:, 1]] * x[:, triples[:, 2]]) @ ct
        return (yp + yt).unsqueeze(1), {}

    meta = {"generator": "flat sparse polynomial (pair+triple monomials)", "params": p,
            "pairs": pairs.tolist(), "triples": triples.tolist()}
    return _continuous_bundle(cfg, name, "D03", d, 1, "regression", target, int(p["pool_size"]), meta)


# ----------------------------------------------------------------------------
# D04 parity / multiplexer / delayed query  (finite domains)
# ----------------------------------------------------------------------------

def _finite_bits_bundle(cfg, name, n_bits, label_fn, pool_size, meta, relevant):
    ds = int(cfg["data_seed"])
    D = 2 ** n_bits
    pool_c, val_c, test_c, dmeta = finite_domain_split(D, pool_size, int(cfg["n_val"]), int(cfg["n_test"]),
                                                       ds, name)

    def mk(codes, pmeta=None):
        bits = codes_to_bits(codes, n_bits)
        return _part((2 * bits - 1).float(), label_fn(bits), meta=pmeta or {})

    extra = {}
    if D <= COMPLETE_DOMAIN_LIMIT:
        extra["complete_domain"] = mk(torch.arange(D), {"complete_domain": True,
                                                        "note": "every domain point; overlaps train by construction"})
    meta.update({"domain": dmeta, "n_bits": n_bits, "relevant_positions": relevant,
                 "input_encoding": "bits in {-1,+1}", "complete_domain_partition": D <= COMPLETE_DOMAIN_LIMIT})
    b = finalize_bundle(cfg=cfg, name=name, family="D04", task="classification", layout="vec",
                        input_spec=_vec_spec(n_bits), out_dim=2, pool=mk(pool_c), val=mk(val_c),
                        test=mk(test_c), extra=extra, meta=meta)
    b.meta["train_domain_coverage"] = len(b.train) / D
    return b


PARITY_DEFAULTS = {"k": 4, "n_irrelevant": 12, "pool_size": 32768}


def build_parity(cfg: dict, root=None):
    name = "parity"
    p = check_params(name, cfg.get("params", {}), PARITY_DEFAULTS)
    k, n = int(p["k"]), int(p["k"]) + int(p["n_irrelevant"])
    if n > 62:
        raise ValueError("at most 62 bits")
    g = torch_gen(int(cfg["teacher_seed"]), "teacher", name, "positions")
    rel = torch.randperm(n, generator=g)[:k].sort().values

    def label(bits):
        return (bits[:, rel].sum(1) % 2).long()

    return _finite_bits_bundle(cfg, name, n, label, int(p["pool_size"]),
                               {"generator": "parity of k relevant bits", "params": p}, rel.tolist())


MULTIPLEXER_DEFAULTS = {"address_bits": 3, "n_irrelevant": 0, "pool_size": 32768}


def build_multiplexer(cfg: dict, root=None):
    name = "multiplexer"
    p = check_params(name, cfg.get("params", {}), MULTIPLEXER_DEFAULTS)
    a = int(p["address_bits"])
    n = a + 2 ** a + int(p["n_irrelevant"])
    if n > 62:
        raise ValueError("at most 62 bits")
    g = torch_gen(int(cfg["teacher_seed"]), "teacher", name, "positions")
    pos = torch.randperm(n, generator=g)
    addr, data = pos[:a], pos[a:a + 2 ** a]
    weights = 2 ** torch.arange(a)

    def label(bits):
        idx = (bits[:, addr] * weights).sum(1)
        return bits[:, data].gather(1, idx.unsqueeze(1)).squeeze(1).long()

    return _finite_bits_bundle(cfg, name, n, label, int(p["pool_size"]),
                               {"generator": "multiplexer: address bits select a data bit", "params": p,
                                "address_positions": addr.tolist(), "data_positions": data.tolist()},
                               addr.tolist() + data.tolist())


DELAYED_QUERY_DEFAULTS = {"n_bits": 12, "split_mode": "pairs", "pool_size": 32768, "query_op": "bit"}
# query_op (F09e): bit (y = x_q) | xor_next (compositional: y = x_q XOR x_{q+1 mod n})
#                  | two_bits (multiple query: y = 2 x_q + x_{q+1 mod n}, 4 classes)


def build_delayed_query(cfg: dict, root=None):
    """X = {'x': bits in {-1,+1} (N, n), 'q': one-hot query (N, n)}; y = bit x_q in {0,1}.
    The 'x' stream is a function of the x-code only, so it carries no information
    about q.  Where q may enter the network is a MODEL choice (query-after-peg vs
    the query-known-early control)."""
    name = "delayed_query"
    p = check_params(name, cfg.get("params", {}), DELAYED_QUERY_DEFAULTS)
    n = int(p["n_bits"])
    if n > 40:
        raise ValueError("n_bits <= 40")
    ds = int(cfg["data_seed"])
    mode = p["split_mode"]
    pool_size, n_val, n_test = int(p["pool_size"]), int(cfg["n_val"]), int(cfg["n_test"])

    op = p["query_op"]
    if op not in ("bit", "xor_next", "two_bits"):
        raise ValueError("query_op must be bit, xor_next or two_bits")

    def mk(xc, q, pmeta=None):
        bits = codes_to_bits(xc, n)
        y = bits.gather(1, q.unsqueeze(1)).squeeze(1).long()
        if op != "bit":
            y2 = bits.gather(1, ((q + 1) % n).unsqueeze(1)).squeeze(1).long()
            y = (y ^ y2) if op == "xor_next" else 2 * y + y2
        return Partition({"x": (2 * bits - 1).float(), "q": F.one_hot(q, n).float()}, y, None, None, {},
                         pmeta or {})

    if mode == "pairs":
        D = (2 ** n) * n
        pc, vc, tc, dmeta = finite_domain_split(D, pool_size, n_val, n_test, ds, name, "pairs")
        parts = [mk(c // n, c % n) for c in (pc, vc, tc)]
    elif mode == "complete":
        # v5 finite-interface benchmark: the training objective IS the complete-domain objective (every
        # (x, q) pair, uniform); val and test are the same complete domain (they include training inputs
        # by construction: an optimisation / communication study, not a generalisation one)
        D = (2 ** n) * n
        if D > COMPLETE_DOMAIN_LIMIT:
            raise ValueError("split_mode=complete needs a small domain (n * 2^n <= COMPLETE_DOMAIN_LIMIT)")
        allc = torch.arange(D)
        cm = {"complete_domain": True, "note": "complete domain; includes every training input"}
        parts = [mk(allc // n, allc % n, dict(cm)) for _ in range(3)]
        dmeta = {"domain_size": D, "mode": "complete_domain_train_val_test", "pool": D, "val": D, "test": D}
    elif mode == "x_holdout":
        D = (2 ** n) * n
        nx = lambda m: -(-m // n)
        pc, vc, tc, dmeta = finite_domain_split(2 ** n, nx(pool_size), nx(n_val), nx(n_test), ds, name, "x")
        g = torch_gen(ds, "split", name, "x_holdout_pairs")
        parts = []
        for c in (pc, vc, tc):
            xc = c.repeat_interleave(n)
            q = torch.arange(n).repeat(len(c))
            perm = torch.randperm(len(xc), generator=g)
            parts.append(mk(xc[perm], q[perm]))
        dmeta["unit"] = "x codes (each expanded to all n queries)"
    else:
        raise ValueError("split_mode must be 'pairs', 'x_holdout' or 'complete'")
    extra = {}
    if D <= COMPLETE_DOMAIN_LIMIT:
        allc = torch.arange(D)
        extra["complete_domain"] = mk(allc // n, allc % n,
                                      {"complete_domain": True, "note": "all (x, q) pairs; overlaps train"})
    meta = {"generator": {"bit": "delayed query: y = x_q", "xor_next": "y = x_q XOR x_(q+1)",
                          "two_bits": "y = (x_q, x_(q+1)) as 2 x_q + x_(q+1)"}[op], "params": p, "domain": dmeta,
            "pair_domain_size": D,
            "complete_domain_partition": D <= COMPLETE_DOMAIN_LIMIT,
            "query_stream": "q", "leakage_note": "x stream depends only on x-code; q enters only via X['q']"}
    spec = {"x": {"shape": [n], "dtype": "float"}, "q": {"shape": [n], "dtype": "float"}}
    b = finalize_bundle(cfg=cfg, name=name, family="D04", task="classification", layout="vec",
                        input_spec=spec, out_dim=4 if op == "two_bits" else 2, pool=parts[0], val=parts[1],
                        test=parts[2], extra=extra, meta=meta)
    b.meta["train_domain_coverage"] = len(b.train) / D
    return b


LATER_QUERY_DEFAULTS = {"n_bits": 8, "task_bits": 1, "pool_size": 32768, "split_mode": "x"}


def build_later_query(cfg: dict, root=None):
    """Mechanism E: x uniform on {0,1}^n (as +-1 inputs).  The initial task uses only the
    first task_bits bits (task_bits = 1: y = x_0; otherwise their parity).  The predeclared
    later-query family is every single bit x_j (aux['later'], N x n in {0,1}): a peg may be
    sufficient for the initial task and insufficient for the later queries; later queries
    are evaluated by decoders fitted on TRAINING codes (no input re-access) next to an
    input re-access control."""
    name = "later_query"
    p = check_params(name, cfg.get("params", {}), LATER_QUERY_DEFAULTS)
    n, k = int(p["n_bits"]), int(p["task_bits"])
    if not 1 <= k <= n <= 24:
        raise ValueError("need 1 <= task_bits <= n_bits <= 24")
    ds = int(cfg["data_seed"])
    if p["split_mode"] == "complete":
        # v5 retention benchmark: train, val and test are all the complete cube (see delayed_query 'complete')
        if 2 ** n > COMPLETE_DOMAIN_LIMIT:
            raise ValueError("split_mode=complete needs 2^n <= COMPLETE_DOMAIN_LIMIT")
        pc = vc = tc = torch.arange(2 ** n)
        dmeta = {"domain_size": 2 ** n, "mode": "complete_domain_train_val_test", "pool": 2 ** n, "val": 2 ** n,
                 "test": 2 ** n}
    elif p["split_mode"] == "x":
        pc, vc, tc, dmeta = finite_domain_split(2 ** n, int(p["pool_size"]), int(cfg["n_val"]), int(cfg["n_test"]),
                                                ds, name, "x")
    else:
        raise ValueError("later_query split_mode must be 'x' or 'complete'")

    def mk(codes, pmeta=None):
        bits = codes_to_bits(codes, n)
        y = bits[:, 0].long() if k == 1 else (bits[:, :k].sum(1) % 2).long()
        return Partition({"x": (2 * bits - 1).float()}, y, None, None, {"later": bits.float()}, pmeta or {})
    parts = [mk(c) for c in (pc, vc, tc)]
    extra = {}
    if 2 ** n <= COMPLETE_DOMAIN_LIMIT:
        extra["complete_domain"] = mk(torch.arange(2 ** n), {"complete_domain": True, "note": "overlaps train"})
    meta = {"generator": "initial task on the first task_bits bits; later queries: every bit", "params": p,
            "domain": dmeta, "later_queries": [f"x_{j}" for j in range(n)], "task_bits": k}
    return finalize_bundle(cfg=cfg, name=name, family="D04", task="classification", layout="vec",
                           input_spec={"x": {"shape": [n], "dtype": "float"}}, out_dim=2, pool=parts[0],
                           val=parts[1], test=parts[2], extra=extra, meta=meta)


# ----------------------------------------------------------------------------
# D05 shortcut / rare subpopulation / shift
# ----------------------------------------------------------------------------

SHORTCUT_DEFAULTS = {"d_causal": 8, "d_noise": 8, "rho_train": 0.9, "shortcut_strength": 1.0,
                     "shortcut_noise": 0.5, "rare_prevalence": 0.05, "n_rare_test": 5000, "pool_size": 32768,
                     # v30: rule linear (y = 1[w_g . c > 0]) | product (y = 1[(u_g . c)(v_g . c) > 0], a
                     # nonlinear function of the causal variables); input_rotation k > 0: every partition's
                     # input is multiplied by one fixed random orthogonal matrix (teacher seed, key k), which
                     # keeps all information but mixes the shortcut, causal and noise coordinates
                     "rule": "linear", "input_rotation": 0}


def build_shortcut(cfg: dict, root=None):
    """x = [c (d_causal), s (1), noise (d_noise)].
    group ~ Bernoulli(rare_prevalence) from the generator (0 majority, 1 rare);
    y = 1[w_g . c > 0] with a different rule vector for the rare group.
    shortcut s = strength*(2a-1) + shortcut_noise*N(0,1), where
      train pool / val : a = y with prob rho_train else 1-y   (training distribution)
      test             : a ~ Bernoulli(1/2), independent of y
      shift            : a = y with prob 1-rho_train          (reversed correlation)
      rare             : group-1 only, test-distribution shortcut."""
    name = "shortcut"
    p = check_params(name, cfg.get("params", {}), SHORTCUT_DEFAULTS)
    dc, dn = int(p["d_causal"]), int(p["d_noise"])
    rho, mu, sn, prev = float(p["rho_train"]), float(p["shortcut_strength"]), float(p["shortcut_noise"]), \
        float(p["rare_prevalence"])
    gt = torch_gen(int(cfg["teacher_seed"]), "teacher", name, "rules")
    w_major = torch.randn(dc, generator=gt)
    w_rare = torch.randn(dc, generator=gt)
    ds = int(cfg["data_seed"])
    if p["rule"] not in ("linear", "product"):
        raise ValueError("shortcut: rule must be linear or product")
    if p["rule"] == "product":
        # v30: a second rule vector per group from its own key (the linear rule's draws are unchanged)
        gp = torch_gen(int(cfg["teacher_seed"]), "teacher", name, "rules_product")
        v_major, v_rare = torch.randn(dc, generator=gp), torch.randn(dc, generator=gp)

    def label(c, grp):
        if p["rule"] == "linear":
            return torch.where(grp == 1, (c @ w_rare > 0), (c @ w_major > 0)).long()
        return torch.where(grp == 1, ((c @ w_rare) * (c @ v_rare) > 0),
                           ((c @ w_major) * (c @ v_major) > 0)).long()

    def gen(n, key, agree_prob, force_group=None):
        g = torch_gen(ds, "data", name, key)
        c = torch.randn(n, dc, generator=g)
        if force_group is None:
            grp = (torch.rand(n, generator=g) < prev).long()
        else:
            grp = torch.full((n,), force_group, dtype=torch.long)
        y = label(c, grp)
        if agree_prob is None:
            a = (torch.rand(n, generator=g) < 0.5).long()
        else:
            agree = torch.rand(n, generator=g) < agree_prob
            a = torch.where(agree, y, 1 - y)
        s = mu * (2 * a - 1).float() + sn * torch.randn(n, generator=g)
        noise = torch.randn(n, dn, generator=g)
        x = torch.cat([c, s.unsqueeze(1), noise], 1)
        return _part(x, y, groups=grp)

    pool = gen(int(p["pool_size"]), "pool", rho)
    val = gen(int(cfg["n_val"]), "val", rho)
    test = gen(int(cfg["n_test"]), "test", None)
    shift = gen(int(cfg["n_test"]), "shift", 1.0 - rho)
    rare = gen(int(p["n_rare_test"]), "rare", None, force_group=1)
    shift.meta["note"] = "shortcut correlation reversed"
    rare.meta["note"] = "rare group only; shortcut independent of label"

    def counterfactuals(n):
        """Paired interventions on ONE input feature each (mechanism A).  cf_base: shortcut agrees
        with the label (as in training).  cf_causal: the causal features are resampled until the
        label flips, the shortcut kept (a causal-feature model follows the new label, a shortcut
        model keeps the old one).  cf_shortcut: the shortcut sign flipped, the causal features and
        the label kept.  Row i of the three partitions is the same example."""
        g = torch_gen(ds, "data", name, "counterfactual")
        c = torch.randn(n, dc, generator=g)
        grp = (torch.rand(n, generator=g) < prev).long()
        rule = lambda cc: label(cc, grp)
        y = rule(c)
        eps = sn * torch.randn(n, generator=g)
        noise = torch.randn(n, dn, generator=g)
        s_same = mu * (2 * y - 1).float() + eps
        c2 = c.clone()
        todo = torch.ones(n, dtype=torch.bool)
        for _ in range(200):                                 # rejection sampling of a label-flipping c
            cand = torch.randn(n, dc, generator=g)
            ok = todo & (rule(cand) != y)
            c2[ok] = cand[ok]
            todo &= ~ok
            if not todo.any():
                break
        if todo.any():
            raise ValueError("counterfactual sampling did not converge")
        y2 = rule(c2)
        base = _part(torch.cat([c, s_same[:, None], noise], 1), y, groups=grp)
        cfc = _part(torch.cat([c2, s_same[:, None], noise], 1), y2, groups=grp)
        cfs = _part(torch.cat([c, (-mu * (2 * y - 1).float() + eps)[:, None], noise], 1), y, groups=grp)
        base.meta["note"] = "counterfactual base: shortcut agrees with the label"
        cfc.meta["note"] = "causal features changed so the label flips; shortcut unchanged (paired with cf_base)"
        cfs.meta["note"] = "shortcut flipped; causal features and label unchanged (paired with cf_base)"
        return base, cfc, cfs
    cf_base, cf_causal, cf_shortcut = counterfactuals(int(cfg["n_test"]))
    # v13 (audit C2): validation-ONLY environments, generated from their own keys with predeclared
    # shortcut correlations / group weights, for robustness-based selection.  The ordinary 'val' partition
    # stays in-distribution; test / shift / rare are never used for selection.
    nv = int(cfg["n_val"])
    val_indep = gen(nv, "val_env_indep", None)                    # shortcut independent of the label
    val_reversed = gen(nv, "val_env_reversed", 1.0 - rho)         # correlation reversed
    val_rare = gen(nv, "val_env_rare", None, force_group=1)       # rare group only, independent shortcut
    for v_, note in ((val_indep, "validation environment: shortcut independent of label (selection only)"),
                     (val_reversed, "validation environment: shortcut correlation reversed (selection only)"),
                     (val_rare, "validation environment: rare group only (selection only)")):
        v_.meta["note"] = note
    Qrot = None
    if int(p["input_rotation"]):
        # v30: one fixed orthogonal map for every partition (QR of a Gaussian matrix, signs fixed)
        gq = torch_gen(int(cfg["teacher_seed"]), "teacher", name, f"rotation{int(p['input_rotation'])}")
        A = torch.randn(dc + 1 + dn, dc + 1 + dn, generator=gq, dtype=torch.float64)
        Qm, Rm = torch.linalg.qr(A)
        Qrot = (Qm * torch.sign(torch.diagonal(Rm))).to(pool.X["x"].dtype)
        for part_ in (pool, val, test, shift, rare, cf_base, cf_causal, cf_shortcut, val_indep, val_reversed, val_rare):
            part_.X = {"x": part_.X["x"] @ Qrot}
    counts = {k: {"n": len(v), "n_rare": int((v.groups == 1).sum())}
              for k, v in {"pool": pool, "val": val, "test": test, "shift": shift, "rare": rare,
                           "cf_base": cf_base}.items()}
    meta = {"generator": "causal + shortcut + rare subgroup (see docstring)", "params": p,
            "feature_layout": {"causal": [0, dc], "shortcut": dc, "noise": [dc + 1, dc + 1 + dn],
                               **({"input_rotation": Qrot.double().tolist(),
                                   "note": "indices refer to the generator's coordinates; the network sees x Q "
                                           "(row j of Q is generator coordinate j's direction)"}
                                  if Qrot is not None else {})},
            "rule": p["rule"],
            "group_counts": counts, "groups_source": "generator (never inferred from labels)"}
    b = finalize_bundle(cfg=cfg, name=name, family="D05", task="classification", layout="vec",
                        input_spec=_vec_spec(dc + 1 + dn), out_dim=2, pool=pool, val=val, test=test,
                        extra={"shift": shift, "rare": rare, "cf_base": cf_base, "cf_causal": cf_causal,
                               "cf_shortcut": cf_shortcut, "val_indep": val_indep, "val_reversed": val_reversed,
                               "val_rare": val_rare}, meta=meta)
    b.meta["group_counts"]["train"] = {"n": len(b.train), "n_rare": int((b.train.groups == 1).sum())}
    return b
