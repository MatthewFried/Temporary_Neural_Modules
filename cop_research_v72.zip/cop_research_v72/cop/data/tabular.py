"""D06 tabular data: sklearn digits (continuity control), UCI Covertype (larger
benchmark) and California housing (second tabular domain, regression).

Splits are FIXED (params.split_seed, default 0) and independent of data_seed;
data_seed controls only the nested training-subset order and train-only noise.
Feature standardisation (and the regression target scale) is fitted on the
selected training subset only.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import torch

from .bundle import Partition
from .common import check_params, finalize_bundle
from ..utils import tensor_hash
from .splits import random_split, standardise_apply, standardise_fit, stratified_split

DIGITS_DEFAULTS = {"n_test": 360, "n_val": 180, "split_seed": 0}
COVERTYPE_DEFAULTS = {"n_test": 100000, "n_val": 20000, "split_seed": 0}
CALIFORNIA_DEFAULTS = {"n_test": 4128, "n_val": 2064, "split_seed": 0}


def tabular_from_arrays(cfg: dict, name: str, X: np.ndarray, y: np.ndarray, task: str, n_val: int,
                        n_test: int, split_seed: int, cont_cols, meta: dict):
    """Shared path for every tabular dataset (also used by tests with fake arrays)."""
    X = np.asarray(X, dtype=np.float32)
    if task == "classification":
        y = np.asarray(y).astype(np.int64)
        classes = np.unique(y)
        remap = {c: i for i, c in enumerate(classes.tolist())}
        y = np.vectorize(remap.get)(y).astype(np.int64) if not np.array_equal(classes, np.arange(len(classes))) else y
        parts = stratified_split(y, {"val": n_val, "test": n_test, "pool": None}, split_seed, name)
        out_dim = len(classes)
        yt = torch.from_numpy(y)
    else:
        y = np.asarray(y, dtype=np.float32).reshape(len(y), -1)
        parts = random_split(len(y), {"val": n_val, "test": n_test, "pool": None}, split_seed, name)
        out_dim = y.shape[1]
        yt = torch.from_numpy(y)
    Xt = torch.from_numpy(X)

    def mk(idx, tag):
        i = torch.from_numpy(idx)
        return Partition({"x": Xt[i].clone()}, yt[i].clone(), None, None, {}, {"source_indices_hash_of": tag})

    pool, val, test = mk(parts["pool"], "pool"), mk(parts["val"], "val"), mk(parts["test"], "test")
    # regression target noise is specified in units of the (clean) pool target std,
    # i.e. standardised units; the pool excludes val/test.
    noise_scale = float(pool.y.std(0, unbiased=False).mean()) if task == "regression" else 1.0

    def preprocess_fn(train: Partition):
        stats = standardise_fit(train.X["x"], cont_cols)
        info = {"type": "standardise", "cols": stats["cols"], "mean": stats["mean"].tolist(),
                "std": stats["std"].tolist()}
        tstats = None
        if task == "regression":
            ty = train.y_clean if train.y_clean is not None else train.y
            tstats = {"mean": ty.mean(0), "std": ty.std(0, unbiased=False).clamp_min(1e-8)}
            info["target_mean"] = tstats["mean"].tolist()
            info["target_std"] = tstats["std"].tolist()

        def apply(p: Partition) -> Partition:
            q = Partition(dict(p.X), p.y, p.y_clean, p.groups, dict(p.aux), dict(p.meta))
            q.X["x"] = standardise_apply(p.X["x"], stats)
            if tstats is not None:
                q.y = (p.y - tstats["mean"]) / tstats["std"]
                if p.y_clean is not None:
                    q.y_clean = (p.y_clean - tstats["mean"]) / tstats["std"]
            return q
        return info, apply

    meta = dict(meta)
    meta["split_sizes"] = {k: int(len(v)) for k, v in parts.items()}
    meta["split_seed"] = split_seed
    meta["split_index_hashes"] = {k: tensor_hash(torch.from_numpy(v)) for k, v in parts.items()}
    b = finalize_bundle(cfg=cfg, name=name, family="D06", task=task, layout="vec",
                        input_spec={"x": {"shape": [int(X.shape[1])], "dtype": "float"}}, out_dim=out_dim,
                        pool=pool, val=val, test=test, preprocess_fn=preprocess_fn, target_scale=1.0, meta=meta,
                        noise_scale=noise_scale)
    return b


def build_digits(cfg: dict, root=None):
    from sklearn.datasets import load_digits
    p = check_params("digits", cfg.get("params", {}), DIGITS_DEFAULTS)
    d = load_digits()
    X = d.data / 16.0
    return tabular_from_arrays(cfg, "digits", X, d.target, "classification", int(p["n_val"]), int(p["n_test"]),
                               int(p["split_seed"]), None,
                               {"source": "sklearn.datasets.load_digits (UCI optdigits subset, 1797 x 64)",
                                "params": p})


def build_covertype(cfg: dict, root=None):
    from sklearn.datasets import fetch_covtype
    p = check_params("covertype", cfg.get("params", {}), COVERTYPE_DEFAULTS)
    d = fetch_covtype(data_home=str(Path(root) / "sklearn") if root else None, download_if_missing=True)
    return tabular_from_arrays(cfg, "covertype", d.data, d.target, "classification", int(p["n_val"]),
                               int(p["n_test"]), int(p["split_seed"]), list(range(10)),
                               {"source": "UCI Covertype via sklearn.datasets.fetch_covtype (581012 x 54, 7 classes)",
                                "license": "UCI ML repository, CC BY 4.0",
                                "params": p,
                                "caveat": "random stratified split; the source has no independent-location labels, "
                                          "so test is an IID held-out split, NOT a spatial/OOD test",
                                "standardised_columns": "10 continuous columns; 44 binary columns left as 0/1"})


def build_california(cfg: dict, root=None):
    from sklearn.datasets import fetch_california_housing
    p = check_params("california", cfg.get("params", {}), CALIFORNIA_DEFAULTS)
    d = fetch_california_housing(data_home=str(Path(root) / "sklearn") if root else None, download_if_missing=True)
    return tabular_from_arrays(cfg, "california", d.data, d.target, "regression", int(p["n_val"]),
                               int(p["n_test"]), int(p["split_seed"]), None,
                               {"source": "California housing via sklearn.datasets.fetch_california_housing "
                                          "(20640 x 8, regression)", "params": p,
                                "caveat": "random split (block groups are spatially correlated; test is IID, not OOD)"})
