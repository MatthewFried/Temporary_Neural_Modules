"""Constructive compact witnesses (v5, P0).

A known-teacher dataset supplies a COMPACT WITNESS for an architecture only when the
teacher's function can be loaded exactly into that architecture.  This module builds the
witness constructively and verifies it numerically:

  * teacher: data.synthetic make_teacher MLP (weights W_i, biases b_i, activation a), outputs
    standardised for regression, y = (raw - mu) / sd;
  * student: model family 'mlp' with the same activation, no normalisation layers, no late
    query, input dimension d_in and output dimension equal to the teacher's;
  * embedding: student hidden layer i (i < teacher depth) holds the teacher's layer i in its
    first w_t units and zeros elsewhere (student width >= teacher width); a ReLU student
    deeper than the teacher carries the post-activation vector through the extra layers by an
    identity block (exact because post-ReLU values are non-negative); the head folds the output
    standardisation: W_head = W_out / sd, b_head = (b_out - mu) / sd.
  Exactness argument: zero rows give zero pre-activations; a(0) = 0 for relu / tanh / gelu, and
  zero columns ignore them downstream, so every padded unit is inert; the identity block is
  exact for relu only.  The numerical check below (train / val / test / a fresh sample) backs
  the argument; it does not replace it.

Anything else (tanh teacher with a ReLU student, a narrower student, BN, ...) is NOT
realisable by this construction and is reported as a mismatch condition with its reason.
A witness separates approximation error from the rest; it does not make finite-sample
held-out error pure optimisation error (estimation and label noise remain).
"""
from __future__ import annotations

from typing import Optional

import torch

from ..graph.graph import GraphNet

ZERO_AT_ZERO = ("relu", "tanh", "gelu")


def witness_condition(bundle, model_cfg: dict) -> tuple[bool, str]:
    t = bundle.meta.get("teacher")
    if bundle.name not in ("teacher", "easy_teacher") or not isinstance(t, dict):
        return False, "dataset has no known MLP teacher"
    m = model_cfg
    if m.get("family") != "mlp":
        return False, "student is not an MLP"
    if m.get("bn"):
        return False, "student has normalisation layers"
    if m.get("query_at_layer") is not None:
        return False, "student has a late query stream"
    if m.get("act") != t["act"]:
        return False, f"activation mismatch (teacher {t['act']}, student {m.get('act')}): approximation-mismatch condition"
    if t["act"] not in ZERO_AT_ZERO:
        return False, f"activation {t['act']} is not zero at zero"
    dims = t["dims"]
    widths = m.get("widths") or [m["width"]] * m["depth"]
    t_hidden = dims[1:-1]
    if len(widths) < len(t_hidden):
        return False, f"student depth {len(widths)} < teacher depth {len(t_hidden)}"
    if len(widths) > len(t_hidden) and t["act"] != "relu":
        return False, "extra student layers need an identity block, exact for relu only"
    if len(widths) > len(t_hidden) and not t_hidden:
        return False, "an identity block on raw (signed) inputs is not exact under relu"
    for i, wt in enumerate(t_hidden):
        if widths[i] < wt:
            return False, f"student width {widths[i]} < teacher width {wt} at layer {i}"
    if t_hidden and len(widths) > len(t_hidden) and any(w < t_hidden[-1] for w in widths[len(t_hidden):]):
        return False, "extra student layers narrower than the teacher's last hidden layer"
    return True, "exact embedding (zero padding" + (", relu identity block" if len(widths) > len(t_hidden) else "") + ")"


@torch.no_grad()
def build_witness(bundle, model_cfg: dict, template: GraphNet) -> tuple[Optional[GraphNet], dict]:
    """template: a freshly built student (same config); its tensors are overwritten."""
    ok, why = witness_condition(bundle, model_cfg)
    info = {"realizable": ok, "reason": why}
    if not ok:
        return None, info
    t = bundle.meta["teacher"]
    g = template.clone(share_params=False)
    lins = [n for n in g.topo_order() if g.nodes[n].op == "linear" and g.nodes[n].role.endswith(".lin")]
    head = next(n for n in g.topo_order() if g.nodes[n].role == "head")
    Ws, bs = t["weights"], t["biases"]
    nh = len(Ws) - 1
    prev_t, prev_s = int(Ws[0].shape[1]), None
    for i, nid in enumerate(lins):
        mod = g.mods[g.nodes[nid].pkey]
        mod.weight.zero_()
        mod.bias.zero_()
        if i < nh:
            W, b = Ws[i].to(mod.weight), bs[i].to(mod.bias)
            mod.weight[:W.shape[0], :W.shape[1]] = W
            mod.bias[:b.shape[0]] = b
            prev_t = int(W.shape[0])
        else:
            mod.weight[:prev_t, :prev_t] = torch.eye(prev_t, dtype=mod.weight.dtype)
    hm = g.mods[g.nodes[head].pkey]
    hm.weight.zero_()
    hm.bias.zero_()
    W, b = Ws[-1].to(hm.weight), bs[-1].to(hm.bias)
    if bundle.task == "regression":
        mu, sd = t["target_mean"].to(W), t["target_std"].to(W)
        W, b = W / sd[:, None], (b - mu) / sd
    hm.weight[:, :W.shape[1]] = W
    hm.bias.copy_(b)
    return g, info


@torch.no_grad()
def verify_witness(g: GraphNet, bundle, batch: int = 4096, fresh_n: int = 2048) -> dict:
    """Max absolute difference between witness outputs and the noiseless teacher on train (clean
    targets), val, test and, where the dataset has one, a fresh sample (fixed generator)."""
    from ..data.synthetic import teacher_forward
    from ..train.trainer import predict
    t = bundle.meta["teacher"]
    out = {}
    parts = dict(bundle.partitions())
    if bundle.fresh_sampler is not None:
        gen = torch.Generator().manual_seed(0)
        parts["fresh"] = bundle.fresh_sampler(fresh_n, gen).to(next(g.parameters()).device)
    for name, p in parts.items():
        y = predict(g, p, batch).float()
        ref = teacher_forward(t, p.X["x"]).float()
        if bundle.task == "classification":
            out[name] = {"max_abs_logit_err": float((y - ref).abs().max()),
                         "argmax_agreement": float((y.argmax(1) == ref.argmax(1)).float().mean())}
        else:
            out[name] = {"max_abs_err": float((y - ref).abs().max())}
    worst = max(v.get("max_abs_err", v.get("max_abs_logit_err", 0.0)) for v in out.values())
    return {"partitions": out, "max_abs_err": worst, "verified": bool(worst <= 1e-4)}
