"""inspect_environment: record the machine and verify real CUDA training.

The nvidia-smi driver line does not prove the installed PyTorch build can use
CUDA, so `cuda_smoke` runs an actual forward/backward/update on the device and
checks that parameters changed and agree with a CPU reference.
"""
from __future__ import annotations

import json
import os
import platform
import shutil
import subprocess
import sys
import time
from pathlib import Path

from .utils import stable_hash, code_hash


def _run(cmd: list[str]) -> str:
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=30).stdout.strip()
    except Exception as ex:
        return f"unavailable: {ex}"


def _meminfo() -> dict:
    out = {}
    try:
        for line in Path("/proc/meminfo").read_text().splitlines():
            k, v = line.split(":", 1)
            if k in ("MemTotal", "MemAvailable", "SwapTotal"):
                out[k] = v.strip()
    except Exception:
        pass
    return out


def _cpu() -> dict:
    model = ""
    try:
        for line in Path("/proc/cpuinfo").read_text().splitlines():
            if line.startswith("model name"):
                model = line.split(":", 1)[1].strip()
                break
    except Exception:
        pass
    return {"model": model or platform.processor(), "logical_cpus": os.cpu_count(),
            "affinity": len(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else None}


def cuda_smoke(device: str = "cuda") -> dict:
    import torch
    res = {"device": device, "ok": False}
    if device.startswith("cuda") and not torch.cuda.is_available():
        res["error"] = "torch.cuda.is_available() is False"
        return res
    try:
        torch.manual_seed(0)
        lin_cpu = torch.nn.Sequential(torch.nn.Linear(64, 128), torch.nn.ReLU(), torch.nn.Linear(128, 10))
        lin = torch.nn.Sequential(torch.nn.Linear(64, 128), torch.nn.ReLU(), torch.nn.Linear(128, 10))
        lin.load_state_dict(lin_cpu.state_dict())
        lin = lin.to(device)
        x = torch.randn(256, 64)
        y = torch.randint(0, 10, (256,))
        before = [p.detach().clone() for p in lin.parameters()]
        for m, xx, yy in ((lin, x.to(device), y.to(device)), (lin_cpu, x, y)):
            opt = torch.optim.SGD(m.parameters(), lr=0.1)
            loss = torch.nn.functional.cross_entropy(m(xx), yy)
            opt.zero_grad()
            loss.backward()
            opt.step()
        changed = any((a - b.detach()).abs().max().item() > 0 for a, b in zip(before, lin.parameters()))
        diff = max((a.detach().cpu() - b.detach()).abs().max().item() for a, b in zip(lin.parameters(), lin_cpu.parameters()))
        # checkpoint round trip on this device: save, reload into a fresh module, same outputs bitwise
        import io
        buf = io.BytesIO()
        torch.save(lin.state_dict(), buf)
        buf.seek(0)
        lin2 = torch.nn.Sequential(torch.nn.Linear(64, 128), torch.nn.ReLU(), torch.nn.Linear(128, 10)).to(device)
        lin2.load_state_dict(torch.load(buf, map_location=device))
        with torch.no_grad():
            reload_equal = bool(torch.equal(lin(x.to(device)), lin2(x.to(device))))
        res.update({"ok": bool(changed and diff < 1e-4 and reload_equal), "params_changed": bool(changed),
                    "max_diff_vs_cpu": diff, "checkpoint_reload_bitwise": reload_equal})
        if device.startswith("cuda"):
            t = torch.randn(4096, 4096, device=device)
            torch.cuda.synchronize()
            t0 = time.time()
            for _ in range(10):
                t @ t
            torch.cuda.synchronize()
            res["matmul_4096_tflops_fp32"] = round(10 * 2 * 4096 ** 3 / (time.time() - t0) / 1e12, 2)
            res["tf32_matmul_allowed"] = bool(torch.backends.cuda.matmul.allow_tf32)
    except Exception as ex:
        res["error"] = repr(ex)
    return res


def inspect_environment(check_cuda: bool = True) -> dict:
    import torch
    info = {
        "python": sys.version.split()[0], "executable": sys.executable, "platform": platform.platform(),
        "wsl": "microsoft" in platform.release().lower() or Path("/proc/sys/fs/binfmt_misc/WSLInterop").exists(),
        "hostname": platform.node(), "user": os.environ.get("USER", ""), "cwd": os.getcwd(),
        "cpu": _cpu(), "memory": _meminfo(),
        "torch": torch.__version__, "torch_cuda_build": torch.version.cuda,
        "cudnn": torch.backends.cudnn.version() if torch.backends.cudnn.is_available() else None,
        "cuda_available": torch.cuda.is_available(),
        "gpus": [{"name": torch.cuda.get_device_name(i),
                  "total_mem_mib": torch.cuda.get_device_properties(i).total_memory // 2 ** 20,
                  "capability": list(torch.cuda.get_device_capability(i))}
                 for i in range(torch.cuda.device_count())] if torch.cuda.is_available() else [],
        "nvidia_smi": _run(["nvidia-smi", "--query-gpu=name,driver_version,memory.total,memory.used",
                            "--format=csv,noheader"]) if shutil.which("nvidia-smi") else "nvidia-smi not found",
        "code_hash": code_hash(),
        "git_commit": _run(["git", "-C", str(Path(__file__).resolve().parents[1]), "rev-parse", "HEAD"]) or
                      "not a git repository (code_hash identifies the source)",
        "threads": {k: os.environ.get(k) for k in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS")},
        "torch_num_threads": torch.get_num_threads(),
    }
    try:
        import torchvision
        info["torchvision"] = torchvision.__version__
    except Exception:
        info["torchvision"] = None
    for mod in ("numpy", "scipy", "sklearn", "sympy", "networkx", "matplotlib", "yaml"):
        try:
            info[mod] = __import__(mod).__version__
        except Exception:
            info[mod] = None
    info["pip_freeze"] = _run([sys.executable, "-m", "pip", "freeze"]).splitlines()
    if check_cuda and torch.cuda.is_available():
        info["cuda_smoke"] = cuda_smoke("cuda")
    info["cpu_smoke"] = cuda_smoke("cpu")
    return info


def environment_hash(info: dict | None = None) -> str:
    if info is None:
        import torch
        info = {"python": sys.version.split()[0], "torch": torch.__version__, "torch_cuda_build": torch.version.cuda,
                "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None}
    keys = ("python", "torch", "torch_cuda_build")
    sub = {k: info.get(k) for k in keys}
    sub["gpu"] = info.get("gpu") or ((info.get("gpus") or [{}])[0].get("name") if info.get("gpus") else None)
    return stable_hash(sub)
