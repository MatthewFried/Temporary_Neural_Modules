"""Shared experiment helpers: data/model setup, seeds, calibration inputs,
insertion equivalence checks, evaluation + logging, deletion probes."""
from __future__ import annotations

import itertools
import math
from typing import Optional

import torch

from ..config import seed_of
from ..data.registry import load_bundle
from ..graph import edits as E
from ..graph.accounting import report as acct_report
from ..graph.builders import build_model, _init_all
from ..graph.graph import GraphNet, InvalidDeletion
from ..train import metrics as M
from ..train.trainer import Trainer, evaluate, predict
from ..utils import torch_gen


def setup_data(ctx):
    b = load_bundle(ctx.cfg["data"], ctx.data_root, device="cpu")
    ctx.split_hashes = b.hashes()
    ctx.log({"event": "data", "name": b.name, "family": b.family, "task": b.task, "n_train": len(b.train),
             "pool": b.pool_size, "split_hashes": ctx.split_hashes,
             "extra": sorted(b.extra), "preprocess": {k: v for k, v in b.preprocess.items() if k != "stats"}})
    return b.to(ctx.device)


def seeds(cfg) -> dict:
    return {"minibatch": seed_of(cfg, "minibatch"), "augmentation": seed_of(cfg, "augmentation"),
            "init": seed_of(cfg, "init")}


def new_model(cfg, bundle, device, key: str = "base") -> GraphNet:
    g = build_model(cfg["model"], bundle, torch_gen(seed_of(cfg, "init"), "init", key))
    if cfg.get("train", {}).get("precision") == "fp64":
        g = g.double()
    return g.to(device)


def reinit_all(g: GraphNet, gen: torch.Generator) -> None:
    act = g.meta.get("arch", {}).get("act", "relu")
    fam = g.family
    scheme = "default" if fam in ("transformer", "gru") else ("xavier" if act in ("tanh", "identity") else "kaiming")
    _init_all(g, gen, scheme)


def make_trainer(ctx, model, bundle, stream_key: str = "") -> Trainer:
    return Trainer(model, bundle, ctx.cfg["train"], seeds(ctx.cfg), ctx.device, ctx.log, stream_key)


def calib_sets(bundle, n: int, stress_scale: float = 4.0, seed: int = 0) -> dict[str, dict]:
    """Inputs for equivalence checks: training calibration inputs, fresh IID
    inputs (validation inputs, never used for training) and stress inputs."""
    tr = bundle.train
    va = bundle.val
    n_tr, n_va = min(n, len(tr)), min(n, len(va))
    cal = {k: v[:n_tr] for k, v in tr.X.items()}
    fresh = {k: v[:n_va] for k, v in va.X.items()}
    g = torch.Generator().manual_seed(seed)
    stress = {}
    for k, v in cal.items():
        if v.is_floating_point():
            noise = torch.randn(v.shape, generator=g).to(v.device, v.dtype)
            stress[k] = v * stress_scale + noise * stress_scale
        else:
            hi = int(v.max().item()) + 1
            stress[k] = torch.randint(0, max(hi, 2), v.shape, generator=g).to(v.device)
    return {"calibration": cal, "fresh": fresh, "stress": stress}


@torch.no_grad()
def outputs_on(model: GraphNet, sets: dict, dtype=None) -> dict:
    from ..train.trainer import model_dtype
    dtype = dtype or model_dtype(model)
    was = model.training
    model.eval()
    out = {k: model({kk: (vv.to(dtype) if vv.is_floating_point() else vv) for kk, vv in X.items()})
           for k, X in sets.items()}
    model.train(was)
    return out


def equivalence_report(before: dict, after: dict) -> dict:
    return {k: M.equivalence(before[k], after[k]) for k in before}


def identity_tolerance(cfg, dtype) -> float:
    return cfg["criteria"]["identity_rel_tol_fp64"] if dtype == torch.float64 else cfg["criteria"]["identity_rel_tol_fp32"]


# ----------------------------------------------------------------------------- identity checks (v13)
# Declared before any evaluation; nothing here is derived from the case being judged.
# Edit round-off limit: the largest change in execution-precision error an edit may introduce, relative to the
# reference scale, per execution dtype.  It is fixed and independent of the high-precision agreement tolerance.
IDENTITY_EDIT_ROUNDOFF_MAX_REL = {torch.float32: 1e-4, torch.float64: 1e-10}
IDENTITY_LOW_SCALE = 1e-8            # mean |output| below this makes relative comparisons inconclusive
# a real high-precision change on any set dominates the overall verdict (it is never hidden as inconclusive)
VERDICT_ORDER = ("nonfinite", "changed", "low_scale", "execution_changed")


@torch.no_grad()
def _outs(model: GraphNet, X: dict, dtype, train_mode: bool) -> torch.Tensor:
    m = model.clone(share_params=False).to(dtype=dtype)     # clone: train-mode BN must not update the model
    m.train(train_mode)
    return m({k: (v.to(dtype) if v.is_floating_point() else v) for k, v in X.items()})


def _maxabs(t: torch.Tensor) -> float:
    return float(t.abs().max()) if t.numel() else 0.0


def edit_roundoff_limit(exec_dtype) -> float:
    if exec_dtype not in IDENTITY_EDIT_ROUNDOFF_MAX_REL:
        raise ValueError(f"no declared edit round-off limit for execution dtype {exec_dtype}")
    return IDENTITY_EDIT_ROUNDOFF_MAX_REL[exec_dtype]


def identity_check(pre: GraphNet, post: GraphNet, sets: dict, exec_dtype, cfg, train_mode: bool = False) -> dict:
    """Empirical check, on the given input sets, that an edit declared function-preserving preserves the
    function.  It is a measurement on these inputs, not a global identity proof.  Per set, with
    p64 / q64 = pre / post evaluated in float64 from their STORED parameters, p_exec / q_exec = the same at the
    execution dtype, every difference formed in float64, and s = max(mean |p64|, mean |q64|) (the common
    reference scale):

      a       = maxabs(q64 - p64) / s          high-precision agreement; tolerance by storage dtype
                                               (identity_rel_tol_fp64 / identity_rel_tol_fp32, construction-aware:
                                               factors rounded to float32 at construction cannot meet 1e-10)
      d_edit  = maxabs((q_exec - q64) - (p_exec - p64)) / s
                                               the change the edit makes to the execution-precision error, per
                                               coordinate and example (sign and location count); must not exceed
                                               the fixed edit round-off limit for the execution dtype
      o       = maxabs(q_exec - p_exec) / s    observed agreement at the execution dtype; must not exceed the
                                               fixed bound tol_hp + edit limit
      u_pre, u_post = maxabs(p_exec - p64) / s, maxabs(q_exec - q64) / s
                                               diagnostics only (preexisting_instability when u_pre exceeds the
                                               edit limit); they never relax or decide a verdict

    verdict per set: nonfinite | low_scale (s below IDENTITY_LOW_SCALE) | changed (a above tolerance) |
    execution_changed (d_edit or o above its fixed bound) | exact.  The overall verdict is the first failing
    reason over the sets in VERDICT_ORDER (nonfinite, changed, low_scale, execution_changed)."""
    store_dt = next(post.parameters()).dtype
    tol_hp = cfg["criteria"]["identity_rel_tol_fp64"] if store_dt == torch.float64 else \
        cfg["criteria"]["identity_rel_tol_fp32"]
    tol_edit = edit_roundoff_limit(exec_dtype)
    tol_obs = tol_hp + tol_edit
    out = {"tolerance_high_precision": tol_hp, "edit_roundoff_max_rel": tol_edit, "observed_max_rel": tol_obs,
           "storage_dtype": str(store_dt).replace("torch.", ""), "exec_dtype": str(exec_dtype).replace("torch.", ""),
           "scope": "empirical agreement on these input sets, not a global identity proof", "sets": {}}
    worst = None
    for name, X in sets.items():
        p64, q64 = _outs(pre, X, torch.float64, train_mode).double(), _outs(post, X, torch.float64, train_mode).double()
        pe, qe = _outs(pre, X, exec_dtype, train_mode).double(), _outs(post, X, exec_dtype, train_mode).double()
        finite = all(bool(torch.isfinite(t).all()) for t in (p64, q64, pe, qe))
        # common reference scale, symmetric in pre and post (a function moved off zero is a change, not low scale)
        scale = max(float(p64.abs().mean()), float(q64.abs().mean())) if finite else float("nan")
        r = {"finite": finite, "scale": scale}
        if not finite:
            r["verdict"] = "nonfinite"
        elif scale < IDENTITY_LOW_SCALE:
            r["verdict"] = "low_scale"
        else:
            e_pre, e_post = pe - p64, qe - q64
            r.update({"a_high_precision": _maxabs(q64 - p64) / scale,
                      "d_edit": _maxabs(e_post - e_pre) / scale,
                      "o_observed": _maxabs(qe - pe) / scale,
                      "u_pre": _maxabs(e_pre) / scale, "u_post": _maxabs(e_post) / scale,
                      "max_abs_high_precision": _maxabs(q64 - p64)})
            r["preexisting_instability"] = r["u_pre"] > tol_edit
            r["observed_within_fixed_bound"] = r["o_observed"] <= tol_obs
            if r["a_high_precision"] > tol_hp:
                r["verdict"] = "changed"
            elif r["d_edit"] > tol_edit or not r["observed_within_fixed_bound"]:
                r["verdict"] = "execution_changed"
            else:
                r["verdict"] = "exact"
        out["sets"][name] = r
        if r["verdict"] != "exact" and (worst is None or VERDICT_ORDER.index(r["verdict"]) < VERDICT_ORDER.index(worst)):
            worst = r["verdict"]
    out["verdict"] = worst or ("exact" if sets else "no_inputs")
    out["preexisting_instability_sets"] = sorted(k for k, r in out["sets"].items() if r.get("preexisting_instability"))
    return out


def eval_log(ctx, model, bundle, stage: str, refs: Optional[dict] = None, save_preds: bool = False,
             partitions: Optional[list[str]] = None, dtype=None) -> tuple[dict, dict]:
    """Evaluate task metrics on partitions; drift against reference prediction
    sets {ref_name: {partition: preds}}; log long-format rows."""
    ev = ctx.cfg.get("eval", {})
    parts = list(partitions or ev.get("partitions", ["val", "test"]))
    if ev.get("extra", True) and partitions is None:
        parts += [p for p in bundle.extra if p not in parts]
    res, preds = evaluate(model, bundle, parts, ctx.cfg.get("train", {}).get("eval_batch", 4096), dtype, True)
    gh = model.structural_hash()
    for p, m in res.items():
        ctx.metrics(stage, p, m, graph_hash=gh)
    drifts = {}
    for rname, rp in (refs or {}).items():
        for p, out in preds.items():
            if p in rp:
                d = M.drift(out, rp[p], bundle.task, bundle.partitions()[p].y, bundle.target_scale)
                drifts[f"{rname}:{p}"] = d
                ctx.metrics(stage, p, d, prefix=f"drift_vs_{rname}.", graph_hash=gh)
    for p, out in preds.items():
        im = teacher_imitation(out, bundle, p)
        if im:
            res[p].update(im)
            ctx.metrics(stage, p, im, graph_hash=gh)
    if save_preds:
        ctx.save_preds(stage, preds)
    return res, preds | {"__drift__": drifts}


@torch.no_grad()
def teacher_imitation(out: torch.Tensor, bundle, part: str) -> dict:
    """Teacher imitation error, kept separate from task risk: distance to the known
    compact teacher's clean output.  Regression: MSE to y_clean in target units
    (and normalised by target_scale^2); classification with a known teacher:
    KL(teacher || model) at T = 1 and disagreement of the arg-max."""
    p = bundle.partitions().get(part)
    if p is None:
        return {}
    if bundle.task == "regression" and (p.y_clean is not None or part != "train"):
        # target noise is applied to the TRAINING targets only: val / test / extra targets are the
        # clean generator output (y_clean is stored for the training partition only)
        yc = (p.y_clean if p.y_clean is not None else p.y).to(out.device).float().view_as(out)
        mse = float(((out.float() - yc) ** 2).mean())
        return {"teacher_imitation_mse": mse, "teacher_imitation_nmse": mse / (bundle.target_scale ** 2 + 1e-12)}
    if bundle.task == "classification" and isinstance(bundle.meta.get("teacher"), dict) and "x" in p.X:
        from ..data.synthetic import teacher_forward
        t = teacher_forward(bundle.meta["teacher"], p.X["x"].to(out.device)).float()
        lt, lo = torch.log_softmax(t, -1), torch.log_softmax(out.float(), -1)
        return {"teacher_imitation_kl": float((lt.exp() * (lt - lo)).sum(-1).mean()),
                "teacher_disagreement": float((t.argmax(-1) != out.argmax(-1)).float().mean())}
    return {}


def log_accounting(ctx, model, stage: str, T: int = 1) -> dict:
    rep = acct_report(model, T)
    ctx.metric(stage, "none", "params", rep["params"], rep["structural_hash"])
    ctx.metric(stage, "none", "macs_per_example", rep["macs"], rep["structural_hash"])
    ctx.metric(stage, "none", "n_implants", len(model.implants), rep["structural_hash"])
    ctx.metric(stage, "none", "n_atoms", len(model.atoms()), rep["structural_hash"])
    return rep


ENDPOINT_METRICS = ("loss", "mse", "acc")


def record_endpoint(ctx, bundle, ckpt_stage: str, diverged: bool = False, diverged_reason: Optional[str] = None,
                    extra: Optional[dict] = None, name: str = "endpoint") -> dict:
    """THE endpoint of a job (V3-01): the model saved as checkpoint `ckpt_stage` is reloaded and
    evaluated on every partition (stage 'endpoint'), so every reported endpoint metric is reproducible
    from that file.  endpoint.json carries the checkpoint identity, the update count, the numerical
    status (diverged flag of the training that produced it, finiteness of its tensors and of its
    endpoint metrics) and its architecture (sharing-aware hash, parameters, MACs, interface bits).
    No other stage may stand in for the endpoint."""
    from ..graph.accounting import architecture_hash
    ck = ctx.load_ckpt(ckpt_stage)
    nu = getattr(ctx, "numerics", None) or {}
    if not diverged and nu.get("diverged"):
        # a phase of this job diverged (e.g. a CoP chain's training): the endpoint inherits it
        diverged, diverged_reason = True, f"{nu.get('phase')}: {nu.get('reason')}"
    model = GraphNet.from_checkpoint(ck["model"], ctx.device)
    res, _ = eval_log(ctx, model, bundle, name, save_preds=True)   # kept for fresh-process reload checks
    finite_tensors = all(bool(torch.isfinite(t).all()) for t in list(model.parameters()) + list(model.buffers())
                         if t.is_floating_point())
    finite_metrics = all(math.isfinite(float(m[k])) for m in res.values() for k in ENDPOINT_METRICS if k in m)
    rep = acct_report(model, seq_T(bundle))
    gh = model.structural_hash()
    ep = {"stage": name, "checkpoint": ckpt_stage, "checkpoint_param_hash": ck["lineage"]["param_hash"],
          "updates": int(ctx.updates), "examples": int(ctx.examples), "diverged": bool(diverged),
          "diverged_reason": diverged_reason, "finite_tensors": finite_tensors, "finite_metrics": finite_metrics,
          "architecture_hash": architecture_hash(model), "params": int(rep["params"]), "macs": int(rep["macs"]),
          "peg_bits_per_example": int(rep.get("peg_bits_per_example", 0)), "n_implants": len(model.implants),
          **(extra or {})}
    reasons = []
    if diverged:
        reasons.append("diverged" + (f": {diverged_reason}" if diverged_reason else ""))
    if not finite_tensors:
        reasons.append("non-finite parameters or buffers")
    if not finite_metrics:
        reasons.append("non-finite endpoint metrics")
    ep["numerically_valid"] = not reasons
    ep["numerical_reasons"] = reasons
    ctx.save_json(f"{name}.json", ep)
    ctx.metric(name, "none", "endpoint_numerically_valid", int(ep["numerically_valid"]), gh)
    ctx.metric(name, "none", "endpoint_diverged", int(bool(diverged)), gh)
    return ep


# ----------------------------------------------------------------------------- validation selection (v13)
SELECTION_PARTITIONS_FORBIDDEN = ("test", "shift", "rare", "train")


def selection_points(n: int, k: int) -> list[int]:
    """k declared candidate points spread evenly over a phase of n updates (the last is n; ties merge)."""
    if k <= 0 or n <= 0:
        return []
    return sorted({max(1, int(round(n * i / k))) for i in range(1, k + 1)})


class Selector:
    """Validation-only endpoint selection inside a job's FINAL COMPACT phase (v13, audit C2).

    Candidates are evaluated at declared points (train.select_candidates, evenly spaced over the phase, the
    last one the final update), plus optionally the state at the start of the phase; the model given to the
    selector must already have the job's final compact architecture (an expanded state can never be a
    candidate).  Rule: lowest validation risk (mse for regression, cross-entropy for classification) on
    train.select_partition; ties go to the EARLIER candidate.  The best state is saved as checkpoint
    'best_val'; selection.json records every candidate, so a resumed job re-evaluates the same states and
    reaches the same choice.  The fixed-budget endpoint (endpoint.json) is never replaced.  Test, shift, rare
    and train partitions can never be selection partitions."""

    def __init__(self, ctx, bundle, phase: str, compact_fn=None):
        t = ctx.cfg.get("train", {})
        self.ctx, self.bundle, self.phase = ctx, bundle, phase
        self.k = int(t.get("select_candidates", 0) or 0)
        self.partition = t.get("select_partition", "val")
        if self.partition in SELECTION_PARTITIONS_FORBIDDEN or not str(self.partition).startswith("val"):
            raise ValueError(f"selection partition {self.partition!r} is not a validation partition")
        self.compact_fn = compact_fn or (lambda m: m)
        self.state = ctx.load_json("selection.json") if ctx.has_json("selection.json") else \
            {"phase": phase, "candidates": [], "best": None, "rule": "lowest validation risk; ties -> earlier",
             "partition": self.partition, "n_declared": self.k}

    @property
    def enabled(self) -> bool:
        return self.k > 0

    def points(self, n: int) -> list[int]:
        return selection_points(n, self.k)

    def _risk(self, res: dict) -> float:
        m = res[self.partition]
        return float(m["mse"] if self.bundle.task == "regression" else m["loss"])

    def consider(self, model, global_step: int, seg_step: int, label: str = "", trainer=None) -> dict:
        """trainer: saved with the candidate when the candidate IS the trained model (identity compact_fn), so
        a descendant can start from the full selected state (model, optimizer, RNG and data streams)."""
        from ..train.trainer import evaluate
        cand = self.compact_fn(model)
        tr_save = trainer if (trainer is not None and cand is model) else None
        res, _ = evaluate(cand, self.bundle, [self.partition], self.ctx.cfg["train"]["eval_batch"])
        r = self._risk(res)
        from ..train.trainer import forward_macs
        n_ev = len(self.bundle.partitions()[self.partition])
        rec = {"global_step": int(global_step), "seg_step": int(seg_step), "label": label, "risk": r,
               "eval_examples": int(n_ev), "eval_macs": int(forward_macs(cand, seq_T(self.bundle), {}) * n_ev)}
        cands = [c for c in self.state["candidates"] if c["global_step"] != rec["global_step"]]
        cands.append(rec)
        self.state["candidates"] = sorted(cands, key=lambda c: c["global_step"])
        b = self.state["best"]
        finite = math.isfinite(r)
        if finite and (b is None or r < b["risk"] or (r == b["risk"] and rec["global_step"] < b["global_step"])):
            self.state["best"] = rec
            self.ctx.save_ckpt("best_val", cand, tr_save, {"selection": rec, "full_state": tr_save is not None})
        elif b is not None and b["global_step"] == rec["global_step"] and not self.ctx.has_ckpt("best_val"):
            self.ctx.save_ckpt("best_val", cand, tr_save, {"selection": rec, "full_state": tr_save is not None})
        self.ctx.save_json("selection.json", self.state)
        self._charge()
        return {f"select_{self.partition}_risk": r}

    def _charge(self) -> None:
        """Absolute (idempotent) work record of every candidate evaluation so far."""
        cs = self.state["candidates"]
        self.ctx.set_work(f"search:selection_{self.phase}", {
            "forward_examples": sum(int(c.get("eval_examples", 0)) for c in cs),
            "macs": sum(int(c.get("eval_macs", 0)) for c in cs), "macs_complete": True,
            "recorded_from": "selection.json candidate evaluations (forward only)"})

    def ensure_final(self, model, global_step: int, seg_step: int, label: str = "final", trainer=None) -> None:
        """The final state of the phase is always a candidate (it is the fixed-budget endpoint's state)."""
        if self.enabled and not any(c["global_step"] == int(global_step) for c in self.state["candidates"]):
            self.consider(model, global_step, seg_step, label, trainer)

    def eval_fn(self, label: str = ""):
        def fn(trn, step):
            out = self.consider(trn.model, trn.state["global_step"], step, label)
            trn.model.train()
            return out
        return fn

    def record(self, bundle, diverged: bool = False, reason: Optional[str] = None,
               diverged_at: Optional[int] = None) -> Optional[dict]:
        """Write endpoint_best_val.json (reloaded and evaluated like the fixed endpoint) with the full
        candidate list; None when selection is off or no finite candidate exists.  A job that diverged AFTER
        its selected candidate (diverged_at, the trainer's global step of the failed update) keeps a valid
        selected endpoint: the candidate is a pre-divergence state whose own tensors and metrics are checked
        on reload.  The same rule applies to every arm."""
        if not self.enabled:
            return None
        self._charge()
        b = self.state.get("best")
        if b is None or not self.ctx.has_ckpt("best_val"):
            self.ctx.save_json("endpoint_best_val.json", {"stage": "endpoint_best_val", "selected": None,
                                                         "reason": "no finite validation candidate",
                                                         "selection": self.state})
            return None
        later = bool(diverged and diverged_at is not None and int(b["global_step"]) < int(diverged_at))
        return record_endpoint(self.ctx, bundle, "best_val", diverged and not later, reason, name="endpoint_best_val",
                               extra={"selection": self.state, "selected_global_step": b["global_step"],
                                      "job_diverged_after_selected_state": later,
                                      "job_diverged_at": diverged_at if diverged else None,
                                      "n_candidates": len(self.state["candidates"]),
                                      "selection_partition": self.partition,
                                      "note": "validation-selected endpoint; the fixed-budget endpoint is "
                                              "endpoint.json; the job's full work is charged to both"})


def seq_T(bundle) -> int:
    if bundle.layout == "seq":
        return int(bundle.test.X["x"].shape[1])
    return 1


# ----------------------------------------------------------------------------- deletion probes

def risk_of(m: dict, task: str) -> float:
    return M.headline(m, task)


def single_deletions(ctx, g: GraphNet, bundle, stage: str, base: dict, partitions=("val", "test")) -> dict:
    """Delta_A for every single atom at fixed remaining weights (L1 evidence)."""
    out = {}
    for a in g.atoms():
        try:
            h = E.delete(g, [a])
        except InvalidDeletion as ex:
            out[a] = {"invalid": str(ex)}
            ctx.metric(stage, "none", f"delete[{a}].invalid", str(ex))
            continue
        res, _ = evaluate(h, bundle, list(partitions), ctx.cfg["train"]["eval_batch"])
        rec = {}
        for p in partitions:
            if p in res and p in base:
                dlt = risk_of(res[p], bundle.task) - risk_of(base[p], bundle.task)
                rec[p] = {"delta_risk": dlt, **({"delta_acc": res[p]["acc"] - base[p]["acc"]} if "acc" in res[p] else {})}
                ctx.metric(stage, p, f"delete[{a}].delta_risk", dlt, h.structural_hash(), atoms=[a])
                if "acc" in res[p]:
                    ctx.metric(stage, p, f"delete[{a}].delta_acc", rec[p]["delta_acc"], h.structural_hash(), atoms=[a])
        out[a] = rec
    return out


def calib_partition(bundle, n: int):
    """Training-only calibration subset (used for any data-driven choice)."""
    idx = torch.arange(min(n, len(bundle.train)), device=bundle.train.y.device)
    return bundle.train.index(idx)
