"""Per-run context: directories, structured logs, long-format metric rows,
checkpoints with lineage, and parent-run access.

Run directory layout (results_root/runs/<run_id>/):
  config.json        resolved logical config (immutable)
  status.json        pending|running|complete|failed|timed_out|unsupported|skipped_with_reason
  attempts/<id>.json one record per attempt (exec fields, code/env hashes, error)
  log.jsonl          structured events
  metrics.jsonl      long-format metric rows with all required fields
  ckpt/<stage>.pt    checkpoints (model spec+state, trainer state, lineage)
  graphs/<stage>.json, .dot
  preds/<stage>__<partition>.pt
  summary.json       compact per-run summary
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any, Optional

import torch

from ..utils import (append_jsonl, atomic_torch_save, atomic_write_json, atomic_write_bytes, read_json, read_jsonl,
                     stable_hash, tensor_hash, semantic_code_hash, interrupted)
from ..config import run_id as make_run_id

STATUSES = ("pending", "running", "complete", "failed", "timed_out", "unsupported", "skipped_with_reason",
            "invalid", "stale")
# 'complete' = computationally finished.  Scientific validity is separate and is
# written next to it in status.json: validity = valid | unverified (a claimed
# property could not be checked, e.g. a certificate too large for the checker)
# | (status 'invalid': a claimed contract was violated; the run is quarantined
# and its dependants are skipped).  'stale' = a completed run produced by
# different result-determining code (see runner provenance checks).


class Unsupported(Exception):
    """Raised when a configuration is scientifically inapplicable; recorded as status 'unsupported'."""


class ScientificInvalid(Exception):
    """A claimed scientific contract was violated (e.g. a construction declared
    exact changed the function, a required control failed, an independent
    certificate check rejected a claim).  Recorded as status 'invalid' with the
    diagnostics; the run never enters analysis populations or parent selection."""

    def __init__(self, reason: str, diagnostics: Optional[dict] = None):
        super().__init__(reason)
        self.reason = reason
        self.diagnostics = diagnostics or {}


class StaleParent(RuntimeError):
    """A parent run was produced by different result-determining code."""


class RunContext:
    def __init__(self, cfg: dict, results_root: str | Path, exec_cfg: dict, attempt_id: str,
                 code_hash: str, env_hash: str):
        self.cfg = cfg
        self.run_id = make_run_id(cfg)
        self.root = Path(results_root)
        self.dir = self.root / "runs" / self.run_id
        self.exec = exec_cfg
        self.device = exec_cfg.get("device", "cpu")
        self.data_root = exec_cfg.get("data_root")
        self.attempt_id = attempt_id
        self.code_hash = code_hash
        self.env_hash = env_hash
        self.cfg_hash = stable_hash(cfg)
        self.t0 = time.time()
        self.split_hashes: dict = {}
        self.dir.mkdir(parents=True, exist_ok=True)
        (self.dir / "ckpt").mkdir(exist_ok=True)
        cpath = self.dir / "config.json"
        if cpath.exists():
            old = read_json(cpath)
            if stable_hash(old) != self.cfg_hash:
                raise RuntimeError(f"run dir {self.dir} holds a different config; refusing to reuse")
        else:
            atomic_write_json(cpath, cfg)
        self.updates = 0
        self.examples = 0
        self.semantic_hash = exec_cfg.get("_semantic_hash") or semantic_code_hash()
        self.validity = "valid"
        self.validity_reasons: list[str] = []
        self.work: dict[str, dict] = {}      # measured work by phase (updates, examples, forward examples, seconds)
        # numerical status of the training that produced this job's model; carried in every checkpoint so a
        # resumed attempt keeps a divergence that happened in an earlier attempt (V3-01 / V3-02)
        self.numerics: dict = {"diverged": False, "reason": None, "phase": None}

    def note_divergence(self, reason: Optional[str], phase: Optional[str]) -> None:
        if not self.numerics["diverged"]:
            self.numerics = {"diverged": True, "reason": reason, "phase": phase}
            self.log({"event": "job_diverged", "reason": reason, "phase": phase})

    def note_trainer(self, tr, phase: str) -> None:
        if tr is not None and tr.state.get("diverged"):
            self.note_divergence(tr.state.get("diverged_reason"), phase)

    # -------------------------------------------------------------- validity
    def unverified(self, reason: str) -> None:
        """A claimed property could not be independently checked (not a failure)."""
        if self.validity == "valid":
            self.validity = "unverified"
        self.validity_reasons.append(reason)
        self.log({"event": "unverified", "reason": reason})

    def count_work(self, phase: str, updates: int = 0, examples: int = 0, forward_examples: int = 0,
                   seconds: float = 0.0, macs: int = 0, teacher_macs: int = 0, macs_bwd: Optional[int] = None,
                   macs_complete: Optional[bool] = None) -> None:
        """macs: ESTIMATED dense training MACs (3 x analytic forward MACs of the effective graph per
        example per update; not measured backward work); macs_bwd: the backward-aware estimate
        (forward + input gradients where some upstream tensor trains + weight gradients of trainable
        tensors); teacher_macs: analytic forward MACs of teachers.  macs_complete is False when
        a phase trains without any MAC estimate (e.g. CoP local fits): its totals are partial."""
        w = self.work.setdefault(phase, {"updates": 0, "examples": 0, "forward_examples": 0, "seconds": 0.0,
                                         "macs": 0, "teacher_macs": 0, "macs_bwd": 0, "macs_complete": True,
                                         "macs_method": "estimated_dense_3x_forward"})
        w["updates"] += int(updates)
        w["examples"] += int(examples)
        w["forward_examples"] += int(forward_examples)
        w["seconds"] += float(seconds)
        w["macs"] = int(w.get("macs", 0)) + int(macs)
        w["teacher_macs"] = int(w.get("teacher_macs", 0)) + int(teacher_macs)
        w["macs_bwd"] = int(w.get("macs_bwd", 0)) + int(macs if macs_bwd is None else macs_bwd)
        if macs_complete is None:
            macs_complete = not (int(updates) > 0 and int(macs) == 0)
        w["macs_complete"] = bool(w.get("macs_complete", True)) and bool(macs_complete)
        w.setdefault("macs_method", "estimated_dense_3x_forward")

    def set_work(self, phase: str, counters: dict) -> None:
        """Record a phase from ABSOLUTE counters (overwrites): idempotent across attempts and resumes, unlike
        count_work, which adds increments."""
        w = {k: counters.get(k, 0) for k in ("updates", "examples", "forward_examples", "macs", "teacher_macs",
                                             "macs_bwd")}
        w["seconds"] = float(counters.get("seconds", 0.0))
        w["macs_complete"] = bool(counters.get("macs_complete", not (w["updates"] > 0 and w["macs"] == 0)))
        w["macs_method"] = "estimated_dense_3x_forward"
        w["recorded_from"] = counters.get("recorded_from", "trainer counters")
        self.work[phase] = w

    # ------------------------------------------------------------------ logs
    def log(self, rec: dict) -> None:
        append_jsonl(self.dir / "log.jsonl", {"t": round(time.time() - self.t0, 3), "attempt": self.attempt_id, **rec})

    def peak_mem(self) -> int:
        if str(self.device).startswith("cuda") and torch.cuda.is_available():
            return int(torch.cuda.max_memory_allocated())
        return 0

    def metric(self, stage: str, partition: str, name: str, value: Any, graph_hash: str = "",
               parent_id: str = "", **extra) -> None:
        c = self.cfg
        d = c.get("data", {})
        rec = {
            "run_id": self.run_id, "attempt_id": self.attempt_id, "parent_id": parent_id or self.parent_ids(),
            "work_package_id": ",".join(c.get("wp", [])), "resolved_config_hash": self.cfg_hash,
            "code_hash": self.code_hash, "environment_hash": self.env_hash, "split_hashes": self.split_hashes,
            "dataset_seed": d.get("data_seed"), "teacher_seed": d.get("teacher_seed"),
            "optimizer_seed": c.get("seeds", {}).get("optimizer"), "stage": stage, "graph_hash": graph_hash,
            "metric_name": name, "metric_value": value, "evaluation_partition": partition,
            "training_updates": self.updates, "examples_seen": self.examples,
            "elapsed_seconds": round(time.time() - self.t0, 3), "peak_memory_bytes": self.peak_mem(),
            "status": "recorded", **extra,
        }
        append_jsonl(self.dir / "metrics.jsonl", rec)

    def metrics(self, stage: str, partition: str, d: dict, prefix: str = "", graph_hash: str = "", **extra) -> None:
        for k, v in d.items():
            if isinstance(v, (int, float, list, tuple, str, bool)) or v is None:
                self.metric(stage, partition, prefix + k, v, graph_hash, **extra)

    def parent_ids(self) -> str:
        return ",".join(f"{k}:{v}" for k, v in sorted(self.cfg.get("parents", {}).items()))

    # ----------------------------------------------------------- checkpoints
    def ckpt_path(self, stage: str) -> Path:
        return self.dir / "ckpt" / f"{stage}.pt"

    def has_ckpt(self, stage: str) -> bool:
        return self.ckpt_path(stage).exists()

    def save_ckpt(self, stage: str, model, trainer=None, extra: Optional[dict] = None) -> None:
        obj = {"model": model.checkpoint(), "trainer": None if trainer is None else trainer.state_dict(),
               "lineage": {"run_id": self.run_id, "stage": stage, "parents": self.cfg.get("parents", {}),
                           "graph_hash": model.structural_hash(), "param_hash": model.param_hash(),
                           "cfg_hash": self.cfg_hash, "code_hash": self.code_hash, "split_hashes": self.split_hashes},
               "extra": extra or {}, "numerics": dict(self.numerics)}
        atomic_torch_save(obj, self.ckpt_path(stage))
        self.log({"event": "checkpoint", "stage": stage, "graph_hash": obj["lineage"]["graph_hash"]})

    def load_ckpt(self, stage: str, run_dir: Optional[Path] = None) -> dict:
        p = (run_dir or self.dir) / "ckpt" / f"{stage}.pt"
        ck = torch.load(p, map_location="cpu", weights_only=False)
        if run_dir is None and isinstance(ck, dict) and (ck.get("numerics") or {}).get("diverged"):
            nu = ck["numerics"]
            self.note_divergence(nu.get("reason"), nu.get("phase"))
        return ck

    def parent_dir(self, role: str) -> Path:
        """THE parent validation API (every parent access goes through it):
        the parent must be complete (an 'invalid' parent never is), an
        'unverified' parent makes this run unverified too, its stored config
        must hash to the declared run id, and it must have been produced by the
        same result-determining code (semantic code hash) unless that reuse was
        explicitly accepted and recorded (cop.cli accept-stale)."""
        pid = self.cfg.get("parents", {}).get(role)
        if pid is None:
            raise KeyError(f"no parent {role!r}")
        d = self.root / "runs" / pid
        st = d / "status.json"
        if not st.exists():
            raise RuntimeError(f"parent {role}={pid} has no status")
        sd = read_json(st)
        if sd.get("status") != "complete":
            raise RuntimeError(f"parent {role}={pid} is not complete (status {sd.get('status')})")
        if (d / "config.json").exists() and make_run_id(read_json(d / "config.json")) != pid:
            raise RuntimeError(f"parent {role}={pid}: stored config does not hash to its run id")
        prov = d / "provenance.json"
        if prov.exists():
            ph = read_json(prov).get("semantic_hash")
            if ph and ph != self.semantic_hash and not reuse_accepted(d, self.semantic_hash):
                raise StaleParent(f"parent {role}={pid} was produced by different result-determining code "
                                  f"({ph} != {self.semantic_hash}); rerun it or record an explicit reuse "
                                  f"(python -m cop.cli accept-stale)")
        else:
            raise StaleParent(f"parent {role}={pid} has no provenance record")
        if sd.get("validity", "valid") != "valid":
            why = f"parent {role}={pid} is {sd.get('validity')}"
            if why not in self.validity_reasons:
                self.unverified(why)
        return d

    def parent_ckpt(self, role: str, stage: str) -> dict:
        if not self.split_hashes:
            raise RuntimeError("set up the data (common.setup_data) before loading a parent checkpoint, so its "
                               "split hashes can be checked")
        ck = self.load_ckpt(stage, self.parent_dir(role))
        ph = ck["lineage"].get("split_hashes") or {}
        if ph and ph != self.split_hashes:
            raise RuntimeError(f"parent {role} was trained on different data splits; refusing to reuse")
        return ck

    def parent_json(self, role: str, name: str) -> Any:
        return read_json(self.parent_dir(role) / name)

    # -------------------------------------------------------------- outputs
    def save_graph(self, stage: str, model) -> None:
        (self.dir / "graphs").mkdir(exist_ok=True)
        atomic_write_json(self.dir / "graphs" / f"{stage}.json", model.to_json_graph())
        atomic_write_bytes(self.dir / "graphs" / f"{stage}.dot", model.to_dot().encode())

    def save_preds(self, stage: str, preds: dict) -> None:
        (self.dir / "preds").mkdir(exist_ok=True)
        for part, t in preds.items():
            atomic_torch_save(t.detach().to(torch.float32 if t.is_floating_point() else t.dtype).cpu(),
                              self.dir / "preds" / f"{stage}__{part}.pt")

    def save_json(self, name: str, obj: Any) -> None:
        atomic_write_json(self.dir / name, obj)

    def has_json(self, name: str) -> bool:
        return (self.dir / name).exists()

    def load_json(self, name: str) -> Any:
        return read_json(self.dir / name)

    def summary(self, obj: dict) -> None:
        atomic_write_json(self.dir / "summary.json", obj)


def reuse_accepted(run_dir: Path, semantic_hash: str) -> bool:
    for r in read_jsonl(Path(run_dir) / "reuse_accepted.jsonl"):
        if r.get("accepted_for_semantic_hash") == semantic_hash:
            return True
    return False


# =============================================================================
# Resumable state for manual (non-Trainer) loops and multi-stage jobs
# =============================================================================

class JobState:
    """Per-key checkpoints for manual loops and job stages (P3/P4/P5,
    dissipation, neutral mutation).  Each key has its own file
    ckpt/state__<key>.pt holding whatever the stage needs to continue or to be
    replayed (module states, optimizer state, generator state, step index,
    results).  A finished key is never recomputed; an interrupted loop resumes
    at the saved step.  Keys are replayed in program order on resume, so the
    final result equals an uninterrupted run."""

    def __init__(self, ctx, prefix: str = "state"):
        self.ctx = ctx
        self.prefix = prefix

    def _path(self, key: str) -> Path:
        safe = "".join(ch if ch.isalnum() or ch in "-_." else "_" for ch in key)
        return self.ctx.dir / "ckpt" / f"{self.prefix}__{safe}.pt"

    def get(self, key: str) -> Optional[dict]:
        p = self._path(key)
        return torch.load(p, map_location="cpu", weights_only=False) if p.exists() else None

    def put(self, key: str, payload: dict) -> None:
        atomic_torch_save(payload, self._path(key))

    def done(self, key: str) -> bool:
        d = self.get(key)
        return bool(d and d.get("done"))


def _mod_states(mods: dict) -> dict:
    return {k: {kk: v.detach().cpu().clone() for kk, v in m.state_dict().items()} for k, m in mods.items()}


def _load_mod_states(mods: dict, states: dict) -> None:
    for k, m in mods.items():
        if k in states:
            m.load_state_dict(states[k])


def local_loop(ctx, js: JobState, key: str, mods: dict, lopt, gen: Optional[torch.Generator], n: int, step_fn,
               every: Optional[int] = None, phase: str = "local_fit", examples_per_step: int = 0,
               k_offset: int = 0, extra_get=None, extra_set=None) -> dict:
    """n updates of `step_fn(k) -> loss tensor | None` (None = no trainable
    contribution at this step: counted as skipped, no update).  Resumable at
    step granularity: module states, optimizer state, the batch generator and
    the step index are checkpointed every `train.checkpoint_every` steps and on
    interrupt.  `k_offset` shifts the step index seen by the lr schedule (a
    continuation loop sharing one LocalOpt); `extra_get()` / `extra_set(d)`
    persist loop-level bookkeeping (e.g. assembly usage counts) with it.
    Returns {'updates', 'skipped', 'seconds'}."""
    import time as _time
    st = js.get(key)
    if st is not None and st.get("done"):
        _load_mod_states(mods, st["modules"])
        lopt.load_state_dict(st["opt"])
        if gen is not None and st.get("gen") is not None:
            gen.set_state(st["gen"])
        if extra_set is not None and st.get("extra") is not None:
            extra_set(st["extra"])
        info = st["info"]
        ctx.count_work(phase, updates=info["updates"], examples=info["updates"] * examples_per_step,
                       seconds=info["seconds"])
        return info
    k0, skipped, secs = 0, 0, 0.0
    if st is not None:
        _load_mod_states(mods, st["modules"])
        lopt.load_state_dict(st["opt"])
        if gen is not None and st.get("gen") is not None:
            gen.set_state(st["gen"])
        k0, skipped, secs = st["k"], st.get("skipped", 0), st.get("seconds", 0.0)
        if extra_set is not None and st.get("extra") is not None:
            extra_set(st["extra"])
        ctx.log({"event": "resume_local_loop", "key": key, "step": k0})
    every = every if every is not None else int(ctx.cfg.get("train", {}).get("checkpoint_every") or 0)
    t0 = _time.time()

    def save(k, done=False, info=None):
        js.put(key, {"modules": _mod_states(mods), "opt": lopt.state_dict(),
                     "gen": None if gen is None else gen.get_state(), "k": k, "skipped": skipped,
                     "seconds": secs + _time.time() - t0, "done": done, "info": info,
                     "extra": None if extra_get is None else extra_get()})

    for k in range(k0, n):
        if interrupted():
            save(k)
            raise KeyboardInterrupt("interrupted; checkpoint written")
        loss = step_fn(k)
        if loss is None or not getattr(loss, "requires_grad", False):
            skipped += 1
        else:
            lopt.step(loss, k + k_offset)
        if every and (k + 1) % every == 0 and k + 1 < n:
            save(k + 1)
    info = {"updates": n - skipped, "skipped": skipped, "seconds": secs + _time.time() - t0}
    save(n, True, info)
    ctx.count_work(phase, updates=info["updates"], examples=info["updates"] * examples_per_step,
                   seconds=info["seconds"])
    return info
