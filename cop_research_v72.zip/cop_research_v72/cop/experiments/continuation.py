"""Compact-architecture continuation jobs (kind=continue): the controls of the
strengthening extension and the common continuation of durability tests.

A job continues a start checkpoint (by default the baseline f0) in its own
architecture for a budget, under one arm:
  plain         C1 (equal updates / examples) and C2 (budget = parent_compute: equal measured
                training MACs); also the common continuation of exported models (durability)
  lr_restart    C7: the learning-rate schedule restarts (warmup + cosine) at every segment start
  opt_reset     C7: optimizer state reset at every segment start
  perturb       C7: Gaussian perturbation of every trainable tensor (norm perturb_rel * ||theta||)
                at every segment start (matched perturbation without growth)
  distill       C4: loss = alpha * distill(teacher) + (1 - alpha) * task; the teacher is an expanded
                model (continue.teacher); its forward cost is charged
  self_distill  C5: the same with a same-architecture teacher (born-again when reinit=true)
  prune_regrow  C8: every prune_period updates the lowest-norm prune_frac of the output channels of
                each hidden linear / conv layer is zeroed for prune_duration updates, then regrown
                (orthogonal re-initialisation at the mean norm of the kept channels)
The start checkpoint's trainer state is inherited (random streams, optimizer
state, counters), so a control sees the same minibatch order as the treated
history it is paired with.  `segments` mirrors the treated history's segment
structure (rounds, contraction phases), so lr schedules restart at the same points.
"""
from __future__ import annotations

import copy

import json

import math
from typing import Optional

import torch
import torch.nn.functional as F

from ..config import seed_of
from ..graph.graph import GraphNet
from ..graph.accounting import architecture_hash, report as acct_report
from ..train import metrics as M
from ..train.trainer import (Segment, distill_loss, task_loss, forward_macs, teacher_star_loss, predict,
                             compute_counters, MAC_PARTS)
from ..utils import torch_gen, read_json
from . import common as C
from .context import Unsupported, ScientificInvalid


DIAGNOSTIC = "diagnostic:"      # work phases that do not reach the job's endpoint (e.g. a repaired clone)
SEARCH = "search:"              # v13: validation-selection evaluations; part of the procedure's cost, not training
_W0 = ("updates", "examples", "macs", "teacher_macs", "macs_bwd", "seconds")
ZERO_WORK = {"updates": 0, "examples": 0, "macs": 0, "teacher_macs": 0, "macs_bwd": 0, "seconds": 0.0,
             "macs_complete": True}


BASELINE_PHASE = "baseline_train"


def _counters(state: dict) -> dict:
    """Work counters of a trainer state (absolute, as saved in a checkpoint)."""
    upd, macs = int(state.get("global_step", 0)), int(state.get("train_macs", 0))
    return {"updates": upd, "examples": int(state.get("examples", 0)), "macs": macs,
            "teacher_macs": int(state.get("teacher_macs", 0)),
            "macs_bwd": int(state.get("train_macs_bwd", macs)), "seconds": 0.0,
            "macs_complete": not (upd > 0 and macs == 0)}


def baseline_cost(d) -> dict:
    """Training work of a baseline (f0) job, with its provenance (v13, audit A2).
      ledger                  the job's recorded 'baseline_train' phase (v13 and later)
      checkpoint_counters     no ledger (results of v12 or earlier): the counters saved in ckpt/baseline.pt
      missing                 neither: reported as INCOMPLETE, never as zero-and-complete"""
    from pathlib import Path
    d = Path(d)
    sm = read_json(d / "summary.json") if (d / "summary.json").exists() else {}
    w = (sm.get("work") or {}).get(BASELINE_PHASE)
    if w:
        out = {k: w.get(k, 0) for k in _W0}
        out["macs_complete"] = bool(w.get("macs_complete", True))
        return {**out, "provenance": "ledger", "source": str(d / "summary.json")}
    ck = d / "ckpt" / "baseline.pt"
    if ck.exists():
        st = torch.load(ck, map_location="cpu", weights_only=False)["trainer"]["state"]
        return {**_counters(st), "provenance": "checkpoint_counters (no work ledger: v12 or earlier)",
                "source": str(ck)}
    return {**dict(ZERO_WORK), "macs_complete": False,
            "provenance": "missing: no work ledger and no baseline checkpoint", "source": None}


def inline_f0_cost(d) -> Optional[dict]:
    """Work of an f0 trained INSIDE a chain job (no 'baseline' parent): the counters saved with its
    baseline_ref.  None when the job has a baseline parent (that parent's baseline_cost applies)."""
    from pathlib import Path
    d = Path(d)
    cfg = read_json(d / "config.json") if (d / "config.json").exists() else {}
    if "baseline" in (cfg.get("parents") or {}):
        return None
    ck = d / "ckpt" / "baseline_ref.pt"
    if not ck.exists():
        return {**dict(ZERO_WORK), "macs_complete": False, "provenance": "missing: inline f0 without baseline_ref",
                "source": None}
    b = torch.load(ck, map_location="cpu", weights_only=False)
    st = ((b.get("extra") or {}).get("trainer") or {}).get("state")
    if st is None:
        return {**dict(ZERO_WORK), "macs_complete": False, "provenance": "missing: baseline_ref has no counters",
                "source": str(ck)}
    return {**_counters(st), "provenance": "inline baseline_ref counters", "source": str(ck)}


def run_work(d) -> dict:
    """A run's own work, without diagnostic phases.  macs / macs_bwd are estimates (see
    ExperimentContext.count_work); macs_complete is False if any phase trained without one.
    v13: a baseline job's work is its baseline_cost (ledger, else checkpoint counters, else incomplete)."""
    from pathlib import Path
    d = Path(d)
    cfgp = d / "config.json"
    if cfgp.exists() and (read_json(cfgp).get("kind") == "baseline"):
        b = baseline_cost(d)
        return {k: b[k] for k in (*_W0, "macs_complete")}
    tot = dict(ZERO_WORK)
    sm = read_json(d / "summary.json") if (d / "summary.json").exists() else {}
    for ph, w in (sm.get("work") or {}).items():
        if ph.startswith(DIAGNOSTIC) or ph.startswith(SEARCH):
            continue
        for k in _W0:
            v = w.get(k)
            if k == "macs_bwd" and v is None:
                v = w.get("macs", 0)
            tot[k] += v or 0
        upd, macs = int(w.get("updates", 0) or 0), int(w.get("macs", 0) or 0)
        tot["macs_complete"] = tot["macs_complete"] and bool(w.get("macs_complete", not (upd > 0 and macs == 0)))
    return tot


def search_work(d) -> dict:
    """Validation-selection work of a run (v13, audit C2: search / validation work is charged): forward MACs
    and examples of every candidate evaluation.  Kept out of run_work, so training budgets and MAC matching
    stay training-only; the analysis adds it to the total procedure cost."""
    from pathlib import Path
    d = Path(d)
    sm = read_json(d / "summary.json") if (d / "summary.json").exists() else {}
    tot = {"macs": 0, "forward_examples": 0}
    for ph, w in (sm.get("work") or {}).items():
        if ph.startswith(SEARCH):
            tot["macs"] += int(w.get("macs", 0) or 0)
            tot["forward_examples"] += int(w.get("forward_examples", 0) or 0)
    return tot


def _ckpt_trainer_state(ck: dict) -> Optional[dict]:
    t = ck.get("trainer") or (ck.get("extra") or {}).get("trainer") or {}
    return t.get("state") if isinstance(t, dict) else None


def stage_work(d, stage: Optional[str]) -> Optional[dict]:
    """Training work of run d up to its checkpoint `stage` (v20: any checkpoint that carries trainer counters:
    snap_<u>, post_insert_r<k>, round_<k>, pre_contraction_r<k>, ...): the checkpoint's counters minus those at
    the run's start (baseline_ref).  None for the run's whole work (stage None or final).  A missing checkpoint
    or one without counters gives ZERO counters with accounting_complete False and the reason; it is never
    replaced by the run's full cost."""
    from pathlib import Path
    d = Path(d)
    if stage in (None, "", "final"):
        return None
    ps, pb = d / "ckpt" / f"{stage}.pt", d / "ckpt" / "baseline_ref.pt"
    bad = lambda why: {**dict(ZERO_WORK), "macs_complete": False, "accounting_complete": False,
                       "accounting_note": f"{d.name}@{stage}: {why}"}
    if not ps.exists():
        return bad("stage checkpoint missing")
    s = _ckpt_trainer_state(torch.load(ps, map_location="cpu", weights_only=False))
    if s is None:
        return bad("stage checkpoint has no trainer counters")
    cfg = read_json(d / "config.json")
    scratch = (cfg.get("growth") or {}).get("schedule") == "from_scratch"
    if scratch:
        bt = {}
    else:
        if not pb.exists():
            return bad("baseline_ref checkpoint missing (start counters unknown)")
        bt = _ckpt_trainer_state(torch.load(pb, map_location="cpu", weights_only=False)) or {}
    g = lambda st, k, dflt=None: int(st.get(k, st.get(dflt, 0) if dflt else 0) or 0)
    out = {"updates": g(s, "global_step") - g(bt, "global_step"),
           "examples": g(s, "examples") - g(bt, "examples"),
           "macs": g(s, "train_macs") - g(bt, "train_macs"),
           "teacher_macs": g(s, "teacher_macs") - g(bt, "teacher_macs"),
           "macs_bwd": g(s, "train_macs_bwd", "train_macs") - g(bt, "train_macs_bwd", "train_macs")}
    full = run_work(d)
    out["macs_complete"] = full["macs_complete"]
    out["accounting_complete"] = True
    out["seconds"] = full["seconds"] * out["updates"] / max(1, full["updates"])   # pro rata (wall time only)
    return out


def _consumed(d, stage: Optional[str], into: dict) -> None:
    """Record that the procedure consumes run d up to `stage`, then the learned models d itself consumed: its
    trajectory parent (at tags.parent_stage) and, for a hybrid removal, the donor (at dissipation.hybrid.donor_stage).
    Baselines (f0) are never consumed here (reported separately); budget-only or comparison-only parents are not
    learned dependencies and are not followed."""
    from pathlib import Path
    d = Path(d)
    if not (d / "config.json").exists():
        into.setdefault(str(d), []).append(("missing", stage))
        return
    cfg = read_json(d / "config.json")
    if cfg.get("kind") == "baseline":
        return
    into.setdefault(str(d), []).append(("run", stage))
    par = cfg.get("parents") or {}
    rb = (cfg.get("dissipation") or {}).get("rebuild") or {}
    pristine = rb.get("backbone") == "f0" and rb.get("implants") == "fresh"
    if par.get("trajectory") and not pristine:
        # v22: a start state rebuilt from f0 and implants at insertion consumes no trained model (the trajectory
        # supplies only the graph and the insertion draws); any trained part keeps the trajectory charged
        _consumed(d.parent / par["trajectory"], (cfg.get("tags") or {}).get("parent_stage") or "final", into)
    hy = (cfg.get("dissipation") or {}).get("hybrid") or {}
    if hy.get("donor_role") and par.get(hy["donor_role"]):
        _consumed(d.parent / par[hy["donor_role"]], hy.get("donor_stage") or "final", into)


def _sum(ws) -> dict:
    tot = {**dict(ZERO_WORK), "accounting_complete": True}
    notes = []
    for w in ws:
        for k in _W0:
            tot[k] += w.get(k, 0) or 0
        tot["macs_complete"] = tot["macs_complete"] and bool(w.get("macs_complete", True))
        tot["accounting_complete"] = tot["accounting_complete"] and bool(w.get("accounting_complete", True))
        if w.get("accounting_note"):
            notes.append(w["accounting_note"])
    if notes:
        tot["accounting_note"] = "; ".join(notes)
    return tot


def chain_work_parts(d) -> dict:
    """v20 procedure cost of the model at run d, by consumed learned dependency, each charged ONCE:
      own                 d's own training (e.g. removal and repair)
      source_lineage      the trajectory chain d starts from, up to the stage it starts from
      donor_incremental   for a hybrid: what the donor adds beyond the source lineage (a different descendant of
                          the same f0: its own training up to the donor stage; the same trajectory at another
                          stage: only the part beyond the stage already charged)
      total               the sum (f0 excluded; it is reported separately)
    Several consumptions of one run are charged at the latest stage needed (counters are monotone within a run)."""
    from pathlib import Path
    d = Path(d)
    own = run_work(d)
    cons_src, cons_all = {}, {}
    cfg = read_json(d / "config.json") if (d / "config.json").exists() else {}
    par = cfg.get("parents") or {}
    rb = (cfg.get("dissipation") or {}).get("rebuild") or {}
    if par.get("trajectory") and not (rb.get("backbone") == "f0" and rb.get("implants") == "fresh"):
        _consumed(d.parent / par["trajectory"], (cfg.get("tags") or {}).get("parent_stage") or "final", cons_src)
    _consumed(d, None, cons_all)
    cons_all.pop(str(d), None)

    def charge(cons: dict) -> list:
        ws = []
        for run, uses in cons.items():
            if any(kind == "missing" for kind, _ in uses):
                ws.append({**dict(ZERO_WORK), "macs_complete": False, "accounting_complete": False,
                           "accounting_note": f"{Path(run).name}: run folder missing"})
                continue
            cand = []
            for _, st in uses:
                w = stage_work(run, st)
                cand.append(w if w is not None else {**run_work(run), "accounting_complete": True})
            ok = [w for w in cand if w.get("accounting_complete", True)]
            ws.append(max(ok, key=lambda w: w["updates"]) if ok else cand[0])
        return ws
    src = _sum(charge(cons_src))
    allw = _sum(charge(cons_all))
    donor = {k: (allw[k] - src[k]) for k in _W0}
    donor.update({"macs_complete": allw["macs_complete"], "accounting_complete": allw["accounting_complete"]})
    total = _sum([own, allw])
    return {"own": own, "source_lineage": src, "donor_incremental": donor, "total": total}


def chain_work_dir(d) -> dict:
    """Work of the treated chain ending at run d (C1 / C2 budget rule): d's own work plus every learned model it
    consumes, each once (chain_work_parts total), excluding f0 and controls.  A child that starts from a
    checkpoint of its trajectory (tags.parent_stage) is charged the trajectory's work up to that checkpoint."""
    t = chain_work_parts(d)["total"]
    return t


def chain_work(ctx, role: str) -> dict:
    return chain_work_dir(ctx.parent_dir(role))


def _fork_point(tr, si: int, base_u: int) -> dict:
    """v43: the trainer at a segment start, before that segment's optimizer rule: the model's parameter hash, the
    optimizer state by parameter name, the sampler position / epoch / permutation, the RNG states and the
    minibatch stream so far."""
    import hashlib as _hl
    from .dissipation import opt_state_digest
    st = tr.state
    perm = st.get("perm")
    rng = _hl.sha256(b"".join(k.encode() + g_.get_state().numpy().tobytes()
                              for k, g_ in sorted(tr.gens.items()) if g_ is not None)).hexdigest()[:24]
    return {"segment": int(si), "update": int(base_u), "model_param_hash": tr.model.param_hash(),
            "opt": opt_state_digest(tr.opt, list(getattr(tr, "opt_param_names", []) or [])) if tr.opt is not None
            else None,
            "sampler": {"pos": int(st.get("pos", 0)), "epoch": int(st.get("epoch", 0)),
                        "perm_hash": None if perm is None else _hl.sha256(perm.cpu().numpy().tobytes()).hexdigest()[:24]},
            "rng_hash": rng, "batch_id_hash": st.get("batch_id_hash"), "batches_drawn": st.get("batches_drawn")}


def _segments(cc: dict, total: int) -> list[int]:
    if cc["segments"] and sum(cc["segments"]) == total:
        return [int(x) for x in cc["segments"]]
    if cc["segments"]:
        # a derived budget (parent_compute / parent_updates): keep the proportions of the segments
        s = sum(cc["segments"])
        out = [int(round(total * x / s)) for x in cc["segments"]]
        out[-1] += total - sum(out)
        return out
    return [total]


@torch.no_grad()
def _perturb(model: GraphNet, rel: float, gen: torch.Generator) -> float:
    tot = 0.0
    for p in model.parameters():
        if not p.requires_grad or p.numel() == 0:
            continue
        n = torch.randn(p.shape, generator=gen, dtype=torch.float64).to(p.device, p.dtype)
        nrm = float(p.detach().double().norm())
        if nrm == 0 or float(n.double().norm()) == 0:
            continue
        p.add_(n * (rel * nrm / float(n.double().norm())))
        tot += rel * nrm
    return tot


def etd_selection_points(segs: list, k: int) -> set:
    """v23: validation-selection points (total-update positions) of an example-tied dropout job: k candidates
    spread over its repair segment (offsets 1..repair, the last the final update), none in the masked phase."""
    from .common import selection_points
    return {int(segs[0]) + int(p_) for p_ in selection_points(int(segs[1]), int(k))}


class _ExampleTiedDropout:
    """v22: example-tied dropout (Maini et al., ICML 2023, "Can Neural Network Memorization Be Localized?"),
    adapted to the compact MLP.  In every hidden linear layer of the backbone, a fixed random fraction p_gen of
    the units ("generalization neurons") is always active; every training example gets its own fixed random
    subset of the remaining units ("memorization neurons", p_mem of that pool), active only when the example is
    in the batch; the other units are zeroed for that example.  In evaluation mode only the generalization
    neurons are active (the paper's test-time rule; no rescaling, which the paper does not specify).  The mask
    acts on the linear layer's output, which equals masking the unit when the following activation maps 0 to 0
    (relu, gelu, tanh, silu, identity; anything else is refused).  drop(): the memorization neurons' outgoing
    weights (the consumer layer's input columns) are zeroed, so the plain network computes the test-time function
    exactly and can be trained further without masks."""
    ZERO_ACTS = ("relu", "gelu", "tanh", "silu", "identity")

    def __init__(self, model: GraphNet, n_train: int, p_gen: float, p_mem: float, seed: int):
        self.p_gen, self.p_mem = float(p_gen), float(p_mem)
        self.layers, self.consumer = [], {}
        cons = {}
        for nid in model.topo_order():
            for i in model.nodes[nid].inputs:
                cons.setdefault(i, []).append(nid)
        for nid in model.topo_order():
            nd = model.nodes[nid]
            if nd.op != "linear" or nid == model.output or nd.owner is not None:
                continue
            c1 = cons.get(nid, [])
            if len(c1) != 1 or model.nodes[c1[0]].op != "act" or \
                    model.nodes[c1[0]].attrs.get("fn") not in self.ZERO_ACTS:
                raise Unsupported(f"example-tied dropout: hidden layer {nid} is not followed by a single activation "
                                  f"with act(0) = 0")
            c2 = cons.get(c1[0], [])
            if len(c2) != 1 or model.nodes[c2[0]].op != "linear":
                raise Unsupported(f"example-tied dropout: the activation after {nid} does not feed one linear layer")
            self.layers.append(nid)
            self.consumer[nid] = c2[0]
        if not self.layers:
            raise Unsupported("example-tied dropout needs hidden linear layers")
        self.gen_mask, self.mem_assign, self.n_mem_active = {}, {}, {}
        for li, nid in enumerate(self.layers):
            w = int(model.mods[model.nodes[nid].pkey].weight.shape[0])
            g = torch_gen(seed, "init", "example_tied_dropout", nid)
            perm = torch.randperm(w, generator=g)
            n_gen = max(1, int(round(self.p_gen * w)))
            gm = torch.zeros(w, dtype=torch.bool)
            gm[perm[:n_gen]] = True
            pool = perm[n_gen:]
            k = max(1, int(round(self.p_mem * len(pool)))) if len(pool) else 0
            # per example: k units of the memorization pool (independent draws from one generator, CPU)
            sel = torch.argsort(torch.rand(n_train, len(pool), generator=g), dim=1)[:, :k]
            ma = torch.zeros(n_train, w, dtype=torch.bool)
            if k:
                ma.scatter_(1, pool[sel], True)
            self.gen_mask[nid], self.mem_assign[nid], self.n_mem_active[nid] = gm, ma, k
        self.mode = "off"

    def set_mode(self, model: GraphNet, mode: str) -> None:
        """'etd': every forward WITHOUT a per-call patch (evaluation, prediction) sees the test-time rule
        (generalization neurons only) through the graph's value_patch; training batches carry their own
        per-example masks (batch_ctx -> ctx['patch'], which takes precedence).  'off': no masking."""
        self.mode = mode
        if mode == "etd":
            model.value_patch = {nid: (lambda v, nid=nid: v * self.gen_mask[nid].to(v.device, v.dtype)[None, :])
                                 for nid in self.layers}
        else:
            model.value_patch = None

    def batch_ctx(self, batch) -> dict:
        idx = batch.aux["_index"].long().cpu()
        ms = {nid: (self.gen_mask[nid][None, :] | self.mem_assign[nid][idx]) for nid in self.layers}
        return {"patch": {nid: (lambda v, m=m: v * m.to(v.device, v.dtype)) for nid, m in ms.items()}}

    @torch.no_grad()
    def drop(self, model: GraphNet) -> dict:
        n = 0
        for nid in self.layers:
            m = model.mods[model.nodes[self.consumer[nid]].pkey]
            mem = (~self.gen_mask[nid]).to(m.weight.device)
            m.weight[:, mem] = 0
            n += int(mem.sum())
        return {"memorization_units_dropped": n}

    def info(self) -> dict:
        return {"method": "example-tied dropout (Maini et al. 2023), adapted", "p_gen": self.p_gen,
                "p_mem": self.p_mem, "p_mem_meaning": "fraction of the memorization pool active per example",
                "layers": {nid: {"units": int(len(self.gen_mask[nid])), "generalization": int(self.gen_mask[nid].sum()),
                                 "memorization_active_per_example": int(self.n_mem_active[nid])}
                           for nid in self.layers},
                "mask_point": "output of each hidden linear layer (act(0) = 0 makes it the unit's activation); "
                              "applied through the graph's value patch",
                "test_time": "generalization neurons only; no rescaling"}


class _PruneRegrow:
    """C8 (RePr / DSD style): every prune_period updates the lowest-norm prune_frac of the output
    channels of each hidden linear / conv layer is pruned for prune_duration updates, then regrown
    (orthogonal to the kept filters, at their mean norm).

    Persistence policy (V3-06), recorded in every event: while a prune window is open the pruned rows
    are zeroed before every training forward AND after every optimizer step (post_step), so every
    evaluation and checkpoint between updates sees them at zero; the optimizer moments of the
    affected rows (Adam exp_avg / exp_avg_sq, SGD momentum_buffer) are reset to zero at pruning and
    again at regrowth, so inherited moments cannot reactivate a pruned row and a regrown row starts
    without stale momentum.  Masks are row indices kept on CPU (checkpointed) and moved to the
    weights' device when applied (V3-05); random draws come from a CPU generator and are moved."""
    MOMENT_POLICY = "reset_at_prune_and_regrow"

    def __init__(self, model: GraphNet, frac: float, period: int, duration: int, seed: int):
        self.frac, self.period, self.duration, self.seed = frac, period, duration, seed
        self.masks: dict[str, torch.Tensor] = {}
        self.events: list[dict] = []
        self.layers = [n for n in model.topo_order() if model.nodes[n].op in ("linear", "conv")
                       and n != model.output and model.nodes[n].owner is None]

    @staticmethod
    def _reset_moments(trn, m, ii) -> int:
        opt = getattr(trn, "opt", None)
        if opt is None:
            return 0
        n = 0
        for prm in (m.weight, m.bias):
            if prm is None:
                continue
            st = opt.state.get(prm) or {}
            for key in ("exp_avg", "exp_avg_sq", "max_exp_avg_sq", "momentum_buffer"):
                t = st.get(key)
                if isinstance(t, torch.Tensor) and t.dim() > 0 and t.shape[0] == prm.shape[0]:
                    t[ii] = 0
                    n += 1
        return n

    @torch.no_grad()
    def _zero(self, g) -> None:
        for nid, idx in self.masks.items():
            m = g.mods[g.nodes[nid].pkey]
            ii = idx.to(m.weight.device)
            m.weight[ii] = 0
            if m.bias is not None:
                m.bias[ii] = 0

    @torch.no_grad()
    def __call__(self, trn, k: int) -> None:
        g = trn.model
        ph = k % self.period
        ev = k // self.period
        if ph == 0:
            self.masks = {}
            reset = 0
            for nid in self.layers:
                m = g.mods[g.nodes[nid].pkey]
                W = m.weight
                nrm = W.reshape(W.shape[0], -1).norm(dim=1)
                q = max(1, int(round(self.frac * W.shape[0])))
                idx = torch.argsort(nrm)[:q].cpu()
                self.masks[nid] = idx
                reset += self._reset_moments(trn, m, idx.to(W.device))
            self.events.append({"update": k, "event": "prune", "moment_policy": self.MOMENT_POLICY,
                                "moment_tensors_reset": reset,
                                "n_channels": {n: int(len(v)) for n, v in self.masks.items()}})
        if ph < self.duration and self.masks:
            self._zero(g)                                    # pruned rows are zero in this training forward
        if ph == self.duration and self.masks:
            gen = torch_gen(self.seed, "init", "prune_regrow", str(ev))
            reset = 0
            for nid, idx in self.masks.items():
                m = g.mods[g.nodes[nid].pkey]
                dev = m.weight.device
                ii = idx.to(dev)
                W = m.weight.reshape(m.weight.shape[0], -1).double()
                keep = torch.ones(W.shape[0], dtype=torch.bool, device=dev)
                keep[ii] = False
                K = W[keep]
                R = torch.randn(len(idx), W.shape[1], generator=gen, dtype=torch.float64).to(dev)
                if K.shape[0] and K.shape[0] < W.shape[1]:
                    Q = torch.linalg.qr(K.T)[0]                   # orthonormal basis of the kept filters
                    R = R - (R @ Q) @ Q.T                         # regrown filters orthogonal to the kept ones
                scale = float(K.norm(dim=1).mean()) if K.shape[0] else 1.0
                R = R / R.norm(dim=1, keepdim=True).clamp_min(1e-12) * scale
                m.weight[ii] = R.reshape(len(idx), *m.weight.shape[1:]).to(m.weight.dtype)
                if m.bias is not None:
                    m.bias[ii] = 0
                reset += self._reset_moments(trn, m, ii)
            self.events.append({"update": k, "event": "regrow", "moment_policy": self.MOMENT_POLICY,
                                "moment_tensors_reset": reset})
            self.masks = {}

    @torch.no_grad()
    def post_step(self, trn, k: int) -> None:
        """After the optimizer step of update k: keep the pruned rows at zero for evaluation /
        checkpointing until the window closes (the regrowth happens at the start of update
        k = start + duration)."""
        if self.masks and (k % self.period) < self.duration:
            self._zero(trn.model)


def _finish_reinit(ctx, model: GraphNet, bundle, arch0: str) -> dict:
    """After re-initialisation of an endpoint architecture (e.g. a CoP export): table modules are
    zeroed (the generic initialiser does not cover them) and every quantiser is re-calibrated on
    the re-initialised network's training activations, as for the P5 matched controls.  The
    architecture must be unchanged."""
    import torch.nn as nn
    for m in model.mods.values():
        for mm in m.modules():
            if hasattr(mm, "table") and isinstance(getattr(mm, "table"), nn.Parameter):
                with torch.no_grad():
                    mm.table.zero_()
    recal = []
    if any(model.nodes[n].op == "quant" for n in model.live_nodes()):
        from ..cop_pegs.cycles import recalibrate_quantizers
        recal = recalibrate_quantizers(ctx, model, bundle, "continue_reinit")
    if architecture_hash(model) != arch0:
        raise ScientificInvalid("re-initialisation changed the endpoint architecture", {})
    return {"quantizers_recalibrated": recal}


def quant_recipe_name(t: dict) -> str:
    """v15 finite-peg training recipe label: warmup (capacity relaxation), else the range rule (fixed / ema)."""
    w = int(t.get("quant_warmup_updates", 0) or 0)
    r = t.get("quant_range", "fixed")
    name = f"warmup+{r}" if w and r != "fixed" else ("warmup" if w else r)
    return name + ("_m" if float(t.get("quant_ste_margin", 0.0) or 0.0) > 0 else "")     # v17 gradient margin


@torch.no_grad()
def quantizer_audit(model: GraphNet, bundle, n: int = 512, ref_codes: Optional[dict] = None,
                    keep_codes: Optional[dict] = None) -> list[dict]:
    """v13 (audit B3 / C4): the state of every quantiser on TRAINING calibration activations: clipping
    fraction (inputs outside [lo, hi], whose straight-through gradient is zero), distinct levels per
    coordinate and distinct full messages against the alphabet (occupancy).  A diagnostic, not a fix."""
    X = {k: v[:n] for k, v in bundle.train.X.items()}
    was = model.training
    model.eval()
    out = []
    for nid in [q for q in model.topo_order() if model.nodes[q].op == "quant"]:
        q = model.mods[model.nodes[nid].pkey]
        zin = model.nodes[nid].inputs[0]
        _, v = model(X, return_nodes=[zin])
        z = v[zin]
        z = (z.permute(0, 2, 3, 1).reshape(-1, q.k) if z.dim() == 4 else z.reshape(-1, q.k)).float()
        rec = {"node": nid, "mode": q.mode, "k": int(q.k), "calibrated": bool(q.calibrated)}
        if q.mode == "uniform":
            lo, hi = q.lo.float().to(z.device), q.hi.float().to(z.device)
            rec["clip_fraction"] = float(((z < lo) | (z > hi)).float().mean())
            # v17: clipped inputs split into those within 1e-4 x range of the edge (rounding at a discrete edge,
            # covered by train.quant_ste_margin) and those genuinely outside
            out_by = torch.maximum(lo - z, z - hi)
            edge = (out_by > 0) & (out_by <= 1e-4 * (hi - lo))
            rec["clip_fraction_edge"] = float(edge.float().mean())
            rec["clip_fraction_far"] = float((out_by > 1e-4 * (hi - lo)).float().mean())
            c = q.codes(z)
            rec["levels"] = int(2 ** q.bits)
            rec["distinct_levels_per_coordinate"] = [int(torch.unique(c[:, j]).numel()) for j in range(c.shape[1])]
            rec["distinct_messages"] = int(torch.unique(c, dim=0).shape[0])
            rec["alphabet"] = q.n_symbols()
            ent = []
            for j in range(c.shape[1]):
                _, cnt = torch.unique(c[:, j], return_counts=True)
                pr = cnt.double() / cnt.sum()
                ent.append(float(-(pr * pr.log2()).sum()))
            rec["coordinate_entropy_bits"] = ent
            rec["range_lo"], rec["range_hi"] = [float(x) for x in q.lo], [float(x) for x in q.hi]
            cc_ = c.cpu()
            if keep_codes is not None:
                keep_codes[nid] = cc_
            if ref_codes is not None and nid in ref_codes and ref_codes[nid].shape == cc_.shape:
                rec["code_change_fraction_from_start"] = float((ref_codes[nid] != cc_).any(1).double().mean())
        elif q.mode in ("vq", "multi"):
            c = q.codes(z)
            rec["distinct_messages"] = int(torch.unique(c if c.dim() > 1 else c[:, None], dim=0).shape[0])
            rec["alphabet"] = q.n_symbols()
        out.append(rec)
    model.train(was)
    return out


def gradient_audit(model: GraphNet, bundle, n: int = 256, ste_margin: float = 0.0) -> dict:
    """Gradient norm by module of the task loss on one training calibration batch (a clone: the model and its
    trainer are untouched).  Modules with exactly zero gradient are listed (e.g. behind a saturated clip).
    ste_margin: the job's train.quant_ste_margin, so the audit uses the gradient rule the job trained with."""
    from ..graph.ops import Quantizer
    g = model.clone(share_params=False)
    g.train()
    for m_ in g.mods.values():
        if isinstance(m_, Quantizer):
            m_.ste_margin = float(ste_margin or 0.0)
            m_.passthrough = False
    X = {k: v[:n] for k, v in bundle.train.X.items()}
    y = bundle.train.y[:n]
    out = g(X)
    task_loss(out, y, bundle.task).backward()
    norms = {}
    for key, m in g.mods.items():
        ps = [p for p in m.parameters() if p.grad is not None]
        if any(p.requires_grad for p in m.parameters()):
            norms[key] = float(torch.sqrt(sum((p.grad.double() ** 2).sum() for p in ps))) if ps else 0.0
    return {"grad_norm_by_module": norms, "zero_gradient_modules": sorted(k for k, v in norms.items() if v == 0.0),
            "ste_margin": float(ste_margin or 0.0)}


@torch.no_grad()
def _perturb_matched(ctx, cfg, cc, model, bundle) -> dict:
    """v32: a generic damage-and-recovery control.  One fixed random direction per parameter tensor (norm equal
    to the tensor's norm, stream mutation/perturb_match) is scaled so the model's VALIDATION damage matches the
    budget parent removal's frozen joint deletion.
    v36: the matched quantity is declared (continue.perturb_match_metric): val_err (the error rate, which stops at
    chance: when the deletion is already near chance a random perturbation may never reach it) or val_risk (the task
    risk, cross-entropy for classification, which has no ceiling).  Both are recorded at the chosen scale.
    v34: the estimand is declared (continue.perturb_estimand): 'absolute' targets the deleted parent's value itself;
    'increment' targets this model's unperturbed value plus the deletion's increase over its intact model.  The
    scale is bracketed (doubling from 0.25 up to 64) and bisected on the crossing (below the target at lo, at or
    above it at hi); the closer end of the final bracket is used.  The job is invalid (status invalid, recorded in
    perturb_match.json with the weights restored) when the target is not above the unperturbed value, when it is
    not reached by scale 64, or when the achieved value is farther than the tolerance from it (val_err:
    max(perturb_match_tol, 1 / n_val); val_risk: perturb_match_tol).  These three are the control's DECLARED
    outcomes (audit_v5/tools/audit_common.declared_invalid): the analyses list such a job as an exclusion.
    The damage is not monotone in the scale: the crossing found is one crossing, not the only one."""
    from ..train.trainer import evaluate
    pj = ctx.parent_json(cc["budget_parent"], "dissipation_result.json")
    fws = pj.get("frozen_weight_sweep") or {}
    metric = cc.get("perturb_match_metric", "val_err")
    key = "err" if metric == "val_err" else "risk"
    try:
        del_v = float(fws["joint_deletion"]["val"][key])
        intact_v = float(fws["intact"]["val"][key])
    except (KeyError, TypeError):
        raise ScientificInvalid(f"perturb_match: the parent removal has no frozen joint-deletion / intact validation "
                                f"{key}", {"budget_parent": cc["budget_parent"]})
    gen = torch_gen(seed_of(cfg, "mutation"), "mutation", "perturb_match")
    ps = [p for p in model.parameters() if p.requires_grad and p.numel() > 0]
    base = [p.detach().clone() for p in ps]
    dirs = []
    for p in ps:
        n = torch.randn(p.shape, generator=gen, dtype=torch.float64).to(p.device, p.dtype)
        nn_ = float(n.double().norm())
        dirs.append(n * (float(p.detach().double().norm()) / nn_) if nn_ > 0 else torch.zeros_like(p))
    batch = cfg["train"]["eval_batch"]
    n_val = len(bundle.val)
    seen = {}

    def val_at(rel):
        for p, b0, dd in zip(ps, base, dirs):
            p.copy_(b0 + rel * dd)
        r, _ = evaluate(model, bundle, ["val"], batch)
        model.train()
        seen[rel] = {"val_err": 1.0 - float(r["val"]["acc"]) if "acc" in r["val"] else None,
                     "val_risk": float(M.headline(r["val"], bundle.task))}
        return seen[rel][metric]
    e0 = val_at(0.0)
    est = cc.get("perturb_estimand", "absolute")
    target = del_v if est == "absolute" else e0 + (del_v - intact_v)
    tol = float(cc.get("perturb_match_tol", 0.005))
    if metric == "val_err":
        tol = max(tol, 1.0 / max(1, n_val))
    rec = {"source": cc["perturb_match"], "metric": metric, "estimand": est, "partition": "val", "n_val": int(n_val),
           "parent_intact_value": intact_v, "parent_deleted_value": del_v, "parent_deletion_increment": del_v - intact_v,
           "unperturbed_value": e0, "target_value": target, f"target_{metric}": target, "tolerance": tol,
           "unperturbed": dict(seen[0.0]), "segment": int(cc.get("perturb_segment", 1)),
           "note": f"matched on the immediate validation {key} only; not an equivalent of deletion in any other sense"}
    if metric == "val_err":
        rec["unperturbed_val_err"] = e0

    def invalid(why, **kw):
        for p, b0 in zip(ps, base):
            p.copy_(b0)
        rec.update({"failure": why, **kw})
        ctx.save_json("perturb_match.json", rec)
        raise ScientificInvalid(f"perturb_match: {why}", rec)
    if not target > e0:
        invalid("the target is not above the unperturbed value (nothing to match)")
    lo, hi = 0.0, 0.25
    trace = []
    while True:
        v_hi = val_at(hi)
        trace.append({"scale": hi, **seen[hi]})
        if v_hi >= target:
            break
        if hi >= 64.0:
            invalid("the target is not reached by scale 64 (unreachable)", bracket_trace=trace)
        lo, hi = hi, hi * 2
    for _ in range(30):
        mid = 0.5 * (lo + hi)
        if val_at(mid) >= target:
            hi = mid
        else:
            lo = mid
    v_lo, v_hi = val_at(lo), val_at(hi)
    pick = lo if abs(v_lo - target) < abs(v_hi - target) else hi
    achieved = val_at(pick)                          # leaves the model at the chosen scale
    rec.update({"bracket_trace": trace, "bracket": [lo, hi], "bracket_values": [v_lo, v_hi],
                "relative_scale": pick, "achieved_value": achieved, f"achieved_{metric}": achieved,
                "achieved": dict(seen[pick]), "abs_error_to_target": abs(achieved - target)})
    if metric == "val_err":
        rec["achieved_val_err"] = achieved
    if abs(achieved - target) > tol:
        invalid("the achieved value is not within tolerance of the target")
    ctx.save_json("perturb_match.json", rec)
    return rec


def run_continue(ctx) -> dict:
    cfg = ctx.cfg
    cc = cfg["continue"]
    bundle = C.setup_data(ctx)
    ck = ctx.parent_ckpt(cc["start"], cc["start_stage"])
    model = GraphNet.from_checkpoint(ck["model"], ctx.device)
    if model.implants and cc["arm"] != "plain":
        raise Unsupported("control arms continue a compact (implant-free) model")
    arch0 = architecture_hash(model)
    reinit_info = None
    if cc["reinit"]:
        trained = {k: v.detach().clone() for k, v in model.state_dict().items()}
        C.reinit_all(model, torch_gen(seed_of(cfg, "init"), "init", "continue_reinit"))
        reinit_info = _finish_reinit(ctx, model, bundle, arch0)
        # v13 audit of the scratch control: no trained floating tensor may survive the reset; quantiser
        # clipping / occupancy and per-module gradients right after re-initialisation and calibration
        after = model.state_dict()
        reinit_info["unchanged_after_reset"] = sorted(
            k for k, v in trained.items() if k in after and v.is_floating_point() and v.numel() > 0
            and torch.equal(v.to(after[k].device), after[k]))
        codes0 = {}
        reinit_info["quantizers_at_start"] = quantizer_audit(model, bundle, keep_codes=codes0)
        if codes0 and not (ctx.dir / "quant_codes_start.pt").exists():
            torch.save(codes0, ctx.dir / "quant_codes_start.pt")     # resume-safe reference for code drift
        reinit_info["gradients_at_start"] = gradient_audit(model, bundle, ste_margin=cfg["train"].get("quant_ste_margin", 0.0))
    tr = C.make_trainer(ctx, model, bundle, "main")
    st_tr = ck.get("trainer")
    if st_tr is None and isinstance(ck.get("extra"), dict):
        st_tr = ck["extra"].get("trainer")
    inherit = st_tr is not None and not cc["reinit"] and cc["inherit_state"]
    if inherit:
        tr.load_state_dict(st_tr)                        # same streams / optimizer state as the treated history
    g_start = int(tr.state["global_step"])
    m_start = int(tr.state.get("train_macs", 0))
    if cc.get("fork_audit") and not cfg["train"].get("audit_batches", False):   # v45: else the trainer audits
        # v43: the compact fork audit.  The ordered stream of training-example ids as a hash chain in the trainer
        # state (resume-safe), and at every fresh segment start, before its optimizer rule applies, the model, the
        # optimizer state by parameter name, the sampler and the RNG states (compact arms that share a prefix must
        # agree there, and draw the same minibatches after it)
        import hashlib as _hl
        bundle.train.aux["_index"] = torch.arange(len(bundle.train), device=bundle.train.y.device)
        _nb = tr.next_batch

        def _nb_hashed():
            b_ = _nb()
            ids = b_.aux.get("_index")
            if ids is not None:
                tr.state["batch_id_hash"] = _hl.sha256(str(tr.state.get("batch_id_hash", "")).encode()
                                                       + ids.detach().cpu().numpy().tobytes()).hexdigest()[:24]
                tr.state["batches_drawn"] = int(tr.state.get("batches_drawn", 0)) + 1
            return b_
        tr.next_batch = _nb_hashed
    tr.state["train_macs"], tr.state["train_macs_bwd"], tr.state["teacher_macs"] = 0, 0, 0
    tr.state["mac_parts"] = {k_: 0 for k_ in MAC_PARTS}     # v45: counted from the start of the continuation
    tr.curves = []
    # ---- budget
    T = C.seq_T(bundle)
    if cc["budget"] == "fixed":
        total = int(cc["updates"]) if int(cc["updates"]) else sum(cc["segments"])
        basis = "fixed updates"
    else:
        w = chain_work(ctx, cc["budget_parent"])
        if cc.get("budget_add_f0"):
            # endpoint-matched controls train a RE-INITIALISED endpoint architecture: they also get the
            # training f0 received, so their exposure equals the treated chain's total exposure
            f0s = ctx.parent_ckpt("baseline", "baseline")["trainer"]["state"]
            w = dict(w)
            w["updates"] += int(f0s["global_step"])
            w["examples"] += int(f0s["examples"])
            w["macs"] += int(f0s.get("train_macs", 0))
            w["f0_added"] = {"updates": int(f0s["global_step"]), "macs": int(f0s.get("train_macs", 0))}
        if cc["budget"] == "parent_updates":
            total, basis = int(w["updates"]), "parent chain's measured updates"
        else:
            per = 3 * forward_macs(model, T, {}) * tr.B
            total = int(math.ceil((w["macs"] + w["teacher_macs"]) / max(1, per)))
            basis = ("parent chain's estimated dense training MACs plus teacher forward MACs / "
                     "(3 x forward MACs x batch) of this architecture, rounded up")
        bj = {"parent_chain_work": w, "updates": total, "basis": basis,
              "parent_compute_complete": bool(w.get("macs_complete", True))}
        if cc["budget"] == "parent_compute":
            bj["target_macs"] = int(w["macs"] + w["teacher_macs"])
            bj["planned_macs"] = int(total * per)
            bj["overshoot_macs"] = int(total * per - bj["target_macs"])     # from rounding up (V3-09)
            if not w.get("macs_complete", True):
                raise Unsupported("parent_compute needs a parent chain whose every phase has a MAC estimate")
        ctx.save_json("budget.json", bj)
    segs = _segments(cc, total)
    teacher = None
    if cc["arm"] in ("distill", "self_distill"):
        tk = ctx.parent_ckpt(cc["teacher"], cc["teacher_stage"])
        teacher = GraphNet.from_checkpoint(tk["model"], ctx.device).eval()
        for p in teacher.parameters():
            p.requires_grad_(False)
    pr = _PruneRegrow(model, float(cc["prune_frac"]), int(cc["prune_period"]), int(cc["prune_duration"]),
                      seed_of(cfg, "init")) if cc["arm"] == "prune_regrow" else None
    etd, etd_native = None, None
    if cc["arm"] == "example_tied_dropout":
        # v22: segment 0 trains with example-tied dropout, segment 1 starts by dropping the memorization neurons
        # (native test-time function, recorded) and repairs the plain network without masks
        if len(segs) != 2:
            raise Unsupported("example_tied_dropout needs two segments: the dropout phase and the repair")
        if cfg["train"].get("stream") == "fresh":
            raise Unsupported("example_tied_dropout needs a fixed training set (example identities)")
        etd = _ExampleTiedDropout(model, len(bundle.train), cc["etd_p_gen"], cc["etd_p_mem"], seed_of(cfg, "init"))
        bundle.train.aux["_index"] = torch.arange(len(bundle.train), device=bundle.train.y.device)
    if pr is not None and not pr.layers:
        raise Unsupported("prune_regrow needs hidden linear / conv layers")
    eval_at = sorted(set(int(u) for u in cc["eval_at"] if 0 < int(u) <= total) |
                     {int(round(total * (i + 1) / max(1, cc["eval_points"]))) for i in range(cc["eval_points"])})
    done_marks = set()
    # v13: validation-selection candidates over the whole continuation (the model is compact throughout);
    # the start state (u = 0) is not a candidate, so f0 is never selected inside one arm only
    sel = C.Selector(ctx, bundle, "continue")
    sel_pts = set(sel.points(total)) if sel.enabled else set()
    if etd is not None and sel.enabled:
        # v23: the candidates are spread over the REPAIR phase only (as in the removal jobs' compact phase): the
        # same number of candidates, offsets k > 0 from the drop, the last one the final update
        sel_pts = etd_selection_points(segs, sel.k)
    etd_path, etd_ref_val = [], None
    early = sorted({int(k_) for k_ in (cc.get("repair_early_eval") or []) if 0 < int(k_) <= int(segs[-1])}) \
        if etd is not None else []

    def etd_observe(trn, offset):
        """v23: the repaired model at an offset from the drop: val / test risk and error, and its agreement with
        the native dropped model at the drop (the reference 'native_at_drop')."""
        from ..train.trainer import evaluate
        r_, pr_ = evaluate(trn.model, bundle, ["val", "test"], cfg["train"]["eval_batch"], return_preds=True)
        o_v = pr_["val"].double().cpu()
        rec = {"offset_from_drop": int(offset), "update": int(segs[0]) + int(offset),
               "val_risk": M.headline(r_["val"], bundle.task), "test_risk": M.headline(r_["test"], bundle.task)
               if "test" in r_ else None, **({"val_err": 1.0 - r_["val"]["acc"]} if "acc" in r_["val"] else {}),
               **({"test_err": 1.0 - r_["test"]["acc"]} if "test" in r_ and "acc" in r_["test"] else {})}
        if etd_ref_val is not None:
            rec["val_rms_drift_from_native_at_drop"] = float(((o_v - etd_ref_val) ** 2).mean().sqrt())
            if bundle.task == "classification" and o_v.dim() == 2:
                lp_r, lp_m = torch.log_softmax(etd_ref_val, -1), torch.log_softmax(o_v, -1)
                rec["val_flip_rate_from_native_at_drop"] = float((o_v.argmax(-1) != etd_ref_val.argmax(-1))
                                                                 .double().mean())
                rec["val_tv_from_native_at_drop"] = float(0.5 * (lp_r.exp() - lp_m.exp()).abs().sum(-1).mean())
                rec["val_kl_native_at_drop_to_model"] = float((lp_r.exp() * (lp_r - lp_m)).sum(-1).mean())
        trn.model.train()
        return rec

    def maybe_select(trn, u):
        if etd is not None and etd.mode == "etd":
            return            # a masked state is never a candidate: its checkpoint would not carry the masks
        if u in sel_pts:
            sel.consider(trn.model, trn.state["global_step"], u, f"continue@{u}", trn)
            trn.model.train()

    def maybe_eval(trn, u):
        if u in eval_at and u not in done_marks:
            done_marks.add(u)
            ctx.updates, ctx.examples = u, trn.state["examples"]
            C.eval_log(ctx, trn.model, bundle, f"at_{u}")
            if cc.get("save_eval_checkpoints"):
                ex_ = {"update": int(u)}
                if trn.state.get("update_norms") is not None:       # v43: the cumulative path length so far
                    ex_["update_norms"] = copy.deepcopy(trn.state["update_norms"])
                ex_["compute"] = compute_counters(trn.state)            # v45: the training counters so far
                ctx.save_ckpt(f"at_{u}", trn.model, None, ex_)   # v31: trace checkpoints
            trn.model.train()

    resumed = ctx.has_ckpt("partial")
    k0 = 0
    if resumed:
        pk = ctx.load_ckpt("partial")
        model = GraphNet.from_checkpoint(pk["model"], ctx.device)
        tr.model = model
        tr.load_state_dict(pk["trainer"])
        k0 = int(pk["extra"]["segment_index"])
        done_marks |= set(pk["extra"].get("done_marks", []))
        etd_path = list(pk["extra"].get("etd_path") or [])
        if pr is not None:
            pr.events = list(pk["extra"].get("prune_events", []))
            pr.masks = {k_: torch.tensor(v) for k_, v in (pk["extra"].get("prune_masks") or {}).items()}
    tcfg0 = dict(tr.t)
    if etd is not None and resumed and k0 >= 1 and ctx.has_ckpt("etd_native"):
        etd_native = (ctx.load_ckpt("etd_native").get("extra") or {}).get("etd_native")
        nat_m = GraphNet.from_checkpoint(ctx.load_ckpt("etd_native")["model"], ctx.device)
        etd_ref_val = predict(nat_m, bundle.partitions()["val"], cfg["train"]["eval_batch"]).double().cpu()
        del nat_m
    for si in range(k0, len(segs)):
        n = segs[si]
        base_u = sum(segs[:si])
        fresh_seg = not (resumed and si == k0)
        if etd is not None:
            if si == 0:
                etd.set_mode(tr.model, "etd")
            else:
                etd.set_mode(tr.model, "off")
                if fresh_seg:
                    # the drop: native test-time function of the dropout model, made permanent and checked
                    etd.set_mode(tr.model, "etd")
                    with torch.no_grad():
                        o_mask = {p_: predict(tr.model, part, cfg["train"]["eval_batch"]).double().cpu()
                                  for p_, part in bundle.partitions().items() if p_ in ("val", "test")}
                    etd.set_mode(tr.model, "off")
                    info = etd.drop(tr.model)
                    with torch.no_grad():
                        dmax = max(float((predict(tr.model, part, cfg["train"]["eval_batch"]).double().cpu()
                                          - o_mask[p_]).abs().max()) for p_, part in bundle.partitions().items()
                                   if p_ in o_mask)
                    scale = max(1.0, max(float(v.abs().max()) for v in o_mask.values()))
                    if not dmax <= 1e-4 * scale:
                        raise ScientificInvalid("example-tied dropout: the dropped network does not reproduce the "
                                                "test-time masked function", {"max_abs_diff": dmax})
                    ctx.updates, ctx.examples = base_u, tr.state["examples"]
                    res_n, _ = C.eval_log(ctx, tr.model, bundle, "etd_native")
                    etd_native = {**info, "max_abs_diff_masked_vs_dropped": dmax, "at_update": base_u,
                                  "phase_cost": {"updates": int(base_u), "train_macs": int(tr.state.get("train_macs", 0)),
                                                 "train_macs_bwd": int(tr.state.get("train_macs_bwd", 0)),
                                                 "note": "this job's dropout phase only (f0 is charged separately "
                                                         "when the job starts from it)"},
                                  "metrics": {p_: {k_: v_ for k_, v_ in m_.items() if isinstance(v_, (int, float))}
                                              for p_, m_ in res_n.items()},
                                  "endpoint_semantics": "native test-time function: generalization neurons only "
                                                        "(memorization neurons' outgoing weights zeroed)"}
                    ctx.save_ckpt("etd_native", tr.model, None, {"etd_native": etd_native})
                    # v23: a reloadable endpoint record with saved predictions (fresh reload checks it)
                    C.record_endpoint(ctx, bundle, "etd_native", False, None, name="endpoint_etd_native",
                                      extra={"semantics": etd_native["endpoint_semantics"]})
                    etd_ref_val = o_mask["val"] if "val" in o_mask else None
                    etd_path = [etd_observe(tr, 0)]
                    tr.model.train()
        if fresh_seg:
            reset = cc["arm"] == "opt_reset" or not inherit       # opt_reset: at every segment start
            if etd is not None and si == 1:
                reset = True             # the repair starts with a fresh optimizer, as the removal phases do
            sr = cc.get("segment_reset") or []
            if sr:
                # v25: the declared phase boundaries of a treated history (C1_phase); segment 0 without a reset
                # continues the start checkpoint's optimizer state only when that state was inherited
                reset = bool(sr[si]) or (si == 0 and not inherit)
            if cc["arm"] == "perturb":
                _perturb(model, float(cc["perturb_rel"]), torch_gen(seed_of(cfg, "mutation"), "mutation",
                                                                    "perturb", str(si)))
            if cc.get("perturb_match", "none") != "none" and si == int(cc.get("perturb_segment", 1)):
                _perturb_matched(ctx, cfg, cc, tr.model, bundle)
            fa_rec = _fork_point(tr, si, base_u) if cc.get("fork_audit") else None
            # v34: a declared segment_reset is explicit in both directions (False carries the state even when
            # train.opt_state_on_edit is reset); without one, the arm's rule (True, or the global setting)
            tr.configure("none", None, reset_state=bool(reset) if sr else (True if reset else None))
            if fa_rec is not None:
                fa_rec["reset_applied"] = bool(reset)
                fa_rec["opt_tensors_with_state_after_configure"] = sum(1 for v in tr.opt.state.values() if v)
                tr.state.setdefault("fork_audit_starts", []).append(fa_rec)
        if cc["arm"] == "lr_restart":
            tr.t = dict(tcfg0, lr_schedule="cosine", warmup=int(cc["restart_warmup"]))
        alpha = float(cc["distill_alpha"])

        star = cfg["train"].get("target", "task") == "teacher_star"

        def tfn(out, batch, X, alpha=alpha):
            with torch.no_grad():
                t_out = teacher(X)
            ld = distill_loss(out, t_out, bundle.task, cfg["train"]["distill_temperature"], batch.y)
            if alpha >= 1:
                return ld
            # the task term follows the target regime: T0 trains toward the known teacher, not the labels
            lt = teacher_star_loss(out, batch, X, bundle, cfg["train"]["distill_temperature"]) if star else \
                task_loss(out, batch.y, bundle.task)
            return alpha * ld + (1 - alpha) * lt

        def on_step(trn, k, base_u=base_u, si=si):
            if pr is not None:
                pr(trn, base_u + k)
            if etd is not None and si == 1 and k in early and not any(e_["offset_from_drop"] == k for e_ in etd_path):
                etd_path.append(etd_observe(trn, k))       # dense early repair observations
            maybe_eval(trn, base_u + k)
            if k > 0:
                maybe_select(trn, base_u + k)
        def post_step(trn, k, base_u=base_u):
            if pr is not None:
                pr.post_step(trn, base_u + k)
        tscope = None
        if cc.get("trainable_scope", "full") != "full":
            # v29: only the declared layers of the compact network learn (the optimizer still covers every tensor)
            from .dissipation import scope_pkeys
            if any(imp.nodes for imp in tr.model.implants.values()):
                raise Unsupported("continue.trainable_scope needs a compact start model")
            tscope = scope_pkeys(tr.model, cc["trainable_scope"])
        seg = Segment(f"cont_{si}", n, on_step=on_step, post_step=post_step, trainable=tscope,
                      target="custom" if teacher is not None else "task", target_fn=tfn if teacher is not None
                      else None, batch_ctx=etd.batch_ctx if (etd is not None and etd.mode == "etd") else None)
        fsg = cc.get("freeze_segments") or []
        if fsg:
            # v43/v44: this segment's declared freezes (a frozen prefix of the job's train freezes)
            seg.freeze_inputs = cfg["train"]["freeze_inputs"] if fsg[si] else "none"
            seg.freeze_backbone = cfg["train"].get("freeze_backbone", "none") if fsg[si] else "none"

        def cb(si=si):
            ctx.save_ckpt("partial", tr.model, tr, {"segment_index": si, "done_marks": sorted(done_marks),
                                                     "etd_path": list(etd_path),
                                                     "prune_events": pr.events if pr else [],
                                                     "prune_masks": {k_: v.tolist() for k_, v in pr.masks.items()}
                                                     if pr else {}})
        r_seg = tr.run(seg, checkpoint_cb=cb)
        maybe_select(tr, base_u + int(r_seg["updates"]))     # the state at the end of the segment
    maybe_eval(tr, total)
    if etd is not None and not any(e_["offset_from_drop"] == int(segs[1]) for e_ in etd_path):
        etd_path.append(etd_observe(tr, int(segs[1])))
    model = tr.model
    done_u = int(tr.state["global_step"]) - g_start
    # one teacher forward per training example actually seen (resume-safe: from the trainer's counters)
    teacher_fwd = done_u * tr.B if teacher is not None else 0
    t_macs = (forward_macs(teacher, T, {}) * teacher_fwd) if teacher is not None else 0
    ctx.count_work("continue", updates=done_u, examples=done_u * tr.B, seconds=tr.timing["train_seconds"],
                   macs=int(tr.state.get("train_macs", 0)), macs_bwd=int(tr.state.get("train_macs_bwd", 0)), teacher_macs=int(t_macs))
    if teacher is not None:
        ctx.count_work("teacher_forward", forward_examples=teacher_fwd)
    ctx.updates, ctx.examples = done_u, done_u * tr.B
    res, _ = C.eval_log(ctx, model, bundle, "final", save_preds=True)
    er = acct_report(model, T)
    gh = model.structural_hash()
    for k_ in ("params", "macs", "param_bytes_fp32", "buffer_bytes", "activation_values_per_example"):
        ctx.metric("final", "none", f"export_{k_}", er.get(k_), gh)
    ctx.metric("final", "none", "export_architecture_equals_start", int(architecture_hash(model) == arch0), gh)
    ctx.save_ckpt("final", model, tr)
    ctx.ckpt_path("partial").unlink(missing_ok=True)
    C.record_endpoint(ctx, bundle, "final", bool(tr.state.get("diverged")), tr.state.get("diverged_reason"),
                      {"start_architecture_hash": arch0})
    if reinit_info is not None and any(model.nodes[q].op == "quant" for q in model.live_nodes()):
        ref = torch.load(ctx.dir / "quant_codes_start.pt") if (ctx.dir / "quant_codes_start.pt").exists() else None
        reinit_info["quantizers_at_end"] = quantizer_audit(model, bundle, ref_codes=ref)
        reinit_info["gradients_at_end"] = gradient_audit(model, bundle, ste_margin=cfg["train"].get("quant_ste_margin", 0.0))
        if ctx.has_ckpt("best_val"):
            msel = GraphNet.from_checkpoint(ctx.load_ckpt("best_val")["model"], ctx.device)
            reinit_info["quantizers_at_selected"] = quantizer_audit(msel, bundle, ref_codes=ref)
            reinit_info["gradients_at_selected"] = gradient_audit(msel, bundle, ste_margin=cfg["train"].get("quant_ste_margin", 0.0))
        reinit_info["quant_recipe"] = {"recipe": quant_recipe_name(cfg["train"]),
                                       "warmup_updates": int(cfg["train"].get("quant_warmup_updates", 0) or 0),
                                       "warmup_calibrated_at": tr.state.get("quant_events")}
    # v13 (audit B3 / D2): later-query retention of a control endpoint with pegs (mechanism E), measured with
    # the same training-code decoders as the treated chain
    lq = None
    peg_ids = [i for i, imp in model.implants.items() if "peg" in (imp.meta or {})]
    if "later" in bundle.train.aux and peg_ids:
        from ..cop_pegs.chain import later_queries
        lq = later_queries(ctx, model, bundle, peg_ids, checkpoint="final")
    sel.record(bundle, bool(tr.state.get("diverged")), tr.state.get("diverged_reason"), tr.state.get("diverged_at"))
    # v17: the same readouts at the validation-selected checkpoint, labelled, so no readout's checkpoint is implicit
    lq_sel = None
    if lq is not None and ctx.has_ckpt("best_val"):
        from ..cop_pegs.chain import later_queries
        msel = GraphNet.from_checkpoint(ctx.load_ckpt("best_val")["model"], ctx.device)
        pids = [i for i, imp in msel.implants.items() if "peg" in (imp.meta or {})]
        if pids:
            lq_sel = later_queries(ctx, msel, bundle, pids, stage="later_queries_best_val", checkpoint="best_val")
    out = {"arm": cc["arm"], "start": cc["start"], "start_stage": cc["start_stage"], "updates": done_u,
           "requested_updates": total, "segments": segs, "budget_basis": cc["budget"], "eval_at": eval_at,
           "segment_reset": list(cc.get("segment_reset") or []) or None,
           "freeze_segments": list(cc.get("freeze_segments") or []) or None,
           "fork_audit": ({"starts": tr.state.get("fork_audit_starts", []),
                           "batch_id_hash_end": tr.state.get("batch_id_hash"),
                           "batches_drawn_end": tr.state.get("batches_drawn"),
                           "updates": int(tr.state["global_step"]) - g_start} if cc.get("fork_audit") else None),
           "trainable_scope": cc.get("trainable_scope", "full"),
           "compute_end": compute_counters(tr.state),     # v45: counted from the start of the continuation
           "perturb_match": (json.load(open(ctx.dir / "perturb_match.json")) if (ctx.dir / "perturb_match.json").exists()
                             else None),
           "diverged": bool(tr.state.get("diverged")), "teacher_forward_examples": teacher_fwd,
           "final": {p: {k: v for k, v in m.items() if isinstance(v, (int, float))} for p, m in res.items()},
           "prune_events": pr.events if pr else None, "start_global_step": g_start,
           "example_tied_dropout": ({**etd.info(), "native": etd_native, "repair_path": etd_path,
                                     "phase_updates": {"dropout_phase": int(segs[0]), "removal_transition": 0,
                                                       "post_removal_repair": int(segs[1])},
                                     "repair_semantics": "drop and regrow: after the drop every parameter trains "
                                                         "without masks, so the zeroed columns can become nonzero",
                                     "selection": "candidates spread over the repair phase only"}
                                    if etd is not None else None),
           "start_train_macs": m_start, "inherited_state": inherit, "reinit": reinit_info,
           "later_queries": lq, "later_queries_selected": lq_sel,
           "quant_recipe": (reinit_info or {}).get("quant_recipe") or (
               {"recipe": quant_recipe_name(cfg["train"]),
                "warmup_updates": int(cfg["train"].get("quant_warmup_updates", 0) or 0)}
               if any(model.nodes[q].op == "quant" for q in model.live_nodes()) else None)}
    ctx.save_json("continue_result.json", out)
    return {k: v for k, v in out.items() if k not in ("final", "prune_events")}
