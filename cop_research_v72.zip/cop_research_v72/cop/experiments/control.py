"""Wave 0 control job: exactness and engineering checks on a real model/data
configuration and device (CPU or GPU).  Each check returns a record with the
measured errors, the tolerance applied, the dtype and a pass/fail flag.
"""
from __future__ import annotations

import copy
import itertools

import torch

from ..config import seed_of
from ..graph import edits as E
from ..graph.export import export_compact
from ..graph.graph import GraphNet, InvalidDeletion
from ..train import metrics as M
from ..train.trainer import Segment, Trainer
from ..utils import torch_gen
from . import common as C
from .context import ScientificInvalid
from .growth import insert_residual_peg


def _constructions(g: GraphNet, gen_for):
    """(name, function(graph) -> implant ids) for every construction applicable to g."""
    L = g.layout
    kind = {"mlp": "post_act", "cnn": "post_act", "resnet": "block_out", "transformer": "resid",
            "gru": "gru_out"}[g.family]
    out = []
    cut = lambda h, **kw: E.cut_at(h, kind, "middle", **kw)
    out.append(("A_residual_zero", lambda h: [E.insert_residual_zero(h, cut(h), gen_for("A"), width=8)]))
    out.append(("A_residual_zero_channels4", lambda h: [E.insert_residual_zero(h, cut(h, channels=[0, 1, 2, 3]),
                                                                               gen_for("Ach"), width=4)]))
    if L in ("seq", "img"):
        pos = {"last": 1} if L == "seq" else {"region": [0, 4, 0, 4]}
        out.append(("A_residual_zero_positions", lambda h: [E.insert_residual_zero(h, cut(h, positions=pos),
                                                                                   gen_for("Apos"), width=4)]))
    out.append(("B_linear_factor_orth", lambda h: [E.insert_linear_factor(h, cut(h), gen_for("B"),
                                                                          width=h.node_dim(cut(h).source) + 4)]))
    out.append(("B_linear_factor_inv", lambda h: [E.insert_linear_factor(h, cut(h), gen_for("Bi"), mode="invertible")]))
    segs = g.meta.get("segments", [])
    if segs:
        seg = segs[len(segs) // 2]["nodes"]
        out.append(("C_dup_untied", lambda h: list(E.insert_dup_branch(h, seg, gen_for("C"), tied=False))))
        out.append(("C_dup_tied", lambda h: list(E.insert_dup_branch(h, seg, gen_for("Ct"), tied=True))))
        out.append(("C_dup_split0.3", lambda h: list(E.insert_dup_branch(h, seg, gen_for("Cs"), split=0.3))))
    out.append(("D_cancel_untied", lambda h: list(E.insert_cancel_pair(h, cut(h), gen_for("D"), width=8))))
    out.append(("D_cancel_tied", lambda h: list(E.insert_cancel_pair(h, cut(h), gen_for("Dt"), width=8, tied=True))))
    for kind_, tie in itertools.product(("coupling", "linear"), ("enforced", "untied")):
        out.append((f"E_inverse_{kind_}_{tie}", lambda h, k=kind_, t=tie: list(
            E.insert_inverse_pair(h, cut(h), gen_for(f"E{k}{t}"), kind=k, tie=t, width=8))))
    out.append(("F_concat_expand", lambda h: [E.insert_concat_expand(h, cut(h), gen_for("F"), width=6)]))
    for merge in ("sum", "concat", "route"):
        def grp(h, merge=merge):
            G = E.insert_group(h, cut(h), gen_for(f"G{merge}"), merge=merge)
            return [G] + [E.add_branch(h, G, gen_for(f"G{merge}{k}"), width=4) for k in range(2)]
        out.append((f"group_{merge}", grp))
    out.append(("peg_residual_k4", lambda h: [insert_residual_peg(h, cut(h), gen_for("P"), 8, "relu", 4)]))
    lins = [n for s in segs for n in s["nodes"] if g.nodes[n].op == "linear"]
    if lins:
        out.append(("node_factorization", lambda h: [E.factorize_node(h, lins[0], gen_for("NF"))]))
    if g.layout == "vec":
        def bridge(h):
            c = cut(h)
            c.branch_source = h.inputs["x"]
            return [E.insert_bridge(h, c, gen_for("BR"), width=6)]
        out.append(("bridge_from_input", bridge))

    def nested(h):
        i1 = E.insert_residual_zero(h, cut(h), gen_for("N1"), width=8)
        i2 = E.insert_residual_zero(h, E.implant_cut(h, i1, "hidden"), gen_for("N2"), width=4)
        i3 = E.insert_residual_zero(h, E.implant_cut(h, i1, "skip"), gen_for("N3"), width=4)
        return [i1, i2, i3]
    out.append(("nested_recursive", nested))
    return out


def run_control(ctx) -> dict:
    cfg = ctx.cfg
    if not str(ctx.device).startswith(cfg["control"]["device"]):
        raise RuntimeError(f"control job certifies device {cfg['control']['device']} but runs on {ctx.device}")
    bundle = C.setup_data(ctx)
    checks = cfg["control"]["checks"]
    results = {"device": ctx.device, "records": []}
    gen_for = lambda k: torch_gen(seed_of(cfg, "insertion"), "insertion", "control", k)
    base = C.new_model(dict(cfg, train={"precision": "fp32"}), bundle, ctx.device)
    sets = C.calib_sets(bundle, cfg["eval"]["calib_size"], cfg["eval"]["stress_scale"])
    # briefly train the base so BN statistics and weights are non-trivial
    tr = Trainer(base, bundle, {**_tc(), "batch_size": 64}, {"minibatch": 0, "augmentation": 0}, ctx.device)
    tr.configure("none", None)
    tr.run(Segment("warm", 20))
    for dt_name in cfg["control"]["dtypes"]:
        dt = torch.float64 if dt_name == "float64" else torch.float32
        tol = C.identity_tolerance(cfg, dt)
        for mode in ("eval", "train"):
            if "insertions" not in checks:
                break
            for name, fn in _constructions(base, gen_for):
                g = base.clone(share_params=False).to(dtype=dt)
                g.train(mode == "train")
                sets_dt = {k: {kk: (vv.to(dt) if vv.is_floating_point() else vv) for kk, vv in s.items()}
                           for k, s in sets.items()}
                with torch.no_grad():
                    before = {k: g(X) for k, X in sets_dt.items()}
                pre = g.clone(share_params=False)
                try:
                    ids = fn(g)
                except Exception as ex:
                    results["records"].append({"check": "insertion", "construction": name, "dtype": dt_name,
                                               "mode": mode, "status": "unsupported", "reason": repr(ex)})
                    continue
                g.train(mode == "train")
                with torch.no_grad():
                    after = {k: g(X) for k, X in sets_dt.items()}
                eq = {k: M.equivalence(before[k], after[k]) for k in before}
                ident = [g.implants[i].identity for i in ids if i in g.implants]
                chk = C.identity_check(pre, g, sets, dt, cfg, train_mode=(mode == "train"))
                ok = chk["verdict"] == "exact"
                rec = {"check": "insertion", "construction": name, "dtype": dt_name, "mode": mode,
                       "identity_guarantee": ident, "tolerance_rel": chk["tolerance_high_precision"],
                       "edit_roundoff_max_rel": chk["edit_roundoff_max_rel"],
                       "observed_max_rel": chk["observed_max_rel"], "identity_verdict": chk["verdict"],
                       "preexisting_instability_sets": chk["preexisting_instability_sets"],
                       "identity_check": chk["sets"], "pass": ok,
                       **{f"{k}.max_rel": v["max_rel"] for k, v in eq.items()},
                       **{f"{k}.max_abs": v["max_abs"] for k, v in eq.items()}}
                if not ok and chk["verdict"] != "changed":
                    rec["diagnostic"] = f"identity not established: {chk['verdict']}"
                elif not ok:
                    has_bn = any(g.nodes[n].op == "bn" for n in g.live_nodes())
                    rec["diagnostic"] = ("train-mode BatchNorm uses batch statistics; equivalence in train mode "
                                         "holds only if the implant leaves BN inputs unchanged"
                                         if (mode == "train" and has_bn) else "outputs changed beyond tolerance")
                results["records"].append(rec)
                ctx.metric("control", "calibration", f"insertion[{name}|{dt_name}|{mode}].max_rel",
                           eq["calibration"]["max_rel"], pass_=ok)
    if "fold" in checks and base.layout == "vec":
        g = base.clone(share_params=False).double()
        X = {k: v.double() if v.is_floating_point() else v for k, v in sets["fresh"].items()}
        iid = E.insert_linear_factor(g, E.cut_at(g, "post_act", "middle"), gen_for("fold"), width=g.node_dim(
            E.cut_at(g, "post_act", "middle").source) + 3)
        with torch.no_grad():
            y = g(X)
            h = E.fold_implant(g, iid)
            yf = h(X)
            exp, rep = export_compact(h, X)
        results["records"].append({"check": "fold_linear_chain", "max_abs": (y - yf).abs().max().item(),
                                   "export_max_abs": rep["max_abs_err"], "pass": (y - yf).abs().max().item() < 1e-10})
    if "deletion_pair" in checks:
        g = base.clone(share_params=False).double().eval()
        X = {k: v.double() if v.is_floating_point() else v for k, v in sets["fresh"].items()}
        kind = {"mlp": "post_act", "cnn": "post_act", "resnet": "block_out", "transformer": "resid",
                "gru": "gru_out"}[g.family]
        G, u, v = E.insert_cancel_pair(g, E.cut_at(g, kind, "middle"), gen_for("pair"), width=8)
        with torch.no_grad():
            y = g(X)
            du = (E.delete(g, [u])(X) - y).abs().max().item()
            dv = (E.delete(g, [v])(X) - y).abs().max().item()
            duv = (E.delete(g, [u, v])(X) - y).abs().max().item()
        results["records"].append({"check": "cancel_pair_deletion", "single_u": du, "single_v": dv, "pair": duv,
                                   "pass": du > 1e-6 and dv > 1e-6 and duv < 1e-10})
    if "stationary" in checks and bundle.task in ("regression", "classification"):
        results["records"] += stationary_checks(base, bundle, ctx.device)
    if "resume" in checks:
        results["records"].append(resume_check(base, bundle, ctx.device))
    if str(ctx.device).startswith("cuda"):
        g = base.clone(share_params=False).eval()
        with torch.no_grad():
            yg = g(sets["fresh"]).double().cpu()
            gc = g.to("cpu")
            yc = gc({k: v.cpu() for k, v in sets["fresh"].items()}).double()
        results["records"].append({"check": "cpu_vs_gpu_fp32", "max_abs": (yg - yc).abs().max().item(),
                                   "note": "TF32 disabled unless exec allow_tf32; not bitwise across devices"})
    n_fail = sum(1 for r in results["records"] if r.get("pass") is False)
    results["n_records"] = len(results["records"])
    results["n_fail"] = n_fail
    ctx.save_json("control_results.json", results)
    failed = [(r.get("check"), r.get("construction"), r.get("dtype"), r.get("mode"))
              for r in results["records"] if r.get("pass") is False]
    if n_fail:
        # a required control failed: the job is invalid and every wave gate depending on it stops
        raise ScientificInvalid(f"{n_fail} required control check(s) failed on {ctx.device}", {"failed": failed})
    n_unsup = sum(1 for r in results["records"] if r.get("status") == "unsupported")
    if n_unsup:
        ctx.unverified(f"{n_unsup} construction(s) not applicable to this model (see control_results.json)")
    return {"n_records": results["n_records"], "n_fail": 0, "n_unsupported": n_unsup}


def _tc(**kw):
    from ..config import TRAIN_DEFAULTS
    t = dict(TRAIN_DEFAULTS)
    t.update(kw)
    return t


def stationary_checks(base: GraphNet, bundle, device) -> list[dict]:
    """T09: self-distillation to the model's own outputs with MSE/KL is an exact
    zero-loss point: plain SGD (no momentum, no weight decay, no noise) leaves the
    parameters unchanged; inherited momentum or weight decay moves them."""
    out = []
    for name, tc, carry_momentum in (
            ("sgd_plain", _tc(optimizer="sgd", lr=0.1, momentum=0.0, weight_decay=0.0), False),
            ("sgd_inherited_momentum", _tc(optimizer="sgd", lr=0.1, momentum=0.9, weight_decay=0.0), True),
            ("sgd_weight_decay", _tc(optimizer="sgd", lr=0.1, momentum=0.0, weight_decay=0.1), False)):
        g = base.clone(share_params=False).double()
        teacher = g.clone(share_params=False).eval()
        b = bundle
        tr = Trainer(g, b, {**tc, "precision": "fp64", "batch_size": 64}, {"minibatch": 1, "augmentation": 1}, device)
        tr.configure("none", None)
        for m in g.mods.values():
            if isinstance(m, (torch.nn.BatchNorm1d, torch.nn.BatchNorm2d)):
                g.frozen_bn.add([k for k, v in g.mods.items() if v is m][0])
        if carry_momentum:
            for p in [p for gp in tr.opt.param_groups for p in gp["params"]]:
                tr.opt.state[p]["momentum_buffer"] = torch.randn_like(p) * 1e-3
        before = [p.detach().clone() for p in g.parameters()]
        # BN modules are in g.frozen_bn, so g.train() keeps them in eval mode (no statistic updates)
        def sq_err(out, batch, X, teacher=teacher):
            with torch.no_grad():
                t = teacher(X)
            return ((out - t) ** 2).mean()   # squared error: exact zero gradient at equality
        seg = Segment("stationary", 10, target="custom", target_fn=sq_err)
        tr.run(seg)
        moved = max((a - p.detach()).abs().max().item() for a, p in zip(before, g.parameters()))
        expect_static = name == "sgd_plain"
        out.append({"check": "stationary", "variant": name, "max_param_change": moved,
                    "expected": "static" if expect_static else "moves",
                    "pass": (moved == 0.0) if expect_static else (moved > 0.0)})
    return out


def resume_check(base: GraphNet, bundle, device, n: int = 40) -> dict:
    """T19: n updates uninterrupted == n/2 updates + checkpoint + restore + n/2."""
    tc = _tc(optimizer="adamw", lr=1e-3, batch_size=32)
    g1 = base.clone(share_params=False)
    t1 = Trainer(g1, bundle, tc, {"minibatch": 3, "augmentation": 3}, device)
    t1.configure("none", None)
    t1.run(Segment("s", n))
    g2 = base.clone(share_params=False)
    t2 = Trainer(g2, bundle, tc, {"minibatch": 3, "augmentation": 3}, device)
    t2.configure("none", None)
    t2.run(Segment("s", n // 2))
    ck_model = g2.checkpoint()
    ck_tr = copy.deepcopy(t2.state_dict())
    g3 = GraphNet.from_checkpoint(ck_model, device)
    t3 = Trainer(g3, bundle, tc, {"minibatch": 99, "augmentation": 99}, device)  # wrong seeds on purpose: state restores
    t3.load_state_dict(ck_tr)
    t3.run(Segment("s", n))
    diff = max((a - b).abs().max().item() for a, b in zip(g1.state_dict().values(), g3.state_dict().values())
               if a.is_floating_point())
    return {"check": "resume_equality", "max_abs_param_diff": diff, "updates_1": t1.state["global_step"],
            "updates_resumed": t3.state["global_step"], "pass": diff == 0.0 and t1.state["global_step"] ==
            t3.state["global_step"],
            "note": "bitwise on CPU; on GPU nondeterministic kernels may give small differences"}
