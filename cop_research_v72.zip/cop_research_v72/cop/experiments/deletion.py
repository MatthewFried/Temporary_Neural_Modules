"""R1: exhaustive and structured deletion at fixed remaining weights.

Atoms are implants with an allowed deletion (bypass / drop_term / fold).
Deleting an implant removes its descendants, so subsets are canonicalised
(descendants of deleted ancestors dropped) and the resulting graphs are
grouped by structural hash: two subsets that produce the same graph are one
intervention, never two.

Outputs per family member: task metrics on every evaluated partition
(complete finite domain when available), drift against the undeleted model,
parameters removed.  Certificates:
  best valid deletion  -- per criterion and tolerance, the valid deletion that
                          removes the most parameters (a reducibility witness
                          for that criterion);
  L2 certificate       -- only when the family is EXHAUSTIVE over all subsets
                          of the atoms and no non-empty subset satisfies the
                          criterion at that tolerance.  Scope: fixed remaining
                          weights, this deletion family, this evaluation
                          domain and precision.  It is not a statement about
                          other architectures or retrained models.
Group interaction J(A,B) = R(D_{A u B}) - R(D_A) - R(D_B) + R(f) is reported
for pairs of atoms with that sign convention.
"""
from __future__ import annotations

import itertools
import math
from typing import Optional

import torch

from ..graph import edits as E
from ..graph.accounting import count_params
from ..graph.graph import GraphNet, InvalidDeletion
from ..train import metrics as M
from ..train.trainer import evaluate
from ..utils import np_gen, atomic_write_json


def chain_order(g: GraphNet, ids: list[str]) -> list[str]:
    """Order series siblings along data flow (entry of one = exit of previous)."""
    by_entry = {g.implants[i].entry: i for i in ids if g.implants[i].kind == "series"}
    exits = {g.implants[i].exit for i in ids}
    starts = [i for i in ids if g.implants[i].kind == "series" and g.implants[i].entry not in exits]
    chains = []
    for s in starts:
        ch, cur = [s], s
        while g.implants[cur].exit in by_entry:
            cur = by_entry[g.implants[cur].exit]
            ch.append(cur)
        chains.append(ch)
    return chains


def family(g: GraphNet, dcfg: dict, seed: int) -> tuple[list[tuple[str, tuple[str, ...]]], dict]:
    atoms = g.atoms()
    n = len(atoms)
    info = {"n_atoms": n, "atoms": atoms}
    fam: list[tuple[str, tuple[str, ...]]] = []
    if dcfg["family"] in ("auto", "exhaustive") and n <= dcfg["max_exhaustive_atoms"]:
        for k in range(1, n + 1):
            for S in itertools.combinations(atoms, k):
                fam.append(("exhaustive", S))
        info["exhaustive"] = True
        info["n_subsets"] = 2 ** n - 1
        return fam, info
    if dcfg["family"] == "exhaustive":
        raise ValueError(f"{n} atoms exceeds max_exhaustive_atoms={dcfg['max_exhaustive_atoms']}")
    info["exhaustive"] = False
    seen = set()

    def add(tag, S):
        S = tuple(sorted(set(S), key=lambda s: int(s[1:])))
        if S and S not in seen:
            seen.add(S)
            fam.append((tag, S))

    for a in atoms:
        add("single", [a])
    parents = {}
    for a in atoms:
        parents.setdefault(g.implants[a].parent, []).append(a)
    for p, kids in parents.items():
        if len(kids) > 1:
            add(f"siblings_of:{p}", kids)
        for ch in chain_order(g, kids):
            # every window of length 2..8; longer windows at power-of-two lengths with half-length stride
            lens = list(range(2, min(len(ch), 8) + 1))
            L2 = 16
            while L2 <= len(ch):
                lens.append(L2)
                L2 *= 2
            if len(ch) > 8 and len(ch) not in lens:
                lens.append(len(ch))
            for L in lens:
                stride = 1 if L <= 8 else L // 2
                for i in range(0, len(ch) - L + 1, stride):
                    add(f"chain_segment:{p}", ch[i:i + L])
    gens = {}
    for a in atoms:
        gens.setdefault(g.implants[a].generation, []).append(a)
    for k, ids in gens.items():
        add(f"generation:{k}", ids)
    for a in atoms:
        desc = [d for d in g.implant_descendants(a) if d in atoms]
        if desc:
            add(f"descendants_only:{a}", desc)
    if n <= 16:
        for A, B in itertools.combinations(atoms, 2):
            add("pair", [A, B])
    rng = np_gen(seed, "deletion", "sample")
    for k in dcfg["sample_sizes"]:
        if k > n:
            continue
        for _ in range(dcfg["n_sampled"] // max(1, len(dcfg["sample_sizes"]))):
            add(f"sampled_size:{k}", list(rng.choice(atoms, size=k, replace=False)))
    info["n_subsets"] = len(fam)
    info["families"] = sorted({t.split(":")[0] for t, _ in fam})
    return fam, info


def _preserves(task: str, base: dict, cur: dict, dr: Optional[dict], crit: str, tol: float,
               target_scale: float = 1.0) -> bool:
    """Task criterion: regression compares the NORMALISED excess risk
    (MSE - MSE_base) / target_scale^2 with criteria.nmse; classification the
    accuracy drop in percentage points with criteria.acc_drop_pp."""
    if crit == "task":
        if task == "regression":
            return (cur["mse"] - base["mse"]) / (float(target_scale) ** 2 + 1e-12) <= tol
        return (base["acc"] - cur["acc"]) * 100.0 <= tol
    if crit == "expanded":
        if dr is None:
            return False
        if task == "regression":
            return dr["nmse"] <= tol
        return dr["js"] <= tol
    raise ValueError(crit)


def _dt(g):
    from ..train.trainer import model_dtype
    return model_dtype(g)


def evaluate_family(ctx, g: GraphNet, bundle, stage: str, ref_preds: Optional[dict] = None,
                    original_preds: Optional[dict] = None, dcfg: Optional[dict] = None,
                    out_name: Optional[str] = None) -> dict:
    dcfg = dcfg or ctx.cfg["deletion"]
    crit_cfg = ctx.cfg["criteria"]
    task = bundle.task
    parts = [p for p in dcfg["partitions"] if p in bundle.partitions()]
    if "complete_domain" in bundle.extra and "complete_domain" not in parts:
        parts.append("complete_domain")
    for p in ("rare", "shift"):
        if p in bundle.extra and p not in parts:
            parts.append(p)
    base, base_preds = evaluate(g, bundle, parts, ctx.cfg["train"]["eval_batch"], return_preds=True)
    p0 = count_params(g)["total"]
    fam, info = family(g, dcfg, ctx.cfg["seeds"]["deletion"])
    rows, by_hash = [], {}
    probe_part = bundle.partitions()[parts[0]]
    probe_X = {k: v[:256] for k, v in probe_part.X.items()}
    probe_out: dict[str, torch.Tensor] = {}
    n_collisions = 0
    for tag, S in fam:
        canon = tuple(E.canonical_atoms(g, S))
        rec = {"family": tag, "atoms": list(S), "canonical": list(canon)}
        try:
            h = E.delete(g, canon)
        except InvalidDeletion as ex:
            rec["invalid"] = str(ex)
            rows.append(rec)
            continue
        gh = h.instance_hash()
        rec["graph_hash"] = h.structural_hash()
        rec["instance_hash"] = gh
        with torch.no_grad():
            h.eval()
            po = h({k: (v.to(_dt(h)) if v.is_floating_point() else v) for k, v in probe_X.items()})
        if gh in by_hash:
            # content-bound hash match; independently confirm on a probe batch before skipping evaluation
            if torch.equal(po, probe_out[gh]):
                rec["same_graph_as"] = by_hash[gh]
                rows.append(rec)
                continue
            n_collisions += 1
            rec["hash_collision_detected"] = True
            gh = gh + f"#c{n_collisions}"
            rec["instance_hash"] = gh
        by_hash[gh] = len(rows)
        probe_out[gh] = po
        res, preds = evaluate(h, bundle, parts, ctx.cfg["train"]["eval_batch"], return_preds=True)
        rec["params_removed"] = p0 - count_params(h)["total"]
        rec["metrics"] = {}
        for p in parts:
            m = res[p]
            dr = M.drift(preds[p], base_preds[p], task, bundle.partitions()[p].y, bundle.target_scale)
            entry = {"risk": M.headline(m, task), "delta_risk": M.headline(m, task) - M.headline(base[p], task),
                     "drift_vs_current": dr}
            pd = M.paired_delta(preds[p], base_preds[p], bundle.partitions()[p].y, task)
            entry["paired_delta"] = pd     # per-example paired difference vs the undeleted model (cluster = sequence)
            if "acc" in m:
                entry["acc"] = m["acc"]
                entry["delta_acc"] = m["acc"] - base[p]["acc"]
            if task == "regression":
                entry["mse"] = m["mse"]
                entry["nmse_increase"] = (m["mse"] - base[p]["mse"]) / (float(bundle.target_scale) ** 2 + 1e-12)
            if original_preds and p in original_preds:
                entry["drift_vs_original"] = M.drift(preds[p], original_preds[p], task, bundle.partitions()[p].y,
                                                     bundle.target_scale)
            for gk in [k for k in m if k.startswith("acc_g") and not k.endswith("ci95")]:
                entry[gk] = m[gk]
            rec["metrics"][p] = entry
        rows.append(rec)
    # interactions J(A,B)
    risk_of = {}
    for r in rows:
        if "metrics" in r or "same_graph_as" in r:
            src = rows[r["same_graph_as"]] if "same_graph_as" in r else r
            if "metrics" in src:
                risk_of[tuple(sorted(r["atoms"]))] = {p: src["metrics"][p]["risk"] for p in parts}
    inter = []
    singles = [a for a in info["atoms"]]
    for A, B in itertools.combinations(singles, 2):
        kA, kB = (A,), (B,)
        kAB = tuple(sorted((A, B), key=lambda s: int(s[1:])))
        kAB_alt = tuple(sorted((A, B)))
        rAB = risk_of.get(kAB) or risk_of.get(kAB_alt)
        if kA in risk_of and kB in risk_of and rAB:
            for p in parts:
                J = rAB[p] - risk_of[kA][p] - risk_of[kB][p] + M.headline(base[p], task)
                inter.append({"A": A, "B": B, "partition": p, "J": J})
    # certificates
    certs = []
    sel_part = "val" if "val" in parts else parts[0]
    domain_part = "complete_domain" if "complete_domain" in parts else sel_part
    tols = {"task": crit_cfg["nmse"] if task == "regression" else crit_cfg["acc_drop_pp"],
            "expanded": crit_cfg["nmse"] if task == "regression" else crit_cfg["js"]}
    for crit, tl in tols.items():
        for tol in tl:
            for part in sorted({sel_part, domain_part}):
                valid = []
                for r in rows:
                    if "metrics" not in r:
                        continue
                    e = r["metrics"][part]
                    cur = {"acc": e.get("acc"), "mse": e.get("mse")}
                    bm = {"acc": base[part].get("acc"), "mse": base[part].get("mse")}
                    if _preserves(task, bm, cur, e["drift_vs_current"], crit, tol, bundle.target_scale):
                        valid.append(r)
                best = max(valid, key=lambda r: (r["params_removed"], -len(r["atoms"])), default=None)
                c = {"criterion": crit, "tolerance": tol, "partition": part,
                     "domain": "complete finite domain" if part == "complete_domain" else f"finite sample '{part}' "
                               f"(n={len(bundle.partitions()[part])}); not a population claim",
                     "family": "all subsets of atoms" if info["exhaustive"] else "structured+sampled (not exhaustive)",
                     "n_atoms": info["n_atoms"], "precision": f"{str(_dt(g)).replace('torch.', '')} evaluation",
                     "tolerance_units": ("normalised excess MSE (MSE - MSE_base)/target_scale^2" if task == "regression"
                                         else "accuracy drop, percentage points") if crit == "task" else
                     ("nmse to the undeleted model" if task == "regression" else "Jensen-Shannon to the undeleted model"),
                     "edits": "fixed remaining weights; canonical deletion (descendants removed with ancestors)",
                     "best_valid_deletion": None if best is None else {"atoms": best["atoms"],
                                                                        "params_removed": best["params_removed"]},
                     "n_valid": len(valid)}
                if info["exhaustive"] and not valid:
                    c["label"] = "L2_certificate_no_valid_deletion"
                elif best is not None:
                    c["label"] = "reducible_by_deletion_witness"
                else:
                    c["label"] = "no_valid_deletion_found_in_family (not a certificate)"
                certs.append(c)
    # L1: does every single deletion change the function (on the selection partition)?
    l1 = {}
    for r in rows:
        if r["family"] in ("single", "exhaustive") and len(r["atoms"]) == 1:
            src = rows[r["same_graph_as"]] if "same_graph_as" in r else r
            if "metrics" in src:
                d = src["metrics"][sel_part]["drift_vs_current"]
                l1[r["atoms"][0]] = (d.get("max_abs_logit", d.get("max_abs", 0.0)) > 0.0)
    smallest = None
    for r in rows:
        if "metrics" in r and (smallest is None or r["params_removed"] > smallest["params_removed"]):
            smallest = r
    greedy = []
    if dcfg.get("compare_greedy"):
        budget = len(by_hash)                             # the group search's evaluated distinct deletions
        for c in certs:
            if c["partition"] != sel_part:
                continue
            gr = greedy_removal(g, bundle, sel_part, c["criterion"], c["tolerance"], budget,
                                ctx.cfg["train"]["eval_batch"], base, base_preds)
            gp = c["best_valid_deletion"]["params_removed"] if c["best_valid_deletion"] else 0
            greedy.append({"criterion": c["criterion"], "tolerance": c["tolerance"], "partition": sel_part,
                           "greedy": gr, "group_search_params_removed": gp,
                           "group_search_evaluations": budget})
    out = {"stage": stage, "info": info, "partitions": parts, "base": base, "rows": rows, "interactions": inter,
           "greedy_vs_group": greedy,
           "certificates": certs, "L1_single_deletion_changes_function": l1,
           "largest_deletion_evaluated": None if smallest is None else
           {"atoms": smallest["atoms"], "params_removed": smallest["params_removed"]},
           "n_distinct_graphs": len(by_hash), "hash_collisions_detected": n_collisions,
           "dedupe": "content-bound instance hash, confirmed on a 256-example probe batch before skipping"}
    if ctx is not None:
        ctx.save_json(out_name or f"deletions_{stage}.json", out)
        for c in certs:
            ctx.metric(stage, c["partition"], f"deletion_cert[{c['criterion']}@{c['tolerance']}].n_valid",
                       c["n_valid"], g.structural_hash(), label=c["label"])
        for it in inter:
            ctx.metric(stage, it["partition"], f"J[{it['A']},{it['B']}]", it["J"], g.structural_hash())
        ctx.metric(stage, "none", "deletion_family_size", len(fam), g.structural_hash(), exhaustive=info["exhaustive"])
        for gr in greedy:
            ctx.metric(stage, gr["partition"], f"greedy_params_removed[{gr['criterion']}@{gr['tolerance']}]",
                       gr["greedy"]["params_removed"], g.structural_hash(),
                       group_search_params_removed=gr["group_search_params_removed"],
                       evaluations=gr["greedy"]["evaluations"])
    return out


def greedy_removal(g: GraphNet, bundle, part: str, crit: str, tol: float, budget: int, batch: int,
                   base: dict, base_preds) -> dict:
    """F05e: greedy one-at-a-time removal under the same criterion, with at most `budget`
    evaluated deletions (the group search's evaluation count, so both searches have equal
    cost).  Each step tries every remaining atom added to the current deleted set and keeps
    the valid one removing the most parameters; stops when none is valid or the budget is spent."""
    task = bundle.task
    p0 = count_params(g)["total"]
    atoms = g.atoms()
    cur: list[str] = []
    evals = 0
    path = []
    bm = {"acc": base[part].get("acc"), "mse": base[part].get("mse")}
    while evals < budget:
        best = None
        for a in atoms:
            if a in cur or evals >= budget:
                continue
            try:
                h = E.delete(g, cur + [a])
            except InvalidDeletion:
                continue
            canon = set(E.canonical_atoms(g, cur + [a]))
            if canon == set(E.canonical_atoms(g, cur)):
                continue                                  # already removed with an ancestor
            evals += 1
            res, preds = evaluate(h, bundle, [part], batch, return_preds=True)
            m = res[part]
            dr = M.drift(preds[part], base_preds[part], task, bundle.partitions()[part].y, bundle.target_scale)
            if _preserves(task, bm, {"acc": m.get("acc"), "mse": m.get("mse")}, dr, crit, tol, bundle.target_scale):
                pr = p0 - count_params(h)["total"]
                if best is None or pr > best[1]:
                    best = (a, pr)
        if best is None:
            break
        cur.append(best[0])
        path.append({"added": best[0], "params_removed": best[1], "evaluations_so_far": evals})
    return {"atoms": cur, "params_removed": path[-1]["params_removed"] if path else 0, "evaluations": evals,
            "budget": budget, "path": path}


def run_deletion_job(ctx) -> dict:
    """Standalone R1 job on a parent checkpoint (Wave 4)."""
    from .common import setup_data
    bundle = setup_data(ctx)
    stage = ctx.cfg.get("tags", {}).get("parent_stage", "final")
    ck = ctx.parent_ckpt("trajectory", stage)
    g = GraphNet.from_checkpoint(ck["model"], ctx.device)
    f0 = GraphNet.from_checkpoint(ctx.parent_ckpt("trajectory", "baseline_ref")["model"], ctx.device)
    _, orig = evaluate(f0, bundle, ["val", "test"], return_preds=True)
    res = evaluate_family(ctx, g, bundle, stage, original_preds=orig)
    return {"n_distinct_graphs": res["n_distinct_graphs"], "exhaustive": res["info"]["exhaustive"]}
