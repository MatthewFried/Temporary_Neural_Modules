"""Non-mutating contraction diagnostics (v5, P1).

Recorded for every implant that a contraction is about to remove (dissipation start, repair
start, each grow/contract cycle), on the model as it stands before any removal:

  A. affine residual at the implant: T = implant map entry value h -> exit value T(h).  An
     affine map (A, b) is fitted by least squares (relative ridge 1e-10, CPU float64) on the
     first `eval.calib_size` TRAINING inputs and scored on separate VALIDATION inputs:
       rho_raw            = mean over positions of ||T(h) - (A h + b)||^2
       rho_rel_output     = rho_raw / mean ||T(h) - mean T||^2      (fraction of output variance left)
       rho_rel_change     = rho_raw / mean ||T(h) - h||^2            (series implants of equal width)
     plus the condition number and numerical rank of the centred calibration activations.
     Vectors are per position: channels for images (one map shared over positions), the last
     dimension for sequences.  rho is the distance to an affine replacement AT THIS CUT on this
     distribution, not to everything the compact network can represent, and it is not
     scale-free: rescaling the representation changes it without changing the function.
  B. downstream-sensitive residual: mean ||J_D(T(h)) r(h)||^2 over validation inputs, with D the
     map from the implant's exit value to the model output and r the affine residual, computed
     with a Jacobian-vector product (local linearisation: curvature and saturation are missed),
     normalised by the output variance.
  C. virtual affine replacement: a CLONE whose exit uses are redirected to A h + b, evaluated on
     val / test.  This is an intervention measurement of immediate damage (not a prediction of
     it); its prospective targets are later repair cost and final gain.
  Baseline predictors kept beside them: deletion damage of the implant alone (fixed weights),
  implant output size ||T(h) - h||^2 (or ||T(h)||^2 for a branch), gate values owned by the
  implant, and the model's pre-contraction risk.

Nothing here changes the model: it runs in eval mode under no_grad (the JVP uses
autograd.functional.jvp with respect to the exit value only, so no parameter .grad is
written), draws no random numbers that persist (building the replacement module's default
initialisation and the deletion baseline, which may build a folded module, run inside
torch.random.fork_rng, so the global RNG is restored), and touches
no trainer, optimizer or data stream.  The
parameter / buffer hash and the CPU (and CUDA) RNG state are compared before and after and the
result is recorded (`state_unchanged`).  Fitted maps are saved to diagnostics/<tag>.pt and the
records to contraction_diagnostics.json (idempotent per tag, so a resumed job reuses them).
Costs (seconds per part) are recorded: fitting is O(N d^2 + d^3) and is not free.
"""
from __future__ import annotations

import hashlib
import math
import time
from typing import Optional

import torch

from ..graph import edits as E
from ..graph.graph import GraphNet, InvalidDeletion
from ..train import metrics as M
from ..train.trainer import evaluate
from ..utils import atomic_torch_save, atomic_write_json, read_json


def _state_fingerprint(g: GraphNet) -> str:
    h = hashlib.sha256()
    for k, v in sorted(g.state_dict().items()):
        h.update(k.encode())
        h.update(v.detach().cpu().contiguous().numpy().tobytes())
    h.update(repr(sorted(g.gate_vals.items())).encode())
    return h.hexdigest()[:16]


def _rng_fingerprint() -> str:
    h = hashlib.sha256(torch.get_rng_state().numpy().tobytes())
    if torch.cuda.is_available():
        for s in torch.cuda.get_rng_state_all():
            h.update(s.numpy().tobytes())
    return h.hexdigest()[:16]


def _flat(t: torch.Tensor, layout: str) -> torch.Tensor:
    if t.dim() == 4:
        return t.movedim(1, -1).reshape(-1, t.shape[1])
    return t.reshape(-1, t.shape[-1])


def eval_inputs(g: GraphNet, X: dict) -> dict:
    """The one input representation used by every diagnostic forward pass: floating tensors in the model's
    dtype and on its device; integer (token / query) tensors keep their integer dtype and move to the device."""
    from ..train.trainer import model_dtype
    dt = model_dtype(g)
    dev = next(g.parameters()).device
    return {k: (v.to(device=dev, dtype=dt) if v.is_floating_point() else v.to(device=dev)) for k, v in X.items()}


@torch.no_grad()
def _values(g: GraphNet, X: dict, nodes: list[str], batch: int) -> dict:
    X = eval_inputs(g, X)
    n = len(next(iter(X.values())))
    out = {k: [] for k in nodes}
    for i in range(0, n, batch):
        _, vals = g({k: v[i:i + batch] for k, v in X.items()}, return_nodes=nodes)
        for k in nodes:
            out[k].append(vals[k])
    return {k: torch.cat(v) for k, v in out.items()}


def _has_attention(g: GraphNet) -> bool:
    from ..cop_pegs.modules import AttnPearl
    from ..graph.ops import SelfAttention
    return any(isinstance(m, (SelfAttention, AttnPearl)) for m in g.modules())


def _derivative_capable_attention():
    """Context for forward-over-reverse differentiation (autograd.functional.jvp uses a double backward):
    the fused scaled-dot-product kernels (flash / memory-efficient, CPU and CUDA) do not implement the
    derivative of their backward, so the math kernel is selected inside the diagnostic only.  Training
    kernels are untouched (the context restores the previous selection on exit)."""
    from torch.nn.attention import SDPBackend, sdpa_kernel
    return sdpa_kernel([SDPBackend.MATH]), "math (torch.nn.attention.sdpa_kernel, scoped to the JVP)"


def _sub(part, n: int) -> dict:
    return {k: v[:n] for k, v in part.X.items()}


def _risk(g, bundle, parts, batch) -> dict:
    res, _ = evaluate(g, bundle, parts, batch)
    return {p: float(M.headline(res[p], bundle.task)) for p in parts}


@torch.no_grad()
def _fit(Hc: torch.Tensor, Yc: torch.Tensor):
    X = Hc.detach().to("cpu", torch.float64)
    Y = Yc.detach().to("cpu", torch.float64)
    Xa = torch.cat([X, torch.ones(len(X), 1, dtype=torch.float64)], 1)
    G = Xa.T @ Xa
    A = G + 1e-10 * float(G.diagonal().mean()) * torch.eye(Xa.shape[1], dtype=torch.float64)
    sol = torch.linalg.solve(A, Xa.T @ Y)
    s = torch.linalg.svdvals(X - X.mean(0))
    smax = float(s.max()) if s.numel() else 0.0
    rank = int((s > max(smax, 1e-300) * 1e-10).sum())
    nz = s[s > max(smax, 1e-300) * 1e-10]
    cond = float(smax / float(nz.min())) if nz.numel() else float("inf")
    return sol[:-1].T.contiguous(), sol[-1].contiguous(), {"cond": cond, "rank": rank, "dim": int(X.shape[1]),
                                                           "n_rows": int(X.shape[0])}


def _apply(W, b, H: torch.Tensor) -> torch.Tensor:
    """A h + b in float64 on H's device (the map is fitted on the CPU; activations may be on the GPU)."""
    return H.to(torch.float64) @ W.to(H.device, torch.float64).T + b.to(H.device, torch.float64)


def virtual_affine_clone(g: GraphNet, iid: str, W: torch.Tensor, b: torch.Tensor) -> GraphNet:
    """Clone of g in which every use of the implant's exit value outside the implant reads
    A entry + b instead (the implant itself is left in place but no longer feeds anything)."""
    from ..cop_pegs.transplant import AffineAlignment, alignment_spec
    imp = g.implants[iid]
    h = g.clone(share_params=False)
    image = g.layout == "img"
    dt = next(h.parameters()).dtype
    devs = [torch.cuda.current_device()] if torch.cuda.is_available() else []
    with torch.random.fork_rng(devices=devs):          # nn.Linear's default init draws from the global RNG
        al = AffineAlignment(W.shape[1], W.shape[0], image=image).to(dtype=dt)
    with torch.no_grad():                               # copied in the model's dtype (exact for float64 models)
        al.lin.weight.copy_(W.to(al.lin.weight.dtype))
        al.lin.bias.copy_(b.to(al.lin.bias.dtype))
    mt, margs = alignment_spec(al)
    attrs = {"module_type": mt, "module_args": margs, "dim": h.node_dim(imp.exit)}
    for k in ("hw", "T", "layout"):
        if k in h.nodes[imp.exit].attrs:
            attrs[k] = h.nodes[imp.exit].attrs[k]
    dev = next(h.parameters()).device
    nid = h.add_node("module", [imp.entry], attrs, role="virtual_affine", module=al.to(device=dev, dtype=dt))
    h.replace_uses(imp.exit, nid, exclude={nid} | set(imp.nodes))
    h._plan = None
    return h


def jvp_sensitivity(g: GraphNet, iid: str, W, b, X: dict) -> dict:
    """mean_x ||J_D(T(h)) r(h)||^2 with D: exit value -> model output (local linearisation).  Every forward
    pass (values, reference output and the JVP closure) uses the same eval_inputs(g, X).  Raises on failure;
    the caller records the failure (a missing JVP is never reported as zero sensitivity)."""
    imp = g.implants[iid]
    X = eval_inputs(g, X)
    with torch.no_grad():
        v = _values(g, X, [imp.entry, imp.exit], 4096)
        H, Y = v[imp.entry], v[imp.exit]
        R = (_flat(Y, g.layout).to(torch.float64) - _apply(W, b, _flat(H, g.layout))).to(Y.dtype)
        if Y.dim() == 4:
            R = R.reshape(Y.shape[0], Y.shape[2], Y.shape[3], Y.shape[1]).movedim(-1, 1)
        else:
            R = R.reshape(Y.shape)
    saved = getattr(g, "value_patch", None)

    def f(z):
        g.value_patch = {imp.exit: (lambda t, z=z: z)}
        try:
            return g(X)
        finally:
            g.value_patch = saved
    import contextlib
    ctxm, backend = (_derivative_capable_attention() if _has_attention(g) else
                     (contextlib.nullcontext(), "default (no attention modules)"))
    rnn = any(isinstance(m, torch.nn.RNNBase) for m in g.modules())
    if rnn:
        # cuDNN RNN kernels have no double backward: the native RNN path is used inside the JVP only
        backend += "; cudnn disabled for RNN modules (scoped)"
    with ctxm, (torch.backends.cudnn.flags(enabled=False) if rnn else contextlib.nullcontext()):
        with torch.no_grad():
            out0 = g(X)
        _, jr = torch.autograd.functional.jvp(f, (Y.detach(),), (R.detach(),), create_graph=False, strict=False)
    jr = jr.detach().double()
    o = out0.detach().double()
    per = (jr.reshape(jr.shape[0], -1) ** 2).sum(1)
    var = ((o.reshape(o.shape[0], -1) - o.reshape(o.shape[0], -1).mean(0)) ** 2).sum(1).mean()
    val = float(per.mean())
    if not math.isfinite(val):
        raise FloatingPointError(f"non-finite JVP residual ({val})")
    return {"jvp_residual": val, "jvp_residual_rel_output": float(per.mean() / var.clamp_min(1e-30)),
            "n_examples": int(jr.shape[0]), "jvp_backend": backend,
            "limitation": "first-order (local linearisation) at the current exit value"}


DIAGNOSTIC_VERSION = "diag-8.0"
REQUIRED_MEASUREMENTS = ("fit", "virtual", "deletion", "jvp")


def _diagnose_implant(g, iid, bundle, parts, batch, Xc, Xv, n_jvp, rec, maps, save_maps=None) -> dict:
    """Every measurement has its own status (ok / failed / not_applicable) and error, so a failed JVP keeps
    the fit, the virtual replacement and the deletion baseline.  The fitted map is stored in `maps` as soon
    as the fit succeeds.  `complete` is True only when every required measurement is ok or not applicable;
    `error` (kept for older readers) joins the failures."""
    imp = g.implants[iid]
    row: dict = {"kind": imp.kind, "construction": imp.construction}
    st = {m: "not_run" for m in REQUIRED_MEASUREMENTS}
    errs = {}
    W = b = None
    try:
        t0 = time.time()
        vc = _values(g, Xc, [imp.entry, imp.exit], batch)
        vv = _values(g, Xv, [imp.entry, imp.exit], batch)
        Hc, Yc = _flat(vc[imp.entry], g.layout), _flat(vc[imp.exit], g.layout)
        Hv, Yv = _flat(vv[imp.entry], g.layout), _flat(vv[imp.exit], g.layout)
        if Hc.shape[0] != Yc.shape[0]:
            raise ValueError("entry and exit values have different positions")
        W, b, fit_info = _fit(Hc, Yc)
        if not (torch.isfinite(W).all() and torch.isfinite(b).all()):
            raise FloatingPointError("non-finite affine fit")
        maps[iid] = {"weight": W.cpu(), "bias": b.cpu(), "entry": imp.entry, "exit": imp.exit,
                     "image": g.layout == "img", "diagnostic_version": DIAGNOSTIC_VERSION}
        if save_maps is not None:
            save_maps()                                 # on disk before any later measurement can fail
        Rv = Yv.double() - _apply(W, b, Hv)
        rho = float((Rv ** 2).sum(1).mean())
        outvar = float(((Yv.double() - Yv.double().mean(0)) ** 2).sum(1).mean())
        row.update({**fit_info, "rho_raw": rho, "rho_rel_output": rho / max(outvar, 1e-30),
                    "rho_train_raw": float(((Yc.double() - _apply(W, b, Hc)) ** 2).sum(1).mean()),
                    "fit_seconds": time.time() - t0})
        if Hv.shape[1] == Yv.shape[1] and imp.kind == "series":
            ch = float(((Yv.double() - Hv.double()) ** 2).sum(1).mean())
            row["implant_change_sq"] = ch
            row["rho_rel_change"] = rho / ch if ch > 1e-30 else None
        else:
            row["implant_output_sq"] = float((Yv.double() ** 2).sum(1).mean())
        gates = sorted({a for n in imp.nodes if n in g.nodes for a in
                        ([g.nodes[n].attrs.get("gate")] + list(g.nodes[n].attrs.get("gates") or []))
                        if a is not None and a in g.gate_vals})
        row["gate_values"] = {a: float(g.gate_vals[a]) for a in gates}
        st["fit"] = "ok"
    except Exception as ex:
        st["fit"], errs["fit"] = "failed", f"{type(ex).__name__}: {ex}"
    if st["fit"] == "ok":
        try:
            t1 = time.time()
            vclone = virtual_affine_clone(g, iid, W, b)
            vclone.eval()
            row["virtual_affine_risk"] = _risk(vclone, bundle, parts, batch)
            row["virtual_affine_damage"] = {p: row["virtual_affine_risk"][p] - rec["pre_contraction_risk"][p]
                                            for p in parts}
            row["virtual_seconds"] = time.time() - t1
            st["virtual"] = "ok"
        except Exception as ex:
            st["virtual"], errs["virtual"] = "failed", f"{type(ex).__name__}: {ex}"
        try:
            t2 = time.time()
            row.update(jvp_sensitivity(g, iid, W, b, _sub(bundle.val, min(n_jvp, len(bundle.val)))))
            row["jvp_seconds"] = time.time() - t2
            st["jvp"] = "ok"
        except Exception as ex:
            st["jvp"], errs["jvp"] = "failed", f"{type(ex).__name__}: {ex}"
    try:
        # a fold-type deletion builds a new module whose default init draws from the global RNG
        with torch.random.fork_rng(devices=[torch.cuda.current_device()] if torch.cuda.is_available() else []):
            dele = E.delete(g, [iid], share_params=False)
        dele.eval()
        dr = _risk(dele, bundle, parts, batch)
        row["deletion_damage"] = {p: dr[p] - rec["pre_contraction_risk"][p] for p in parts}
        st["deletion"] = "ok"
    except InvalidDeletion as ex:
        row["deletion_damage"] = None
        row["deletion_invalid"] = str(ex)
        st["deletion"] = "not_applicable"
    except Exception as ex:
        st["deletion"], errs["deletion"] = "failed", f"{type(ex).__name__}: {ex}"
    for m in REQUIRED_MEASUREMENTS:
        row[f"{m}_status"] = st[m]
        if m in errs:
            row[f"{m}_error"] = errs[m]
    row["complete"] = all(st[m] in ("ok", "not_applicable") for m in REQUIRED_MEASUREMENTS)
    if not row["complete"]:
        row["error"] = "; ".join(f"{m}: {errs.get(m, st[m])}" for m in REQUIRED_MEASUREMENTS
                                 if st[m] not in ("ok", "not_applicable"))
    return row


def contraction_diagnostics(ctx, g: GraphNet, bundle, implant_ids: list[str], tag: str,
                            n_jvp: int = 256) -> dict:
    path = ctx.dir / "contraction_diagnostics.json"
    store = read_json(path) if path.exists() else {}
    if tag in store:
        return store[tag]
    batch = ctx.cfg["train"]["eval_batch"]
    n_cal = min(int(ctx.cfg["eval"]["calib_size"]), len(bundle.train))
    n_val = min(int(ctx.cfg["eval"]["calib_size"]), len(bundle.val))
    Xc, Xv = _sub(bundle.train, n_cal), _sub(bundle.val, n_val)
    parts = [p for p in ("val", "test") if p in bundle.partitions()]
    was = g.training
    fp0, rng0 = _state_fingerprint(g), _rng_fingerprint()
    g.eval()
    t_all = time.time()
    rec = {"tag": tag, "calibration": {"partition": "train", "first_n": n_cal},
           "scoring": {"partition": "val", "first_n": n_val}, "implants": {}}
    maps: dict = {}
    (ctx.dir / "diagnostics").mkdir(exist_ok=True)
    mp = ctx.dir / "diagnostics" / f"{tag}.pt"
    rec["maps_file"] = f"diagnostics/{tag}.pt"
    rec["diagnostic_version"] = DIAGNOSTIC_VERSION
    try:
        rec["pre_contraction_risk"] = _risk(g, bundle, parts, batch)
        for iid in implant_ids:
            imp = g.implants.get(iid)
            if imp is None or imp.entry is None or imp.exit is None or imp.entry not in g.nodes or \
                    imp.exit not in g.nodes:
                rec["implants"][iid] = {"skipped": "implant has no entry / exit value"}
                continue
            rec["implants"][iid] = _diagnose_implant(g, iid, bundle, parts, batch, Xc, Xv, n_jvp, rec, maps,
                                                     save_maps=lambda: atomic_torch_save(maps, mp))
            atomic_torch_save(maps, mp)                 # every fitted map is on disk before the next implant
    finally:
        atomic_torch_save(maps, mp)
        g.train(was)
    rows = [r for r in rec["implants"].values() if "skipped" not in r]
    rec["complete"] = all(r.get("complete") for r in rows)
    rec["n_incomplete_implants"] = sum(not r.get("complete") for r in rows)
    rec["seconds"] = time.time() - t_all
    rec["state_unchanged"] = (_state_fingerprint(g) == fp0) and (_rng_fingerprint() == rng0)
    if not rec["state_unchanged"]:
        raise RuntimeError(f"contraction diagnostics changed the model or RNG state ({tag})")
    store[tag] = rec
    atomic_write_json(path, store)
    for iid, row in rec["implants"].items():
        for k in ("rho_raw", "rho_rel_output", "jvp_residual_rel_output"):
            if isinstance(row.get(k), float):
                ctx.metric(f"diag:{tag}", "val", f"{k}[{iid}]", row[k], g.structural_hash())
    return rec
