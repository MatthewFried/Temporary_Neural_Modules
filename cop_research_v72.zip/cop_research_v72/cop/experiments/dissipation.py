"""R5 paths back: abrupt vs gradual removal and other return paths.

Every method ends with the PHYSICALLY simplified model (export_compact with all
target implants removed, gates at endpoints, scaffolds dropped); the exported
model is checked to contain none of the targets.  Recorded along the path:
validation risk at path_eval_points, peak risk, final risk after physical
removal and post-training, and total updates.  A barrier observed on one path
is a property of that path only.
"""
from __future__ import annotations

import copy

import math
import re
from typing import Optional

import torch
import torch.nn.functional as F

from ..config import seed_of
from ..graph import edits as E
from ..graph.export import export_compact
from ..graph.graph import GraphNet, GraphError, InvalidDeletion
from ..train import metrics as M
from ..train.trainer import Segment, Trainer, evaluate, forward_macs, predict, compute_counters
from ..utils import torch_gen
from . import common as C
from .context import Unsupported, ScientificInvalid


def _targets(g: GraphNet, spec: str) -> list[str]:
    atoms = g.atoms()
    if spec == "all":
        return [a for a in atoms if g.implants[a].parent is None]
    if spec.startswith("generation:"):
        k = int(spec.split(":")[1])
        return [a for a in atoms if g.implants[a].generation == k]
    if spec.startswith("atoms:"):
        return spec[6:].split(",")
    raise ValueError(spec)


def _ordered(g: GraphNet, targets: list[str], order: str) -> list[list[str]]:
    """Expand targets with their descendants, group them into removal phases, then move any
    implant whose internal values another target reads (e.g. a diamond bridge reading a branch's
    hidden layer) into the reader's phase if it would otherwise be removed earlier: deleting it
    first would leave the reader without its input.  The returned phases are recorded."""
    phases = _ordered_raw(g, targets, order)
    full = {t for ph in phases for t in ph}
    readers: dict[str, set[str]] = {}
    for t in full:
        region = g.region(t)
        inner = set(region) - {g.implants[t].exit}
        rd = set()
        for n in g.nodes.values():
            if n.id in region or not any(i in inner for i in n.inputs):
                continue
            o = n.owner
            while o is not None and o not in full:
                o = g.implants[o].parent if o in g.implants else None
            if o is not None and o != t:
                rd.add(o)
        readers[t] = rd
    idx = {t: k for k, ph in enumerate(phases) for t in ph}
    changed = True
    while changed:
        changed = False
        for t, rd in readers.items():
            late = max([idx[r] for r in rd] + [idx[t]])
            if late > idx[t]:
                idx[t] = late
                changed = True
    # removing (or gating) an implant removes its descendants with it: a descendant scheduled after
    # one of its ancestors has no phase of its own (so ancestor_first is a single joint removal)
    def anc(t):
        p_ = g.implants[t].parent
        while p_ is not None:
            yield p_
            p_ = g.implants[p_].parent if p_ in g.implants else None
    keep = {t for t in full if not any(a_ in idx and idx[a_] < idx[t] for a_ in anc(t))}
    out = [sorted([t for t in keep if idx[t] == k], key=lambda s: int(s[1:])) for k in range(len(phases))]
    return [ph for ph in out if ph]


def _ordered_raw(g: GraphNet, targets: list[str], order: str) -> list[list[str]]:
    full = set()
    for t in targets:
        full |= {t, *[d for d in g.implant_descendants(t) if g.implants[d].deletion in ("bypass", "drop_term")]}
    if order == "joint":
        return [sorted(full, key=lambda s: int(s[1:]))]
    if order in ("oldest_first", "newest_first"):
        # by insertion round (oldest = inserted first); descendants follow their own rounds
        by_r: dict[int, list[str]] = {}
        for t in full:
            by_r.setdefault(int(g.implants[t].round or 0), []).append(t)
        rs = sorted(by_r, reverse=order == "newest_first")
        return [sorted(by_r[k], key=lambda s: int(s[1:])) for k in rs]
    by_gen = {}
    for t in full:
        by_gen.setdefault(g.implants[t].generation, []).append(t)
    gens = sorted(by_gen)
    if order == "descendant_first":
        gens = gens[::-1]
    return [sorted(by_gen[k], key=lambda s: int(s[1:])) for k in gens]


def contribution_nodes(g: GraphNet, iid: str) -> tuple[str, str]:
    imp = g.implants[iid]
    if imp.kind == "branch":
        return imp.exit, None
    return imp.exit, imp.entry


def inverse_pairs(model: GraphNet, live: list[str]) -> list[dict]:
    """Explicit inverse metadata for each inverse-pair target: kind (linear |
    coupling), tie, and the parameter keys of T and Tinv by role."""
    out = []
    for t in live:
        imp = model.implants[t]
        if imp.construction != "inverse_pair":
            continue
        meta = imp.meta.get("inverse") or {}
        kids = model.implant_children(t)
        T = next(c for c in kids if model.implants[c].construction == "inverse_T")
        Ti = next(c for c in kids if model.implants[c].construction == "inverse_Tinv")
        role = lambda c, r: [model.nodes[n].pkey for n in model.implants[c].nodes
                             if model.nodes[n].role == r and model.nodes[n].pkey]
        rec = {"group": t, "kind": meta.get("kind"), "tie": meta.get("tie")}
        if rec["kind"] == "linear":
            rec["W"], rec["Winv"] = role(T, "W"), role(Ti, "Winv")
            rec["exact_by_construction"] = rec["tie"] == "enforced" or rec["W"] == rec["Winv"]
        elif rec["kind"] == "coupling":
            rec["m"] = [model.nodes[n].pkey for n in model.implants[T].nodes if model.nodes[n].pkey]
            rec["m_inv"] = [model.nodes[n].pkey for n in model.implants[Ti].nodes if model.nodes[n].pkey]
            rec["exact_by_construction"] = rec["tie"] == "enforced" or rec["m"] == rec["m_inv"]
        else:
            raise Unsupported(f"inverse pair {t} has no inverse metadata (kind {rec['kind']!r})")
        out.append(rec)
    return out


def inverse_restore_penalty(m: GraphNet, pairs: list[dict]):
    """Composition error of each inverse pair, dispatched on explicit metadata.
      linear   Tinv(T(h)) = W_inv (W h + b) + b_inv: penalty ||W_inv W - I||_F^2 + ||W_inv b + b_inv||^2,
               zero exactly at a correct affine inverse pair (and its gradient vanishes there)
      coupling T(h) = [h1, h2 + m(h1)], Tinv(y) = [y1, y2 - m'(y1)]: parameter-tie penalty
               ||theta' - theta||^2 (sufficient for exact inversion; zero when m' = m)
    Pairs that are exact by construction (enforced / shared parameters) get no penalty."""
    tot = 0.0
    for pr in pairs:
        if pr["exact_by_construction"]:
            continue
        if pr["kind"] == "linear":
            A, B = m.mods[pr["W"][0]], m.mods[pr["Winv"][0]]
            W, Wi = A.weight, B.weight
            eye = torch.eye(W.shape[1], device=W.device, dtype=W.dtype)
            tot = tot + ((Wi @ W - eye) ** 2).sum()
            b = A.bias if A.bias is not None else torch.zeros(W.shape[0], device=W.device, dtype=W.dtype)
            bi = B.bias if B.bias is not None else torch.zeros(Wi.shape[0], device=W.device, dtype=W.dtype)
            tot = tot + ((Wi @ b + bi) ** 2).sum()
        else:
            for a, bkey in zip(pr["m"], pr["m_inv"]):
                if a == bkey:
                    continue
                for x, y in zip(m.mods[a].parameters(), m.mods[bkey].parameters()):
                    tot = tot + ((x - y) ** 2).sum()
    return tot


class _Steps:
    """Sequential job steps with a checkpoint after each one (model, trainer
    generator state, path, counters, variables).  A resumed job restores the
    state after the last completed step and skips steps up to it; a training
    step interrupted mid-way resumes from its Trainer checkpoint."""

    def __init__(self, ctx, st: dict, tr: Trainer):
        self.ctx, self.st, self.tr = ctx, st, tr
        self.i = -1
        self.done = -1
        self.partial = None
        if ctx.has_ckpt("diss_state"):
            ck = ctx.load_ckpt("diss_state")
            st["model"] = GraphNet.from_checkpoint(ck["model"], ctx.device)
            st.update({k: ck["extra"][k] for k in ("path", "upd", "vars")})
            tr.model = st["model"]
            tr.load_state_dict(ck["trainer"])
            self.done = ck["extra"]["step"]
            ctx.log({"event": "resume", "after_step": self.done})
        if ctx.has_ckpt("diss_partial"):
            ck = ctx.load_ckpt("diss_partial")
            if ck["extra"]["step"] > self.done:
                self.partial = ck

    def save(self, name: str, model, extra: dict) -> None:
        self.ctx.save_ckpt(name, model, self.tr, {"path": self.st["path"], "upd": self.st["upd"],
                                                  "vars": self.st["vars"], **extra})
        if name == "diss_state":
            # between steps only the Trainer's streams carry over (every training step re-configures its
            # optimizer); drop the parameter selection, which refers to the model of the previous step
            ck = self.ctx.load_ckpt(name)
            ck["trainer"]["state"]["pkeys"] = None
            ck["trainer"]["opt"] = None
            from ..utils import atomic_torch_save
            atomic_torch_save(ck, self.ctx.ckpt_path(name))

    def __call__(self, fn) -> None:
        self.i += 1
        if self.i <= self.done:
            return
        fn()
        self.save("diss_state", self.st["model"], {"step": self.i})
        self.ctx.ckpt_path("diss_partial").unlink(missing_ok=True)


def _per_example(m, bundle, batch):
    """per-example training loss (cross-entropy or squared error) and error indicator (classification)."""
    out = predict(m, bundle.train, batch).double()
    y = bundle.train.y
    if bundle.task == "classification":
        loss = F.cross_entropy(out, y.long(), reduction="none")
        return loss.cpu(), (out.argmax(-1) != y).double().cpu()
    return ((out - y.double().view_as(out)) ** 2).reshape(len(y), -1).mean(1).cpu(), None


def branch_side(slot: str) -> Optional[str]:
    """'a' / 'b' for the specialised branches (slot spec/r<k>/a or /b), else None."""
    tail = str(slot or "").rsplit("/", 1)[-1]
    return tail if tail in ("a", "b") and "spec/" in str(slot) else None


@torch.no_grad()
def frozen_weight_sweep(model, targets: list, bundle, batch: int, membership: Optional[torch.Tensor] = None,
                        membership_by_implant: Optional[dict] = None,
                        membership_initial: Optional[torch.Tensor] = None) -> dict:
    """v15 (review Families 1 and 4): the dependence of the CURRENT computation on the additions, with every weight
    frozen: the intact model, every implant gate scaled to 0.75 / 0.5 / 0.25 / 0, each single-implant deletion and
    the joint deletion, all on the same trained weights and before any repair.  Risk and error on val / test /
    rare / shift where present.  A gate at 0 and a physical deletion are both reported: for series implants they
    are the same function; for branches the gate scales the merge coefficient."""
    parts = [p for p in ("val", "test", "rare", "shift") if p in bundle.partitions()]

    def score(m):
        res, _ = evaluate(m, bundle, parts, batch)
        return {p: {"risk": M.headline(res[p], bundle.task),
                    **({"err": 1.0 - res[p]["acc"]} if "acc" in res[p] else {})} for p in parts}
    live = [t for t in targets if t in model.implants and model.implants[t].nodes]
    # single deletions cover EVERY implant with nodes, not only the removal targets: a branch inside a group (e.g.
    # one specialized branch) can then be deleted alone; deleting a parent deletes its descendants
    every = sorted((t for t, imp in model.implants.items() if imp.nodes), key=lambda s_: int(s_[1:]))
    out = {"targets": live, "all_implants": every,
           "parents": {t: model.implants[t].parent for t in every if getattr(model.implants[t], "parent", None)},
           "slots": {t: model.implants[t].slot for t in every},
           "kinds": {t: model.implants[t].kind for t in every},
           "intact": score(model), "gate_scale": {}, "single_deletion": {}}
    for v in (0.75, 0.5, 0.25, 0.0):
        try:
            h = model.clone(share_params=False)
            for t in live:
                gid = E.add_gate(h, t)
                h.gate_vals[gid] = float(v)
            h._plan = None
            out["gate_scale"][str(v)] = score(h)
        except (GraphError, InvalidDeletion) as ex:
            out["gate_scale"][str(v)] = {"error": f"{type(ex).__name__}: {ex}"}
    # membership_by_implant (hybrids): implant -> (indicator or None, source label) for implants whose training
    # split differs from the receiver's (swapped-in branches carry their donor lineage's split, or none)
    mbi = membership_by_implant or {}
    any_mem = membership is not None or any(v[0] is not None for v in mbi.values())
    base_pe = _per_example(model, bundle, batch) if any_mem else None
    if any_mem:
        out["membership"] = {"source": "branch-a indicator over the training set (receiver lineage)",
                             "n_a": int(membership.sum()) if membership is not None else None,
                             "n_b": int((~membership).sum()) if membership is not None else None,
                             "swapped_in": {t: v[1] for t, v in mbi.items()}}
        out["damage_by_membership"] = {}
    for t in every:
        try:
            h = E.delete(model, [t], share_params=False)
            out["single_deletion"][t] = score(h)
            side = branch_side(model.implants[t].slot)
            mem_t, src_t = mbi.get(t, (membership, "receiver lineage"))
            if base_pe is not None and side is not None and mem_t is None:
                out["damage_by_membership"][t] = {"side": side, "not_applicable":
                                                  f"no stable training split for this branch ({src_t})"}
            elif base_pe is not None and side is not None:
                membership_t = mem_t
                # v19: does deleting a branch hurt the examples it was trained on (its own partition) more than
                # the others?  Training-set loss / error change, frozen weights
                lo, er = _per_example(h, bundle, batch)
                # own_* / other_*: END-assignment damage (the split in force at the start checkpoint); after a
                # reassigned history this is not every example the branch trained on, so the INITIAL split's
                # damage (initial_own_* / initial_other_*) is reported beside it when it differs
                splits = [("", membership_t)]
                if membership_initial is not None and t not in mbi and not torch.equal(membership_initial, membership_t):
                    splits.append(("initial_", membership_initial))
                rec = {"side": side, "split_source": src_t, "assignment": "end (start checkpoint)"}
                for pre, mem_ in splits:
                    own = mem_ if side == "a" else ~mem_
                    rec[f"{pre}own_n"], rec[f"{pre}other_n"] = int(own.sum()), int((~own).sum())
                    for nm, after, before in (("loss", lo, base_pe[0]), ("err", er, base_pe[1])):
                        if after is None:
                            continue
                        d = after - before
                        rec[f"{pre}own_{nm}_increase"] = float(d[own].mean()) if own.any() else None
                        rec[f"{pre}other_{nm}_increase"] = float(d[~own].mean()) if (~own).any() else None
                out["damage_by_membership"][t] = rec
        except (GraphError, InvalidDeletion) as ex:
            out["single_deletion"][t] = {"error": f"{type(ex).__name__}: {ex}"}
    if live:
        try:
            out["joint_deletion"] = score(E.delete(model, live, share_params=False))
        except (GraphError, InvalidDeletion) as ex:
            out["joint_deletion"] = {"error": f"{type(ex).__name__}: {ex}"}
    return out


@torch.no_grad()
def sink_profile(model, f0, bundle, batch: int, membership: Optional[torch.Tensor] = None) -> dict:
    """v25: which TRAINING examples depend on the additions, with frozen weights before any repair.  For the
    joint deletion and every single implant deletion: mean per-example loss and error, intact and deleted, and
    their change, within strata of the training set: all; own / other examples of each specialised branch (a
    stable split only); the rare group; examples whose shortcut sign disagrees with the clean label (shortcut
    data); examples whose training label was corrupted (label noise); f0's hardest quarter by its own training
    loss.  f0's error in every stratum is reported beside it (the backbone alone after deletion vs the model the
    history started from).  A memorization-sink reading predicts that deleting a branch hurts its own examples,
    and hard or atypical ones most."""
    tr = bundle.train
    N = len(tr)
    strata: dict[str, torch.Tensor] = {"all": torch.ones(N, dtype=torch.bool)}
    if tr.groups is not None and bool((tr.groups == 1).any()):
        strata["rare_group"] = (tr.groups == 1).cpu()
    yc = tr.y_clean if tr.y_clean is not None else tr.y
    if tr.y_clean is not None and bool((tr.y != tr.y_clean).any()):
        strata["noisy_label"] = (tr.y != tr.y_clean).cpu()
        strata["clean_label"] = (tr.y == tr.y_clean).cpu()
    fl = (bundle.meta or {}).get("feature_layout") or {}
    sc = fl.get("shortcut") if "input_rotation" not in fl else None      # v30: rotated inputs have no shortcut column
    if sc is not None and bundle.task == "classification" and len(tr.X) == 1:
        x = next(iter(tr.X.values()))
        if x.dim() == 2 and int(sc) < x.shape[1]:
            conf = ((x[:, int(sc)] > 0).long() != yc.long()).cpu()
            strata["shortcut_conflict"] = conf
            strata["shortcut_agree"] = ~conf
    lo_f0, er_f0 = _per_example(f0, bundle, batch)
    q = torch.quantile(lo_f0.double(), 0.75)
    strata["f0_hardest_quarter"] = lo_f0 >= q
    strata["f0_easiest_three_quarters"] = lo_f0 < q
    if membership is not None:
        strata["branch_a_examples"] = membership.cpu().bool()
        strata["branch_b_examples"] = ~membership.cpu().bool()
    lo0, er0 = _per_example(model, bundle, batch)

    def summ(lo, er) -> dict:
        out = {}
        for nm, m in strata.items():
            if not bool(m.any()):
                continue
            r = {"n": int(m.sum()), "loss": float(lo[m].mean()), "loss_increase": float((lo - lo0)[m].mean())}
            if er is not None:
                r.update({"err": float(er[m].mean()), "err_increase": float((er - er0)[m].mean())})
            out[nm] = r
        return out
    res = {"strata_definitions": {
        "branch_a_examples": "the stable split's branch-a examples (none for redrawn / quota splits)",
        "shortcut_conflict": "training examples whose shortcut feature sign disagrees with the clean label",
        "noisy_label": "training labels changed by the label-noise corruption",
        "f0_hardest_quarter": "f0's top quarter of per-example training loss"},
        "f0": {nm: {"n": int(m.sum()), "loss": float(lo_f0[m].mean()),
                    **({"err": float(er_f0[m].mean())} if er_f0 is not None else {})}
               for nm, m in strata.items() if bool(m.any())},
        "intact": summ(lo0, er0), "single_deletion": {}, "slots": {}}
    every = sorted((t for t, imp in model.implants.items() if imp.nodes), key=lambda s_: int(s_[1:]))
    tops = [t for t in every if model.implants[t].parent is None]
    try:
        h = E.delete(model, tops, share_params=False)
        res["joint_deletion"] = summ(*_per_example(h, bundle, batch))
    except (GraphError, InvalidDeletion) as ex:
        res["joint_deletion"] = {"error": f"{type(ex).__name__}: {ex}"}
    for t in every:
        res["slots"][t] = model.implants[t].slot
        try:
            h = E.delete(model, [t], share_params=False)
            res["single_deletion"][t] = summ(*_per_example(h, bundle, batch))
        except (GraphError, InvalidDeletion) as ex:
            res["single_deletion"][t] = {"error": f"{type(ex).__name__}: {ex}"}
    return res


def scope_pkeys(model: GraphNet, scope: str) -> Optional[set]:
    """v25: the parameter keys that learn under a repair scope: None = every parameter (full); readout = the
    last parametric layer in topological order; top2 = the last two; first (v29) = the first one."""
    if scope == "full":
        return None
    order = model.topo_order(model.live_nodes())
    pks: list[str] = []
    for n in order:
        pk = model.nodes[n].pkey
        if pk is not None and pk not in pks and pk in model.mods and any(True for _ in model.mods[pk].parameters()):
            pks.append(pk)
    if scope == "first":
        if not pks:
            raise Unsupported("repair_scope=first needs a parametric layer")
        return {pks[0]}
    k = {"readout": 1, "top2": 2}[scope]
    if len(pks) < k:
        raise Unsupported(f"repair_scope={scope} needs at least {k} parametric layers")
    return set(pks[-k:])


def spec_membership(ctx, cfg, bundle, role: str = "trajectory", stage: Optional[str] = None,
                    initial: bool = False) -> Optional[torch.Tensor]:
    """v19 / v20: the stable branch-a membership of the training examples for a specialised parent, or None when
    the partition has no stable membership (redrawn, all examples) or the topology is not specialised.  A fixed
    random split is the one in force at the parent's checkpoint `stage` (final: the split at the end of
    training; an earlier checkpoint of a reassigned split: the initial split with every event strictly before
    that checkpoint's job update replayed); initial=True gives the split at the start of training.  Group and
    label partitions are recomputed from their definition."""
    g = cfg.get("growth") or {}
    if g.get("topology") != "specialized" or g.get("specialize") not in ("class_halves", "class_halves_oracle"):
        return None
    mode = g.get("spec_partition", "auto")
    if mode in ("redrawn_random", "all_examples", "matched_quota"):
        return None
    if mode == "random_matched":
        pdir = ctx.parent_dir(role)
        f0p, ffp = pdir / "spec_partition.pt", pdir / "spec_partition_final.pt"
        if not f0p.exists():
            return None
        ind0 = torch.load(f0p, map_location="cpu", weights_only=False)
        ra = (g.get("spec_reassign") or {}).get("mode", "none")
        if initial or ra == "none":
            return ind0.bool()
        if stage in (None, "", "final"):
            return torch.load(ffp, map_location="cpu", weights_only=False).bool() if ffp.exists() else None
        from .trajectory import replay_reassign
        from ..config import seed_of as _seed
        ck = torch.load(pdir / "ckpt" / f"{stage}.pt", map_location="cpu", weights_only=False)
        bk = torch.load(pdir / "ckpt" / "baseline_ref.pt", map_location="cpu", weights_only=False)
        st = (ck.get("trainer") or {}).get("state") or {}
        bt = ((bk.get("trainer") or (bk.get("extra") or {}).get("trainer")) or {}).get("state") or {}
        u = int(st.get("global_step", 0)) - int(bt.get("global_step", 0))
        total = int(g.get("rounds", 1)) * int(g.get("updates_per_round", 0))
        split, _, _ = replay_reassign(ind0, g, total, _seed(cfg, "partition"), u)
        return split.bool()
    if mode == "cyclic_blocks":
        # v22: the cyclic assignment in force at the checkpoint's global step (initial: at the job's first update)
        from .trajectory import cyclic_membership, cyclic_a_len
        pdir = ctx.parent_dir(role)
        if not (pdir / "spec_phase.pt").exists():
            return None
        ph = torch.load(pdir / "spec_phase.pt", map_location="cpu", weights_only=False)
        T = int(g["spec_block_period"])
        frac = g.get("spec_random_fraction")
        if frac is None:
            tr_ = bundle.train
            frac = 0.5 if tr_.groups is None else float((tr_.groups == 0).float().mean())
        nm = "baseline_ref" if initial else ("final" if stage in (None, "", "final") else stage)
        ck = torch.load(pdir / "ckpt" / f"{nm}.pt", map_location="cpu", weights_only=False)
        st = (ck.get("trainer") or (ck.get("extra") or {}).get("trainer") or {}).get("state") or {}
        return cyclic_membership(ph, int(st.get("global_step", 0)), T, cyclic_a_len(frac, T)).bool()
    from .trajectory import _spec_split
    return _spec_split(bundle.train, bundle, mode, g.get("specialize") == "class_halves_oracle", None).cpu().bool()


def branch_ages(model: GraphNet, ck: dict, bk: dict, upr: int) -> dict:
    """v20: the training age (job updates since insertion) of every specialised branch at a checkpoint: a branch
    of round r was inserted at job update (r - 1) x updates_per_round."""
    st = (ck.get("trainer") or {}).get("state") or {}
    bt = ((bk.get("trainer") or (bk.get("extra") or {}).get("trainer")) or {}).get("state") or {}
    u = int(st.get("global_step", 0)) - int(bt.get("global_step", 0))
    out = {}
    for t, imp in model.implants.items():
        # the round is read from the slot (spec/r<k>/a): a branch's Implant.round is its group's round
        m = re.match(r"spec/r(\d+)/[ab]$", str(imp.slot or ""))
        if imp.nodes and m:
            out[imp.slot] = u - (int(m.group(1)) - 1) * int(upr)
    return {"checkpoint_job_update": u, "updates_per_round": int(upr), "ages": out}


def swap_players(model: GraphNet) -> list[str]:
    """v20: the disjoint specialised branch players (slots spec/r<k>/a|b), sorted; parent containers (the group
    spec/G) are not players: deleting or copying a container and its children can be the same operation."""
    return sorted(imp.slot for imp in model.implants.values() if imp.nodes and branch_side(imp.slot) is not None)


def make_hybrid(g: GraphNet, donor: GraphNet, slots: list) -> dict:
    """v19: copy, IN PLACE into g (the receiver), the parameters and buffers of the implants named by `slots`
    (implant slot labels; ["all"] = every implant) and of their descendants from `donor`.  The two graphs must be
    structurally identical (same live graph, sharing and dimensions); a module shared between a selected implant
    and anything outside the selection is refused (copying it would also change the receiver's backbone)."""
    if g.structural_hash() != donor.structural_hash():
        raise Unsupported("hybrid: receiver and donor graphs are not structurally identical")
    if sorted(g.nodes) != sorted(donor.nodes) or any(g.nodes[n].pkey != donor.nodes[n].pkey for n in g.nodes):
        raise Unsupported("hybrid: receiver and donor differ in node ids or parameter keys")
    if slots == ["all"]:
        chosen = {t for t, imp in g.implants.items() if imp.nodes}
    else:
        by_slot = {imp.slot: t for t, imp in g.implants.items()}
        missing = [sl for sl in slots if sl not in by_slot]
        if missing:
            raise Unsupported(f"hybrid: no implant with slot(s) {missing}")
        chosen = {by_slot[sl] for sl in slots}
    for t in list(chosen):
        chosen |= set(g.implant_descendants(t))
    keys_in = {g.nodes[n].pkey for t in chosen for n in g.implants[t].nodes if g.nodes[n].pkey}
    keys_out = {g.nodes[n].pkey for n in g.live_nodes() if g.nodes[n].pkey and g.nodes[n].owner not in chosen}
    shared = sorted(keys_in & keys_out)
    if shared:
        raise Unsupported(f"hybrid: modules {shared} are shared between the swapped implants and the rest")
    n_par, d2, r2 = 0, 0.0, 0.0
    with torch.no_grad():
        for k in sorted(keys_in, key=str):
            src, dst = donor.mods[k].state_dict(), g.mods[k].state_dict()
            for name, v in src.items():
                if dst[name].shape != v.shape:
                    raise Unsupported(f"hybrid: shape mismatch in {k}.{name}")
                if v.is_floating_point():
                    d2 += float(((dst[name].double() - v.double().to(dst[name].device)) ** 2).sum())
                    r2 += float((dst[name].double() ** 2).sum())
                    n_par += int(v.numel())
            g.mods[k].load_state_dict({nm: v.to(dst[nm].device) for nm, v in src.items()})
    g._plan = None
    return {"implants": sorted(chosen, key=lambda s_: int(s_[1:])),
            "slots": sorted(g.implants[t].slot for t in chosen), "modules": sorted(keys_in, key=str),
            "values_copied": n_par, "receiver_minus_donor_rel_l2": (d2 / r2) ** 0.5 if r2 > 0 else None}


@torch.no_grad()
def node_values(model: GraphNet, part, nodes: list, batch: int) -> dict:
    """values of graph nodes on a partition (eval mode, the model's dtype), concatenated over batches, on CPU."""
    from ..train.trainer import model_dtype
    dt = model_dtype(model)
    was = model.training
    model.eval()
    outs = {n: [] for n in nodes}
    for i in range(0, len(part), batch):
        X = {k: (v[i:i + batch].to(dt) if v.is_floating_point() else v[i:i + batch]) for k, v in part.X.items()}
        _, vals = model(X, return_nodes=list(nodes))
        for n in nodes:
            outs[n].append(vals[n].double().cpu())
    model.train(was)
    return {n: torch.cat(v) for n, v in outs.items()}


def _branch_out_linear(g: GraphNet, t: str) -> Optional[str]:
    """the linear node producing a branch's term (the exit, or the input of a gradient-mask exit); None when the
    term is not produced by a linear layer owned by the branch (no exact affine fold)."""
    imp = g.implants[t]
    n = imp.exit
    if n is not None and g.nodes[n].op == "mask_grad":
        n = g.nodes[n].inputs[0]
    if n is None or g.nodes[n].op != "linear" or g.nodes[n].owner != t:
        return None
    return n


ALIGN_OK = ("fitted", "identity_fallback")


def _fold_branch(h: GraphNet, lin: str, A: torch.Tensor, c: torch.Tensor) -> None:
    """fold T(y) = y A + c into the branch's last linear layer IN PLACE (W' = A^T W, b' = A^T b + c).  The caller
    has checked that the layer can represent the offset (a bias, or c == 0)."""
    m = h.mods[h.nodes[lin].pkey]
    W = m.weight.double()
    A_, c_ = A.to(W.device, torch.float64), c.to(W.device, torch.float64)
    if m.bias is not None:
        bb = m.bias.double()
        m.bias.copy_((A_.T @ bb + c_).to(m.bias.dtype))
    m.weight.copy_((A_.T @ W).to(m.weight.dtype))


def retained_mask_ctx(bundle, membership: Optional[torch.Tensor], gcfg: dict, holder: Optional[dict] = None):
    """v41: the gradient-mask context of a removal / keep job with removal_masks=retained.  membership (the
    parent's branch-a split, random_matched) is put on the training partition as the trajectory does; the parent's
    mask route (forward / parameter) is kept; holder ({'tr': trainer}) lets spec_masks record the per-example
    gradient ELIGIBILITY in the trainer state (eligibility, not a proof that each gradient was nonzero)."""
    from .trajectory import spec_masks
    pmode = gcfg.get("spec_partition", "auto")
    if membership is not None:
        bundle.train.aux["_spec_random"] = membership.long().to(bundle.train.y.device)
    return spec_masks(bundle, oracle_clean=gcfg.get("specialize") == "class_halves_oracle", mode=pmode,
                      holder=holder, forward=gcfg.get("spec_mask_route") == "forward",
                      param_only=gcfg.get("spec_mask_route") == "parameter")


def eligibility_record(tr, bundle) -> dict:
    """v41: the gradient-eligibility counts spec_masks recorded (holder wired), and whether, for every example
    seen, eligibility for branch a matches the split on the training partition (aux _spec_random) exactly."""
    ex = dict(tr.state.get("spec_exposure") or {})
    pe = (tr.state.get("spec_exposure_pe") or {}).get("0")
    out = {"counts": ex}
    mem = bundle.train.aux.get("_spec_random")
    if pe is not None and mem is not None:
        n_ = torch.tensor(pe["n"])
        a_ = torch.tensor(pe["a"])
        b_ = torch.tensor(pe["b"])
        seen = n_ > 0
        m_ = mem.bool().cpu()
        out.update({"examples_seen": int(seen.sum()),
                    "a_matches_split": bool(((a_[seen] == n_[seen]) == m_[seen]).all() and
                                            ((a_[seen] == 0) == ~m_[seen]).all()),
                    "b_is_complement": bool((a_[seen] + b_[seen] == n_[seen]).all())})
    return out


def opt_state_digest(opt, names: list) -> dict:
    """v41: a checksum of an optimizer's per-tensor state by parameter name ('pkey.name'), with the step counters'
    range and the number of tensors that hold state."""
    from ..utils import stable_hash, tensor_hash
    flat = [p for gp in opt.param_groups for p in gp["params"]] if opt is not None else []
    per, steps_ = {}, []
    for p, n in zip(flat, names):
        stt = opt.state.get(p) or {}
        if stt:
            per[n] = {k: (tensor_hash(v) if isinstance(v, torch.Tensor) else repr(v)) for k, v in sorted(stt.items())}
            if "step" in stt:
                steps_.append(float(stt["step"]))
    return {"digest": stable_hash(per), "tensors_with_state": len(per), "tensors": len(flat),
            "step_min": min(steps_) if steps_ else None, "step_max": max(steps_) if steps_ else None}


def parent_opt_digest(ck: dict, names: list) -> dict:
    """v41: opt_state_digest of a checkpoint's saved optimizer state for the given parameter names."""
    from ..utils import stable_hash, tensor_hash
    pt = ck.get("trainer") or {}
    pn, opt = pt.get("opt_param_names") or [], pt.get("opt") or {}
    idx = {n: i for i, n in enumerate(pn)}
    per, steps_ = {}, []
    for n in names:
        i = idx.get(n)
        stt = (opt.get("state") or {}).get(i) if i is not None else None
        if stt:
            per[n] = {k: (tensor_hash(v) if isinstance(v, torch.Tensor) else repr(v)) for k, v in sorted(stt.items())}
            if "step" in stt:
                steps_.append(float(stt["step"]))
    return {"digest": stable_hash(per), "tensors_with_state": len(per), "tensors": len(names),
            "step_min": min(steps_) if steps_ else None, "step_max": max(steps_) if steps_ else None}


@torch.no_grad()
def align_swapped(h: GraphNet, receiver: GraphNet, slots: list, bundle, batch: int, ridge: float = 1e-8,
                  maps: Optional[dict] = None) -> dict:
    """v20 (review item 7): a simple fitted interface alignment for swapped-in branches, IN PLACE on h.  For each
    swapped branch, the affine map T(y) = y A + c from the swapped branch's term to the receiver's own branch term
    in the same slot is fitted by (ridge) least squares on TRAINING inputs, everything else frozen, and folded
    exactly into the branch's last linear layer (W' = A^T W, b' = A^T b + c).  Capacity: d x d + d values per
    branch.  The branches of one group read the same backbone value, so the fits do not interact.
    v34: every branch has a status: fitted; identity_fallback (the fit's training residual is not below the raw
    residual, so no adapter is applied); unsupported (the term is not a vector produced by a linear layer of the
    branch, or the layer has no bias for a nonzero offset); numerical_failure (non-finite branch terms or map).
    Representability is checked BEFORE any parameter changes, so an unsupported branch leaves h untouched.
    out['ok'] is True only when every branch is fitted or identity_fallback.  maps (optional dict) receives
    slot -> {'A', 'c'} (float64, CPU) for every fitted branch and slot -> None for an identity fallback."""
    import time as _time
    t_start = _time.time()
    by_slot_h = {imp.slot: t for t, imp in h.implants.items()}
    by_slot_r = {imp.slot: t for t, imp in receiver.implants.items()}
    out = {"fitted_on": "train", "ridge": ridge, "branches": {}, "params": 0, "train_examples": len(bundle.train),
           "solve_macs": 0, "forward_macs": 0}
    fwd_one = (forward_macs(h, C.seq_T(bundle), {}) + forward_macs(receiver, C.seq_T(bundle), {})) * len(bundle.train)
    for sl in slots:
        th, tr_ = by_slot_h[sl], by_slot_r[sl]
        lin = _branch_out_linear(h, th)
        tgt_node = _branch_out_linear(receiver, tr_)
        if lin is None or tgt_node is None:
            out["branches"][sl] = {"status": "unsupported",
                                   "reason": "branch term is not produced by a linear layer of the branch"}
            continue
        y = node_values(h, bundle.train, [lin], batch)[lin]
        t_ = node_values(receiver, bundle.train, [tgt_node], batch)[tgt_node]
        if y.dim() != 2 or t_.dim() != 2:
            out["branches"][sl] = {"status": "unsupported",
                                   "reason": f"branch term of shape {tuple(y.shape)} (vector terms only)"}
            continue
        if not (bool(torch.isfinite(y).all()) and bool(torch.isfinite(t_).all())):
            out["branches"][sl] = {"status": "numerical_failure", "reason": "non-finite branch terms"}
            continue
        Y, T = y.reshape(len(y), -1), t_.reshape(len(t_), -1)
        Y1 = torch.cat([Y, torch.ones(len(Y), 1, dtype=Y.dtype)], 1)
        G = Y1.T @ Y1
        out["solve_macs"] += int(len(Y1) * Y1.shape[1] * (Y1.shape[1] + T.shape[1]) + Y1.shape[1] ** 3)
        out["forward_macs"] += int(fwd_one)          # the hybrid's and the receiver's pass over the training inputs
        lam = ridge * float(G.diagonal().mean().clamp_min(1e-12))
        try:
            beta = torch.linalg.solve(G + lam * torch.eye(G.shape[0], dtype=G.dtype), Y1.T @ T)
        except RuntimeError as ex:                   # a singular system despite the ridge
            out["branches"][sl] = {"status": "numerical_failure", "reason": f"solve failed: {ex}"}
            continue
        A, c = beta[:-1], beta[-1]
        if not (bool(torch.isfinite(A).all()) and bool(torch.isfinite(c).all())):
            out["branches"][sl] = {"status": "numerical_failure", "reason": "non-finite alignment"}
            continue
        den = (T - T.mean(0)).pow(2).sum().clamp_min(1e-30)
        raw = float(((Y - T) ** 2).sum() / den)
        res = float(((Y1 @ beta - T) ** 2).sum() / den)
        npar = int(A.numel() + c.numel())
        if not res < raw:
            # the identity is in the affine family: never keep a (ridge-shrunk) fit that is worse than no adapter
            out["branches"][sl] = {"status": "identity_fallback", "params": npar, "train_rel_residual_raw": raw,
                                   "train_rel_residual_aligned": raw, "kept_identity": True}
            out["params"] += npar
            if maps is not None:
                maps[sl] = None
            continue
        m = h.mods[h.nodes[lin].pkey]
        if m.bias is None and float(c.abs().max()) > 0:
            out["branches"][sl] = {"status": "unsupported", "reason": "branch linear has no bias for the offset",
                                   "train_rel_residual_raw": raw}
            continue
        _fold_branch(h, lin, A, c)
        out["branches"][sl] = {"status": "fitted", "params": npar, "train_rel_residual_raw": raw,
                               "train_rel_residual_aligned": res, "kept_identity": False}
        out["params"] += npar
        if maps is not None:
            maps[sl] = {"A": A.detach().cpu().clone(), "c": c.detach().cpu().clone()}
    h._plan = None
    out["ok"] = all(b.get("status") in ALIGN_OK for b in out["branches"].values()) and \
        set(out["branches"]) == set(slots)
    out["status_counts"] = {k: sum(b.get("status") == k for b in out["branches"].values())
                            for k in ("fitted", "identity_fallback", "unsupported", "numerical_failure")}
    out["fit_seconds"] = _time.time() - t_start
    out["fit_macs_total"] = int(out["solve_macs"] + out["forward_macs"])
    out["cost_note"] = ("fitting work: one forward pass of the hybrid and of the receiver over the training inputs per "
                        "swapped branch (forward_macs) plus the normal equations (solve_macs); no gradient steps.  "
                        "Fitting capacity: 'params' fitted values.  Inference: the map is folded into the branch's "
                        "last linear layer, so it adds no parameters or MACs to the deployed model")
    return out


@torch.no_grad()
def apply_saved_alignment(h: GraphNet, maps: dict) -> None:
    """v34: refold saved maps (align_swapped(maps=...)) into a fresh hybrid h, IN PLACE; None = identity."""
    by_slot = {imp.slot: t for t, imp in h.implants.items()}
    for sl, mp in maps.items():
        if mp is None:
            continue
        lin = _branch_out_linear(h, by_slot[sl])
        if lin is None:
            raise Unsupported(f"saved alignment for {sl}: no branch linear layer")
        _fold_branch(h, lin, mp["A"], mp["c"])
    h._plan = None


@torch.no_grad()
def transfer_models(receiver: GraphNet, donor: GraphNet, slots: list, bundle, batch: int, align: bool = True,
                    maps: Optional[dict] = None) -> dict:
    """v34: the donor's branches `slots` copied into a copy of the receiver ('raw'), and (align) a second copy with
    the interface alignment of align_swapped ('aligned', 'adapter').  The receiver and the donor are not modified."""
    h = receiver.clone(share_params=False)
    info = make_hybrid(h, donor, slots) if slots else {"values_copied": 0, "receiver_minus_donor_rel_l2": None}
    out = {"raw": h, "info": info}
    if align and slots:
        ha = h.clone(share_params=False)
        out["adapter"] = align_swapped(ha, receiver, slots, bundle, batch, maps=maps)
        out["aligned"] = ha
    return out


@torch.no_grad()
def swap_scan(receiver: GraphNet, donor: GraphNet, bundle, batch: int, align: bool = True) -> dict:
    """v20 (review item 7): every subset of the disjoint specialised branch players (2^n, n <= 6; the empty set is
    the receiver) copied from the donor into a copy of the receiver, scored with frozen weights: task risk / error
    on val and test, the function change from the receiver and from the donor (val output RMS difference, class
    flip rate), raw and after the affine interface alignment of the swapped branches (align_swapped).  Native
    scores of both models are recorded.  Nothing is trained; validation decides, test is for reporting."""
    players = swap_players(receiver)
    if not players or len(players) > 6:
        raise Unsupported(f"swap scan needs 1..6 specialised branch players, found {len(players)}")
    if swap_players(donor) != players:
        raise Unsupported("swap scan: receiver and donor have different branch players")
    parts = [p for p in ("val", "test") if p in bundle.partitions()]
    pv = bundle.partitions()

    def score(m):
        res, _ = evaluate(m, bundle, parts, batch)
        return {p: {"risk": M.headline(res[p], bundle.task),
                    **({"err": 1.0 - res[p]["acc"]} if "acc" in res[p] else {})} for p in parts}
    ref = {nm: predict(mm, pv["val"], batch).double().cpu() for nm, mm in (("receiver", receiver), ("donor", donor))}

    def fchange(m):
        o = predict(m, pv["val"], batch).double().cpu()
        rec = {}
        for nm, r in ref.items():
            rec[f"val_rms_diff_from_{nm}"] = float(((o - r) ** 2).mean().sqrt())
            if bundle.task == "classification":
                rec[f"val_flip_rate_from_{nm}"] = float((o.argmax(-1) != r.argmax(-1)).double().mean())
        return rec
    own = {}
    for n in receiver.nodes.values():
        if n.pkey:
            own.setdefault(n.pkey, set()).add(n.owner)
    numel = lambda k: sum(p.numel() for p in receiver.mods[k].parameters())
    by_slot = {imp.slot: t for t, imp in receiver.implants.items()}
    out = {"players": players, "native": {"receiver": score(receiver), "donor": score(donor)},
           "backbone_params": int(sum(numel(k) for k, o in own.items() if o == {None})),
           "player_params": {sl: int(sum(numel(k) for k, o in own.items() if o == {by_slot[sl]})) for sl in players},
           "alignment": ("affine map from the swapped branch term to the receiver's branch term in the same slot, "
                         "least squares on training inputs, everything else frozen" if align else None),
           "subsets": []}
    for mask in range(2 ** len(players)):
        sub = [players[i] for i in range(len(players)) if (mask >> i) & 1]
        t = transfer_models(receiver, donor, sub, bundle, batch, align=align)
        info = t["info"]
        row = {"subset": sub, "n_players": len(sub), "values_copied": info["values_copied"],
               "receiver_minus_donor_rel_l2": info["receiver_minus_donor_rel_l2"],
               "raw": {**score(t["raw"]), "function": fchange(t["raw"])}}
        if "aligned" in t:
            row["aligned"] = {**score(t["aligned"]), "function": fchange(t["aligned"]), "adapter": t["adapter"]}
        out["subsets"].append(row)
        del t
    return out


@torch.no_grad()
def rebuild_state(ctx, g: GraphNet, f0: GraphNet, backbone: str, implants: str, rounds: int) -> dict:
    """v22: rebuild the start state IN PLACE from its parts.  backbone=f0: every module not owned by an implant is
    copied from the untouched f0 (the baseline the trajectory started from); implants=fresh: every implant module
    is reset to its state at insertion (the earliest post_insert_r<k> checkpoint holding it), i.e. the
    function-preserving additions before any training.  f0 + fresh is the same final graph with all additions
    still function-preserving and no intervening training (checked against f0's predictions by the caller)."""
    sd = g.state_dict()
    owner_of = {}
    for n in g.nodes.values():
        if n.pkey:
            owner_of.setdefault(n.pkey, set()).add(n.owner)
    mixed = sorted(k for k, o in owner_of.items() if None in o and len(o) > 1)
    if mixed:
        raise Unsupported(f"rebuild: modules {mixed} are shared between the backbone and an implant")
    imp_keys = {k for k, o in owner_of.items() if None not in o}
    src = {}
    if implants == "fresh":
        for r in range(1, int(rounds) + 1):
            nm = f"post_insert_r{r}"
            if not (ctx.parent_dir("trajectory") / "ckpt" / f"{nm}.pt").exists():
                continue
            st = ctx.load_ckpt(nm, ctx.parent_dir("trajectory"))["model"]["state"]
            for k, v in st.items():
                if k.split(".")[1] in imp_keys:
                    src.setdefault(k, v)                  # earliest post-insertion state = state at insertion
    f0s = f0.state_dict() if backbone == "f0" else {}
    new, n_bb, n_imp = {}, 0, 0
    for k, v in sd.items():
        p = k.split(".")[1] if k.startswith("mods.") else None
        if p in imp_keys and implants == "fresh":
            if k not in src:
                raise Unsupported(f"rebuild: no insertion state for {k}")
            new[k] = src[k].to(v.device, v.dtype)
            n_imp += 1
        elif p is not None and p not in imp_keys and backbone == "f0":
            if k not in f0s or f0s[k].shape != v.shape:
                raise Unsupported(f"rebuild: backbone tensor {k} is not in f0 with the same shape")
            new[k] = f0s[k].to(v.device, v.dtype)
            n_bb += 1
    g.load_state_dict({**sd, **new})
    g._plan = None
    return {"backbone": backbone, "implants": implants, "backbone_tensors_from_f0": n_bb,
            "implant_tensors_reset_to_insertion": n_imp}


@torch.no_grad()
def pristine_certificate(g: GraphNet, f0: GraphNet, bundle, batch: int) -> dict:
    """v23: why the rebuilt state (f0 backbone, every implant at insertion) computes f0, for the specialised
    sum-branch architecture only:
      structure   every branch implant's term comes from a linear layer of the branch whose weight and bias are
                  EXACTLY zero (its term is 0 for every input), and every other implant holds only parameter-free
                  sum merges ('add') and pass-through nodes ('identity'); anything else is refused (unsupported)
      backbone    every tensor of a module owned by no implant equals f0's tensor exactly
      function    float64 copies of both models agree on train / val / test to 1e-12 relative (an exact zero term
                  added to a float64 sum leaves it unchanged, so this is an identity up to f0's own evaluation)"""
    bad, zero_terms = [], 0
    for t, imp in g.implants.items():
        if not imp.nodes:
            continue
        if imp.kind == "branch":
            lin = _branch_out_linear(g, t)
            if lin is None:
                bad.append(f"{t}: branch term not produced by a linear layer of the branch")
                continue
            m = g.mods[g.nodes[lin].pkey]
            if bool(m.weight.ne(0).any()) or (m.bias is not None and bool(m.bias.ne(0).any())):
                bad.append(f"{t}: branch output layer is not exactly zero")
            zero_terms += 1
        else:
            ops = {g.nodes[n].op for n in imp.nodes}
            if not ops <= {"add", "identity"} or any(g.nodes[n].pkey for n in imp.nodes):
                bad.append(f"{t}: container holds {sorted(ops)} (only parameter-free sum merges and identities are "
                           f"certified)")
    if bad:
        raise Unsupported("rebuild certificate: " + "; ".join(bad))
    sd, fs = g.state_dict(), f0.state_dict()
    owners = {}
    for n in g.nodes.values():
        if n.pkey:
            owners.setdefault(n.pkey, set()).add(n.owner)
    bb_keys = [k for k in sd if k.startswith("mods.") and owners.get(k.split(".")[1]) == {None}]
    bb_equal = all(k in fs and torch.equal(sd[k].cpu(), fs[k].cpu()) for k in bb_keys)
    g64, f64 = g.clone(share_params=False).double(), f0.clone(share_params=False).double()
    fn = {}
    ok_fn = True
    for part in ("train", "val", "test"):
        if part not in bundle.partitions():
            continue
        a_ = predict(g64, bundle.partitions()[part], batch).double().cpu()
        b_ = predict(f64, bundle.partitions()[part], batch).double().cpu()
        d_ = float((a_ - b_).abs().max())
        sc = max(1.0, float(b_.abs().max()))
        fn[part] = {"max_abs_diff": d_, "scale": sc}
        ok_fn = ok_fn and d_ <= 1e-12 * sc
    return {"passed": bool(bb_equal and ok_fn), "zero_branch_terms": zero_terms,
            "backbone_tensors_equal_f0": bool(bb_equal), "backbone_tensors": len(bb_keys), "float64": fn,
            "tolerance": "max |difference| <= 1e-12 x max(1, max |f0 output|), float64 copies"}


def fold_receiver_problems(g: GraphNet, targets: list) -> list:
    """v65: why the additions `targets` cannot be folded into the layer that reads their merge (empty: they can).
    The fold needs one backbone linear layer reading the merge (position-wise: a 1x1 layer in an image network),
    so W A and b + W c compose exactly at every position.  A padded spatial convolution cannot absorb an affine
    offset exactly: fewer offset terms reach its border positions, which one spatially constant bias cannot
    reproduce."""
    out = []
    for t in targets:
        cons = g.consumers(g.implants[t].exit)
        nd = g.nodes[cons[0][0]] if len(cons) == 1 else None
        if nd is None or nd.op != "linear" or nd.owner is not None:
            out.append(f"the merge of {t} is read by {[g.nodes[c].op for c, _ in cons]}; the fold needs one "
                       f"backbone linear (1x1) layer to compose into (a padded spatial convolution cannot absorb "
                       f"the offset at the border)")
    return out


def run_dissipation(ctx) -> dict:
    cfg = ctx.cfg
    dc = cfg["dissipation"]
    bundle = C.setup_data(ctx)
    stage0 = (cfg.get("tags") or {}).get("parent_stage", "final")       # e.g. snap_<u> (mechanism B), round_<k>
    ck0 = ctx.parent_ckpt("trajectory", stage0)
    bk0 = ctx.parent_ckpt("trajectory", "baseline_ref")
    g = GraphNet.from_checkpoint(ck0["model"], ctx.device)
    batch = cfg["train"]["eval_batch"]
    upr_t = int((cfg.get("growth") or {}).get("updates_per_round", 0) or 0)
    ages = branch_ages(g, ck0, bk0, upr_t) if swap_players(g) else None
    hy = dc.get("hybrid") or {}
    hybrid_info = None
    pv0 = bundle.partitions()
    # v20 (review item 7): the declared recovery references: f0's val risk (original task performance), the
    # receiver's own val risk and val outputs (the recipient's task performance and function) before any swap
    recovery_ref = {"receiver_val_risk": M.headline(evaluate(g, bundle, ["val"], batch)[0]["val"], bundle.task)}
    recv_val_out = predict(g, pv0["val"], batch).double().cpu()
    recovery_ref["receiver_val_out_rms"] = float(recv_val_out.pow(2).mean().sqrt())
    rb = dc.get("rebuild") or {}
    rebuild_info = None
    if rb.get("backbone", "receiver") != "receiver" or rb.get("implants", "receiver") != "receiver":
        # v22: the receiver (references above) is the trained state; the job starts from the rebuilt one
        f0_rb = GraphNet.from_checkpoint(bk0["model"], ctx.device)
        rebuild_info = rebuild_state(ctx, g, f0_rb, rb.get("backbone", "receiver"), rb.get("implants", "receiver"),
                                     int((cfg.get("growth") or {}).get("rounds", 1)))
        if rebuild_info["backbone"] == "f0" and rebuild_info["implants"] == "fresh":
            cert = pristine_certificate(g, f0_rb, bundle, batch)
            rebuild_info["certificate"] = cert
            rebuild_info["max_abs_diff_from_f0_val"] = cert["float64"]["val"]["max_abs_diff"]
            if not cert["passed"]:
                raise ScientificInvalid("rebuild: f0 backbone with fresh implants failed the neutrality certificate",
                                        cert)
        if rebuild_info["implants"] == "fresh":
            ages = {"checkpoint_job_update": None, "ages": {k: 0 for k in (ages or {}).get("ages", {})},
                    "note": "implants reset to their insertion state"}
        del f0_rb
    if hy.get("donor_role"):
        # v19 swap experiment: the receiver's backbone (and its non-selected implants) with the donor's selected
        # implants; deterministic, so a resumed job rebuilds the same start state before its first step
        dck = ctx.parent_ckpt(hy["donor_role"], hy["donor_stage"])
        donor = GraphNet.from_checkpoint(dck["model"], ctx.device)
        recovery_ref["donor_val_risk"] = M.headline(evaluate(donor, bundle, ["val"], batch)[0]["val"], bundle.task)
        dcfg0 = ctx.parent_json(hy["donor_role"], "config.json")
        dbk = ctx.parent_ckpt(hy["donor_role"], "baseline_ref")
        hybrid_info = {"donor_role": hy["donor_role"], "donor_stage": hy["donor_stage"], "receiver_stage": stage0,
                       **make_hybrid(g, donor, list(hy["slots"])),
                       "receiver_branch_ages": ages,
                       "donor_branch_ages": branch_ages(donor, dck, dbk, int((dcfg0.get("growth") or {})
                                                                             .get("updates_per_round", 0) or 0))}
        del donor, dck, dbk
    from ..utils import tensor_hash as _th, stable_hash as _sh
    parent_state_hash = _sh({k_: _th(v_) for k_, v_ in sorted(ck0["model"]["state"].items())})
    del ck0
    from ..graph.accounting import architecture_hash, report as acct_report
    f0 = GraphNet.from_checkpoint(bk0["model"], ctx.device)
    del bk0
    f0_arch = architecture_hash(f0)
    recovery_ref["f0_val_risk"] = M.headline(evaluate(f0, bundle, ["val"], batch)[0]["val"], bundle.task)
    # v20 (review item 5): the removal policy, explicit
    gcfg = cfg.get("growth") or {}
    removal_policy = {"masks": dc["removal_masks"], "gate_schedule": dc["gate_schedule"],
                      "optimizer": dc["optimizer_policy"],
                      "optimizer_note": ("every training phase (transition, repair) starts with a fresh optimizer state"
                                         if dc["optimizer_policy"] == "reset_each_phase" else
                                         "v39: the keep phase continues the parent checkpoint's optimizer state "
                                         "(every trainable tensor, matched by name)"),
                      "masks_note": ("released: every branch receives every example's gradient during removal"
                                     if dc["removal_masks"] == "released" else
                                     "retained: the specialised branches keep the gradient masks of the split in "
                                     "force at the start checkpoint (gradients only; the forward route is unchanged)"),
                      "gate_note": ("anneal: gates follow the method's schedule" if dc["gate_schedule"] == "anneal"
                                    else "hold: gates stay at 1 during the transition, then the additions are removed")}
    mask_ctx = None
    mask_holder: dict = {}
    if dc["removal_masks"] == "retained":
        if gcfg.get("topology") != "specialized" or gcfg.get("specialize") not in ("class_halves",
                                                                                  "class_halves_oracle"):
            raise Unsupported("removal_masks=retained needs a specialised (class_halves) parent")
        pmode = gcfg.get("spec_partition", "auto")
        if pmode in ("redrawn_random", "cyclic_blocks", "matched_quota"):
            raise Unsupported(f"removal_masks=retained: a {pmode} split has no stable membership")
        mem_r = None
        if pmode == "random_matched":
            mem_r = spec_membership(ctx, cfg, bundle, stage=stage0)
            if mem_r is None:
                raise Unsupported("removal_masks=retained: the parent's split is not available")
            from ..utils import tensor_hash as _thm
            removal_policy["membership"] = f"the parent's split in force at checkpoint {stage0}"
            removal_policy["membership_hash"] = _thm(mem_r.bool().cpu())
            removal_policy["membership_branch_a"] = int(mem_r.bool().sum())
        else:
            removal_policy["membership"] = f"recomputed from the partition definition ({pmode})"
        removal_policy["mask_route"] = gcfg.get("spec_mask_route", "gradient")
        # v39 / v41: the parent's mask route; the trainer is attached below so the eligibility is recorded
        mask_ctx = retained_mask_ctx(bundle, mem_r, gcfg, holder=mask_holder)
    targets = _targets(g, dc["targets"])
    if not targets:
        raise Unsupported("no target implants")
    phases = _ordered(g, targets, dc["order"])
    method = dc["method"]
    # v65: the mechanism forks (keep_swap, keep_shift50, keep_shift100) are the keep fork from a function-preserving
    # redistribution of the additions' computation (cop.graph.redistribute), applied to the start state
    from ..graph.redistribute import REDISTRIBUTIONS
    method_name = method
    redist = method if method in REDISTRIBUTIONS else None
    if redist is not None:
        method = "keep"
    # P1 (v5): non-mutating diagnostics of every target on the expanded model, before any contraction
    from .diagnostics import contraction_diagnostics
    contraction_diagnostics(ctx, g, bundle, sorted(set(targets), key=lambda s_: int(s_[1:])), "dissipation_start")
    if method == "inverse_restore" and not inverse_pairs(g, [t for ph in phases for t in ph]):
        raise Unsupported("inverse_restore needs inverse-pair targets")
    if method == "branch_merge" and not branch_merge(g.clone(share_params=False), [t for ph in phases for t in ph]):
        raise Unsupported("branch_merge needs groups with >=2 untied branches of equal architecture")
    if method == "fold":
        bad = [t for t in targets if not (g.implants[t].deletion == "fold" or E.region_is_affine(g, g.region(t)))]
        if bad:
            raise Unsupported(f"fold needs affine targets; not affine: {bad}")
    if method == "fold_unrouted":
        # v59: affine apart from gradient-mask nodes; the fold ends the routing (the folded weights train on every
        # example), which is the point of this method and is recorded in the result
        bad = [t for t in targets if g.implants[t].meta.get("conv") or not E.region_is_affine(
            g, set(g.region(t)) - set(E.grad_mask_nodes(g, g.region(t))))]
        if bad:
            raise Unsupported(f"fold_unrouted needs vector targets affine apart from gradient masks: {bad}")
        # v65: the fold must compose into the layer that reads the merge: one backbone linear layer (position-wise;
        # in an image network a 1x1 layer).  A padded spatial convolution cannot absorb an affine offset exactly
        # (fewer offset terms reach it at the border), so it is refused before anything is trained
        bad_r = fold_receiver_problems(g, targets)
        if bad_r:
            raise Unsupported("fold_unrouted: " + "; ".join(bad_r))
    if redist is not None:
        if dc["optimizer_policy"] != "reset_each_phase":
            raise Unsupported(f"{method_name}: the redistribution forks start a fresh optimizer")
        from ..graph.redistribute import the_group, branch_pairs, receiving_layer
        try:
            G_ = the_group(g)
            branch_pairs(g, G_)
            receiving_layer(g, G_)
        except GraphError as ex_:
            raise Unsupported(f"{method_name}: {ex_}")
    if method in ("linear", "cosine", "group_removal", "stochastic_bypass"):
        probe = g.clone(share_params=False)
        try:
            for t in sorted({t for ph in phases for t in ph}, key=lambda s_: int(s_[1:])):
                if t in probe.implants:
                    E.add_gate(probe, t)
        except GraphError as ex:
            raise Unsupported(f"{method} needs gateable targets: {ex}")
    tr = Trainer(g, bundle, cfg["train"], {"minibatch": seed_of(cfg, "repair"), "augmentation": seed_of(cfg, "repair")},
                 ctx.device, ctx.log, "dissipation")
    mask_holder["tr"] = tr
    st = {"model": g, "path": [], "upd": 0, "vars": {}}
    # v31: the ordered stream of training-example ids this job draws, as a hash chain in the trainer state (resume-
    # safe), so forks of one parent can be checked to have seen the same minibatches
    import hashlib as _hl
    bundle.train.aux["_index"] = torch.arange(len(bundle.train), device=bundle.train.y.device)
    _nb = tr.next_batch

    def _nb_hashed():
        b_ = _nb()
        ids = b_.aux.get("_index")
        if ids is not None:
            tr.state["batch_id_hash"] = _hl.sha256(str(tr.state.get("batch_id_hash", "")).encode()
                                                   + ids.detach().cpu().numpy().tobytes()).hexdigest()[:24]
            tr.state["batches_drawn"] = int(tr.state.get("batches_drawn", 0)) + 1
        return b_
    if not cfg["train"].get("audit_batches", False):     # v45: with train.audit_batches the trainer keeps the chain
        tr.next_batch = _nb_hashed

    def event(kind: str, ckpt: Optional[str] = None, model=None, **kw):
        """v31: the edit / optimizer event ledger (with a checkpoint of the state when given)."""
        if ckpt is not None and model is not None:
            ctx.save_ckpt(ckpt, model, None, {"event": kind, "update": int(st["upd"])})
        st["vars"].setdefault("events", []).append({"event": kind, "update": int(st["upd"]), "checkpoint": ckpt, **kw})
    teacher = None
    if dc["target"] == "expanded":
        teacher = g.clone(share_params=False).eval()     # the parent's expanded model, frozen
        for p_ in teacher.parameters():
            p_.requires_grad_(False)
    from ..graph.accounting import count_params
    p_start = count_params(g)["total"]
    steps = _Steps(ctx, st, tr)
    n_pts = max(2, dc["path_eval_points"])
    S = dc["speed_updates"]
    nph = len(phases)

    def share(total: int, k: int, n: int) -> int:
        """Phase k's part of a total budget split over n phases: the total contraction and repair
        budget is the same for every removal order (mechanism D / F06c)."""
        total, n = int(total), max(1, int(n))
        return total // n + (1 if k < total % n else 0)

    Xmon = {k_: v[:min(512, len(bundle.val))] for k_, v in bundle.val.X.items()}

    @torch.no_grad()
    def gated_contribution(model) -> Optional[float]:
        """Mean |gate * (implant output - bypass)| of the gated targets on validation inputs: a
        shrinking gate can be defeated by a growing implant output, so the product is monitored."""
        gids = {gd: t for k_, v in st["vars"].items() if k_.startswith("gidmap_") for t, gd in v.items()}
        if not gids:
            return None
        nodes, pairs = set(), []
        for gd, t in gids.items():
            if t not in model.implants:
                continue
            imp = model.implants[t]
            if imp.kind == "branch":
                pairs.append(("branch", imp.exit, None, gd))
                nodes.add(imp.exit)
            else:
                pairs.append(("series", imp.exit, imp.entry, gd))
                nodes |= {imp.exit, imp.entry}
        live = model.live_nodes()
        pairs = [p_ for p_ in pairs if p_[1] in live and (p_[2] is None or p_[2] in live)]
        nodes = {n_ for p_ in pairs for n_ in (p_[1], p_[2]) if n_ is not None}
        if not pairs:
            return 0.0
        was = model.training
        model.eval()
        _, vals = model({k_: (v.to(next(model.parameters()).dtype) if v.is_floating_point() else v)
                         for k_, v in Xmon.items()}, return_nodes=sorted(nodes))
        model.train(was)
        tot = 0.0
        for kind, ex, en, gd in pairs:
            c_ = model.gate_vals[gd] * vals[ex] if kind == "branch" else vals[ex] - vals[en]
            tot += float(c_.abs().mean())
        return tot / len(pairs)

    sel = C.Selector(ctx, bundle, "dissipation_final_compact_phase", compact_fn=lambda m: export_compact(m)[0])

    def path_extra(model, tag):
        """v13: every partition (incl. group / rare / shift metrics) at a path point, the mean logit norm on
        validation inputs and the prediction drift from the expanded start model."""
        ctx.updates, ctx.examples = st["upd"], st["upd"] * tr.B
        C.eval_log(ctx, model, bundle, f"pathfull@{st['upd']}")
        with torch.no_grad():
            out_v = predict(model, bundle.val, batch).double().cpu()
        gh = model.structural_hash()
        ctx.metric(f"pathfull@{st['upd']}", "val", "logit_norm_mean", float(out_v.norm(dim=-1).mean()), gh, tag=tag)
        ref = st["vars"].get("start_val_out")
        if ref is not None:
            ctx.metric(f"pathfull@{st['upd']}", "val", "prediction_drift_rms_from_start",
                       float(((out_v - ref) ** 2).mean().sqrt()), gh, tag=tag)
            if bundle.task == "classification":
                ctx.metric(f"pathfull@{st['upd']}", "val", "prediction_flip_rate_from_start",
                           float((out_v.argmax(-1) != ref.argmax(-1)).double().mean()), gh, tag=tag)

    def ev(model, tag, full: bool = False):
        r, pr = evaluate(model, bundle, ["val", "test"], batch, return_preds=True)
        risk = M.headline(r["val"], bundle.task)
        gc = gated_contribution(model)
        # v20: test risk at every path point (validation decides a recovery crossing, test is reported there) and
        # the function distance from the receiver (the start model before any swap)
        o_v = pr["val"].double().cpu()
        dr = float(((o_v - recv_val_out) ** 2).mean().sqrt())
        imit = {}
        if bundle.task == "classification" and o_v.dim() == 2:
            # v22: function agreement beyond output RMS (which is sensitive to confidence / scale): decision
            # disagreement, total-variation distance of the class probabilities, KL(receiver || model)
            lp_r, lp_m = torch.log_softmax(recv_val_out, -1), torch.log_softmax(o_v, -1)
            imit = {"val_flip_rate_from_receiver": float((o_v.argmax(-1) != recv_val_out.argmax(-1)).double().mean()),
                    "val_tv_from_receiver": float(0.5 * (lp_r.exp() - lp_m.exp()).abs().sum(-1).mean()),
                    "val_kl_receiver_to_model": float((lp_r.exp() * (lp_r - lp_m)).sum(-1).mean())}
        st["path"].append({"update": st["upd"], "tag": tag, "val_risk": risk, **({"val_acc": r["val"]["acc"]}
                                                                                 if "acc" in r["val"] else {}),
                           **({"test_risk": M.headline(r["test"], bundle.task)} if "test" in r else {}),
                           "val_rms_drift_from_receiver": dr, **imit,
                           **({"gated_contribution": gc} if gc is not None else {})})
        if full:
            # every partition (test, rare, shift, ...) at the key points of the path
            C.eval_log(ctx, model, bundle, f"path_{tag}")
            if dc["path_full_eval"]:
                # v15: logit norm and prediction drift at the same key events (start, right after an abrupt
                # deletion or a fold, the physically removed model), on the same weights as the event
                with torch.no_grad():
                    out_v = predict(model, bundle.val, batch).double().cpu()
                if tag == "start":
                    st["vars"]["start_val_out"] = out_v
                gh = model.structural_hash()
                ctx.metric(f"path_{tag}", "val", "logit_norm_mean", float(out_v.norm(dim=-1).mean()), gh, tag=tag)
                ref = st["vars"].get("start_val_out")
                if ref is not None:
                    ctx.metric(f"path_{tag}", "val", "prediction_drift_rms_from_start",
                               float(((out_v - ref) ** 2).mean().sqrt()), gh, tag=tag)
                    if bundle.task == "classification":
                        ctx.metric(f"path_{tag}", "val", "prediction_flip_rate_from_start",
                                   float((out_v.argmax(-1) != ref.argmax(-1)).double().mean()), gh, tag=tag)
        ctx.updates, ctx.examples = st["upd"], st["upd"] * tr.B
        ctx.metric(f"path@{st['upd']}", "val", "risk", risk, model.structural_hash(), tag=tag)
        return risk

    rb_cache: dict = {}

    def repair_bundle():
        """v26: the training bundle restricted to dissipation.repair_subset examples (fixed per job seed)."""
        if "b" not in rb_cache:
            import copy as _copy
            from ..utils import tensor_hash
            N_ = len(bundle.train)
            n_ = min(int(dc["repair_subset"]), N_)
            idx = torch.randperm(N_, generator=torch_gen(seed_of(cfg, "repair"), "repair", "subset"))[:n_].sort().values
            b2 = _copy.copy(bundle)
            b2.train = bundle.train.index(idx.to(bundle.train.y.device))
            rb_cache["b"] = b2
            info = {"n": int(n_), "of": int(N_), "index_hash": tensor_hash(idx),
                    "phases": "post-removal repair only; same number of updates"}
            if b2.train.groups is not None:
                info["n_rare_group"] = int((b2.train.groups == 1).sum())
            st["vars"]["repair_subset"] = info
        return rb_cache["b"]

    def train(n, name, on_step=None, extra=None, batch_ctx=None, target="task", target_fn=None,
              extra_trainable=None, eval_path=True, carry_opt=False):
        compact_now = not any(t in st["model"].implants and st["model"].implants[t].nodes for t in targets)
        if compact_now and dc["post_match_macs_of"]:
            # v13 MAC-matched panel: the final compact phase gets the updates that bring this job's estimated
            # training MACs to the reference job's; fixed once and kept in the checkpointed state for resume
            pv = steps.partial["extra"]["vars"] if (steps.partial is not None and
                                                     steps.partial["extra"]["step"] == steps.i) else st["vars"]
            if "mac_matching" not in pv:
                from .continuation import run_work
                ref = run_work(ctx.parent_dir(dc["post_match_macs_of"]))
                per = 3 * forward_macs(st["model"], C.seq_T(bundle), {}) * tr.B
                have = int(tr.state.get("train_macs", 0))
                pv["mac_matching"] = {"reference_role": dc["post_match_macs_of"], "reference_macs": int(ref["macs"]),
                                      "reference_macs_complete": bool(ref["macs_complete"]),
                                      "macs_before_phase": have, "macs_per_update": int(per),
                                      "planned_updates": max(0, int(math.ceil((int(ref["macs"]) - have) / max(1, per)))),
                                      "declared_post_updates": int(n)}
                st["vars"]["mac_matching"] = pv["mac_matching"]
            n = int(pv["mac_matching"]["planned_updates"])
        if n <= 0:
            return
        model = st["model"]
        i_step = steps.i
        if steps.partial is not None and steps.partial["extra"]["step"] == i_step:
            ck = steps.partial
            model = GraphNet.from_checkpoint(ck["model"], ctx.device)
            st["model"] = model
            st.update({k: ck["extra"][k] for k in ("path", "upd", "vars")})
            tr.model = model
            tr.load_state_dict(ck["trainer"])
            base = ck["extra"]["base"]
            steps.partial = None
            resumed_here = True
        else:
            tr.model = model
            tr.configure("none", None, reset_state=True, extra_trainable=extra_trainable)
            base = st["upd"]
            resumed_here = False
            names_ = list(getattr(tr, "opt_param_names", []))
            event("optimizer_reset", phase=name, moments_present=int(len(tr.opt.state)) if tr.opt is not None else 0)
            if tr.opt is not None and len(tr.opt.state):
                raise RuntimeError("an optimizer reset left moments in place")
            if carry_opt:
                # v39: the parent's optimizer state for EVERY tensor of the new optimizer (the keep fork trains the
                # parent's own model), else unsupported; a resumed phase restores its own saved state instead.
                # v41: the same optimizer and hyperparameters as the parent (the helper copies state, not the
                # parameter groups), and the carried state must equal the parent's entry for every name exactly
                ptrain = ctx.parent_json("trajectory", "config.json")["train"]
                keys_ = ("optimizer", "lr", "betas", "eps", "weight_decay", "momentum", "lr_schedule", "warmup",
                         "grad_clip", "precision")
                diff_ = [k_ for k_ in keys_ if ptrain.get(k_) != cfg["train"].get(k_)]
                if diff_:
                    raise Unsupported(f"optimizer_policy=carry_from_parent: the parent's training differs in {diff_}")
                from .repair import _carry_parent_opt
                n_opt = sum(1 for gp in tr.opt.param_groups for _ in gp["params"])
                n_car = _carry_parent_opt(ctx, stage0, tr)
                if n_car != n_opt or len(set(names_)) != len(names_):
                    raise Unsupported(f"optimizer_policy=carry_from_parent: {n_car} of {n_opt} tensors have parent "
                                      f"optimizer state (names unique: {len(set(names_)) == len(names_)})")
                got_d = opt_state_digest(tr.opt, names_)
                want_d = parent_opt_digest(ctx.parent_ckpt("trajectory", stage0), names_)
                if got_d["digest"] != want_d["digest"]:
                    raise Unsupported("optimizer_policy=carry_from_parent: the carried state differs from the "
                                      "parent's named entries")
                event("optimizer_carried", phase=name, tensors=int(n_car), digest=got_d["digest"],
                      step_min=got_d["step_min"], step_max=got_d["step_max"])
            if dc["restore_before_repair"] == "all_but_first" and name.startswith(("post_", "recover_")) and \
                    "restore_before_repair" not in st["vars"]:
                # v30: every backbone layer except the first back to f0 before the repair (a resumed phase already
                # holds the restored weights in its checkpoint)
                if any(t in model.implants and model.implants[t].nodes for t in targets):
                    raise Unsupported("restore_before_repair needs a compact model at the repair")
                first = scope_pkeys(model, "first")
                event("restore_before", ckpt="event_restore_before", model=model)
                sd_m, sd_f = model.state_dict(), f0.state_dict()
                new_sd, moved = dict(sd_m), []
                for k_, v_ in sd_m.items():
                    pk_ = k_.split(".")[1] if k_.startswith("mods.") else None
                    if pk_ is None or pk_ in first:
                        continue
                    if k_ not in sd_f or sd_f[k_].shape != v_.shape:
                        raise Unsupported(f"restore_before_repair: {k_} is not in f0 with the same shape")
                    new_sd[k_] = sd_f[k_].to(v_.device, v_.dtype)
                    moved.append(k_)
                model.load_state_dict(new_sd)
                model._plan = None
                st["vars"]["restore_before_repair"] = {"kept_from_state": sorted(first), "restored_from_f0": moved,
                                                       "at_update": int(st["upd"])}
                event("restore_after", ckpt="event_restore_after", model=model)
        # v26: limited repair data (post-removal phases only): the sampler draws from a fixed random subset of the
        # training set; a fresh phase starts a new epoch over the subset (a resumed one keeps its saved position)
        want = repair_bundle() if (int(dc.get("repair_subset", 0) or 0) > 0 and
                                   name.startswith(("post_", "recover_"))) else bundle
        if tr.bundle is not want:
            if not resumed_here:
                tr.state["perm"], tr.state["pos"] = None, 0
            tr.bundle = want
        every = max(1, n // max(1, n_pts // max(1, len(phases))))
        pts = set(range(every, n + 1, every))
        if dc.get("early_eval") and name.startswith(("post_", "recover_", "keep_")):
            # v22: dense evaluation early in every repair phase (offsets from the phase start)
            pts |= {int(u) for u in dc["early_eval"] if 1 <= int(u) <= n}

        def efn(trn, step):
            st["upd"] = base + step
            if dc["save_path_checkpoints"]:
                ex_ = {"path_tag": name, "update": st["upd"]}
                if trn.state.get("update_norms") is not None:       # v43: the cumulative path length so far
                    ex_["update_norms"] = copy.deepcopy(trn.state["update_norms"])
                ex_["compute"] = compute_counters(trn.state)            # v45: the training counters so far
                ctx.save_ckpt(f"path_u{st['upd']}", trn.model, None, ex_)
            if dc["path_full_eval"]:
                path_extra(trn.model, name)
            if name == "stochastic_bypass":
                saved = dict(trn.model.gate_vals)
                for gd in st["vars"].get("gids_0", []):
                    trn.model.gate_vals[gd] = 1.0          # path points evaluate the full model, not one mask
                ev(trn.model, name)
                trn.model.gate_vals.update(saved)
            else:
                ev(trn.model, name)
            return {}
        if target == "task" and teacher is not None:
            target, tch = "expanded", teacher                 # path trained to match the expanded model (F05b)
        else:
            tch = None
        # v13: validation-selection candidates only in a phase whose model is already compact (every target
        # removed): an expanded or partially contracted state can never be a selected endpoint
        compact = sel.enabled and not any(t in tr.model.implants and tr.model.implants[t].nodes for t in targets)
        sel_pts = set(sel.points(n)) if compact else set()
        # v25: repair scope (post-removal phases only; the transition phase always trains every parameter)
        trainable = None
        if name.startswith(("keep_", "anneal_")) and dc.get("keep_frozen_implants"):
            # v30: the additions stay in the forward pass with frozen parameters; the backbone learns
            trainable = {model.nodes[n_].pkey for n_ in model.live_nodes() if model.nodes[n_].pkey is not None
                         and model.nodes[n_].owner is None}
        if dc["repair_scope"] != "full" and name.startswith(("post_", "recover_")):
            if any(t in tr.model.implants and tr.model.implants[t].nodes for t in targets):
                raise Unsupported("repair_scope other than full needs a compact model in the repair phase "
                                  "(a single-phase removal)")
            trainable = scope_pkeys(tr.model, dc["repair_scope"])
            if "repair_scope" not in st["vars"]:
                npar = {pk: sum(p_.numel() for p_ in tr.model.mods[pk].parameters()) for pk in trainable}
                st["vars"]["repair_scope"] = {"scope": dc["repair_scope"], "trainable_pkeys": sorted(trainable),
                                              "trainable_params": int(sum(npar.values())),
                                              "compact_params": int(sum(p_.numel() for p_ in tr.model.parameters())),
                                              "phases": "post-removal repair only"}

        def step_hook(trn, k):
            if on_step is not None:
                on_step(trn, k)
            if k > 0 and k in sel_pts:
                sel.consider(trn.model, trn.state["global_step"], k, f"{name}@{k}")
                trn.model.train()
        # v41: the optimizer state at the phase start and after its first update (a resumed phase keeps the
        # records it made before the interruption, in st['vars'])
        oa = st["vars"].setdefault("opt_audit", {}).setdefault(name, {})
        if "start" not in oa:
            oa["start"] = opt_state_digest(tr.opt, list(getattr(tr, "opt_param_names", [])))

        def audit_hook(trn, k, inner=step_hook if sel_pts else on_step):
            if inner is not None:
                inner(trn, k)
            if k == 1 and "after_first_update" not in oa:
                oa["after_first_update"] = opt_state_digest(trn.opt, list(getattr(trn, "opt_param_names", [])))
        seg = Segment(name, n, on_step=audit_hook, extra_loss=extra, batch_ctx=batch_ctx,
                      target=target, target_fn=target_fn,
                      eval_points=sorted(pts) if eval_path else [],
                      eval_fn=efn if eval_path else None, teacher=tch, trainable=trainable)
        r_ = tr.run(seg, checkpoint_cb=lambda: steps.save("diss_partial", tr.model, {"step": i_step, "base": base}))
        if int(r_["updates"]) in sel_pts:
            sel.consider(tr.model, tr.state["global_step"], int(r_["updates"]), f"{name}@{r_['updates']}")
        tr.extra_trainable = None
        st["upd"] = base + int(r_["updates"])           # actual updates (fewer than n after divergence)
        st["vars"].setdefault("phases", []).append({
            "phase": name, "start_update": int(base), "updates": int(r_["updates"]), "declared_updates": int(n),
            # v34: the attempt history is kept apart (attempt_*), so a resumed job's ledger equals an uninterrupted one
            "optimizer": "carried from the parent" if carry_opt else "fresh at phase start",
            "attempt_resumed_inside": bool(resumed_here),
            # v39: whether this phase's branch gradients were masked by the parent's split
            "grad_masks": "retained" if (batch_ctx is not None and batch_ctx is mask_ctx) else "released",
            # v41: gradient eligibility (cumulative over the job's masked phases) and the optimizer audit
            "eligibility": (eligibility_record(tr, bundle) if (batch_ctx is not None and batch_ctx is mask_ctx)
                            else "every example eligible for every branch (masks released)"),
            "optimizer_audit": dict(oa),
            "lr": float(tr.t["lr"]), "lr_schedule": tr.t["lr_schedule"], "warmup": int(tr.t.get("warmup", 0) or 0),
            "trainable": sorted(trainable) if trainable is not None else "all",
            "batch_id_hash_end": tr.state.get("batch_id_hash"), "batches_drawn_end": tr.state.get("batches_drawn"),
            "gates": {str(k_): float(v_) for k_, v_ in tr.model.gate_vals.items()} or None})

    def set_model(fn):
        def f():
            st["model"] = fn(st["model"])
        return f

    steps(lambda: st["vars"].__setitem__("r0", ev(st["model"], "start", full=True)))
    if dc["path_full_eval"]:
        mem = spec_membership(ctx, cfg, bundle, stage=stage0)
        mem0 = spec_membership(ctx, cfg, bundle, initial=True)
        mbi = None
        if hybrid_info is not None:
            # swapped-in branches were trained under the DONOR lineage's split (none for a redrawn donor), as in
            # force at the donor checkpoint
            dcfg = ctx.parent_json(hy["donor_role"], "config.json")
            dmem = spec_membership(ctx, dcfg, bundle, role=hy["donor_role"], stage=hy["donor_stage"])
            label = f"donor lineage ({(dcfg.get('growth') or {}).get('spec_partition')})"
            mbi = {t: (dmem, label) for t in hybrid_info["implants"]}
        steps(lambda: st["vars"].__setitem__("frozen_sweep", frozen_weight_sweep(st["model"], targets, bundle, batch,
                                                                                 membership=mem,
                                                                                 membership_by_implant=mbi,
                                                                                 membership_initial=mem0)))
        # v25: per-stratum dependence of the training examples (memorization-sink reading); hybrids are skipped
        # (their branches carry different splits)
        if hybrid_info is None:
            steps(lambda: st["vars"].__setitem__("sink_profile", sink_profile(st["model"], f0, bundle, batch,
                                                                              membership=mem)))
    sw = dc.get("swap_scan") or {}
    if sw.get("donor_role"):
        def do_scan():
            sdon = GraphNet.from_checkpoint(ctx.parent_ckpt(sw["donor_role"], sw["donor_stage"])["model"], ctx.device)
            st["vars"]["swap_scan"] = {"donor_role": sw["donor_role"], "donor_stage": sw["donor_stage"],
                                       "receiver_stage": stage0, **swap_scan(st["model"], sdon, bundle, batch)}
        steps(do_scan)
    if dc["path_full_eval"]:
        def keep_start():
            with torch.no_grad():
                st["vars"]["start_val_out"] = predict(st["model"], bundle.val, batch).double().cpu()
        steps(keep_start)
    if method in ("abrupt",):
        for k, ph in enumerate(phases):
            # an ancestor deleted in an earlier phase has taken its descendants with it
            steps(set_model(lambda m, ph=ph: E.delete(m, [t for t in ph if t in m.implants], share_params=False)))
            steps(lambda k=k: event("physical_deletion", ckpt=f"event_deleted_{k}", model=st["model"]))
            steps(lambda k=k: ev(st["model"], f"after_abrupt_delete_{k}", full=True))
            n_k = share(dc["post_updates"], k, nph)
            sp = int(dc.get("split_updates", 0) or 0)
            if sp and 0 < sp < n_k:
                # v31 phase-matched fork: the same repair split at the linear removal's transition length, a fresh
                # optimizer at the boundary, the minibatch stream continuing
                steps(lambda k=k, sp=sp: train(sp, f"recover_{k}"))
                steps(lambda k=k, sp=sp, n_k=n_k: train(n_k - sp, f"recover_{k}b"))
            else:
                steps(lambda k=k, n_k=n_k: train(n_k, f"recover_{k}"))
    elif method == "fold":
        # exact algebraic return: every target folded (no training needed), then optional post training
        def fold_all():
            m = st["model"]
            for t in [t for t in targets if t in m.implants]:
                m = E.fold_implant(m, t, share_params=False)
            st["model"] = export_compact(m, fold_linear=True)[0]
        steps(fold_all)
        steps(lambda: ev(st["model"], "after_fold", full=True))
        steps(lambda: train(dc["post_updates"], "post_0"))
    elif method == "fold_unrouted":
        # v59: the exact fold of affine additions that carry gradient masks (routed additions).  The forward
        # function is unchanged; from here on the folded compact weights train directly on every example
        # (removal_masks=released), so routing and the additions' parametrisation both end at the fork
        def fold_all_unrouted():
            m = st["model"]
            removed = []
            for t in [t for t in targets if t in m.implants]:
                m = E.fold_implant(m, t, share_params=False, drop_grad_masks=True)
                removed += m.meta["history"][-1].get("grad_masks_removed", [])
            st["model"] = export_compact(m, fold_linear=True)[0]
            st["vars"]["grad_masks_removed"] = sorted(set(removed))

        def keep_fold_start():
            # v60: the compact network that starts the training, saved before its first update (a permanent
            # checkpoint), with its graph, parameter and architecture hashes
            m = st["model"]
            rec = {"checkpoint": "event_after_fold", "graph_hash": m.structural_hash(), "param_hash": m.param_hash(),
                   "architecture_hash": architecture_hash(m), "update": int(st["upd"])}
            event("fold_unrouted", ckpt="event_after_fold", model=m, graph_hash=rec["graph_hash"],
                  param_hash=rec["param_hash"], architecture_hash=rec["architecture_hash"])
            st["vars"]["fold_start"] = rec
        steps(fold_all_unrouted)
        steps(keep_fold_start)
        steps(lambda: ev(st["model"], "after_fold", full=True))
        steps(lambda: train(dc["post_updates"], "post_0"))
    elif method == "stochastic_bypass":
        keep, resc = float(dc["bypass_keep"]), bool(dc["bypass_rescale"])
        ph = sorted({t for p_ in phases for t in p_}, key=lambda s_: int(s_[1:]))

        def add_gates_sb():
            st["vars"]["gids_0"] = [E.add_gate(st["model"], t) for t in ph if st["model"].implants.get(t)]
            st["vars"]["gidmap_0"] = {t: E.add_gate(st["model"], t) for t in ph if st["model"].implants.get(t)}
        steps(add_gates_sb)
        rseed = seed_of(cfg, "repair")

        def on_step_sb(trn, step):
            gg = torch_gen(rseed, "repair", "stochastic_bypass", str(step))
            m = torch.rand(len(st["vars"]["gids_0"]), generator=gg) < keep
            for gd, on in zip(st["vars"]["gids_0"], m.tolist()):
                trn.model.gate_vals[gd] = (1.0 / keep if resc else 1.0) if on else 0.0
        steps(lambda: train(S, "stochastic_bypass", on_step=on_step_sb))

        def remove_sb():
            for gd in st["vars"]["gids_0"]:
                st["model"].gate_vals[gd] = 0.0
            st["model"] = export_compact(st["model"])[0]       # the deterministic exported model, not a mask ensemble
            ev(st["model"], "physically_removed_0", full=True)
        steps(remove_sb)
        steps(lambda: train(dc["post_updates"], "post_0"))
    elif method in ("linear", "cosine", "group_removal"):
        sched = "linear" if method == "group_removal" else method
        use_phases = [sorted({t for ph in phases for t in ph}, key=lambda s: int(s[1:]))] if method == "group_removal" \
            else phases
        for k, ph in enumerate(use_phases):
            Sk = share(S, k, len(use_phases))

            def add_gates(ph=ph, k=k):
                st["vars"][f"gids_{k}"] = [E.add_gate(st["model"], t) for t in ph if st["model"].implants.get(t)]
                st["vars"][f"gidmap_{k}"] = {t: E.add_gate(st["model"], t) for t in ph if st["model"].implants.get(t)}
            steps(add_gates)

            def on_step(trn, step, k=k, sched=sched, Sk=Sk):
                frac = min(1.0, (step + 1) / max(1, Sk))
                v = 1 - frac if sched == "linear" else 0.5 * (1 + math.cos(math.pi * frac))
                if dc["gate_schedule"] == "hold":
                    v = 1.0
                for gd in st["vars"][f"gids_{k}"]:
                    trn.model.gate_vals[gd] = float(v)
            steps(lambda k=k, on_step=on_step, Sk=Sk: train(Sk, f"anneal_{k}", on_step=on_step, batch_ctx=mask_ctx))
            # v20: every policy is evaluated at the end of its transition, before the additions are removed
            steps(lambda k=k: ev(st["model"], f"end_transition_{k}", full=True))

            def remove(k=k):
                for gd in st["vars"][f"gids_{k}"]:
                    st["model"].gate_vals[gd] = 0.0
                st["model"] = export_compact(st["model"])[0]
                st["vars"].pop(f"gidmap_{k}", None)
                event("physical_deletion", ckpt=f"event_deleted_{k}", model=st["model"])
                ev(st["model"], f"physically_removed_{k}", full=True)
            steps(remove)
            steps(lambda k=k, n_=len(use_phases) if method in ("linear", "cosine", "group_removal") else nph:
                  train(share(dc["post_updates"], k, n_), f"post_{k}", batch_ctx=mask_ctx))
    elif method in ("residual_penalty", "inverse_restore", "branch_merge"):
        for k, ph in enumerate(phases):
            if method == "residual_penalty":
                def pen_step(ph=ph, k=k):
                    model = st["model"]
                    live = [t for t in ph if t in model.implants]
                    pairs = [contribution_nodes(model, t) for t in live]
                    collect = {a for a, b in pairs} | {b for a, b in pairs if b}

                    def pen(m, c, batch_, step, pairs=pairs):
                        col = c.get("collected", {})
                        tot = 0.0
                        for a, b in pairs:
                            if a in col:
                                tot = tot + ((col[a] - (col[b] if b else 0.0)) ** 2).mean()
                        return dc["penalty"] * tot
                    train(share(S, k, nph), f"penalty_{k}", extra=pen, batch_ctx=lambda b, collect=collect: {"collect": collect},
                          eval_path=False)
                    ev(st["model"], f"after_penalty_{k}")
                steps(pen_step)
            elif method == "inverse_restore":
                def inv_step(ph=ph, k=k):
                    model = st["model"]
                    pairs = inverse_pairs(model, [t for t in ph if t in model.implants])
                    st["vars"][f"inverse_pairs_{k}"] = [{kk: v for kk, v in p_.items()} for p_ in pairs]
                    if pairs:
                        train(share(S, k, nph), f"restore_{k}", extra=lambda m, c, b_, s_, pairs=pairs:
                              dc["penalty"] * inverse_restore_penalty(m, pairs), eval_path=False)
                    ev(st["model"], f"after_restore_{k}")
                steps(inv_step)
            else:  # branch_merge
                def merge_step(ph=ph, k=k):
                    model = st["model"]
                    merged = branch_merge(model, [t for t in ph if t in model.implants])
                    st["vars"][f"merged_{k}"] = merged
                    ev(model, f"after_merge_{k}")
                steps(merge_step)
            steps(set_model(lambda m, ph=ph: E.delete(m, [t for t in ph if t in m.implants], share_params=False)))
            steps(lambda k=k: ev(st["model"], f"after_delete_{k}", full=k == 0))
            steps(lambda k=k, n_=len(use_phases) if method in ("linear", "cosine", "group_removal") else nph:
                  train(share(dc["post_updates"], k, n_), f"post_{k}"))
    elif method == "keep":
        # v30: nothing is removed; the expanded model trains on for post_updates (the removal jobs' minibatch
        # stream); the comparison for elapsed training without removal.  v39: removal_masks=retained keeps the
        # parent's gradient masks (before v39 the keep phases never received them: every keep job of v30-v38 had
        # released masks, so none was affected); optimizer_policy=carry_from_parent continues the parent's state
        sp = int(dc.get("split_updates", 0) or 0)
        carry = dc["optimizer_policy"] == "carry_from_parent"
        if redist is not None:
            # v65: the edit, then the edited start state saved (a permanent checkpoint) with its hashes and the
            # forward change it made in this precision (relative to the largest logit, validation inputs)
            def redistribute_start():
                from ..graph.redistribute import redistribute
                m = st["model"]
                with torch.no_grad():
                    z0 = predict(m, pv0["val"], batch).double().cpu()
                info = redistribute(m, redist)
                with torch.no_grad():
                    z1 = predict(m, pv0["val"], batch).double().cpu()
                info["val_relative_logit_change"] = float((z1 - z0).abs().max()) / max(1.0, float(z0.abs().max()))
                info["val_flip_rate"] = float((z1.argmax(-1) != z0.argmax(-1)).double().mean())
                st["vars"]["redistribution"] = {"method": redist, **info}

            def keep_redistribution_start():
                m = st["model"]
                rec = {"checkpoint": "event_after_redistribute", "graph_hash": m.structural_hash(),
                       "param_hash": m.param_hash(), "update": int(st["upd"])}
                event("redistribute", ckpt="event_after_redistribute", model=m, graph_hash=rec["graph_hash"],
                      param_hash=rec["param_hash"], method=redist)
                st["vars"]["redistribution"]["start"] = rec
            steps(redistribute_start)
            steps(keep_redistribution_start)
        if sp and 0 < sp < int(dc["post_updates"]):
            # v31 phase-matched fork (see abrupt)
            steps(lambda: train(sp, "keep_0", batch_ctx=mask_ctx))
            steps(lambda: train(int(dc["post_updates"]) - sp, "keep_1", batch_ctx=mask_ctx))
        else:
            steps(lambda: train(dc["post_updates"], "keep_0", batch_ctx=mask_ctx, carry_opt=carry))
    elif method == "peg_replacement":
        for k, ph in enumerate(phases):
            for t in [t for t in ph if t in g.implants and g.implants[t].parent is None]:
                def prep(t=t):
                    if t not in st["model"].implants:
                        return
                    h2, iid, target_node, ref = prepare_small(ctx, st["model"], t, cfg)
                    st["vars"][f"replace_{t}"] = {"iid": iid, "target_node": target_node}
                    st["ref"] = ref
                    st["model"] = h2
                steps(prep)

                def fit(t=t):
                    if f"replace_{t}" not in st["vars"]:
                        return
                    v = st["vars"][f"replace_{t}"]
                    ref = st.get("ref")
                    if ref is None:       # resumed after prep: the reference is the saved model before the swap
                        ref = GraphNet.from_checkpoint(ctx.load_ckpt(f"diss_ref_{t}")["model"], ctx.device)
                        st["ref"] = ref
                    iid, target_node = v["iid"], v["target_node"]

                    def tfn(out, batch_, X, g_ref=ref, iid=iid, target_node=target_node):
                        with torch.no_grad():
                            _, vv = g_ref(X, return_nodes=[target_node])
                        h_ref = st["model"]
                        _, v2 = h_ref(X, return_nodes=[h_ref.implants[iid].exit])
                        return F.mse_loss(v2[h_ref.implants[iid].exit], vv[target_node])
                    train(S, f"replace_{t}", target="custom", target_fn=tfn,
                          extra_trainable=set(st["model"].implants[iid].nodes), eval_path=False)
                    st.pop("ref", None)
                steps(fit)
            steps(lambda k=k: ev(st["model"], f"after_replace_{k}"))
            steps(lambda k=k, n_=len(use_phases) if method in ("linear", "cosine", "group_removal") else nph:
                  train(share(dc["post_updates"], k, n_), f"post_{k}"))
    else:
        raise Unsupported(method)
    model = st["model"]
    exp, rep = export_compact(model)
    ctx.save_ckpt("export", exp)
    remaining = [t for t in targets if t in exp.implants and exp.implants[t].nodes]
    r_final = ev(exp, "exported")
    # the contracted model on every partition (test, rare, shift, ...), with drift to the expanded start
    res_exp, _ = C.eval_log(ctx, exp, bundle, "exported")
    er = acct_report(exp, C.seq_T(bundle))
    arch_f0 = architecture_hash(exp) == f0_arch
    returns_to_f0 = method not in ("peg_replacement", "keep") and dc["targets"] == "all"
    gh = exp.structural_hash()
    for k_ in ("params", "macs", "param_bytes_fp32", "buffer_bytes", "activation_values_per_example",
               "peg_bits_per_example"):
        ctx.metric("exported", "none", f"export_{k_}", er.get(k_), gh)
    ctx.metric("exported", "none", "export_architecture_equals_f0", int(arch_f0), gh)
    if returns_to_f0 and dc["require_f0_architecture"]:
        if remaining:
            raise ScientificInvalid("contraction left target implants in the export", {"remaining": remaining})
        if not arch_f0:
            raise ScientificInvalid("the contracted export does not have the f0 architecture",
                                    {"export_params": er["params"], "f0_params": count_params(f0)["total"]})
    C.record_endpoint(ctx, bundle, "export", bool(tr.state.get("diverged")), tr.state.get("diverged_reason"),
                      {"f0_architecture_hash": f0_arch})
    sel.ensure_final(exp, tr.state["global_step"], 0, "export")
    sel.record(bundle, bool(tr.state.get("diverged")), tr.state.get("diverged_reason"), tr.state.get("diverged_at"))
    out = {"method": method_name, "order": dc["order"], "targets": targets, "phases": phases,
           "start_risk": st["vars"]["r0"], "peak_risk": max(p["val_risk"] for p in st["path"]), "final_risk": r_final,
           "total_updates": st["upd"], "targets_remaining_in_export": remaining,
           "params_start": p_start, "params_export": rep["after"]["params"],
           "export_architecture_equals_f0": arch_f0, "export_macs": er.get("macs"),
           "exported_metrics": {p_: {k_: v for k_, v in m_.items() if isinstance(v, (int, float))}
                                for p_, m_ in res_exp.items()},
           "parent_stage": stage0, "target": dc["target"], "diverged": bool(tr.state.get("diverged")),
           "inverse_pairs": {k: v for k, v in st["vars"].items() if k.startswith("inverse_pairs_")},
           "path_scope": "barrier statements refer to this path only",
           "path_sampling": {"path_eval_points": int(n_pts), "peak_risk_is": "the maximum over sampled path points "
                             "(sample density above), not a certified barrier",
                             "dense_checkpoints": bool(dc["save_path_checkpoints"])},
           "mac_matching": st["vars"].get("mac_matching"),
           "frozen_weight_sweep": st["vars"].get("frozen_sweep"), "hybrid": hybrid_info,
           "removal_policy": removal_policy, "branch_ages": ages, "swap_scan": st["vars"].get("swap_scan"),
           "recovery_reference": recovery_ref, "rebuild": rebuild_info,
           "sink_profile": st["vars"].get("sink_profile"),
           **({"grad_masks_removed": st["vars"].get("grad_masks_removed"), "fold_start": st["vars"].get("fold_start")}
              if method == "fold_unrouted" else {}),
           "repair_scope": st["vars"].get("repair_scope") or {"scope": dc["repair_scope"]},
           "repair_subset": st["vars"].get("repair_subset"),
           "restore_before_repair": st["vars"].get("restore_before_repair"),
           "schedule_audit": {"parent_state_hash": parent_state_hash, "phases": st["vars"].get("phases"),
                              "events": st["vars"].get("events"), "batch_id_hash": tr.state.get("batch_id_hash"),
                              "batches_drawn": tr.state.get("batches_drawn"), "updates_total": int(st["upd"]),
                              "split_updates": int(dc.get("split_updates", 0) or 0)},
           "keep_frozen_implants": bool(dc.get("keep_frozen_implants")) if method in ("keep", "linear") else None,
           **({"redistribution": st["vars"].get("redistribution")} if redist is not None else {})}
    ctx.updates, ctx.examples = st["upd"], st["upd"] * tr.B
    ctx.count_work("dissipation", updates=st["upd"], examples=st["upd"] * tr.B, seconds=tr.timing["train_seconds"],
                   macs=int(tr.state.get("train_macs", 0)), macs_bwd=int(tr.state.get("train_macs_bwd", 0)), teacher_macs=int(tr.state.get("teacher_macs", 0)))
    out["compute_end"] = compute_counters(tr.state)          # v45: this job's training counters (fresh trainer)
    ctx.save_json("dissipation_result.json", {**out, "path": st["path"]})
    ctx.metrics("final", "val", {k: v for k, v in out.items() if isinstance(v, (int, float))})
    for nm in ("diss_state", "diss_partial"):
        ctx.ckpt_path(nm).unlink(missing_ok=True)
    return out


@torch.no_grad()
def branch_merge(g: GraphNet, targets: list[str]) -> list[str]:
    """Merge sibling branches of identical architecture into the first one:
    parameters averaged with the merge weights, coefficient = sum.  Exact when
    the branches are equal; otherwise an approximation measured on the path."""
    merged = []
    for G in targets:
        imp = g.implants.get(G)
        if imp is None or "merge" not in imp.meta:
            continue
        m = g.nodes[imp.meta["merge"]]
        if m.op != "add":
            continue
        kids = [c for c in g.implant_children(G) if g.implants[c].kind == "branch" and g.implants[c].nodes]
        if len(kids) < 2:
            continue
        sig = lambda c: [(g.nodes[n].op, tuple(p.shape) if g.nodes[n].pkey else None)
                         for n in g.implants[c].nodes for p in ([g.mods[g.nodes[n].pkey].weight] if g.nodes[n].pkey else [None])]
        first = kids[0]
        same = [c for c in kids if sig(c) == sig(first)]
        if len(same) < 2:
            continue
        coefs = {c: m.attrs["coefs"][m.attrs["terms"].index(c)] for c in same}
        tot = sum(coefs.values())
        if tot == 0:
            continue
        pk = lambda c: [g.nodes[n].pkey for n in g.implants[c].nodes if g.nodes[n].pkey]
        if len({tuple(pk(c)) for c in same}) < len(same):
            continue  # tied branches: already one computation
        for idx, p0 in enumerate(pk(first)):
            ps = [g.mods[pk(c)[idx]] for c in same]
            for name, prm in g.mods[p0].named_parameters():
                avg = sum(coefs[c] * dict(ps[j].named_parameters())[name] for j, c in enumerate(same)) / tot
                prm.copy_(avg)
        m.attrs["coefs"][m.attrs["terms"].index(first)] = tot
        for c in same[1:]:
            k = m.attrs["terms"].index(c)
            m.attrs["coefs"][k] = 0.0
        merged.append(G)
        g._plan = None
    return merged


def prepare_small(ctx, g: GraphNet, t: str, cfg) -> tuple:
    """Deterministic part of 'peg_replacement': delete the series implant t
    and insert a narrow zero-initialised residual implant at the same cut; the
    replacement is then fitted locally (training inputs) to the deleted
    implant's contribution in the reference model g.  The reference is saved
    so a resumed fit uses the same target."""
    imp = g.implants[t]
    if imp.kind != "series":
        raise Unsupported("peg_replacement implemented for series implants")
    h = g.clone(share_params=False)
    rep_cut = E.Cut(source=imp.entry, consumers=[(c, s) for c, s in h.consumers(imp.exit)
                                                 if c not in h.region(t)])
    width = cfg["repair"]["adapter_width"] if "repair" in cfg else 16
    h2 = E.delete(h, [t], share_params=True)
    cut2 = E.Cut(source=rep_cut.source, consumers=[(c, s) for c, s in rep_cut.consumers if c in h2.nodes])
    iid = E.insert_residual_zero(h2, cut2, torch_gen(seed_of(cfg, "repair"), "repair", f"replace/{t}"), width=width,
                                 slot=f"replace/{t}")
    ref = g.clone(share_params=False).eval()
    for p in ref.parameters():
        p.requires_grad_(False)
    ctx.save_ckpt(f"diss_ref_{t}", ref)
    return h2, iid, imp.exit, ref
