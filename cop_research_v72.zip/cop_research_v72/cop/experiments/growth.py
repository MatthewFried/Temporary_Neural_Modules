"""Growth programs: what each topology inserts in round r.

Every program is deterministic given (graph, config, round) and draws implant
initialisations from the insertion stream keyed by a STRUCTURAL slot label
(e.g. 'tree/b1/c'), so histories that build the same final graph in different
orders (depth-first vs breadth-first, incremental vs all-at-once) receive the
same initial implant parameters (common random numbers).

The growth state (frontiers, group ids) lives in g.meta['growth_state'] so it is
checkpointed with the model.
"""
from __future__ import annotations

import math
from typing import Callable, Optional

import torch

from ..graph import edits as E
from ..graph.graph import GraphNet, GraphError
from ..graph.ops import init_module, MLPModule, PolyModule
from ..utils import torch_gen
from .context import Unsupported

CORE_TOPOLOGIES = ("none", "layered", "parallel", "recursive", "recursive_branch")


class Grower:
    def __init__(self, gcfg: dict, insertion_seed: int, bundle, log: Callable = lambda r: None):
        self.c = gcfg
        self.seed = insertion_seed
        self.bundle = bundle
        self.log = log
        self.select_fn: Optional[Callable] = None   # set by trajectory for data-driven choices (training data only)
        self.known_module_fn: Optional[Callable] = None

    def gen(self, slot: str) -> torch.Generator:
        # grow / contract cycles salt the slot with the cycle index (fresh implants every cycle)
        return torch_gen(self.seed, "insertion", (self.salt + slot) if getattr(self, "salt", "") else slot)

    # ----------------------------------------------------------------- cuts
    def _channels(self, g: GraphNet, cut: E.Cut, slot: str):
        ch = self.c["channels"]
        if ch is None:
            return None
        d = g.node_dim(cut.source)
        if isinstance(ch, int):
            if ch >= d:
                return None
            if self.c["channel_order"] == "random":
                perm = torch.randperm(d, generator=self.gen(slot + "/channels"))
                return sorted(perm[:ch].tolist())
            if self.c["channel_order"] == "top_variance":
                # feature-guided choice on TRAINING calibration inputs only; criterion and cost logged
                X = {k: v[:2048] for k, v in self.bundle.train.X.items()}
                was = g.training
                g.eval()
                with torch.no_grad():
                    _, vals = g(X, return_nodes=[cut.source])
                g.train(was)
                h = vals[cut.source]
                dims = [i for i in range(h.dim()) if i != (1 if g.layout in ("vec", "img") else h.dim() - 1)]
                var = h.float().var(dim=dims)
                top = sorted(torch.topk(var, ch).indices.tolist())
                self.log({"event": "channel_selection", "criterion": "activation variance on training calibration "
                          "inputs", "n_inputs": int(next(iter(X.values())).shape[0]), "chosen": top,
                          "search_cost": "one forward pass"})
                return top
            return list(range(ch))
        return list(ch)

    def backbone_cut(self, g: GraphNet, slot: str, where=None) -> E.Cut:
        w = self.c["cut_where"] if where is None else where
        if isinstance(w, str) and w.startswith(("probe:", "probe_random:")):
            w = self._probe_cut(g, w)
        c = E.cut_at(g, self.c["cut_kind"], w, subset=self.c["cut_subset"], positions=self.c["positions"])
        c.channels = self._channels(g, c, slot)
        return c

    def _probe_cut(self, g: GraphNet, spec: str) -> int:
        """F02d: 'probe:<aux>' = the cutpoint whose activation best predicts the dataset's known
        intermediate <aux> (ridge R^2 on TRAINING calibration inputs); 'probe_random:<aux>' = a
        random other cutpoint with the same activation dimension (seeded), as the matched random
        boundary.  R^2 and activation scale of both are logged (computed once, cached in growth_state)."""
        kind, aux = spec.split(":", 1)
        st = g.meta.setdefault("growth_state", {})
        cache = st.setdefault("probe_cut", {})
        if spec in cache:
            return cache[spec]
        if aux not in self.bundle.train.aux:
            raise Unsupported(f"cut_where={spec}: dataset has no known intermediate {aux!r}")
        cps = E.cutpoints(g, self.c["cut_kind"])
        n = min(2048, len(self.bundle.train))
        X = {k: v[:n] for k, v in self.bundle.train.X.items()}
        Z = self.bundle.train.aux[aux][:n].double()
        srcs = [E.resolve_edges(g, cp["edges"]).source for cp in cps]
        was = g.training
        g.eval()
        with torch.no_grad():
            _, vals = g(X, return_nodes=list(dict.fromkeys(srcs)))
        g.train(was)
        rows = []
        for i, src in enumerate(srcs):
            H = vals[src].reshape(n, -1).double()
            Ha = torch.cat([H - H.mean(0), torch.ones(n, 1, dtype=H.dtype, device=H.device)], 1)
            lam = 1e-3 * float((Ha ** 2).sum(0).mean())
            W = torch.linalg.solve(Ha.T @ Ha + lam * torch.eye(Ha.shape[1], dtype=H.dtype, device=H.device),
                                   Ha.T @ Z.to(H.device))
            r2 = 1.0 - float(((Ha @ W - Z) ** 2).sum() / ((Z - Z.mean(0)) ** 2).sum().clamp_min(1e-12))
            rows.append({"cutpoint": i, "dim": int(H.shape[1]), "r2": r2, "act_std": float(H.std())})
        best = max(range(len(rows)), key=lambda i: (rows[i]["r2"], -i))
        others = [i for i in range(len(rows)) if i != best and rows[i]["dim"] == rows[best]["dim"]]
        if kind == "probe":
            choice = best
        else:
            if not others:
                raise Unsupported("no other cutpoint with the same activation dimension for the matched random cut")
            choice = others[int(torch.randint(len(others), (1,), generator=self.gen("probe_random/" + aux)))]
        info = {"spec": spec, "chosen": choice, "best_probe": best, "candidates": rows,
                "criterion": "ridge R^2 of the known intermediate on training calibration inputs",
                "search_cost_forward_examples": n}
        self.log({"event": "probe_cut", **info})
        st.setdefault("probe_cut_info", {})[spec] = info
        cache[spec] = choice
        return choice

    def inner_cut(self, g: GraphNet, iid: str, where: Optional[str] = None) -> E.Cut:
        w = where or self.c["inner_cut"]
        cps = g.implants[iid].meta.get("cutpoints", {})
        if w not in cps:
            w = "hidden" if "hidden" in cps else sorted(cps)[0]
        return E.implant_cut(g, iid, w)

    # ------------------------------------------------------------ insertion
    def _match_width(self, g: GraphNet, build: Callable[[GraphNet, int], object], default: int, slot: str) -> int:
        """F03 equal-cost panels: the width whose added parameters (or forward MACs per
        example) is closest to growth.width_match_target, searched on clones of the graph.
        The target is per ROUND: a program that inserts several modules in one round matches each
        to its share (self._wm_frac), so every topology adds the same cost per round."""
        mode = self.c["width_match"]
        if mode == "none":
            return default
        from ..graph.accounting import count_params, count_macs
        measure = (lambda h: count_params(h)["total"]) if mode == "params" else (lambda h: count_macs(h)["macs"])
        base = measure(g)
        target = int(round(int(self.c["width_match_target"]) * float(getattr(self, "_wm_frac", 1.0))))
        best, best_err, best_add = None, None, None
        for w in range(1, 4 * max(default, 16) + 1):
            h = g.clone(share_params=False)
            try:
                build(h, w)
            except GraphError:
                continue
            add = measure(h) - base
            err = abs(add - target)
            if best_err is None or err < best_err:
                best, best_err, best_add = w, err, add
            if add > target:
                break
        if best is None:
            raise Unsupported("no width satisfies the width_match panel")
        g.meta.setdefault("growth_state", {}).setdefault("width_match", []).append(
            {"slot": slot, "mode": mode, "target": target, "width": best, "added": int(best_add)})
        return best

    def insert(self, g: GraphNet, cut: E.Cut, slot: str, rnd: int, width: Optional[int] = None,
               construction: Optional[str] = None) -> list[str]:
        con = construction or self.c["construction"]
        w = width or self.c["width"]
        if self.c["width_match"] != "none" and width is None:
            w = self._match_width(g, lambda h, ww: self._insert(h, self._recut(h, g, cut), slot, rnd, ww, con),
                                  w, slot)
        return self._insert(g, cut, slot, rnd, w, con)

    @staticmethod
    def _recut(h: GraphNet, g: GraphNet, cut: E.Cut) -> E.Cut:
        import copy as _c
        return _c.deepcopy(cut)          # node ids are preserved by clone

    def _insert(self, g: GraphNet, cut: E.Cut, slot: str, rnd: int, w: int, con: str) -> list[str]:
        gen = self.gen(slot)
        if self.c["peg_dim"] and con == "residual_zero":
            return [insert_residual_peg(g, cut, gen, w, self.c["act"], self.c["peg_dim"], self.c["peg_bits"],
                                        slot=slot, rnd=rnd)]
        if con == "residual_zero":
            return [E.insert_residual_zero(g, cut, gen, width=w, act=self.c["act"], slot=slot, rnd=rnd,
                                           kernel=int(self.c["kernel"]), nonlinearity=float(self.c["nonlinearity"]),
                                           mixer=self.c["mixer"])]
        if con == "linear_factor":
            d = g.node_dim(cut.source) if cut.channels is None else len(cut.channels)
            return [E.insert_linear_factor(g, cut, gen, width=max(w, d), slot=slot, rnd=rnd)]
        if con == "concat_expand":
            return [E.insert_concat_expand(g, cut, gen, width=w, act=self.c["act"], slot=slot, rnd=rnd)]
        if con == "inverse_pair":
            tie = {"untied": "untied", "tied": "enforced", "enforced": "enforced", "learned": "learned"}[self.c["tie"]]
            cond = self.c["inverse_cond"] if self.c["inverse_kind"] == "linear" else None
            G, T, Ti = E.insert_inverse_pair(g, cut, gen, kind=self.c["inverse_kind"], tie=tie, width=w,
                                             act="tanh" if self.c["act"] == "relu" else self.c["act"], slot=slot,
                                             rnd=rnd, cond=None if cond is None else float(cond))
            return [G, T, Ti]
        if con == "cancel_pair":
            G, u, v = E.insert_cancel_pair(g, cut, gen, width=w, act=self.c["act"], tied=self.c["tie"] == "tied",
                                           noise=self.c["symmetry_noise"], slot=slot, rnd=rnd)
            return [G, u, v]
        raise GraphError(f"unknown construction {con}")

    def branch(self, g: GraphNet, group: str, slot: str, **kw) -> str:
        tie_to = None
        if self.c["tie"] == "tied":
            prev = [k for k in g.implant_children(group) if g.implants[k].kind == "branch"]
            tie_to = prev[0] if prev else None
        w = kw.pop("width", self.c["width"])
        if self.c["width_match"] != "none":
            w = self._match_width(g, lambda h, ww: E.add_branch(h, group, self.gen(slot), width=ww, act=self.c["act"],
                                                                 tie_to=tie_to, slot=slot,
                                                                 route_split=self.c["route_split"], **dict(kw)),
                                  w, slot)
        return E.add_branch(g, group, self.gen(slot), width=w, act=self.c["act"],
                            tie_to=tie_to, slot=slot, route_split=self.c["route_split"], **kw)

    # ---------------------------------------------------------------- rounds
    def round(self, g: GraphNet, r: int, R: int) -> list[str]:
        """Apply round r (1-indexed) of the program; return new implant ids."""
        st = g.meta.setdefault("growth_state", {})
        topo = self.c["topology"]
        fn = getattr(self, f"_t_{topo}", None)
        if fn is None:
            raise Unsupported(f"topology {topo} not implemented")
        new = fn(g, r, R, st) or []
        self.log({"event": "growth_round", "round": r, "topology": topo, "new_implants": new})
        return new

    # --- core five ------------------------------------------------------------
    def _t_none(self, g, r, R, st):
        return []

    def _t_layered(self, g, r, R, st):
        shape = self.c["shape"]
        slot = f"layered/r{r}"
        if shape == "chain":
            return self.insert(g, self.backbone_cut(g, slot), slot, r)
        if shape == "wide":
            if r > 1:
                return []
            return self.insert(g, self.backbone_cut(g, slot), slot, r, width=self.c["wide_width"])
        if shape == "alternating":
            w = self.c["narrow_width"] if r % 2 == 1 else self.c["wide_width"]
            return self.insert(g, self.backbone_cut(g, slot), slot, r, width=w)
        if shape == "separated":
            n = len(E.cutpoints(g, self.c["cut_kind"]))
            idx = int(round((r - 1) * n / max(R, 1))) % n
            return self.insert(g, self.backbone_cut(g, slot, where=idx), slot, r)
        raise GraphError(shape)

    def _t_parallel(self, g, r, R, st):
        new = []
        if r == 1:
            G = E.insert_group(g, self.backbone_cut(g, "parallel/group"), self.gen("parallel/group"),
                               merge=self.c["merge"], slot="parallel/group", rnd=r)
            st["group"] = G
            new.append(G)
        for k in range(self.c["branches_per_round"]):
            new.append(self.branch(g, st["group"], f"parallel/r{r}/b{k}"))
        return new

    def _t_recursive(self, g, r, R, st):
        slot = "rec/" + "/".join(["c"] * r)
        if r == 1:
            new = self.insert(g, self.backbone_cut(g, slot), slot, r)
        else:
            new = self.insert(g, self.inner_cut(g, st["last"]), slot, r)
        st["last"] = new[0]
        return new

    def _t_recursive_branch(self, g, r, R, st):
        """odd rounds: a 2-branch group (backbone at r=1, else inside the first
        frontier implant); even rounds: a residual implant inside every frontier
        branch.  3 rounds -> 8 atoms (tree with branching at two levels)."""
        new = []
        if r % 2 == 1:
            slot = f"rb/r{r}/group"
            cut = self.backbone_cut(g, slot) if r == 1 else self.inner_cut(g, st["frontier"][0])
            G = E.insert_group(g, cut, self.gen(slot), merge=self.c["merge"], slot=slot, rnd=r)
            bs = [self.branch(g, G, f"rb/r{r}/b{k}") for k in range(2)]
            st["frontier"] = bs
            new += [G] + bs
        else:
            fr = []
            for k, b in enumerate(st["frontier"]):
                slot = f"rb/r{r}/in{k}"
                ids = self.insert(g, self.inner_cut(g, b), slot, r, construction="residual_zero")
                fr.append(ids[0])
                new += ids
            st["frontier"] = fr
        return new

    # --- E3 recursive variants --------------------------------------------------
    def _t_tree_depth2(self, g, r, R, st):
        """Final graph: group with branches b1, b2; c_k inside b_k; d_k inside c_k.
        breadth_first: r1 {G,b1,b2}, r2 {c1,c2}, r3 {d1,d2}
        depth_first:   r1 {G,b1,b2}, r2 {c1,d1}, r3 {c2,d2}"""
        new = []
        if r == 1:
            G = E.insert_group(g, self.backbone_cut(g, "tree/G"), self.gen("tree/G"), merge=self.c["merge"],
                               slot="tree/G", rnd=r)
            st["b"] = [self.branch(g, G, f"tree/b{k + 1}") for k in range(2)]
            st["c"], st["d"] = {}, {}
            return [G] + st["b"]
        bf = self.c["order"] == "breadth_first"
        plan = {2: [("c", 0), ("c", 1)], 3: [("d", 0), ("d", 1)]} if bf else \
            {2: [("c", 0), ("d", 0)], 3: [("c", 1), ("d", 1)]}
        for lvl, k in plan.get(r, []):
            if lvl == "c":
                host, slot = st["b"][k], f"tree/b{k + 1}/c"
            else:
                host, slot = st["c"][str(k)], f"tree/b{k + 1}/c/d"
            ids = self.insert(g, self.inner_cut(g, host), slot, r, construction="residual_zero")
            st[lvl][str(k)] = ids[0]
            new += ids
        return new

    def _t_hard_submodule(self, g, r, R, st):
        slot = f"hard/r{r}"
        if r == 1:
            return self.insert(g, self.backbone_cut(g, slot), slot, r)
        if self.select_fn is None:
            raise Unsupported("hard_submodule needs a training-data selection function")
        host, info = self.select_fn(g, "max_single_delta")
        self.log({"event": "hard_submodule_selection", "round": r, "host": host, **info})
        st.setdefault("selections", []).append({"round": r, "host": host, **info})
        return self.insert(g, self.inner_cut(g, host), slot, r)

    def _t_recursive_descendants(self, g, r, R, st, cap: int = 16):
        slot0 = f"desc/r{r}"
        if r == 1:
            return self.insert(g, self.backbone_cut(g, slot0), slot0, r)
        leaves = [k for k, v in g.implants.items() if not g.implant_children(k) and "hidden" in v.meta.get("cutpoints", {})]
        new = []
        for k, leaf in enumerate(sorted(leaves, key=lambda s: int(s[1:]))):
            if len(g.implants) >= cap:
                self.log({"event": "cap_reached", "cap": cap})
                break
            new += self.insert(g, self.inner_cut(g, leaf), f"{slot0}/{k}", r, construction="residual_zero")
        return new

    def _t_chain_in_branch(self, g, r, R, st):
        if r == 1:
            G = E.insert_group(g, self.backbone_cut(g, "cib/G"), self.gen("cib/G"), merge=self.c["merge"],
                               slot="cib/G", rnd=r)
            st["branch"] = self.branch(g, G, "cib/b")
            return [G, st["branch"]]
        return self.insert(g, self.inner_cut(g, st["branch"]), f"cib/r{r}", r, construction="residual_zero")

    # --- E2 branch families -------------------------------------------------------
    def _t_dup_branch(self, g, r, R, st):
        segs = g.meta.get("segments", [])
        if not segs:
            raise Unsupported("model has no duplicable segments")
        i = ((len(segs) - 1) // 2 + (r - 1)) % len(segs)
        G, o, c = E.insert_dup_branch(g, segs[i]["nodes"], self.gen(f"dup/r{r}"), tied=self.c["tie"] == "tied",
                                      split=self.c["split"], noise=self.c["symmetry_noise"], slot=f"dup/r{r}", rnd=r)
        return [G, o, c]

    def _t_cancel_pair(self, g, r, R, st):
        return self.insert(g, self.backbone_cut(g, f"cancel/r{r}"), f"cancel/r{r}", r, construction="cancel_pair")

    def _t_inverse_pair(self, g, r, R, st):
        return self.insert(g, self.backbone_cut(g, f"inv/r{r}"), f"inv/r{r}", r, construction="inverse_pair")

    def _t_linear_factor(self, g, r, R, st):
        return self.insert(g, self.backbone_cut(g, f"lf/r{r}"), f"lf/r{r}", r, construction="linear_factor")

    def _t_concat_expand(self, g, r, R, st):
        return self.insert(g, self.backbone_cut(g, f"cx/r{r}"), f"cx/r{r}", r, construction="concat_expand")

    def _backbone_maps(self, g: GraphNet) -> list[str]:
        """Backbone linear / conv nodes of the model's segments, in order (factorisation / split sites)."""
        live = g.live_nodes()
        out = [n for s_ in g.meta.get("segments", []) for n in s_["nodes"]
               if g.nodes.get(n) and g.nodes[n].op in ("linear", "conv") and g.nodes[n].owner is None and n in live]
        if not out:
            out = [n for n in g.topo_order() if g.nodes[n].op in ("linear", "conv") and g.nodes[n].owner is None
                   and n in live and n != g.output]
        return out

    def _site(self, g: GraphNet, r: int) -> str:
        lins = self._backbone_maps(g)
        if not lins:
            raise Unsupported("no backbone linear / conv nodes to factorise or split")
        w = self.c["cut_where"]
        base = {"early": 0, "middle": (len(lins) - 1) // 2, "late": len(lins) - 1}.get(w, w if isinstance(w, int) else 0)
        return lins[(int(base) + r - 1) % len(lins)]

    def _t_node_factorization(self, g, r, R, st):
        nid = self._site(g, r)
        return [E.factorize_node(g, nid, self.gen(f"nf/r{r}"), width=None, slot=f"nf/r{r}", rnd=r,
                                 balance=float(self.c["factor_balance"]))]

    # --- strengthening extension (v3) ----------------------------------------------
    def _t_node_split(self, g, r, R, st):
        """F01b: a compatible affine operation split across two additive branches (balance growth.split)."""
        nid = self._site(g, r)
        return [E.split_node(g, nid, self.gen(f"ns/r{r}"), split=float(self.c["split"]), slot=f"ns/r{r}", rnd=r)]

    def _t_bottleneck(self, g, r, R, st):
        """F01e: rank-k (optionally quantised) series interface, PCA-initialised on training
        calibration activations of the cut; declared approximate (its insertion loss is recorded)."""
        slot = f"bn/r{r}"
        cut = self.backbone_cut(g, slot)
        if g.layout != "vec":
            raise Unsupported("bottleneck interface implemented for vector models")
        k = int(self.c["bottleneck_dim"])
        n = min(2048, len(self.bundle.train))
        X = {kk: v[:n] for kk, v in self.bundle.train.X.items()}
        was = g.training
        g.eval()
        with torch.no_grad():
            _, vals = g(X, return_nodes=[cut.source])
        g.train(was)
        H = vals[cut.source].double()
        if cut.channels is not None:
            H = H[:, cut.channels]
        mu = H.mean(0)
        U, S, Vh = torch.linalg.svd(H - mu, full_matrices=False)
        if k >= H.shape[1]:
            raise Unsupported("bottleneck rank must be below the cut dimension")
        A = Vh[:k]
        iid = E.insert_bottleneck(g, cut, self.gen(slot), k, int(self.c["bottleneck_bits"]), A_init=A, mean=mu,
                                  slot=slot, rnd=r)
        if self.c["bottleneck_bits"]:
            qn = g.implants[iid].meta["bottleneck"]["code"]
            with torch.no_grad():
                _, v2 = g(X, return_nodes=[g.nodes[qn].inputs[0]])
            g.mods[g.nodes[qn].pkey].calibrate(v2[g.nodes[qn].inputs[0]], gen=self.gen(slot + "/q"))
        ev = (S[:k] ** 2).sum() / (S ** 2).sum().clamp_min(1e-12)
        g.implants[iid].meta["bottleneck"].update({"pca_explained_variance": float(ev), "init_data": "train calib"})
        return [iid]

    def _t_chunked(self, g, r, R, st):
        """F03e: coordinatewise branches: n_chunks residual implants, each reading and writing only
        its own disjoint channel chunk of the cut (no cross-chunk communication inside the implants)."""
        cut0 = self.backbone_cut(g, f"chunk/r{r}")
        d = g.node_dim(cut0.source)
        m = int(self.c["n_chunks"])
        if m < 2 or m > d:
            raise Unsupported("n_chunks must be in [2, cut dimension]")
        new = []
        self._wm_frac = 1.0 / m                    # equal-cost panel: the round's budget split over the chunks
        try:
            for k in range(m):
                lo, hi = k * d // m, (k + 1) * d // m
                c = self.backbone_cut(g, f"chunk/r{r}/{k}")
                c.channels = list(range(lo, hi))
                new += self.insert(g, c, f"chunk/r{r}/{k}", r, construction="residual_zero")
        finally:
            self._wm_frac = 1.0
        return new

    def _t_diamond(self, g, r, R, st):
        """F03d: reconvergent paths with a shared downstream consumer: round 1 adds a branch group
        at the cut and a zero-output bridge from that branch's hidden layer to a LATER cut, so the
        branch's hidden activations have two downstream consumers; later rounds grow inside the branch."""
        if r == 1:
            if g.layout != "vec":
                raise Unsupported("diamond topology implemented for vector models")
            G = E.insert_group(g, self.backbone_cut(g, "diamond/G"), self.gen("diamond/G"), merge=self.c["merge"],
                               slot="diamond/G", rnd=r)
            self._wm_frac = 0.5                    # equal-cost panel: round 1 = branch + bridge, half each
            try:
                b = self.branch(g, G, "diamond/b")
            finally:
                self._wm_frac = 1.0
            hid = g.implants[b].meta.get("cutpoints", {}).get("hidden")
            if not hid:
                raise Unsupported("branch has no hidden cutpoint for the reconvergent bridge")
            src = g.nodes[hid[0][0]].inputs[hid[0][1]]
            cps = E.cutpoints(g, self.c["cut_kind"])
            cur = E.cut_at(g, self.c["cut_kind"], self.c["cut_where"]).source
            idx = [i for i, cp in enumerate(cps) if E.resolve_edges(g, cp["edges"]).source == cur]
            later = (idx[0] + 1) if idx else len(cps) - 1
            if later >= len(cps):
                raise Unsupported("no later cutpoint for the reconvergent bridge")
            c2 = E.cut_at(g, self.c["cut_kind"], later)
            c2.branch_source = src
            wb = self.c["width"]
            if self.c["width_match"] != "none":
                import copy as _cp
                self._wm_frac = 0.5
                try:
                    wb = self._match_width(g, lambda h, ww: E.insert_bridge(h, _cp.deepcopy(c2), self.gen("diamond/bridge"),
                                                                            width=ww, act=self.c["act"],
                                                                            slot="diamond/bridge", rnd=r),
                                           wb, "diamond/bridge")
                finally:
                    self._wm_frac = 1.0
            br = E.insert_bridge(g, c2, self.gen("diamond/bridge"), width=wb, act=self.c["act"],
                                 slot="diamond/bridge", rnd=r)
            st["branch"] = b
            return [G, b, br]
        return self.insert(g, self.inner_cut(g, st["branch"]), f"diamond/r{r}", r, construction="residual_zero")

    def _t_twin_helpers(self, g, r, R, st):
        """Mechanism G: two independently initialised helper branches in one group (one branch for
        helper_schedule=single), each with its own gate; the availability schedule is applied by the
        trajectory during training (both / alternate / stochastic)."""
        if r > 1:
            return []
        G = E.insert_group(g, self.backbone_cut(g, "twin/G"), self.gen("twin/G"), merge="sum", slot="twin/G", rnd=r)
        n = 1 if self.c["helper_schedule"] == "single" else 2
        bs = [self.branch(g, G, f"twin/h{k}") for k in range(n)]
        st["helpers"] = bs
        st["helper_gates"] = [E.add_gate(g, b, 1.0) for b in bs]
        return [G] + bs

    def _t_complementary(self, g, r, R, st):
        """Branches see different inputs: a disjoint channel chunk of the cut,
        and (vector models) a bridge from the network input."""
        new = []
        if r == 1:
            G = E.insert_group(g, self.backbone_cut(g, "comp/G"), self.gen("comp/G"), merge=self.c["merge"],
                               slot="comp/G", rnd=r)
            st["group"] = G
            new.append(G)
        G = st["group"]
        d = g.node_dim(g.implants[G].entry)
        nchunk = 4
        k = (r - 1) % nchunk
        lo, hi = k * d // nchunk, (k + 1) * d // nchunk
        new.append(self.branch(g, G, f"comp/r{r}/chunk", channels=list(range(lo, hi))))
        if g.layout == "vec" and "x" in g.inputs:
            new.append(self.branch(g, G, f"comp/r{r}/input", input_node=g.inputs["x"]))
        return new

    def _t_specialized(self, g, r, R, st):
        """Branches trained on different sub-distributions (gradient masks
        'spec_a'/'spec_b', defined from TRAINING labels/groups/inputs only) or
        with an auxiliary objective head.  Explicitly a deliberate intervention."""
        new = []
        if r == 1:
            G = E.insert_group(g, self.backbone_cut(g, "spec/G"), self.gen("spec/G"), merge=self.c["merge"],
                               slot="spec/G", rnd=r)
            st["group"] = G
            new.append(G)
        G = st["group"]
        if self.c["specialize"] == "aux":
            aux_dim = self.bundle.out_dim
            new.append(self.branch(g, G, f"spec/r{r}/aux", aux_dim=aux_dim))
        else:
            new.append(self.branch(g, G, f"spec/r{r}/a", specialize_mask="spec_a"))
            new.append(self.branch(g, G, f"spec/r{r}/b", specialize_mask="spec_b"))
        return new

    def _t_bridge(self, g, r, R, st):
        if "x" not in g.inputs or g.layout != "vec":
            raise Unsupported("bridge topology implemented for vector models")
        cut = self.backbone_cut(g, f"bridge/r{r}")
        src = g.inputs["x"]
        sel = self.c["bridge_inputs"]
        info = {"bridge_inputs": sel}
        if sel != "all":
            lay = self.bundle.meta.get("feature_layout")
            if not lay:
                raise Unsupported("bridge_inputs needs a dataset with a declared feature_layout")
            if sel == "random":
                # randomized feature assignment of the helper (seeded, recorded)
                sel = ["causal", "shortcut"][int(torch.randint(2, (1,), generator=self.gen("bridge/assign")))]
            lo_hi = lay[sel]
            idx = list(range(lo_hi[0], lo_hi[1])) if isinstance(lo_hi, list) else [int(lo_hi)]
            st.setdefault("bridge_select", {})
            key = ",".join(map(str, idx))
            if key not in st["bridge_select"]:
                st["bridge_select"][key] = g.add_node("select", [src], {"idx": idx, "dim": len(idx)},
                                                      role="bridge_inputs")
            src = st["bridge_select"][key]
            info.update({"assigned": sel, "input_features": idx})
        cut.branch_source = src
        iid = E.insert_bridge(g, cut, self.gen(f"bridge/r{r}"), width=self.c["width"], act=self.c["act"],
                              slot=f"bridge/r{r}", rnd=r)
        g.implants[iid].meta["helper"] = info
        return [iid]

    def _t_known_module(self, g, r, R, st):
        if r > 1:
            return []
        if g.layout != "vec":
            raise Unsupported("known-module implants implemented for vector models")
        if self.known_module_fn is None:
            raise Unsupported("known-module implant needs a module factory")
        cut = self.backbone_cut(g, "known")
        # input access: the raw input (extra context; disclosed) or the cut itself (matched access, F10e)
        cut.branch_source = g.inputs["x"] if self.c["known_access"] == "x" else cut.source
        module, attrs, k_out, info = self.known_module_fn(g, cut.branch_source)
        info["input_access"] = self.c["known_access"]
        iid = E.insert_bridge(g, cut, self.gen("known"), module=module, module_out=k_out, module_attrs=attrs,
                              construction=f"known_{self.c['known_module']}", slot="known", rnd=r)
        g.implants[iid].meta["known_module"] = info
        return [iid]


# =============================================================================
# I4 communication-limited implant: h + D(Q(E(act(A h)))),  D = 0
# =============================================================================

def insert_residual_peg(g: GraphNet, cut: E.Cut, gen, width: int, act: str, k: int, bits: int = 0,
                        slot: str = "", rnd=None) -> str:
    def body(g, h, iid, d, gen_, p):
        a = E._linear(g, h, d, width, iid, "A", gen, base_attrs=E._dimattrs(g, h, width))
        s = g.add_node("act", [a], {"fn": act, **E._dimattrs(g, h, width)}, owner=iid, role="act")
        e = E._linear(g, s, width, k, iid, "peg_enc", gen, base_attrs=E._dimattrs(g, h, k))
        q = g.add_node("quant", [e], {"dim": k, "mode": "uniform" if bits else "none", "bits": bits or 8,
                                      **E._dimattrs(g, h, k)}, owner=iid, role="peg_quant", build=True)
        b = E._linear(g, q, k, d, iid, "B", gen, scheme="zero", base_attrs=E._dimattrs(g, h, d))
        m = g.add_node("add", [h, b], {"coefs": [1.0, 1.0], "terms": ["skip", "branch"], **E._dimattrs(g, h, d)},
                       owner=iid, role="merge")
        g.implants[iid].meta["cutpoints"] = {"hidden": [[e, 0]], "skip": [[m, 0]]}
        g.implants[iid].meta["peg"] = {"enc": e, "quant": q, "dec": b, "dim": k, "bits": bits}
        return m

    return E.insert_series(g, cut, "residual_peg", body, {"width": width, "act": act, "peg_dim": k, "bits": bits},
                           gen, "exact_identity", slot, rnd)


# =============================================================================
# E5 known-computation modules
# =============================================================================

def make_known_module(kind: str, bundle, gen: torch.Generator, width: int, pretrain: Optional[Callable] = None,
                      d_src: Optional[int] = None, src_train: Optional[torch.Tensor] = None,
                      y_train: Optional[torch.Tensor] = None):
    """Return (module, attrs, out_dim, info).  'poly' uses the dataset's known
    input groups (D03 compose: products within each level-1 pair) or all pairs
    of the first coordinates; 'pretrained' is an MLP trained by `pretrain`
    (its cost is counted by the caller); 'random_matched' is the same MLP
    architecture with random weights and no pretraining.
    v3 (F10d): 'mixing_random' is a fixed random orthogonal mixing of the source,
    'mixing_aligned' a fixed orthogonal mixing whose leading directions are the
    left singular vectors of the TRAINING cross-covariance between the source
    and the target (task-aligned), completed to an orthonormal basis; both are
    frozen (only the zero-initialised adapter learns)."""
    d_in = int(d_src) if d_src is not None else bundle.input_spec["x"]["shape"][0]
    if kind in ("mixing_random", "mixing_aligned"):
        Q = torch.linalg.qr(torch.randn(d_in, d_in, generator=gen, dtype=torch.float64))[0]
        info = {"kind": kind, "pretrain_updates": 0, "frozen": True, "d": d_in}
        if kind == "mixing_aligned":
            if src_train is None or y_train is None:
                raise Unsupported("mixing_aligned needs training source activations and targets")
            # fitted on CPU in float64 (as every other closed-form fit), so CPU and GPU runs build the same map
            Hc = src_train.detach().double().cpu()
            Hc = Hc - Hc.mean(0)
            Y = y_train.detach().double().cpu()
            Y = (torch.nn.functional.one_hot(Y.long(), int(Y.max()) + 1).double() if Y.dim() == 1 else Y)
            Yc = Y - Y.mean(0)
            U, S, _ = torch.linalg.svd(Hc.T @ Yc, full_matrices=False)
            r = int((S > 1e-9 * S.max().clamp_min(1e-30)).sum())
            M = torch.cat([U[:, :r], Q], 1)
            Q = torch.linalg.qr(M)[0][:, :d_in]          # aligned directions first, completed orthonormally
            info.update({"aligned_rank": r, "alignment_data": "train subset"})
        mod = MLPModule(d_in, [], d_in, "identity", "vec")
        with torch.no_grad():
            lin = [m for m in mod.modules() if isinstance(m, torch.nn.Linear)][0]
            lin.weight.copy_(Q.T.to(lin.weight.dtype))
            if lin.bias is not None:
                lin.bias.zero_()
        attrs = {"module_type": "mlp", "module_args": {"d_in": d_in, "hidden": [], "d_out": d_in, "act": "identity",
                                                        "layout": "vec"}}
        return mod, attrs, d_in, info
    if kind == "poly":
        groups = bundle.meta.get("intermediate_input_groups", {}).get("z")
        terms = [list(gp) for gp in groups] if groups else [[i, j] for i in range(min(d_in, 6)) for j in range(i + 1, min(d_in, 6))]
        mod = PolyModule(terms)
        attrs = {"module_type": "poly", "module_args": {"terms": terms}}
        return mod, attrs, len(terms), {"kind": "poly", "terms": terms, "pretrain_updates": 0}
    hidden = [width, width]
    out = width
    mod = MLPModule(d_in, hidden, out, "relu", "vec")
    init_module(mod, gen, "kaiming")
    attrs = {"module_type": "mlp", "module_args": {"d_in": d_in, "hidden": hidden, "d_out": out, "act": "relu",
                                                    "layout": "vec"}}
    info = {"kind": kind, "arch": attrs["module_args"], "pretrain_updates": 0}
    if kind == "pretrained":
        if pretrain is None:
            raise Unsupported("pretrained known module needs a pretraining routine")
        info.update(pretrain(mod))
    return mod, attrs, out, info
