"""Known-intermediate probes and interventions (D03 compose; spec section 13).

Probe class: ridge-regularised LINEAR probes (fixed class), fitted on
training-subset activations only and scored (R^2) on validation inputs.
Intervention: for node h with probe weights W (k x d), patch the probe
subspace of a base input with that of a source input,
    h' = h_base + P (h_src - h_base),   P = W^T (W W^T)^+ W,
and compare the patched model output with the output the known causal model
predicts when the level-1 variables are set to the source's values.  This is
a diagnostic under a stated probe class, not a unique causal attribution.
"""
from __future__ import annotations

import torch

from ..graph.graph import GraphNet


def _acts(model: GraphNet, X: dict, nodes: list[str]) -> dict:
    model.eval()
    with torch.no_grad():
        _, vals = model(X, return_nodes=nodes)
    return {k: v.flatten(1).double() for k, v in vals.items()}


def ridge(A: torch.Tensor, Y: torch.Tensor, lam: float):
    mu_a, mu_y = A.mean(0, keepdim=True), Y.mean(0, keepdim=True)
    A0, Y0 = A - mu_a, Y - mu_y
    d = A0.shape[1]
    W = torch.linalg.solve(A0.T @ A0 + lam * len(A0) * torch.eye(d, dtype=A.dtype, device=A.device), A0.T @ Y0)
    return W, mu_a, mu_y


def r2(pred: torch.Tensor, Y: torch.Tensor) -> list[float]:
    ss_res = ((pred - Y) ** 2).sum(0)
    ss_tot = ((Y - Y.mean(0)) ** 2).sum(0).clamp_min(1e-12)
    return (1 - ss_res / ss_tot).tolist()


def probe_intermediates(ctx, model: GraphNet, bundle, stage: str, n: int = 4096, lam: float = 1e-3) -> dict:
    tr, va = bundle.train, bundle.val
    nt, nv = min(n, len(tr)), min(n, len(va))
    nodes = [n_ for n_ in model.live_nodes() if model.nodes[n_].op == "act"]
    nodes = sorted(nodes, key=lambda s: int(s[1:]))
    Xt = {k: v[:nt] for k, v in tr.X.items()}
    Xv = {k: v[:nv] for k, v in va.X.items()}
    At, Av = _acts(model, Xt, nodes), _acts(model, Xv, nodes)
    out = {"probe_class": "ridge linear", "lambda": lam, "fit": f"train subset n={nt}", "score": f"val n={nv}",
           "nodes": {}}
    for var in tr.aux:
        if var.startswith("_") or var not in va.aux:
            continue                     # private training-only aux (e.g. _spec_random: a branch partition)
        Yt, Yv = tr.aux[var][:nt].double(), va.aux[var][:nv].double()
        for nid in nodes:
            W, ma, my = ridge(At[nid], Yt, lam)
            sc = r2((Av[nid] - ma) @ W + my, Yv)
            out["nodes"].setdefault(nid, {"owner": model.nodes[nid].owner, "role": model.nodes[nid].role})[var] = sc
            ctx.metric(stage, "val", f"probe_r2[{nid}:{var}]", sum(sc) / len(sc), model.structural_hash(),
                       owner=model.nodes[nid].owner)
    fz = bundle.meta.get("from_z")
    if fz is not None and "z" in tr.aux:
        out["interventions"] = {}
        st = bundle.meta.get("target_standardisation", {})
        mu = torch.tensor(st.get("mean", [0.0])).double().to(Av[nodes[0]].device)
        sd = torch.tensor(st.get("std", [1.0])).double().to(Av[nodes[0]].device)
        perm = torch.roll(torch.arange(nv, device=Av[nodes[0]].device), 1)
        for nid in nodes:
            W, ma, my = ridge(At[nid], tr.aux["z"][:nt].double(), lam)
            Wt = W.T                                   # k x d
            P = Wt.T @ torch.linalg.pinv(Wt @ Wt.T) @ Wt
            h = Av[nid]
            hp = h + (h[perm] - h) @ P.T
            shape = None

            def patch_fn(node, xs, mod, g, c, hp=hp):
                return hp.to(xs[0].dtype).view_as(xs[0])
            # run with the node's value replaced
            from ..graph.ops import FORWARD
            orig = model._plan
            model._compile()
            plan = []
            for item in model._plan:
                if item[0] == nid:
                    item = (item[0], patch_fn, *item[2:])
                plan.append(item)
            model._plan = plan
            with torch.no_grad():
                y_patch = model(Xv).double()
            model._plan = None
            with torch.no_grad():
                y_base = model(Xv).double()
            z_cf = va.aux["z"][:nv].double()[perm]
            y_cf = ((fz(z_cf.float()).double() - mu) / sd)
            err_patch = ((y_patch - y_cf) ** 2).mean().item()
            err_base = ((y_base - y_cf) ** 2).mean().item()
            out["interventions"][nid] = {"mse_patched_vs_counterfactual": err_patch,
                                         "mse_unpatched_vs_counterfactual": err_base}
            ctx.metric(stage, "val", f"interchange[{nid}].mse_patched", err_patch, model.structural_hash())
            ctx.metric(stage, "val", f"interchange[{nid}].mse_unpatched", err_base, model.structural_hash())
    ctx.save_json(f"probes_{stage}.json", out)
    return {"n_nodes": len(nodes), "vars": [v for v in tr.aux if not v.startswith("_") and v in va.aux]}
