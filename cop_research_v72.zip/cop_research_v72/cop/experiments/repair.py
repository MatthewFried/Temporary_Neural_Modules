"""R2 repair region and budget ladders, with R4 criteria recorded throughout.

The SAME deletion (chosen by a validation-only rule) is repaired under one
region x target x budget x seed per job.  Every evaluation point records all
preservation criteria (task risk, distance to the expanded model ft, distance
to the original f0, rare/shift partitions when present), so frontiers can be
drawn per criterion.  'First update reaching tolerance' is reported per
criterion; runs that never reach it are right-censored at their budget.
"""
from __future__ import annotations

import math
from pathlib import Path
from typing import Optional

import torch

from ..config import seed_of
from ..graph import edits as E
from ..graph.graph import GraphNet, InvalidDeletion
from ..train import metrics as M
from ..train.trainer import Segment, Trainer, evaluate
from ..utils import torch_gen
from . import common as C
from .context import Unsupported


def select_deletion(ft: GraphNet, bundle, rule: str, batch: int) -> list[str]:
    atoms = ft.atoms()
    if not atoms:
        raise Unsupported("model has no deletable implants")
    if rule.startswith("atoms:"):
        return rule[6:].split(",")
    if rule == "all":
        return [a for a in atoms if ft.implants[a].parent is None] or atoms
    if rule.startswith("generation:"):
        k = int(rule.split(":")[1])
        return [a for a in atoms if ft.implants[a].generation == k]
    if rule.startswith("subtree:"):
        return [rule.split(":")[1]]
    base, _ = evaluate(ft, bundle, ["val"], batch)
    scores = {}
    for a in atoms:
        try:
            r, _ = evaluate(E.delete(ft, [a]), bundle, ["val"], batch)
            scores[a] = M.headline(r["val"], bundle.task) - M.headline(base["val"], bundle.task)
        except InvalidDeletion:
            continue
    if rule == "max_single":
        return [max(scores, key=lambda k: (scores[k], -int(k[1:])))]
    if rule == "min_single":
        return [min(scores, key=lambda k: (scores[k], int(k[1:])))]
    raise ValueError(rule)


def deletion_sites(ft: GraphNet, atoms: list[str]) -> list[dict]:
    """Edges that change when the atoms are deleted (for incident adapters)."""
    sites = []
    for a in E.canonical_atoms(ft, atoms):
        imp = ft.implants[a]
        region = ft.region(a)
        if imp.kind == "series":
            cons = [(c, s) for c, s in ft.consumers(imp.exit) if c not in region]
            sites.append({"atom": a, "kind": "series", "entry": imp.entry, "consumers": cons,
                          "output": ft.output == imp.exit})
        else:
            sites.append({"atom": a, "kind": "branch", "merge": imp.merge})
    return sites


def region_nodes(g: GraphNet, sites: list[dict], region: str, radius: int) -> Optional[set[str]]:
    live = g.live_nodes()
    param = {n for n in live if g.nodes[n].pkey is not None}
    seeds = set()
    for s in sites:
        if s["kind"] == "series":
            if s["entry"] in g.nodes:
                seeds.add(s["entry"])
            seeds |= {c for c, _ in s["consumers"] if c in g.nodes}
        elif s["merge"] in g.nodes:
            seeds.add(s["merge"])
    if region == "full":
        return None
    if region == "readout":
        # F08a: the parameterised node(s) nearest the output (the readout), the rest frozen
        found, todo, seen = set(), [g.output], set()
        while todo:
            m = todo.pop()
            if m in seen or m not in g.nodes:
                continue
            seen.add(m)
            if m in param:
                found.add(m)
                continue
            todo += list(g.nodes[m].inputs)
        return found
    if region == "downstream":
        out = set()
        for n in seeds:
            out |= g.descendants(n)
        return (out | seeds) & param
    if region == "adjacent":
        # parameterised nodes within `radius` parameterised hops of the deletion edge(s);
        # unparameterised nodes (activations, merges) are traversed freely
        def first_param(start_nodes, direction):
            found, todo, seen = set(), list(start_nodes), set()
            while todo:
                m = todo.pop()
                if m in seen or m not in g.nodes:
                    continue
                seen.add(m)
                if m in param:
                    found.add(m)
                    continue
                todo += list(g.nodes[m].inputs) if direction == "up" else [c for c, _ in g.consumers(m)]
            return found
        up_front, down_front = set(), set()
        for s in sites:
            if s["kind"] == "series":
                up_front |= first_param([s["entry"]], "up") if s["entry"] in g.nodes else set()
                down_front |= first_param([c for c, _ in s["consumers"] if c in g.nodes], "down")
            elif s["merge"] in g.nodes:
                up_front |= first_param(list(g.nodes[s["merge"]].inputs), "up")
                down_front |= first_param([c for c, _ in g.consumers(s["merge"])], "down")
        out = up_front | down_front
        for _ in range(radius - 1):
            up_front = first_param([i for n in up_front for i in g.nodes[n].inputs], "up")
            down_front = first_param([c for n in down_front for c, _ in g.consumers(n)], "down")
            out |= up_front | down_front
        return out
    if region == "containing_pearl":
        pearls = g.meta.get("pearls") or [s["nodes"] for s in g.meta.get("segments", [])]
        out = set()
        anc_seed = set()
        for n in seeds:
            anc_seed |= g.ancestors(n) | {n}
        for p in pearls:
            ps = set(p)
            if ps & (seeds | {c for n in seeds for c, _ in g.consumers(n)}):
                out |= ps
        if not out:
            # site lies between pearls: take the nearest downstream pearl
            for p in pearls:
                if set(p) & set().union(*[g.descendants(n) for n in seeds]):
                    out |= set(p)
                    break
        return out & param
    raise ValueError(region)


def param_hop_distance(g: GraphNet, sites: list[dict], nodes: Optional[set[str]]) -> dict:
    """Measured repair scope in graph distance: for every trainable parameterised node, the
    number of parameterised nodes on the shortest path (either direction) from a deletion
    site, counting itself (a node next to the site has distance 1; unparameterised nodes are
    free).  Reported as max / mean / histogram next to the trainable parameter count."""
    import heapq
    live = g.live_nodes()
    param = {n for n in live if g.nodes[n].pkey is not None}
    seeds = set()
    for s_ in sites:
        if s_["kind"] == "series":
            if s_["entry"] in g.nodes:
                seeds.add(s_["entry"])
            seeds |= {c for c, _ in s_["consumers"] if c in g.nodes}
        elif s_["merge"] in g.nodes:
            seeds.add(s_["merge"])
    target = param if nodes is None else (set(nodes) & param)
    if not seeds or not target:
        return {"max": None, "mean": None, "hist": {}, "n_nodes": len(target)}
    dist = {n: (1 if n in param else 0) for n in seeds}
    h = [(d, n) for n, d in dist.items()]
    heapq.heapify(h)
    while h:
        d, n = heapq.heappop(h)
        if d > dist.get(n, 10 ** 9):
            continue
        nbrs = list(g.nodes[n].inputs) + [c for c, _ in g.consumers(n)]
        for m in nbrs:
            if m not in live:
                continue
            nd = d + (1 if m in param else 0)
            if nd < dist.get(m, 10 ** 9):
                dist[m] = nd
                heapq.heappush(h, (nd, m))
    ds = [dist[n] for n in target if n in dist]
    hist: dict[str, int] = {}
    for d in ds:
        hist[str(d)] = hist.get(str(d), 0) + 1
    return {"max": max(ds) if ds else None, "mean": sum(ds) / len(ds) if ds else None, "hist": hist,
            "n_nodes": len(target)}


def _restrict_train(bundle, n: int):
    """A bundle view whose training partition is the first n training examples only."""
    import copy as _c
    b = _c.copy(bundle)
    b.train = bundle.train.index(torch.arange(min(n, len(bundle.train))))
    return b


def run_repair(ctx) -> dict:
    """One repair job.  Resumable at update granularity: the Trainer state,
    the curve, the phase (repair | extension) and the extension decision are in
    ckpt/partial.pt; a resumed job continues the same update sequence."""
    cfg = ctx.cfg
    rc = cfg["repair"]
    bundle = C.setup_data(ctx)
    pstage = cfg.get("tags", {}).get("parent_stage", "final")
    ft = GraphNet.from_checkpoint(ctx.parent_ckpt("trajectory", pstage)["model"], ctx.device)
    f0 = GraphNet.from_checkpoint(ctx.parent_ckpt("trajectory", "baseline_ref")["model"], ctx.device)
    pcfg = ctx.parent_json("trajectory", "config.json")
    gr = pcfg["growth"]
    ref_budget = gr["rounds"] * gr["updates_per_round"] if gr["compute_schedule"] == "per_round" else gr["total_updates"]
    if pstage.startswith("round_"):
        ref_budget = int(pstage.split("_")[1]) * gr["updates_per_round"]   # growth training up to that round
    if rc["budget_reference"] == "per_round":
        ref_budget = gr["updates_per_round"]
    budget = int(round(rc["budget_multiplier"] * ref_budget))
    batch = cfg["train"]["eval_batch"]
    if rc["region"] == "fresh_original" and not ft.atoms():
        atoms = []        # a fresh compact model needs no deletion (e.g. a parent without implants)
    else:
        atoms = select_deletion(ft, bundle, rc["deletion"], batch)
    sites = deletion_sites(ft, atoms)
    if atoms:
        # P1 (v5): non-mutating diagnostics of the implants about to be removed, on the expanded model
        from .diagnostics import contraction_diagnostics
        contraction_diagnostics(ctx, ft, bundle, list(atoms), "repair_start")
    ctx.save_json("repair_setup.json", {"atoms": atoms, "sites": sites, "budget": budget, "ref_budget": ref_budget,
                                        "selection": f"rule {rc['deletion']} on validation"})
    parts = ["val", "test"] + [p for p in ("rare", "shift", "complete_domain") if p in bundle.extra]
    _, ft_preds = evaluate(ft, bundle, parts, batch, return_preds=True)
    _, f0_preds = evaluate(f0, bundle, parts, batch, return_preds=True)
    ft_res, _ = evaluate(ft, bundle, parts, batch)
    region = rc["region"]
    gen = torch_gen(seed_of(cfg, "repair"), "repair", "init")
    trainable_nodes = None
    if region in ("fresh_original", "fresh_smaller"):
        if region == "fresh_original":
            model = f0.clone(share_params=False)
        else:
            model = E.delete(ft, atoms, share_params=False)
        C.reinit_all(model, gen)
    else:
        model = E.delete(ft, atoms, share_params=False)
        if region == "incident_adapters":
            trainable_nodes = set()
            for k, s in enumerate(sites):
                if s["kind"] == "series":
                    cons = [(c, sl) for c, sl in s["consumers"] if c in model.nodes and model.nodes[c].inputs[sl] == s["entry"]]
                    if not cons and not s["output"]:
                        continue
                    cut = E.Cut(source=s["entry"], consumers=cons if cons else None)
                else:
                    cut = E.Cut(source=s["merge"]) if s["merge"] in model.nodes else None
                    if cut is None:
                        continue
                iid = E.insert_residual_zero(model, cut, torch_gen(seed_of(cfg, "repair"), "repair", f"adapter{k}"),
                                             width=rc["adapter_width"], slot=f"adapter{k}")
                trainable_nodes |= set(model.implants[iid].nodes)
        elif region != "none":
            trainable_nodes = region_nodes(model, sites, region, rc["adjacent_radius"])
            if trainable_nodes is not None and not trainable_nodes:
                raise Unsupported(f"region {region} contains no parameters for this deletion")
    model = model.to(ctx.device)
    teacher = {"task": None, "expanded": ft, "original": f0}[rc["target"]]
    seeds = {"minibatch": seed_of(cfg, "repair"), "augmentation": seed_of(cfg, "repair")}
    # F08e data-access ladder: what the repair may train on
    access = rc["data_access"]
    tcfg = dict(cfg["train"])
    tbundle = bundle
    if access == "calibration":
        tbundle = _restrict_train(bundle, int(rc["calibration_size"]))
    elif access == "fresh":
        if bundle.fresh_sampler is None:
            raise Unsupported("repair.data_access=fresh needs a dataset with a fresh-sample stream")
        tcfg["stream"] = "fresh"
    elif access == "checkpoint":
        # recovery ORACLE: the repair region starts from the parent's pre-growth (f0) tensors where they exist
        restored = []
        for nid in (trainable_nodes if trainable_nodes is not None else
                    {n for n in model.live_nodes() if model.nodes[n].pkey is not None}):
            if nid in f0.nodes and f0.nodes[nid].pkey is not None and model.nodes[nid].pkey is not None and \
                    model.nodes[nid].owner is None:
                src_m, dst_m = f0.mods[f0.nodes[nid].pkey], model.mods[model.nodes[nid].pkey]
                if all(a.shape == b.shape for a, b in zip(src_m.state_dict().values(), dst_m.state_dict().values())):
                    with torch.no_grad():
                        dst_m.load_state_dict({k_: v.detach().clone() for k_, v in src_m.state_dict().items()})
                    restored.append(nid)
        ctx.log({"event": "oracle_checkpoint_restore", "nodes": sorted(restored)})
    tr = Trainer(model, tbundle, tcfg, seeds, ctx.device, ctx.log, "repair")
    n_eval = max(1, rc["eval_points"])
    scale2 = float(bundle.target_scale) ** 2
    curve: list[dict] = []
    state = {"phase": "repair", "extended": False, "extra": 0}

    def crit_eval(trn, step):
        ctx.updates, ctx.examples = trn.state["global_step"], trn.state["examples"]
        res, preds = evaluate(trn.model, bundle, parts, batch, return_preds=True)
        row = {"update": step}
        for p in parts:
            row[f"{p}.risk"] = M.headline(res[p], bundle.task)
            if "acc" in res[p]:
                row[f"{p}.acc"] = res[p]["acc"]
                row[f"{p}.acc_drop_pp_vs_ft"] = (ft_res[p]["acc"] - res[p]["acc"]) * 100
            else:
                row[f"{p}.mse_increase_vs_ft"] = res[p]["mse"] - ft_res[p]["mse"]
                # normalised excess risk: same units as criteria.nmse (target-scale invariant)
                row[f"{p}.nmse_increase_vs_ft"] = (res[p]["mse"] - ft_res[p]["mse"]) / (scale2 + 1e-12)
            d_ft = M.drift(preds[p], ft_preds[p], bundle.task, bundle.partitions()[p].y, bundle.target_scale)
            d_f0 = M.drift(preds[p], f0_preds[p], bundle.task, bundle.partitions()[p].y, bundle.target_scale)
            key = "nmse" if bundle.task == "regression" else "js"
            row[f"{p}.dist_expanded"] = d_ft[key]
            row[f"{p}.dist_original"] = d_f0[key]
        for k, v in row.items():
            if k != "update":
                part, name = k.split(".", 1)
                ctx.metric(f"repair@{step}", part, name, v, trn.model.structural_hash())
        curve.append(row)
        return {}

    def ckpt():
        ctx.save_ckpt("partial", tr.model, tr, {"curve": curve, **state})

    resumed = False
    if ctx.has_ckpt("partial"):
        ck = ctx.load_ckpt("partial")
        model = GraphNet.from_checkpoint(ck["model"], ctx.device)
        tr = Trainer(model, tbundle, tcfg, seeds, ctx.device, ctx.log, "repair")
        tr.load_state_dict(ck["trainer"])
        curve[:] = ck["extra"]["curve"]
        state.update({k: ck["extra"][k] for k in ("phase", "extended", "extra")})
        if "opt_state_carried" in ck["extra"]:
            state["opt_state_carried"] = ck["extra"]["opt_state_carried"]
        resumed = True
        ctx.log({"event": "resume", "phase": state["phase"], "global_step": tr.state["global_step"]})
    else:
        ctx.save_ckpt("before_repair", model)
        crit_eval(tr, 0)
    sel = C.Selector(ctx, bundle, "repair")
    if region != "none" and budget > 0:
        if not resumed:
            if region not in ("fresh_original", "fresh_smaller", "full"):
                tr.configure("none", None, reset_state=True, extra_trainable=trainable_nodes)
            else:
                tr.configure("none", None, reset_state=True)
            if rc["opt_state"] == "preserve":
                state["opt_state_carried"] = _carry_parent_opt(ctx, pstage, tr)
        if state["phase"] == "repair":
            pts = sorted({max(1, int(round(budget * (i + 1) / n_eval))) for i in range(n_eval)})
            # v13: validation-selection candidates over the PLANNED repair budget only (an adaptive extension
            # would give this arm more selection opportunities than its controls)
            sel_pts = set(sel.points(budget)) if sel.enabled else set()

            def sel_step(trn, k):
                if k > 0 and k in sel_pts:
                    sel.consider(trn.model, trn.state["global_step"], k, f"repair@{k}", trn)
                    trn.model.train()
            seg = Segment("repair", budget, target=rc["target"], teacher=teacher, eval_points=pts, eval_fn=crit_eval,
                          on_step=sel_step if sel_pts else None)
            r_seg = tr.run(seg, checkpoint_cb=ckpt)
            if int(r_seg["updates"]) in sel_pts:
                sel.consider(tr.model, tr.state["global_step"], int(r_seg["updates"]), f"repair@{r_seg['updates']}", tr)
            reach = reach_table(curve, cfg["criteria"], bundle.task)
            need = extension_needed(reach, cfg["criteria"], bundle.task, rc)
            extra = int(round(budget * (rc["extension_factor"] - 1)))
            state.update({"phase": "extension" if (need and extra > 0) else "done", "extended": bool(need and extra > 0),
                          "extra": extra if (need and extra > 0) else 0})
            ckpt()
        if state["phase"] == "extension":
            off = budget
            extra = state["extra"]

            def ext_eval(trn, step):
                return crit_eval(trn, off + step)
            pts = sorted({max(1, int(round(extra * (i + 1) / n_eval))) for i in range(n_eval)})
            seg = Segment("repair_extension", extra, target=rc["target"], teacher=teacher, eval_points=pts,
                          eval_fn=ext_eval)
            tr.run(seg, checkpoint_cb=ckpt)
            state["phase"] = "done"
            ckpt()
    total_done = tr.state["global_step"]
    ctx.updates, ctx.examples = tr.state["global_step"], tr.state["examples"]
    # the curve always ends at the actual endpoint (V3-01): a run that diverged (or stopped) between
    # evaluation points is evaluated where it stopped, so no earlier row can stand in for its endpoint
    last_u = max([r["update"] for r in curve], default=None)
    final_u = int(total_done)          # the repair trainer starts at 0: its step count is the repair's update index
    if region != "none" and budget > 0 and last_u != final_u:
        crit_eval(tr, final_u)
    reach = reach_table(curve, cfg["criteria"], bundle.task)
    n_tr = 0 if tr.opt is None else sum(p.numel() for gp in tr.opt.param_groups for p in gp["params"]
                                        if p.requires_grad)
    scope = param_hop_distance(model, sites, trainable_nodes) if region not in ("fresh_original",
                                                                                 "fresh_smaller") else \
        {"max": None, "mean": None, "hist": {}, "n_nodes": None, "note": "fresh model: no deletion site"}
    out = {"atoms": atoms, "region": region, "target": rc["target"], "budget": budget, "updates_done": total_done,
           "examples_seen": tr.state["examples"], "extended": state["extended"], "extension_rule": rc["extend_on"],
           "n_trainable": n_tr, "reach": reach, "curve": curve, "train_seconds": tr.timing["train_seconds"],
           "eval_resolution_updates": sorted({r["update"] for r in curve}),
           "repair_graph_distance": scope, "data_access": access, "opt_state": rc["opt_state"],
           "opt_state_carried": state.get("opt_state_carried"),
           "trainable_nodes": None if trainable_nodes is None else sorted(trainable_nodes, key=lambda s_: int(s_[1:])),
           "diverged": bool(tr.state.get("diverged")),
           "termination_reason": "diverged" if tr.state.get("diverged") else
           ("reached" if any(v is not None for v in (reach.get("task") or {}).values())
            else "censored_at_budget")}
    ctx.count_work("repair", updates=total_done, examples=tr.state["examples"], seconds=tr.timing["train_seconds"],
                   macs=int(tr.state.get("train_macs", 0)), macs_bwd=int(tr.state.get("train_macs_bwd", 0)), teacher_macs=int(tr.state.get("teacher_macs", 0)))
    ctx.save_ckpt("after_repair", tr.model, tr)
    ctx.ckpt_path("partial").unlink(missing_ok=True)
    C.record_endpoint(ctx, bundle, "after_repair", bool(tr.state.get("diverged")), tr.state.get("diverged_reason"),
                      {"repair_updates_done": final_u if region != "none" and budget > 0 else 0,
                       "termination_reason": out["termination_reason"]})
    sel.ensure_final(tr.model, tr.state["global_step"], final_u if region != "none" and budget > 0 else 0,
                     "final", tr)
    sel.record(bundle, bool(tr.state.get("diverged")), tr.state.get("diverged_reason"), tr.state.get("diverged_at"))
    ctx.save_json("repair_result.json", out)
    return {k: v for k, v in out.items() if k != "curve"}


def _carry_parent_opt(ctx, pstage: str, tr: Trainer) -> int:
    """repair.opt_state=preserve: the parent's optimizer state for every surviving trainable
    tensor (matched by 'pkey.name'); returns the number of tensors carried."""
    ck = ctx.parent_ckpt("trajectory", pstage)
    pt = ck.get("trainer") or {}
    names, opt = pt.get("opt_param_names") or [], pt.get("opt")
    if not names or opt is None or tr.opt is None:
        raise Unsupported("repair.opt_state=preserve needs a parent checkpoint with optimizer state and names")
    by_name = {n: i for i, n in enumerate(names)}
    carried = 0
    flat = [p for gp in tr.opt.param_groups for p in gp["params"]]
    for p, n in zip(flat, tr.opt_param_names):
        i = by_name.get(n)
        if i is None or i not in opt["state"]:
            continue
        stt = opt["state"][i]
        if any(isinstance(v, torch.Tensor) and v.dim() > 0 and v.shape != p.shape for v in stt.values()):
            continue
        # v39: torch's own placement (Optimizer.load_state_dict): 'step' stays where it is (CPU) unless the group
        # is fused or capturable; floating state takes the parameter's dtype and device
        grp = next(gp for gp in tr.opt.param_groups if any(q is p for q in gp["params"]))
        on_dev = bool(grp.get("fused", False) or grp.get("capturable", False))

        def place(k, v):
            if not isinstance(v, torch.Tensor):
                return v
            if k == "step":
                return v.clone().to(dtype=torch.float32, device=p.device) if on_dev else v.clone()
            return v.clone().to(dtype=p.dtype, device=p.device) if p.is_floating_point() else v.clone().to(p.device)
        tr.opt.state[p] = {k: place(k, v) for k, v in stt.items()}
        carried += 1
    return carried


def extension_needed(reach: dict, crit: dict, task: str, rc: dict) -> bool:
    """Extend iff the deciding criterion at its LOOSEST tolerance was not reached
    within the base budget.  A first hit at update 0 counts as reached (the
    check is `is None`, never truthiness).  extend_on: 'target' = the criterion
    of the configured repair target (task -> task risk, expanded -> distance to
    ft, original -> distance to f0); 'task'; 'both' = extend if either is unmet."""
    if not rc["extend_if_inconclusive"]:
        return False
    loose_task = str((crit["nmse"] if task == "regression" else crit["acc_drop_pp"])[-1])
    loose_dist = str((crit["nmse"] if task == "regression" else crit["js"])[-1])
    tgt_key = {"task": ("task", loose_task), "expanded": ("expanded", loose_dist),
               "original": ("original", loose_dist)}[rc["target"]]
    unmet_target = reach[tgt_key[0]].get(tgt_key[1]) is None
    unmet_task = reach["task"].get(loose_task) is None
    return {"target": unmet_target, "task": unmet_task, "both": unmet_target or unmet_task}[rc["extend_on"]]


def reach_table(curve: list[dict], crit: dict, task: str) -> dict:
    """First evaluated update meeting each tolerance on validation; None = censored."""
    out = {"task": {}, "expanded": {}, "original": {}}
    tols_task = crit["nmse"] if task == "regression" else crit["acc_drop_pp"]
    tols_dist = crit["nmse"] if task == "regression" else crit["js"]
    for tol in tols_task:
        key = "val.nmse_increase_vs_ft" if task == "regression" else "val.acc_drop_pp_vs_ft"
        hit = next((r["update"] for r in curve if r.get(key, math.inf) <= tol), None)
        out["task"][str(tol)] = hit
    for tol in tols_dist:
        out["expanded"][str(tol)] = next((r["update"] for r in curve if r.get("val.dist_expanded", math.inf) <= tol), None)
        out["original"][str(tol)] = next((r["update"] for r in curve if r.get("val.dist_original", math.inf) <= tol), None)
    out["censoring"] = "None means not reached within the evaluated budget (right-censored), not infinite cost"
    out["units"] = {"task": "regression: (MSE - MSE_ft) / target_scale^2 (criteria.nmse); classification: accuracy "
                            "drop in percentage points (criteria.acc_drop_pp)",
                    "expanded/original": "nmse (regression) or Jensen-Shannon (classification) to ft / f0"}
    out["selection_note"] = ("first VALIDATION evaluation point meeting the tolerance (a selected event at the curve's "
                             "resolution); report test risk at that point and the full curve")
    return out
