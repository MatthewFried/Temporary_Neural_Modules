"""Baseline and growth-trajectory jobs (E1-E5, I1-I4, Wave 1-3).

Trajectory stages (each checkpointed; resumable):
  baseline_ref                  f0 loaded from the shared baseline parent (or trained inline)
  post_insert_r{r} / round_{r}  incremental schedule
  final                         end state + R1 deletion family, crossover, probes, export check
All topologies of one cell start from the SAME parent checkpoint including
its optimizer and minibatch-generator state, so the minibatch sequence after
the baseline is identical across topologies (insertion randomness has its own
stream).  The continued baseline fc is the 'none' topology of the same cell.
"""
from __future__ import annotations

import copy
import hashlib
import math
import time
from typing import Optional

import torch
import torch.nn.functional as F

from ..config import seed_of
from ..graph import edits as E
from ..graph.export import export_compact
from ..graph.graph import GraphNet, InvalidDeletion
from ..train import metrics as M
from ..train.trainer import Segment, Trainer, evaluate, predict, task_loss, LocalOpt
from ..utils import torch_gen, interrupted, atomic_torch_save
from . import common as C
from .context import Unsupported, ScientificInvalid, StaleParent
from .deletion import evaluate_family
from .growth import Grower, make_known_module


# =============================================================================
# Baseline
# =============================================================================

def _val_eval_fn(ctx, bundle):
    def fn(tr: Trainer, step: int) -> dict:
        res, _ = evaluate(tr.model, bundle, ["val"], ctx.cfg["train"]["eval_batch"])
        return {f"val_{k}": v for k, v in res["val"].items() if isinstance(v, (int, float))}
    return fn


def _eval_points(n: int, every: int) -> list[int]:
    if not every:
        return []
    return list(range(every, n + 1, every))


def train_baseline(ctx, bundle, stage: str = "baseline", selector=None) -> tuple[GraphNet, Trainer]:
    cfg = ctx.cfg
    model = C.new_model(cfg, bundle, ctx.device)
    tr = C.make_trainer(ctx, model, bundle, "main")
    if ctx.has_ckpt(f"partial_{stage}"):
        ck = ctx.load_ckpt(f"partial_{stage}")
        model = GraphNet.from_checkpoint(ck["model"], ctx.device)
        tr = C.make_trainer(ctx, model, bundle, "main")
        tr.load_state_dict(ck["trainer"])
        ctx.log({"event": "resume", "stage": stage, "seg_step": tr.state["seg_step"]})
    else:
        tr.configure("none", None)
    n = cfg["train"]["baseline_updates"]
    sel_pts = set(selector.points(n)) if selector is not None and selector.enabled else set()

    def sel_hook(trn, k):
        if k > 0 and k in sel_pts:
            selector.consider(trn.model, trn.state["global_step"], k, f"{stage}@{k}", trn)
            trn.model.train()
    seg = Segment(stage, n, eval_points=_eval_points(n, cfg["train"]["eval_every"]), eval_fn=_val_eval_fn(ctx, bundle),
                  on_step=chain_hooks(snapshot_hook(ctx, set(cfg["train"]["snapshot_at"]), 0),
                                      sel_hook if sel_pts else None))
    r_seg = tr.run(seg, checkpoint_cb=lambda: ctx.save_ckpt(f"partial_{stage}", tr.model, tr))
    if int(r_seg["updates"]) in sel_pts:
        selector.consider(tr.model, tr.state["global_step"], int(r_seg["updates"]), f"{stage}@{r_seg['updates']}", tr)
    if n in set(cfg["train"]["snapshot_at"]) and not ctx.has_ckpt(f"snap_{n}"):
        ctx.save_ckpt(f"snap_{n}", tr.model, tr, {})
    return tr.model, tr


def snapshot_hook(ctx, at: set, base: int, extra_fn=None):
    """on_step hook saving a full checkpoint 'snap_<u>' when u updates of this job's own
    training are done (u = global_step - base).  Idempotent (a resumed job re-saves the same state)."""
    if not at:
        return None

    def hook(trn, k):
        u = int(trn.state["global_step"]) - int(base)
        if u in at and not ctx.has_ckpt(f"snap_{u}"):
            ctx.save_ckpt(f"snap_{u}", trn.model, trn, extra_fn(trn) if extra_fn else {})
    return hook


def chain_hooks(*hooks):
    hs = [h for h in hooks if h is not None]
    if not hs:
        return None

    def f(trn, k):
        for h in hs:
            h(trn, k)
    return f


def run_baseline(ctx) -> dict:
    bundle = C.setup_data(ctx)
    # v13: f0 selection by a declared validation rule (train.select_candidates); descendants of the selected
    # panel start from checkpoint 'best_val' (tags.f0_stage / continue.start_stage = best_val)
    sel = C.Selector(ctx, bundle, "baseline")
    if not ctx.has_ckpt("baseline"):
        model, tr = train_baseline(ctx, bundle, selector=sel)
        ctx.updates, ctx.examples = tr.state["global_step"], tr.state["examples"]
        ctx.save_ckpt("baseline", model, tr)
        ctx.ckpt_path("partial_baseline").unlink(missing_ok=True)
    ck = ctx.load_ckpt("baseline")
    model = GraphNet.from_checkpoint(ck["model"], ctx.device)
    ctx.updates = ck["trainer"]["state"]["global_step"]
    ctx.examples = ck["trainer"]["state"]["examples"]
    # v13 (audit A2): the baseline's training work, from the saved checkpoint's absolute counters, so the
    # record is the same after an uninterrupted run, a resumed run, or a rerun that finds the checkpoint
    from .continuation import BASELINE_PHASE, _counters
    ctx.set_work(BASELINE_PHASE, {**_counters(ck["trainer"]["state"]),
                                  "seconds": float((ck["trainer"].get("timing") or {}).get("train_seconds", 0.0)),
                                  "recorded_from": "ckpt/baseline.pt trainer counters"})
    res, _ = C.eval_log(ctx, model, bundle, "baseline", save_preds=True)
    acct = C.log_accounting(ctx, model, "baseline", C.seq_T(bundle))
    ctx.save_graph("baseline", model)
    tq = training_quality(res, bundle)
    ctx.metric("baseline", "val", "training_quality", tq)
    ts = ck["trainer"]["state"]
    C.record_endpoint(ctx, bundle, "baseline", bool(ts.get("diverged")), ts.get("diverged_reason"))
    if sel.enabled and sel.state.get("best") is None:
        # the saved baseline state is the only candidate left: keep its full trainer state with it, so a
        # descendant of best_val resumes the same optimizer, RNG and data streams
        class _SavedTrainer:
            def state_dict(self, _d=ck["trainer"]):
                return _d
        sel.ensure_final(model, ts["global_step"], ts["global_step"], "baseline", trainer=_SavedTrainer())
    sel.record(bundle, bool(ts.get("diverged")), ts.get("diverged_reason"), ts.get("diverged_at"))
    record_witness(ctx, bundle, model)
    return {"val": res.get("val"), "test": res.get("test"), "params": acct["params"], "training_quality": tq,
            "train_seconds": ck["trainer"]["timing"]["train_seconds"]}


def record_witness(ctx, bundle, template: GraphNet) -> Optional[dict]:
    """P0 (v5): for a known-teacher dataset, the constructive compact witness in THIS job's
    architecture (data.witness), verified against the noiseless teacher and saved as checkpoint
    'witness'; or the reason why the teacher is not exactly realisable (a mismatch condition).
    witness.json is read by the analysis for loss-compatible gap closure."""
    if bundle.name not in ("teacher", "easy_teacher"):
        return None
    from ..data.witness import build_witness, verify_witness
    from ..train.trainer import evaluate
    wg, info = build_witness(bundle, ctx.cfg["model"], template)
    if wg is not None:
        ver = verify_witness(wg, bundle, ctx.cfg["train"]["eval_batch"])
        info["verification"] = ver
        res, _ = evaluate(wg, bundle, ["train", "val", "test"], ctx.cfg["train"]["eval_batch"])
        info["risk"] = {p: {k: v for k, v in m.items() if isinstance(v, (int, float))} for p, m in res.items()}
        info["loss_reference"] = ("mse on clean held-out targets (noise is added to training targets only)"
                                  if bundle.task == "regression" else
                                  "accuracy only: argmax labels are reproduced, the cross-entropy infimum is not attained")
        ctx.save_ckpt("witness", wg)
        if not ver["verified"]:
            info["realizable"] = False
            info["reason"] = f"numerical check failed (max abs err {ver['max_abs_err']:.3g})"
    ctx.save_json("witness.json", info)
    return info


def training_quality(res: dict, bundle) -> str:
    """Coarse label kept with every row: never used to drop rows."""
    v = res.get("val", {})
    if bundle.task == "regression":
        m = v.get("mse", float("nan"))
        return "fit" if m < 0.1 else ("partial" if m < 0.5 else "poor")
    a = v.get("acc", float("nan"))
    chance = 1.0 / max(2, bundle.out_dim)
    if a != a:
        return "unknown"
    return "fit" if a > 0.9 else ("partial" if a > chance + 0.1 else "poor")


# =============================================================================
# Driver helpers (I2) and conditions (I4)
# =============================================================================

def _second_teacher(bundle, teacher_seed: int, seed_offset: int = 7919):
    from ..data.synthetic import make_teacher, teacher_raw
    t0 = bundle.meta.get("teacher")
    if t0 is None or bundle.task != "regression":
        raise Unsupported("changing_target needs a regression teacher dataset (D02)")
    dims = t0["dims"]
    t1 = make_teacher(int(teacher_seed) + seed_offset, "teacher_shift", dims[0], dims[1],
                      len(dims) - 2, dims[-1], t0["act"], t0["gain"], t0["bias_std"])
    g = torch_gen(int(teacher_seed) + seed_offset, "teacher", "teacher_shift", "reference")
    xr = torch.randn(65536, dims[0], generator=g)
    yr = teacher_raw(t1, xr)
    t1["target_mean"], t1["target_std"] = yr.mean(0), yr.std(0, unbiased=False).clamp_min(1e-8)
    return t0, t1


def _teacher_eval(t: dict, x: torch.Tensor) -> torch.Tensor:
    from ..data.synthetic import teacher_forward
    return teacher_forward(t, x)


SPEC_PARTITIONS = ("auto", "group", "observed_label", "random_matched", "redrawn_random", "all_examples",
                   "cyclic_blocks", "matched_quota")


def replay_minibatch_indices(trn, n: int) -> torch.Tensor:
    """v23: the example indices of the trainer's next n uniform minibatches, WITHOUT consuming its streams (the
    sampler shuffles without replacement per epoch from the 'minibatch' generator; a copy of the generator state
    and of the epoch position is advanced instead).  Other samplers are refused."""
    if trn.t.get("stream") == "fresh" or trn.t.get("sampler", "uniform") != "uniform":
        raise Unsupported("matched_quota needs the uniform without-replacement sampler on a fixed training set")
    g = torch.Generator()
    g.set_state(trn.gens["minibatch"].get_state())
    N, B = len(trn.bundle.train), int(trn.B)
    perm = trn.state["perm"].clone() if trn.state["perm"] is not None else None
    pos = int(trn.state["pos"])
    out = torch.empty(n, B, dtype=torch.long)
    for u in range(n):
        if perm is None or pos + B > N:
            perm = torch.randperm(N, generator=g)
            pos = 0
        out[u] = perm[pos:pos + B].cpu()
        pos += B
    return out


def _even(total: int, parts: int) -> list[int]:
    return [total // parts + (1 if j < total % parts else 0) for j in range(parts)]


def quota_schedule(idx: torch.Tensor, n_train: int, frac: float, b_run: int, seed: int, window: int) -> dict:
    """v23: matched-exposure assignment on a KNOWN minibatch stream (idx: n_updates x batch example indices).
    Every example with n appearances in the window gets q = floor(frac x n + 1/2) appearances on branch a and
    n - q on branch b (the quota depends only on the stream, the fraction and the example, so it is identical for
    every schedule on the same stream).  The ORDER of its appearances sets the persistence: the n - q b-appearances
    form m runs (b_run = 0: one run; b_run = k >= 1: runs of at most k appearances, m = ceil((n - q) / k), at most
    q), separated by a-runs of near-equal length; the first a-run is split at a per-example offset drawn from
    (seed, window) only, so the b-runs are never cut by the window edges and the offsets are shared by every
    schedule.  Returns the per-update assignment (True = branch a) and per-example quotas."""
    U, B = idx.shape
    flat = idx.flatten()
    order = torch.argsort(flat, stable=True)            # positions grouped by example, in time order
    counts = torch.bincount(flat, minlength=n_train)
    gen = torch_gen(seed, "insertion", "spec_quota_offset", str(int(window)))
    off_u = torch.rand(n_train, generator=gen, dtype=torch.float64)
    assign = torch.zeros(U * B, dtype=torch.bool)
    q_all = torch.zeros(n_train, dtype=torch.long)
    runs_all = torch.zeros(n_train, dtype=torch.long)
    start = 0
    for i in range(n_train):
        n = int(counts[i])
        if n == 0:
            continue
        pos = order[start:start + n]
        start += n
        q = int(math.floor(frac * n + 0.5))
        nb = n - q
        q_all[i] = q
        if nb == 0:
            assign[pos] = True
            continue
        if q == 0:
            runs_all[i] = 1
            continue
        m = 1 if int(b_run) == 0 else -(-nb // int(b_run))
        m = max(1, min(m, q))
        bs, as_ = _even(nb, m), _even(q, m)
        k0 = int(math.floor(float(off_u[i]) * (as_[0] + 1)))       # leading part of the first a-run
        seq = [True] * k0
        for j in range(m):
            seq += [False] * bs[j]
            seq += [True] * (as_[(j + 1) % m] if j + 1 < m else 0)
        seq += [True] * (as_[0] - k0)
        if m == 1:
            seq = [True] * k0 + [False] * nb + [True] * (q - k0)
        assign[pos] = torch.tensor(seq, dtype=torch.bool)
        runs_all[i] = m
    return {"assign": assign.view(U, B), "quota_a": q_all, "appearances": counts, "b_runs": runs_all}


def cyclic_a_len(frac: float, period: int) -> int:
    """v22: updates per cycle that an example spends in branch a under cyclic_blocks (at least 1 in each branch)."""
    return min(int(period) - 1, max(1, int(round(float(frac) * int(period)))))


def cyclic_membership(phase: torch.Tensor, step: int, period: int, a_len: int) -> torch.Tensor:
    """v22: branch-a indicator at a trainer global step: example i is in branch a when (step + phase_i) mod period
    < a_len.  Phases are spread uniformly over the period, so every update has round(a_len / period x N) +- 1
    examples in branch a, and over any whole number of periods every example spends exactly a_len / period of
    the updates in branch a (equal exposure; the period sets only how long each stay lasts)."""
    return ((int(step) + phase.long()) % int(period)) < int(a_len)


def cyclic_phases(n: int, period: int, seed: int) -> torch.Tensor:
    """uniformly spread per-example phases: rank r_i of a random permutation -> floor(r_i x period / n)."""
    gen = torch_gen(seed, "insertion", "spec_cyclic_phase")
    rank = torch.empty(n, dtype=torch.long)
    rank[torch.randperm(n, generator=gen)] = torch.arange(n)
    return (rank * int(period)) // max(1, n)


def _spec_split(batch, bundle, mode: str, oracle_clean: bool = False, redraw=None):
    """The branch-a indicator of a batch under a declared partition mode (v13, audit D1):
      auto            v12 behaviour: group ids when the data has them, else observed labels / inputs
      group           true group ids (generator metadata; error if absent)
      observed_label  observed labels only, group ids never consulted
      random_matched  a deterministic random partition with the training set's group-0 proportion (or
                      growth.spec_random_fraction), fixed per example (aux "_spec_random", saved with the run)
      redrawn_random  v15: a fresh random split of every batch with the same share, drawn from a stream keyed by
                      the trainer's global step (redraw = (seed, step, fraction)); membership is not stable
      all_examples    v15: both branches receive every example's gradient (the same branch graph, no masks)
      cyclic_blocks   v22: every example alternates between the branches in a cycle of growth.spec_block_period
                      updates (a share spec_random_fraction of each cycle in branch a), with uniformly spread
                      per-example phases (aux "_spec_phase"): equal exposure for every example, persistence set
                      by the period (redraw = (seed, step, frac, period))"""
    if mode == "all_examples":
        return torch.ones(len(batch), dtype=torch.bool, device=batch.y.device)
    if mode == "cyclic_blocks":
        seed, step, frac, period = redraw
        return cyclic_membership(batch.aux["_spec_phase"], step, period, cyclic_a_len(frac, period)).to(
            batch.y.device)
    if mode == "redrawn_random":
        seed, step, frac = redraw[:3]
        gen = torch_gen(seed, "insertion", f"spec_redraw_{int(step)}")
        return (torch.rand(len(batch), generator=gen) < frac).to(batch.y.device)
    if mode == "group" or (mode == "auto" and batch.groups is not None):
        if batch.groups is None:
            raise Unsupported("spec_partition=group needs a dataset with group ids")
        return batch.groups == 0
    if mode == "random_matched":
        return batch.aux["_spec_random"].bool()
    if bundle.task == "classification":
        if oracle_clean:
            if batch.y_clean is None:
                raise Unsupported("class_halves_oracle needs clean labels")
            return batch.y_clean < (bundle.out_dim // 2)
        return batch.y < (bundle.out_dim // 2)
    if bundle.task == "regression":
        return batch.X["x"][:, 0] > 0
    return batch.X["x"][:, 0] < (bundle.out_dim // 2)


def reassign_events(growth: dict, total_updates: int) -> list[tuple[int, float, str]]:
    """v19: the declared reassignment events of a fixed random split as (job update, fraction, kind)."""
    ra = growth.get("spec_reassign") or {}
    mode = ra.get("mode", "none")
    if mode == "none":
        return []
    start = int(ra["start"])
    if mode == "abrupt":
        return [(start, float(ra["fraction"]), "exchange")]
    if mode == "abrupt_redraw":
        return [(start, 1.0, "redraw")]
    end = int(ra["end"]) if ra.get("end") is not None else int(total_updates)
    us = list(range(start, end, int(ra["period"])))
    if mode == "periodic":
        return [(u, float(ra["fraction"]), "exchange") for u in us]
    if mode == "periodic_redraw":
        return [(u, 1.0, "redraw") for u in us]
    # ramp: CUMULATIVE targets 1/n, 2/n, ..., 1 times the declared fraction of the smaller side's ORIGINAL
    # examples moved; each event moves only examples still in their original branch
    n = len(us)
    return [(u, float(ra["fraction"]) * (k + 1) / n, "ramp") for k, u in enumerate(us)]


def apply_reassign_event(cur: torch.Tensor, orig: torch.Tensor, k: int, event: tuple, seed: int) -> tuple:
    """one event on the current branch-a indicator (CPU long tensors) -> (new indicator, record).  Doses are
    stated with their denominators: `fraction` of the SMALLER side's examples (pairs exchanged), and the
    examples moved as a share of the whole training set."""
    at, frac, kind = event
    gen = torch_gen(seed, "insertion", f"spec_reassign_{k}")
    orig = orig.to(cur.dtype)
    n_small = int(min(int(orig.sum()), int((orig == 0).sum())))
    if kind == "redraw":
        n = len(cur)
        perm = torch.randperm(n, generator=gen)
        new = torch.zeros(n, dtype=cur.dtype)
        new[perm[:int(cur.sum())]] = 1          # same count in branch a, fresh membership
        moved = int((new != cur).sum())
    else:
        if kind == "ramp":
            done = int(((orig == 0) & (cur == 1)).sum())       # original b examples already moved to a
            m = max(0, int(round(frac * n_small)) - done)
            ia = torch.nonzero((cur == 1) & (orig == 1)).flatten()   # never moved
            ib = torch.nonzero((cur == 0) & (orig == 0)).flatten()
            m = min(m, len(ia), len(ib))
        else:
            ia, ib = torch.nonzero(cur == 1).flatten(), torch.nonzero(cur == 0).flatten()
            m = int(round(frac * min(len(ia), len(ib))))
        pa = ia[torch.randperm(len(ia), generator=gen)[:m]]
        pb = ib[torch.randperm(len(ib), generator=gen)[:m]]
        new = cur.clone()
        new[pa], new[pb] = 0, 1
        moved = 2 * m
    n = len(cur)
    rec = {"event": k, "job_update": at, "kind": kind, "fraction": frac,
           "fraction_denominator": "smaller side's examples (pairs exchanged)" if kind != "redraw" else
           "fresh split with the same branch-a count", "smaller_side_n": n_small, "examples_moved": moved,
           "moved_fraction_of_training_set": moved / max(1, n), "branch_a_count": int(new.sum()),
           "away_from_initial_fraction": float((new != orig).double().mean())}
    return new, rec


def replay_reassign(ind0: torch.Tensor, growth: dict, total_updates: int, seed: int, limit: int) -> tuple:
    """the split after every event with job update < limit, from the initial split (pure function: the
    trajectory, its resume and analyses of earlier checkpoints all use it).  -> (split, records, ever_moved)."""
    cur = ind0.clone().long()
    ever = torch.zeros(len(cur), dtype=torch.bool)
    recs = []
    for k, ev in enumerate(reassign_events(growth, total_updates)):
        if ev[0] >= limit:
            break
        cur, rec = apply_reassign_event(cur, ind0.long(), k, ev, seed)
        ever |= cur != ind0.long()
        recs.append(rec)
    return cur, recs, ever


def spec_access_record(bundle, mode: str, oracle_clean: bool = False, seed: int = 0, frac: float = 0.5,
                       period: int = 0, growth_route: str = "gradient") -> dict:
    """What information the branch masks use and how the TRAINING set splits under the declared partition
    (NOMINAL, from the dataset; v15: the empirical exposure under the actual sampler is the trajectory's
    spec_exposure): counts per branch by group and by label, and the nominal gradient coverage of each branch.
    For redrawn_random the split shown is one draw (step 0); membership changes every batch."""
    tr = bundle.train
    if mode == "matched_quota":
        # nominal only (counts of a split with the declared share); the assignment is per appearance
        a = torch.arange(len(tr), device=tr.y.device) < int(round(frac * len(tr)))
    else:
        a = _spec_split(tr, bundle, mode, oracle_clean, (seed, 0, frac, period))
    bmask = torch.ones_like(a) if mode == "all_examples" else ~a
    rec = {"spec_partition": mode,
           "uses_group_ids": mode == "group" or (mode == "auto" and tr.groups is not None),
           "uses_labels": mode == "observed_label" or (mode == "auto" and tr.groups is None
                                                       and bundle.task == "classification"),
           "uses_random_partition": mode in ("random_matched", "redrawn_random", "cyclic_blocks"),
           "membership": {"redrawn_random": "redrawn every batch", "all_examples": "every example in both",
                          "cyclic_blocks": f"cyclic, period {period} updates, uniformly spread phases",
                          "matched_quota": "per appearance: equal integer a / b quotas per example and round, "
                                           "ordered by the declared run structure"}.get(
               mode, "fixed per example"),
           "random_fraction": frac if mode in ("random_matched", "redrawn_random", "cyclic_blocks", "matched_quota")
           else None,
           "group_ids_at_inference": False, "proportions": "nominal (dataset); see spec_exposure for the sampler's",
           "mask_route": growth_route,
           "n_train": len(tr), "branch_a_fraction": float(a.float().mean())}
    for name, m in (("branch_a", a), ("branch_b", bmask)):
        r = {"n": int(m.sum())}
        if tr.groups is not None:
            r["by_group"] = {str(int(gv)): int((m & (tr.groups == gv)).sum()) for gv in torch.unique(tr.groups)}
        if bundle.task == "classification":
            r["by_label"] = {str(int(yv)): int((m & (tr.y == yv)).sum()) for yv in torch.unique(tr.y)}
        rec[name] = r
    rec["gradient_coverage"] = {"branch_a": rec["branch_a_fraction"], "branch_b": float(bmask.float().mean()),
                                "backbone_and_head": 1.0,
                                "note": "fraction of training examples whose loss gradient reaches each branch "
                                        + {"forward": "(v25 forward route: a branch's output is zero in training "
                                                      "for the examples not assigned to it, which also masks its "
                                                      "gradient; inference is unmasked)",
                                           "parameter": "(v26 parameter route: only the branch's own parameters "
                                                        "are masked; every example's gradient flows through the "
                                                        "branch into the upstream backbone; inference unmasked)"}
                                        .get(growth_route, "(masks act on gradients only; forward values and "
                                                           "inference are unmasked)")}
    return rec


def spec_masks(bundle, oracle_clean: bool = False, mode: str = "auto", holder: Optional[dict] = None,
               seed: int = 0, frac: float = 0.5, period: int = 0, quota=None, forward: bool = False,
               param_only: bool = False):
    """Branch gradient masks for the specialized topology (v13: the partition source is declared by
    growth.spec_partition, see _spec_split).  `oracle_clean=True` (specialize='class_halves_oracle') uses the
    clean labels: a separate intervention with privileged information about label noise.
    v15: `holder` carries the trainer (set by the segment's on_step); the EMPIRICAL per-branch exposure (examples
    whose loss gradient reaches each branch, by group when the data has groups) accumulates in the trainer state,
    so it survives resumes and reflects the actual sampler (e.g. group-balanced oversampling)."""
    def fn(batch) -> dict:
        tr = (holder or {}).get("tr")
        step = tr.state["global_step"] if tr is not None else 0
        redraw = (seed, step, frac, period)
        if mode == "matched_quota":
            if quota is None:
                raise RuntimeError("matched_quota masks need the trajectory's quota schedule")
            a = quota(batch, step)
        else:
            a = _spec_split(batch, bundle, mode, oracle_clean, redraw)
        b = torch.ones_like(a) if mode == "all_examples" else ~a
        if tr is not None and "_index" in batch.aux:
            # v22 / v23: mask eligibility per training example and growth round (window): how often it was in a
            # batch, and how often its loss gradient was ELIGIBLE to reach branch a / branch b (the sampler decides
            # when an example is seen, the schedule where; a zero gradient is still counted as eligible)
            N = len(bundle.train)
            w = str(holder["window"](step)) if (holder and "window" in holder) else "0"
            pe = tr.state.setdefault("spec_exposure_pe", {})
            if "n" in pe:                               # pre-v23 layout in a resumed state: one window
                pe = tr.state["spec_exposure_pe"] = {"0": pe}
            pw = pe.setdefault(w, {"n": [0] * N, "a": [0] * N, "b": [0] * N})
            for i_, a_, b_ in zip(batch.aux["_index"].tolist(), a.tolist(), b.tolist()):
                pw["n"][i_] += 1
                pw["a"][i_] += int(a_)
                pw["b"][i_] += int(b_)
        if tr is not None:
            ex = tr.state.setdefault("spec_exposure", {"batches": 0, "examples": 0, "branch_a": 0, "branch_b": 0})
            ex["batches"] += 1
            ex["examples"] += int(len(batch))
            ex["branch_a"] += int(a.sum())
            ex["branch_b"] += int(b.sum())
            if batch.groups is not None:
                for gv in torch.unique(batch.groups).tolist():
                    m = batch.groups == gv
                    ex[f"group{int(gv)}_examples"] = ex.get(f"group{int(gv)}_examples", 0) + int(m.sum())
                    ex[f"group{int(gv)}_branch_a"] = ex.get(f"group{int(gv)}_branch_a", 0) + int((a & m).sum())
                    ex[f"group{int(gv)}_branch_b"] = ex.get(f"group{int(gv)}_branch_b", 0) + int((b & m).sum())
        out = {"grad_masks": {"spec_a": a.float(), "spec_b": b.float()}}
        if forward:
            out["mask_forward"] = True              # v25: the branch outputs themselves are masked
        if param_only:
            out["mask_param_only"] = True           # v26: only the branch parameters' gradients are masked
        return out
    return fn


def add_aux_heads(g: GraphNet, new: list[str], out_dim: int, gen) -> list[str]:
    heads = []
    for iid in new:
        imp = g.implants.get(iid)
        if imp is None:
            continue
        acts = [n for n in imp.nodes if g.nodes[n].role == "act"]
        if not acts:
            continue
        a = acts[0]
        h = E._linear(g, a, g.node_dim(a), out_dim, iid, "aux_head", gen, base_attrs={"dim": out_dim})
        if g.layout == "img":
            h0 = h
            g.nodes[h0].attrs["layout"] = "img"
            gp = g.add_node("gap", [h0], {"dim": out_dim, "layout": "vec"}, owner=iid, role="aux_gap")
            h = gp
        g.side_outputs[f"aux:{iid}"] = h
        heads.append(h)
    E._finalize_modules(g, list(g.nodes))
    return heads


# =============================================================================
# Trajectory
# =============================================================================

class Trajectory:
    def __init__(self, ctx):
        self.ctx = ctx
        self.cfg = ctx.cfg
        self.g = dict(self.cfg["growth"])
        self.R = int(self.g["rounds"])
        if self.g["compute_schedule"] == "total":
            self.upr = max(1, int(self.g["total_updates"]) // max(1, self.R))
        else:
            self.upr = int(self.g["updates_per_round"])
        self.bundle = C.setup_data(ctx)
        if self.g["topology"] == "specialized" and self.g["specialize"] in ("class_halves", "class_halves_oracle"):
            self._setup_spec_partition()
        self.sets = C.calib_sets(self.bundle, self.cfg["eval"]["calib_size"], self.cfg["eval"]["stress_scale"])
        self.grower = Grower(self.g, seed_of(self.cfg, "insertion"), self.bundle, ctx.log)
        self.grower.select_fn = self._select_hard
        self.grower.known_module_fn = self._known_module
        self.aux_heads: list[str] = []
        self.fc_cache: dict[int, dict] = {}
        self.dtype = torch.float64 if self.cfg["train"]["precision"] == "fp64" else torch.float32

    def _setup_spec_partition(self) -> None:
        """v13 (audit D1): the declared branch partition.  random_matched draws one fixed indicator per training
        example with the training set's group-0 proportion (named RNG stream, saved as spec_partition.pt), so
        it matches the true-group split in size but carries no group information.  The access record
        (specialization_access.json) states what the masks use; group metadata never enters a forward pass."""
        mode = self.g["spec_partition"]
        tr = self.bundle.train
        frac = self.g.get("spec_random_fraction")
        if frac is None:
            frac = 0.5 if tr.groups is None else float((tr.groups == 0).float().mean())
        self.spec_fraction = float(frac)
        if mode == "random_matched":
            n = len(tr)
            gen = torch_gen(seed_of(self.cfg, "partition"), "insertion", "spec_random")
            perm = torch.randperm(n, generator=gen)
            ind = torch.zeros(n, dtype=torch.long)
            ind[perm[:int(round(frac * n))]] = 1                # exactly round(frac * n) examples in branch a
            tr.aux["_spec_random"] = ind.to(tr.y.device)
            torch.save(ind, self.ctx.dir / "spec_partition.pt")
            self._spec_ind0 = ind.clone()
        self.spec_period = int(self.g.get("spec_block_period", 0) or 0)
        # v22: example identities in the batches, for the REALISED per-example exposure (spec_masks)
        tr.aux["_index"] = torch.arange(len(tr), device=tr.y.device)
        self._quota = {}
        if mode == "matched_quota":
            sq = self.g.get("spec_quota") or {}
            self.spec_fraction = float(sq["fraction"])
        if mode == "cyclic_blocks":
            ph = cyclic_phases(len(tr), self.spec_period, seed_of(self.cfg, "partition"))
            tr.aux["_spec_phase"] = ph.to(tr.y.device)
            torch.save(ph, self.ctx.dir / "spec_phase.pt")
        self._spec_reassign_applied = 0          # events applied in THIS process (replayed after a resume)
        self._spec_reassign_log = []
        rec = spec_access_record(self.bundle, mode, self.g["specialize"] == "class_halves_oracle",
                                 seed_of(self.cfg, "partition"), self.spec_fraction, self.spec_period,
                                 growth_route=self.g.get("spec_mask_route", "gradient"))
        rec["sampler"] = self.cfg["train"].get("sampler", "uniform")
        self.ctx.save_json("specialization_access.json", rec)

    def _quota_path(self, w: int):
        return self.ctx.dir / f"spec_quota_w{int(w)}.pt"

    def _quota_prepare(self, trn) -> None:
        """v23: at the first update of every growth round (window), replay the trainer's minibatch stream for the
        window and build the matched-quota assignment; saved before any of its updates (a resumed job loads it)."""
        u = int(trn.state["global_step"]) - int(self.g0)
        w = min(self.R - 1, max(0, u // max(1, self.upr)))
        if w in self._quota:
            return
        p = self._quota_path(w)
        if p.exists():
            self._quota[w] = torch.load(p, map_location="cpu", weights_only=False)
            return
        if u != w * self.upr:
            raise ScientificInvalid("matched_quota: a window's schedule is missing after its first update",
                                    {"window": w, "job_update": u})
        n = min(self.upr, self.R * self.upr - u)
        idx = replay_minibatch_indices(trn, n)
        sq = self.g["spec_quota"]
        sch = quota_schedule(idx, len(self.bundle.train), float(sq["fraction"]), int(sq["b_run"]),
                             seed_of(self.cfg, "partition"), w)
        rec = {"window": w, "first_job_update": u, "updates": n, "indices": idx, **sch,
               "stream_hash": hashlib.sha256(idx.contiguous().numpy().tobytes()).hexdigest()[:20],
               "quota_hash": hashlib.sha256(sch["quota_a"].contiguous().numpy().tobytes()).hexdigest()[:20],
               "fraction": float(sq["fraction"]), "b_run": int(sq["b_run"])}
        atomic_torch_save(rec, p)
        self._quota[w] = rec

    def _quota_assign(self, batch, step) -> torch.Tensor:
        u = int(step) - int(self.g0)
        w = min(self.R - 1, max(0, u // max(1, self.upr)))
        rec = self._quota.get(w)
        if rec is None:
            p = self._quota_path(w)
            if not p.exists():
                raise ScientificInvalid("matched_quota: no schedule for this window", {"window": w})
            rec = self._quota[w] = torch.load(p, map_location="cpu", weights_only=False)
        k = u - rec["first_job_update"]
        got = batch.aux["_index"].long().cpu()
        if not (0 <= k < rec["updates"]) or not torch.equal(got, rec["indices"][k]):
            raise ScientificInvalid("matched_quota: the minibatch differs from the replayed stream",
                                    {"window": w, "update_in_window": k})
        return rec["assign"][k].to(batch.y.device)

    def _spec_reassign_events(self) -> list[tuple[int, float, str]]:
        return reassign_events(self.g, self.R * self.upr)

    def _spec_reassign_step(self, trn) -> None:
        """Apply every due reassignment event (job update u = global step - g0).  Events are deterministic
        functions of their index (named stream keyed by the partition seed), so a resumed job replays them from
        the saved initial split and reaches the same assignment.  An exchange swaps m = round(fraction x the
        smaller side) random pairs (one example from each branch): both branches keep their exact counts."""
        self._spec_reassign_until(int(trn.state["global_step"]) - int(self.g0) + 1)

    def _spec_reassign_until(self, limit: int) -> None:
        """apply every event with job update < limit (training applies the events due at update u before that
        update's batch; finish() replays up to the job's last update, so a job resumed after its training gets
        the same final split)."""
        evs = self._spec_reassign_events()
        if not evs:
            return
        ind = self.bundle.train.aux["_spec_random"]
        before = self._spec_reassign_applied
        seed = seed_of(self.cfg, "partition")
        if not hasattr(self, "_spec_ever_moved"):
            self._spec_ever_moved = torch.zeros(len(ind), dtype=torch.bool)
        while self._spec_reassign_applied < len(evs) and evs[self._spec_reassign_applied][0] < limit:
            k = self._spec_reassign_applied
            cur = ind.cpu().clone()
            new, rec = apply_reassign_event(cur, self._spec_ind0, k, evs[k], seed)
            self._spec_ever_moved |= (new != self._spec_ind0.to(new.dtype))
            ind.copy_(new.to(ind.device))
            self._spec_reassign_applied += 1
            self._spec_reassign_log.append(rec)
        if self._spec_reassign_applied > before:
            self.ctx.log({"event": "spec_reassign", "applied_events": self._spec_reassign_applied,
                          "of": len(evs), "branch_a_count": int(ind.sum())})

    def group_inference_check(self, model) -> Optional[dict]:
        """Predictions on validation inputs must not change when the group metadata is permuted (v13 D1)."""
        va = self.bundle.val
        if va.groups is None:
            return None
        from ..data.bundle import Partition
        gen = torch.Generator().manual_seed(0)
        perm = torch.randperm(len(va), generator=gen).to(va.groups.device)
        swapped = Partition(va.X, va.y, va.y_clean, va.groups[perm], dict(va.aux), dict(va.meta))
        a = predict(model, va, self.cfg["train"]["eval_batch"])
        b = predict(model, swapped, self.cfg["train"]["eval_batch"])
        return {"predictions_identical_under_permuted_groups": bool(torch.equal(a, b)), "n": len(va)}

    # ----------------------------------------------------------------- refs
    def load_f0(self):
        ctx = self.ctx
        if ctx.has_ckpt("baseline_ref"):
            ck = ctx.load_ckpt("baseline_ref")
        elif "baseline" in self.cfg.get("parents", {}):
            stage = (self.cfg.get("tags") or {}).get("f0_stage", "baseline")   # e.g. snap_<u> (F06d)
            ck = ctx.parent_ckpt("baseline", stage)
            ctx.save_ckpt("baseline_ref", GraphNet.from_checkpoint(ck["model"]), None,
                          {"trainer": ck["trainer"], "source": self.cfg["parents"]["baseline"], "stage": stage})
            ck = ctx.load_ckpt("baseline_ref")
            ck["trainer"] = ck["extra"]["trainer"]
        else:
            model, tr = train_baseline(ctx, self.bundle)
            ctx.save_ckpt("baseline_ref", model, None, {"trainer": tr.state_dict(), "source": "inline"})
            ctx.ckpt_path("partial_baseline").unlink(missing_ok=True)
            ck = ctx.load_ckpt("baseline_ref")
        if ck.get("trainer") is None:
            ck["trainer"] = ck["extra"]["trainer"]
        self.f0_ck = ck
        self.f0 = GraphNet.from_checkpoint(ck["model"], ctx.device)
        self.g0 = int(ck["trainer"]["state"]["global_step"]) if self.g["schedule"] != "from_scratch" else 0
        from ..graph.accounting import architecture_hash
        self.f0_arch = architecture_hash(self.f0)
        if self.cfg["train"]["target"] == "teacher_star":
            from ..train.trainer import teacher_star_target_available
            if not teacher_star_target_available(self.bundle):
                raise Unsupported("train.target=teacher_star (T0) needs a dataset with a known compact teacher")
        _, self.f0_preds = evaluate(self.f0, self.bundle, self._parts(), self.cfg["train"]["eval_batch"],
                                    return_preds=True)
        return ck

    def _parts(self):
        p = list(self.cfg["eval"]["partitions"])
        if self.cfg["eval"]["extra"]:
            p += [k for k in self.bundle.extra if k not in p]
        return p

    def fc_preds(self, r: int) -> Optional[dict]:
        if "continued" not in self.cfg.get("parents", {}):
            return None
        if r not in self.fc_cache:
            try:
                ck = self.ctx.parent_ckpt("continued", f"round_{r}")
            except StaleParent:
                raise
            except FileNotFoundError as ex:      # the continued baseline has no checkpoint for this round
                self.ctx.log({"event": "fc_missing", "round": r, "error": str(ex)})
                return None
            m = GraphNet.from_checkpoint(ck["model"], self.ctx.device)
            _, self.fc_cache[r] = evaluate(m, self.bundle, self._parts(), self.cfg["train"]["eval_batch"],
                                           return_preds=True)
        return self.fc_cache[r]

    # ------------------------------------------------------- data-driven choices
    def _calib_risk(self, g: GraphNet, part) -> float:
        out = predict(g, part, self.cfg["train"]["eval_batch"], self.dtype)
        return M.headline(M.task_metrics(out, part.y, self.bundle.task, None, self.bundle.target_scale),
                          self.bundle.task)

    def _select_hard(self, g: GraphNet, rule: str):
        """Implant whose single deletion hurts most on TRAINING calibration data."""
        part = C.calib_partition(self.bundle, self.cfg["eval"]["calib_size"])
        base = self._calib_risk(g, part)
        scores = {}
        for a in g.atoms():
            if "hidden" not in g.implants[a].meta.get("cutpoints", {}):
                continue
            try:
                scores[a] = self._calib_risk(E.delete(g, [a]), part) - base
            except InvalidDeletion:
                continue
        if not scores:
            raise Unsupported("no candidate implant with an internal cut")
        best = max(scores, key=lambda k: (scores[k], -int(k[1:])))
        return best, {"scores": scores, "data": "train calibration subset", "n": len(part)}

    def _known_module(self, g: GraphNet, src: Optional[str] = None):
        kind = self.g["known_module"]
        gen = self.grower.gen("known/module")
        src = src or g.inputs["x"]
        on_cut = src != g.inputs["x"]
        if kind == "poly" and on_cut:
            raise Unsupported("the poly known module is defined on the raw input coordinates")
        n = min(2048, len(self.bundle.train))
        if on_cut:
            X = {k_: v[:n] for k_, v in self.bundle.train.X.items()}
            was = g.training
            g.eval()
            with torch.no_grad():
                _, vals = g(X, return_nodes=[src])
            g.train(was)
            src_train = vals[src].detach()
        else:
            src_train = self.bundle.train.X["x"][:n]
        self._known_src = src if on_cut else None
        self._known_graph = g
        pre = None
        if kind == "pretrained":
            pre = self._pretrain_known
        mod, attrs, k, info = make_known_module(kind, self.bundle, gen, self.g["width"], pre,
                                                d_src=g.node_dim(src), src_train=src_train,
                                                y_train=self.bundle.train.y[:n])
        mod.to(self.ctx.device, self.dtype)
        from ..utils import atomic_torch_save
        atomic_torch_save([p.detach().clone().cpu() for p in mod.parameters()], self.ctx.dir / "known_init.pt")
        info["initial_params_file"] = "known_init.pt"
        return mod, attrs, k, info

    def _pretrain_known(self, mod) -> dict:
        """Pretrain an MLP feature extractor on TRAINING data: predict the known
        level-1 intermediates when the dataset has them, else the task target,
        through a temporary linear readout that is discarded (cost counted)."""
        b = self.bundle
        mod.to(self.ctx.device)
        tgt_kind = "aux_z" if "z" in b.train.aux else "task"
        out_dim = b.train.aux["z"].shape[1] if tgt_kind == "aux_z" else b.out_dim
        head = torch.nn.Linear(mod.layers[-1].out_features, out_dim)
        from ..graph.ops import init_module
        init_module(head, torch_gen(seed_of(self.cfg, "insertion"), "insertion", "known/pretrain_head"), "default")
        head.to(self.ctx.device)
        n_upd = int(self.g["pretrain_updates"])
        lopt = LocalOpt(list(mod.parameters()) + list(head.parameters()), self.cfg["train"], n_upd)
        gen = torch_gen(seed_of(self.cfg, "insertion"), "insertion", "known/pretrain")
        N = len(b.train)
        B = min(int(self.cfg["train"]["batch_size"]), N)
        src = getattr(self, "_known_src", None)
        for i in range(n_upd):
            idx = torch.randint(0, N, (B,), generator=gen).to(self.ctx.device)
            x = b.train.X["x"][idx]
            if src is not None:
                # matched input access: the specialist sees the cut activations of the current model (frozen)
                gk = self._known_graph
                was = gk.training
                gk.eval()
                with torch.no_grad():
                    _, v = gk({k_: t[idx] for k_, t in b.train.X.items()}, return_nodes=[src])
                gk.train(was)
                x = v[src].detach()
            out = head(torch.relu(mod(x)))
            if tgt_kind == "aux_z":
                loss = F.mse_loss(out, b.train.aux["z"][idx])
            else:
                loss = task_loss(out, b.train.y[idx], b.task)
            lopt.step(loss, i)
        # training MACs of the specialist (3 x forward of its linear maps and the discarded head) plus,
        # with cut access, one forward of the frozen model per example
        lin = sum(m_.in_features * m_.out_features for m_ in list(mod.modules()) + [head]
                  if isinstance(m_, torch.nn.Linear))
        fwd_src = 0
        if src is not None:
            from ..train.trainer import forward_macs
            fwd_src = forward_macs(self._known_graph, C.seq_T(self.bundle), {})
        self.ctx.count_work("known_pretrain", updates=n_upd, examples=n_upd * B,
                            macs=int(n_upd * B * (3 * lin + fwd_src)))
        return {"pretrain_updates": n_upd, "pretrain_target": tgt_kind, "pretrain_head_params_discarded":
                sum(p.numel() for p in head.parameters()), "pretrain_data": "train subset",
                "pretrain_policy": lopt.resolved()}

    # ---------------------------------------------------------------- policy (I3)
    def choose_cut(self, model: GraphNet, r: int) -> dict:
        pol = self.g["policy"]
        cps = E.cutpoints(model, self.g["cut_kind"])
        K = min(self.g["policy_candidates"], len(cps))
        if K < 1:
            raise Unsupported("no cutpoint available for the policy")
        # Candidate generation and selection use separate deterministic draws.
        # The candidate set is common to every policy of a cell (same seed and
        # round), so adaptive policies are compared on the same candidates.
        rng = torch_gen(seed_of(self.cfg, "policy"), "policy", f"r{r}", "candidates")
        cand = sorted(torch.randperm(len(cps), generator=rng)[:K].tolist())
        if pol == "random":
            sel = torch_gen(seed_of(self.cfg, "policy"), "policy", f"r{r}", "select")
            j = int(torch.randint(0, K, (1,), generator=sel))
            return {"chosen": cand[j], "candidates": cand, "n_cutpoints": len(cps), "scores": None,
                    "search_updates": 0, "selection": "uniform over candidates (separate draw)"}
        part = C.calib_partition(self.bundle, self.cfg["eval"]["calib_size"])
        scores = {}
        for ci in cand:
            probe = model.clone(share_params=False)
            gr = Grower(dict(self.g, cut_where=ci), seed_of(self.cfg, "insertion"), self.bundle)
            new = gr.round(probe, r, self.R)
            tr = Trainer(probe, self.bundle, self.cfg["train"],
                         {"minibatch": seed_of(self.cfg, "policy"), "augmentation": seed_of(self.cfg, "policy")},
                         self.ctx.device, None, f"probe/r{r}/c{ci}")
            tr.configure(self.cfg["train"]["freeze"], new[0] if new else None, reset_state=True)
            tr.run(Segment(f"probe_r{r}_c{ci}", self.g["policy_probe_updates"]))
            base = self._calib_risk(probe, part)
            top = [i for i in new if probe.implants[i].parent is None or probe.implants[i].parent not in new]
            try:
                scores[ci] = self._calib_risk(E.delete(probe, top[:1]), part) - base
            except InvalidDeletion:
                scores[ci] = float("nan")
        valid = {k: v for k, v in scores.items() if v == v}
        if not valid:
            raise Unsupported(f"policy {pol}: no candidate cut had a valid deletion score")
        if pol == "dependence_seeking":
            chosen = max(valid, key=lambda k: (valid[k], -k))
        else:
            chosen = min(valid, key=lambda k: (valid[k], k))
        return {"chosen": chosen, "candidates": cand, "n_cutpoints": len(cps), "scores": scores,
                "search_updates": K * self.g["policy_probe_updates"], "selection_data": "train calibration subset",
                "tie_break": "lowest cut index"}

    # ---------------------------------------------------------------- segments
    def round_start_model(self, model: GraphNet, r: int) -> GraphNet:
        """Frozen copy of the model at the START of round r.  Persisted, so a
        resumed round uses the same reference as an uninterrupted one."""
        stage = f"round_start_r{r}"
        if not self.ctx.has_ckpt(stage):
            self.ctx.save_ckpt(stage, model, None)
        prev = GraphNet.from_checkpoint(self.ctx.load_ckpt(stage)["model"], self.ctx.device).eval()
        if self.dtype == torch.float64:
            prev = prev.double()
        for p in prev.parameters():
            p.requires_grad_(False)
        return prev

    def _helper_hook(self, model: GraphNet):
        """Mechanism G availability schedule over the history's own update count u."""
        st = model.meta.get("growth_state", {})
        gates = st.get("helper_gates")
        sched = self.g["helper_schedule"]
        if self.g["topology"] != "twin_helpers" or not gates or sched in ("both", "single"):
            return None, None
        P, keep = int(self.g["helper_period"]), float(self.g["helper_keep"])
        seed = seed_of(self.cfg, "insertion")

        def hook(trn, k):
            u = int(trn.state["global_step"]) - self.g0
            if sched == "alternate":
                on = (u // max(1, P)) % len(gates)
                vals = [1.0 if i == on else 0.0 for i in range(len(gates))]
            else:
                gg = torch_gen(seed, "insertion", "helper_bypass", str(u))
                vals = [float(v) for v in (torch.rand(len(gates), generator=gg) < keep)]
            for gid, v in zip(gates, vals):
                trn.model.gate_vals[gid] = v

        def restore(m):
            for gid in gates:
                m.gate_vals[gid] = 1.0
        return hook, restore

    def make_segment(self, model: GraphNet, r: int, name: str, n: int, eval_points=None, eval_fn=None) -> Segment:
        drv = self.g["driver"]
        hh, restore = self._helper_hook(model)
        if eval_fn is not None and restore is not None:
            base_eval = eval_fn

            def eval_fn(trn, step, base_eval=base_eval):     # evaluate with every helper available
                saved = dict(trn.model.gate_vals)
                restore(trn.model)
                out = base_eval(trn, step)
                trn.model.gate_vals.update(saved)
                return out
        seg = Segment(name, n, eval_points=eval_points or [], eval_fn=eval_fn,
                      on_step=chain_hooks(snapshot_hook(self.ctx, set(self.cfg["train"]["snapshot_at"]), self.g0,
                                                        lambda trn: self._ckpt_extra(trn)), hh))
        self._helper_restore = restore
        extra_terms = []
        if drv == "changing_target":
            t0, t1 = _second_teacher(self.bundle, self.cfg["data"]["teacher_seed"])
            lam = self.g["driver_strength"] * r / max(1, self.R)

            def target_fn(out, batch, X, t0=t0, t1=t1, lam=lam):
                with torch.no_grad():
                    y = (1 - lam) * _teacher_eval(t0, X["x"]) + lam * _teacher_eval(t1, X["x"])
                return F.mse_loss(out, y.to(out.dtype))
            seg.target, seg.target_fn = "custom", target_fn
            self.ctx.log({"event": "changing_target", "round": r, "lambda": lam})
        elif drv == "output_constrained":
            prev = self.round_start_model(model, r)
            lam = self.g["driver_strength"]

            def oc(m, ctx_, batch, k, prev=prev, lam=lam):
                with torch.no_grad():
                    t = prev(self._cast(batch.X))
                return lam * F.mse_loss(ctx_["__out__"].to(t.dtype), t)
            extra_terms.append(("output_constraint", oc, None))
        elif drv == "stationary_self":
            prev = self.round_start_model(model, r)
            if self.bundle.task == "regression":
                seg.target, seg.teacher = "expanded", prev       # MSE to own outputs: exact zero-gradient start
            else:
                def sq(out, batch, X, prev=prev):
                    with torch.no_grad():
                        t = prev(X)
                    return ((out - t) ** 2).mean()               # squared error on logits (exact zero gradient)
                seg.target, seg.target_fn = "custom", sq
        if self.g["aux_objective"] != "none" and self.aux_heads:
            sign = self.g["aux_objective"]
            w = self.g["aux_weight"]
            task = self.bundle.task

            def aux_loss(m, ctx_, batch, k, sign=sign, w=w):
                tot = 0.0
                for name, out in ctx_.get("side", {}).items():
                    if not name.startswith("aux:"):
                        continue
                    y = batch.y
                    if sign == "antagonistic":
                        if task == "regression":
                            y = -y
                        else:
                            y = torch.roll(y, 1, 0)   # conflicting target: labels of another example
                    tot = tot + w * task_loss(out, y, task)
                return tot
            extra_terms.append(("aux", aux_loss, None))
        if self.g["replacement_pressure"] > 0:
            lam = self.g["replacement_pressure"]
            bnodes = [n for imp in model.implants.values() for n in imp.nodes if model.nodes[n].role == "B"]

            def rp(m, ctx_, batch, k, lam=lam):
                col = ctx_.get("collected", {})
                if not col:
                    return 0.0
                return lam * sum(v.pow(2).mean() for v in col.values()) / len(col)
            extra_terms.append(("replacement_pressure", rp, bnodes))
        if self.g["topology"] == "specialized" and self.g["specialize"] in ("class_halves", "class_halves_oracle"):
            if self.g.get("spec_mask_route") == "parameter":
                # v26: the parameter route masks parameter gradients inside the linear op; any other parametric
                # node in a specialised branch would escape the mask
                for iid, imp in model.implants.items():
                    if not ((imp.meta or {}).get("specialization") or {}).get("mask_key"):
                        continue
                    bad = [n for n in imp.nodes if model.nodes[n].pkey is not None and model.nodes[n].op != "linear"
                           and any(True for _ in model.mods[model.nodes[n].pkey].parameters())]
                    if bad:
                        raise Unsupported(f"spec_mask_route=parameter needs linear-only branches; {iid} has {bad}")
            holder = {}
            prev_on = seg.on_step

            holder["window"] = lambda step: min(self.R - 1, max(0, (int(step) - int(self.g0)) // max(1, self.upr)))

            def on_step_spec(trn, k, prev_on=prev_on, holder=holder):
                holder["tr"] = trn
                self._spec_reassign_step(trn)
                if self.g["spec_partition"] == "matched_quota":
                    self._quota_prepare(trn)             # before this update's batch is drawn
                if prev_on is not None:
                    prev_on(trn, k)
            seg.on_step = on_step_spec
            seg.batch_ctx = spec_masks(self.bundle, oracle_clean=self.g["specialize"] == "class_halves_oracle",
                                       mode=self.g["spec_partition"], holder=holder,
                                       seed=seed_of(self.cfg, "partition"), frac=self.spec_fraction,
                                       period=self.spec_period,
                                       quota=self._quota_assign if self.g["spec_partition"] == "matched_quota"
                                       else None, forward=self.g.get("spec_mask_route") == "forward",
                                       param_only=self.g.get("spec_mask_route") == "parameter")
        if extra_terms:
            collect = set()
            for nm, f, aux in extra_terms:
                if nm == "replacement_pressure":
                    collect |= set(aux)
            base_ctx = seg.batch_ctx

            def bctx(batch, base_ctx=base_ctx, collect=collect):
                d = base_ctx(batch) if base_ctx else {}
                if collect:
                    d["collect"] = collect
                return d
            seg.batch_ctx = bctx

            def extra(m, ctx_, batch, k):
                tot = 0.0
                for nm, f, aux in extra_terms:
                    tot = tot + f(m, ctx_, batch, k)
                return tot
            seg.extra_loss = extra
        return seg

    def _cast(self, X):
        return {k: (v.to(self.dtype) if v.is_floating_point() else v) for k, v in X.items()}

    def neutral_mutation(self, model: GraphNet, tr: Trainer, r: int, n: int) -> dict:
        """Explicit neutral-drift process (deliberate perturbation, not SGD):
        propose theta + sigma*N(0,I) on trainable parameters; accept iff the
        output change on the calibration inputs stays within the criterion and
        the training-calibration task risk does not increase by more than tol."""
        sigma = self.g["driver_strength"] or 1e-3
        tol = self.cfg["criteria"]["nmse"][0] if self.bundle.task == "regression" else self.cfg["criteria"]["js"][0]
        gen = torch_gen(seed_of(self.cfg, "mutation"), "mutation", f"r{r}")
        part = C.calib_partition(self.bundle, self.cfg["eval"]["calib_size"])
        params = [p for g_ in tr.opt.param_groups for p in g_["params"]] if tr.opt else []
        res = getattr(self, "_mut_resume", None)
        self._mut_resume = None
        if res and res.get("round") == r and res.get("phase") == "mutation":
            i0, acc, base_risk = int(res["i"]), int(res["acc"]), float(res["base_risk"])
            gen.set_state(res["gen"])
            ref = res["ref"].to(self.ctx.device)
            self.ctx.log({"event": "resume_mutation", "round": r, "proposal": i0})
        else:
            i0, acc = 0, 0
            ref = predict(model, part, dtype=self.dtype)
            base_risk = self._calib_risk(model, part)
        every = int(self.cfg["train"].get("checkpoint_every") or 0)

        def save(i):
            self.ctx.save_ckpt("partial", model, tr, {"round": r, "phase": "mutation", "i": i, "acc": acc,
                                                     "gen": gen.get_state(), "ref": ref.detach().cpu(),
                                                     "base_risk": base_risk, **self._ckpt_extra(tr)})
        for i in range(i0, n):
            if interrupted():
                save(i)
                raise KeyboardInterrupt("interrupted; checkpoint written")
            if every and i > i0 and i % every == 0:
                save(i)
            old = [p.detach().clone() for p in params]
            with torch.no_grad():
                for p in params:
                    p.add_(torch.randn(p.shape, generator=gen).to(p) * sigma)
            out = predict(model, part, dtype=self.dtype)
            d = M.drift(out, ref, self.bundle.task, part.y, self.bundle.target_scale)
            dv = d["nmse"] if self.bundle.task == "regression" else d["js"]
            risk = self._calib_risk(model, part)
            if dv <= tol and risk <= base_risk + tol:
                acc += 1
            else:
                with torch.no_grad():
                    for p, o in zip(params, old):
                        p.copy_(o)
        tr.state["global_step"] += n
        return {"mutation_proposals": n, "accepted": acc, "sigma": sigma, "tolerance": tol,
                "label": "deliberate perturbation (neutral mutation process)"}

    # ------------------------------------------------------------------ main
    def run(self) -> dict:
        sched = self.g["schedule"]
        self.load_f0()
        if sched == "from_scratch":
            return self.run_from_scratch()
        if sched == "all_at_once":
            return self.run_all_at_once()
        return self.run_incremental()

    def _restore(self, stage: str):
        ck = self.ctx.load_ckpt(stage)
        model = GraphNet.from_checkpoint(ck["model"], self.ctx.device)
        tr = C.make_trainer(self.ctx, model, self.bundle, "main")
        tr.load_state_dict(ck["trainer"])
        self.aux_heads = list(ck["extra"].get("aux_heads", []))
        tr.policy_extra_frozen = set(ck["extra"].get("extra_frozen", []))
        if "work" in ck["extra"]:
            # measured work up to this checkpoint (e.g. known-module pretraining in an earlier round)
            self.ctx.work = copy.deepcopy(ck["extra"]["work"])
        return model, tr, ck

    def _fresh_from_f0(self):
        model = GraphNet.from_checkpoint(self.f0_ck["model"], self.ctx.device)
        tr = C.make_trainer(self.ctx, model, self.bundle, "main")
        tr.load_state_dict(self.f0_ck["trainer"])
        tr.curves = []
        return model, tr

    def _insert_round(self, model: GraphNet, tr: Trainer, r: int) -> list[str]:
        ctx = self.ctx
        ctx.updates, ctx.examples = tr.state["global_step"], tr.state["examples"]   # exposure at insertion time
        before = C.outputs_on(model, self.sets, self.dtype)
        info = {}
        if self.g["policy"] != "fixed" and self.g["topology"] not in ("none",):
            info = self.choose_cut(model, r)
            self.grower.c = dict(self.g, cut_where=info["chosen"])
            ctx.log({"event": "policy_choice", "round": r, **{k: v for k, v in info.items()}})
            ctx.metric(f"insert_r{r}", "train_calibration", "policy_search_updates", info["search_updates"])
            ctx.count_work("policy_search", updates=int(info["search_updates"]),
                           examples=int(info["search_updates"]) * int(self.cfg["train"]["batch_size"]))
        r_loc, R_loc = self._cycle_round(model, r)
        before_train = self._train_mode_outputs(model)
        pre = model.clone(share_params=False)          # the pre-edit state, kept for the high-precision check
        new = self.grower.round(model, r_loc, R_loc)
        label, eq = self.insertion_gate(model, before, new, f"insert_r{r}", pre=pre)
        self.insertion_checks(model, new, f"insert_r{r}", before_train)
        if self.g["aux_objective"] != "none" and new:
            self.aux_heads += add_aux_heads(model, new, self.bundle.out_dim, self.grower.gen(f"aux/r{r}"))
        if self.g["stable_pegs"]:
            for imp in model.implants.values():
                if "peg" in imp.meta and imp.round is not None and imp.round < r:
                    tr.policy_extra_frozen.add(model.nodes[imp.meta["peg"]["enc"]].pkey)
        ref = new[0] if new else None
        frozen_known = self.g["known_module"] in ("mixing_random", "mixing_aligned") or not self.g["known_trainable"]
        if self.g["known_module"] != "none":
            for i in new:
                for n in model.implants[i].nodes:
                    if model.nodes[n].role != "known":
                        continue
                    pk = model.nodes[n].pkey
                    if frozen_known:
                        tr.policy_extra_frozen.add(pk)
                    elif self.g["known_partial"]:
                        # partially trainable specialist: only its last linear layer learns (F10e)
                        names = [nm for nm, _ in model.mods[pk].named_parameters()]
                        last = [nm for nm, mm in model.mods[pk].named_modules() if isinstance(mm, torch.nn.Linear)][-1]
                        model.meta.setdefault("frozen_param_names", {})[pk] = \
                            [nm for nm in names if not nm.startswith(last + ".")]
        cinfo = tr.configure(self.cfg["train"]["freeze"], ref)
        ctx.log({"event": "optimizer_configured", "round": r, **cinfo})
        for k in ("n_trainable_params", "opt_state_carried"):
            ctx.metric(f"insert_r{r}", "none", k, cinfo[k], model.structural_hash())
        ctx.save_graph(f"post_insert_r{r}", model)
        return new

    # ------------------------------------------------------------ v3: cycles, live gradient
    def _cycle_round(self, model: GraphNet, r: int) -> tuple[int, int]:
        """Round index seen by the growth program: global in an ordinary history; within the
        current cycle for grow / contract cycles (with the cycle's insertion salt and, for
        cycle_cut=moving, the cut advanced by one cutpoint per cycle)."""
        k = int(self.g["contract_every"])
        if not k:
            return r, self.R
        cyc = model.meta.setdefault("growth_state", {}).setdefault("cycle", {"index": 0, "start_round": 1})
        self.grower.salt = f"cycle{cyc['index']}/"
        if self.g["cycle_cut"] == "moving":
            n = len(E.cutpoints(model, self.g["cut_kind"]))
            base = self.g["cut_where"]
            b0 = {"early": 0, "middle": (n - 1) // 2, "late": n - 1}.get(base, base if isinstance(base, int) else 0)
            self.grower.c = dict(self.grower.c, cut_where=(int(b0) + cyc["index"]) % n)
        return r - int(cyc["start_round"]) + 1, k

    def _train_mode_outputs(self, model: GraphNet):
        """Outputs in TRAIN mode on a clone (BN batch statistics; buffers of the model untouched),
        or None for models without normalisation layers (train mode = eval mode there)."""
        if not any(n.op == "bn" for n in model.nodes.values()):
            return None
        h = model.clone(share_params=False)
        h.train()
        with torch.no_grad():
            return h(self._cast(self.sets["calibration"]))

    def insertion_checks(self, model: GraphNet, new: list[str], stage: str, before_train=None) -> dict:
        """Section 3: (i) a zero-output insertion must keep a live gradient: one backward pass of
        the task loss on a training calibration batch (eval mode, no update, buffers untouched)
        must give a nonzero gradient to every new implant; (ii) equivalence in TRAIN mode on a
        clone (normalisation layers use batch statistics there), recorded next to the eval-mode
        gate.  Both are recorded; a dead insertion is flagged (metric insertion_live_gradient = 0)."""
        if not new:
            return {}
        ctx = self.ctx
        n = min(256, len(self.bundle.train))
        part = self.bundle.train.index(torch.arange(n))
        X = self._cast(part.X)
        was = model.training
        model.eval()
        req = {id(p): p.requires_grad for p in model.parameters()}
        for p in model.parameters():
            p.requires_grad_(True)
            p.grad = None
        loss = task_loss(model(X), part.y.to(next(iter(X.values())).device), self.bundle.task)
        loss.backward()
        out = {}
        for iid in new:
            if iid not in model.implants:
                continue
            # an implant's own parameterised nodes (a group / merge implant without parameters is skipped)
            pks = {model.nodes[nid].pkey for nid in model.implants[iid].nodes
                   if nid in model.nodes and model.nodes[nid].owner == iid and model.nodes[nid].pkey is not None}
            pks = {pk for pk in pks if any(True for _ in model.mods[pk].parameters())}
            if not pks:
                continue
            out[iid] = sum(float(p.grad.abs().sum()) for pk in pks for p in model.mods[pk].parameters()
                           if p.grad is not None)
        for p in model.parameters():
            p.grad = None
            p.requires_grad_(req[id(p)])
        model.train(was)
        live = all(v > 0 for v in out.values()) if out else True
        gh = model.structural_hash()
        ctx.metric(stage, "train_calibration", "insertion_live_gradient", int(live), gh, implant_grad_l1=out)
        res = {"live_gradient": live, "implant_grad_l1": out}
        if before_train is not None:
            after_train = self._train_mode_outputs(model)
            eq = M.equivalence(before_train, after_train)
            ctx.metrics(stage, "calibration", eq, prefix="insertion_equivalence_train_mode.", graph_hash=gh)
            res["train_mode_max_rel"] = eq.get("max_rel")
        ctx.log({"event": "insertion_checks", "stage": stage, **res})
        return res

    def insertion_gate(self, model: GraphNet, before: dict, new: list[str], stage: str,
                       pre: Optional[GraphNet] = None) -> tuple[str, dict]:
        """Exactness contract of the insertion (v13: common.identity_check, claims judged per input set with
        fixed tolerances declared in advance).  Labels:
          exact                      high-precision pre/post agreement within the storage-dtype tolerance, the
                                     edit's change to the execution-precision error (d_edit) and the observed
                                     execution-dtype agreement within their fixed bounds, finite outputs, on
                                     calibration, fresh and stress inputs separately;
          L0_approximate             not exact, the round contains implants DECLARED approximate, and
                                     deleting exactly those implants passes the same check;
          L0_inconclusive_<reason>   execution_changed (the edit changes the execution-precision error, d_edit, or
                                     the observed agreement beyond fixed bounds), low output
                                     scale or non-finite outputs: exactness cannot be established;
          L0_failed_exact_insertion  the high-precision function changed for a construction declared exact.
        The last two are not exact expansions: diagnostics and the offending model are saved and the run is
        quarantined (status 'invalid').  An agreement on these inputs is not a global identity certificate."""
        ctx = self.ctx
        after = C.outputs_on(model, self.sets, self.dtype)
        eq = C.equivalence_report(before, after)
        if pre is None:
            raise ValueError("insertion_gate needs the pre-edit model (pre=) for the high-precision check")
        chk = C.identity_check(pre, model, self.sets, self.dtype, self.cfg)
        approx_ids = [i for i in new if i in model.implants and model.implants[i].identity == "approximate"]
        attrib = None
        if chk["verdict"] == "exact":
            label = "exact"
        elif chk["verdict"] == "changed" and approx_ids:
            try:
                tops = [i for i in approx_ids if model.implants[i].parent not in approx_ids]
                h = E.delete(model, tops)
                chk2 = C.identity_check(pre, h, self.sets, self.dtype, self.cfg)
                attrib = {k: v.get("a_high_precision") for k, v in chk2["sets"].items()}
                label = "L0_approximate" if chk2["verdict"] == "exact" else "L0_failed_exact_insertion"
            except InvalidDeletion as ex:
                attrib = {"error": str(ex)}
                label = "L0_failed_exact_insertion"
        elif chk["verdict"] in ("execution_changed", "low_scale", "nonfinite", "no_inputs"):
            label = f"L0_inconclusive_{chk['verdict']}"
        else:
            label = "L0_failed_exact_insertion"
        gh = model.structural_hash()
        for k, v in eq.items():
            ctx.metrics(stage, k, v, prefix="insertion_equivalence.", graph_hash=gh)
        for k, v in chk["sets"].items():
            ctx.metrics(stage, k, {kk: vv for kk, vv in v.items() if isinstance(vv, (int, float, bool))},
                        prefix="identity_check.", graph_hash=gh)
        ctx.metric(stage, "none", "insertion_label", label, gh, implants=new, approximate_implants=approx_ids,
                   tolerance_rel=chk["tolerance_high_precision"], edit_roundoff_max_rel=chk["edit_roundoff_max_rel"],
                   observed_max_rel=chk["observed_max_rel"],
                   identity_verdict=chk["verdict"], preexisting_instability_sets=chk["preexisting_instability_sets"])
        if label.startswith("L0_failed") or label.startswith("L0_inconclusive"):
            diag = {"stage": stage, "label": label, "identity_check": chk, "equivalence_exec_dtype": eq,
                    "implants": new, "approximate_implants": approx_ids,
                    "after_removing_approximate_implants": attrib,
                    "diagnostic": "the high-precision function changed, or exactness could not be established at "
                                  "the execution dtype; check BN statistics, dtype, stochastic layers, shared "
                                  "parameters and conditioning"}
            ctx.log({"event": "insertion_not_exact", **{k: v for k, v in diag.items() if k != "identity_check"}})
            ctx.save_ckpt(f"invalid_{stage}", model, None, diag)
            ctx.save_graph(f"invalid_{stage}", model)
            raise ScientificInvalid(f"{stage}: {label} (verdict {chk['verdict']}; per set: "
                                    f"{ {k: v['verdict'] for k, v in chk['sets'].items()} })", diag)
        return label, eq

    def _round_eval(self, model: GraphNet, tr: Trainer, r: int, stage: str, deletions: bool = True):
        ctx = self.ctx
        ctx.updates, ctx.examples = tr.state["global_step"], tr.state["examples"]
        refs = {"f0": self.f0_preds}
        fc = self.fc_preds(r) if self.g["topology"] != "none" else None
        if fc is not None:
            refs["fc"] = fc
        save = stage == "final" or "all_rounds" in self.cfg["eval"]["save_predictions"]
        res, preds = C.eval_log(ctx, model, self.bundle, stage, refs, save_preds=save)
        C.log_accounting(ctx, model, stage, C.seq_T(self.bundle))
        if deletions and model.atoms():
            C.single_deletions(ctx, model, self.bundle, stage, res)
            if self.g["evaluate_deletions"] and stage.startswith("round_") and len(model.atoms()) <= 6:
                # best simplification found by deletion at this point of the history (I1)
                d = evaluate_family(ctx, model, self.bundle, stage, original_preds=self.f0_preds,
                                    dcfg=dict(self.cfg["deletion"], family="exhaustive"))
                ctx.metric(stage, "none", "best_deletion_params_removed",
                           max([c["best_valid_deletion"]["params_removed"] for c in d["certificates"]
                                if c["best_valid_deletion"] and c["partition"] == "val" and c["criterion"] == "task"]
                               or [0]), model.structural_hash())
        ctx.metric(stage, "val", "training_quality", training_quality(res, self.bundle))
        return res

    def _ckpt_extra(self, tr=None):
        return {"aux_heads": self.aux_heads,
                "extra_frozen": sorted(tr.policy_extra_frozen) if tr is not None else [],
                "work": copy.deepcopy(self.ctx.work)}

    def _train_round(self, model, tr, r, stage_name):
        seg = self.make_segment(model, r, f"round_{r}", self.upr,
                                eval_points=_eval_points(self.upr, self.cfg["train"]["eval_every"]),
                                eval_fn=_val_eval_fn(self.ctx, self.bundle))
        if self.g["driver"] == "neutral_mutation":
            info = self.neutral_mutation(model, tr, r, self.upr)
            self.ctx.updates, self.ctx.examples = tr.state["global_step"], tr.state["examples"]
            self.ctx.log({"event": "neutral_mutation", "round": r, **info})
            self.ctx.metrics(stage_name, "train_calibration", info)
            return

        def cb():
            self.ctx.save_ckpt("partial", model, tr, {"round": r, "phase": "train", **self._ckpt_extra(tr)})
        tr.run(seg, checkpoint_cb=cb)
        if getattr(self, "_helper_restore", None) is not None:
            self._helper_restore(model)      # the expanded model is evaluated with every helper available

    # ------------------------------------------------------------ v3: grow / contract cycles
    def _val_risk(self, model: GraphNet) -> float:
        r_, _ = evaluate(model, self.bundle, ["val"], self.cfg["train"]["eval_batch"])
        return M.headline(r_["val"], self.bundle.task)

    def _contraction_due(self, model: GraphNet, r: int) -> tuple[bool, dict]:
        k = int(self.g["contract_every"])
        if not k:
            return False, {}
        cyc = model.meta.setdefault("growth_state", {}).setdefault("cycle", {"index": 0, "start_round": 1})
        local = r - int(cyc["start_round"]) + 1
        if self.g["contract_trigger"] == "replay":
            # V3-11b: the realised schedule of an adaptive (damage-triggered) parent, replayed without probes
            if not hasattr(self, "_replay_rounds"):
                self._replay_rounds = sorted({int(x["round"]) for x in self.ctx.parent_json("schedule",
                                                                                            "contractions.json")})
            due = r in self._replay_rounds or r == self.R
            return due, ({"reason": "replay", "local_round": local} if due else {})
        if local >= k or r == self.R:
            return True, {"reason": "schedule", "local_round": local}
        if self.g["contract_trigger"] == "damage":
            tops = [i for i, v in model.implants.items() if v.parent is None]
            if not tops:
                return False, {}
            base = self._val_risk(model)
            try:
                dmg = self._val_risk(E.delete(model, tops)) - base
            except InvalidDeletion:
                return False, {"reason": "probe_not_deletable"}
            from ..train.trainer import forward_macs
            nv = len(self.bundle.val)
            # forward-only probe cost (selection overhead, F06e): charged at one forward per example
            self.ctx.count_work("contract_trigger_probe", forward_examples=2 * nv,
                                macs=int(nv * (forward_macs(model, C.seq_T(self.bundle), {}) +
                                               forward_macs(E.delete(model, tops), C.seq_T(self.bundle), {}))))
            self.ctx.metric(f"probe_r{r}", "val", "contraction_trigger_damage", dmg, model.structural_hash(),
                            threshold=float(self.g["contract_threshold"]))
            if dmg > float(self.g["contract_threshold"]):
                return True, {"reason": "damage_trigger", "damage": dmg, "local_round": local}
        return False, {}

    def _contract(self, model: GraphNet, tr: Trainer, r: int, resume: Optional[dict] = None):
        """Return to the f0 architecture: exact folds where the implant is affine
        (contract_method=auto), otherwise a gate anneal to exactly zero over contract_updates
        updates (auto / gate) or an abrupt deletion followed by contract_updates repair updates
        (abrupt, or auto without a gateable implant); then physical removal.  The result must
        have the f0 architecture (asserted).  Resumable inside the anneal / repair."""
        from ..graph.accounting import architecture_hash
        ctx = self.ctx
        st = model.meta.setdefault("growth_state", {})
        cyc = st.setdefault("cycle", {"index": 0, "start_round": 1})
        c = int(cyc["index"])
        n = int(self.g["contract_updates"])
        method = self.g["contract_method"]
        if resume is None:
            tops = [i for i, v in model.implants.items() if v.parent is None]
            info = {"cycle": c, "round": r, "implants": tops, "folded": [], "gated": [], "deleted": [],
                    "pre_risk": self._val_risk(model)}
            # P1 (v5): non-mutating diagnostics of every implant this contraction removes
            from .diagnostics import contraction_diagnostics
            # metric rows carry the update / example counters: take them from the trainer, which is exact
            # after a resume (the context's counters are only refreshed at evaluations)
            ctx.updates, ctx.examples = int(tr.state["global_step"]), int(tr.state["examples"])
            contraction_diagnostics(ctx, model, self.bundle, list(tops), f"contraction_c{c}_r{r}")
            info["fold_into_neighbour"] = False
            for t in list(tops):
                if method == "auto" and (model.implants[t].deletion == "fold" or
                                         E.region_is_affine(model, model.region(t))):
                    try:
                        replaces = model.implants[t].deletion == "fold"     # replaced an existing node
                        model = E.fold_implant(model, t, share_params=True)
                        info["folded"].append(t)
                        # an affine series implant folds to an extra linear map: merged into the adjacent
                        # backbone linear by the folding export below (optimizer state of those tensors resets)
                        info["fold_into_neighbour"] = info["fold_into_neighbour"] or not replaces
                    except InvalidDeletion:
                        pass
            rest = [t for t in tops if t not in info["folded"]]
            mode = "none"
            if rest:
                gateable = all(not (model.implants[t].kind == "branch" and
                                    model.nodes[model.implants[t].merge].op == "route") for t in rest)
                if method in ("auto", "gate") and n > 0 and gateable:
                    mode = "gate"
                    info["gated"] = rest
                    info["gates"] = [E.add_gate(model, t, 1.0) for t in rest]
                else:
                    mode = "repair"
                    model = E.delete(model, rest, share_params=True)
                    info["deleted"] = rest
                    info["immediate_damage"] = self._val_risk(model) - info["pre_risk"]
            info["mode"] = mode
            tr.model = model
            tr.configure("none", None)
        else:
            info = dict(resume)
            mode = info["mode"]
        seg_name = f"contract_r{r}"

        def cb():
            ctx.save_ckpt("partial", tr.model, tr, {"round": r, "phase": "contract", "contract": info,
                                                     **self._ckpt_extra(tr)})
        if mode == "gate" and n > 0:
            gids = info["gates"]

            def anneal(trn, k, gids=gids):
                v = max(0.0, 1.0 - (k + 1) / n)
                for gid in gids:
                    trn.model.gate_vals[gid] = v
            tr.run(Segment(seg_name, n, on_step=anneal), checkpoint_cb=cb)
            model = tr.model
            for gid in gids:
                model.gate_vals[gid] = 0.0
            info["after_anneal_risk"] = self._val_risk(model)
            model = E.delete(model, info["gated"], share_params=True)
        elif mode == "repair" and n > 0:
            tr.run(Segment(seg_name, n), checkpoint_cb=cb)
            model = tr.model
        E.prune_dead(model)
        exp, _ = export_compact(model, fold_linear=bool(info.get("fold_into_neighbour")))
        arch_ok = architecture_hash(exp) == self.f0_arch
        if not arch_ok:
            raise ScientificInvalid(f"cycle {c}: the contracted model does not have the f0 architecture",
                                    {"cycle": c, "implants_left": sorted(model.implants)})
        # continue in an f0-structured graph (f0's node ids and cutpoints, so later cycles cut where
        # f0 cuts) holding the contracted weights.  The live model is the source whenever it already has
        # the f0 architecture (exact tensor correspondence, so optimizer state follows its tensors);
        # after a fold into a neighbouring layer the folded export is the source and the state resets.
        from ..graph.accounting import transfer_by_architecture
        src = model if architecture_hash(model) == self.f0_arch else exp
        rebuilt = self.f0.clone(share_params=False)
        rebuilt.to(next(model.parameters()).device)
        pairs = transfer_by_architecture(src, rebuilt)
        old_opt = tr.opt
        rebuilt.meta = copy.deepcopy(model.meta)
        model = rebuilt
        tr.model = model
        tr.configure("none", None, reset_state=True)
        carried = 0
        if old_opt is not None and src is not exp and self.cfg["train"]["opt_state_on_edit"] == "preserve":
            for ps, pr in pairs:
                if ps in old_opt.state:
                    tr.opt.state[pr] = old_opt.state[ps]
                    carried += 1
        info["opt_state_carried_tensors"] = carried
        info.update({"post_risk": self._val_risk(model), "f0_architecture": True, "updates": n if mode != "none"
                     else 0})
        # next cycle: fresh growth state (implants are gone), cycle counter advanced
        model.meta["growth_state"] = {"cycle": {"index": c + 1, "start_round": r + 1}}
        self.aux_heads = []
        ctx.updates, ctx.examples = tr.state["global_step"], tr.state["examples"]   # exposure (also after a resume)
        gh = model.structural_hash()
        for k_, v_ in info.items():
            if isinstance(v_, (int, float)) and not isinstance(v_, bool):
                ctx.metric(f"cycle_{c}", "val", f"contraction.{k_}", v_, gh)
        C.eval_log(ctx, model, self.bundle, f"cycle_{c}")
        ctx.log({"event": "contraction", **{k_: v_ for k_, v_ in info.items() if k_ != "gates"}})
        model.meta.setdefault("cycle_log", []).append({k_: v_ for k_, v_ in info.items() if k_ != "gates"})
        return model

    def run_incremental(self) -> dict:
        ctx = self.ctx
        done = [r for r in range(1, self.R + 1) if ctx.has_ckpt(f"round_{r}")]
        start = max(done) if done else 0
        if ctx.has_ckpt("partial") and ctx.load_ckpt("partial")["extra"]["round"] <= start:
            ctx.ckpt_path("partial").unlink()     # killed after round_{start} was saved: the partial is stale
        contract_resume = None
        if ctx.has_ckpt("partial"):
            model, tr, ck = self._restore("partial")
            r_part = ck["extra"]["round"]
            self._mut_resume = ck["extra"] if ck["extra"].get("phase") == "mutation" else None
            if ck["extra"].get("phase") == "contract":
                contract_resume = ck["extra"]["contract"]
            ctx.log({"event": "resume", "round": r_part, "seg_step": tr.state["seg_step"]})
        else:
            r_part = None
            if start:
                model, tr, _ = self._restore(f"round_{start}")
            else:
                model, tr = self._fresh_from_f0()
        for r in range(start + 1, self.R + 1):
            if contract_resume is None:
                if r_part != r:
                    new = self._insert_round(model, tr, r)
                    ctx.save_ckpt(f"post_insert_r{r}", model, tr, self._ckpt_extra(tr))
                self._train_round(model, tr, r, f"round_{r}")
                due, why = self._contraction_due(model, r)
            else:
                due, why = True, {"reason": "resumed"}
            if due:
                if contract_resume is None:
                    # v8: the exact pre-contraction state (round_<r> is saved AFTER the contraction), so cycle
                    # diagnostics can be recomputed later without replaying the round
                    ctx.save_ckpt(f"pre_contraction_r{r}", model, tr, self._ckpt_extra(tr))
                model = self._contract(model, tr, r, contract_resume)
                contract_resume = None
            self._round_eval(model, tr, r, f"round_{r}")
            ctx.save_ckpt(f"round_{r}", model, tr, self._ckpt_extra(tr))
            ctx.ckpt_path("partial").unlink(missing_ok=True)
            r_part = None
        return self.finish(model, tr)

    def run_all_at_once(self) -> dict:
        ctx = self.ctx
        if self.g["topology"] in ("hard_submodule",) or self.g["policy"] != "fixed":
            raise Unsupported("all_at_once needs a data-independent growth program (no adaptive selection)")
        if ctx.has_ckpt(f"round_{self.R}"):
            model, tr, _ = self._restore(f"round_{self.R}")
            return self.finish(model, tr)
        if ctx.has_ckpt("partial"):
            model, tr, ck = self._restore("partial")
        else:
            model, tr = self._fresh_from_f0()
            before = C.outputs_on(model, self.sets, self.dtype)
            pre = model.clone(share_params=False)
            new_all = []
            for r in range(1, self.R + 1):
                new_all += self.grower.round(model, r, self.R)
            self.insertion_gate(model, before, new_all, "insert_all", pre=pre)
            if self.g["aux_objective"] != "none":
                self.aux_heads += add_aux_heads(model, new_all, self.bundle.out_dim, self.grower.gen("aux/all"))
            tr.configure(self.cfg["train"]["freeze"], new_all[0] if new_all else None)
            ctx.save_ckpt("post_insert_all", model, tr, self._ckpt_extra(tr))
        total = self.R * self.upr

        def efn(trn, step):
            r = step // self.upr
            self._round_eval(trn.model, trn, r, f"round_{r}", deletions=True)
            return {}
        seg = self.make_segment(model, self.R, "all_at_once", total,
                                eval_points=[self.upr * k for k in range(1, self.R + 1)], eval_fn=efn)
        tr.run(seg, checkpoint_cb=lambda: ctx.save_ckpt("partial", model, tr, {"round": 0, **self._ckpt_extra(tr)}))
        ctx.save_ckpt(f"round_{self.R}", model, tr, self._ckpt_extra(tr))
        ctx.ckpt_path("partial").unlink(missing_ok=True)
        return self.finish(model, tr)

    def run_from_scratch(self) -> dict:
        """Final enlarged architecture from random initialisation, trained for
        baseline_updates + rounds*updates_per_round on the task."""
        ctx = self.ctx
        if self.g["topology"] in ("hard_submodule",) or self.g["policy"] != "fixed":
            raise Unsupported("from_scratch needs a data-independent growth program")
        if ctx.has_ckpt(f"round_{self.R}"):
            model, tr, _ = self._restore(f"round_{self.R}")
            return self.finish(model, tr)
        if ctx.has_ckpt("partial"):
            model, tr, ck = self._restore("partial")
        else:
            model = C.new_model(self.cfg, self.bundle, ctx.device, key="scratch")
            for r in range(1, self.R + 1):
                self.grower.round(model, r, self.R)
            C.reinit_all(model, torch_gen(seed_of(self.cfg, "init"), "init", "scratch_reinit"))
            ctx.metric("insert_all", "none", "insertion_label", "not_applicable_from_scratch",
                       model.structural_hash())
            if self.g["aux_objective"] != "none":
                self.aux_heads += add_aux_heads(model, list(model.implants), self.bundle.out_dim,
                                                self.grower.gen("aux/all"))
            tr = C.make_trainer(ctx, model, self.bundle, "scratch")
            tr.configure("none", None)
        base_n = self.cfg["train"]["baseline_updates"]
        total = base_n + self.R * self.upr

        def efn(trn, step):
            r = (step - base_n) // self.upr
            self._round_eval(trn.model, trn, r, f"round_{r}", deletions=True)
            return {}
        seg = Segment("from_scratch", total, eval_points=[base_n + self.upr * k for k in range(1, self.R + 1)],
                      eval_fn=efn)
        tr.run(seg, checkpoint_cb=lambda: ctx.save_ckpt("partial", model, tr, {"round": 0, **self._ckpt_extra(tr)}))
        ctx.save_ckpt(f"round_{self.R}", model, tr, self._ckpt_extra(tr))
        ctx.ckpt_path("partial").unlink(missing_ok=True)
        return self.finish(model, tr)

    # ------------------------------------------------------------------ final
    def finish(self, model: GraphNet, tr: Trainer) -> dict:
        ctx = self.ctx
        # main training of this history (the parent baseline's updates are the parent's work)
        g0 = 0 if self.g["schedule"] == "from_scratch" else int(self.f0_ck["trainer"]["state"]["global_step"])
        e0 = 0 if self.g["schedule"] == "from_scratch" else int(self.f0_ck["trainer"]["state"]["examples"])
        m0 = 0 if self.g["schedule"] == "from_scratch" else int(self.f0_ck["trainer"]["state"].get("train_macs", 0))
        mb0 = 0 if self.g["schedule"] == "from_scratch" else \
            int(self.f0_ck["trainer"]["state"].get("train_macs_bwd", 0))
        ctx.count_work("growth_train", updates=tr.state["global_step"] - g0, examples=tr.state["examples"] - e0,
                       seconds=tr.timing["train_seconds"], macs=int(tr.state.get("train_macs", 0)) - m0,
                       macs_bwd=int(tr.state.get("train_macs_bwd", 0)) - mb0,
                       teacher_macs=int(tr.state.get("teacher_macs", 0)))
        res = self._round_eval(model, tr, self.R, "final", deletions=False)
        ctx.save_graph("final", model)
        out = {"final": {k: {kk: vv for kk, vv in v.items() if isinstance(vv, (int, float))} for k, v in res.items()},
               "n_implants": len(model.implants), "n_atoms": len(model.atoms()),
               "graph_hash": model.structural_hash(), "global_step": tr.state["global_step"],
               "train_seconds": tr.timing["train_seconds"]}
        if self.g["evaluate_deletions"] and model.atoms():
            d = evaluate_family(ctx, model, self.bundle, "final", original_preds=self.f0_preds)
            out["deletions"] = {"n_distinct_graphs": d["n_distinct_graphs"], "exhaustive": d["info"]["exhaustive"],
                                "certificates": [c for c in d["certificates"] if c["partition"] == "val"][:6]}
        if self.g["crossover"] and model.implants and self.g["schedule"] == "incremental":
            out["crossover"] = crossover(ctx, model, self.f0, self.bundle, self.R)
        if self.g["probes"] and any(not k_.startswith("_") for k_ in self.bundle.train.aux):
            from .probes import probe_intermediates
            out["probes"] = probe_intermediates(ctx, model, self.bundle, "final")
        if self.g["topology"] == "known_module":
            out["known_module"] = known_module_report(ctx, model)
        out["probes_robustness"] = robustness_probes(ctx, model, self.bundle)
        if tr.state.get("spec_exposure"):
            out["spec_exposure"] = dict(tr.state["spec_exposure"])     # empirical, under the actual sampler
        if tr.state.get("spec_exposure_pe"):
            # v23: mask eligibility per example, per growth round and per PHYSICAL branch (a round-r branch lives
            # in rounds r..R); counts are appearances whose gradient was eligible to reach the branch
            pe = tr.state["spec_exposure_pe"]
            if "n" in pe:
                pe = {"0": pe}
            q = torch.tensor([0.05, 0.25, 0.5, 0.75, 0.95], dtype=torch.float64)

            def summ(n_, a_, b_):
                seen = n_ > 0
                sh = a_[seen] / n_[seen]
                return {"examples_seen": int(seen.sum()), "appearances_mean": float(n_.mean()),
                        "share_a_mean": float(sh.mean()) if len(sh) else None,
                        "share_a_std": float(sh.std()) if len(sh) > 1 else None,
                        "share_a_quantiles": dict(zip(["p05", "p25", "p50", "p75", "p95"],
                                                      [float(x) for x in torch.quantile(sh, q)])) if len(sh) else None,
                        "examples_never_on_a": int((a_[seen] == 0).sum()),
                        "examples_never_on_b": int((b_[seen] == 0).sum())}
            T_ = {w: {k: torch.tensor(v, dtype=torch.float64) for k, v in d.items()} for w, d in pe.items()}
            by_w = {w: summ(d["n"], d["a"], d["b"]) for w, d in sorted(T_.items())}
            by_branch = {}
            for r in range(1, self.R + 1):
                ws = [w for w in T_ if int(w) >= r - 1]
                if not ws:
                    continue
                n_ = sum(T_[w]["n"] for w in ws)
                a_ = sum(T_[w]["a"] for w in ws)
                b_ = sum(T_[w]["b"] for w in ws)
                by_branch[f"spec/r{r}"] = {"born_job_update": (r - 1) * self.upr, "rounds": [int(w) + 1 for w in
                                                                                             sorted(ws, key=int)],
                                           **summ(n_, a_, b_)}
            n_all = sum(d["n"] for d in T_.values())
            a_all = sum(d["a"] for d in T_.values())
            b_all = sum(d["b"] for d in T_.values())
            out["spec_exposure_per_example"] = {**summ(n_all, a_all, b_all), "by_round": by_w,
                                                "by_physical_branch": by_branch,
                                                "measure": "mask eligibility per sampled appearance (not a check that "
                                                           "the gradient was nonzero)"}
            torch.save({w: {k: torch.tensor(v) for k, v in d.items()} for w, d in pe.items()},
                       ctx.dir / "spec_exposure_per_example.pt")
        if self.g.get("spec_partition") == "matched_quota" and self.g.get("topology") == "specialized":
            qs = {}
            for w in range(self.R):
                p_ = self._quota_path(w)
                if not p_.exists():
                    continue
                rq = (getattr(self, "_quota", None) or {}).get(w) or torch.load(p_, map_location="cpu",
                                                                                 weights_only=False)
                seen = rq["appearances"] > 0
                qs[str(w)] = {"stream_hash": rq["stream_hash"], "quota_hash": rq["quota_hash"],
                              "updates": rq["updates"], "fraction": rq["fraction"], "b_run": rq["b_run"],
                              "examples_seen": int(seen.sum()),
                              "appearances_min": int(rq["appearances"][seen].min()) if seen.any() else None,
                              "appearances_max": int(rq["appearances"][seen].max()) if seen.any() else None,
                              "quota_share_a": float(rq["quota_a"].sum()) / max(1, int(rq["appearances"].sum())),
                              "b_runs_mean": float(rq["b_runs"][seen].double().mean()) if seen.any() else None,
                              "b_runs_max": int(rq["b_runs"].max())}
            out["spec_quota"] = qs
        if "_spec_phase" in self.bundle.train.aux:
            # v22: the cyclic schedule's per-example exposure over the job's updates (exact, from the phases)
            ph = self.bundle.train.aux["_spec_phase"].cpu().long()
            T, aL = self.spec_period, cyclic_a_len(self.spec_fraction, self.spec_period)
            total = int(tr.state["global_step"]) - int(self.g0)
            cnt = (total // T) * aL * torch.ones(len(ph), dtype=torch.long)
            for t in range(int(self.g0) + (total // T) * T, int(self.g0) + total):
                cnt += cyclic_membership(ph, t, T, aL).long()
            share = cnt.double() / max(1, total)
            out["spec_cyclic"] = {"period": T, "updates_in_a_per_cycle": aL, "cycle_share_a": aL / T,
                                  "job_updates": total, "whole_cycles": total // T,
                                  "per_example_share_a_min": float(share.min()),
                                  "per_example_share_a_max": float(share.max()),
                                  "per_example_share_a_mean": float(share.mean()),
                                  "stay_length_a_updates": aL, "stay_length_b_updates": T - aL,
                                  "masks_control": "gradients only; the forward route of every example is unchanged"}
            torch.save(cyclic_membership(ph, int(tr.state["global_step"]), T, aL).long(),
                       ctx.dir / "spec_partition_final.pt")
        if "_spec_random" in self.bundle.train.aux:
            # v19: the split as it stands at the end (equal to spec_partition.pt unless reassigned); events are
            # replayed first, so a job restored after its training ends with the same split
            # (a diverged update was not counted in global_step, but its events were applied before its batch)
            self._spec_reassign_until(int(tr.state["global_step"]) - int(self.g0) + (1 if tr.state.get("diverged")
                                                                                       else 0))
            fin = self.bundle.train.aux["_spec_random"].cpu()
            torch.save(fin, ctx.dir / "spec_partition_final.pt")
            ra = self.g.get("spec_reassign") or {}
            ever = getattr(self, "_spec_ever_moved", None)
            out["spec_reassign"] = {"mode": ra.get("mode", "none"), "schedule": dict(ra),
                                    "events": list(self._spec_reassign_log),
                                    "declared_events": len(self._spec_reassign_events()),
                                    "final_differs_from_initial_fraction":
                                        float((fin != self._spec_ind0).double().mean())
                                        if getattr(self, "_spec_ind0", None) is not None else None,
                                    "ever_moved_fraction": float(ever.double().mean()) if ever is not None else 0.0,
                                    "masks_control": "gradients only; the forward route of every example is "
                                                     "unchanged"}
        gi = self.group_inference_check(model)
        if gi is not None:
            out["group_inference_check"] = gi
            if not gi["predictions_identical_under_permuted_groups"]:
                raise ScientificInvalid("predictions depend on group metadata at inference", gi)
        routes = route_diagnostics(ctx, model, self.bundle)
        if routes:
            out["routing"] = routes
        exp, rep = export_compact(model, self.sets["fresh"])
        ctx.metric("final", "fresh", "export_max_abs_err", rep.get("max_abs_err"), exp.structural_hash())
        ctx.metric("final", "none", "export_params", rep["after"]["params"], exp.structural_hash())
        from ..graph.accounting import architecture_hash, report as acct_report
        er = acct_report(exp, C.seq_T(self.bundle))
        for k_ in ("macs", "param_bytes_fp32", "peg_bits_per_example"):
            if k_ in er:
                ctx.metric("final", "none", f"export_{k_}", er[k_], exp.structural_hash())
        ctx.metric("final", "none", "export_architecture_equals_f0", int(architecture_hash(exp) == self.f0_arch),
                   exp.structural_hash())
        if set(self.cfg["train"]["snapshot_at"]) & {int(tr.state["global_step"]) - self.g0} and \
                not ctx.has_ckpt(f"snap_{int(tr.state['global_step']) - self.g0}"):
            ctx.save_ckpt(f"snap_{int(tr.state['global_step']) - self.g0}", model, tr, self._ckpt_extra(tr))
        out["export"] = {"params_before": rep["before"]["params"], "params_after": rep["after"]["params"],
                         "max_abs_err": rep.get("max_abs_err")}
        ctx.save_ckpt("final", model, tr, self._ckpt_extra(tr))
        if int(self.g.get("contract_every", 0) or 0):
            ctx.save_json("contractions.json", [{k_: v_ for k_, v_ in x.items() if isinstance(v_, (int, float, str))}
                                                for x in model.meta.get("cycle_log", [])])
        C.record_endpoint(ctx, self.bundle, "final", bool(tr.state.get("diverged")), tr.state.get("diverged_reason"),
                          {"f0_architecture_hash": self.f0_arch})
        return out


@torch.no_grad()
def route_diagnostics(ctx, model: GraphNet, bundle) -> dict:
    """Routing entropy and expert utilisation on validation inputs (diagnostics,
    not definitions of usefulness)."""
    rnodes = [n for n in model.live_nodes() if model.nodes[n].op == "route"]
    if not rnodes:
        return {}
    model.eval()
    c = {"collect_routes": True}
    X = {k: v[:4096] for k, v in bundle.val.X.items()}
    model(X, c)
    out = {}
    for nid, p in c.get("routes", {}).items():
        lay = model.nodes[nid].attrs.get("layout", model.layout)
        pp = p.movedim(1, -1) if lay == "img" else p
        pp = pp.reshape(-1, pp.shape[-1]).double()
        ent = float(-(pp * (pp + 1e-30).log()).sum(-1).mean())
        util = pp.mean(0).tolist()
        terms = [t for t, on in zip(model.nodes[nid].attrs["terms"], model.nodes[nid].attrs["active"]) if on]
        out[nid] = {"mean_entropy_nats": ent, "max_entropy_nats": math.log(pp.shape[-1]),
                    "utilisation": dict(zip(terms, util))}
        ctx.metric("final", "val", f"route[{nid}].entropy", ent, model.structural_hash())
    return out


@torch.no_grad()
def robustness_probes(ctx, model: GraphNet, bundle) -> dict:
    """Input-corruption probe (Gaussian noise in standardised input units; a
    corruption probe, not an OOD benchmark) and precision probe (weights and
    inputs evaluated in bfloat16 against fp32), both on validation inputs."""
    from ..train.trainer import predict
    part = bundle.val
    base = predict(model, part)
    out = {}
    if part.X["x"].is_floating_point():
        g = torch.Generator().manual_seed(0)
        for sigma in (0.1, 0.3):
            noisy = part.index(torch.arange(len(part), device=part.y.device))
            noisy.X = dict(noisy.X)
            noisy.X["x"] = part.X["x"] + sigma * torch.randn(part.X["x"].shape, generator=g).to(part.X["x"])
            o = predict(model, noisy)
            d = M.drift(o, base, bundle.task, part.y, bundle.target_scale)
            r = M.task_metrics(o, part.y, bundle.task, part.groups, bundle.target_scale)
            out[f"noise_{sigma}"] = {"risk": M.headline(r, bundle.task), **d}
            ctx.metrics("final", "val", {"risk": out[f"noise_{sigma}"]["risk"], **d}, prefix=f"corruption_probe_{sigma}.")
    h = model.clone(share_params=False).to(torch.bfloat16)
    Xb = {k: (v.to(torch.bfloat16) if v.is_floating_point() else v) for k, v in part.X.items()}
    try:
        h.eval()
        o = torch.cat([h({k: v[i:i + 4096] for k, v in Xb.items()}).float() for i in range(0, len(part), 4096)])
        d = M.drift(o, base, bundle.task, part.y, bundle.target_scale)
        out["bf16"] = d
        ctx.metrics("final", "val", d, prefix="precision_probe_bf16.")
    except Exception as ex:          # some ops (e.g. linalg.inv) have no bf16 kernel on CPU
        out["bf16"] = {"unsupported": repr(ex)}
    return out


def known_module_report(ctx, model: GraphNet) -> dict:
    out = {}
    for iid, imp in model.implants.items():
        info = imp.meta.get("known_module")
        if not info:
            continue
        kn = [n for n in imp.nodes if model.nodes[n].role == "known"][0]
        bn = [n for n in imp.nodes if model.nodes[n].role == "B"][0]
        mod = model.mods[model.nodes[kn].pkey]
        init = []
        if info.get("initial_params_file") and (ctx.dir / info["initial_params_file"]).exists():
            init = torch.load(ctx.dir / info["initial_params_file"], map_location="cpu")
        cur = [p.detach().cpu() for p in mod.parameters()]
        drift = None
        if init and cur:
            num = sum(((a - b) ** 2).sum() for a, b in zip(cur, init)).sqrt()
            den = sum((b ** 2).sum() for b in init).sqrt().clamp_min(1e-12)
            drift = float(num / den)
        bnorm = float(model.mods[model.nodes[bn].pkey].weight.detach().norm())
        out[iid] = {"kind": info["kind"], "adapter_B_norm": bnorm, "module_relative_param_change": drift,
                    "pretrain_updates": info.get("pretrain_updates", 0),
                    "reading": "recruited if deleting the implant hurts (see deletions); overwritten if the module "
                               "parameters moved far; bypassed if B stays near zero"}
        ctx.metrics("final", "none", {k: v for k, v in out[iid].items() if isinstance(v, (int, float))},
                    prefix=f"known[{iid}].")
    return out


@torch.no_grad()
def crossover(ctx, model: GraphNet, f0: GraphNet, bundle, R: int) -> dict:
    """Historical crossover interventions relative to the FIRST top-level cut:
    swap backbone-upstream / implant / backbone-downstream parameters between
    the original model, the implants at insertion time, and the current model.
    Diagnoses co-adaptation; not a unique causal attribution."""
    from ..train.trainer import region_sets
    tops = [i for i, v in model.implants.items() if v.parent is None]
    if not tops:
        return {}
    first = min(tops, key=lambda s: int(s[1:]))
    rs = region_sets(model, first)
    pk = lambda nodes: {model.nodes[n].pkey for n in nodes if model.nodes[n].pkey}
    up, down = pk(rs["upstream"]), pk(rs["downstream"])
    imp = pk(rs["implants"])
    init_imp = {}
    for r in range(1, R + 1):
        if ctx.has_ckpt(f"post_insert_r{r}"):
            st = ctx.load_ckpt(f"post_insert_r{r}")["model"]["state"]
            for k, v in st.items():
                if k.split(".")[1] in imp:
                    init_imp.setdefault(k, v)   # earliest saved post-insertion state = state at insertion
    f0_state = f0.state_dict()

    def variant(src_up, src_imp, src_down):
        h = model.clone(share_params=False)
        sd = h.state_dict()
        for k in sd:
            p = k.split(".")[1]
            src = src_up if p in up else (src_imp if p in imp else (src_down if p in down else "current"))
            if src == "orig" and k in f0_state:
                sd[k] = f0_state[k]
            elif src == "init" and k in init_imp:
                sd[k] = init_imp[k]
        h.load_state_dict(sd)
        return h

    res = {}
    for name, (a, b, c) in {"orig_up+cur_imp+orig_down": ("orig", "current", "orig"),
                            "cur_up+init_imp+cur_down": ("current", "init", "current"),
                            "orig_up+cur_imp+cur_down": ("orig", "current", "current"),
                            "cur_up+cur_imp+orig_down": ("current", "current", "orig"),
                            "current": ("current", "current", "current")}.items():
        h = variant(a, b, c)
        r, _ = evaluate(h, bundle, ["val", "test"], ctx.cfg["train"]["eval_batch"])
        res[name] = {p: M.headline(m, bundle.task) for p, m in r.items()}
        for p, m in r.items():
            ctx.metric("final", p, f"crossover[{name}].risk", M.headline(m, bundle.task), h.structural_hash())
    res["reference_cut_implant"] = first
    return res


def run_trajectory(ctx) -> dict:
    return Trajectory(ctx).run()
