"""Cut-level transplants (kind=transplant, mechanism C).

Two models of the same architecture (for example the pre-cycle f0 and a
post-cycle contracted model) are combined at a cut: every parameterised node
up to the cut comes from the `upstream` model, the rest from the `downstream`
model.  Reported on every partition:
  upstream, downstream     the two source models
  direct                   the transplant without alignment
  aligned                  with a low-cost alignment at the cut (transplant.align = symbol | affine),
                           fitted on TRAINING inputs only from paired cut activations
                           (upstream convention -> downstream convention); its parameters are counted
  bn_recalibrated          (transplant.bn_recalibrate) the aligned (or direct) transplant with BN running
                           statistics downstream of the cut recomputed on training inputs: a separate
                           intervention
A failed direct transplant does not prove lost knowledge (the conventions at
the cut may differ); the aligned row separates the two.
"""
from __future__ import annotations

import math
from typing import Optional

import torch
from torch import nn

from ..graph import edits as E
from ..graph.accounting import architecture_hash, transfer_by_architecture
from ..graph.graph import GraphNet
from ..train.trainer import evaluate
from ..train import metrics as M
from ..cop_pegs.transplant import fit_alignment, alignment_spec
from . import common as C
from .context import Unsupported


def _upstream_nodes(g: GraphNet, cut_src: str) -> set[str]:
    return g.ancestors(cut_src) | {cut_src}


@torch.no_grad()
def _cut_values(g: GraphNet, X: dict, node: str, batch: int = 1024) -> torch.Tensor:
    was = g.training
    g.eval()
    n = len(next(iter(X.values())))
    out = []
    for i in range(0, n, batch):
        _, v = g({k: t[i:i + batch] for k, t in X.items()}, return_nodes=[node])
        out.append(v[node])
    g.train(was)
    return torch.cat(out)


@torch.no_grad()
def recalibrate_bn(g: GraphNet, X: dict, nodes: set[str], batch: int = 256) -> int:
    """Recompute running statistics of the BN modules in `nodes` on training inputs
    (cumulative average over the whole set; no parameter changes)."""
    bns = [g.mods[g.nodes[n].pkey] for n in nodes if n in g.nodes and g.nodes[n].op == "bn"]
    if not bns:
        return 0
    saved = {id(m): m.momentum for m in bns}
    for m in bns:
        m.reset_running_stats()
        m.momentum = None
    was = g.training
    # only the selected BN modules run in train mode (accumulating statistics); every other module,
    # including upstream BN, stays in eval mode, so the statistics are those of eval-time inputs
    g.eval()
    for m in bns:
        m.train()
    n = len(next(iter(X.values())))
    for i in range(0, n, batch):
        g({k: t[i:i + batch] for k, t in X.items()})
    g.train(was)
    for m in bns:
        m.momentum = saved[id(m)]
    return len(bns)


def run_transplant(ctx) -> dict:
    cfg = ctx.cfg
    tp = cfg["transplant"]
    if tp["design"] == "grid":
        return run_transplant_grid(ctx)
    bundle = C.setup_data(ctx)
    up = GraphNet.from_checkpoint(ctx.parent_ckpt(tp["upstream"], tp["upstream_stage"])["model"], ctx.device)
    down = GraphNet.from_checkpoint(ctx.parent_ckpt(tp["downstream"], tp["downstream_stage"])["model"], ctx.device)
    if up.implants or down.implants:
        raise Unsupported("transplants combine compact (implant-free) models of one architecture")
    if architecture_hash(up) != architecture_hash(down):
        raise Unsupported("upstream and downstream models have different architectures")
    # both rebuilt on one template graph so that the cut is the same node in both
    tmpl = down.clone(share_params=False)
    upg = down.clone(share_params=False)
    transfer_by_architecture(up, upg)
    cut = E.cut_at(tmpl, tp["cut_kind"], tp["cut_where"])
    src = cut.source
    up_nodes = _upstream_nodes(tmpl, src)
    batch = cfg["train"]["eval_batch"]
    parts = list(cfg["eval"]["partitions"]) + [p for p in bundle.extra if p not in cfg["eval"]["partitions"]]
    rows = {}

    saved = {}

    def record(name, g):
        # every row is a saved, reloadable model (V3-10): checkpoint transplant_<name>, evaluated from the file
        stage = f"transplant_{name}"
        ctx.save_ckpt(stage, g)
        gl = GraphNet.from_checkpoint(ctx.load_ckpt(stage)["model"], ctx.device)
        res, _ = C.eval_log(ctx, gl, bundle, name, save_preds=True)
        rows[name] = {p: {k: v for k, v in m.items() if isinstance(v, (int, float))} for p, m in res.items()}
        for p, m in res.items():
            ctx.metric(name, p, "risk", M.headline(m, bundle.task), gl.structural_hash())
        saved[name] = {"checkpoint": stage, "param_hash": gl.param_hash(), "structural_hash": gl.structural_hash()}

    record("upstream", upg)
    record("downstream", tmpl)
    # direct transplant: upstream tensors for every node up to the cut
    direct = tmpl.clone(share_params=False)
    for nid in up_nodes:
        n = direct.nodes[nid]
        if n.pkey is not None:
            direct.mods[n.pkey].load_state_dict(upg.mods[upg.nodes[nid].pkey].state_dict())
    record("direct", direct)
    info = {"cut": src, "cut_kind": tp["cut_kind"], "cut_where": tp["cut_where"], "align": tp["align"],
            "n_upstream_param_nodes": sum(1 for n in up_nodes if tmpl.nodes[n].pkey is not None)}
    best = direct
    if tp["align"] != "none":
        n = min(int(cfg["eval"]["calib_size"]), len(bundle.train))
        X = {k: v[:n] for k, v in bundle.train.X.items()}
        Zs, Zt = _cut_values(upg, X, src), _cut_values(tmpl, X, src)
        image = Zs.dim() == 4                                 # (N, C, H, W): one alignment per spatial position
        if bundle.layout != "vec":
            Zs = Zs.movedim(1, -1).reshape(-1, Zs.shape[1]) if Zs.dim() == 4 else Zs.reshape(-1, Zs.shape[-1])
            Zt = Zt.movedim(1, -1).reshape(-1, Zt.shape[1]) if Zt.dim() == 4 else Zt.reshape(-1, Zt.shape[-1])
        al, ainfo = fit_alignment(tp["align"], Zs, Zt, image=image)
        info["alignment"] = ainfo
        info["calibration_inputs"] = {"partition": "train", "first_n": n}
        aligned = direct.clone(share_params=False)
        mt, margs = alignment_spec(al)
        attrs = {"module_type": mt, "module_args": margs, "dim": aligned.node_dim(src)}
        for k in ("hw", "T", "layout"):
            if k in aligned.nodes[src].attrs:
                attrs[k] = aligned.nodes[src].attrs[k]
        dt = next(upg.parameters()).dtype
        nid = aligned.add_node("module", [src], attrs, role="alignment", module=al.to(device=ctx.device, dtype=dt))
        aligned.replace_uses(src, nid, exclude={nid})
        aligned._plan = None
        record("aligned", aligned)
        best = aligned
    if tp["bn_recalibrate"]:
        rec = best.clone(share_params=False)
        n = min(int(cfg["eval"]["calib_size"]), len(bundle.train))
        X = {k: v[:n] for k, v in bundle.train.X.items()}
        down_nodes = set(rec.live_nodes()) - up_nodes
        info["bn_recalibrated_modules"] = recalibrate_bn(rec, X, down_nodes)
        record("bn_recalibrated", rec)
    info["saved_models"] = saved
    out = {"info": info, "rows": rows}
    ctx.save_json("transplant_result.json", out)
    part = "test" if "test" in parts else parts[0]
    return {"cut": src, "align": tp["align"],
            "risk": {k: (M.headline(v[part], bundle.task) if part in v else None) for k, v in rows.items()}}


# ============================================================================= v5 grid (P5)

def _adapter_node(g: GraphNet, src: str, al: nn.Module, device, dtype) -> str:
    mt, margs = alignment_spec(al)
    attrs = {"module_type": mt, "module_args": margs, "dim": g.node_dim(src)}
    for k in ("hw", "T", "layout"):
        if k in g.nodes[src].attrs:
            attrs[k] = g.nodes[src].attrs[k]
    nid = g.add_node("module", [src], attrs, role="alignment", module=al.to(device=device, dtype=dtype))
    g.replace_uses(src, nid, exclude={nid})
    g._plan = None
    return nid


def _finite_number(v) -> bool:
    try:
        return math.isfinite(float(v))
    except (TypeError, ValueError):
        return False


def assembly_eligibility(info: dict, model: Optional[GraphNet], preds: Optional[dict], metrics: Optional[dict]) -> dict:
    """Eligibility of one transplant assembly (also used on historical results, where model / preds may be
    None and values may be serialised strings such as 'nan')."""
    reasons = []
    if info.get("fit_status", "ok") != "ok":
        reasons.append(f"fit failed: {info.get('fit_error')}")
    if info.get("diverged"):
        reasons.append(f"adapter fit diverged: {info.get('diverged_reason')}")
    if model is not None:
        if not all(bool(torch.isfinite(t).all()) for t in model.state_dict().values() if t.is_floating_point()):
            reasons.append("non-finite parameters or buffers")
    if preds is not None:
        for p, t in preds.items():
            if torch.is_tensor(t) and t.is_floating_point() and not bool(torch.isfinite(t).all()):
                reasons.append(f"non-finite predictions on {p}")
    if metrics is None:
        reasons.append("no metrics")
    else:
        for p, m in metrics.items():
            for k, v in (m or {}).items():
                if not _finite_number(v):
                    reasons.append(f"non-finite metric {p}.{k}")
                    break
    return {"eligible": not reasons, "reasons": reasons}


def run_transplant_grid(ctx) -> dict:
    """Mechanism C, v5: models A (role upstream / stage upstream_stage, e.g. the pre-cycle f0) and B
    (role downstream, e.g. the post-cycle model) of one architecture, cut at one node.  For every
    upstream in {A, B}, downstream in {A, B} and adapter family f, the combined model u_up -> adapter_f
    -> d_down is saved, reloaded and evaluated on every partition (challenge partitions included).
    Adapters: identity | orthogonal (centred Procrustes) | affine | mlp (residual, activation matching,
    transplant.adapter_updates steps) | affine_task / mlp_task (initialised at the identity, trained
    with the task loss through the frozen network for adapter_updates updates).  Every combination
    gets the SAME family and budget, so the reference (A up, A down) also carries an adapter.
    Reported contrasts per family:
      new_upstream_gain_on_old_downstream = R(A up, A down, f) - R(B up, A down, f)
      new_downstream_gain_with_old_upstream = R(A up, A down, f) - R(A up, B down, f)
    Positive values favour B.  Affine rescue measures compatibility under that adapter family; a
    private convention can itself be an affine (or orthogonal) map, and a failed rescue can come from
    fitting, conditioning, nonlinear coordinates or normalisation as well as missing information.
    Adapter parameters are reported and never credited to the backbone."""
    from ..cop_pegs.transplant import fit_orthogonal_alignment, fit_mlp_alignment, AffineAlignment, \
        ResidualMLPAlignment, IdentityAlignment
    from ..train.trainer import Segment, Trainer
    from ..config import seed_of
    from ..utils import torch_gen
    cfg = ctx.cfg
    tp = cfg["transplant"]
    bundle = C.setup_data(ctx)
    A = GraphNet.from_checkpoint(ctx.parent_ckpt(tp["upstream"], tp["upstream_stage"])["model"], ctx.device)
    Bm = GraphNet.from_checkpoint(ctx.parent_ckpt(tp["downstream"], tp["downstream_stage"])["model"], ctx.device)
    if A.implants or Bm.implants:
        raise Unsupported("transplants combine compact (implant-free) models of one architecture")
    if architecture_hash(A) != architecture_hash(Bm):
        raise Unsupported("the two models have different architectures")
    tmpl = A.clone(share_params=False)
    models = {"A": tmpl, "B": A.clone(share_params=False)}
    transfer_by_architecture(Bm, models["B"])
    cut = E.cut_at(tmpl, tp["cut_kind"], tp["cut_where"])
    src = cut.source
    up_nodes = _upstream_nodes(tmpl, src)
    n = min(int(cfg["eval"]["calib_size"]), len(bundle.train))
    X = {k: v[:n] for k, v in bundle.train.X.items()}
    image = bundle.layout == "img"
    dt = next(tmpl.parameters()).dtype

    def flat(z):
        return z.movedim(1, -1).reshape(-1, z.shape[1]) if z.dim() == 4 else z.reshape(-1, z.shape[-1])
    Z = {k: _cut_values(m, X, src) for k, m in models.items()}
    rows, saved, fits, assemblies = {}, {}, {}, {}
    work_updates = 0
    for u in ("A", "B"):
        for d in ("A", "B"):
            base = models[d].clone(share_params=False)
            for nid in up_nodes:
                nn_ = base.nodes[nid]
                if nn_.pkey is not None:
                    base.mods[nn_.pkey].load_state_dict(models[u].mods[models[u].nodes[nid].pkey].state_dict())
            for fam in tp["align_families"]:
                key = f"{u}up_{d}down_{fam}"
                gen = torch_gen(seed_of(cfg, "assembly"), "assembly", "transplant", key)
                info: dict = {"kind": fam}
                try:
                    if fam == "identity":
                        al, info = IdentityAlignment(image), {"kind": "identity", "params": 0}
                    elif fam == "orthogonal":
                        al, info = fit_orthogonal_alignment(flat(Z[u]), flat(Z[d]), image=image)
                    elif fam == "affine":
                        from ..cop_pegs.transplant import fit_affine_alignment
                        al, info = fit_affine_alignment(flat(Z[u]), flat(Z[d]), image=image)
                    elif fam == "mlp":
                        al, info = fit_mlp_alignment(flat(Z[u]), flat(Z[d]), cfg["train"],
                                                     int(tp["adapter_updates"]), gen, image=image)
                        work_updates += int(tp["adapter_updates"])
                    else:                                       # task-trained adapters, identity initialisation
                        k_ = base.node_dim(src)
                        devs = [torch.cuda.current_device()] if torch.cuda.is_available() else []
                        with torch.random.fork_rng(devices=devs):     # default inits draw from the global RNG
                            torch.manual_seed(int(torch.randint(0, 2 ** 31 - 1, (1,), generator=gen)))
                            if fam == "affine_task":
                                al = AffineAlignment(k_, k_, image)
                                with torch.no_grad():
                                    al.lin.weight.copy_(torch.eye(k_))
                                    al.lin.bias.zero_()
                            else:
                                al = ResidualMLPAlignment(k_, k_, image)
                        info = {"kind": fam, "objective": "task loss through the frozen network",
                                "updates": int(tp["adapter_updates"])}
                    g = base.clone(share_params=False)
                    nid = _adapter_node(g, src, al, ctx.device, dt)
                    if fam.endswith("_task"):
                        tcfg = {**cfg["train"], "bn_stats": "frozen"}
                        trn = Trainer(g, bundle, tcfg, C.seeds(cfg), ctx.device, ctx.log, f"transplant_{key}")
                        trn.configure("none", None, reset_state=True)
                        trn.run(Segment("adapter_fit", int(tp["adapter_updates"]), trainable={g.nodes[nid].pkey}))
                        info["diverged"] = bool(trn.state.get("diverged"))
                        if info["diverged"]:
                            info["diverged_reason"] = trn.state.get("diverged_reason")
                        info["updates_done"] = int(trn.state["global_step"])
                        work_updates += int(trn.state["global_step"])
                    info["params"] = int(sum(p_.numel() for p_ in g.mods[g.nodes[nid].pkey].parameters())) \
                        if g.nodes[nid].pkey else 0
                    if fam in ("orthogonal", "affine"):
                        info["params"] = int(g.mods[g.nodes[nid].pkey].n_params())
                    if tp["bn_recalibrate"]:
                        down_nodes = set(g.live_nodes()) - up_nodes
                        info["bn_recalibrated_modules"] = recalibrate_bn(g, X, down_nodes)
                    info["fit_status"] = "ok"
                except Exception as ex:                          # a failed fit is recorded, not fatal
                    info.update({"fit_status": "failed", "fit_error": f"{type(ex).__name__}: {ex}"})
                    fits[key] = info
                    assemblies[key] = {"eligible": False, "reasons": [f"fit failed: {info['fit_error']}"]}
                    rows[key] = None
                    continue
                fits[key] = info
                stage = f"transplant_{key}"
                ctx.save_ckpt(stage, g)
                gl = GraphNet.from_checkpoint(ctx.load_ckpt(stage)["model"], ctx.device)
                res, preds = C.eval_log(ctx, gl, bundle, key, save_preds=True)
                rows[key] = {p: {k: v for k, v in m.items() if isinstance(v, (int, float))} for p, m in res.items()}
                saved[key] = {"checkpoint": stage, "param_hash": gl.param_hash(), "structural_hash": gl.structural_hash()}
                assemblies[key] = assembly_eligibility(info, gl, preds, rows[key])
    parts = sorted({p for r in rows.values() if r for p in r})
    contrasts, ce = {}, {}
    for fam in tp["align_families"]:
        c = {}
        keys = {r: f"{r}_{fam}" for r in ("Aup_Adown", "Bup_Adown", "Aup_Bdown", "Bup_Bdown")}
        for p in parts:
            def R(k):
                if not assemblies.get(k, {}).get("eligible"):
                    return None                                 # an ineligible assembly never enters a contrast
                m = (rows.get(k) or {}).get(p)
                return None if m is None else M.headline(m, bundle.task)
            ra, rb_ab, ra_b, rbb = (R(keys[r]) for r in ("Aup_Adown", "Bup_Adown", "Aup_Bdown", "Bup_Bdown"))
            bad = sorted(k for k in keys.values() if not assemblies.get(k, {}).get("eligible"))
            # numbers only here (null where an assembly is ineligible); eligibility is kept beside them
            c[p] = {"new_upstream_gain_on_old_downstream": None if None in (ra, rb_ab) else ra - rb_ab,
                    "new_downstream_gain_with_old_upstream": None if None in (ra, ra_b) else ra - ra_b,
                    "R_A": ra, "R_B": rbb, "R_Bup_Adown": rb_ab, "R_Aup_Bdown": ra_b}
            ce.setdefault(fam, {})[p] = {"eligible": not bad, "ineligible_assemblies": bad,
                                         "reasons": {k: assemblies.get(k, {}).get("reasons", ["missing"]) for k in bad}}
        contrasts[fam] = c
    n_bad = sum(not a_["eligible"] for a_ in assemblies.values())
    if n_bad:
        ctx.unverified(f"transplant grid: {n_bad} of {len(assemblies)} assemblies ineligible "
                       f"({sorted(k for k, a_ in assemblies.items() if not a_['eligible'])[:8]})")
    ctx.count_work("diagnostic:transplant_adapters", updates=work_updates)
    info = {"design": "grid", "cut": src, "cut_kind": tp["cut_kind"], "cut_where": tp["cut_where"],
            "models": {"A": {"role": tp["upstream"], "stage": tp["upstream_stage"]},
                       "B": {"role": tp["downstream"], "stage": tp["downstream_stage"]}},
            "families": list(tp["align_families"]), "adapter_updates": int(tp["adapter_updates"]),
            "calibration_inputs": {"partition": "train", "first_n": n}, "fits": fits, "saved_models": saved,
            "assemblies": assemblies, "n_ineligible_assemblies": n_bad,
            "eligibility_rule": "an assembly is eligible when its fit succeeded, it did not diverge, its parameters "
                                "and buffers are finite, and its predictions and metrics are finite on every "
                                "partition; a contrast is computed only when every assembly it uses is eligible",
            "n_upstream_param_nodes": sum(1 for n_ in up_nodes if tmpl.nodes[n_].pkey is not None),
            "interpretation": "compatibility under each adapter family, at matched family and budget; not a "
                              "feature-versus-convention identification"}
    out = {"info": info, "rows": rows, "contrasts": contrasts, "contrast_eligibility": ce}
    ctx.save_json("transplant_result.json", out)
    return {"design": "grid", "families": list(tp["align_families"])}
