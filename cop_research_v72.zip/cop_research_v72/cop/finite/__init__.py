"""Finite certificates (R3) and finite transition systems (I5).

Entry point: run_finite_job(cfg, out_dir).  Every certificate is checked by
the independent checker in cop/finite/checker.py, whose verdict is recorded
next to (not inside) the certificate.
"""
from __future__ import annotations

import copy
import json
import time
from pathlib import Path
from typing import Any

from ..utils import atomic_write_json
from .certificate import make_certificate, write_certificate, PROOF_STATUSES
from . import boolean, rank, message, piecewise, transition
from .checker import verify_certificate

FINITE_DEFAULTS: dict[str, Any] = {
    "kind": None,                     # 'boolean_class' | 'rank' | 'message' | 'piecewise' | 'transition'
    "time_budget_s": 600.0,
    "boolean_class": {
        "n_inputs": 2,
        "target": "xor",              # named target or explicit 0/1 truth table of length 2^n (index i: x_j = bit j of i)
        "hidden_widths": [],
        "weight_set": [-1, 0, 1],
        "tolerance_errors": 0,
        "max_members": 5_000_000,
        "stop_at_witness": False,
    },
    "rank": {
        "mode": "exact",              # 'exact' | 'approx'
        "matrix": None,               # explicit integer/rational matrix, or None to generate
        "rows": 6, "cols": 6, "true_rank": 3, "seed": 0,
        "bottleneck": 2,
        "tolerance": 0.0,             # approx mode: squared Frobenius error tolerance
        "exact_max_dim": 8,
        "interval_eps": "1/1000000",
    },
    "message": {
        "n_bits": 3,
        "k_bits": 2,
        "tolerance_errors": 0,
        "max_encoders": 2_000_000,
        "query_timing": "after",       # after: encoder sees x only (delayed query) | before: encoder sees (x, q)
    },
    "piecewise": {
        "points": [0, 1, 2, 3],
        "values": [0, 1, 0, 1],
        "left_slope": 0,
        "right_slope": 0,
        "width": 3,
        "tolerance": 0,
    },
    "transition": {
        "system": "permutation_chain",    # 'permutation_chain' | 'absorbing_toy' | 'quantized_chain' | 'table'
        "params": {},
        "state_cap": 200_000,
        "exact_max_transient": 80,
        "long_time_threshold": 1000.0,
        "simple_threshold": None,
        "export_graph_max_states": 20000,
    },
}

KINDS = ("boolean_class", "rank", "message", "piecewise", "transition")


def resolve_finite_config(cfg: dict) -> dict:
    cfg = dict(cfg)
    unknown = set(cfg) - set(FINITE_DEFAULTS)
    if unknown:
        raise ValueError(f"unknown finite-job keys: {sorted(unknown)}")
    kind = cfg.get("kind")
    if kind not in KINDS:
        raise ValueError(f"finite job 'kind' must be one of {KINDS}, got {kind!r}")
    out = {"kind": kind, "time_budget_s": float(cfg.get("time_budget_s", FINITE_DEFAULTS["time_budget_s"]))}
    sec = copy.deepcopy(FINITE_DEFAULTS[kind])
    given = cfg.get(kind, {}) or {}
    bad = set(given) - set(sec)
    if bad:
        raise ValueError(f"unknown keys in finite '{kind}' section: {sorted(bad)}")
    sec.update(copy.deepcopy(given))
    for other in KINDS:
        if other != kind and cfg.get(other):
            raise ValueError(f"section {other!r} given for a {kind!r} job")
    out[kind] = sec
    return out


def _boolean(c: dict, deadline: float) -> list[dict]:
    n = int(c["n_inputs"])
    tgt = boolean.named_target(c["target"], n) if isinstance(c["target"], str) else [int(v) for v in c["target"]]
    r = boolean.enumerate_class(n, c["hidden_widths"], c["weight_set"], tgt, int(c["tolerance_errors"]),
                                c["max_members"], deadline, bool(c["stop_at_witness"]))
    cert = make_certificate(
        ctype="boolean_class", status=r["status"],
        domain={"type": "complete_boolean_cube", "n_inputs": n, "index_convention": "x_j = (i >> j) & 1",
                "size": 2 ** n},
        cls={"family": "threshold_network", "unit": "step(z) = 1[z > 0]", "hidden_widths": list(c["hidden_widths"]),
             "output_units": 1, "weight_set": r["weight_set"], "n_params": r["n_params"],
             "param_order": "per layer: W row-major (out,in) then b; member index digits base |S| LSB first",
             "class_size": r["total"]},
        tolerance={"max_error_count": int(c["tolerance_errors"])}, precision="exact_integer",
        coverage={"method": "enumeration", "examined": r["examined"], "total": r["total"], "complete": r["complete"],
                  "timed_out": r["timed_out"]},
        scope="Statement covers only this class (architecture, finite weight set, step convention) on the complete "
              "Boolean domain; it says nothing about real-valued weights or other architectures.",
        witness=r["witness"],
        data={"target": tgt, "min_error_examined": r["min_error_examined"], "min_error_exact": r["min_error_exact"],
              "n_members_meeting_tolerance_examined": r["n_members_meeting_tolerance_examined"]})
    return [cert]


def _rank(c: dict, deadline: float) -> list[dict]:
    M = c["matrix"]
    if M is None:
        M = rank.random_integer_rank_matrix(int(c["rows"]), int(c["cols"]), int(c["true_rank"]), int(c["seed"]))
    k = int(c["bottleneck"])
    m, n = len(M), len(M[0])
    cls = {"family": "linear_bottleneck", "map": "x -> A B x", "A_shape": [m, k], "B_shape": [k, n],
           "weights": "real", "biases": "none (homogeneous target)"}
    if c["mode"] == "exact":
        d = rank.rank_exact_certificate_data(M, k)
        st = d.pop("status")
        wit = d.pop("witness", None)
        return [make_certificate(
            ctype="rank_exact", status=st,
            domain={"type": "all of R^n", "n": n, "target": "y = M x", "M": [[str(v) for v in r] for r in M]},
            cls=cls, tolerance={"exact_equality": True}, precision="exact_rational",
            coverage={"method": "theorem_rank", "complete": st != "unsupported"},
            scope="Exact representability of the linear map M by any real rank-k factorisation.",
            witness=wit, data=d)]
    d = rank.rank_approx_certificate_data(M, k, float(c["tolerance"]), int(c["exact_max_dim"]), str(c["interval_eps"]))
    st = d.pop("status")
    wit = d.pop("witness", None)
    return [make_certificate(
        ctype="rank_approx", status=st,
        domain={"type": "R^n with E[x x^T] = I (e.g. x ~ N(0, I))", "n": n, "target": "y = M x",
                "M": [[str(v) for v in r] for r in M], "noise": "excluded"},
        cls=cls, tolerance={"max_expected_sq_error": float(c["tolerance"])}, precision=d["precision"],
        coverage={"method": "eckart_young_theorem", "complete": True},
        scope="Lower bound on min over the class of ||M - AB||_F^2 = E||Mx - ABx||^2 under E[xx^T] = I.",
        witness=wit, data=d)]


def _message_query_before(c: dict) -> list[dict]:
    """Query disclosed BEFORE encoding: the encoder maps (x, q) to a message.  With k >= 1 the
    encoder z = x_q and decoder d(z, q) = z have zero errors (witness).  With k = 0 there is one
    encoder; the decoder sees only q, so each q costs min(#ones, #zeros) = 2^(n-1) errors: the
    complete class is examined and the minimum is n * 2^(n-1)."""
    n, k, tol = int(c["n_bits"]), int(c["k_bits"]), int(c["tolerance_errors"])
    N, M = 2 ** n, 2 ** k
    domain = {"type": "complete", "x": f"{{0,1}}^{n}", "q": f"{{0..{n - 1}}}", "target": "x_q", "size": n * N,
              "n_bits": n}
    cls = {"encoder": f"any map ({{0,1}}^{n}, q) -> {{0..{M - 1}}} (k = {k} bits)",
           "decoder": "any map (message, q) -> {0,1}", "k_bits": k, "query_timing": "before",
           "restriction": "the encoder sees x and q; the decoder never sees x"}
    if k >= 1:
        enc = [((i >> q) & 1) for i in range(N) for q in range(n)]          # index i * n + q
        dec = [[m if m < 2 else 0 for _ in range(n)] for m in range(M)]
        status, witness = ("witness_found" if 0 <= tol else "no_certificate"), {"encoder": enc, "decoder": dec,
                                                                                "errors": 0}
        data = {"min_errors_examined": 0, "min_errors_exact": True}
        cov = {"method": "construction", "complete": True}
    else:
        best = n * (N // 2)
        status = "certified_no_member" if best > tol else "witness_found"
        witness = None if best > tol else {"encoder": [0] * (N * n), "decoder": [[0] * n], "errors": best}
        data = {"min_errors_examined": best, "min_errors_exact": True}
        cov = {"method": "enumeration", "examined": 1, "total": 1, "complete": True, "timed_out": False}
    return [make_certificate(
        ctype="message", status=status, domain=domain, cls=cls, tolerance={"max_error_count": tol},
        precision="exact_integer", coverage=cov,
        scope="Full-domain query-before-encoding task: the question is available to the encoder.",
        witness=witness, data=data)]


def _message(c: dict, deadline: float) -> list[dict]:
    if c.get("query_timing", "after") == "before":
        return _message_query_before(c)
    if c.get("query_timing", "after") != "after":
        raise ValueError("message.query_timing must be 'after' or 'before'")
    n, k, tol = int(c["n_bits"]), int(c["k_bits"]), int(c["tolerance_errors"])
    lb = message.analytic_lower_bound(n, k)
    r = message.enumerate_min_errors(n, k, tol, c["max_encoders"], deadline)
    domain = {"type": "complete", "x": f"{{0,1}}^{n}", "q": f"{{0..{n - 1}}}", "target": "x_q", "size": n * 2 ** n,
              "n_bits": n}
    cls = {"encoder": f"any map {{0,1}}^{n} -> {{0..{2 ** k - 1}}} (k = {k} bits)",
           "decoder": "any map (message, q) -> {0,1}", "k_bits": k, "query_timing": "after",
           "restriction": "encoder never sees q; decoder never sees x"}
    certs = []
    if r["witness"] is not None:
        st = "witness_found"
    elif r["complete"]:
        st = "certified_no_member"
    else:
        st = "incomplete"
    certs.append(make_certificate(
        ctype="message", status=st, domain=domain, cls=cls, tolerance={"max_error_count": tol},
        precision="exact_integer",
        coverage={"method": "enumeration", "examined": r["examined"], "total": r["total"], "complete": r["complete"],
                  "timed_out": r["timed_out"]},
        scope="Full-domain delayed-query task under the stated communication restriction only.",
        witness=r["witness"],
        data={"min_errors_examined": r["min_errors_examined"], "min_errors_exact": r["min_errors_exact"],
              "min_error_encoder": r["min_error_encoder"], "analytic_lower_bound": lb}))
    certs.append(make_certificate(
        ctype="message", status="certified_lower_bound" if lb > tol else "no_certificate", domain=domain, cls=cls,
        tolerance={"max_error_count": tol}, precision="exact_integer",
        coverage={"method": "analytic", "complete": True},
        scope="Analytic bound: blocks of s distinct inputs vary in >= ceil(log2 s) coordinates, each costing >= 1 error.",
        data={"analytic_lower_bound": lb, "pigeonhole_zero_error_impossible": 2 ** n > 2 ** k}))
    return certs


def _piecewise(c: dict, deadline: float) -> list[dict]:
    d = piecewise.piecewise_certificate_data(c["points"], c["values"], c["left_slope"], c["right_slope"],
                                            int(c["width"]), c["tolerance"])
    st = d.pop("status")
    wit = d.pop("witness", None)
    return [make_certificate(
        ctype="piecewise", status=st,
        domain={"type": "real_line", "target": "CPWL", "points": [str(v) for v in c["points"]],
                "values": [str(v) for v in c["values"]], "left_slope": str(c["left_slope"]),
                "right_slope": str(c["right_slope"])},
        cls={"family": "one_hidden_layer_relu", "form": "c + sum_j a_j relu(u_j x + b_j)", "width": int(c["width"]),
             "weights": "real"},
        tolerance={"exact_equality": True, "given": str(c["tolerance"])}, precision="exact_rational",
        coverage={"method": d.get("rule", "construction"), "complete": st != "unsupported"},
        scope="Exact representation on the whole real line only; approximation is not covered.",
        witness=wit, data=d)]


def _transition(c: dict, deadline: float) -> list[dict]:
    sys_ = transition.build_system(c["system"], dict(c["params"]))
    a = transition.analyze(sys_, int(c["state_cap"]), deadline, int(c["exact_max_transient"]),
                           float(c["long_time_threshold"]), c["simple_threshold"], int(c["export_graph_max_states"]))
    st = "complete_analysis" if a["complete"] else "incomplete"
    graph = a.pop("graph")
    return [make_certificate(
        ctype="transition", status=st,
        domain={"type": "reachable_state_space", "n_states": a["n_states"], "state_cap": a["state_cap"]},
        cls={"system": a["system"], "simple_threshold_override": c["simple_threshold"],
             "state_cap": int(c["state_cap"]), "long_time_threshold": float(c["long_time_threshold"])},
        edit_rules=a["system"], tolerance=None,
        precision=f"exact_rational graph; hitting={a.get('hitting_arithmetic')}; time={a.get('time_arithmetic')}",
        coverage={"method": "bfs", "complete": a["complete"], "examined": a["n_states"],
                  "incomplete_reason": a["incomplete_reason"]},
        scope="Statements apply to this finite stochastic process only; they do not transfer to SGD or to "
              "biological evolution without a separate argument.",
        data={**a, "graph": graph})]


def run_finite_job(cfg: dict, out_dir: str | Path) -> dict:
    cfg = resolve_finite_config(cfg)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    deadline = t0 + cfg["time_budget_s"]
    kind = cfg["kind"]
    fn = {"boolean_class": _boolean, "rank": _rank, "message": _message, "piecewise": _piecewise,
          "transition": _transition}[kind]
    certs = fn(cfg[kind], deadline)
    summary: dict[str, Any] = {"config": cfg, "elapsed_s": None, "certificates": []}
    for i, cert in enumerate(certs):
        path = write_certificate(cert, out_dir / f"certificate_{kind}_{i}.json")
        verdict = verify_certificate(str(path))
        if kind == "message" and verdict["verdict"] != "rejected":
            with open(path) as f_:
                got_c = json.load(f_)
            want_c = (int(cfg[kind]["n_bits"]), int(cfg[kind]["k_bits"]), cfg[kind].get("query_timing", "after"))
            if (int(got_c["domain"]["n_bits"]), int(got_c["class"]["k_bits"]),
                    got_c["class"].get("query_timing", "after")) != want_c:
                verdict = {"ok": False, "verdict": "rejected", "reasons": ["certificate class differs from the job "
                                                                           "configuration"],
                           "checks": verdict.get("checks", {})}
        if kind == "transition" and verdict["verdict"] != "rejected":
            # the claimed class must be the configured one (the checker verifies claims against the class)
            c_ = cfg[kind]
            want = {"system": transition.build_system(c_["system"], dict(c_["params"])).spec(),
                    "simple_threshold_override": c_["simple_threshold"], "state_cap": int(c_["state_cap"]),
                    "long_time_threshold": float(c_["long_time_threshold"])}
            want = json.loads(json.dumps(want))
            with open(path) as f_:
                got = json.load(f_)["class"]
            if got != want:
                verdict = {"ok": False, "verdict": "rejected", "reasons": ["certificate class differs from the job "
                                                                           "configuration"],
                           "checks": verdict.get("checks", {})}
        summary["certificates"].append({"path": str(path), "type": cert["type"], "status": cert["status"],
                                        "is_proof_status": cert["status"] in PROOF_STATUSES,
                                        "independent_check": verdict})
    summary["elapsed_s"] = time.time() - t0
    summary["all_checks_ok"] = all(c["independent_check"]["ok"] for c in summary["certificates"])
    verdicts = [c["independent_check"]["verdict"] for c in summary["certificates"]]
    summary["validity"] = "invalid" if "rejected" in verdicts else ("valid" if summary["all_checks_ok"] else "unverified")
    atomic_write_json(out_dir / "summary.json", summary)
    return summary


def run_finite_ctx(ctx) -> dict:
    """Runner entry: a rejected certificate makes the job 'invalid'; a
    certificate whose claims could not all be checked makes it 'unverified'."""
    from ..experiments.context import ScientificInvalid
    s = run_finite_job(ctx.cfg["finite"], ctx.dir / "finite")
    bad = [c for c in s["certificates"] if c["independent_check"]["verdict"] == "rejected"]
    if bad:
        raise ScientificInvalid("independent checker rejected a certificate",
                                {"rejected": [{"path": c["path"], "reasons": c["independent_check"]["reasons"]}
                                              for c in bad]})
    for c in s["certificates"]:
        if not c["independent_check"]["ok"]:
            ctx.unverified(f"{c['type']} {c['status']}: {c['independent_check']['verdict']}: "
                           f"{'; '.join(c['independent_check']['reasons'])[:300]}")
    return {k: v for k, v in s.items() if k != "config"}


__all__ = ["FINITE_DEFAULTS", "resolve_finite_config", "run_finite_job", "verify_certificate",
           "boolean", "rank", "message", "piecewise", "transition"]
