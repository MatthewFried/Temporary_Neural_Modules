"""Exhaustive enumeration of small threshold-network classes on the complete Boolean domain (R3).

Conventions (also recorded in every certificate):
  * Domain: all x in {0,1}^n.  Domain index i encodes x_j = (i >> j) & 1.
  * Unit: out = step(w . h + b) with step(z) = 1 if z > 0 else 0 (strict).
  * Network: hidden layers of the stated widths, then one output unit.
  * Parameters: every weight and bias ranges over the stated finite integer set S.
  * Parameter vector order: for each layer, W in row-major (out, in), then b.
  * Member index m in [0, |S|^P): parameter p takes S[digit_p(m)], digits base |S|,
    least significant digit first.
  * Error of a member = number of domain points where its output differs from the
    target truth table.  A member meets tolerance t iff error <= t.
"""
from __future__ import annotations

import time
from typing import Sequence

import numpy as np

NAMED_TARGETS = ("and", "or", "xor", "parity", "majority", "first", "nand")


def domain_bits(n: int) -> np.ndarray:
    idx = np.arange(2 ** n, dtype=np.int64)
    return ((idx[:, None] >> np.arange(n, dtype=np.int64)) & 1).astype(np.int64)


def named_target(name: str, n: int) -> list[int]:
    X = domain_bits(n)
    s = X.sum(1)
    if name == "and":
        t = (s == n)
    elif name == "nand":
        t = (s != n)
    elif name == "or":
        t = (s > 0)
    elif name in ("xor", "parity"):
        t = (s % 2 == 1)
    elif name == "majority":
        t = (2 * s > n)
    elif name == "first":
        t = X[:, 0] == 1
    else:
        raise ValueError(f"unknown named target {name!r}; choose from {NAMED_TARGETS}")
    return [int(v) for v in t]


def layer_shapes(n: int, widths: Sequence[int]) -> list[tuple[int, int]]:
    sizes = [n] + list(widths) + [1]
    return [(sizes[i], sizes[i + 1]) for i in range(len(sizes) - 1)]


def n_params(n: int, widths: Sequence[int]) -> int:
    return sum((fi + 1) * fo for fi, fo in layer_shapes(n, widths))


def class_size(n: int, widths: Sequence[int], S: Sequence[int]) -> int:
    return len(S) ** n_params(n, widths)


def decode_members(idx: np.ndarray, P: int, S: np.ndarray) -> np.ndarray:
    """idx: (C,) int64 member indices -> (C, P) parameter values."""
    s = len(S)
    rem = idx.astype(np.int64).copy()
    digits = np.empty((idx.shape[0], P), dtype=np.int64)
    for p in range(P):
        digits[:, p] = rem % s
        rem //= s
    return S[digits]


def forward_batch(params: np.ndarray, X: np.ndarray, shapes: list[tuple[int, int]]) -> np.ndarray:
    """params (C,P), X (D,n) -> outputs (C,D) in {0,1}."""
    C = params.shape[0]
    h = np.broadcast_to(X[None], (C,) + X.shape)
    off = 0
    for fi, fo in shapes:
        W = params[:, off:off + fi * fo].reshape(C, fo, fi)
        off += fi * fo
        b = params[:, off:off + fo]
        off += fo
        z = np.einsum("cdi,coi->cdo", h, W) + b[:, None, :]
        h = (z > 0).astype(np.int64)
    return h[..., 0]


def params_to_layers(vec: Sequence[int], shapes: list[tuple[int, int]]) -> list[dict]:
    out, off = [], 0
    for fi, fo in shapes:
        W = [list(map(int, vec[off + r * fi: off + (r + 1) * fi])) for r in range(fo)]
        off += fi * fo
        b = list(map(int, vec[off:off + fo]))
        off += fo
        out.append({"W": W, "b": b})
    return out


def enumerate_class(n: int, widths: Sequence[int], weight_set: Sequence[int], target: Sequence[int],
                    tolerance_errors: int = 0, max_members: int | None = None, deadline: float | None = None,
                    stop_at_witness: bool = False, chunk: int = 1 << 15) -> dict:
    """Exhaustively evaluate members of the class in index order.

    Returns a dict with exact coverage accounting.  status is
    'witness_found' if any examined member meets tolerance,
    'certified_no_member' only if every member was examined and none met it,
    otherwise 'incomplete'.
    """
    S = np.array(sorted(set(int(v) for v in weight_set)), dtype=np.int64)
    if len(S) == 0:
        raise ValueError("empty weight set")
    target = np.asarray(target, dtype=np.int64)
    if target.shape != (2 ** n,):
        raise ValueError(f"target must have length 2^n = {2 ** n}")
    if not set(np.unique(target).tolist()) <= {0, 1}:
        raise ValueError("target must be 0/1")
    shapes = layer_shapes(n, widths)
    P = n_params(n, widths)
    total = len(S) ** P
    limit = total if max_members is None else min(total, int(max_members))
    if limit > np.iinfo(np.int64).max:
        limit = int(np.iinfo(np.int64).max)
    X = domain_bits(n)
    examined = 0
    min_err = None
    min_idx = None
    witness_idx = None
    n_witness = 0
    timed_out = False
    start = 0
    while start < limit:
        if deadline is not None and time.time() > deadline:
            timed_out = True
            break
        stop = min(limit, start + chunk)
        idx = np.arange(start, stop, dtype=np.int64)
        prm = decode_members(idx, P, S)
        out = forward_batch(prm, X, shapes)
        err = (out != target[None]).sum(1)
        examined += stop - start
        j = int(err.argmin())
        if min_err is None or int(err[j]) < min_err:
            min_err, min_idx = int(err[j]), int(idx[j])
        ok = np.nonzero(err <= tolerance_errors)[0]
        n_witness += int(ok.size)
        if ok.size and witness_idx is None:
            witness_idx = int(idx[ok[0]])
        start = stop
        if stop_at_witness and witness_idx is not None:
            break
    complete = examined == total
    if witness_idx is not None:
        status = "witness_found"
    elif complete:
        status = "certified_no_member"
    else:
        status = "incomplete"
    witness = None
    if witness_idx is not None:
        vec = decode_members(np.array([witness_idx]), P, S)[0]
        wout = forward_batch(vec[None], X, shapes)[0]
        witness = {"member_index": witness_idx, "params": [int(v) for v in vec],
                   "layers": params_to_layers(vec, shapes),
                   "errors": int((wout != target).sum()), "outputs": [int(v) for v in wout]}
    return {
        "status": status, "examined": int(examined), "total": int(total), "complete": bool(complete),
        "timed_out": timed_out, "min_error_examined": min_err, "min_error_member_index": min_idx,
        "min_error_exact": bool(complete), "n_members_meeting_tolerance_examined": n_witness,
        "witness": witness, "n_params": P, "weight_set": [int(v) for v in S], "shapes": shapes,
    }
