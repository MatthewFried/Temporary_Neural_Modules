"""Certificate schema shared by every finite certificate generator (R3, I5).

A certificate is a JSON-serialisable dict.  The guard `finalize_certificate`
is the single exit point used by all generators: a proof status with
incomplete coverage is downgraded to 'incomplete' (and the downgrade is
recorded), so no proof label can ever leave the generator from a truncated
search or a timeout.
"""
from __future__ import annotations

import time
from fractions import Fraction
from pathlib import Path
from typing import Any

from ..utils import atomic_write_json, code_hash

CERT_VERSION = "1.0"

CERT_TYPES = ("boolean_class", "rank_exact", "rank_approx", "message", "piecewise", "transition")

STATUSES = (
    "witness_found",          # an explicit member meeting the criterion is exhibited and verified
    "certified_no_member",    # every member of the finite class (or an exact theorem) rules the criterion out
    "certified_lower_bound",  # a sound lower bound strictly exceeds the tolerance
    "complete_analysis",      # transition system: reachable state space enumerated completely
    "incomplete",             # budget, cap or timeout hit; no proof label
    "unsupported",            # no sound method implemented for this case
    "no_certificate",         # complete method ran but neither a witness nor a bound resolves the question
    "numerical_bound",        # floating-point bound with heuristic margin: evidence, not a proof label
)

PROOF_STATUSES = ("certified_no_member", "certified_lower_bound", "complete_analysis")


def _finite_code_hash() -> str:
    return code_hash(Path(__file__).resolve().parent)


def frac_str(x: Fraction | int) -> str:
    x = Fraction(x)
    return f"{x.numerator}/{x.denominator}" if x.denominator != 1 else str(x.numerator)


def parse_frac(s: Any) -> Fraction:
    if isinstance(s, Fraction):
        return s
    if isinstance(s, bool):
        raise TypeError("bool is not a rational")
    if isinstance(s, int):
        return Fraction(s)
    if isinstance(s, str):
        return Fraction(s)
    if isinstance(s, float):
        return Fraction(s)  # exact binary value of the float
    raise TypeError(f"cannot parse rational from {s!r}")


def make_certificate(*, ctype: str, status: str, domain: dict, cls: dict, tolerance: Any,
                     precision: str, coverage: dict, scope: str, edit_rules: Any = None,
                     witness: Any = None, data: Any = None, notes: list[str] | None = None) -> dict:
    if ctype not in CERT_TYPES:
        raise ValueError(f"unknown certificate type {ctype}")
    if status not in STATUSES:
        raise ValueError(f"unknown status {status}")
    for k in ("complete", "method"):
        if k not in coverage:
            raise ValueError(f"coverage must include {k!r}")
    cert = {
        "cert_version": CERT_VERSION,
        "type": ctype,
        "status": status,
        "domain": domain,
        "class": cls,
        "edit_rules": edit_rules,
        "tolerance": tolerance,
        "precision": precision,
        "coverage": coverage,
        "witness": witness,
        "data": data,
        "scope": scope,
        "notes": list(notes or []),
        "generator": {"package": "cop.finite", "code_hash": _finite_code_hash(), "created": time.time()},
    }
    return finalize_certificate(cert)


def finalize_certificate(cert: dict) -> dict:
    """Downgrade any proof status that lacks complete coverage."""
    if cert["status"] in PROOF_STATUSES and not bool(cert["coverage"].get("complete")):
        cert["notes"].append(f"status {cert['status']!r} downgraded to 'incomplete': coverage incomplete")
        cert["status"] = "incomplete"
    if cert["status"] == "witness_found" and cert.get("witness") is None:
        cert["notes"].append("status 'witness_found' downgraded: no witness attached")
        cert["status"] = "incomplete"
    return cert


def write_certificate(cert: dict, path: str | Path) -> Path:
    cert = finalize_certificate(cert)
    atomic_write_json(path, cert)
    return Path(path)
