"""Independent certificate checker.

This module deliberately imports nothing from the rest of cop.finite.  Every
check is re-implemented in a direct (slower) way:
  boolean_class  brute-force re-enumeration with itertools.product, pure Python
  rank_exact     fraction Gaussian elimination written here; exact witness product
  rank_approx    float64 SVD recomputation; for exact_rational_interval bounds the
                 lower endpoints are re-verified by Sylvester inertia counts
                 (signs of leading principal minors, exact fractions), which is a
                 different method from the generator's root isolation
  message        brute-force enumeration of all encoders with itertools.product;
                 analytic bound recomputed by a different recursion
  piecewise      slopes and knots recomputed; witness evaluated exactly; the
                 subset-sum condition re-checked by brute force
  transition     only the system specification is trusted: initial states,
                 the whole reachable space, complexity, loss, threshold,
                 labels (bottleneck paths), closed classes with contents
                 (Kosaraju), inevitability, P(hit)=1, hitting probabilities
                 and times (own elimination) are re-derived and compared

verify_certificate returns {'ok', 'verdict', 'reasons', 'checks'}; verdict is
'verified' (every claimed field checked; ok=True), 'partially_checked' (no
contradiction, some claimed fields not checkable; ok=False), 'unchecked' or
'rejected'.  'checks' says per field whether it was verified exactly or
numerically.
"""
from __future__ import annotations

import itertools
import json
import math
import random
from collections import deque
from fractions import Fraction
from pathlib import Path
from typing import Any

import numpy as np

PROOF = ("certified_no_member", "certified_lower_bound", "complete_analysis")
BRUTE_LIMIT = 400_000


class _Reject(Exception):
    pass


class _Unchecked(Exception):
    pass


def _req(cond: bool, msg: str):
    if not cond:
        raise _Reject(msg)


def _fr(s) -> Fraction:
    if isinstance(s, float):
        return Fraction(s)
    return Fraction(s)


# ---------------------------------------------------------------- boolean
def _step_net(params, n, widths, x):
    sizes = [n] + list(widths) + [1]
    h = list(x)
    off = 0
    for li in range(len(sizes) - 1):
        fi, fo = sizes[li], sizes[li + 1]
        W = params[off:off + fi * fo]
        off += fi * fo
        b = params[off:off + fo]
        off += fo
        h = [1 if sum(W[o * fi + i] * h[i] for i in range(fi)) + b[o] > 0 else 0 for o in range(fo)]
    return h[0]


def _decode_lsb(idx: int, P: int, S: list) -> list:
    """Member index -> parameters, digits base |S| least-significant first
    (the documented class enumeration order)."""
    out = []
    for _ in range(P):
        out.append(S[idx % len(S)])
        idx //= len(S)
    return out


def _check_boolean(c, fc):
    d, cls = c["domain"], c["class"]
    n = int(d["n_inputs"])
    widths = cls["hidden_widths"]
    S = sorted(cls["weight_set"])
    target = c["data"]["target"]
    tol = int(c["tolerance"]["max_error_count"])
    xs = [[(i >> j) & 1 for j in range(n)] for i in range(2 ** n)]
    sizes = [n] + list(widths) + [1]
    P = sum((sizes[i] + 1) * sizes[i + 1] for i in range(len(sizes) - 1))
    total = len(S) ** P
    _req(int(cls["class_size"]) == total, "class_size mismatch")
    _req(int(c["coverage"]["total"]) == total, "coverage total mismatch")
    examined = int(c["coverage"]["examined"])
    _req(0 <= examined <= total, "examined outside [0, total]")
    _req(bool(c["coverage"]["complete"]) == (examined == total), "coverage.complete inconsistent with examined")
    st = c["status"]
    _req(st in ("witness_found", "certified_no_member", "incomplete"), f"unexpected status {st}")
    if st == "witness_found":
        w = c["witness"]["params"]
        _req(len(w) == P and all(v in S for v in w), "witness parameters outside class")
        err = sum(_step_net(w, n, widths, x) != t for x, t in zip(xs, target))
        _req(err <= tol, f"witness has {err} errors > tolerance {tol}")
        _req(err == c["witness"]["errors"], "witness error count mismatch")
        idx = int(c["witness"]["member_index"])
        _req(_decode_lsb(idx, P, S) == list(w), "member_index does not decode to witness params")
        _req(idx < examined, "witness index outside the examined prefix")
        fc.ok("witness")
    if st == "certified_no_member":
        _req(c["coverage"]["complete"] and examined == total, "proof claim with incomplete coverage")
        if total > BRUTE_LIMIT:
            raise _Unchecked(f"class size {total} exceeds checker brute-force limit {BRUTE_LIMIT}")
    if st == "incomplete":
        _req(not c["data"].get("min_error_exact"), "incomplete enumeration claims an exact minimum")
    # statistics over the examined prefix (index order 0 .. examined-1), re-derived by brute force
    if examined > BRUTE_LIMIT:
        if st == "certified_no_member":
            raise _Unchecked(f"examined {examined} exceeds checker brute-force limit {BRUTE_LIMIT}")
        fc.skip("examined_prefix_statistics", f"examined {examined} > brute-force limit {BRUTE_LIMIT}")
        return
    errs = [sum(_step_net(_decode_lsb(i, P, S), n, widths, x) != t for x, t in zip(xs, target))
            for i in range(examined)]
    n_ok = sum(e <= tol for e in errs)
    if st == "certified_no_member":
        _req(n_ok == 0, "a member meets tolerance; certificate is false")
        fc.ok("no_member")
    if st == "incomplete":
        _req(n_ok == 0, "an examined member meets tolerance but no witness is reported")
    dd = c["data"]
    if dd.get("min_error_examined") is not None and errs:
        _req(int(dd["min_error_examined"]) == min(errs), "min error over the examined members mismatch")
    if "n_members_meeting_tolerance_examined" in dd:
        _req(int(dd["n_members_meeting_tolerance_examined"]) == n_ok, "number of members meeting tolerance mismatch")
    if dd.get("min_error_exact"):
        _req(examined == total, "exact minimum claimed without complete enumeration")
    fc.ok("examined_prefix_statistics")


# ---------------------------------------------------------------- rank
def _frac_rank(M):
    A = [row[:] for row in M]
    rows = len(A)
    cols = len(A[0]) if rows else 0
    rank = 0
    for c in range(cols):
        p = None
        for i in range(rank, rows):
            if A[i][c] != 0:
                p = i
                break
        if p is None:
            continue
        A[rank], A[p] = A[p], A[rank]
        for i in range(rank + 1, rows):
            if A[i][c] != 0:
                f = A[i][c] / A[rank][c]
                for j in range(c, cols):
                    A[i][j] -= f * A[rank][j]
        rank += 1
    return rank


def _frac_det(M):
    A = [row[:] for row in M]
    n = len(A)
    det = Fraction(1)
    for c in range(n):
        p = next((i for i in range(c, n) if A[i][c] != 0), None)
        if p is None:
            return Fraction(0)
        if p != c:
            A[c], A[p] = A[p], A[c]
            det = -det
        det *= A[c][c]
        for i in range(c + 1, n):
            f = A[i][c] / A[c][c]
            for j in range(c, n):
                A[i][j] -= f * A[c][j]
    return det


def _count_eigs_below(G, a: Fraction):
    """Number of eigenvalues (with multiplicity) of symmetric G strictly below a,
    via signs of leading principal minors of G - aI.  Returns None if a minor vanishes."""
    n = len(G)
    A = [[G[i][j] - (a if i == j else 0) for j in range(n)] for i in range(n)]
    prev = Fraction(1)
    changes = 0
    for k in range(1, n + 1):
        d = _frac_det([row[:k] for row in A[:k]])
        if d == 0:
            return None
        if (d > 0) != (prev > 0):
            changes += 1
        prev = d
    return changes


def _check_rank_exact(c, fc):
    M = [[_fr(v) for v in row] for row in c["domain"]["M"]]
    k = int(c["class"]["A_shape"][1])
    r = _frac_rank(M)
    d = c.get("data") or {}
    if "rank" in d:
        _req(int(d["rank"]) == r, f"claimed rank {d['rank']} != {r}")
    if "k" in d:
        _req(int(d["k"]) == k, "k mismatch")
    if "shape" in d:
        _req(list(d["shape"]) == [len(M), len(M[0])], "shape mismatch")
    if c["status"] == "certified_no_member":
        _req(r > k, f"rank {r} <= k {k}: impossibility claim false")
        if d.get("pivots") is not None:
            piv = list(d["pivots"])
            _req(len(piv) == r and _frac_rank([[row[j] for j in piv] for row in M]) == r, "pivot columns invalid")
        fc.ok("rank")
        return
    if c["status"] == "witness_found":
        A = [[_fr(v) for v in row] for row in c["witness"]["A"]]
        B = [[_fr(v) for v in row] for row in c["witness"]["B"]]
        _req(len(A) == len(M) and all(len(row) == k for row in A), "A shape")
        _req(len(B) == k and all(len(row) == len(M[0]) for row in B), "B shape")
        prod = [[sum((A[i][t] * B[t][j] for t in range(k)), Fraction(0)) for j in range(len(M[0]))] for i in range(len(M))]
        _req(prod == M, "A B != M exactly")
        fc.ok("witness")
        return
    if c["status"] == "unsupported":
        fc.ok("status_unsupported")
        return
    raise _Reject(f"unexpected status {c['status']}")


def _check_rank_approx(c, fc):
    M = [[_fr(v) for v in row] for row in c["domain"]["M"]]
    k = int(c["class"]["A_shape"][1])
    tol = float(c["tolerance"]["max_expected_sq_error"])
    Mf = np.array([[float(v) for v in row] for row in M])
    s = np.linalg.svd(Mf, compute_uv=False)
    tail = float(np.sum(s[k:] ** 2))
    data = c["data"]
    if "singular_values_float64" in data:
        sv = np.array(data["singular_values_float64"], dtype=np.float64)
        _req(sv.shape == s.shape and np.allclose(sv, s, rtol=1e-9, atol=1e-12), "singular values mismatch")
    if "tail_float64" in data:
        _req(abs(float(data["tail_float64"]) - tail) <= 1e-9 * max(1.0, tail), "tail mismatch")
    fc.ok("spectrum", "numerical")
    if c["status"] == "certified_lower_bound":
        lb = float(data["lower_bound"])
        _req(lb > tol, "lower bound does not exceed tolerance")
        if c["precision"] == "exact_rational_interval":
            m, n = len(M), len(M[0])
            dim = min(m, n)
            if m <= n:
                G = [[sum((M[i][t] * M[j][t] for t in range(n)), Fraction(0)) for j in range(m)] for i in range(m)]
            else:
                G = [[sum((M[t][i] * M[t][j] for t in range(m)), Fraction(0)) for j in range(n)] for i in range(n)]
            lows = sorted(_fr(v) for v in data["lower_endpoints_used"])
            _req(len(lows) == dim - k, "number of endpoints != dim - k")
            verified = []
            for j, a in enumerate(lows):  # claim: j-th smallest eigenvalue (0-based j) >= a
                if a <= 0:
                    verified.append(Fraction(0))
                    continue
                aa = a
                for _ in range(60):
                    cnt = _count_eigs_below(G, aa)
                    if cnt is not None:
                        break
                    aa = aa - abs(aa) / 1024
                else:
                    raise _Unchecked("could not find a non-singular test point")
                _req(cnt <= j, f"{cnt} eigenvalues below {aa}, so the {j + 1}-th smallest is below the claimed endpoint")
                verified.append(aa)
            lbv = sum(verified, Fraction(0))
            _req(lbv > Fraction(tol), f"independently verified bound {float(lbv)} does not exceed tolerance")
        else:
            raise _Reject("certified_lower_bound requires exact_rational_interval precision")
        _req(lb <= tail * (1 + 1e-9) + 1e-12, "lower bound exceeds float Eckart-Young value")
        fc.ok("lower_bound")
        return
    if c["status"] == "numerical_bound":
        _req(c["precision"] == "float64_with_margin", "numerical_bound must be float mode")
        lb = data.get("lower_bound")
        if lb is not None:
            _req(float(lb) <= tail * (1 + 1e-9) + 1e-12, "numerical lower bound exceeds the float Eckart-Young value")
        fc.ok("numerical_bound", "numerical")      # a numerical claim, verified numerically (not a proof label)
        return
    if c["status"] == "witness_found":
        A = [[Fraction(float(v)) for v in row] for row in c["witness"]["A"]]
        B = [[Fraction(float(v)) for v in row] for row in c["witness"]["B"]]
        _req(len(A) == len(M) and all(len(r) == k for r in A) and len(B) == k, "witness shapes")
        err = Fraction(0)
        for i in range(len(M)):
            for j in range(len(M[0])):
                pij = sum((A[i][t] * B[t][j] for t in range(k)), Fraction(0))
                err += (M[i][j] - pij) ** 2
        _req(err <= Fraction(tol), "witness error (exact rational evaluation) exceeds tolerance")
        fc.ok("witness")
        return
    if c["status"] in ("no_certificate", "unsupported"):
        fc.ok("status_" + c["status"])
        return
    raise _Reject(f"unexpected status {c['status']}")


# ---------------------------------------------------------------- message
def _msg_errors(enc, n, M):
    xs = [[(i >> j) & 1 for j in range(n)] for i in range(2 ** n)]
    err = 0
    for m in range(M):
        block = [xs[i] for i in range(2 ** n) if enc[i] == m]
        for q in range(n):
            ones = sum(x[q] for x in block)
            err += min(ones, len(block) - ones)
    return err


def _analytic_lb_rec(N, M):
    # different method: recursion over the largest block size, nonincreasing order
    from functools import lru_cache

    @lru_cache(maxsize=None)
    def f(rem, blocks, maxs):
        if rem == 0:
            return 0
        if blocks == 0:
            return 10 ** 9
        best = 10 ** 9
        for s in range(1, min(rem, maxs) + 1):
            best = min(best, (math.ceil(math.log2(s)) if s > 1 else 0) + f(rem - s, blocks - 1, s))
        return best
    return f(N, M, N)


def _check_message_before(c, fc):
    n = int(c["domain"]["n_bits"])
    M = 2 ** int(c["class"]["k_bits"])
    tol = int(c["tolerance"]["max_error_count"])
    N = 2 ** n
    xs = [[(i >> j) & 1 for j in range(n)] for i in range(N)]
    if c["status"] == "witness_found":
        enc, dec = c["witness"]["encoder"], c["witness"]["decoder"]
        _req(len(enc) == N * n and all(isinstance(e, int) and 0 <= e < M for e in enc), "witness encoder malformed")
        _req(len(dec) <= M and all(len(r) == n for r in dec), "witness decoder malformed")
        e = sum(dec[enc[i * n + q]][q] != xs[i][q] for i in range(N) for q in range(n))
        _req(e == c["witness"]["errors"] and e <= tol, "witness error mismatch")
        fc.ok("witness")
        if c["data"].get("min_errors_exact"):
            # an exact minimum is only claimed with a zero-error witness (zero is a lower bound)
            _req(e == 0 and int(c["data"]["min_errors_examined"]) == 0, "exact minimum claimed without proof")
            fc.ok("min_errors")
        return
    if c["status"] == "certified_no_member":
        _req(M == 1, "query-before proof claims are only issued for the single-message class")
        best = sum(min(sum(x[q] for x in xs), N - sum(x[q] for x in xs)) for q in range(n))
        _req(best > tol and best == int(c["data"]["min_errors_examined"]), "single-message minimum mismatch")
        fc.ok("no_member")
        return
    raise _Reject(f"unexpected status {c['status']} for a query-before certificate")


def _check_message(c, fc):
    if (c.get("class") or {}).get("query_timing", "after") == "before":
        _check_message_before(c, fc)
        return
    n = int(c["domain"]["n_bits"])
    M = 2 ** int(c["class"]["k_bits"])
    tol = int(c["tolerance"]["max_error_count"])
    N = 2 ** n
    lb = _analytic_lb_rec(N, M)
    if "analytic_lower_bound" in (c.get("data") or {}):
        _req(lb == int(c["data"]["analytic_lower_bound"]), f"analytic bound mismatch {lb}")
    if c["coverage"]["method"] == "analytic":
        if c["status"] == "certified_lower_bound":
            _req(lb > tol, "analytic bound does not exceed tolerance")
        else:
            _req(c["status"] == "no_certificate" and lb <= tol, f"status {c['status']} inconsistent with the bound")
        if "pigeonhole_zero_error_impossible" in c["data"]:
            _req(bool(c["data"]["pigeonhole_zero_error_impossible"]) == (N > M), "pigeonhole flag mismatch")
        fc.ok("analytic_bound")
        return
    total = M ** N
    _req(int(c["coverage"]["total"]) == total, "coverage total mismatch")
    if c["status"] == "witness_found":
        enc = c["witness"]["encoder"]
        _req(len(enc) == N and all(0 <= e < M for e in enc), "witness encoder malformed")
        e = _msg_errors(enc, n, M)
        _req(e <= tol and e == c["witness"]["errors"], "witness error mismatch")
        # decoder correctness: given decoder achieves the claimed errors
        dec = c["witness"]["decoder"]
        xs = [[(i >> j) & 1 for j in range(n)] for i in range(N)]
        e2 = sum(dec[enc[i]][q] != xs[i][q] for i in range(N) for q in range(n))
        _req(e2 == e, "explicit decoder does not attain the claimed errors")
        fc.ok("witness")
        if c["data"].get("min_errors_exact"):
            if total > BRUTE_LIMIT:
                fc.skip("min_errors", "encoder space too large for brute-force check")
            else:
                best = min(_msg_errors(x, n, M) for x in itertools.product(range(M), repeat=N))
                _req(best == c["data"]["min_errors_examined"], "min error mismatch")
                fc.ok("min_errors")
        return
    if c["status"] == "certified_no_member":
        _req(c["coverage"]["complete"] and int(c["coverage"]["examined"]) == total, "proof claim with incomplete coverage")
        if total > BRUTE_LIMIT:
            raise _Unchecked("encoder space too large for brute-force check")
        best = None
        best_enc = None
        for enc in itertools.product(range(M), repeat=N):
            e = _msg_errors(enc, n, M)
            if best is None or e < best:
                best, best_enc = e, enc
        _req(best > tol, "an encoder meets tolerance")
        _req(c["data"].get("min_errors_exact") is True and best == c["data"]["min_errors_examined"],
             "min error mismatch")
        if c["data"].get("min_error_encoder") is not None:
            _req(_msg_errors(c["data"]["min_error_encoder"], n, M) == best, "min_error_encoder does not attain the minimum")
        fc.ok("no_member")
        return
    if c["status"] == "incomplete":
        _req(not c["data"].get("min_errors_exact"), "incomplete enumeration claims an exact minimum")
        ex_ = int(c["coverage"]["examined"])
        if ex_ > BRUTE_LIMIT:
            fc.skip("examined_prefix_statistics", f"examined {ex_} > brute-force limit")
            return
        errs = [_msg_errors(_decode_lsb(i, N, list(range(M))), n, M) for i in range(ex_)]
        if errs and c["data"].get("min_errors_examined") is not None:
            _req(int(c["data"]["min_errors_examined"]) == min(errs), "min error over the examined prefix mismatch")
        _req(all(e > tol for e in errs), "an examined encoder meets tolerance but no witness is reported")
        fc.ok("examined_prefix_statistics")
        return
    raise _Reject(f"unexpected status {c['status']}")


# ---------------------------------------------------------------- piecewise
def _check_piecewise(c, fc):
    d = c["domain"]
    t = [_fr(v) for v in d["points"]]
    v = [_fr(x) for x in d["values"]]
    sL, sR = _fr(d["left_slope"]), _fr(d["right_slope"])
    w = int(c["class"]["width"])
    slopes = [sL] + [(v[i + 1] - v[i]) / (t[i + 1] - t[i]) for i in range(len(t) - 1)] + [sR]
    knots = [(t[i], slopes[i + 1] - slopes[i]) for i in range(len(t)) if slopes[i + 1] != slopes[i]]
    r = len(knots)

    def f(x):
        if x <= t[0]:
            return v[0] + sL * (x - t[0])
        if x >= t[-1]:
            return v[-1] + sR * (x - t[-1])
        for i in range(len(t) - 1):
            if t[i] <= x <= t[i + 1]:
                return v[i] + slopes[i + 1] * (x - t[i])

    _req(int(c["data"]["n_pieces"]) == r + 1, "piece count mismatch")
    if "genuine_knots" in c["data"]:
        _req([[_fr(a), _fr(b_)] for a, b_ in c["data"]["genuine_knots"]] == [[t_, d_] for t_, d_ in knots],
             "genuine knots mismatch")
    if "width" in c["data"]:
        _req(int(c["data"]["width"]) == w, "width mismatch")
    if c["status"] == "certified_no_member":
        if r > w:
            fc.ok("no_member")
            return
        if r == 0:
            _req(sL != 0 and w <= 1, "affine case: representable")
            fc.ok("no_member")
            return
        _req(w == r, "w >= r+1 is always representable")
        for size in range(r + 1):
            for J in itertools.combinations(range(r), size):
                _req(sum((knots[j][1] for j in J), Fraction(0)) != -sL, "a valid subset exists; target representable")
        fc.ok("no_member")
        return
    if c["status"] == "witness_found":
        cc = _fr(c["witness"]["c"])
        units = [{k: _fr(x) for k, x in u.items()} for u in c["witness"]["units"]]
        _req(len(units) <= w, "witness uses more units than width")

        def g(x):
            return cc + sum((u["a"] * max(u["u"] * x + u["b"], Fraction(0)) for u in units), Fraction(0))
        pts = set(t)
        for u in units:
            if u["u"] != 0:
                pts.add(-u["b"] / u["u"])
        pts = sorted(pts)
        pts = [pts[0] - 1] + pts + [pts[-1] + 1]
        _req(all(f(x) == g(x) for x in pts), "witness differs from target")
        fc.ok("witness")
        return
    if c["status"] == "unsupported":
        fc.ok("status_unsupported")
        return
    raise _Reject(f"unexpected status {c['status']}")


# ---------------------------------------------------------------- transition
#
# The checker trusts NOTHING in a transition certificate except the system
# specification `data.system`, which must equal `class.system` and
# `edit_rules`.  From that spec it independently derives the initial states,
# the complete reachable state space (its own BFS with its own move
# derivation), complexity and loss of every state, the simple-set threshold,
# all return labels (a bottleneck shortest-path computation, a different
# algorithm from the generator's per-level reverse searches), the closed
# classes with their full contents (Kosaraju), the inevitability and P(hit)=1
# claims, and the hitting probabilities / expected hitting times (its own
# Gaussian elimination: exact rationals where the certificate claims exact
# arithmetic, float64 otherwise).  Every claimed field is compared.  A field it
# cannot check (state space above CHECK_STATE_LIMIT, too many unknowns for
# exact arithmetic) is reported as unchecked and the verdict becomes
# 'partially_checked' (ok = False): never mistaken for full verification.

CHECK_STATE_LIMIT = 300_000
EXACT_UNKNOWN_LIMIT = 200


def _rederive_moves(spec, state):
    """Independent re-implementation of the three built-in systems' dynamics.
    Returns dict next_state_key -> Fraction."""
    kind = spec["kind"]
    out: dict[Any, Fraction] = {}

    def add(t, p):
        key = json.dumps(t)
        out[key] = out.get(key, Fraction(0)) + p

    if kind == "table":
        for p, t, _ in spec["transitions"][state]:
            add(t, Fraction(p))
        return out
    if kind == "permutation_chain":
        m, K = spec["m"], spec["K"]
        chain = [list(T) for T in state]

        def prod(ch):
            f = list(range(m))
            for T in ch:
                f = [T[f[x]] for x in range(m)]
            return f
        f0 = prod(chain)
        props = []
        taus = [(a, b) for a in range(m) for b in range(a + 1, m)]

        def tr(a, b):
            tt = list(range(m))
            tt[a], tt[b] = b, a
            return tt
        L = len(chain)
        for i in range(L - 1):
            for a, b in taus:
                tau = tr(a, b)
                new = [T[:] for T in chain]
                new[i] = [tau[chain[i][x]] for x in range(m)]
                new[i + 1] = [chain[i + 1][tau[y]] for y in range(m)]
                props.append(new)
        for i in range(L):
            for a, b in taus:
                tau = tr(a, b)
                new = [T[:] for T in chain]
                new[i] = [tau[chain[i][x]] for x in range(m)]
                props.append(new)
        if L < K:
            for pos in range(L + 1):
                props.append(chain[:pos] + [list(range(m))] + chain[pos:])
        if L > 1:
            for i in range(L):
                props.append(chain[:i] + chain[i + 1:])
        p = Fraction(1, len(props))
        for t in props:
            add(t if prod(t) == f0 else chain, p)
        return out
    if kind == "quantized_chain":
        m, K, mn = spec["m"], spec["K"], spec["min_len"]
        target = spec["target"]
        rule = spec["rule"]
        r = Fraction(spec["metropolis_r"])
        D = 2 ** m
        chain = [list(mod) for mod in state]

        def apply(mod, h):
            nh = 0
            for j in range(m):
                z = mod[j * (m + 1) + m]
                for i in range(m):
                    z += mod[j * (m + 1) + i] * ((h >> i) & 1)
                if z > 0:
                    nh += 2 ** j
            return nh

        def readout(ch):
            res = []
            for x in range(D):
                h = x
                for mod in ch:
                    h = apply(mod, h)
                res.append(h % 2)
            return res

        def loss(ch):
            return sum(a != b for a, b in zip(readout(ch), target))
        ident = []
        for j in range(m):
            ident += [1 if i == j else 0 for i in range(m)] + [0]
        props = []
        L = len(chain)
        if L < K:
            for pos in range(L + 1):
                props.append(chain[:pos] + [ident[:]] + chain[pos:])
        for i in range(L):
            for pp in range(m * (m + 1)):
                for val in (-1, 0, 1):
                    if val != chain[i][pp]:
                        new = [mm[:] for mm in chain]
                        new[i][pp] = val
                        props.append(new)
        if L > mn:
            for i in range(L):
                props.append(chain[:i] + chain[i + 1:])
        p = Fraction(1, len(props))
        ro, lo = readout(chain), loss(chain)
        for t in props:
            if rule == "neutral":
                a = Fraction(1) if readout(t) == ro else Fraction(0)
            else:
                dl = loss(t) - lo
                if rule == "nonincreasing":
                    a = Fraction(1) if dl <= 0 else Fraction(0)
                else:
                    a = Fraction(1) if dl <= 0 else r ** dl
            if a > 0:
                add(t, p * a)
            if a < 1:
                add(chain, p * (1 - a))
        return out
    raise _Unchecked(f"no independent re-derivation for system kind {kind}")


def _kosaraju(n, adj):
    order, seen = [], [False] * n
    for s in range(n):
        if seen[s]:
            continue
        stack = [(s, iter(adj[s]))]
        seen[s] = True
        while stack:
            v, it = stack[-1]
            nxt = next(it, None)
            if nxt is None:
                stack.pop()
                order.append(v)
            elif not seen[nxt]:
                seen[nxt] = True
                stack.append((nxt, iter(adj[nxt])))
    radj = [[] for _ in range(n)]
    for v in range(n):
        for w in adj[v]:
            radj[w].append(v)
    comp = [-1] * n
    c = 0
    for s in reversed(order):
        if comp[s] != -1:
            continue
        comp[s] = c
        st = [s]
        while st:
            v = st.pop()
            for w in radj[v]:
                if comp[w] == -1:
                    comp[w] = c
                    st.append(w)
        c += 1
    return comp, c


def _bfs(src, adj, allowed=None):
    seen = set(x for x in src if allowed is None or allowed(x))
    dq = deque(seen)
    while dq:
        v = dq.popleft()
        for w in adj[v]:
            if w not in seen and (allowed is None or allowed(w)):
                seen.add(w)
                dq.append(w)
    return seen




def _perm_prod(m, ch):
    f = list(range(m))
    for T in ch:
        f = [T[f[x]] for x in range(m)]
    return f


def _qc_apply(m, mod, h):
    nh = 0
    for j in range(m):
        z = mod[j * (m + 1) + m]
        for i in range(m):
            z += mod[j * (m + 1) + i] * ((h >> i) & 1)
        if z > 0:
            nh += 2 ** j
    return nh


def _qc_readout(m, ch):
    res = []
    for x in range(2 ** m):
        h = x
        for mod in ch:
            h = _qc_apply(m, mod, h)
        res.append(h % 2)
    return res


def _t_initial(spec):
    if spec["kind"] == "table":
        return [str(s) for s in spec["initial"]]
    if spec["kind"] in ("permutation_chain", "quantized_chain"):
        return [[list(x) for x in spec["start"]]]
    raise _Unchecked(f"no independent semantics for system kind {spec['kind']}")


def _t_complexity(spec, s) -> int:
    if spec["kind"] == "table":
        return int(spec["complexity"][s])
    return len(s)


def _t_loss(spec, s) -> Fraction:
    k = spec["kind"]
    if k == "table":
        return Fraction(spec["loss"][s])
    if k == "permutation_chain":
        m = spec["m"]
        tgt = _perm_prod(m, [list(T) for T in spec["start"]])
        return Fraction(sum(1 for a, b in zip(_perm_prod(m, s), tgt) if a != b))
    if k == "quantized_chain":
        return Fraction(sum(a != b for a, b in zip(_qc_readout(spec["m"], s), spec["target"])))
    raise _Unchecked(f"no loss semantics for {k}")


def _t_explore(spec, limit):
    init = []
    keys, idx, states, succ = [], {}, [], []
    for s0 in _t_initial(spec):
        k = json.dumps(s0)
        if k not in idx:
            idx[k] = len(states)
            states.append(s0)
            keys.append(k)
            succ.append(None)
            init.append(idx[k])
    q = deque(range(len(states)))
    while q:
        i = q.popleft()
        mv = _rederive_moves(spec, states[i])
        _req(sum(mv.values(), Fraction(0)) == 1, f"re-derived move probabilities from {keys[i]} do not sum to 1")
        d: dict[int, Fraction] = {}
        for k, p in mv.items():
            _req(p >= 0, "negative re-derived probability")
            if p == 0:
                continue
            j = idx.get(k)
            if j is None:
                if len(states) >= limit:
                    return None
                j = len(states)
                idx[k] = j
                states.append(json.loads(k))
                keys.append(k)
                succ.append(None)
                q.append(j)
            d[j] = d.get(j, Fraction(0)) + p
        succ[i] = d
    return {"states": states, "keys": keys, "idx": idx, "succ": succ, "init": init}


def _bottleneck_to(S, adj, radj, loss_l):
    """minimax[v] = min over paths v -> S of the max loss on the path (both ends
    included); inf if S is unreachable.  Dijkstra on the reverse graph."""
    import heapq
    INF = None
    best = [INF] * len(adj)
    h = []
    for s in S:
        best[s] = loss_l[s]
        heapq.heappush(h, (loss_l[s], s))
    while h:
        d, v = heapq.heappop(h)
        if best[v] is not None and d > best[v]:
            continue
        for u in radj[v]:
            nd = max(loss_l[u], d)
            if best[u] is None or nd < best[u]:
                best[u] = nd
                heapq.heappush(h, (nd, u))
    return best


def _gauss_exact(A, b):
    n = len(b)
    M = [row[:] + [b[i]] for i, row in enumerate(A)]
    for c in range(n):
        piv = next((i for i in range(c, n) if M[i][c] != 0), None)
        _req(piv is not None, "singular hitting system")
        M[c], M[piv] = M[piv], M[c]
        pv = M[c][c]
        if pv != 1:
            M[c] = [v / pv for v in M[c]]
        for i in range(n):
            if i != c and M[i][c] != 0:
                f = M[i][c]
                M[i] = [a - f * bb for a, bb in zip(M[i], M[c])]
    return [M[i][n] for i in range(n)]


def _solve_hitting(U, succ, known, const, exact):
    """x_v = const + sum_w P(v,w) x_w on U; known values elsewhere."""
    if not U:
        return {}
    pos = {v: k for k, v in enumerate(U)}
    if exact:
        A = [[Fraction(0)] * len(U) for _ in U]
        b = [Fraction(const)] * len(U)
        for v in U:
            r = pos[v]
            A[r][r] += 1
            for w, p in succ[v].items():
                if w in pos:
                    A[r][pos[w]] -= p
                else:
                    b[r] += p * Fraction(known[w])
        x = _gauss_exact(A, b)
    else:
        import scipy.sparse as sp
        import scipy.sparse.linalg as spla
        rows, cols, vals = [], [], []
        b = np.full(len(U), float(const))
        for v in U:
            r = pos[v]
            rows.append(r); cols.append(r); vals.append(1.0)
            for w, p in succ[v].items():
                if w in pos:
                    rows.append(r); cols.append(pos[w]); vals.append(-float(p))
                else:
                    b[r] += float(p) * float(known[w])
        A = sp.csr_matrix((vals, (rows, cols)), shape=(len(U), len(U)))  # duplicates are summed
        x = np.atleast_1d(spla.spsolve(A.tocsc(), b))
        _req(bool(np.all(np.isfinite(x))), "numerical hitting system is singular")
        # residual check, so a solver failure is never mistaken for a false claim or a true one
        _req(float(np.max(np.abs(A @ x - b))) <= 1e-9 * max(1.0, float(np.max(np.abs(x)))),
             "numerical hitting solve did not converge")
        x = [float(v) for v in x]
    return {v: x[pos[v]] for v in U}


def _check_transition_fields(c, data, cls):
    """Duplicated and configuration fields of a transition certificate must agree."""
    dom, cov = c.get("domain") or {}, c.get("coverage") or {}
    _req(dom.get("type") == "reachable_state_space", "domain.type")
    _req(dom.get("n_states") == data["n_states"] == cov.get("examined"),
         "domain.n_states / data.n_states / coverage.examined disagree")
    _req("state_cap" in cls and "long_time_threshold" in cls, "class lacks the configured state_cap / long_time_threshold")
    _req(dom.get("state_cap") == data["state_cap"] == cls["state_cap"], "state_cap fields disagree")
    _req(int(data["n_states"]) <= int(data["state_cap"]), "more states than the state cap")
    _req(data.get("long_time_threshold") == cls["long_time_threshold"], "long_time_threshold differs from the class")
    _req(cov.get("method") == "bfs", "coverage.method")
    _req(bool(cov.get("complete")) == bool(data.get("complete")), "coverage.complete != data.complete")
    _req(cov.get("incomplete_reason") == data.get("incomplete_reason"), "incomplete_reason fields disagree")
    want = f"exact_rational graph; hitting={data.get('hitting_arithmetic')}; time={data.get('time_arithmetic')}"
    _req(c.get("precision") == want, f"precision {c.get('precision')!r} != {want!r}")
    if data.get("complete"):
        _req(data.get("incomplete_reason") is None, "complete search with an incomplete_reason")
    else:
        _req(data.get("incomplete_reason") in ("state_cap", "deadline", "unexpanded"), "unknown incomplete_reason")
        _req(data.get("hitting_arithmetic") is None and data.get("time_arithmetic") is None,
             "incomplete search carries hitting / time arithmetic")
        if data["incomplete_reason"] == "state_cap":
            _req(int(data["n_states"]) == int(data["state_cap"]), "state_cap reason but the cap was not reached")


def _num_eq(a, b, rel=1e-7, abs_=1e-9):
    return abs(float(a) - float(b)) <= abs_ + rel * max(abs(float(a)), abs(float(b)))


def _check_transition(c, fc):
    data = c["data"]
    spec = data["system"]
    cls = c.get("class") or {}
    _req(cls.get("system") == spec, "class.system differs from data.system (the authoritative specification)")
    _req(c.get("edit_rules") == spec, "edit_rules differ from data.system")
    complete = bool(data.get("complete"))
    if c["status"] == "complete_analysis":
        _req(bool(c["coverage"]["complete"]) and complete, "complete_analysis with incomplete search")
    else:
        _req(c["status"] == "incomplete" and not complete, f"unexpected status {c['status']}")
    thr_override = cls.get("simple_threshold_override")
    thr_given = thr_override if thr_override is not None else spec.get("simple_threshold")
    _check_transition_fields(c, data, cls)
    fc.ok("duplicated_fields")
    g = data.get("graph")
    if not complete:
        _check_transition_incomplete(c, fc, spec, thr_given, g)
        return
    ex = _t_explore(spec, CHECK_STATE_LIMIT)
    if ex is None:
        raise _Unchecked(f"reachable state space exceeds the checker limit {CHECK_STATE_LIMIT}")
    states, keys, succ, init = ex["states"], ex["keys"], ex["succ"], ex["init"]
    n = len(states)
    _req(int(data["n_states"]) == n, f"n_states {data['n_states']} != independently explored {n}")
    _req(int(c["coverage"].get("examined", n)) == n, "coverage.examined != reachable state count")
    fc.ok("state_space")
    adj = [sorted(d) for d in succ]
    radj = [[] for _ in range(n)]
    for v in range(n):
        for w in adj[v]:
            radj[w].append(v)
    _req(int(data["n_edges"]) == sum(len(a) for a in adj), "n_edges mismatch")
    comp_l = [_t_complexity(spec, st) for st in states]
    loss_l = [_t_loss(spec, st) for st in states]
    # simple-set threshold from the specification (or the recorded override)
    if thr_given is not None:
        thr, src = int(thr_given), "given"
    else:
        min_init = min(loss_l[i] for i in init)
        thr, src = min(comp_l[i] for i in range(n) if loss_l[i] <= min_init), \
            "min_complexity_with_loss_le_min_initial_loss"
    _req(data["simple_threshold"] == thr, f"simple_threshold {data['simple_threshold']} != derived {thr}")
    _req(data.get("simple_threshold_source") == src, "simple_threshold_source mismatch")
    simple = [comp_l[i] <= thr for i in range(n)]
    S = [i for i in range(n) if simple[i]]
    _req(int(data["n_simple"]) == len(S), "n_simple mismatch")
    fc.ok("complexity_loss_threshold")
    # return labels
    bott = _bottleneck_to(S, adj, radj, loss_l)
    labels = []
    for i in range(n):
        if simple[i]:
            labels.append("in_simple_set")
        elif bott[i] is None:
            labels.append("return_impossible")
        elif bott[i] <= loss_l[i]:
            labels.append("return_possible_zero_loss_path")
        else:
            labels.append("return_possible_only_via_higher_loss")
    cnt: dict[str, int] = {}
    for lab in labels:
        cnt[lab] = cnt.get(lab, 0) + 1
    _req(data["return_label_counts"] == cnt, f"return_label_counts {data['return_label_counts']} != {cnt}")
    fc.ok("return_labels")
    # closed classes
    comp, nc = _kosaraju(n, adj)
    _req(int(data["n_scc"]) == nc, "n_scc mismatch")
    members: dict[int, list[int]] = {}
    for v in range(n):
        members.setdefault(comp[v], []).append(v)
    closed = {cc for cc, mem in members.items() if all(comp[w] == cc for v in mem for w in adj[v])}
    mine = {}
    for cc in closed:
        mem = members[cc]
        mine[frozenset(keys[v] for v in mem)] = {"size": len(mem), "contains_simple": any(simple[v] for v in mem),
                                                 "min_complexity": min(comp_l[v] for v in mem),
                                                 "max_complexity": max(comp_l[v] for v in mem),
                                                 "losses": sorted({_fs_(loss_l[v]) for v in mem})}
    claimed = data.get("closed_classes") or []
    _req(len(claimed) == len(closed), "closed class count mismatch")
    gkeys = [json.dumps(st) for st in g["states"]] if g is not None else None
    id_to_set: dict = {}
    if g is not None:
        for ci in claimed:
            _req("members" in ci, "closed class without member list")
            _req(all(isinstance(v, int) and 0 <= v < len(gkeys) for v in ci["members"]), "member index out of range")
            _req(len(set(ci["members"])) == len(ci["members"]) == ci["size"], "closed class member list malformed")
            fs = frozenset(gkeys[v] for v in ci["members"])
            _req(fs in mine, f"claimed closed class {ci['id']} is not a closed class of the specified system")
            for kk, vv in mine[fs].items():
                _req(ci[kk] == vv, f"closed class {ci['id']}: {kk} {ci[kk]!r} != {vv!r}")
            _req(json.dumps(ci["example_state"]) in fs, "example_state not in its class")
            id_to_set[ci["id"]] = fs
        _req(len(id_to_set) == len(mine), "duplicate claimed closed classes")
        fc.ok("closed_classes")
    else:
        # no exported graph: the certificate claims class summaries only; check them as a multiset
        summ = lambda d_: json.dumps({k: d_[k] for k in ("size", "contains_simple", "min_complexity",
                                                          "max_complexity", "losses")}, sort_keys=True)
        _req(sorted(summ(ci) for ci in claimed) == sorted(summ(v) for v in mine.values()),
             "closed class summaries mismatch")
        fc.ok("closed_class_summaries")
    bad = {fs for fs, v in mine.items() if not v["contains_simple"]}
    # absorbing-S* chain: states from which P(hit S*) = 1 (graph-exact)
    adj_abs = [[] if simple[v] else adj[v] for v in range(n)]
    comp2, _ = _kosaraju(n, adj_abs)
    mem2: dict[int, list[int]] = {}
    for v in range(n):
        mem2.setdefault(comp2[v], []).append(v)
    closed2 = {cc for cc, mem in mem2.items() if all(comp2[w] == cc for v in mem for w in adj_abs[v])}
    bad2 = [v for cc in closed2 if not all(simple[u] for u in mem2[cc]) for v in mem2[cc]]
    radj_abs = [[] for _ in range(n)]
    for v in range(n):
        for w in adj_abs[v]:
            radj_abs[w].append(v)
    reach_bad = _bfs(bad2, radj_abs)
    hit_one = set(range(n)) - reach_bad
    can_reach = {i for i in range(n) if bott[i] is not None}
    known = {}
    for v in range(n):
        if simple[v] or v in hit_one:
            known[v] = 1
        elif v not in can_reach:
            known[v] = 0
    U = [v for v in range(n) if v not in known]
    H = sorted(hit_one - set(S))
    claim_h = data.get("hitting_arithmetic")
    claim_t = data.get("time_arithmetic")
    hits = None
    if claim_h == "exact_rational":
        if len(U) <= EXACT_UNKNOWN_LIMIT:
            hits = _solve_hitting(U, succ, known, 0, True)
            fc.ok("hitting_probabilities", "exact")
        else:
            fc.skip("hitting_probabilities", f"{len(U)} unknowns > exact checker limit {EXACT_UNKNOWN_LIMIT}")
    else:
        _req(claim_h == "float64", f"unknown hitting arithmetic {claim_h}")
        hits = _solve_hitting(U, succ, known, 0, False)
        fc.ok("hitting_probabilities", "numerical")
    times = None
    if claim_t == "exact_rational":
        if len(H) <= EXACT_UNKNOWN_LIMIT:
            times = _solve_hitting(H, succ, {v: 0 for v in S}, 1, True)
            fc.ok("expected_hitting_times", "exact")
        else:
            fc.skip("expected_hitting_times", f"{len(H)} unknowns > exact checker limit {EXACT_UNKNOWN_LIMIT}")
    else:
        _req(claim_t == "float64", f"unknown time arithmetic {claim_t}")
        times = _solve_hitting(H, succ, {v: 0 for v in S}, 1, False)
        fc.ok("expected_hitting_times", "numerical")
    # initial-state reports, aligned with the independently derived initial states
    reps = data["initial"]
    _req(len(reps) == len(init), f"{len(reps)} initial reports for {len(init)} initial states")
    long_thr = data.get("long_time_threshold")
    for rep, i in zip(reps, init):
        _req(json.dumps(rep["state"]) == keys[i], "initial state mismatch")
        _req(rep["complexity"] == comp_l[i] and Fraction(rep["loss"]) == loss_l[i], "initial complexity/loss mismatch")
        _req(rep["return_label"] == labels[i], f"initial return label {rep['return_label']} != {labels[i]}")
        R = _bfs([i], adj)
        rc = {frozenset(keys[v] for v in members[comp[v]]) for v in R if comp[v] in closed}
        inev = bool(rc) and rc <= bad
        _req(rep["entrenchment_inevitable"] == inev, "inevitability claim false")
        _req(rep["bad_class_reachable"] == bool(rc & bad), "bad-class reachability claim false")
        if id_to_set:
            claimed_rc = {id_to_set.get(x) for x in rep["reachable_closed_classes"]}
            _req(claimed_rc == rc, "reachable closed classes mismatch")
        else:
            by_id = {ci["id"]: summ(ci) for ci in claimed}
            _req(sorted(by_id.get(x, "?") for x in rep["reachable_closed_classes"]) ==
                 sorted(summ(mine[fs]) for fs in rc), "reachable closed classes mismatch")
        _req(rep["p_hit_simple_is_one_graph_exact"] == (i in hit_one), "P(hit)=1 claim false")
        ph_claim = rep["p_hit_simple"]
        truth = Fraction(known[i]) if i in known else (hits[i] if hits is not None else None)
        if truth is not None:
            if isinstance(ph_claim, str):
                _req(isinstance(truth, Fraction) and Fraction(ph_claim) == truth,
                     f"hitting probability {ph_claim} != {truth}")
            else:
                _req(0.0 <= float(ph_claim) <= 1.0 and _num_eq(ph_claim, truth), "hitting probability mismatch")
        et = rep["expected_time_to_simple"]
        if simple[i]:
            _req(et == 0, "expected time of a simple state must be 0")
        elif i not in hit_one:
            _req(et is None, "finite expected time claimed although P(hit) < 1")
        else:
            _req(et is not None, "expected time missing although P(hit) = 1")
            if isinstance(et, str):
                _req(Fraction(et) >= 1, "expected hitting time below 1 for a non-simple state")
            else:
                _req(float(et) >= 1.0 - 1e-9, "expected hitting time below 1 for a non-simple state")
            if times is not None:
                tv = times[i]
                if isinstance(et, str):
                    _req(isinstance(tv, Fraction) and Fraction(et) == tv, f"expected time {et} != {tv}")
                else:
                    _req(_num_eq(et, tv), "expected time mismatch")
            _req("long_expected_time" in rep, "long_expected_time flag missing")
            _req(rep["long_expected_time"] == (float(et if not isinstance(et, str) else Fraction(et)) >
                                               float(long_thr)), "long_expected_time flag inconsistent")
        if simple[i] or i not in hit_one:
            _req("long_expected_time" not in rep, "long_expected_time flag on a state without a finite hitting time")
    fc.ok("initial_reports")
    # exported graph (when present): every state, value, edge and label
    if g is None:
        fc.ok("aggregates_only (no per-state graph was claimed)")
        return
    _req(len(gkeys) == n and set(gkeys) == set(keys), "exported state set differs from the reachable set")
    gi = {k: j for j, k in enumerate(gkeys)}
    _req(len(gi) == n, "duplicate exported states")
    mi = ex["idx"]
    _req([gkeys[j] for j in g["initial"]] == [keys[i] for i in init], "exported initial states mismatch")
    _req(all(bool(x) for x in g["expanded"]), "complete claimed but some states unexpanded")
    for j, k in enumerate(gkeys):
        i = mi[k]
        _req(g["complexity"][j] == comp_l[i] and Fraction(g["loss"][j]) == loss_l[i], f"state {j}: complexity/loss")
        _req(g["labels"][j] == labels[i], f"state {j}: label {g['labels'][j]} != {labels[i]}")
    ge: dict = {}
    for e in g["edges"]:
        _req(len(e) == 3 and 0 <= e[0] < n and 0 <= e[1] < n, "malformed edge")
        p = Fraction(e[2])
        _req(0 < p <= 1, "edge probability outside (0, 1]")
        key = (gkeys[e[0]], gkeys[e[1]])
        ge[key] = ge.get(key, Fraction(0)) + p
    me = {(keys[i], keys[j]): p for i in range(n) for j, p in succ[i].items()}
    _req(ge == me, "exported transitions differ from the independently derived dynamics")
    fc.ok("per_state_graph")


def _check_transition_incomplete(c, fc, spec, thr_given, g):
    """An incomplete search claims only (i) an explored subgraph of the true
    system and (ii) witnessed return paths inside it.  Soundness: every exported
    state must be reachable from the specified initial states over exported
    edges, and every exported edge must be a true transition (the full
    re-derived distribution for expanded states, a subset of it otherwise), so a
    witnessed path is a real path of the specified process."""
    data = c["data"]
    _req(not data.get("closed_classes"), "incomplete search reports closed classes")
    for k in ("n_scc", "hitting_arithmetic", "time_arithmetic"):
        _req(data.get(k) is None, f"incomplete search reports {k}")
    reps = data.get("initial") or []
    for rep in reps:
        _req(set(rep) == {"state", "complexity", "loss", "return_label"},
             "incomplete-search initial report carries extra claims")
    init_keys = []
    for s0 in _t_initial(spec):
        k = json.dumps(s0)
        if k not in init_keys:
            init_keys.append(k)
    _req(len(reps) == len(init_keys), f"{len(reps)} initial reports for {len(init_keys)} initial states")
    if thr_given is not None:
        _req(data["simple_threshold"] == int(thr_given) and data.get("simple_threshold_source") == "given",
             "simple_threshold / source differ from the specification")
    else:
        _req(data["simple_threshold"] is None and data.get("simple_threshold_source") == "undetermined_incomplete",
             "incomplete search without a given threshold must leave it undetermined")
    if g is None:
        # without the explored subgraph only the initial states can be checked
        for rep, k in zip(reps, init_keys):
            st = json.loads(k)
            _req(json.dumps(rep["state"]) == k, "initial state mismatch")
            _req(rep["complexity"] == _t_complexity(spec, st) and Fraction(rep["loss"]) == _t_loss(spec, st),
                 "initial complexity/loss mismatch")
        fc.ok("initial_states")
        fc.skip("explored_subgraph", "incomplete analysis without exported graph")
        return
    n = len(g["states"])
    _req(int(data["n_states"]) == n, "n_states != number of exported states")
    _req(all(len(g[f]) == n for f in ("complexity", "loss", "expanded", "labels")), "graph field lengths differ")
    gkeys = [json.dumps(s_) for s_ in g["states"]]
    _req(len(set(gkeys)) == n, "duplicate exported states")
    _req([gkeys[j] for j in g["initial"]] == init_keys, "exported initial states mismatch")
    succ: list[dict] = [dict() for _ in range(n)]
    for e in g["edges"]:
        _req(len(e) == 3, "malformed edge")
        i, j, p = e
        _req(isinstance(i, int) and isinstance(j, int) and 0 <= i < n and 0 <= j < n, "edge index out of range")
        _req(j not in succ[i], "duplicate edge")
        p = Fraction(p)
        _req(0 < p <= 1, "edge probability outside (0, 1]")
        succ[i][j] = p
    _req(int(data["n_edges"]) == len(g["edges"]), "n_edges != number of exported edges")
    _req(not all(bool(x) for x in g["expanded"]), "incomplete search claims every state expanded")
    for i in range(n):
        st = g["states"][i]
        _req(g["complexity"][i] == _t_complexity(spec, st) and Fraction(g["loss"][i]) == _t_loss(spec, st),
             f"state {i}: complexity/loss")
        if not succ[i] and not g["expanded"][i]:
            continue
        re_ = {k: p for k, p in _rederive_moves(spec, st).items() if p != 0}
        _req(sum(re_.values(), Fraction(0)) == 1, f"state {i}: re-derived probabilities do not sum to 1")
        ex_ = {gkeys[j]: p for j, p in succ[i].items()}
        if g["expanded"][i]:
            _req(re_ == ex_, f"state {i}: exported transitions differ from re-derived dynamics")
        else:
            _req(all(re_.get(k) == p for k, p in ex_.items()),
                 f"state {i}: exported partial transitions are not transitions of the specified system")
    adj = [sorted(d) for d in succ]
    reach0 = _bfs(list(g["initial"]), adj)
    _req(len(reach0) == n, f"{n - len(reach0)} exported states are not reachable from the initial states")
    fc.ok("explored_subgraph")
    allowed = {"unsearched", "in_simple_set", "return_possible_witnessed_incomplete"}
    _req(all(l in allowed for l in g["labels"]), "incomplete search carries a definitive label")
    if thr_given is None:
        simple = [False] * n
        want_l = ["unsearched"] * n
    else:
        simple = [g["complexity"][i] <= int(thr_given) for i in range(n)]
        radj = [[] for _ in range(n)]
        for i in range(n):
            for j in succ[i]:
                radj[j].append(i)
        reach = _bfs([i for i in range(n) if simple[i]], radj)
        want_l = ["in_simple_set" if simple[i] else
                  ("return_possible_witnessed_incomplete" if i in reach else "unsearched") for i in range(n)]
    for i, l in enumerate(g["labels"]):
        _req(l == want_l[i], f"state {i}: label {l} != {want_l[i]}")
    _req(int(data["n_simple"]) == sum(simple), "n_simple mismatch")
    cnt: dict[str, int] = {}
    for lab in want_l:
        cnt[lab] = cnt.get(lab, 0) + 1
    _req(data["return_label_counts"] == cnt, f"return_label_counts {data['return_label_counts']} != {cnt}")
    fc.ok("return_labels_witnessed")
    for rep, j in zip(reps, g["initial"]):
        _req(json.dumps(rep["state"]) == gkeys[j], "initial state mismatch")
        _req(rep["complexity"] == g["complexity"][j] and Fraction(rep["loss"]) == Fraction(g["loss"][j]),
             "initial complexity/loss mismatch")
        _req(rep["return_label"] == want_l[j], f"initial return label {rep['return_label']} != {want_l[j]}")
    fc.ok("initial_reports")


def _fs_(x: Fraction) -> str:
    return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"


# ---------------------------------------------------------------- entry
class _Fields:
    """Field-level record: which claimed quantities were verified and how
    (exact | numerical), and which could not be checked."""

    def __init__(self):
        self.checks: dict[str, str] = {}
        self.unchecked: list[str] = []

    def ok(self, name: str, how: str = "exact") -> None:
        self.checks[name] = how

    def skip(self, name: str, why: str) -> None:
        self.checks[name] = "unchecked"
        self.unchecked.append(f"{name}: {why}")


def verify_certificate(cert_or_path: Any) -> dict:
    """verdict: verified (every claimed field checked; ok=True) | partially_checked
    (no contradiction found but some claimed fields could not be checked;
    ok=False) | unchecked (nothing could be checked; ok=False) | rejected."""
    if isinstance(cert_or_path, (str, Path)):
        with open(cert_or_path) as f:
            c = json.load(f)
    else:
        c = json.loads(json.dumps(cert_or_path))
    fc = _Fields()
    try:
        st = c.get("status")
        cov = c.get("coverage") or {}
        if st in PROOF:
            _req(bool(cov.get("complete")), "proof status with incomplete coverage")
            if cov.get("method") == "enumeration":
                _req(cov.get("examined") == cov.get("total"), "proof status but examined != total")
            _req(not cov.get("timed_out"), "proof status after timeout")
        t = c.get("type")
        fn = {"boolean_class": _check_boolean, "rank_exact": _check_rank_exact, "rank_approx": _check_rank_approx,
              "message": _check_message, "piecewise": _check_piecewise, "transition": _check_transition}.get(t)
        if fn is None:
            raise _Reject(f"unknown certificate type {t}")
        fn(c, fc)
        if fc.unchecked:
            return {"ok": False, "verdict": "partially_checked", "reasons": fc.unchecked, "checks": fc.checks}
        return {"ok": True, "verdict": "verified", "reasons": [], "checks": fc.checks}
    except _Reject as e:
        return {"ok": False, "verdict": "rejected", "reasons": [str(e)], "checks": fc.checks}
    except _Unchecked as e:
        return {"ok": False, "verdict": "unchecked", "reasons": [str(e)], "checks": fc.checks}
    except Exception as e:  # malformed certificate
        return {"ok": False, "verdict": "rejected", "reasons": [f"malformed certificate: {type(e).__name__}: {e}"],
                "checks": fc.checks}


if __name__ == "__main__":
    import sys
    for p in sys.argv[1:]:
        print(p, json.dumps(verify_certificate(p)))
