"""Exact finite communication bounds by decoder-codebook enumeration (v5, P2).

Communication model (the delayed-query problem of docs/SEMANTICS and calibration 7.2):
  x uniform on {0,1}^n; a query q uniform on {0..n-1}, independent of x; an encoder sees x
  only and emits one of at most M = 2^k messages; a decoder sees (message, q) only and
  answers x_q.  No bypass from x to the decoder, no access to q by the encoder.
Error counts are over the complete domain: n * 2^n (x, q) pairs.

Decoder-codebook argument.  A decoder is a table c_m in {0,1}^n per message m (its answer to
each query).  For a fixed codebook C the best encoder sends a nearest codeword in Hamming
distance, so
    errors*(n, k) = min_{|C| <= M} sum_{x} min_{c in C} d_H(x, c).
Adding a codeword never increases the error, so exactly min(M, 2^n) DISTINCT codewords are
searched.  On the uniform cube the map (x, C) -> (x xor v, C xor v) preserves the objective,
so one codeword may be fixed at 0 (XOR anchor).  The anchor is NOT valid for a non-uniform
source; this module only treats the uniform complete cube.  When M >= 2^n the identity code
has zero error, which is optimal because errors are non-negative.

Original-task preservation (the retention benchmark).  If the encoder must also let the
decoder answer an original task t(x) in {0,1} with ZERO error, every message cell must be pure
in t.  Each codeword then carries a task label l(c) and x may only use codewords with
l(c) = t(x):
    errors_t*(n, k) = min_{C, labels} sum_x min_{(c, l) in C : l = t(x)} d_H(x, c).
For a bit task t(x) = x_j the label is forced (l = c_j: the cell is pure in x_j, so its
majority answer to query j is x_j) and the XOR anchor stays valid (translation preserves
c_j = x_j).  For other tasks labelled codebooks are enumerated without an anchor.  Only the
zero-error constraint is solved by codebooks; the full trade-off frontier (original-task
errors against later-query errors) is computed by encoder enumeration where that is small
(`brute_force`).

All results are exact or explicitly incomplete (complete = False, no value reported as
optimal); there is no approximation and no sampling.
"""
from __future__ import annotations

import itertools
import math
import time
from typing import Callable, Optional

import numpy as np

MAX_CANDIDATES = 50_000_000


def cube(n: int) -> np.ndarray:
    """(2^n, n) bits; row i has bit j = (i >> j) & 1 (the order of data.splits.codes_to_bits)."""
    idx = np.arange(2 ** n, dtype=np.int64)
    return ((idx[:, None] >> np.arange(n, dtype=np.int64)) & 1).astype(np.int16)


def hamming(n: int) -> np.ndarray:
    X = cube(n)
    return (X[:, None, :] != X[None, :, :]).sum(axis=2).astype(np.int16)


def oracle_errors(labels, n: int, queries=None) -> int:
    """Optimal-decoder errors of a FROZEN encoder: for every message cell and query, the
    majority answer (ties either way cost the same).  labels: message id of every x (2^n)."""
    X = cube(n).astype(np.int64)
    lab = np.asarray(labels).reshape(-1)
    if lab.shape[0] != X.shape[0]:
        raise ValueError("labels must give one message per x of the complete cube")
    qs = list(range(n)) if queries is None else list(queries)
    tot = 0
    for m in np.unique(lab):
        rows = X[lab == m][:, qs]
        ones = rows.sum(axis=0)
        tot += int(np.minimum(ones, rows.shape[0] - ones).sum())
    return tot


def task_purity_errors(labels, task) -> int:
    """Errors of the best decoder of the original task t from the message alone (majority per cell)."""
    lab = np.asarray(labels).reshape(-1)
    t = np.asarray(task).reshape(-1).astype(np.int64)
    tot = 0
    for m in np.unique(lab):
        r = t[lab == m]
        tot += int(min(r.sum(), len(r) - r.sum()))
    return tot


def _count(c: int):
    """JSON-safe count: the integer when it fits in 63 bits, else its log10 as a string label."""
    c = int(c)
    return c if c < 2 ** 63 else f"10^{math.log10(c):.1f}" if c < 10 ** 300 else f"2^{c.bit_length() - 1}+"


def _result(n, k, M, errors, method, complete, examined, candidates, seconds, centers=None, encoder=None, **kw):
    tot = n * 2 ** n
    out = {"n": n, "k_bits": k, "messages": M, "errors": None if errors is None else int(errors),
           "answers": tot, "accuracy": None if errors is None else 1.0 - errors / tot,
           "complete": bool(complete), "method": method, "examined": int(examined), "candidates": _count(candidates),
           "seconds": float(seconds), "centers": centers, "encoder": encoder}
    out.update(kw)
    return out


def delayed_query_optimum(n: int, k: int, max_candidates: int = MAX_CANDIDATES,
                          time_limit: Optional[float] = None,
                          messages: Optional[int] = None) -> dict:
    """Exact minimum errors for the uniform delayed-query problem with at most 2^k messages (or at most
    `messages` messages when given, for alphabets that are not a power of two)."""
    if n < 1 or k < 0:
        raise ValueError("need n >= 1 and k >= 0")
    N = 2 ** n
    M = min(2 ** k if messages is None else int(messages), N)
    if M < 1:
        raise ValueError("need at least one message")
    t0 = time.perf_counter()
    if M == N:
        return _result(n, k, M, 0, "identity code; errors are non-negative", True, 0, 1, 0.0,
                       centers=list(range(N)), encoder=list(range(N)))
    cand = math.comb(N - 1, M - 1)
    if cand > max_candidates:
        return _result(n, k, M, None, "too many anchored codebooks; not computed", False, 0, cand, 0.0)
    D = hamming(n)
    best, centers, examined = n * N + 1, None, 0
    it = itertools.combinations(range(1, N), M - 1)
    complete = True
    while True:
        batch = list(itertools.islice(it, 8192))
        if not batch:
            break
        codes = np.zeros((len(batch), M), dtype=np.int64)
        if M > 1:
            codes[:, 1:] = np.asarray(batch, dtype=np.int64)
        scores = D[:, codes].min(axis=2).sum(axis=0)          # (B,)
        j = int(scores.argmin())
        if int(scores[j]) < best:
            best, centers = int(scores[j]), codes[j].tolist()
        examined += len(batch)
        if time_limit is not None and time.perf_counter() - t0 > time_limit and examined < cand:
            complete = False
            break
    if not complete:
        return _result(n, k, M, None, "time limit before the search finished; not computed", False, examined, cand,
                       time.perf_counter() - t0)
    enc = D[:, centers].argmin(axis=1)
    X = cube(n)
    direct = int((X[np.asarray(centers)[enc]] != X).sum())
    if direct != best or oracle_errors(enc, n) != best:
        raise AssertionError("codebook witness does not reproduce its error count")
    return _result(n, k, M, best, "all distinct decoder codebooks, XOR anchor at 0", True, examined, cand,
                   time.perf_counter() - t0, centers=centers, encoder=enc.tolist())


def task_vector(n: int, task: str) -> np.ndarray:
    """Original-task labels on the complete cube: 'bit:j' (x_j) or 'parity:m' (parity of x_0..x_{m-1})."""
    X = cube(n).astype(np.int64)
    kind, _, arg = task.partition(":")
    j = int(arg)
    if kind == "bit":
        if not 0 <= j < n:
            raise ValueError("bit task index out of range")
        return X[:, j]
    if kind == "parity":
        if not 1 <= j <= n:
            raise ValueError("parity width out of range")
        return X[:, :j].sum(1) % 2
    raise ValueError(f"unknown task {task!r}")


def retention_optimum(n: int, k: int, task: str, max_candidates: int = MAX_CANDIDATES,
                      time_limit: Optional[float] = None,
                      messages: Optional[int] = None) -> dict:
    """Exact minimum later-query errors (all n bit queries) subject to ZERO original-task error (at most 2^k
    messages, or `messages` when given)."""
    N = 2 ** n
    M = min(2 ** k if messages is None else int(messages), N)
    t = task_vector(n, task)
    t0 = time.perf_counter()
    X = cube(n)
    if len(set(t.tolist())) > 1 and M < 2:
        return _result(n, k, M, None, "infeasible: one message cannot separate the original task", True, 0, 0, 0.0,
                       task=task, feasible=False)
    if M == N:
        return _result(n, k, M, 0, "identity code (pure cells, zero error)", True, 0, 1, 0.0, task=task,
                       feasible=True, centers=list(range(N)), encoder=list(range(N)))
    kind = task.split(":")[0]
    if kind == "bit":
        jbit = int(task.split(":")[1])
        cand = math.comb(N - 1, M - 1)
        if cand > max_candidates:
            return _result(n, k, M, None, "too many anchored codebooks; not computed", False, 0, cand, 0.0, task=task)
        D = hamming(n).astype(np.int64)              # int64: sums include the infeasibility sentinel
        lab_of = X[:, jbit].astype(np.int64)                  # forced codeword label c_j
        big = 10 ** 6
        best, centers, examined = None, None, 0
        it = itertools.combinations(range(1, N), M - 1)
        while True:
            batch = list(itertools.islice(it, 8192))
            if not batch:
                break
            codes = np.zeros((len(batch), M), dtype=np.int64)
            codes[:, 1:] = np.asarray(batch, dtype=np.int64)
            ok = (lab_of[codes][:, None, :] == t[None, :, None])             # (B, N, M) allowed codewords
            d = np.where(ok, D[:, codes].transpose(1, 0, 2), big)            # (B, N, M)
            sc = d.min(axis=2).sum(axis=1)
            j = int(sc.argmin())
            if sc[j] < big and (best is None or int(sc[j]) < best):
                best, centers = int(sc[j]), codes[j].tolist()
            examined += len(batch)
            if time_limit is not None and time.perf_counter() - t0 > time_limit and examined < cand:
                return _result(n, k, M, None, "time limit before the search finished; not computed", False,
                               examined, cand, time.perf_counter() - t0, task=task)
        method = "all distinct decoder codebooks, labels forced (c_j), XOR anchor at 0"
        labels_c = [int(lab_of[c]) for c in centers]
    else:
        # labelled codebooks (codeword, label), no anchor: candidates choose M of 2N labelled words
        cand = math.comb(2 * N, M)
        if cand > max_candidates:
            return _result(n, k, M, None, "too many labelled codebooks; not computed", False, 0, cand, 0.0, task=task)
        D = hamming(n).astype(np.int64)
        words = np.arange(2 * N)
        wc, wl = words % N, words // N
        big = 10 ** 6
        best, sel, examined = None, None, 0
        it = itertools.combinations(range(2 * N), M)
        while True:
            batch = list(itertools.islice(it, 8192))
            if not batch:
                break
            idx = np.asarray(batch, dtype=np.int64)
            ok = (wl[idx][:, None, :] == t[None, :, None])
            d = np.where(ok, D[:, wc[idx]].transpose(1, 0, 2), big)
            sc = d.min(axis=2).sum(axis=1)
            j = int(sc.argmin())
            if sc[j] < big and (best is None or int(sc[j]) < best):
                best, sel = int(sc[j]), idx[j].tolist()
            examined += len(batch)
            if time_limit is not None and time.perf_counter() - t0 > time_limit and examined < cand:
                return _result(n, k, M, None, "time limit before the search finished; not computed", False,
                               examined, cand, time.perf_counter() - t0, task=task)
        if best is None:
            return _result(n, k, M, None, "infeasible", True, examined, cand, time.perf_counter() - t0, task=task,
                           feasible=False)
        centers = [int(wc[s]) for s in sel]
        labels_c = [int(wl[s]) for s in sel]
        method = "all labelled decoder codebooks (no anchor)"
    # witness encoder: nearest allowed codeword; verify purity and the error count independently
    allowed = np.asarray(labels_c)[None, :] == t[:, None]
    dd = np.where(allowed, D[:, centers], 10 ** 6)
    enc = dd.argmin(axis=1)
    if task_purity_errors(enc, t) != 0:
        raise AssertionError("retention witness is not pure in the original task")
    if oracle_errors(enc, n) > best:
        raise AssertionError("retention witness does not reproduce its error count")
    if oracle_errors(enc, n) != best:
        raise AssertionError("oracle decoding of the witness differs from the codebook count")
    return _result(n, k, M, best, method, True, examined, cand, time.perf_counter() - t0, task=task, feasible=True,
                   centers=centers, encoder=enc.tolist(), center_labels=labels_c)


def brute_force(n: int, k: int, task: Optional[str] = None, max_encoders: int = 1 << 20,
                chunk: int = 1 << 14, messages: Optional[int] = None) -> dict:
    """Every encoder {0,1}^n -> {0..M-1} (M^(2^n) of them, capped).  Returns the unconstrained
    minimum and, with a task, the minimum later-query errors for every achievable number of
    original-task errors (the exact trade-off frontier on the complete cube).  Independent of the
    codebook argument: it is the cross-check for it on small cases."""
    N, M = 2 ** n, min(2 ** k if messages is None else int(messages), 2 ** n)
    if N * math.log2(max(M, 1)) > math.log2(max_encoders) + 1e-9:     # M^N > cap, without forming M^N
        lg = N * math.log2(max(M, 1))
        return {"n": n, "k_bits": k, "complete": False, "encoders": f"2^{lg:.1f}",
                "reason": f"2^{lg:.1f} encoders exceed the cap {max_encoders}"}
    total = M ** N
    X = cube(n).astype(np.int64)
    t = task_vector(n, task) if task else None
    best = None
    frontier: dict[int, int] = {}
    for start in range(0, total, chunk):
        idx = np.arange(start, min(total, start + chunk), dtype=np.int64)
        rem = idx.copy()
        labels = np.empty((idx.size, N), dtype=np.int64)
        for p in range(N):
            labels[:, p] = rem % M
            rem //= M
        onehot = (labels[:, :, None] == np.arange(M)[None, None, :]).astype(np.int64)   # C,N,M
        sizes = onehot.sum(1)                                                          # C,M
        ones = np.einsum("cnm,nq->cmq", onehot, X)
        err = np.minimum(ones, sizes[:, :, None] - ones).sum((1, 2))
        b = int(err.min())
        best = b if best is None or b < best else best
        if t is not None:
            ot = np.einsum("cnm,n->cm", onehot, t)
            et = np.minimum(ot, sizes - ot).sum(1)
            for e_t in np.unique(et):
                v = int(err[et == e_t].min())
                if int(e_t) not in frontier or v < frontier[int(e_t)]:
                    frontier[int(e_t)] = v
    out = {"n": n, "k_bits": k, "complete": True, "encoders": total, "min_errors": int(best),
           "answers": n * N}
    if t is not None:
        # keep only Pareto-optimal points: more original-task errors must buy fewer later errors
        pts, run = [], None
        for e_t in sorted(frontier):
            if run is None or frontier[e_t] < run:
                pts.append({"task_errors": int(e_t), "later_errors": int(frontier[e_t])})
                run = frontier[e_t]
        out.update({"task": task, "task_answers": N, "frontier": pts,
                    "min_errors_zero_task_error": frontier.get(0)})
    return out


def decomposition(e_model: int, e_oracle: int, e_star: int) -> dict:
    """e_model - e_star = (e_model - e_oracle) + (e_oracle - e_star): decoder-learning gap plus the
    gap between the learned code and an optimal code (both on the declared exact finite domain)."""
    dec, code = int(e_model) - int(e_oracle), int(e_oracle) - int(e_star)
    tot = int(e_model) - int(e_star)
    if dec + code != tot:
        raise AssertionError("decomposition does not close")
    return {"excess_total": tot, "decoder_learning_gap": dec, "code_gap": code,
            "closes": True, "notes": ("e_oracle >= e_star always (the optimum is over all codes); a negative decoder gap "
                                      "is impossible for the optimal decoder, so e_model >= e_oracle")}
