"""Delayed-query communication bound (R3).

Task: x in {0,1}^n, query q in {0..n-1}, target x_q.  Domain = all n * 2^n pairs.
Communication restriction: an encoder e: {0,1}^n -> {0..2^k-1} sees x only; a
decoder d(m, q) sees only the message m and the query q (no bypass from x to
the decoder, no access to q by the encoder).

For a fixed encoder the optimal decoder answers the majority bit of x_q within
the block e^{-1}(m), giving errors(e) = sum_m sum_q min(ones_{m,q}, |block_m| - ones_{m,q}).
The minimum over all (2^k)^(2^n) encoders is computed by exhaustive enumeration
for small n, k.

Analytical bound: a block of s distinct vectors varies in at least ceil(log2 s)
coordinates and each varying coordinate costs at least one error, so
errors(e) >= min over block-size vectors (s_1..s_M), sum s_i = 2^n, M <= 2^k,
of sum ceil(log2 s_i).  In particular zero error is impossible iff 2^n > 2^k
(pigeonhole).
"""
from __future__ import annotations

import time

import numpy as np

from .boolean import domain_bits


def ceil_log2(s: int) -> int:
    return 0 if s <= 1 else (s - 1).bit_length()


def analytic_lower_bound(n: int, k: int) -> int:
    N, M = 2 ** n, 2 ** k
    # dp[j][t] = min sum of ceil_log2 over j blocks (block size >= 1) covering t elements
    INF = 10 ** 9
    best = INF
    dp = [INF] * (N + 1)
    dp[0] = 0
    for _ in range(min(M, N)):
        new = [INF] * (N + 1)
        for t in range(N + 1):
            if dp[t] >= INF:
                continue
            for s in range(1, N - t + 1):
                v = dp[t] + ceil_log2(s)
                if v < new[t + s]:
                    new[t + s] = v
        dp = new
        best = min(best, dp[N])
    return int(best)


def encoder_errors(labels: np.ndarray, X: np.ndarray, M: int) -> np.ndarray:
    """labels (C,N) in [0,M) -> optimal-decoder error counts (C,)."""
    onehot = (labels[:, :, None] == np.arange(M)[None, None, :]).astype(np.int64)  # C,N,M
    ones = np.einsum("cnm,nq->cmq", onehot, X)
    sizes = onehot.sum(1)
    return np.minimum(ones, sizes[:, :, None] - ones).sum((1, 2))


def optimal_decoder(labels: list[int], n: int, M: int) -> list[list[int]]:
    X = domain_bits(n)
    dec = []
    for m in range(M):
        rows = X[np.array(labels) == m]
        if rows.shape[0] == 0:
            dec.append([0] * n)
        else:
            ones = rows.sum(0)
            dec.append([int(2 * o > rows.shape[0]) for o in ones])  # ties -> 0
    return dec


def enumerate_min_errors(n: int, k: int, tolerance_errors: int = 0, max_encoders: int | None = None,
                         deadline: float | None = None, chunk: int = 1 << 14) -> dict:
    N, M = 2 ** n, 2 ** k
    X = domain_bits(n)
    total = M ** N
    limit = total if max_encoders is None else min(total, int(max_encoders))
    limit = min(limit, int(np.iinfo(np.int64).max))
    examined, best, best_idx, timed_out = 0, None, None, False
    witness_idx = None
    start = 0
    while start < limit:
        if deadline is not None and time.time() > deadline:
            timed_out = True
            break
        stop = min(limit, start + chunk)
        idx = np.arange(start, stop, dtype=np.int64)
        rem = idx.copy()
        labels = np.empty((idx.size, N), dtype=np.int64)
        for p in range(N):
            labels[:, p] = rem % M
            rem //= M
        err = encoder_errors(labels, X, M)
        j = int(err.argmin())
        if best is None or int(err[j]) < best:
            best, best_idx = int(err[j]), int(idx[j])
        if witness_idx is None:
            ok = np.nonzero(err <= tolerance_errors)[0]
            if ok.size:
                witness_idx = int(idx[ok[0]])
        examined += stop - start
        start = stop
    complete = examined == total

    def decode(i: int) -> list[int]:
        out = []
        for _ in range(N):
            out.append(i % M)
            i //= M
        return out

    witness = None
    if witness_idx is not None:
        lab = decode(witness_idx)
        e = int(encoder_errors(np.array([lab]), X, M)[0])
        witness = {"encoder_index": witness_idx, "encoder": lab, "decoder": optimal_decoder(lab, n, M), "errors": e}
    best_enc = decode(best_idx) if best_idx is not None else None
    return {"examined": int(examined), "total": int(total), "complete": bool(complete), "timed_out": timed_out,
            "min_errors_examined": best, "min_errors_exact": bool(complete), "min_error_encoder": best_enc,
            "witness": witness}

