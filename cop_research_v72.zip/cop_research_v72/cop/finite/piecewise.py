"""Exact-representation certificates for one-hidden-layer ReLU networks on R (R3).

Class N_w: f(x) = c + sum_{j=1..w} a_j relu(u_j x + b_j), all parameters real,
domain = the whole real line, criterion = exact equality (tolerance 0).

Target: a continuous piecewise-linear (CPWL) function given by rational points
t_1 < ... < t_p with values v_i and the slopes sL (x < t_1), sR (x > t_p).
Genuine knots are points where the slope changes; with r genuine knots the
target has m = r + 1 pieces (the minimal number of affine pieces).

Facts used (proofs in docs/CERTIFICATES.md):
  (B) Every member of N_w has at most w kinks, hence at most w + 1 pieces.  So
      m > w + 1 (equivalently r > w) excludes exact representation.  This is the
      sound piece-count bound.
  (E) Exact characterisation.  For r >= 1: representable iff w >= r + 1, or
      w = r and some subset J of genuine knots has sum_{j in J} Delta_j = -sL,
      where Delta_j is the slope change at knot j.  For r = 0: representable iff
      sL = 0 (any w >= 0) or w >= 2.
Tolerance > 0 (approximation) is reported as 'unsupported': no sound
approximation lower bound is implemented.
"""
from __future__ import annotations

from fractions import Fraction
from itertools import combinations
from typing import Any, Sequence

Q = Fraction


def _q(v: Any) -> Fraction:
    if isinstance(v, float):
        raise TypeError("piecewise certificates require exact rationals (int or 'p/q' strings), not floats")
    return Fraction(v)


class CPWL:
    def __init__(self, points: Sequence[Any], values: Sequence[Any], left_slope: Any, right_slope: Any):
        if len(points) == 0 or len(points) != len(values):
            raise ValueError("need >= 1 point and matching values")
        self.t = [_q(p) for p in points]
        self.v = [_q(v) for v in values]
        if any(b <= a for a, b in zip(self.t, self.t[1:])):
            raise ValueError("points must be strictly increasing")
        self.sL, self.sR = _q(left_slope), _q(right_slope)
        inner = [(self.v[i + 1] - self.v[i]) / (self.t[i + 1] - self.t[i]) for i in range(len(self.t) - 1)]
        self.slopes = [self.sL] + inner + [self.sR]  # slope on each of the p+1 intervals

    def __call__(self, x: Fraction) -> Fraction:
        t, v = self.t, self.v
        if x <= t[0]:
            return v[0] + self.sL * (x - t[0])
        if x >= t[-1]:
            return v[-1] + self.sR * (x - t[-1])
        for i in range(len(t) - 1):
            if t[i] <= x <= t[i + 1]:
                return v[i] + self.slopes[i + 1] * (x - t[i])
        raise AssertionError

    def genuine_knots(self) -> list[tuple[Fraction, Fraction]]:
        """[(t_j, Delta_j)] where Delta_j = slope_right - slope_left != 0."""
        return [(self.t[i], self.slopes[i + 1] - self.slopes[i]) for i in range(len(self.t))
                if self.slopes[i + 1] != self.slopes[i]]


def eval_relu_net(units: list[dict], c: Fraction, x: Fraction) -> Fraction:
    s = c
    for u in units:
        z = u["u"] * x + u["b"]
        if z > 0:
            s += u["a"] * z
    return s


def verify_equal(f: CPWL, units: list[dict], c: Fraction) -> bool:
    kinks = set(f.t)
    for u in units:
        if u["u"] != 0:
            kinks.add(-u["b"] / u["u"])
    pts = sorted(kinks)
    pts = [pts[0] - 1] + pts + [pts[-1] + 1]
    return all(f(x) == eval_relu_net(units, c, x) for x in pts)


def construct_witness(f: CPWL, w: int) -> tuple[list[dict], Fraction] | None:
    K = f.genuine_knots()
    r = len(K)
    sL = f.sL
    units: list[dict] = []
    if r == 0:
        p = f.t[0]
        if sL == 0:
            units = []
        elif w >= 2:
            units = [{"a": sL, "u": Q(1), "b": -p}, {"a": -sL, "u": Q(-1), "b": p}]  # sL (x - p)
        else:
            return None
        c = f(p) - sum((eval_relu_net([u], Q(0), p) for u in units), Q(0))
    elif w >= r + 1:
        t1, d1 = K[0]
        a = -sL
        units = [{"a": a, "u": Q(-1), "b": t1},            # a relu(t1 - x): slope -a = sL on the left
                 {"a": d1 - a, "u": Q(1), "b": -t1}]       # remaining slope change at t1
        units += [{"a": d, "u": Q(1), "b": -t} for t, d in K[1:]]
        c = f(t1)
    elif w == r:
        J = subset_sum_choice(K, sL)
        if J is None:
            return None
        units = []
        for j, (t, d) in enumerate(K):
            if j in J:
                units.append({"a": d, "u": Q(-1), "b": t})   # left-facing, change +d, left slope -d
            else:
                units.append({"a": d, "u": Q(1), "b": -t})
        x0 = K[0][0]
        c = f(x0) - eval_relu_net(units, Q(0), x0)
    else:
        return None
    units = units + [{"a": Q(0), "u": Q(0), "b": Q(0)}] * (w - len(units))
    if not verify_equal(f, units, c):
        raise AssertionError("witness construction failed exact verification")
    return units, c


def subset_sum_choice(K: list[tuple[Fraction, Fraction]], sL: Fraction) -> set[int] | None:
    r = len(K)
    for size in range(r + 1):
        for J in combinations(range(r), size):
            if sum((K[j][1] for j in J), Q(0)) == -sL:
                return set(J)
    return None


def piecewise_certificate_data(points, values, left_slope, right_slope, width: int, tolerance: Any = 0) -> dict:
    if Fraction(tolerance) != 0:
        return {"status": "unsupported", "reason": "approximate representation (tolerance > 0) has no sound bound implemented"}
    f = CPWL(points, values, left_slope, right_slope)
    K = f.genuine_knots()
    r = len(K)
    m = r + 1
    w = int(width)
    res: dict[str, Any] = {"genuine_knots": [[str(t), str(d)] for t, d in K], "n_pieces": m, "width": w}
    if r > w:
        res.update(status="certified_no_member", rule="piece_count_bound",
                   argument=f"target has {m} pieces > w + 1 = {w + 1}; every member has <= w kinks")
        return res
    if r == 0 and f.sL != 0 and w <= 1:
        res.update(status="certified_no_member", rule="exact_characterisation_affine",
                   argument="non-constant affine target: one unit with non-zero slope change creates a kink")
        return res
    wit = construct_witness(f, w)
    if wit is None:
        res.update(status="certified_no_member", rule="exact_characterisation_subset_sum",
                   argument=f"w = r = {r}: each genuine knot needs its own unit; no subset of slope changes sums to -sL = {-f.sL}")
        return res
    units, c = wit
    res.update(status="witness_found",
               witness={"c": str(c), "units": [{k: str(v) for k, v in u.items()} for u in units]})
    return res
