"""Linear rank-bottleneck certificates (R3).

Class L_k(m, n): real linear maps x -> A B x with A in R^{m x k}, B in R^{k x n}
(a linear network with a width-k bottleneck; biases are irrelevant for the
homogeneous target y = M x and are excluded).

Exact representation (type 'rank_exact').
  rank(A B) <= k for every member, so rank(M) > k proves M is not in L_k.
  For a rational M the rank over Q equals the rank over R (rank is the size of
  the largest non-vanishing minor), so exact rational elimination is a proof.
  If rank(M) = r <= k, M = C R with C = M[:, pivots] and R the non-zero rows of
  the reduced row echelon form; padded with zeros this is an explicit member,
  verified by exact multiplication.

Approximate representation (type 'rank_approx').
  Eckart-Young-Mirsky: min_{rank(N) <= k} ||M - N||_F^2 = sum_{i>k} sigma_i(M)^2.
  If x has E[x x^T] = I (for example x ~ N(0, I)), then
  E ||M x - A B x||^2 = ||M - A B||_F^2, so the same quantity lower-bounds the
  expected squared error of every member.  Observation noise is outside this
  statement.  Two evaluation modes:
    exact_rational_interval: eigenvalues of the Gram matrix are isolated in
      rational intervals by exact real-root isolation of its characteristic
      polynomial (sympy); the bound uses the lower interval endpoints.
    float64_with_margin: singular values from LAPACK with an explicit margin
      delta = 10 * max(m,n) * 2^-52 * sigma_1 per singular value (Weyl);
      bound = sum_{i>k} max(sigma_i - delta, 0)^2.
"""
from __future__ import annotations

from fractions import Fraction
from typing import Any, Sequence

import numpy as np


def to_fraction_matrix(M: Sequence[Sequence[Any]]) -> tuple[list[list[Fraction]], bool]:
    """Returns (matrix, exact_input).  Floats are converted to their exact binary
    value but flagged as non-exact input."""
    exact = True
    out = []
    for row in M:
        r = []
        for v in row:
            if isinstance(v, bool):
                raise TypeError("bool entry")
            if isinstance(v, float):
                exact = False
                r.append(Fraction(v))
            elif isinstance(v, (int, Fraction)):
                r.append(Fraction(v))
            elif isinstance(v, str):
                r.append(Fraction(v))
            elif isinstance(v, (np.integer,)):
                r.append(Fraction(int(v)))
            elif isinstance(v, (np.floating,)):
                exact = False
                r.append(Fraction(float(v)))
            else:
                raise TypeError(f"unsupported entry {v!r}")
        out.append(r)
    if len({len(r) for r in out}) > 1:
        raise ValueError("ragged matrix")
    return out, exact


def rref(M: list[list[Fraction]]) -> tuple[list[list[Fraction]], list[int]]:
    A = [row[:] for row in M]
    m = len(A)
    n = len(A[0]) if m else 0
    pivots: list[int] = []
    r = 0
    for c in range(n):
        piv = next((i for i in range(r, m) if A[i][c] != 0), None)
        if piv is None:
            continue
        A[r], A[piv] = A[piv], A[r]
        pv = A[r][c]
        A[r] = [v / pv for v in A[r]]
        for i in range(m):
            if i != r and A[i][c] != 0:
                f = A[i][c]
                A[i] = [a - f * b for a, b in zip(A[i], A[r])]
        pivots.append(c)
        r += 1
        if r == m:
            break
    return A, pivots


def exact_rank(M: list[list[Fraction]]) -> int:
    return len(rref(M)[1])


def matmul(A: list[list[Fraction]], B: list[list[Fraction]]) -> list[list[Fraction]]:
    n = len(B[0]) if B else 0
    return [[sum((A[i][t] * B[t][j] for t in range(len(B))), Fraction(0)) for j in range(n)]
            for i in range(len(A))]


def exact_factorization(M: list[list[Fraction]], k: int) -> tuple[list[list[Fraction]], list[list[Fraction]]]:
    R, piv = rref(M)
    r = len(piv)
    if r > k:
        raise ValueError("rank exceeds k")
    m, n = len(M), len(M[0])
    C = [[M[i][c] for c in piv] + [Fraction(0)] * (k - r) for i in range(m)]
    B = [R[i][:] for i in range(r)] + [[Fraction(0)] * n for _ in range(k - r)]
    if matmul(C, B) != M:
        raise AssertionError("exact factorization failed verification")
    return C, B


def _fs(x: Fraction) -> str:
    return f"{x.numerator}/{x.denominator}" if x.denominator != 1 else str(x.numerator)


def fmat(M: list[list[Fraction]]) -> list[list[str]]:
    return [[_fs(v) for v in row] for row in M]


def gram_smaller(M: list[list[Fraction]]) -> list[list[Fraction]]:
    m, n = len(M), len(M[0])
    if m <= n:  # M M^T  (m x m)
        return [[sum((M[i][t] * M[j][t] for t in range(n)), Fraction(0)) for j in range(m)] for i in range(m)]
    return [[sum((M[t][i] * M[t][j] for t in range(m)), Fraction(0)) for j in range(n)] for i in range(n)]


def gram_eigen_intervals(G: list[list[Fraction]], eps: Fraction) -> list[tuple[Fraction, Fraction]] | None:
    """Exact isolation of all eigenvalues of the symmetric rational matrix G,
    ascending, with multiplicity.  Returns None if isolation fails."""
    import sympy
    lam = sympy.Symbol("lam")
    Gs = sympy.Matrix([[sympy.Rational(v.numerator, v.denominator) for v in row] for row in G])
    p = Gs.charpoly(lam)
    poly = sympy.Poly(p.as_expr(), lam)
    ivs = poly.intervals(eps=sympy.Rational(eps.numerator, eps.denominator))
    out: list[tuple[Fraction, Fraction]] = []
    for (a, b), mult in ivs:
        fa = Fraction(int(sympy.Rational(a).p), int(sympy.Rational(a).q))
        fb = Fraction(int(sympy.Rational(b).p), int(sympy.Rational(b).q))
        out.extend([(fa, fb)] * int(mult))
    if len(out) != len(G):
        return None
    out.sort()
    return out


def rank_exact_certificate_data(M_in, k: int) -> dict:
    M, exact_input = to_fraction_matrix(M_in)
    if not exact_input:
        return {"status": "unsupported", "reason": "rank_exact requires integer/rational entries (floats given)",
                "exact_input": False}
    r = exact_rank(M)
    res = {"rank": r, "k": k, "shape": [len(M), len(M[0])], "exact_input": True}
    if r > k:
        _, piv = rref(M)
        res.update(status="certified_no_member", pivots=piv,
                   argument=f"rank_Q(M) = {r} > k = {k} and rank(AB) <= k for every member")
    else:
        A, B = exact_factorization(M, k)
        res.update(status="witness_found", witness={"A": fmat(A), "B": fmat(B)})
    return res


def rank_approx_certificate_data(M_in, k: int, tolerance: float, exact_max_dim: int = 8,
                                 interval_eps: str = "1/1000000") -> dict:
    M, exact_input = to_fraction_matrix(M_in)
    m, n = len(M), len(M[0])
    Mf = np.array([[float(v) for v in row] for row in M], dtype=np.float64)
    s = np.linalg.svd(Mf, compute_uv=False)
    dim = min(m, n)
    tail_float = float(np.sum(s[k:] ** 2)) if k < dim else 0.0
    delta = 10.0 * max(m, n) * 2.0 ** -52 * (float(s[0]) if s.size else 0.0)
    tail_margin_lb = float(np.sum(np.maximum(s[k:] - delta, 0.0) ** 2)) if k < dim else 0.0
    res: dict[str, Any] = {"k": k, "shape": [m, n], "singular_values_float64": [float(v) for v in s],
                           "tail_float64": tail_float, "exact_input": exact_input}
    lb = None
    precision = None
    if dim <= exact_max_dim and k < dim:  # exact arithmetic on the stored values (floats = their binary values)
        G = gram_smaller(M)
        ivs = gram_eigen_intervals(G, Fraction(interval_eps))
        if ivs is not None:
            smallest = ivs[: dim - k]  # ascending: the dim-k smallest eigenvalues
            lows = [max(a, Fraction(0)) for a, _ in smallest]
            lbF = sum(lows, Fraction(0))
            lb = float(lbF)
            precision = "exact_rational_interval"
            res["gram_side"] = "M M^T" if m <= n else "M^T M"
            res["eigen_intervals_ascending"] = [[_fs(a), _fs(b)] for a, b in ivs]
            res["lower_endpoints_used"] = [_fs(v) for v in lows]
            res["lower_bound_exact"] = _fs(lbF)
            res["lower_bound_gt_tolerance_exact"] = bool(lbF > Fraction(tolerance))
    if lb is None:
        lb = tail_margin_lb
        precision = "float64_with_margin"
        res["delta_per_singular_value"] = delta
    if k >= dim:
        lb = 0.0
        precision = precision or "trivial"
    res["lower_bound"] = lb
    res["precision"] = precision
    if precision == "exact_rational_interval":
        certified = bool(res["lower_bound_gt_tolerance_exact"])
        res["status"] = "certified_lower_bound" if certified else None
    else:
        # float64 margin bound is a numerical statement, never a proof label
        res["status"] = "numerical_bound" if lb > tolerance else None
    if res["status"] is None:
        if tail_float <= tolerance * (1 + 1e-6) + 1e-12:
            U, sv, Vt = np.linalg.svd(Mf, full_matrices=False)
            A = U[:, :k] * sv[:k]
            B = Vt[:k]
            # exact error of the stored float witness, in rational arithmetic
            AF = [[Fraction(float(v)) for v in row] for row in A]
            BF = [[Fraction(float(v)) for v in row] for row in B]
            P = matmul(AF, BF)
            errF = sum(((M[i][j] - P[i][j]) ** 2 for i in range(m) for j in range(n)), Fraction(0))
            ok = errF <= Fraction(tolerance)
            res["status"] = "witness_found" if ok else "no_certificate"
            res["witness_check"] = {"exact_sq_error_of_stored_witness": float(errF), "meets_tolerance_exactly": bool(ok)}
            if ok:
                res["witness"] = {"A": A.tolist(), "B": B.tolist(), "frobenius_sq_error_exact": float(errF),
                                  "precision": "float64 entries; error evaluated exactly in rational arithmetic"}
        else:
            res["status"] = "no_certificate"
    return res


def random_integer_rank_matrix(rows: int, cols: int, rank: int, seed: int, low: int = -3, high: int = 3) -> list[list[int]]:
    from ..utils import np_gen
    g = np_gen(seed, "data", "rank_matrix", rows, cols, rank)
    A = g.integers(low, high + 1, size=(rows, rank))
    B = g.integers(low, high + 1, size=(rank, cols))
    return (A @ B).astype(int).tolist()
