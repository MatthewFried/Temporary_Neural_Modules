"""Finite transition systems for the complexity-ratchet question (I5).

A system is a finite Markov chain specified by explicit moves:
  initial_states() -> list of hashable states
  moves(s) -> list of (Fraction probability, next_state, label); probabilities
              sum exactly to 1 (rejected proposals appear as explicit self-loops)
  complexity(s) -> int, loss(s) -> Fraction|int
  spec() -> JSON description sufficient for the independent checker to
            re-derive moves.

Analysis (`analyze`):
  * BFS of the reachable state space, capped; hitting the cap or the deadline
    marks the analysis incomplete.  Incomplete analyses never carry
    impossibility or inevitability labels.
  * Iterative Tarjan SCC; closed classes are SCCs with no positive-probability
    edge leaving them.
  * Simple set S*: states with complexity <= threshold.  The threshold is given
    by the system/config or, only for complete searches, defaults to the minimum
    complexity over reachable states whose loss is <= the minimum initial loss.
  * Return labels per state, relative to S*:
      in_simple_set
      return_possible_zero_loss_path       a path to S* along which loss never exceeds loss(s)
      return_possible_only_via_higher_loss every path to S* visits a state with loss > loss(s)
      return_impossible                    no path to S* in the complete reachable graph
      unsearched                           incomplete search and no path found
      return_possible_witnessed_incomplete incomplete search, explicit path found (threshold given)
  * P(ever hit S*) and E[time to hit S*] (where P = 1), exact rational
    arithmetic when the number of unknowns is <= exact_max_transient, float64
    otherwise (flagged).
  * Inevitability: from an initial state, absorption into closed classes that
    contain no S* state ("bad" classes) is inevitable (probability 1) iff every
    closed class reachable from it is bad.  This uses only the finite-chain
    theorem that absorption into a closed class happens with probability 1 and
    graph reachability; it is reported only for complete searches.
"""
from __future__ import annotations

import time
from collections import deque
from fractions import Fraction
from itertools import combinations
from typing import Any, Hashable, Iterable

import numpy as np

F = Fraction


# ----------------------------------------------------------------------------
# Concrete systems
# ----------------------------------------------------------------------------

class TableSystem:
    """Hand-built chain: transitions[s] = [(prob_str, next, label), ...]."""

    kind = "table"

    def __init__(self, transitions: dict, complexity: dict, loss: dict, initial: list,
                 simple_threshold: int | None = None):
        self.T = {str(s): [(F(p), str(t), str(l)) for p, t, l in v] for s, v in transitions.items()}
        self.C = {str(k): int(v) for k, v in complexity.items()}
        self.L = {str(k): F(v) for k, v in loss.items()}
        self.init = [str(s) for s in initial]
        self.simple_threshold = simple_threshold
        for s, v in self.T.items():
            if sum(p for p, _, _ in v) != 1:
                raise ValueError(f"probabilities from {s} do not sum to 1")

    def initial_states(self):
        return list(self.init)

    def moves(self, s):
        return list(self.T[s])

    def complexity(self, s):
        return self.C[s]

    def loss(self, s):
        return self.L[s]

    def encode(self, s):
        return s

    def spec(self):
        return {"kind": "table",
                "transitions": {s: [[f"{p.numerator}/{p.denominator}", t, l] for p, t, l in v] for s, v in self.T.items()},
                "complexity": self.C, "loss": {k: str(v) for k, v in self.L.items()}, "initial": self.init,
                "simple_threshold": self.simple_threshold}


def absorbing_toy(with_good_closed_class: bool = False) -> TableSystem:
    """Validation system with a known no-return closed class {c3, c4}.

    s0 (complexity 1) is the simple state.  s1, s2 are transient.  {c3, c4} is
    closed with complexity 2.  s5 has loss 0 and can reach s0 only through s6
    (loss 1): a positive-loss return.  Variant: s0 made closed (good class),
    so entrenchment is possible but not inevitable.
    """
    h = "1/2"
    t = {
        "s0": [[h, "s0", "stay"], [h, "s1", "grow"]] if not with_good_closed_class else [["1", "s0", "stay"]],
        "s1": [["1/3", "s0", "shrink"], ["1/3", "s2", "grow"], ["1/3", "s1", "stay"]],
        "s2": [[h, "c3", "lock"], [h, "s1", "shrink"]],
        "c3": [["1", "c4", "drift"]],
        "c4": [["1", "c3", "drift"]],
        "s5": [[h, "s6", "up"], [h, "s5", "stay"]],
        "s6": [[h, "s0", "shrink"], [h, "s5", "down"]],
    }
    comp = {"s0": 1, "s1": 2, "s2": 3, "c3": 2, "c4": 2, "s5": 2, "s6": 2}
    loss = {"s0": 0, "s1": 0, "s2": 0, "c3": 0, "c4": 0, "s5": 0, "s6": 1}
    return TableSystem(t, comp, loss, initial=["s1", "s5"], simple_threshold=1)


def _compose(after: tuple, before: tuple) -> tuple:
    return tuple(after[before[x]] for x in range(len(before)))


def _chain_product(chain: tuple) -> tuple:
    m = len(chain[0])
    f = tuple(range(m))
    for T in chain:  # T_0 applied first
        f = _compose(T, f)
    return f


class PermutationChain:
    """Chain of L (1 <= L <= K) permutation modules of {0..m-1}; f = T_{L-1} o ... o T_0.

    Proposals (uniform over this deterministic list; a rejected proposal is a self-loop):
      paired(i, tau) for i < L-1 and every transposition tau:
          T_i <- tau o T_i, T_{i+1} <- T_{i+1} o tau   (always neutral, accepted)
      single(i, tau): T_i <- tau o T_i                   (accepted iff f unchanged: never)
      insert(pos) for pos in 0..L if L < K: identity module   (neutral, accepted)
      delete(i) if L > 1: accepted iff f unchanged (module is the identity)
    Acceptance = exact neutrality of the full-domain function.  complexity = L, loss = 0.
    Known positive control: S* = {L = 1} is reachable from every state.
    """

    kind = "permutation_chain"

    def __init__(self, m: int = 3, K: int = 3, start: list | None = None, simple_threshold: int = 1):
        self.m, self.K = int(m), int(K)
        if start is None:
            start = [[(i + 1) % m for i in range(m)]]
        self.start = tuple(tuple(int(v) for v in T) for T in start)
        for T in self.start:
            if sorted(T) != list(range(self.m)):
                raise ValueError("start modules must be permutations")
        if not 1 <= len(self.start) <= self.K:
            raise ValueError("start length out of range")
        self.target = _chain_product(self.start)
        self.taus = [(a, b) for a, b in combinations(range(self.m), 2)]
        self.simple_threshold = simple_threshold

    def _tau(self, a, b):
        t = list(range(self.m))
        t[a], t[b] = b, a
        return tuple(t)

    def initial_states(self):
        return [self.start]

    def proposals(self, s):
        L = len(s)
        out = []
        for i in range(L - 1):
            for a, b in self.taus:
                tau = self._tau(a, b)
                new = list(s)
                new[i] = _compose(tau, s[i])
                new[i + 1] = _compose(s[i + 1], tau)
                out.append((tuple(new), f"paired({i},{a}{b})"))
        for i in range(L):
            for a, b in self.taus:
                new = list(s)
                new[i] = _compose(self._tau(a, b), s[i])
                out.append((tuple(new), f"single({i},{a}{b})"))
        if L < self.K:
            ident = tuple(range(self.m))
            for pos in range(L + 1):
                out.append((s[:pos] + (ident,) + s[pos:], f"insert({pos})"))
        if L > 1:
            for i in range(L):
                out.append((s[:i] + s[i + 1:], f"delete({i})"))
        return out

    def moves(self, s):
        props = self.proposals(s)
        p = F(1, len(props))
        f0 = _chain_product(s)
        return [(p, t if _chain_product(t) == f0 else s, lab if _chain_product(t) == f0 else lab + ":rejected")
                for t, lab in props]

    def complexity(self, s):
        return len(s)

    def loss(self, s):
        return F(sum(1 for x, y in zip(_chain_product(s), self.target) if x != y))

    def encode(self, s):
        return [list(T) for T in s]

    def spec(self):
        return {"kind": self.kind, "m": self.m, "K": self.K, "start": self.encode(self.start),
                "simple_threshold": self.simple_threshold}


TERNARY = (-1, 0, 1)


class QuantizedChain:
    """Chain of L (min_len <= L <= K) modules on m hidden bits.

    Input x in {0,1}^m enters as the hidden state (bit j of the integer state);
    each module applies m ternary threshold units, unit j computing
    bit_j <- 1[sum_i w_{j,i} bit_i + b_j > 0] with w, b in {-1,0,1};
    the readout is bit 0 of the final hidden state.  A module is the tuple
    (w_{0,0..m-1}, b_0, w_{1,0..m-1}, b_1, ...).  The identity module (w = e_j, b = 0)
    is in the class.  loss(s) = number of x in {0,1}^m where readout != target(x).

    Proposals (uniform over this deterministic list; rejection = self-loop):
      insert(pos) identity module, pos = 0..L, if L < K
      mutate(i, p, v): parameter p of module i set to v != current value
      delete(i) if L > min_len
    Acceptance rule:
      neutral        accept iff the full-domain readout function is unchanged
      nonincreasing  accept iff loss(new) <= loss(old)
      metropolis     accept with probability min(1, r^(loss(new) - loss(old))), r rational in (0,1)
    complexity(s) = L.
    """

    kind = "quantized_chain"

    def __init__(self, m: int = 2, K: int = 2, min_len: int = 0, target: str | list = "and",
                 rule: str = "neutral", metropolis_r: str = "1/2", start: list | None = None,
                 simple_threshold: int | None = None):
        self.m, self.K, self.min_len = int(m), int(K), int(min_len)
        self.D = 2 ** self.m
        self.rule = rule
        if rule not in ("neutral", "nonincreasing", "metropolis"):
            raise ValueError(f"unknown acceptance rule {rule}")
        self.r = F(metropolis_r)
        if not 0 < self.r < 1:
            raise ValueError("metropolis_r must be in (0,1)")
        if isinstance(target, str):
            bits = [[(x >> j) & 1 for j in range(self.m)] for x in range(self.D)]
            fn = {"and": lambda b: int(b[0] and b[1]), "or": lambda b: int(b[0] or b[1]),
                  "xor": lambda b: b[0] ^ b[1], "first": lambda b: b[0], "second": lambda b: b[1],
                  "nand": lambda b: int(not (b[0] and b[1]))}[target]
            self.target = tuple(fn(b) for b in bits)
            self.target_name = target
        else:
            self.target = tuple(int(v) for v in target)
            self.target_name = "table"
        if len(self.target) != self.D:
            raise ValueError("target length must be 2^m")
        self.P = self.m * (self.m + 1)
        if start is None:
            start = [self.default_module()]
        self.start = tuple(tuple(int(v) for v in mod) for mod in start)
        for mod in self.start:
            if len(mod) != self.P or any(v not in TERNARY for v in mod):
                raise ValueError("bad start module")
        if not self.min_len <= len(self.start) <= self.K:
            raise ValueError("start length out of range")
        self.simple_threshold = simple_threshold
        self._map_cache: dict = {}

    def identity_module(self):
        mod = []
        for j in range(self.m):
            mod += [1 if i == j else 0 for i in range(self.m)] + [0]
        return tuple(mod)

    def default_module(self):
        """Module computing target into bit 0 when the target is AND/OR/XOR-free; else identity."""
        ident = list(self.identity_module())
        if self.target_name == "and":
            ident[0:self.m + 1] = [1, 1] + [0] * (self.m - 2) + [-1]
        elif self.target_name == "or":
            ident[0:self.m + 1] = [1, 1] + [0] * (self.m - 2) + [0]
        return tuple(ident)

    def module_map(self, mod: tuple) -> tuple:
        mp = self._map_cache.get(mod)
        if mp is None:
            out = []
            for h in range(self.D):
                bits = [(h >> i) & 1 for i in range(self.m)]
                nh = 0
                for j in range(self.m):
                    base = j * (self.m + 1)
                    z = sum(mod[base + i] * bits[i] for i in range(self.m)) + mod[base + self.m]
                    if z > 0:
                        nh |= 1 << j
                out.append(nh)
            mp = tuple(out)
            self._map_cache[mod] = mp
        return mp

    def readout(self, s: tuple) -> tuple:
        res = []
        for x in range(self.D):
            h = x
            for mod in s:
                h = self.module_map(mod)[h]
            res.append(h & 1)
        return tuple(res)

    def initial_states(self):
        return [self.start]

    def complexity(self, s):
        return len(s)

    def loss(self, s):
        return F(sum(1 for a, b in zip(self.readout(s), self.target) if a != b))

    def proposals(self, s):
        L = len(s)
        out = []
        if L < self.K:
            ident = self.identity_module()
            for pos in range(L + 1):
                out.append((s[:pos] + (ident,) + s[pos:], f"insert({pos})"))
        for i in range(L):
            for p in range(self.P):
                for v in TERNARY:
                    if v != s[i][p]:
                        mod = list(s[i])
                        mod[p] = v
                        out.append((s[:i] + (tuple(mod),) + s[i + 1:], f"mutate({i},{p},{v})"))
        if L > self.min_len:
            for i in range(L):
                out.append((s[:i] + s[i + 1:], f"delete({i})"))
        return out

    def accept_prob(self, s, t) -> Fraction:
        if self.rule == "neutral":
            return F(1) if self.readout(t) == self.readout(s) else F(0)
        d = self.loss(t) - self.loss(s)
        if self.rule == "nonincreasing":
            return F(1) if d <= 0 else F(0)
        if d <= 0:
            return F(1)
        assert d.denominator == 1
        return self.r ** int(d)

    def moves(self, s):
        props = self.proposals(s)
        p = F(1, len(props))
        out = []
        for t, lab in props:
            a = self.accept_prob(s, t)
            if a > 0:
                out.append((p * a, t, lab))
            if a < 1:
                out.append((p * (1 - a), s, lab + ":rejected"))
        return out

    def encode(self, s):
        return [list(mod) for mod in s]

    def spec(self):
        return {"kind": self.kind, "m": self.m, "K": self.K, "min_len": self.min_len, "target": list(self.target),
                "rule": self.rule, "metropolis_r": f"{self.r.numerator}/{self.r.denominator}",
                "start": self.encode(self.start), "simple_threshold": self.simple_threshold}


def build_system(name: str, params: dict):
    if name == "permutation_chain":
        return PermutationChain(**params)
    if name == "absorbing_toy":
        return absorbing_toy(**params)
    if name == "quantized_chain":
        return QuantizedChain(**params)
    if name == "table":
        return TableSystem(**params)
    raise ValueError(f"unknown system {name!r}")


# ----------------------------------------------------------------------------
# Analysis engine
# ----------------------------------------------------------------------------

def _fs(x: Fraction) -> str:
    return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"


def explore(system, state_cap: int, deadline: float | None = None) -> dict:
    index: dict[Hashable, int] = {}
    states: list = []
    succ: list[dict[int, Fraction]] = []
    labels: list[list[str]] = []
    expanded: list[bool] = []
    q: deque[int] = deque()
    complete = True
    reason = None
    for s in system.initial_states():
        if s not in index:
            index[s] = len(states)
            states.append(s)
            succ.append({})
            labels.append([])
            expanded.append(False)
            q.append(index[s])
    while q:
        if deadline is not None and time.time() > deadline:
            complete, reason = False, "deadline"
            break
        i = q.popleft()
        s = states[i]
        mv = system.moves(s)
        tot = sum((p for p, _, _ in mv), F(0))
        if tot != 1:
            raise ValueError(f"move probabilities from state {s!r} sum to {tot}, not 1")
        agg: dict[int, Fraction] = {}
        cap_hit = False
        for p, t, lab in mv:
            if p == 0:
                continue
            if p < 0:
                raise ValueError("negative probability")
            j = index.get(t)
            if j is None:
                if len(states) >= state_cap:
                    cap_hit = True
                    continue
                j = len(states)
                index[t] = j
                states.append(t)
                succ.append({})
                labels.append([])
                expanded.append(False)
                q.append(j)
            agg[j] = agg.get(j, F(0)) + p
        if cap_hit:
            complete, reason = False, "state_cap"
            # keep the partial successor list but mark the state as not fully expanded
            succ[i] = agg
            break
        succ[i] = agg
        expanded[i] = True
    if q:
        complete = False
        reason = reason or "unexpanded"
    return {"states": states, "index": index, "succ": succ, "expanded": expanded, "complete": complete,
            "incomplete_reason": reason, "n_initial": len(dict.fromkeys(system.initial_states()))}


def tarjan_scc(n: int, adj: list[list[int]]) -> list[int]:
    """Iterative Tarjan.  Returns comp id per node."""
    index = [-1] * n
    low = [0] * n
    onstack = [False] * n
    comp = [-1] * n
    stack: list[int] = []
    counter = 0
    ncomp = 0
    for root in range(n):
        if index[root] != -1:
            continue
        work = [(root, 0)]
        index[root] = low[root] = counter
        counter += 1
        stack.append(root)
        onstack[root] = True
        while work:
            v, pi = work[-1]
            if pi < len(adj[v]):
                work[-1] = (v, pi + 1)
                w = adj[v][pi]
                if index[w] == -1:
                    index[w] = low[w] = counter
                    counter += 1
                    stack.append(w)
                    onstack[w] = True
                    work.append((w, 0))
                elif onstack[w]:
                    low[v] = min(low[v], index[w])
            else:
                work.pop()
                if work:
                    u = work[-1][0]
                    low[u] = min(low[u], low[v])
                if low[v] == index[v]:
                    while True:
                        w = stack.pop()
                        onstack[w] = False
                        comp[w] = ncomp
                        if w == v:
                            break
                    ncomp += 1
    return comp


def _reach_from(sources: Iterable[int], adj: list[list[int]], allowed=None) -> set[int]:
    seen = set()
    dq = deque()
    for s in sources:
        if allowed is None or allowed(s):
            seen.add(s)
            dq.append(s)
    while dq:
        v = dq.popleft()
        for w in adj[v]:
            if w not in seen and (allowed is None or allowed(w)):
                seen.add(w)
                dq.append(w)
    return seen


def _solve_linear(A: list[list], b: list, exact: bool):
    n = len(b)
    if n == 0:
        return []
    if not exact:
        x = np.linalg.solve(np.array(A, dtype=np.float64), np.array(b, dtype=np.float64))
        return [float(v) for v in x]
    M = [row[:] + [b[i]] for i, row in enumerate(A)]
    for c in range(n):
        piv = next(i for i in range(c, n) if M[i][c] != 0)
        M[c], M[piv] = M[piv], M[c]
        pv = M[c][c]
        M[c] = [v / pv for v in M[c]]
        for i in range(n):
            if i != c and M[i][c] != 0:
                f = M[i][c]
                M[i] = [a - f * bb for a, bb in zip(M[i], M[c])]
    return [M[i][n] for i in range(n)]


def _solve_sparse_system(U: list[int], succ: list[dict[int, Fraction]], known: dict[int, Any], exact: bool,
                         const: int) -> dict[int, Any]:
    """Solve x_v = const + sum_w P(v,w) x_w for v in U, with x_w = known[w] for w not in U.
    Successors outside U must be in `known`.  Exact rationals or float64 (scipy sparse)."""
    if not U:
        return {}
    pos = {v: k for k, v in enumerate(U)}
    if exact:
        A = [[F(0)] * len(U) for _ in U]
        b = [F(const)] * len(U)
        for v in U:
            r = pos[v]
            A[r][r] += 1
            for w, p in succ[v].items():
                if w in pos:
                    A[r][pos[w]] -= p
                else:
                    b[r] += p * F(known[w])
        x = _solve_linear(A, b, True)
    else:
        import scipy.sparse as sp
        import scipy.sparse.linalg as spla
        rows, cols, vals = [], [], []
        b = np.full(len(U), float(const))
        for v in U:
            r = pos[v]
            rows.append(r); cols.append(r); vals.append(1.0)
            for w, p in succ[v].items():
                if w in pos:
                    rows.append(r); cols.append(pos[w]); vals.append(-float(p))
                else:
                    b[r] += float(p) * float(known[w])
        A = sp.csc_matrix((vals, (rows, cols)), shape=(len(U), len(U)))
        x = [float(v) for v in spla.spsolve(A, b)]
    return {v: x[pos[v]] for v in U}


def analyze(system, state_cap: int = 200_000, deadline: float | None = None, exact_max_transient: int = 80,
            long_time_threshold: float = 1000.0, simple_threshold: int | None = None,
            export_graph_max_states: int = 20000) -> dict:
    ex = explore(system, state_cap, deadline)
    states, succ, complete = ex["states"], ex["succ"], ex["complete"]
    n = len(states)
    adj = [sorted(d) for d in succ]
    radj: list[list[int]] = [[] for _ in range(n)]
    for i, d in enumerate(succ):
        for j in d:
            radj[j].append(i)
    comp_l = [int(system.complexity(s)) for s in states]
    loss_l = [F(system.loss(s)) for s in states]
    init_idx = list(range(ex["n_initial"]))

    thr = simple_threshold if simple_threshold is not None else getattr(system, "simple_threshold", None)
    thr_source = "given"
    if thr is None:
        if complete:
            min_init_loss = min(loss_l[i] for i in init_idx)
            cand = [comp_l[i] for i in range(n) if loss_l[i] <= min_init_loss]
            thr = min(cand)
            thr_source = "min_complexity_with_loss_le_min_initial_loss"
        else:
            thr_source = "undetermined_incomplete"
    simple = [thr is not None and comp_l[i] <= thr for i in range(n)]
    S_star = [i for i in range(n) if simple[i]]

    out: dict[str, Any] = {
        "system": system.spec(), "n_states": n, "complete": complete, "incomplete_reason": ex["incomplete_reason"],
        "state_cap": state_cap, "simple_threshold": thr, "simple_threshold_source": thr_source,
        "n_simple": len(S_star), "n_edges": sum(len(a) for a in adj), "long_time_threshold": long_time_threshold,
    }

    # --- return labels ---
    can_reach = _reach_from(S_star, radj) if thr is not None else set()
    labels = ["unsearched"] * n
    loss_levels = sorted(set(loss_l))
    zero_barrier = set()
    if thr is not None:
        for L in loss_levels:
            R = _reach_from([i for i in S_star if loss_l[i] <= L], radj, allowed=lambda v, L=L: loss_l[v] <= L)
            zero_barrier |= {i for i in R if loss_l[i] == L}
    for i in range(n):
        if thr is None:
            labels[i] = "unsearched"
        elif simple[i]:
            labels[i] = "in_simple_set"
        elif not complete:
            labels[i] = "return_possible_witnessed_incomplete" if i in can_reach else "unsearched"
        elif i not in can_reach:
            labels[i] = "return_impossible"
        elif i in zero_barrier:
            labels[i] = "return_possible_zero_loss_path"
        else:
            labels[i] = "return_possible_only_via_higher_loss"
    counts: dict[str, int] = {}
    for lab in labels:
        counts[lab] = counts.get(lab, 0) + 1
    out["return_label_counts"] = counts

    # --- SCCs, closed classes, inevitability ---
    if complete:
        comp = tarjan_scc(n, adj)
        ncomp = max(comp) + 1 if n else 0
        members: list[list[int]] = [[] for _ in range(ncomp)]
        for v, c in enumerate(comp):
            members[c].append(v)
        closed = [c for c in range(ncomp) if all(comp[w] == c for v in members[c] for w in adj[v])]
        closed_info = []
        for c in closed:
            mem = members[c]
            closed_info.append({"id": c, "size": len(mem), "contains_simple": any(simple[v] for v in mem),
                                "min_complexity": min(comp_l[v] for v in mem),
                                "max_complexity": max(comp_l[v] for v in mem),
                                "losses": sorted({str(loss_l[v]) for v in mem}),
                                "example_state": system.encode(states[mem[0]]),
                                **({"members": sorted(mem)} if n <= export_graph_max_states else {})})
        out["n_scc"] = ncomp
        out["closed_classes"] = closed_info
        bad = {ci["id"] for ci in closed_info if not ci["contains_simple"]}
        init_report = []
        for i in init_idx:
            R = _reach_from([i], adj)
            rc = sorted({comp[v] for v in R if comp[v] in set(closed)})
            init_report.append({"state": system.encode(states[i]), "complexity": comp_l[i], "loss": str(loss_l[i]),
                                "return_label": labels[i], "reachable_closed_classes": rc,
                                "bad_class_reachable": any(c in bad for c in rc),
                                "entrenchment_inevitable": bool(rc) and all(c in bad for c in rc)})
        out["initial"] = init_report

        # --- P(hit S*) = 1 test, graph-exact (S* made absorbing) ---
        adj_abs = [[] if simple[v] else adj[v] for v in range(n)]
        comp2 = tarjan_scc(n, adj_abs)
        nc2 = max(comp2) + 1 if n else 0
        mem2: list[list[int]] = [[] for _ in range(nc2)]
        for v, c in enumerate(comp2):
            mem2[c].append(v)
        closed2 = {c for c in range(nc2) if all(comp2[w] == c for v in mem2[c] for w in adj_abs[v])}
        good2 = {c for c in closed2 if all(simple[v] for v in mem2[c])}
        # P(hit S*) = 1 iff no closed class of the absorbing-S* chain that avoids S* is reachable
        radj_abs: list[list[int]] = [[] for _ in range(n)]
        for v in range(n):
            for w in adj_abs[v]:
                radj_abs[w].append(v)
        bad_members = [v for c in closed2 - good2 for v in mem2[c]]
        can_reach_bad = _reach_from(bad_members, radj_abs)
        hit_one = set(range(n)) - can_reach_bad
        # --- hitting probabilities: unknowns only where 0 < P(hit) < 1 is possible ---
        known = {}
        for v in range(n):
            if simple[v] or v in hit_one:
                known[v] = 1
            elif v not in can_reach:
                known[v] = 0
        U = [v for v in range(n) if v not in known]
        exact = len(U) <= exact_max_transient
        hU = _solve_sparse_system(U, succ, known, exact, const=0)
        hit: dict[int, Any] = {}
        for v in range(n):
            hit[v] = F(known[v]) if v in known else hU[v]
        # --- expected hitting time on states with P(hit) = 1 ---
        H = sorted(hit_one - set(S_star))
        exact_t = len(H) <= exact_max_transient
        tH = _solve_sparse_system(H, succ, {v: 0 for v in S_star}, exact_t, const=1)
        for rep, i in zip(out["initial"], init_idx):
            hv = hit[i]
            rep["p_hit_simple"] = (_fs(hv) if isinstance(hv, Fraction) else float(hv))
            rep["p_hit_simple_is_one_graph_exact"] = i in hit_one
            if simple[i]:
                rep["expected_time_to_simple"] = 0
            elif i in tH:
                tv = tH[i]
                rep["expected_time_to_simple"] = (_fs(tv) if isinstance(tv, Fraction) else float(tv))
                rep["long_expected_time"] = float(tv) > long_time_threshold
            else:
                rep["expected_time_to_simple"] = None  # infinite (P(hit) < 1)
        out["hitting_arithmetic"] = "exact_rational" if exact else "float64"
        out["time_arithmetic"] = "exact_rational" if exact_t else "float64"
    else:
        out["initial"] = [{"state": system.encode(states[i]), "complexity": comp_l[i], "loss": str(loss_l[i]),
                           "return_label": labels[i]} for i in init_idx]
        out["closed_classes"] = None
        out["note"] = "search incomplete: no closed-class, impossibility or inevitability statements"

    if n <= export_graph_max_states:
        out["graph"] = {
            "states": [system.encode(s) for s in states],
            "complexity": comp_l, "loss": [str(v) for v in loss_l], "initial": init_idx,
            "expanded": ex["expanded"],
            "edges": [[i, j, _fs(p)] for i, d in enumerate(succ) for j, p in sorted(d.items())],
            "labels": labels,
        }
    else:
        out["graph"] = None
    return out
