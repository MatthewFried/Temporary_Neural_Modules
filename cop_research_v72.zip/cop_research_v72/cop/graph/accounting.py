"""Parameter, compute and communication accounting (spec sections 13 and T16).

* parameters are counted once per storage (pkey), over live nodes;
* compute (MACs) is counted per INVOCATION, so a shared/recurrent module used
  s times costs s times its compute but its parameters once;
* per-position ops are multiplied by spatial positions (H*W) or tokens (T);
* communication through a peg is counted per example as
  positions x channels x bits for continuous/uniform pegs and
  positions x messages x ceil(log2 codebook) for codebook pegs; continuous
  coordinates are charged `float_bits` each (one real number is never one bit);
* codebooks, routers, adapters, encoders/decoders are ordinary parameters and
  are therefore always included.
"""
from __future__ import annotations

import math
from typing import Optional

from .graph import GraphNet


def active_inputs(g: GraphNet, nid: str) -> list[str]:
    """Inputs that can influence the node's value at current gate/coef values."""
    n = g.nodes[nid]
    if n.op == "gate_mix":
        gv = g.gate_vals[n.attrs["gate"]]
        if gv == 1.0:
            return [n.inputs[1]]
        if gv == 0.0:
            return [n.inputs[0]]
        return list(n.inputs)
    if n.op == "add":
        gates = n.attrs.get("gates") or [None] * len(n.inputs)
        out = []
        for i, c, gid in zip(n.inputs, n.attrs["coefs"], gates):
            w = c * (1.0 if gid is None else g.gate_vals[gid])
            if w != 0.0:
                out.append(i)
        return out
    return list(n.inputs)


def effective_live(g: GraphNet) -> set[str]:
    roots = [g.output] + list(g.side_outputs.values())
    live, stack = set(), [r for r in roots if r]
    while stack:
        n = stack.pop()
        if n in live:
            continue
        live.add(n)
        stack.extend(active_inputs(g, n))
    return live


def has_bypass(g: GraphNet, separator: set[str], sources: Optional[list[str]] = None,
               target: Optional[str] = None) -> bool:
    """True if information can flow from any source input to the target while
    avoiding every separator node (edges with zero effective weight ignored)."""
    sources = sources if sources is not None else list(g.inputs.values())
    target = target or g.output
    stack, seen = [target], set()
    while stack:
        n = stack.pop()
        if n in seen or n in separator:
            continue
        seen.add(n)
        if n in sources:
            return True
        stack.extend(active_inputs(g, n))
    return False


def _positions(attrs: dict, layout: str, T: int) -> int:
    if layout == "img":
        hw = attrs.get("hw", [1, 1])
        return int(hw[0]) * int(hw[1])
    if layout == "seq":
        return T
    return 1


def count_params(g: GraphNet, effective: bool = True) -> dict:
    live = effective_live(g)
    pks: dict[str, str] = {}
    for nid in live:
        n = g.nodes[nid]
        if n.pkey is not None:
            pks.setdefault(n.pkey, nid)
    total, by_owner, by_role = 0, {}, {}
    for pk, nid in pks.items():
        n = g.nodes[nid]
        m = g.mods[pk]
        cnt = sum(p.numel() for p in m.parameters())
        if effective and n.op == "concat_proj" and not all(n.attrs["active"]):
            act_cols = sum(d for d, a in zip(n.attrs["term_dims"], n.attrs["active"]) if a)
            cnt = m.weight.shape[0] * act_cols + (m.bias.numel() if m.bias is not None else 0)
        if effective and n.op == "route" and not all(n.attrs["active"]):
            rows = sum(n.attrs["active"])
            cnt = rows * (m.weight.shape[1] + 1)
        total += cnt
        o = n.owner or "backbone"
        by_owner[o] = by_owner.get(o, 0) + cnt
        by_role[n.role] = by_role.get(n.role, 0) + cnt
    return {"total": total, "by_owner": by_owner, "by_role": by_role, "n_storage_units": len(pks)}


def count_macs(g: GraphNet, T: int = 1) -> dict:
    """Multiply-accumulates per example for one forward pass (per invocation)."""
    live = effective_live(g)
    total, elementwise, by_owner, by_node = 0, 0, {}, {}
    for nid in live:
        n = g.nodes[nid]
        a = n.attrs
        lay = a.get("layout", g.layout)
        P = _positions(a, lay, T)
        macs = 0
        if n.op in ("linear", "linear_inverse"):
            if n.op == "linear":
                m = g.mods[n.pkey]
                macs = m.in_features * m.out_features * P
            else:
                d = a["dim"]
                macs = d * d * P + d ** 3  # inverse recomputed per forward
        elif n.op == "conv":
            m = g.mods[n.pkey]
            k = m.kernel_size[0] * m.kernel_size[1]
            macs = k * m.in_channels * m.out_channels * P // (m.groups or 1)
        elif n.op == "attn":
            d = a["dim"]
            macs = 4 * d * d * T + 2 * T * T * d
        elif n.op == "gru":
            m = g.mods[n.pkey]
            macs = 3 * (m.input_size * m.hidden_size + m.hidden_size * m.hidden_size) * T
        elif n.op == "concat_proj":
            act_cols = sum(d for d, on in zip(a["term_dims"], a["active"]) if on)
            macs = act_cols * a["dim"] * P
        elif n.op == "route":
            k = sum(a["active"])
            macs = a["router_in"] * k * P + k * a["dim"] * P
        elif n.op == "quant":
            q = g.mods[n.pkey]
            if q.mode == "vq":
                macs = q.codebook_size * q.k * P
            elif q.mode == "multi":
                macs = q.codebook_size * q.k * P
        elif n.op == "module":
            m = g.mods[n.pkey]
            macs = (m.macs_per_position() if hasattr(m, "macs_per_position") else 0) * P
        elif n.op in ("act", "add", "bn", "ln", "gate_mix", "pos_mix", "scatter", "mask_grad", "scale"):
            elementwise += int(a.get("dim", 0)) * P
        total += macs
        by_node[nid] = int(macs)
        o = n.owner or "backbone"
        by_owner[o] = by_owner.get(o, 0) + macs
    return {"macs": int(total), "elementwise": int(elementwise), "by_owner": by_owner, "by_node": by_node,
            "method": "analytic per-node MAC count; shared modules counted per invocation; T=%d" % T}


def peg_messages(g: GraphNet, T: int = 1, float_bits: int = 32) -> list[dict]:
    """Communication per example through every quantiser (peg) node."""
    out = []
    live = effective_live(g)
    for nid in sorted(live, key=lambda s: int(s[1:])):
        n = g.nodes[nid]
        if n.op != "quant":
            continue
        q = g.mods[n.pkey]
        P = _positions(n.attrs, n.attrs.get("layout", g.layout), T)
        if q.mode == "none":
            bits = q.k * float_bits
            per = f"{q.k} coords x {float_bits} bits"
        elif q.mode == "uniform":
            bits = q.k * q.bits
            per = f"{q.k} coords x {q.bits} bits"
        elif q.mode == "vq":
            bits = math.ceil(math.log2(q.codebook_size))
            per = f"1 message x {bits} bits"
        else:
            bits = q.n_messages * math.ceil(math.log2(q.codebook_size))
            per = f"{q.n_messages} messages x {math.ceil(math.log2(q.codebook_size))} bits"
        cb = 0
        if hasattr(q, "codebook"):
            cb = q.codebook.numel()
        out.append({"node": nid, "owner": n.owner, "mode": q.mode, "positions": P, "bits_per_position": bits,
                    "bits_per_example": bits * P, "per_position": per, "codebook_params": cb})
    return out


def report(g: GraphNet, T: int = 1, float_bits: int = 32) -> dict:
    """Inference cost of the effective graph: parameters, MACs, parameter and buffer
    bytes, activation values per example (every live node's output; an upper bound on
    the activation memory of one example), and the bits sent across declared pegs."""
    p = count_params(g)
    msgs = peg_messages(g, T, float_bits)
    live = effective_live(g)
    act_vals = 0
    for nid in live:
        a = g.nodes[nid].attrs
        if "dim" in a:
            act_vals += int(a["dim"]) * _positions(a, a.get("layout", g.layout), T)
    buf = sum(b.numel() * b.element_size() for pk, m in g.mods.items() for b in m.buffers()
              if any(g.nodes[n].pkey == pk for n in live))
    return {"params": p["total"], "params_by_owner": p["by_owner"], "storage_units": p["n_storage_units"],
            "param_bytes_fp32": 4 * p["total"], "buffer_bytes": int(buf), "activation_values_per_example": act_vals,
            **{k: v for k, v in count_macs(g, T).items() if k not in ("by_owner", "by_node")},
            "messages": msgs, "peg_bits_per_example": int(sum(m.get("bits_per_example", 0) for m in msgs)),
            "structural_hash": g.structural_hash()}


# ----------------------------------------------------------------------------- architecture identity
_COSMETIC = {"terms", "role", "note"}


def _node_signature(g: GraphNet, nid: str) -> tuple:
    """Architecture-relevant description of one node, independent of node ids,
    owners, roles and parameter values: op, shape attributes and parameter shapes
    (read from the module itself, so e.g. a folded linear and the original linear
    agree when their shapes and bias presence agree)."""
    n = g.nodes[nid]
    a = n.attrs
    mod = g.mods[n.pkey] if n.pkey is not None else None
    if n.op == "linear":
        return ("linear", tuple(mod.weight.shape), mod.bias is not None)
    if n.op == "conv":
        return ("conv", tuple(mod.weight.shape), mod.bias is not None, tuple(mod.stride), tuple(mod.padding))
    if n.op == "input":
        return ("input", a.get("stream"), a.get("dim"))
    if n.op == "act":
        return ("act", a["fn"], a.get("base"), a.get("s"))
    pshapes = tuple(sorted((k, tuple(p.shape)) for k, p in mod.named_parameters())) if mod is not None else ()
    keep = tuple(sorted((k, repr(v)) for k, v in a.items() if k not in _COSMETIC))
    return (n.op, keep, pshapes)


def node_keys(g: GraphNet) -> dict[str, str]:
    """Merkle key of every effective live node: its architecture signature and the keys
    of its inputs (identity nodes transparent).  Independent of node ids and weights."""
    import hashlib
    import sys
    live = effective_live(g)
    memo: dict[str, str] = {}

    def key(nid: str) -> str:
        if nid in memo:
            return memo[nid]
        ins = [key(i) for i in active_inputs(g, nid)] if nid in live else []
        if g.nodes[nid].op == "identity" and len(ins) == 1:
            memo[nid] = ins[0]
            return memo[nid]
        h = hashlib.sha256(repr((_node_signature(g, nid), ins)).encode()).hexdigest()
        memo[nid] = h
        return h

    old = sys.getrecursionlimit()
    sys.setrecursionlimit(max(old, 10000))
    try:
        for nid in sorted(live, key=lambda s_: int(s_[1:])):
            key(nid)
    finally:
        sys.setrecursionlimit(old)
    return memo


def _canonical_order(g: GraphNet) -> tuple[list, dict]:
    """Canonical serialisation of the effective graph: depth-first from the output (then the side
    outputs in name order), inputs in their (semantically ordered) positions, identity nodes
    transparent.  A node gets the index of its first visit; a later visit is a back-reference to
    that index, so the serialisation records which inputs are the SAME node, not merely nodes with
    equal Merkle keys.  Node ids never enter.  Returns (serialisation, {node id: index})."""
    import sys
    live = effective_live(g)
    idx: dict[str, int] = {}
    ser: list = []

    def through(nid: str) -> str:
        while g.nodes[nid].op == "identity":
            ins = active_inputs(g, nid) if nid in live else []
            if len(ins) != 1:
                break
            nid = ins[0]
        return nid

    def visit(nid: str) -> None:
        nid = through(nid)
        if nid in idx:
            ser.append(("ref", idx[nid]))
            return
        idx[nid] = len(idx)
        ins = active_inputs(g, nid) if nid in live else []
        ser.append(("node", _node_signature(g, nid), len(ins)))
        for i in ins:
            visit(i)

    old = sys.getrecursionlimit()
    sys.setrecursionlimit(max(old, 10000))
    try:
        visit(g.output)
        for _, v in sorted(g.side_outputs.items()):
            ser.append(("side_output",))
            visit(v)
    finally:
        sys.setrecursionlimit(old)
    return ser, idx


def sharing_classes(g: GraphNet, keys: Optional[dict] = None) -> list:
    """Canonical parameter-storage equivalence classes of the effective graph: for every storage
    unit (pkey) used by more than one live node, the sorted canonical indices (_canonical_order) of
    the nodes that use it.  Independent of pkey names and node ids; empty when nothing is shared.
    Indices, not Merkle keys: structurally symmetric nodes have equal Merkle keys, so key tuples
    cannot tell which of them is tied to which (A1=B1, A2=B2 versus A1=B2, A2=B1)."""
    return _shared_positions(g, _canonical_order(g)[1])


def _shared_positions(g: GraphNet, idx: dict) -> list:
    by_pk: dict[str, list[int]] = {}
    for nid, i in idx.items():
        pk = g.nodes[nid].pkey
        if pk is not None:
            by_pk.setdefault(pk, []).append(i)
    return sorted(tuple(sorted(v)) for v in by_pk.values() if len(v) > 1)


def architecture_hash(g: GraphNet) -> str:
    """Hash of the effective graph's architecture: the canonical serialisation (operations, shapes,
    ordered wiring, and which inputs are the same node; no node ids, no weights) AND the
    parameter-sharing pattern as classes of canonical positions (V3-08).  Equal hashes mean the same
    parameterised family up to node renaming: same operations, same wiring, same tied tensors.  It
    says nothing about equal parameter VALUES or equal functions at one parameter setting.  Used to
    assert that a contracted export returns to the f0 architecture and to classify comparison
    contracts."""
    import hashlib
    ser, idx = _canonical_order(g)
    return hashlib.sha256(repr((ser, _shared_positions(g, idx))).encode()).hexdigest()[:16]


def transfer_by_architecture(src: GraphNet, dst: GraphNet) -> list:
    """Copy every module state (parameters and buffers) of `src` into the
    architecturally corresponding module of `dst` (same Merkle key; repeated keys
    matched in topological order).  Requires equal architecture hashes.  Returns the
    (src_param, dst_param) pairs, e.g. to carry optimizer state."""
    import torch
    if architecture_hash(src) != architecture_hash(dst):
        raise ValueError("architectures differ; cannot transfer by correspondence")
    ks, kd = node_keys(src), node_keys(dst)
    by_key: dict[str, list[str]] = {}
    for nid in src.topo_order(effective_live(src)):
        if src.nodes[nid].pkey is not None:
            by_key.setdefault(ks[nid], []).append(nid)
    used: dict[str, int] = {}
    pairs = []
    for nid in dst.topo_order(effective_live(dst)):
        pk = dst.nodes[nid].pkey
        if pk is None:
            continue
        cand = by_key.get(kd[nid], [])
        i = used.get(kd[nid], 0)
        if i >= len(cand):
            raise ValueError(f"no corresponding module for {nid}")
        used[kd[nid]] = i + 1
        sm, dm = src.mods[src.nodes[cand[i]].pkey], dst.mods[pk]
        with torch.no_grad():
            dm.load_state_dict({k_: v.detach().clone() for k_, v in sm.state_dict().items()})
        pairs += list(zip(sm.parameters(), dm.parameters()))
    return pairs
