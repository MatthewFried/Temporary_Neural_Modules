"""Model families as GraphNets with tagged cutpoints and duplicable segments.

Cutpoint kinds (spec section 6, cut types C1-C4):
  MLP          input, pre_act (Linear->act edge), post_act (act->next Linear edge)
  CNN/ResNet   pre_bn (conv->bn), post_bn (bn->relu), post_act, block_out (node with
               several consumers; subsets 'branch' and 'skip'), resid_branch
               (residual branch output edge into the add)
  Transformer  resid (residual stream; subsets 'branch' (into LayerNorm) and 'skip'),
               attn_out (attention output edge into the add), mlp_out (MLP branch
               output edge into the add), mlp_hidden (act->fc2)
  GRU          gru_out
Segments (meta['segments']) are single-input node chains that the duplicated
branch construction (C) can copy.
"""
from __future__ import annotations

from typing import Optional

import torch

from .graph import GraphNet
from .ops import init_module


def _init_all(g: GraphNet, gen: torch.Generator, scheme: str) -> None:
    for nid in sorted(g.nodes, key=lambda s: int(s[1:])):
        n = g.nodes[nid]
        if n.pkey is None:
            continue
        m = g.mods[n.pkey]
        sch = scheme
        if n.op in ("bn", "ln"):
            sch = "default"
        if n.role == "head" and scheme == "kaiming":
            sch = "lecun"
        init_module(m, gen, sch)


def _edges_from(g: GraphNet, nid: str) -> list[tuple[str, int]]:
    return g.consumers(nid)


# ----------------------------------------------------------------------------- MLP

def build_mlp(d_in: int, widths: list[int], d_out: int, gen: torch.Generator, act: str = "relu",
              init: Optional[str] = None, bn: bool = False, query: Optional[dict] = None,
              in_stream: str = "x") -> GraphNet:
    """Plain MLP.  `query={'dim': n_q, 'at_layer': j}` injects a late input stream
    'q' by concatenation after hidden layer j (j=-1: at the input, the
    query-known-early control)."""
    g = GraphNet("vec", "mlp")
    x = g.set_input(in_stream, d_in)
    h, d = x, d_in
    q_node = None
    if query is not None:
        q_node = g.set_input("q", query["dim"])
        if query["at_layer"] == -1:
            h = g.add_node("concat", [x, q_node], {"dim": d_in + query["dim"]}, role="query_inject")
            d = d_in + query["dim"]
            g.meta["query_injection"] = h
    lins, acts = [], []
    for k, w in enumerate(widths):
        lin = g.add_node("linear", [h], {"in": d, "out": w, "dim": w}, role=f"L{k}.lin", build=True)
        cur = lin
        if bn:
            cur = g.add_node("bn", [lin], {"dim": w}, role=f"L{k}.bn", build=True)
        a = g.add_node("act", [cur], {"fn": act, "dim": w}, role=f"L{k}.act")
        lins.append(lin)
        acts.append(a)
        h, d = a, w
        if query is not None and query["at_layer"] == k:
            h = g.add_node("concat", [a, q_node], {"dim": w + query["dim"]}, role="query_inject")
            d = w + query["dim"]
            g.meta["query_injection"] = h
    head = g.add_node("linear", [h], {"in": d, "out": d_out, "dim": d_out}, role="head", build=True)
    g.set_output(head)
    first = lins[0] if lins else head
    g.add_cutpoint("input", "input", 0, [(c, s) for c, s in g.consumers(x) if c == first or c == g.meta.get("query_injection")])
    for k, (lin, a) in enumerate(zip(lins, acts)):
        pre_cons = g.consumers(lin)
        g.add_cutpoint(f"L{k}.pre_act", "pre_act", k, pre_cons)
        g.add_cutpoint(f"L{k}.post_act", "post_act", k, g.consumers(a))
        seg = [lin] + ([g.consumers(lin)[0][0]] if bn else []) + [a]
        g.meta.setdefault("segments", []).append({"name": f"L{k}", "nodes": seg})
    g.meta["arch"] = {"family": "mlp", "d_in": d_in, "widths": list(widths), "d_out": d_out, "act": act, "bn": bn,
                      "query": query}
    _init_all(g, gen, init or ("xavier" if act in ("tanh", "identity", "sigmoid") else "kaiming"))
    return g


# ----------------------------------------------------------------------------- CNN

def build_cnn(in_ch: int, hw: tuple[int, int], n_classes: int, gen: torch.Generator, width_mult: float = 1.0,
              init: str = "kaiming") -> GraphNet:
    """Small documented CNN: [conv-bn-relu]x2 -> maxpool -> [conv-bn-relu]x2 -> maxpool -> GAP -> linear."""
    g = GraphNet("img", "cnn")
    H, W = hw
    x = g.set_input("x", in_ch, hw=[H, W])
    c1, c2 = max(4, int(round(32 * width_mult))), max(4, int(round(64 * width_mult)))
    h, c = x, in_ch
    k = 0
    for stage, cs in enumerate([c1, c2]):
        for j in range(2):
            conv = g.add_node("conv", [h], {"in": c, "out": cs, "k": 3, "bias": False, "dim": cs, "hw": [H, W]},
                              role=f"S{stage}.{j}.conv", build=True)
            bn = g.add_node("bn", [conv], {"dim": cs, "hw": [H, W]}, role=f"S{stage}.{j}.bn", build=True)
            r = g.add_node("act", [bn], {"fn": "relu", "dim": cs, "hw": [H, W]}, role=f"S{stage}.{j}.act")
            g.meta.setdefault("_conv", []).append((conv, bn, r))
            h, c = r, cs
            k += 1
        h = g.add_node("pool", [h], {"k": 2, "kind": "max", "dim": c, "hw": [H // 2, W // 2]}, role=f"S{stage}.pool")
        H, W = H // 2, W // 2
    gp = g.add_node("gap", [h], {"dim": c, "layout": "vec"}, role="gap")
    head = g.add_node("linear", [gp], {"in": c, "out": n_classes, "dim": n_classes, "layout": "vec"}, role="head",
                      build=True)
    g.set_output(head)
    for i, (conv, bn, r) in enumerate(g.meta.pop("_conv")):
        g.add_cutpoint(f"C{i}.pre_bn", "pre_bn", i, g.consumers(conv))
        g.add_cutpoint(f"C{i}.post_bn", "post_bn", i, g.consumers(bn))
        g.add_cutpoint(f"C{i}.post_act", "post_act", i, g.consumers(r))
        g.meta.setdefault("segments", []).append({"name": f"C{i}", "nodes": [conv, bn, r]})
    g.meta["arch"] = {"family": "cnn", "in_ch": in_ch, "hw": list(hw), "n_classes": n_classes,
                      "width_mult": width_mult}
    _init_all(g, gen, init)
    return g


def build_cnn_cut(in_ch: int, hw: tuple[int, int], n_classes: int, gen: torch.Generator, width_mult: float = 1.0,
                  init: str = "kaiming") -> GraphNet:
    """v65: a small CNN without normalisation layers whose middle cut feeds a 1x1 RECEIVING layer present in every
    network built from it:
      conv3x3(in -> c1)-relu, conv3x3(c1 -> c1)-relu, maxpool2   [cut: post_act, the middle]
      1x1 linear(c1 -> c2)-relu   (the receiving layer: unpadded, position-wise)
      conv3x3(c2 -> c2)-relu, maxpool2, global average pool   [cut: penultimate]
      linear(c2 -> classes)
    c1 = 32, c2 = 64 at width_mult 1.  Additions inserted at the middle cut are read by the receiving layer with no
    activation in between, so an affine addition h -> A h + c folds into it exactly (W A, b + W c) at every position,
    the border included (a 1x1 layer has no padding).  The penultimate cut (pooled features, vector layout) is where a
    late temporary head sits (the projection-head comparison).  Every layer has a bias."""
    g = GraphNet("img", "cnn_cut")
    H, W = hw
    x = g.set_input("x", in_ch, hw=[H, W])
    c1, c2 = max(4, int(round(32 * width_mult))), max(4, int(round(64 * width_mult)))
    k1 = g.add_node("conv", [x], {"in": in_ch, "out": c1, "k": 3, "bias": True, "dim": c1, "hw": [H, W]},
                    role="S0.0.conv", build=True)
    a1 = g.add_node("act", [k1], {"fn": "relu", "dim": c1, "hw": [H, W]}, role="S0.0.act")
    k2 = g.add_node("conv", [a1], {"in": c1, "out": c1, "k": 3, "bias": True, "dim": c1, "hw": [H, W]},
                    role="S0.1.conv", build=True)
    a2 = g.add_node("act", [k2], {"fn": "relu", "dim": c1, "hw": [H, W]}, role="S0.1.act")
    H, W = H // 2, W // 2
    p1 = g.add_node("pool", [a2], {"k": 2, "kind": "max", "dim": c1, "hw": [H, W]}, role="S0.pool")
    rv = g.add_node("linear", [p1], {"in": c1, "out": c2, "bias": True, "dim": c2, "hw": [H, W]}, role="S1.recv",
                    build=True)
    a3 = g.add_node("act", [rv], {"fn": "relu", "dim": c2, "hw": [H, W]}, role="S1.recv_act")
    k3 = g.add_node("conv", [a3], {"in": c2, "out": c2, "k": 3, "bias": True, "dim": c2, "hw": [H, W]},
                    role="S1.conv", build=True)
    a4 = g.add_node("act", [k3], {"fn": "relu", "dim": c2, "hw": [H, W]}, role="S1.act")
    H, W = H // 2, W // 2
    p2 = g.add_node("pool", [a4], {"k": 2, "kind": "max", "dim": c2, "hw": [H, W]}, role="S1.pool")
    gp = g.add_node("gap", [p2], {"dim": c2, "layout": "vec"}, role="gap")
    head = g.add_node("linear", [gp], {"in": c2, "out": n_classes, "dim": n_classes, "layout": "vec"}, role="head",
                      build=True)
    g.set_output(head)
    g.add_cutpoint("S0.post_pool", "post_act", 0, g.consumers(p1))
    g.add_cutpoint("penultimate", "penultimate", 0, g.consumers(gp))
    g.meta["segments"] = [{"name": "S0.0", "nodes": [k1, a1]}, {"name": "S0.1", "nodes": [k2, a2]},
                          {"name": "S1.recv", "nodes": [rv, a3]}, {"name": "S1.conv", "nodes": [k3, a4]}]
    g.meta["receiving_layer"] = rv
    g.meta["arch"] = {"family": "cnn_cut", "in_ch": in_ch, "hw": list(hw), "n_classes": n_classes,
                      "width_mult": width_mult}
    _init_all(g, gen, init)
    return g


def build_resnet(in_ch: int, hw: tuple[int, int], n_classes: int, gen: torch.Generator, width_mult: float = 1.0,
                 blocks_per_stage: int = 1, init: str = "kaiming") -> GraphNet:
    """CIFAR-style ResNet (3 stages; blocks_per_stage=1 -> ResNet-8, 2 -> ResNet-14)."""
    g = GraphNet("img", "resnet")
    H, W = hw
    x = g.set_input("x", in_ch, hw=[H, W])
    chans = [max(4, int(round(c * width_mult))) for c in (16, 32, 64)]
    conv = g.add_node("conv", [x], {"in": in_ch, "out": chans[0], "k": 3, "bias": False, "dim": chans[0],
                                    "hw": [H, W]}, role="stem.conv", build=True)
    bn = g.add_node("bn", [conv], {"dim": chans[0], "hw": [H, W]}, role="stem.bn", build=True)
    h = g.add_node("act", [bn], {"fn": "relu", "dim": chans[0], "hw": [H, W]}, role="stem.act")
    c = chans[0]
    blocks = []
    bi = 0
    for s, cs in enumerate(chans):
        for j in range(blocks_per_stage):
            stride = 2 if (s > 0 and j == 0) else 1
            H2, W2 = (H // stride, W // stride)
            c1 = g.add_node("conv", [h], {"in": c, "out": cs, "k": 3, "stride": stride, "padding": 1, "bias": False,
                                          "dim": cs, "hw": [H2, W2]}, role=f"B{bi}.conv1", build=True)
            b1 = g.add_node("bn", [c1], {"dim": cs, "hw": [H2, W2]}, role=f"B{bi}.bn1", build=True)
            r1 = g.add_node("act", [b1], {"fn": "relu", "dim": cs, "hw": [H2, W2]}, role=f"B{bi}.act1")
            c2 = g.add_node("conv", [r1], {"in": cs, "out": cs, "k": 3, "bias": False, "dim": cs, "hw": [H2, W2]},
                            role=f"B{bi}.conv2", build=True)
            b2 = g.add_node("bn", [c2], {"dim": cs, "hw": [H2, W2]}, role=f"B{bi}.bn2", build=True)
            if stride != 1 or c != cs:
                pc = g.add_node("conv", [h], {"in": c, "out": cs, "k": 1, "stride": stride, "padding": 0,
                                              "bias": False, "dim": cs, "hw": [H2, W2]}, role=f"B{bi}.proj", build=True)
                skip = g.add_node("bn", [pc], {"dim": cs, "hw": [H2, W2]}, role=f"B{bi}.projbn", build=True)
            else:
                skip = h
            add = g.add_node("add", [skip, b2], {"coefs": [1.0, 1.0], "terms": ["skip", "branch"], "dim": cs,
                                                 "hw": [H2, W2]}, role=f"B{bi}.add")
            out = g.add_node("act", [add], {"fn": "relu", "dim": cs, "hw": [H2, W2]}, role=f"B{bi}.out")
            blocks.append({"in": h, "conv1": c1, "bn1": b1, "act1": r1, "conv2": c2, "bn2": b2, "add": add,
                           "out": out, "identity_skip": skip == h,
                           "skip_edge": [add, 0] if skip == h else [pc, 0]})
            h, c, H, W = out, cs, H2, W2
            bi += 1
    gp = g.add_node("gap", [h], {"dim": c, "layout": "vec"}, role="gap")
    head = g.add_node("linear", [gp], {"in": c, "out": n_classes, "dim": n_classes, "layout": "vec"}, role="head",
                      build=True)
    g.set_output(head)
    for i, b in enumerate(blocks):
        cons = g.consumers(b["out"])
        subsets = {}
        if i + 1 < len(blocks):
            nb = blocks[i + 1]
            subsets = {"branch": [[nb["conv1"], 0]], "skip": [nb["skip_edge"]]}
        g.add_cutpoint(f"B{i}.out", "block_out", i, cons, subsets=subsets)
        g.add_cutpoint(f"B{i}.resid_branch", "resid_branch", i, [(b["add"], 1)])
        g.add_cutpoint(f"B{i}.post_act", "post_act", i, g.consumers(b["act1"]))
        g.add_cutpoint(f"B{i}.pre_bn", "pre_bn", i, g.consumers(b["conv1"]))
        g.add_cutpoint(f"B{i}.post_bn", "post_bn", i, g.consumers(b["bn1"]))
        g.meta.setdefault("segments", []).append(
            {"name": f"B{i}.branch", "nodes": [b["conv1"], b["bn1"], b["act1"], b["conv2"], b["bn2"]]})
    g.meta["arch"] = {"family": "resnet", "in_ch": in_ch, "hw": list(hw), "n_classes": n_classes,
                      "width_mult": width_mult, "blocks_per_stage": blocks_per_stage}
    _init_all(g, gen, init)
    return g


# ----------------------------------------------------------------------------- sequence

def build_transformer(vocab: int, d: int, n_blocks: int, heads: int, n_out: int, gen: torch.Generator,
                      mlp_mult: int = 4, max_len: int = 512, pos: str = "sin", causal: bool = True,
                      act: str = "gelu") -> GraphNet:
    """Pre-LN causal Transformer, dropout-free; per-position logits."""
    if d % heads:
        raise ValueError("d must be divisible by heads")
    g = GraphNet("seq", "transformer")
    x = g.set_input("x", 1, dtype="long")
    h = g.add_node("embed", [x], {"vocab": vocab, "dim": d, "max_len": max_len, "pos": pos}, role="embed", build=True)
    blocks = []
    for i in range(n_blocks):
        ln1 = g.add_node("ln", [h], {"dim": d}, role=f"T{i}.ln1", build=True)
        at = g.add_node("attn", [ln1], {"dim": d, "heads": heads, "causal": causal}, role=f"T{i}.attn", build=True)
        a1 = g.add_node("add", [h, at], {"coefs": [1.0, 1.0], "terms": ["skip", "attn"], "dim": d}, role=f"T{i}.add1")
        ln2 = g.add_node("ln", [a1], {"dim": d}, role=f"T{i}.ln2", build=True)
        f1 = g.add_node("linear", [ln2], {"in": d, "out": mlp_mult * d, "dim": mlp_mult * d}, role=f"T{i}.fc1",
                        build=True)
        ac = g.add_node("act", [f1], {"fn": act, "dim": mlp_mult * d}, role=f"T{i}.act")
        f2 = g.add_node("linear", [ac], {"in": mlp_mult * d, "out": d, "dim": d}, role=f"T{i}.fc2", build=True)
        a2 = g.add_node("add", [a1, f2], {"coefs": [1.0, 1.0], "terms": ["skip", "mlp"], "dim": d}, role=f"T{i}.add2")
        blocks.append({"in": h, "ln1": ln1, "attn": at, "add1": a1, "ln2": ln2, "fc1": f1, "act": ac, "fc2": f2,
                       "add2": a2})
        h = a2
    lnf = g.add_node("ln", [h], {"dim": d}, role="lnf", build=True)
    head = g.add_node("linear", [lnf], {"in": d, "out": n_out, "dim": n_out}, role="head", build=True)
    g.set_output(head)
    for i, b in enumerate(blocks):
        subsets = {}
        if i + 1 < len(blocks):
            nb = blocks[i + 1]
            subsets = {"branch": [[nb["ln1"], 0]], "skip": [[nb["add1"], 0]]}
        g.add_cutpoint(f"T{i}.resid", "resid", i, g.consumers(b["add2"]), subsets=subsets)
        g.add_cutpoint(f"T{i}.attn_out", "attn_out", i, [(b["add1"], 1)])
        g.add_cutpoint(f"T{i}.mlp_out", "mlp_out", i, [(b["add2"], 1)])
        g.add_cutpoint(f"T{i}.mlp_hidden", "mlp_hidden", i, g.consumers(b["act"]))
        g.meta.setdefault("segments", []).append(
            {"name": f"T{i}.mlp", "nodes": [b["ln2"], b["fc1"], b["act"], b["fc2"]]})
    g.meta["arch"] = {"family": "transformer", "vocab": vocab, "d": d, "n_blocks": n_blocks, "heads": heads,
                      "n_out": n_out, "mlp_mult": mlp_mult, "pos": pos, "causal": causal}
    _init_all(g, gen, "default")
    return g


def build_gru(vocab: int, d: int, n_layers: int, n_out: int, gen: torch.Generator, max_len: int = 512) -> GraphNet:
    g = GraphNet("seq", "gru")
    x = g.set_input("x", 1, dtype="long")
    h = g.add_node("embed", [x], {"vocab": vocab, "dim": d, "max_len": max_len, "pos": "sin"}, role="embed",
                   build=True)
    grus = []
    for i in range(n_layers):
        h = g.add_node("gru", [h], {"in": d, "dim": d}, role=f"G{i}", build=True)
        grus.append(h)
    head = g.add_node("linear", [h], {"in": d, "out": n_out, "dim": n_out}, role="head", build=True)
    g.set_output(head)
    for i, n in enumerate(grus):
        g.add_cutpoint(f"G{i}.out", "gru_out", i, g.consumers(n))
    g.meta["arch"] = {"family": "gru", "vocab": vocab, "d": d, "n_layers": n_layers, "n_out": n_out}
    _init_all(g, gen, "default")
    return g


# ----------------------------------------------------------------------------- dispatcher

MODEL_DEFAULTS = {
    "family": "mlp",            # mlp | cnn | cnn_cut (v65) | resnet | transformer | gru
    "depth": 4,                 # mlp hidden layers / transformer blocks / gru layers / resnet blocks per stage
    "width": 128,               # mlp width / sequence d_model
    "act": "relu",              # relu | gelu | tanh | identity
    "widths": None,             # explicit list overrides depth/width for mlp (e.g. bottleneck [64, 4, 64])
    "bn": False,
    "width_mult": 1.0,          # cnn / resnet
    "heads": 4,
    "init": None,               # None = family default
    "query_at_layer": None,     # delayed-query injection layer (mlp); -1 = known before the peg (control)
    "pos": "sin",
    "blocks_per_stage": 1,      # resnet (1 -> ResNet-8, 2 -> ResNet-14)
}


def build_model(mcfg: dict, bundle, gen: torch.Generator) -> GraphNet:
    from ..config import strict_merge
    m = strict_merge(MODEL_DEFAULTS, mcfg, "model")
    fam = m["family"]
    if bundle.layout == "vec":
        if fam != "mlp":
            raise ValueError(f"vector data needs family 'mlp', got {fam}")
        d_in = bundle.input_spec["x"]["shape"][0]
        widths = m["widths"] or [m["width"]] * m["depth"]
        query = None
        if "q" in bundle.input_spec:
            if m["query_at_layer"] is None:
                raise ValueError("data has a late query stream 'q'; set model.query_at_layer")
            query = {"dim": bundle.input_spec["q"]["shape"][0], "at_layer": m["query_at_layer"]}
        return build_mlp(d_in, widths, bundle.out_dim, gen, act=m["act"], init=m["init"], bn=m["bn"], query=query)
    if bundle.layout == "img":
        c, H, W = bundle.input_spec["x"]["shape"]
        if fam == "cnn":
            return build_cnn(c, (H, W), bundle.out_dim, gen, m["width_mult"])
        if fam == "cnn_cut":
            return build_cnn_cut(c, (H, W), bundle.out_dim, gen, m["width_mult"])
        if fam == "resnet":
            return build_resnet(c, (H, W), bundle.out_dim, gen, m["width_mult"], blocks_per_stage=m["blocks_per_stage"])
        raise ValueError(f"image data needs cnn, cnn_cut or resnet, got {fam}")
    if bundle.layout == "seq":
        vocab = bundle.input_spec["x"].get("vocab", bundle.out_dim)
        max_len = int(bundle.meta.get("max_length", 512)) + 8
        if fam == "transformer":
            return build_transformer(vocab, m["width"], m["depth"], m["heads"], bundle.out_dim, gen,
                                     max_len=max(max_len, 64), pos=m["pos"])
        if fam == "gru":
            return build_gru(vocab, m["width"], m["depth"], bundle.out_dim, gen, max_len=max(max_len, 64))
        raise ValueError(f"sequence data needs transformer or gru, got {fam}")
    raise ValueError(bundle.layout)
