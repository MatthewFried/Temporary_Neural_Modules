"""Graph edits: cuts, exact insertion constructions A-F, branch groups,
deletion (canonical), affine folding and gate handling.

Cut semantics
-------------
A cut is (source node, set of consumer edges).  If the edge set equals ALL
current consumers of the source it is a *node cut*: the implant becomes the new
value of the node for everyone, so implants whose entry was the source are
re-pointed to the new exit (and the graph output, if it was the source).  If it
is a strict subset it is an *edge cut*: only those consumers see the change.

The parent of a new implant is the innermost implant containing all consumer
nodes (lowest common owner); for a node cut it is the implant that owns the
source as an internal value (or that implant's parent if the source is its
exit).  Optional `channels` (coordinate/channel subset, implemented with
select/scatter) and `positions` (token or spatial subset, pos_mix) restrict an
implant to part of the cut tensor.

Identity guarantees recorded on each implant
  exact_identity     T(z)=z for every z, exactly, in exact arithmetic (e.g. B=0
                     residual; bypass gate at 1).  Floating point may add
                     rounding for constructions that compute and cancel terms.
  output_preserving  the whole implant's output equals its input although
                     individual parts are not identities (cancelling pair,
                     duplicated branch with split weights, inverse pair).
  approximate        explicitly approximate (symmetry-breaking noise, learned
                     inverse before fitting).  These are L0 insertions.
"""
from __future__ import annotations

import copy
import math
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Optional

import torch
import torch.nn as nn

from .graph import GraphNet, Implant, GraphError, InvalidDeletion
from .ops import build_module, init_module, POSITIONWISE_AFFINE


# =============================================================================
# Cuts
# =============================================================================

@dataclass
class Cut:
    source: str
    consumers: Optional[list[tuple[str, int]]] = None   # None => node cut (all consumers)
    channels: Optional[list[int]] = None
    positions: Optional[dict] = None
    branch_source: Optional[str] = None                   # bridge implants read this node
    name: str = ""

    def describe(self, g: GraphNet) -> dict:
        return {"source": self.source, "source_op": g.nodes[self.source].op,
                "consumers": None if self.consumers is None else [list(c) for c in self.consumers],
                "channels": self.channels, "positions": self.positions,
                "branch_source": self.branch_source, "name": self.name}


def cutpoints(g: GraphNet, kind: Optional[str] = None) -> list[dict]:
    cps = g.meta["cutpoints"]
    return [c for c in cps if kind is None or c["kind"] == kind]


def pick_cutpoint(g: GraphNet, kind: str, where: Any) -> dict:
    cps = sorted(cutpoints(g, kind), key=lambda c: c["index"])
    if not cps:
        raise GraphError(f"no cutpoints of kind {kind!r}; available: {sorted({c['kind'] for c in g.meta['cutpoints']})}")
    if isinstance(where, int):
        return cps[where]
    n = len(cps)
    if where == "early":
        return cps[0]
    if where == "late":
        return cps[-1]
    if where == "middle":
        return cps[(n - 1) // 2]
    if isinstance(where, str) and where.startswith("frac:"):
        return cps[min(n - 1, int(float(where[5:]) * n))]
    raise GraphError(f"bad cut position {where!r}")


def resolve_edges(g: GraphNet, edges: list) -> Cut:
    """Resolve a list of (consumer, slot) edges (from a cutpoint) to the node
    that currently feeds them.  Earlier insertions on the same edges are
    therefore followed: inserting again at a cutpoint produces a chain."""
    edges = [tuple(e) for e in edges]
    feeders = {g.nodes[c].inputs[s] for c, s in edges}
    if len(feeders) != 1:
        raise GraphError(f"cutpoint edges are now fed by different nodes {sorted(feeders)}; "
                         "an earlier edge cut split them; specify the edges explicitly")
    return Cut(source=feeders.pop(), consumers=edges)


def cut_at(g: GraphNet, kind: str, where: Any = "middle", subset: Optional[str] = None, **kw) -> Cut:
    """Cut at a backbone cutpoint.  `subset` selects named edge subsets stored
    with the cutpoint (e.g. 'branch' or 'skip' for a residual stream)."""
    cp = pick_cutpoint(g, kind, where)
    edges = cp["edges"] if subset is None else cp["subsets"][subset]
    c = resolve_edges(g, edges)
    for k, v in kw.items():
        setattr(c, k, v)
    c.name = f"{cp['name']}" + (f":{subset}" if subset else "")
    return c


def implant_cut(g: GraphNet, iid: str, where: str = "hidden", **kw) -> Cut:
    cp = g.implants[iid].meta.get("cutpoints", {})
    if where not in cp:
        raise GraphError(f"implant {iid} ({g.implants[iid].construction}) has no internal cutpoint {where!r}; "
                         f"has {sorted(cp)}")
    c = resolve_edges(g, cp[where])
    for k, v in kw.items():
        setattr(c, k, v)
    c.name = f"{iid}:{where}"
    return c


# =============================================================================
# Helpers
# =============================================================================

def _dimattrs(g: GraphNet, nid: str, dim: Optional[int] = None) -> dict:
    a = g.nodes[nid].attrs
    out = {"dim": a["dim"] if dim is None else dim}
    for k in ("hw", "T"):
        if k in a:
            out[k] = a[k]
    # v65: a node whose layout differs from the graph's (the pooled vector features of an image network) passes its
    # layout on, so an addition there is built for that layout; nodes in the graph's own layout are unchanged
    if a.get("layout", g.layout) != g.layout:
        out["layout"] = a["layout"]
    return out


def _linear(g, src, d_in, d_out, owner, role, gen, scheme="default", bias=True, base_attrs=None, kernel=1):
    attrs = dict(base_attrs or {})
    attrs.update({"dim": d_out})
    if g.layout == "img" and kernel > 1:
        attrs.update({"in": d_in, "out": d_out, "k": kernel, "padding": kernel // 2, "bias": bias})
        nid = g.add_node("conv", [src], attrs, owner=owner, role=role, build=True)
    else:
        attrs.update({"in": d_in, "out": d_out, "bias": bias})
        nid = g.add_node("linear", [src], attrs, owner=owner, role=role, build=True)
    init_module(g.mods[g.nodes[nid].pkey], gen, scheme)
    return nid


def _zero_(g: GraphNet, nid: str) -> None:
    with torch.no_grad():
        for p in g.mods[g.nodes[nid].pkey].parameters():
            p.zero_()


def _set_weight(g: GraphNet, nid: str, W: torch.Tensor, b: Optional[torch.Tensor] = None) -> None:
    m = g.mods[g.nodes[nid].pkey]
    with torch.no_grad():
        m.weight.copy_(W.to(m.weight.dtype))
        if m.bias is not None:
            m.bias.copy_(torch.zeros_like(m.bias) if b is None else b.to(m.bias.dtype))


def _context_parent(g: GraphNet, src: str) -> Optional[str]:
    o = g.nodes[src].owner
    if o is None:
        return None
    if g.implants[o].exit == src:
        return g.implants[o].parent
    return o


def _device_dtype(g: GraphNet):
    for p in g.parameters():
        return p.device, p.dtype
    return torch.device("cpu"), torch.float32


def _finalize_modules(g: GraphNet, nodes: list[str]) -> None:
    dev, dt = _device_dtype(g)
    for n in nodes:
        pk = g.nodes[n].pkey
        if pk is not None:
            g.mods[pk].to(device=dev, dtype=dt)


# =============================================================================
# Series insertion framework
# =============================================================================

BodyFn = Callable[[GraphNet, str, str, int, torch.Generator, dict], str]


def insert_series(g: GraphNet, cut: Cut, construction: str, body: BodyFn, params: dict, gen: torch.Generator,
                  identity: str, slot: str = "", rnd: Optional[int] = None, deletion: str = "bypass") -> str:
    if cut.source not in g.nodes:
        raise GraphError(f"cut source {cut.source} missing")
    all_cons = g.consumers(cut.source)
    is_output = g.output == cut.source
    edges = [tuple(e) for e in (cut.consumers if cut.consumers is not None else all_cons)]
    for c, s in edges:
        if g.nodes[c].inputs[s] != cut.source:
            raise GraphError(f"edge {cut.source}->{c}[{s}] does not exist")
    # node cut = every current consumer (and the graph output, if the source is the output);
    # an explicit edge list never includes the graph output, so it is an edge cut then
    node_cut = set(edges) == set(all_cons) and not (cut.consumers is not None and is_output)
    if not edges and not is_output:
        raise GraphError(f"cut at {cut.source} has no consumers")
    if node_cut:
        parent = _context_parent(g, cut.source)
    else:
        parent = g.lca_owner([c for c, _ in edges])
    gen_no = 1 if parent is None else g.implants[parent].generation + 1
    iid = g._new("I")
    imp = Implant(id=iid, construction=construction, kind="series", parent=parent, generation=gen_no,
                  entry=cut.source, exit=None, nodes=[], cut=cut.describe(g) | {"node_cut": node_cut},
                  identity=identity, deletion=deletion, slot=slot, round=rnd, meta={"params": dict(params)})
    g.implants[iid] = imp
    preexisting = [k for k in g.implants if k != iid]
    first_new = g.ctr["n"] + 1

    src = cut.source
    d_full = g.node_dim(src)
    h = src
    if cut.channels is not None:
        ch = sorted(set(int(c) for c in cut.channels))
        if not ch or ch[-1] >= d_full:
            raise GraphError(f"bad channel subset for dim {d_full}")
        h = g.add_node("select", [src], {"idx": ch, **_dimattrs(g, src, len(ch))}, owner=iid, role="select")
        d = len(ch)
    else:
        d = d_full
    out = body(g, h, iid, d, gen, params)
    if cut.channels is not None:
        out = g.add_node("scatter", [src, out], {"idx": sorted(set(int(c) for c in cut.channels)),
                                                 **_dimattrs(g, src)}, owner=iid, role="scatter")
    if cut.positions is not None:
        if g.layout not in ("seq", "img"):
            raise GraphError("position subsets need seq or img layout")
        out = g.add_node("pos_mix", [src, out], {"positions": dict(cut.positions), **_dimattrs(g, src)},
                         owner=iid, role="pos_mix")
    ex = g.add_node("identity", [out], _dimattrs(g, src), owner=iid, role="exit")
    imp.exit = ex
    g.replace_uses(src, ex, only=edges)
    if node_cut:
        for k in preexisting:
            if g.implants[k].entry == src and k not in g.implant_descendants(iid):
                g.implants[k].entry = ex
        if is_output:
            g.output = ex
    imp.nodes = [n for n in g.nodes if g.nodes[n].owner == iid]
    _finalize_modules(g, [n for n in g.nodes if int(n[1:]) >= first_new])
    g.meta["history"].append({"op": "insert", "implant": iid, "construction": construction, "slot": slot,
                              "round": rnd, "parent": parent, "node_cut": node_cut})
    g._plan = None
    return iid


def child_series(g: GraphNet, parent: str, entry: str, construction: str, body: BodyFn, params: dict,
                 gen: torch.Generator, identity: str, deletion: str = "bypass") -> str:
    """A series implant created *inside* a group being built (no rewiring of
    existing consumers).  Its exit is an explicit identity node."""
    iid = g._new("I")
    imp = Implant(id=iid, construction=construction, kind="series", parent=parent,
                  generation=g.implants[parent].generation + 1, entry=entry, exit=None, nodes=[],
                  cut={"source": entry, "internal_of": parent}, identity=identity, deletion=deletion,
                  slot=g.implants[parent].slot + "/" + construction, round=g.implants[parent].round,
                  meta={"params": dict(params)})
    g.implants[iid] = imp
    out = body(g, entry, iid, g.node_dim(entry), gen, params)
    imp.exit = g.add_node("identity", [out], _dimattrs(g, entry), owner=iid, role="exit")
    imp.nodes = [n for n in g.nodes if g.nodes[n].owner == iid]
    return iid


# =============================================================================
# Construction A: residual zero output   T(h) = h + B act(A h),  B = 0
# =============================================================================

def body_residual_zero(g: GraphNet, h: str, iid: str, d: int, gen: torch.Generator, p: dict) -> str:
    w = int(p.get("width", d))
    act = p.get("act", "relu")
    a_init = p.get("a_init", "default")
    a = _linear(g, h, d, w, iid, "A", gen, scheme=a_init, base_attrs=_dimattrs(g, h, w), kernel=p.get("kernel", 1))
    nl = float(p.get("nonlinearity", 1.0))
    if p.get("mixer", "mlp") == "attention":
        # F10c: a causal self-attention block over the sequence positions of the cut (context access:
        # every earlier position and the current one), between the A projection and the zero B projection
        if g.nodes[h].attrs.get("layout", g.layout) != "seq":
            raise GraphError("growth.mixer=attention needs a sequence cut")
        from ..cop_pegs.modules import AttnPearl
        heads = 2 if w % 2 == 0 else 1
        args = {"k_in": w, "d": w, "k_out": w, "heads": heads}
        mod = AttnPearl(**args)
        init_module(mod, gen, "default")
        s = g.add_node("module", [a], {"module_type": "attn_pearl", "module_args": args, "layout": "seq",
                                       **_dimattrs(g, h, w)},
                       owner=iid, role="act", module=mod)
        g.implants[iid].meta["context_access"] = "causal self-attention: current and all earlier positions"
    else:
        fn_attrs = {"fn": act} if nl >= 1.0 else {"fn": "mix", "base": act, "s": nl}
        s = g.add_node("act", [a], {**fn_attrs, **_dimattrs(g, h, w)}, owner=iid, role="act")
    b = _linear(g, s, w, d, iid, "B", gen, scheme="zero", base_attrs=_dimattrs(g, h, d))
    b_scale = float(p.get("b_init_scale", 0.0))
    if b_scale:
        init_module(g.mods[g.nodes[b].pkey], gen, "default")
        with torch.no_grad():
            for prm in g.mods[g.nodes[b].pkey].parameters():
                prm.mul_(b_scale)
    m = g.add_node("add", [h, b], {"coefs": [1.0, 1.0], "terms": ["skip", "branch"], **_dimattrs(g, h, d)},
                   owner=iid, role="merge")
    g.implants[iid].meta["cutpoints"] = {"hidden": [[b, 0]], "pre_act": [[s, 0]], "branch_input": [[a, 0]],
                                         "skip": [[m, 0]], "branch_output": [[m, 1]]}
    return m


def insert_residual_zero(g, cut, gen, width=None, act="relu", a_init="default", kernel=1, b_init_scale=0.0,
                         slot="", rnd=None, nonlinearity: float = 1.0, mixer: str = "mlp") -> str:
    if a_init == "zero":
        # Allowed only as an explicit control: A=B=0 is a stationary point.
        pass
    d_cut = g.node_dim(cut.source) if cut.channels is None else len(cut.channels)
    p = {"width": width or d_cut,
         "act": act, "a_init": a_init, "kernel": kernel, "b_init_scale": b_init_scale,
         "nonlinearity": float(nonlinearity)}
    if mixer != "mlp":
        p["mixer"] = mixer                       # only recorded when used (keeps v2 implant params unchanged)
    ident = "exact_identity" if not b_init_scale else "approximate"
    if cut.branch_source is not None:
        return insert_bridge(g, cut, gen, width=p["width"], act=act, slot=slot, rnd=rnd)
    return insert_series(g, cut, "residual_zero", body_residual_zero, p, gen, ident, slot, rnd)


def insert_bridge(g, cut, gen, width=None, act="relu", module: Optional[nn.Module] = None, module_out: int = 0,
                  module_attrs: Optional[dict] = None, construction="bridge_zero", slot="", rnd=None) -> str:
    """Residual-zero implant whose branch reads a *different* node
    (`cut.branch_source`, which must not depend on the cut) and adds into the
    cut value:  T(h) = h + B act(A src)  or  h + B M(src)  for a known module M."""
    src = cut.branch_source
    if src in g.descendants(cut.source) or src == cut.source and False:
        raise GraphError("bridge source must not be downstream of the cut")
    if module is not None and module_attrs is None:
        raise GraphError("known-module bridge needs module_attrs for serialisation")

    def body(g, h, iid, d, gen, p):
        if module is not None:
            k = g.add_node("module", [src], {**module_attrs, "dim": module_out, "layout": "vec"},
                           owner=iid, role="known", module=module)
            kout = module_out
        else:
            w = int(p["width"])
            a = _linear(g, src, g.node_dim(src), w, iid, "A", gen, base_attrs={"dim": w})
            k = g.add_node("act", [a], {"fn": p["act"], "dim": w}, owner=iid, role="act")
            kout = w
        b = _linear(g, k, kout, d, iid, "B", gen, scheme="zero", base_attrs=_dimattrs(g, h, d))
        m = g.add_node("add", [h, b], {"coefs": [1.0, 1.0], "terms": ["skip", "branch"], **_dimattrs(g, h, d)},
                       owner=iid, role="merge")
        g.implants[iid].meta["cutpoints"] = {"hidden": [[b, 0]], "skip": [[m, 0]]}
        g.implants[iid].meta["branch_source"] = src
        return m

    p = {"width": width or 16, "act": act, "known_module": None if module is None else module_attrs}
    return insert_series(g, cut, construction, body, p, gen, "exact_identity", slot, rnd)


# =============================================================================
# Construction B: linear factorisation
# =============================================================================

def body_linear_factor(g, h, iid, d, gen, p):
    m = int(p.get("width", d))
    mode = p.get("mode", "orthogonal")
    dt = torch.float64
    if mode == "orthogonal":
        if m < d:
            raise GraphError("identity factorisation through m < d is a rank bottleneck, not an identity")
        Z = torch.randn(m, d, generator=gen, dtype=dt)
        Q, _ = torch.linalg.qr(Z)            # m x d, orthonormal columns
        W1, W2 = Q, Q.T                      # W2 W1 = I_d
    elif mode == "invertible":
        if m != d:
            raise GraphError("invertible mode needs width == d")
        Q = torch.linalg.qr(torch.randn(d, d, generator=gen, dtype=dt))[0]
        W1 = Q * torch.exp(0.3 * torch.randn(d, generator=gen, dtype=dt))[None]   # well-conditioned
        W2 = torch.linalg.inv(W1)
    elif mode == "identity":
        if m < d:
            raise GraphError("identity mode needs m >= d")
        W1 = torch.zeros(m, d, dtype=dt)
        W1[:d] = torch.eye(d, dtype=dt)
        W2 = W1.T.clone()
    else:
        raise GraphError(f"unknown factor mode {mode}")
    n1 = g.add_node("linear", [h], {"in": d, "out": m, "bias": True, **_dimattrs(g, h, m)}, owner=iid, role="W1",
                    build=True)
    _set_weight(g, n1, W1)
    acts = p.get("act", "identity")
    mid = n1
    if acts != "identity":
        raise GraphError("linear factorisation is linear; use residual or inverse constructions for nonlinear chains")
    n2 = g.add_node("linear", [mid], {"in": m, "out": d, "bias": True, **_dimattrs(g, h, d)}, owner=iid, role="W2",
                    build=True)
    _set_weight(g, n2, W2)
    g.implants[iid].meta["cutpoints"] = {"mid": [[n2, 0]], "input": [[n1, 0]]}
    return n2


def insert_linear_factor(g, cut, gen, width=None, mode="orthogonal", slot="", rnd=None) -> str:
    d = g.node_dim(cut.source) if cut.channels is None else len(cut.channels)
    p = {"width": width or d, "mode": mode}
    return insert_series(g, cut, "linear_factor", body_linear_factor, p, gen, "exact_identity", slot, rnd)


def factorize_node(g: GraphNet, nid: str, gen: torch.Generator, width: Optional[int] = None,
                   slot: str = "", rnd=None, balance: float = 1.0) -> str:
    """Replace a backbone/implant linear node W (out x in) by W2 W1 with the same
    product (SVD-based), recorded as an implant with deletion='fold'.
    balance c > 0 scales W1 by c and W2 by 1/c: the product (the function) is
    unchanged, the factor geometry (and so the optimisation) is not."""
    n = g.nodes[nid]
    if n.op == "conv":
        return _factorize_conv(g, nid, gen, width, slot, rnd, balance)
    if n.op != "linear":
        raise GraphError("factorize_node needs a linear or conv node")
    mod = g.mods[n.pkey]
    W = mod.weight.detach().double().cpu()
    b = None if mod.bias is None else mod.bias.detach().double().cpu()
    out_d, in_d = W.shape
    r = min(out_d, in_d)
    m = width or r
    if m < r:
        raise GraphError("factorisation width below min(in,out) would not be exact in general")
    U, S, Vh = torch.linalg.svd(W, full_matrices=False)
    W1 = torch.zeros(m, in_d, dtype=torch.float64)
    W2 = torch.zeros(out_d, m, dtype=torch.float64)
    W1[:r] = S.sqrt()[:, None] * Vh
    W2[:, :r] = U * S.sqrt()[None]
    if m > r:  # extra columns of W2 random; extra rows of W1 zero  => product unchanged
        W2[:, r:] = torch.randn(out_d, m - r, generator=gen, dtype=torch.float64) / math.sqrt(m)
    if not balance > 0:
        raise GraphError("factor balance must be positive")
    W1, W2 = W1 * float(balance), W2 / float(balance)
    cut = Cut(source=n.inputs[0], consumers=[(nid, 0)])
    parent = g.lca_owner([nid])
    iid = g._new("I")
    imp = Implant(id=iid, construction="node_factorization", kind="series", parent=parent,
                  generation=1 if parent is None else g.implants[parent].generation + 1, entry=n.inputs[0],
                  exit=None, nodes=[], cut=cut.describe(g) | {"replaces": nid}, identity="output_preserving",
                  deletion="fold", slot=slot, round=rnd,
                  meta={"replaced_attrs": copy.deepcopy(g.nodes[nid].attrs), "replaced_node": nid, "width": m,
                        "balance": float(balance)})
    g.implants[iid] = imp
    n1 = g.add_node("linear", [n.inputs[0]], {"in": in_d, "out": m, "bias": False, **_dimattrs(g, nid, m)},
                    owner=iid, role="W1", build=True)
    _set_weight(g, n1, W1)
    n2 = g.add_node("linear", [n1], {"in": m, "out": out_d, "bias": b is not None, **_dimattrs(g, nid)},
                    owner=iid, role="W2", build=True)
    _set_weight(g, n2, W2, b)
    ex = g.add_node("identity", [n2], _dimattrs(g, nid), owner=iid, role="exit")
    imp.exit = ex
    imp.entry = n.inputs[0]
    g.replace_uses(nid, ex)
    # the original node is now dead; keep it in the spec for provenance
    imp.nodes = [k for k in g.nodes if g.nodes[k].owner == iid]
    imp.meta["cutpoints"] = {"mid": [[n2, 0]]}
    _finalize_modules(g, imp.nodes)
    g.meta["history"].append({"op": "factorize", "implant": iid, "node": nid})
    return iid


def _factorize_conv(g: GraphNet, nid: str, gen: torch.Generator, width: Optional[int], slot: str, rnd,
                    balance: float) -> str:
    """conv k x k (out, in) -> conv k x k (m, in) followed by a 1 x 1 map (out, m), SVD of the
    (out, in*k*k) matrix.  The pair folds back EXACTLY to one k x k conv with the original
    stride / padding (a 1 x 1 map after a conv keeps its support).  A k x k conv after a
    k x k conv would not fold to one k x k conv in general; that factorisation is not offered."""
    n = g.nodes[nid]
    mod = g.mods[n.pkey]
    a = n.attrs
    W = mod.weight.detach().double().cpu()                       # (out, in, k, k)
    b = None if mod.bias is None else mod.bias.detach().double().cpu()
    out_d, in_d, k1, k2 = W.shape
    Wf = W.reshape(out_d, -1)
    r = min(out_d, Wf.shape[1])
    m = width or r
    if m < r:
        raise GraphError("factorisation width below the rank bound would not be exact in general")
    U, S, Vh = torch.linalg.svd(Wf, full_matrices=False)
    W1 = torch.zeros(m, Wf.shape[1], dtype=torch.float64)
    W2 = torch.zeros(out_d, m, dtype=torch.float64)
    W1[:r] = S.sqrt()[:, None] * Vh
    W2[:, :r] = U * S.sqrt()[None]
    if m > r:
        W2[:, r:] = torch.randn(out_d, m - r, generator=gen, dtype=torch.float64) / math.sqrt(m)
    if not balance > 0:
        raise GraphError("factor balance must be positive")
    W1, W2 = W1 * float(balance), W2 / float(balance)
    cut = Cut(source=n.inputs[0], consumers=[(nid, 0)])
    parent = g.lca_owner([nid])
    iid = g._new("I")
    imp = Implant(id=iid, construction="node_factorization", kind="series", parent=parent,
                  generation=1 if parent is None else g.implants[parent].generation + 1, entry=n.inputs[0],
                  exit=None, nodes=[], cut=cut.describe(g) | {"replaces": nid}, identity="output_preserving",
                  deletion="fold", slot=slot, round=rnd,
                  meta={"replaced_attrs": copy.deepcopy(g.nodes[nid].attrs), "replaced_node": nid, "width": m, "conv": True,
                        "balance": float(balance)})
    g.implants[iid] = imp
    c1 = g.add_node("conv", [n.inputs[0]], {**a, "out": m, "dim": m, "bias": False}, owner=iid, role="W1", build=True)
    with torch.no_grad():
        g.mods[g.nodes[c1].pkey].weight.copy_(W1.reshape(m, in_d, k1, k2).to(mod.weight.dtype))
    n2 = g.add_node("linear", [c1], {"in": m, "out": out_d, "bias": b is not None, **_dimattrs(g, nid)},
                    owner=iid, role="W2", build=True)
    _set_weight(g, n2, W2, b)
    ex = g.add_node("identity", [n2], _dimattrs(g, nid), owner=iid, role="exit")
    imp.exit = ex
    g.replace_uses(nid, ex)
    imp.nodes = [k for k in g.nodes if g.nodes[k].owner == iid]
    imp.meta["cutpoints"] = {"mid": [[n2, 0]]}
    _finalize_modules(g, imp.nodes)
    g.meta["history"].append({"op": "factorize", "implant": iid, "node": nid, "conv": True})
    return iid


def split_node(g: GraphNet, nid: str, gen: torch.Generator, split: float = 0.5, slot: str = "", rnd=None) -> str:
    """Split a linear / conv node W (bias b) into two additive branches s W + (1 - s) W
    (biases s b, (1 - s) b) summed: the same function, a different parameterisation
    (branch balance s).  Recorded as an implant with deletion='fold': merging the
    branches back is exact (strengthening F01b)."""
    n = g.nodes[nid]
    if n.op not in ("linear", "conv"):
        raise GraphError("split_node needs a linear or conv node")
    if not 0.0 < float(split) < 1.0:
        raise GraphError("split must be in (0, 1)")
    mod = g.mods[n.pkey]
    parent = g.lca_owner([nid])
    iid = g._new("I")
    cut = Cut(source=n.inputs[0], consumers=[(nid, 0)])
    imp = Implant(id=iid, construction="node_split", kind="series", parent=parent,
                  generation=1 if parent is None else g.implants[parent].generation + 1, entry=n.inputs[0],
                  exit=None, nodes=[], cut=cut.describe(g) | {"replaces": nid}, identity="output_preserving",
                  deletion="fold", slot=slot, round=rnd,
                  meta={"replaced_attrs": copy.deepcopy(g.nodes[nid].attrs), "replaced_node": nid, "split": float(split),
                        "conv": n.op == "conv"})
    g.implants[iid] = imp
    outs = []
    for role, c in (("Wa", float(split)), ("Wb", 1.0 - float(split))):
        k = g.add_node(n.op, [n.inputs[0]], copy.deepcopy(n.attrs), owner=iid, role=role, build=True)
        m2 = g.mods[g.nodes[k].pkey]
        with torch.no_grad():
            m2.weight.copy_(mod.weight.detach() * c)
            if m2.bias is not None:
                m2.bias.copy_(mod.bias.detach() * c)
        outs.append(k)
    add = g.add_node("add", outs, {"coefs": [1.0, 1.0], "terms": ["a", "b"], **_dimattrs(g, nid)}, owner=iid,
                     role="merge")
    ex = g.add_node("identity", [add], _dimattrs(g, nid), owner=iid, role="exit")
    imp.exit = ex
    g.replace_uses(nid, ex)
    imp.nodes = [k for k in g.nodes if g.nodes[k].owner == iid]
    _finalize_modules(g, imp.nodes)
    g.meta["history"].append({"op": "split_node", "implant": iid, "node": nid, "split": float(split)})
    g._plan = None
    return iid


@torch.no_grad()
def _fold_conv_implant(g: GraphNet, iid: str) -> str:
    """Exact fold of conv-based factorised / split implants into one conv node with the
    replaced node's attributes (stride, padding, bias)."""
    imp = g.implants[iid]
    # the replaced node may have been pruned as dead since the edit: its attributes are kept in the meta
    orig_attrs = imp.meta.get("replaced_attrs")
    if orig_attrs is None:
        orig_attrs = g.nodes[imp.meta["replaced_node"]].attrs
    lin = sorted([n for n in imp.nodes if g.nodes[n].op in ("conv", "linear")], key=lambda s_: int(s_[1:]))
    if imp.construction == "node_factorization":
        c1 = next(n for n in lin if g.nodes[n].role == "W1")
        l2 = next(n for n in lin if g.nodes[n].role == "W2")
        W1 = g.mods[g.nodes[c1].pkey].weight.double()             # (m, in, k, k)
        L2 = g.mods[g.nodes[l2].pkey]
        W = torch.einsum("om,mikl->oikl", L2.weight.double(), W1)
        b = None if L2.bias is None else L2.bias.double()
    elif imp.construction == "node_split":
        Ws = [g.mods[g.nodes[n].pkey] for n in lin]
        W = sum(m.weight.double() for m in Ws)
        b = None if Ws[0].bias is None else sum(m.bias.double() for m in Ws)
    else:
        raise InvalidDeletion(f"no conv fold for construction {imp.construction}")
    attrs = copy.deepcopy(orig_attrs)
    attrs["bias"] = b is not None
    nid = g.add_node("conv", [imp.entry], attrs, owner=imp.parent, role="folded", build=True)
    m = g.mods[g.nodes[nid].pkey]
    dev, dt = _device_dtype(g)
    m.to(device=dev, dtype=dt)
    m.weight.copy_(W.to(m.weight.dtype))
    if b is not None:
        m.bias.copy_(b.to(m.bias.dtype))
    return nid


def insert_bottleneck(g: GraphNet, cut: Cut, gen: torch.Generator, k: int, bits: int = 0,
                      A_init: Optional[torch.Tensor] = None, mean: Optional[torch.Tensor] = None,
                      slot: str = "", rnd=None) -> str:
    """Series rank-k interface with no skip path: h -> B q(A (h - mu)) + mu, A (k x d),
    B = A^T (a projector when A has orthonormal rows, e.g. the top-k principal directions of
    the cut on TRAINING calibration inputs), q = uniform quantiser with `bits` (0 = none).
    A rank- or alphabet-limited insertion is not an identity: it is declared approximate,
    so the insertion gate records its loss separately (strengthening F01e)."""
    d = g.node_dim(cut.source) if cut.channels is None else len(cut.channels)
    if not 1 <= k < d:
        raise GraphError("bottleneck rank must be in [1, d)")
    if A_init is None:
        A_init = torch.linalg.qr(torch.randn(d, k, generator=gen, dtype=torch.float64))[0].T
    A_init = torch.as_tensor(A_init, dtype=torch.float64)
    mu = (torch.zeros(d, dtype=torch.float64, device=A_init.device) if mean is None
          else torch.as_tensor(mean, dtype=torch.float64).to(A_init.device))

    def body(g, h, iid, d_, gen_, p):
        a = g.add_node("linear", [h], {"in": d_, "out": k, "bias": True, **_dimattrs(g, h, k)}, owner=iid, role="A",
                       build=True)
        _set_weight(g, a, A_init, -(A_init @ mu))
        src = a
        if bits:
            src = g.add_node("quant", [a], {"dim": k, "mode": "uniform", "bits": int(bits), **_dimattrs(g, h, k)},
                             owner=iid, role="quant", build=True)
        b = g.add_node("linear", [src], {"in": k, "out": d_, "bias": True, **_dimattrs(g, h, d_)}, owner=iid, role="B",
                       build=True)
        _set_weight(g, b, A_init.T.contiguous(), mu)
        g.implants[iid].meta["cutpoints"] = {"code": [[b, 0]]}
        g.implants[iid].meta["bottleneck"] = {"k": k, "bits": int(bits), "code": src}
        return b

    return insert_series(g, cut, "bottleneck", body, {"k": k, "bits": int(bits)}, gen, "approximate", slot, rnd)


# =============================================================================
# Groups with deletable branches (C duplicated, D cancelling, parallel, routing)
# =============================================================================

def new_branch_implant(g: GraphNet, group: str, construction: str, identity: str, slot: str = "",
                       meta: Optional[dict] = None) -> str:
    iid = g._new("I")
    par = g.implants[group]
    g.implants[iid] = Implant(id=iid, construction=construction, kind="branch", parent=group,
                              generation=par.generation + 1, entry=par.entry, exit=None, nodes=[],
                              cut={"group": group}, identity=identity, deletion="drop_term",
                              merge=par.meta["merge"], slot=slot or f"{par.slot}/b{len(g.implant_children(group))}",
                              round=par.round, meta=dict(meta or {}))
    return iid


def _branch_output_is_zero(g: GraphNet, bid: str) -> bool:
    """True if the branch's output layer B has all-zero weights and bias (its
    contribution is exactly zero) and it has no nested implants."""
    if g.implant_descendants(bid):
        return False
    b = next((n for n in g.nodes if g.nodes[n].owner == bid and g.nodes[n].role == "B"), None)
    if b is None or g.nodes[b].pkey is None:
        return False
    m = g.mods[g.nodes[b].pkey]
    return all(bool((p == 0).all()) for p in m.parameters())


@torch.no_grad()
def _copy_branch_params(g: GraphNet, src: str, dst: str) -> bool:
    """Copy the parameters of branch src into the freshly built branch dst
    (same roles, same shapes).  Returns False if they are not identical in
    architecture or src has nested implants."""
    if g.implant_descendants(src):
        return False
    owned = lambda b: sorted((n for n in g.nodes if g.nodes[n].owner == b), key=lambda s: int(s[1:]))
    key = lambda b: [(g.nodes[n].role, g.nodes[n].op) for n in owned(b)]
    if key(src) != key(dst):
        return False
    sp = [n for n in owned(src) if g.nodes[n].pkey]
    dp = [n for n in owned(dst) if g.nodes[n].pkey]
    for a, b in zip(sp, dp):
        ma, mb = g.mods[g.nodes[a].pkey], g.mods[g.nodes[b].pkey]
        sa, sb = ma.state_dict(), mb.state_dict()
        if sa.keys() != sb.keys() or any(sa[k].shape != sb[k].shape for k in sa):
            return False
    for a, b in zip(sp, dp):
        g.mods[g.nodes[b].pkey].load_state_dict(g.mods[g.nodes[a].pkey].state_dict())
    return True


@torch.no_grad()
def _route_split_rows(g: GraphNet, merge: str, src: str, dst: str, s: float) -> None:
    if not 0.0 < s < 1.0:
        raise GraphError("route_split must be in (0, 1)")
    n = g.nodes[merge]
    m = g.mods[n.pkey]
    terms = n.attrs["terms"]
    j, k = terms.index(src), terms.index(dst)
    m.weight[k].copy_(m.weight[j])
    m.bias[k] = m.bias[j] + math.log(1.0 - s)
    m.bias[j] = m.bias[j] + math.log(s)


def attach_term(g: GraphNet, merge: str, src: str, term: str, coef: float = 1.0, term_dim: Optional[int] = None,
                gen: Optional[torch.Generator] = None) -> None:
    """Append a branch output to a merge node.  For concat_proj merges the
    projection gains zero columns (exactness); for route merges the router gains
    a new row (any router is exact while expert outputs are zero)."""
    n = g.nodes[merge]
    if n.op == "add":
        n.inputs.append(src)
        n.attrs["coefs"].append(float(coef))
        n.attrs["terms"].append(term)
        if n.attrs.get("gates"):
            n.attrs["gates"].append(None)
    elif n.op == "concat_proj":
        old = g.mods[n.pkey]
        dims = n.attrs["term_dims"] + [int(term_dim)]
        attrs = dict(n.attrs)
        attrs.update({"term_dims": dims, "active": n.attrs["active"] + [True], "terms": n.attrs["terms"] + [term]})
        new = build_module("concat_proj", attrs).to(old.weight.device, old.weight.dtype)
        with torch.no_grad():
            new.weight.zero_()
            new.weight[:, :old.weight.shape[1]].copy_(old.weight)
            if new.bias is not None:
                new.bias.copy_(old.bias)
        _replace_module(g, merge, new, attrs)
        n.inputs.append(src)
        if n.attrs.get("gates"):
            n.attrs["gates"].append(None)
    elif n.op == "route":
        old = g.mods[n.pkey]
        attrs = dict(n.attrs)
        attrs.update({"terms": n.attrs["terms"] + [term], "active": n.attrs["active"] + [True]})
        new = build_module("route", attrs).to(old.weight.device, old.weight.dtype)
        with torch.no_grad():
            init_module(new, gen or torch.Generator().manual_seed(0), "default")
            new.weight[:old.weight.shape[0]].copy_(old.weight)
            new.bias[:old.bias.shape[0]].copy_(old.bias)
        _replace_module(g, merge, new, attrs)
        n.inputs.append(src)
    else:
        raise GraphError(f"cannot attach a term to op {n.op}")
    g._plan = None


def _replace_module(g: GraphNet, nid: str, module: nn.Module, attrs: dict) -> None:
    n = g.nodes[nid]
    users = [k for k, m in g.nodes.items() if m.pkey == n.pkey]
    if len(users) > 1:
        raise GraphError("cannot resize a shared merge module")
    pk = g._new("p")
    g.mods[pk] = module
    g.pkey_src[pk] = {"op": n.op, "attrs": copy.deepcopy(attrs)}
    old = n.pkey
    n.pkey = pk
    n.attrs = attrs
    if old is not None and not any(m.pkey == old for m in g.nodes.values()):
        del g.mods[old]
        g.pkey_src.pop(old, None)


def _branch_mlp(g, h, iid, d_in, d_out, gen, width, act, b_scheme, kernel=1):
    a = _linear(g, h, d_in, width, iid, "A", gen, base_attrs=_dimattrs(g, h, width), kernel=kernel)
    s = g.add_node("act", [a], {"fn": act, **_dimattrs(g, h, width)}, owner=iid, role="act")
    if d_out is None:
        return a, s, None
    b = _linear(g, s, width, d_out, iid, "B", gen, scheme=b_scheme, base_attrs=_dimattrs(g, h, d_out))
    return a, s, b


def insert_group(g: GraphNet, cut: Cut, gen: torch.Generator, merge: str = "sum", construction: str = "parallel",
                 slot: str = "", rnd=None, router_input: Optional[str] = None) -> str:
    """Series implant consisting only of a merge node over the skip value; branches are added later."""

    def body(g, h, iid, d, gen, p):
        if merge == "sum":
            m = g.add_node("add", [h], {"coefs": [1.0], "terms": ["skip"], **_dimattrs(g, h, d)}, owner=iid,
                           role="merge")
            g.implants[iid].meta["merge"] = m
            out = m
        elif merge == "concat":
            attrs = {"term_dims": [d], "active": [True], "terms": ["skip"], "bias": False, **_dimattrs(g, h, d)}
            m = g.add_node("concat_proj", [h], attrs, owner=iid, role="merge", build=True)
            _set_weight(g, m, torch.eye(d, dtype=torch.float64))
            g.implants[iid].meta["merge"] = m
            out = m
        elif merge == "route":
            r_in = router_input or h
            attrs = {"router_in": g.node_dim(r_in), "terms": [], "active": [], **_dimattrs(g, h, d)}
            # router with zero experts is created lazily on first branch; start with a placeholder add
            m = g.add_node("add", [h], {"coefs": [1.0], "terms": ["skip"], **_dimattrs(g, h, d)}, owner=iid,
                           role="merge_outer")
            g.implants[iid].meta["merge"] = None
            g.implants[iid].meta["route_pending"] = {"router_in": r_in, "outer": m}
            out = m
        else:
            raise GraphError(f"unknown merge {merge}")
        g.implants[iid].meta["merge_mode"] = merge
        g.implants[iid].meta["cutpoints"] = {"skip": [[out, 0]]}
        return out

    iid = insert_series(g, cut, construction, body, {"merge": merge}, gen, "exact_identity", slot, rnd)
    return iid


def add_branch(g: GraphNet, group: str, gen: torch.Generator, width: int = 16, act: str = "relu",
               input_node: Optional[str] = None, channels: Optional[list[int]] = None, tie_to: Optional[str] = None,
               specialize_mask: Optional[str] = None, aux_dim: int = 0, construction: str = "branch",
               slot: str = "", kernel: int = 1, route_split: float = 0.3) -> str:
    """Add a branch to a group.  Output starts at exactly zero contribution:
    sum/route merges use B=0; concat merges get zero projection columns.
    Route merges: a zero expert is exact only while EVERY existing expert
    outputs zero (its new router row takes probability mass from the others).
    Once an existing expert is non-zero, the new expert is an exact SPLIT of the
    most recent expert j: its parameters are a copy of j's (or shared, if tied)
    and the router rows get logits l_j + log(s) and l_j + log(1 - s), so
    p_j x_j = s p_j x_j + (1 - s) p_j x_j; s = route_split != 0.5 breaks the
    symmetry between the two copies.  Where no exact split exists (j has
    nested implants, channel subsets, masks or a different architecture) the
    zero expert is used and the branch is declared approximate.
    `input_node` (default: group entry) gives complementary branches a
    different input; `channels` restricts the branch to a feature subset;
    `tie_to` makes this branch share all parameters with an existing branch;
    `specialize_mask` routes gradients only from examples in that mask;
    `aux_dim>0` adds an auxiliary head (side output) on the branch hidden layer."""
    G = g.implants[group]
    mode = G.meta["merge_mode"]
    first_new = g.ctr["n"] + 1
    bid = new_branch_implant(g, group, construction, "exact_identity", slot)
    entry = input_node or G.entry
    if input_node is not None and input_node in g.descendants(G.exit):
        raise GraphError("branch input must not depend on the group output")
    g.implants[bid].entry = entry
    h = entry
    d_out = g.node_dim(G.entry)
    if channels is not None:
        h = g.add_node("select", [entry], {"idx": sorted(channels), **_dimattrs(g, entry, len(channels))},
                       owner=bid, role="select")
    d_in = g.node_dim(h)
    if tie_to is not None:
        T = g.implants[tie_to]
        src_nodes = [n for n in T.nodes if g.nodes[n].role in ("A", "act", "B")]
        mapping = {}
        cur = h
        for n in src_nodes:
            on = g.nodes[n]
            cur = g.add_node(on.op, [cur], copy.deepcopy(on.attrs), owner=bid, role=on.role, pkey=on.pkey)
            mapping[n] = cur
        out = cur
        hidden = mapping.get(next((n for n in src_nodes if g.nodes[n].role == "act"), None))
        g.meta["twins"][bid] = {"of": tie_to, "map": mapping}
        g.implants[bid].meta["tied_to"] = tie_to
    else:
        b_scheme = "zero" if mode in ("sum", "route") else None
        a, hidden, b = _branch_mlp(g, h, bid, d_in, None if mode == "concat" else d_out, gen, width, act,
                                   b_scheme or "zero", kernel=kernel)
        out = hidden if mode == "concat" else b
    if specialize_mask is not None:
        out = g.add_node("mask_grad", [out], {"mask_key": specialize_mask, **_dimattrs(g, out)}, owner=bid,
                         role="specialize")
        g.implants[bid].meta["specialization"] = {"kind": "subdistribution", "mask_key": specialize_mask}
    if aux_dim and hidden is not None:
        ah = _linear(g, hidden, g.node_dim(hidden), aux_dim, bid, "aux_head", gen, base_attrs={"dim": aux_dim})
        g.side_outputs[f"aux:{bid}"] = ah
        g.implants[bid].meta["aux_head"] = ah
    g.implants[bid].exit = out
    split_src = None
    if mode == "route" and G.meta.get("merge") is not None:
        r_node = g.nodes[G.meta["merge"]]
        live_terms = [t for t, on in zip(r_node.attrs["terms"], r_node.attrs["active"]) if on]
        nonzero = [t for t in live_terms if not _branch_output_is_zero(g, t)]
        if nonzero:
            src = tie_to if tie_to is not None else live_terms[-1]
            plain = channels is None and specialize_mask is None and not aux_dim and input_node is None
            if plain and (tie_to is not None or _copy_branch_params(g, src, bid)):
                split_src = src
            else:
                g.implants[bid].identity = "approximate"
                g.implants[bid].meta["route_init"] = "zero expert next to non-zero experts (approximate)"
    if mode == "route":
        pend = G.meta.get("route_pending")
        if G.meta["merge"] is None:
            attrs = {"router_in": g.node_dim(pend["router_in"]), "terms": [], "active": [],
                     **_dimattrs(g, G.entry)}
            import warnings
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                r = g.add_node("route", [pend["router_in"]], attrs, owner=group, role="merge", build=True)
            init_module(g.mods[g.nodes[r].pkey], gen, "default")
            g.nodes[pend["outer"]].inputs.append(r)
            g.nodes[pend["outer"]].attrs["coefs"].append(1.0)
            g.nodes[pend["outer"]].attrs["terms"].append("routed")
            G.meta["merge"] = r
        attach_term(g, G.meta["merge"], out, bid, gen=gen)
        if split_src is not None:
            _route_split_rows(g, G.meta["merge"], split_src, bid, route_split)
            g.implants[bid].meta["route_init"] = {"split_of": split_src, "s": route_split}
    else:
        attach_term(g, G.meta["merge"], out, bid, 1.0, term_dim=g.node_dim(out))
    g.implants[bid].merge = G.meta["merge"]
    g.implants[bid].nodes = [n for n in g.nodes if g.nodes[n].owner == bid]
    own = g.implants[bid].nodes
    bnode = next((n for n in own if g.nodes[n].role == "B"), None)
    anode = next((n for n in own if g.nodes[n].role == "act"), None)
    if bnode is not None:
        g.implants[bid].meta["cutpoints"] = {"hidden": [[bnode, 0]]}
    elif anode is not None:
        g.implants[bid].meta["cutpoints"] = {"pre_act": [[anode, 0]]}
    _finalize_modules(g, [n for n in g.nodes if int(n[1:]) >= first_new])
    g.meta["history"].append({"op": "add_branch", "implant": bid, "group": group, "tied_to": tie_to})
    g._plan = None
    return bid


def insert_cancel_pair(g: GraphNet, cut: Cut, gen: torch.Generator, width: int = 16, act: str = "relu",
                       tied: bool = False, noise: float = 0.0, slot: str = "", rnd=None) -> tuple[str, str, str]:
    """D: h + u(h) - v(h), u = v at insertion.  u, v have NONZERO output layers,
    so deleting either alone changes the function while deleting both does not.
    tied=True: v shares u's parameters (stays cancelled forever; control).
    noise>0: untied v perturbed by Gaussian noise (explicitly approximate)."""
    G = insert_group(g, cut, gen, "sum", "cancel_pair", slot, rnd)
    first_new = g.ctr["n"] + 1
    d = g.node_dim(g.implants[G].entry)
    m = g.implants[G].meta["merge"]
    u = new_branch_implant(g, G, "cancel_u", "output_preserving", slot + "/u")
    a, s, b = _branch_mlp(g, g.implants[G].entry, u, d, d, gen, width, act, "default")
    g.implants[u].exit = b
    attach_term(g, m, b, u, +1.0)
    v = new_branch_implant(g, G, "cancel_v", "output_preserving" if noise == 0 else "approximate", slot + "/v")
    cur = g.implants[G].entry
    mapping = {}
    for n in (a, s, b):
        on = g.nodes[n]
        if tied:
            cur = g.add_node(on.op, [cur], copy.deepcopy(on.attrs), owner=v, role=on.role, pkey=on.pkey)
        else:
            mod = copy.deepcopy(g.mods[on.pkey]) if on.pkey else None
            cur = g.add_node(on.op, [cur], copy.deepcopy(on.attrs), owner=v, role=on.role, module=mod)
            if noise and mod is not None:
                with torch.no_grad():
                    for prm in mod.parameters():
                        prm.add_(torch.randn(prm.shape, generator=gen, dtype=torch.float64).to(prm) * noise)
        mapping[n] = cur
    g.implants[v].exit = cur
    attach_term(g, m, cur, v, -1.0)
    for k, (bn, hid) in {u: (b, s), v: (mapping[b], mapping[s])}.items():
        g.implants[k].nodes = [n for n in g.nodes if g.nodes[n].owner == k]
        g.implants[k].merge = m
        g.implants[k].meta["cutpoints"] = {"hidden": [[bn, 0]]}
    g.implants[v].meta["tied_to"] = u if tied else None
    g.meta["twins"][v] = {"of": u, "map": mapping, "tied": tied}
    g.implants[G].identity = "output_preserving" if noise == 0 else "approximate"
    g.implants[G].meta["tied"] = tied
    _finalize_modules(g, [n for n in g.nodes if int(n[1:]) >= first_new])
    g._plan = None
    return G, u, v


def insert_dup_branch(g: GraphNet, segment: list[str], gen: torch.Generator, tied: bool = False,
                      split: float = 0.5, noise: float = 0.0, slot: str = "", rnd=None) -> tuple[str, str, str]:
    """C: duplicate an existing path segment (consecutive nodes, single-input
    first node) and merge  out = split*orig + (1-split)*copy  (renormalised merge).
    split != 0.5 is an exact symmetry breaker; noise > 0 is approximate."""
    for a, b in zip(segment[:-1], segment[1:]):
        if g.nodes[b].inputs != [a]:
            raise GraphError(f"segment nodes must form a single-input chain ({a}->{b})")
    seg_in = g.nodes[segment[0]].inputs
    if len(seg_in) != 1:
        raise GraphError("segment start must have exactly one input")
    seg_out = segment[-1]
    cut = Cut(source=seg_out, consumers=None)

    def body(g, h, iid, d, gen_, p):
        m = g.add_node("add", [h], {"coefs": [split], "terms": ["__orig__"], "renorm": True, **_dimattrs(g, h)},
                       owner=iid, role="merge")
        g.implants[iid].meta["merge"] = m
        g.implants[iid].meta["merge_mode"] = "sum"
        return m

    G = insert_series(g, cut, "dup_branch", body, {"tied": tied, "split": split, "noise": noise, "segment": segment},
                      gen, "output_preserving" if noise == 0 else "approximate", slot, rnd)
    first_new = g.ctr["n"] + 1
    m = g.implants[G].meta["merge"]
    orig = new_branch_implant(g, G, "dup_orig", "output_preserving", slot + "/orig",
                              meta={"backbone_term": True, "segment": segment})
    g.implants[orig].exit = seg_out
    g.implants[orig].entry = seg_in[0]
    g.implants[orig].merge = m
    g.nodes[m].attrs["terms"][0] = orig
    cpy = new_branch_implant(g, G, "dup_copy", "output_preserving", slot + "/copy")
    g.implants[cpy].entry = seg_in[0]
    cur, mapping = seg_in[0], {}
    for n in segment:
        on = g.nodes[n]
        if tied:
            cur = g.add_node(on.op, [cur], copy.deepcopy(on.attrs), owner=cpy, role=on.role or "copy", pkey=on.pkey)
        else:
            mod = copy.deepcopy(g.mods[on.pkey]) if on.pkey else None
            cur = g.add_node(on.op, [cur], copy.deepcopy(on.attrs), owner=cpy, role=on.role or "copy", module=mod)
            if noise and mod is not None:
                with torch.no_grad():
                    for prm in mod.parameters():
                        prm.add_(torch.randn(prm.shape, generator=gen, dtype=torch.float64).to(prm) * noise)
        mapping[n] = cur
    g.implants[cpy].exit = cur
    attach_term(g, m, cur, cpy, 1.0 - split)
    g.implants[cpy].merge = m
    g.implants[cpy].nodes = [n for n in g.nodes if g.nodes[n].owner == cpy]
    g.implants[cpy].meta["tied_to"] = "backbone" if tied else None
    g.meta["twins"][cpy] = {"of": "segment", "map": mapping, "tied": tied}
    _finalize_modules(g, [n for n in g.nodes if int(n[1:]) >= first_new])
    g._plan = None
    return G, orig, cpy


# =============================================================================
# Construction E: inverse pair T^{-1} o T
# =============================================================================

def insert_inverse_pair(g: GraphNet, cut: Cut, gen: torch.Generator, kind: str = "coupling", tie: str = "enforced",
                        width: int = 16, act: str = "tanh", slot: str = "", rnd=None,
                        cond: Optional[float] = None, W_init: Optional[torch.Tensor] = None) -> tuple[str, str, str]:
    """E: group G = Tinv o T.
    kind='coupling': T(h) = [h1, h2 + m(h1)], Tinv(y) = [y1, y2 - m'(y1)] (additive coupling / shear).
    kind='linear'  : T(h) = W h, Tinv(y) = W^{-1} y.
    tie='enforced' : m' IS m (shared params) / Tinv computed as the exact inverse of the live W:
                     global identity for every parameter value (up to float rounding).
    tie='untied'   : m' a copy of m (inverse at insertion only, may diverge).
    tie='learned'  : m' freshly initialised: NOT an identity until fitted (approximate; L0).
    kind='linear' only: W_init gives W explicitly (calibration constructions); cond = kappa >= 1 draws
    W = Q1 diag(s) Q2^T with singular values log-spaced in [kappa^-1/2, kappa^1/2] (condition number
    exactly kappa); default: a random orthogonal matrix times exp(0.3 N(0,1)) column scales.
    """
    if kind != "linear" and (cond is not None or W_init is not None):
        raise GraphError("cond / W_init apply to kind='linear' only")
    if cond is not None and not cond >= 1.0:
        raise GraphError("condition number must be >= 1")
    d = g.node_dim(cut.source) if cut.channels is None else len(cut.channels)
    if kind == "coupling" and d < 2:
        raise GraphError("coupling needs d >= 2")
    holder: dict = {}

    def body(g, h, iid, d_, gen_, p):
        d1 = d_ // 2

        def T_body(g, x, tid, dd, gen__, pp):
            if kind == "coupling":
                x1 = g.add_node("select", [x], {"idx": list(range(d1)), **_dimattrs(g, x, d1)}, owner=tid, role="x1")
                x2 = g.add_node("select", [x], {"idx": list(range(d1, dd)), **_dimattrs(g, x, dd - d1)}, owner=tid,
                                role="x2")
                a, s, b = _branch_mlp(g, x1, tid, d1, dd - d1, gen, width, act, "default")
                holder["m"] = (a, s, b)
                y2 = g.add_node("add", [x2, b], {"coefs": [1.0, 1.0], "terms": ["x2", "shift"],
                                                 **_dimattrs(g, x, dd - d1)}, owner=tid, role="shear")
                y = g.add_node("concat", [x1, y2], _dimattrs(g, x, dd), owner=tid, role="join")
                g.implants[tid].meta["cutpoints"] = {"hidden": [[b, 0]]}
                return y
            if W_init is not None:
                W = torch.as_tensor(W_init, dtype=torch.float64).clone()
                if W.shape != (dd, dd):
                    raise GraphError(f"W_init must be {dd}x{dd}")
            elif cond is not None:
                Q1 = torch.linalg.qr(torch.randn(dd, dd, generator=gen, dtype=torch.float64))[0]
                Q2 = torch.linalg.qr(torch.randn(dd, dd, generator=gen, dtype=torch.float64))[0]
                sv = torch.logspace(-0.5, 0.5, dd, base=float(cond), dtype=torch.float64) if dd > 1 else \
                    torch.ones(1, dtype=torch.float64)
                W = Q1 @ torch.diag(sv) @ Q2.T
            else:
                W = torch.linalg.qr(torch.randn(dd, dd, generator=gen, dtype=torch.float64))[0] * \
                    torch.exp(0.3 * torch.randn(dd, generator=gen, dtype=torch.float64))[None]
            if torch.linalg.matrix_rank(W) < dd:
                raise GraphError("inverse pair needs an invertible W")
            n1 = g.add_node("linear", [x], {"in": dd, "out": dd, "bias": True, **_dimattrs(g, x, dd)}, owner=tid,
                            role="W", build=True)
            _set_weight(g, n1, W)
            holder["W"] = (n1, W)
            return n1

        def Tinv_body(g, y, tid, dd, gen__, pp):
            if kind == "coupling":
                y1 = g.add_node("select", [y], {"idx": list(range(d1)), **_dimattrs(g, y, d1)}, owner=tid, role="y1")
                y2 = g.add_node("select", [y], {"idx": list(range(d1, dd)), **_dimattrs(g, y, dd - d1)}, owner=tid,
                                role="y2")
                a, s, b = holder["m"]
                cur = y1
                for n in (a, s, b):
                    on = g.nodes[n]
                    if tie == "enforced":
                        cur = g.add_node(on.op, [cur], copy.deepcopy(on.attrs), owner=tid, role=on.role, pkey=on.pkey)
                    else:
                        mod = copy.deepcopy(g.mods[on.pkey]) if on.pkey else None
                        if tie == "learned" and mod is not None:
                            init_module(mod, gen, "default")
                        cur = g.add_node(on.op, [cur], copy.deepcopy(on.attrs), owner=tid, role=on.role, module=mod)
                x2 = g.add_node("add", [y2, cur], {"coefs": [1.0, -1.0], "terms": ["y2", "unshift"],
                                                   **_dimattrs(g, y, dd - d1)}, owner=tid, role="unshear")
                x = g.add_node("concat", [y1, x2], _dimattrs(g, y, dd), owner=tid, role="join")
                g.implants[tid].meta["cutpoints"] = {"hidden": [[g.consumers(cur)[0][0], 1]]}
                return x
            n1, W = holder["W"]
            if tie == "enforced":
                return g.add_node("linear_inverse", [y], {"of": n1, **_dimattrs(g, y, dd)}, owner=tid, role="Winv",
                                  pkey=g.nodes[n1].pkey)
            n2 = g.add_node("linear", [y], {"in": dd, "out": dd, "bias": True, **_dimattrs(g, y, dd)}, owner=tid,
                            role="Winv", build=True)
            if tie == "learned":
                init_module(g.mods[g.nodes[n2].pkey], gen, "default")
            else:
                _set_weight(g, n2, torch.linalg.inv(W))
            return n2

        ident_T = "none"
        t = child_series(g, iid, h, "inverse_T", T_body, {}, gen, ident_T, deletion="bypass")
        ident_inv = "none"
        ti = child_series(g, iid, g.implants[t].exit, "inverse_Tinv", Tinv_body, {}, gen, ident_inv, deletion="bypass")
        holder["T"], holder["Tinv"] = t, ti
        g.implants[iid].meta["cutpoints"] = {"mid": [[g.consumers(g.implants[t].exit)[0][0], 0]]}
        g.implants[iid].meta["inverse"] = {"kind": kind, "tie": tie, "global_identity": tie == "enforced",
                                           "measured_only": tie != "enforced"}
        if kind == "linear":
            sv_ = torch.linalg.svdvals(holder["W"][1])
            g.implants[iid].meta["inverse"]["condition_number"] = float(sv_.max() / sv_.min())
        return g.implants[ti].exit

    ident = "approximate" if tie == "learned" else "output_preserving"
    G = insert_series(g, cut, "inverse_pair", body, {"kind": kind, "tie": tie, "width": width, "act": act}, gen, ident,
                      slot, rnd)
    # children were created inside body: fix their ownership lists (insert_series recomputed G's own nodes)
    return G, holder["T"], holder["Tinv"]


# =============================================================================
# Construction F: concatenation expansion  z = P [h ; act(A h)],  P = [I, 0]
# =============================================================================

def body_concat_expand(g, h, iid, d, gen, p):
    w = int(p.get("width", d))
    a = _linear(g, h, d, w, iid, "A", gen, base_attrs=_dimattrs(g, h, w))
    s = g.add_node("act", [a], {"fn": p.get("act", "relu"), **_dimattrs(g, h, w)}, owner=iid, role="act")
    attrs = {"term_dims": [d, w], "active": [True, True], "terms": ["skip", iid + ".expand"], "bias": False,
             **_dimattrs(g, h, d)}
    P = g.add_node("concat_proj", [h, s], attrs, owner=iid, role="P", build=True)
    W = torch.zeros(d, d + w, dtype=torch.float64)
    W[:, :d] = torch.eye(d, dtype=torch.float64)
    _set_weight(g, P, W)
    g.implants[iid].meta["cutpoints"] = {"hidden": [[P, 1]], "pre_act": [[s, 0]]}
    g.implants[iid].meta["projection_params"] = d * (d + w)
    return P


def insert_concat_expand(g, cut, gen, width=None, act="relu", slot="", rnd=None) -> str:
    d = g.node_dim(cut.source) if cut.channels is None else len(cut.channels)
    return insert_series(g, cut, "concat_expand", body_concat_expand, {"width": width or d, "act": act}, gen,
                         "exact_identity", slot, rnd)


# =============================================================================
# Gates (dissipation schedules) and pegs
# =============================================================================

def add_gate(g: GraphNet, iid: str, value: float = 1.0) -> str:
    """Attach a scalar gate to an implant without changing the function at value 1.
    series:  exit' = entry + gate*(exit - entry)  (inserted as gate_mix before consumers)
    branch:  the branch's merge coefficient is multiplied by the gate."""
    imp = g.implants[iid]
    if "gate" in imp.meta:
        return imp.meta["gate"]
    gid = g.new_gate(value)
    if imp.kind == "branch":
        m = g.nodes[imp.merge]
        if m.op == "route":
            raise GraphError("gate a routed expert by its router; not supported")
        if not m.attrs.get("gates"):
            m.attrs["gates"] = [None] * len(m.inputs)
        k = m.attrs["terms"].index(iid)
        m.attrs["gates"][k] = gid
    else:
        ex = imp.exit
        cons = [c for c in g.consumers(ex) if g.nodes[c[0]].owner not in ({iid} | set(g.implant_descendants(iid)))]
        gm = g.add_node("gate_mix", [imp.entry, ex], {"gate": gid, **_dimattrs(g, ex)}, owner=iid, role="gate")
        g.replace_uses(ex, gm, only=cons)
        if g.output == ex:
            g.output = gm
        # an implant stacked on this one (its entry was this exit) now reads the gated value: its entry
        # must follow, or its own gate / deletion would bypass to the UNGATED exit and keep this implant alive
        inner = {iid} | set(g.implant_descendants(iid))
        for j, other in g.implants.items():
            if j not in inner and other.entry == ex:
                other.entry = gm
        imp.exit = gm
        imp.nodes.append(gm)
    imp.meta["gate"] = gid
    g._plan = None
    return gid


# =============================================================================
# Deletion
# =============================================================================

def canonical_atoms(g: GraphNet, atoms: Iterable[str]) -> list[str]:
    atoms = set(atoms)
    for a in atoms:
        if a not in g.implants:
            raise InvalidDeletion(f"unknown implant {a}")
        if g.implants[a].deletion == "forbidden":
            raise InvalidDeletion(f"implant {a} is not deletable")
    keep = [a for a in atoms if not any(anc in atoms for anc in g.implant_ancestors(a))]
    return sorted(keep, key=lambda s: int(s[1:]))


def delete(g: GraphNet, atoms: Iterable[str], share_params: bool = True, simplify: bool = True) -> GraphNet:
    """Return a NEW graph with the given implants removed (fixed remaining weights)."""
    atoms = canonical_atoms(g, atoms)
    h = g.clone(share_params=share_params)
    pending = set(atoms)
    for a in atoms:
        pending |= set(h.implant_descendants(a))
    for a in atoms:
        _delete_one(h, a, pending)
    h.meta["deleted"] = sorted(set(h.meta.get("deleted", [])) | set(atoms), key=lambda s: int(s[1:]))
    if simplify:
        prune_dead(h)
    h._plan = None
    h.live_nodes()
    return h


def _delete_one(g: GraphNet, iid: str, pending: Optional[set] = None) -> None:
    imp = g.implants[iid]
    region = g.region(iid)
    gone_implants = {iid, *g.implant_descendants(iid)}
    # an implant whose internal values are read by other live nodes (e.g. a reconvergent bridge
    # reading a branch's hidden layer) cannot be deleted alone: delete those readers with it
    # liveness that tolerates readers of already-removed nodes: inside one multi-deletion such
    # readers belong to implants that are pending deletion themselves
    roots = [g.output] + list(g.side_outputs.values())
    live, stack = set(), [r_ for r_ in roots if r_ in g.nodes]
    while stack:
        n_ = stack.pop()
        if n_ in live:
            continue
        live.add(n_)
        stack.extend(i for i in g.nodes[n_].inputs if i in g.nodes)
    inner = set(region) - {imp.exit}
    pending = pending or set()
    readers = sorted({n.owner or n.id for n in g.nodes.values()
                      if n.id not in region and n.id in live and any(i in inner for i in n.inputs)
                      and n.owner not in pending}, key=str)
    if readers:
        raise InvalidDeletion(f"implant {iid} has internal values read outside it ({readers}); "
                              "delete its dependants with it")
    if imp.deletion == "fold":
        _fold_replace(g, iid)
        return
    if imp.kind == "series":
        ex, ent = imp.exit, imp.entry
        for n in g.nodes.values():
            if n.id in region:
                continue
            n.inputs = [ent if i == ex else i for i in n.inputs]
        if g.output == ex:
            g.output = ent
        for k, v in list(g.side_outputs.items()):
            if v in region:
                del g.side_outputs[k]
        for k, other in g.implants.items():
            if k in gone_implants:
                continue
            if other.entry == ex:
                other.entry = ent
            if other.exit == ex:
                other.exit = ent
    elif imp.kind == "branch":
        m = g.nodes[imp.merge]
        terms = m.attrs["terms"]
        if iid not in terms:
            raise InvalidDeletion(f"branch {iid} has no term in merge {imp.merge}")
        k = terms.index(iid)
        if m.op == "add":
            off = 0
            coefs = m.attrs["coefs"]
            removed = coefs[k]
            del m.inputs[k]
            del coefs[k]
            del terms[k]
            if m.attrs.get("gates"):
                del m.attrs["gates"][k]
            if m.attrs.get("renorm"):
                if not coefs:
                    raise InvalidDeletion(f"deleting {iid} would leave merge {m.id} with no terms")
                tot = sum(coefs)
                if tot == 0:
                    raise InvalidDeletion("renormalised merge has zero total weight")
                scale = (tot + removed) / tot
                m.attrs["coefs"] = [c * scale for c in coefs]
            elif not m.inputs:
                raise InvalidDeletion(f"merge {m.id} would be empty")
        elif m.op == "concat_proj":
            # inputs list holds active terms only; find position among active
            active = m.attrs["active"]
            pos = sum(1 for j in range(k) if active[j])
            if not active[k]:
                raise InvalidDeletion("term already inactive")
            del m.inputs[pos]
            if m.attrs.get("gates"):
                del m.attrs["gates"][pos]
            m.attrs["active"] = [a if j != k else False for j, a in enumerate(active)]
        elif m.op == "route":
            active = m.attrs["active"]
            pos = sum(1 for j in range(k) if active[j])
            del m.inputs[1 + pos]
            m.attrs["active"] = [a if j != k else False for j, a in enumerate(active)]
            if not any(m.attrs["active"]):
                # no experts left: routed term contributes nothing -> drop it from the outer merge
                outer = [c for c, s in g.consumers(m.id)]
                for c in outer:
                    on = g.nodes[c]
                    j = on.inputs.index(m.id)
                    del on.inputs[j]
                    del on.attrs["coefs"][j]
                    del on.attrs["terms"][j]
                    if on.attrs.get("gates"):
                        del on.attrs["gates"][j]
        else:
            raise InvalidDeletion(f"unsupported merge op {m.op}")
        for k2, v in list(g.side_outputs.items()):
            if v in region:
                del g.side_outputs[k2]
    else:
        raise InvalidDeletion(f"unknown implant kind {imp.kind}")
    for n in region:
        del g.nodes[n]
    for k in gone_implants:
        del g.implants[k]
    g._plan = None


def prune_dead(g: GraphNet) -> None:
    """Physically drop nodes that cannot reach an output and modules no longer used.
    Original backbone input nodes are kept."""
    live = g.live_nodes()
    for nid in list(g.nodes):
        if nid not in live and g.nodes[nid].op != "input":
            del g.nodes[nid]
    used = {n.pkey for n in g.nodes.values() if n.pkey is not None}
    for pk in list(g.mods.keys()):
        if pk not in used:
            del g.mods[pk]
            g.pkey_src.pop(pk, None)
    for k, imp in list(g.implants.items()):
        imp.nodes = [n for n in imp.nodes if n in g.nodes]
    g._plan = None


# =============================================================================
# Affine folding (exact algebra in float64)
# =============================================================================

def grad_mask_nodes(g: GraphNet, nodes: Iterable[str]) -> list[str]:
    """v59: the gradient-mask nodes (op mask_grad) among `nodes`.  Their forward value is their input (without a
    mask_forward context); they only decide which examples' gradients pass.  They are NOT position-wise affine
    operations for training purposes, so region_is_affine keeps refusing them; only the explicit unrouted fold
    (fold_implant(..., drop_grad_masks=True)) removes them, and it records that it did."""
    return sorted(n for n in nodes if g.nodes[n].op == "mask_grad")


def region_is_affine(g: GraphNet, nodes: Iterable[str]) -> bool:
    for n in nodes:
        nd = g.nodes[n]
        if nd.op in POSITIONWISE_AFFINE:
            continue
        if nd.op == "act" and (nd.attrs["fn"] == "identity" or
                               (nd.attrs["fn"] == "mix" and float(nd.attrs.get("s", 1.0)) == 0.0)):
            continue
        return False
    return True


@torch.no_grad()
def affine_map(g: GraphNet, entry: str, exit_: str, region: set[str]) -> tuple[torch.Tensor, torch.Tensor]:
    """Exact affine map (W, b) of the subgraph from `entry` to `exit_` whose
    internal nodes are `region` (all position-wise affine), computed in float64
    by evaluating on [0, e_1, ..., e_d]."""
    d = g.node_dim(entry)
    order = [n for n in g.topo_order(set(region) | {exit_}) if n in region or n == exit_]
    # the probe lives on the device of the region's modules (v9: a CPU probe failed against CUDA modules)
    dev = next((p.device for n in order if g.nodes[n].pkey for p in g.mods[g.nodes[n].pkey].parameters()),
               _device_dtype(g)[0])
    probe = torch.cat([torch.zeros(1, d, dtype=torch.float64, device=dev),
                       torch.eye(d, dtype=torch.float64, device=dev)])
    if g.layout == "img":
        probe = probe[:, :, None, None]
    elif g.layout == "seq":
        probe = probe[:, None, :]
    vals = {entry: probe}
    for nid in order:
        n = g.nodes[nid]
        for i in n.inputs:
            if i not in vals:
                raise GraphError(f"node {nid} reads {i} from outside the fold region")
        from .ops import FORWARD
        mod = g.mods[n.pkey] if n.pkey else None
        if mod is not None:
            mod64 = copy.deepcopy(mod).double()
        else:
            mod64 = None
        vals[nid] = FORWARD[n.op](n, [vals[i] for i in n.inputs], mod64, g, {"X": {}})
    out = vals[exit_].reshape(d + 1, -1)
    b = out[0]
    W = (out[1:] - b[None]).T
    return W, b


def _fold_replace(g: GraphNet, iid: str, drop_grad_masks: bool = False) -> str:
    imp = g.implants[iid]
    region = g.region(iid)
    if imp.meta.get("conv"):
        if drop_grad_masks:
            raise InvalidDeletion(f"implant {iid}: the unrouted fold is for vector implants")
        nid = _fold_conv_implant(g, iid)
        return _rewire_fold(g, iid, region, nid)
    masks = grad_mask_nodes(g, region) if drop_grad_masks else []
    if not region_is_affine(g, set(region) - set(masks)):
        raise InvalidDeletion(f"implant {iid} is not affine{' apart from its gradient masks' if masks else ''}; "
                              f"cannot fold")
    # the masks' forward value is their input: the map below is the region's forward function with or without them
    W, b = affine_map(g, imp.entry, imp.exit, region)
    d_out, d_in = W.shape
    parent = imp.parent
    # a bias only where the folded region can produce one (an all-linear, bias-free region folds to a
    # bias-free map), so folding a factorised bias-free layer restores the original architecture exactly
    has_bias = bool(torch.any(b != 0)) or any(
        g.nodes[n].op in ("linear", "linear_inverse") and g.nodes[n].attrs.get("bias", True) for n in region)
    nid = g.add_node("linear", [imp.entry], {"in": d_in, "out": d_out, "bias": has_bias, **_dimattrs(g, imp.exit)},
                     owner=parent, role="folded", build=True)
    _set_weight(g, nid, W, b if has_bias else None)
    dev, dt = _device_dtype(g)
    g.mods[g.nodes[nid].pkey].to(device=dev, dtype=dt)
    keys = sorted({g.nodes[n].attrs["mask_key"] for n in masks})
    out = _rewire_fold(g, iid, region, nid)
    if masks:
        # the fold keeps the forward function and ends the routing: the folded weights train on every example
        g.meta["history"][-1].update({"op": "fold_unrouted", "grad_masks_removed": keys})
    return out


def _rewire_fold(g: GraphNet, iid: str, region: set, nid: str) -> str:
    imp = g.implants[iid]
    for n in g.nodes.values():
        if n.id in region:
            continue
        n.inputs = [nid if i == imp.exit else i for i in n.inputs]
    if g.output == imp.exit:
        g.output = nid
    gone = {iid, *g.implant_descendants(iid)}
    for k, other in g.implants.items():
        if k in gone:
            continue
        if other.entry == imp.exit:
            other.entry = nid
        if other.exit == imp.exit:
            other.exit = nid
    for n in region:
        del g.nodes[n]
    for k in gone:
        del g.implants[k]
    g.meta["history"].append({"op": "fold", "implant": iid, "node": nid})
    g._plan = None
    return nid


def fold_implant(g: GraphNet, iid: str, share_params: bool = True, drop_grad_masks: bool = False) -> GraphNet:
    """fold an affine implant into one linear node (exact, float64).  drop_grad_masks (v59): also fold an implant
    whose only non-affine nodes are gradient masks; the forward function is unchanged and the routing they imposed
    on training ends (recorded as op fold_unrouted in the graph's history)."""
    h = g.clone(share_params=share_params)
    _fold_replace(h, iid, drop_grad_masks=drop_grad_masks)
    prune_dead(h)
    return h


def fold_affine_chain(g: GraphNet, start: str, end: str, share_params: bool = True) -> GraphNet:
    """Fold the backbone segment strictly after `start` up to and including
    `end` into one linear node, if every node in between is position-wise
    affine and reads only from inside the segment or from `start`."""
    h = g.clone(share_params=share_params)
    seg = (h.descendants(start) & (h.ancestors(end) | {end}))
    if not region_is_affine(h, seg):
        raise GraphError("segment is not affine")
    for n in seg:
        for i in h.nodes[n].inputs:
            if i != start and i not in seg:
                raise GraphError(f"segment node {n} reads external {i}")
    W, b = affine_map(h, start, end, seg - {end})
    nid = h.add_node("linear", [start], {"in": W.shape[1], "out": W.shape[0], "bias": True,
                                         **_dimattrs(h, end)}, role="folded", build=True)
    _set_weight(h, nid, W, b)
    dev, dt = _device_dtype(h)
    h.mods[h.nodes[nid].pkey].to(device=dev, dtype=dt)
    h.replace_uses(end, nid, exclude=seg | {nid})
    prune_dead(h)
    return h
