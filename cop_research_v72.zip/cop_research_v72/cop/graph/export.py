"""Compact export (T15): physically remove retired modules, bypasses at
endpoint gates, auxiliary heads and transparent nodes; slice inactive merge
terms; optionally fold adjacent linear maps when that reduces parameters.
The exported graph is verified against the source graph on supplied inputs.
"""
from __future__ import annotations

import copy
from typing import Optional

import torch

from .graph import GraphNet
from .ops import build_module
from . import edits as E
from .accounting import report


def _bypass_node(g: GraphNet, nid: str, via: str) -> None:
    g.replace_uses(nid, via, exclude={nid})
    for imp in g.implants.values():
        if imp.entry == nid:
            imp.entry = via
        if imp.exit == nid:
            imp.exit = via


@torch.no_grad()
def export_compact(g: GraphNet, inputs: Optional[dict] = None, fold_linear: bool = True,
                   keep_side_outputs: bool = False) -> tuple[GraphNet, dict]:
    h = g.clone(share_params=False)
    h.eval()
    notes = []
    # 1. endpoint gates
    for nid in list(h.nodes):
        n = h.nodes.get(nid)
        if n is None or n.op != "gate_mix":
            continue
        gv = h.gate_vals[n.attrs["gate"]]
        if gv in (0.0, 1.0):
            _bypass_node(h, nid, n.inputs[1] if gv == 1.0 else n.inputs[0])
        else:
            notes.append(f"gate {n.attrs['gate']} at {gv} (not an endpoint) kept")
    for nid in list(h.nodes):
        n = h.nodes.get(nid)
        if n is None or n.op != "add" or not n.attrs.get("gates"):
            continue
        keep = []
        for j, gid in enumerate(n.attrs["gates"]):
            gv = 1.0 if gid is None else h.gate_vals[gid]
            if gv == 0.0:
                continue
            if gid is not None and gv != 1.0:
                n.attrs["coefs"][j] *= gv
                notes.append(f"gate {gid} at {gv} folded into coefficient")
            keep.append(j)
        n.inputs = [n.inputs[j] for j in keep]
        n.attrs["coefs"] = [n.attrs["coefs"][j] for j in keep]
        n.attrs["terms"] = [n.attrs["terms"][j] for j in keep]
        n.attrs["gates"] = None
    # zero coefficient terms
    for n in h.nodes.values():
        if n.op == "add":
            keep = [j for j, c in enumerate(n.attrs["coefs"]) if c != 0.0]
            if len(keep) != len(n.inputs) and keep:
                n.inputs = [n.inputs[j] for j in keep]
                n.attrs["coefs"] = [n.attrs["coefs"][j] for j in keep]
                n.attrs["terms"] = [n.attrs["terms"][j] for j in keep]
                if n.attrs.get("gates"):
                    n.attrs["gates"] = [n.attrs["gates"][j] for j in keep]
    # 2. side outputs
    if not keep_side_outputs:
        h.side_outputs = {}
    # 3. slice inactive concat_proj / route terms
    for nid, n in list(h.nodes.items()):
        if n.op == "concat_proj" and not all(n.attrs["active"]):
            m = h.mods[n.pkey]
            cols, start = [], 0
            for d, on in zip(n.attrs["term_dims"], n.attrs["active"]):
                if on:
                    cols.extend(range(start, start + d))
                start += d
            attrs = dict(n.attrs)
            attrs["term_dims"] = [d for d, on in zip(n.attrs["term_dims"], n.attrs["active"]) if on]
            attrs["terms"] = [t for t, on in zip(n.attrs["terms"], n.attrs["active"]) if on]
            attrs["active"] = [True] * len(attrs["term_dims"])
            new = build_module("concat_proj", attrs).to(m.weight.device, m.weight.dtype)
            new.weight.copy_(m.weight[:, cols])
            if new.bias is not None:
                new.bias.copy_(m.bias)
            E._replace_module(h, nid, new, attrs)
        if n.op == "route" and not all(n.attrs["active"]):
            m = h.mods[n.pkey]
            rows = [i for i, on in enumerate(n.attrs["active"]) if on]
            attrs = dict(n.attrs)
            attrs["terms"] = [t for t, on in zip(n.attrs["terms"], n.attrs["active"]) if on]
            attrs["active"] = [True] * len(rows)
            new = build_module("route", attrs).to(m.weight.device, m.weight.dtype)
            new.weight.copy_(m.weight[rows])
            new.bias.copy_(m.bias[rows])
            E._replace_module(h, nid, new, attrs)
    # 4. transparent nodes
    for nid in list(h.nodes):
        n = h.nodes.get(nid)
        if n is None:
            continue
        if n.op == "identity" or (n.op == "add" and len(n.inputs) == 1 and n.attrs["coefs"][0] == 1.0) or \
                (n.op == "scale" and n.attrs["c"] == 1.0):
            _bypass_node(h, nid, n.inputs[0])
    E.prune_dead(h)
    # 5. fold adjacent linears when it does not increase parameters
    n_fold = 0
    if fold_linear:
        changed = True
        while changed:
            changed = False
            for nid in list(h.nodes):
                n = h.nodes.get(nid)
                if n is None or n.op != "linear":
                    continue
                src = h.nodes[n.inputs[0]]
                if src.op != "linear" or len(h.consumers(src.id)) != 1 or src.id in h.side_outputs.values():
                    continue
                if h.nodes[src.id].attrs.get("layout") != n.attrs.get("layout"):
                    continue
                if any(m.pkey == src.pkey for m in h.nodes.values() if m.id != src.id) or \
                        any(m.pkey == n.pkey for m in h.nodes.values() if m.id != n.id):
                    continue  # shared parameters: folding would untie them
                m1, m2 = h.mods[src.pkey], h.mods[n.pkey]
                before = m1.weight.numel() + m2.weight.numel() + (m1.bias.numel() if m1.bias is not None else 0) + \
                    (m2.bias.numel() if m2.bias is not None else 0)
                after = m2.out_features * m1.in_features + m2.out_features
                if after > before:
                    continue
                W = m2.weight.double() @ m1.weight.double()
                b = (m2.weight.double() @ m1.bias.double() if m1.bias is not None else 0) + \
                    (m2.bias.double() if m2.bias is not None else 0)
                attrs = dict(n.attrs)
                attrs.update({"in": m1.in_features, "bias": True})
                nn_id = h.add_node("linear", [src.inputs[0]], attrs, owner=n.owner, role="folded", build=True)
                E._set_weight(h, nn_id, W, b if isinstance(b, torch.Tensor) else torch.zeros(W.shape[0]))
                h.mods[h.nodes[nn_id].pkey].to(m2.weight.device, m2.weight.dtype)
                _bypass_node(h, nid, nn_id)
                E.prune_dead(h)
                n_fold += 1
                changed = True
                break
    E.prune_dead(h)
    # retire implant records with no remaining nodes
    for k in list(h.implants):
        if not h.implants[k].nodes:
            h.implants[k].meta["physically_removed"] = True
    h._plan = None
    rep = {"notes": notes, "n_linear_folds": n_fold, "before": report(g), "after": report(h)}
    if inputs is not None:
        from ..train.trainer import model_dtype
        dt = model_dtype(g)
        inputs = {k: (v.to(dt) if v.is_floating_point() else v) for k, v in inputs.items()}
        g_was = g.training
        g.eval()
        y0 = g(inputs)
        y1 = h(inputs)
        g.train(g_was)
        err = (y0.double() - y1.double()).abs()
        scale = y0.double().abs().mean().clamp_min(1e-12)
        rep["max_abs_err"] = float(err.max())
        rep["rel_err"] = float(err.max() / scale)
    return h, rep
