"""GraphNet: an explicit, editable computation graph with persistent IDs.

Nodes
  Every original module, implant node, branch, merge and peg node has a
  persistent id ('n<k>').  `inputs` lists the producer of each input slot, so a
  *node cut* (all consumers) and an *edge cut* (selected consumers) are
  different edits.  Parameters live in `mods[pkey]`; nodes that share a pkey
  share parameters (tied copies, recurrent pearls).

Implants
  Every edit that adds computation is recorded as an `Implant` with id 'I<k>',
  construction name, parent implant (the innermost implant containing the cut),
  generation, entry/exit nodes, owned nodes, the resolved cut, the identity
  guarantee and its deletion semantics:
    'bypass'     (series)  remove region; uses of exit outside the region read entry
    'drop_term'  (branch)  remove region; drop the implant's term from its merge
                           (renormalising the merge if the merge says so)
    'fold'                 replace region by the exact affine map it computes
  Region(I) = nodes owned by I or by any descendant of I.  Deleting an implant
  therefore removes its descendants too; deletion subsets are canonicalised
  (descendants of deleted implants are dropped) and resulting graphs are
  de-duplicated by structural hash, so nested bypasses are never counted twice.
"""
from __future__ import annotations

import copy
import dataclasses
import itertools
from dataclasses import dataclass, field
from typing import Any, Iterable, Optional

import torch
import torch.nn as nn

from ..utils import sha256_str, canonical_json, stable_hash
from .ops import FORWARD, build_module

NON_STRUCTURAL_ATTRS = {"tag", "note", "cut_name"}

# Content fingerprints of module tensors.  A deletion family evaluates many
# graphs that share most parameter storages, so fingerprints are cached per
# live tensor object: the entry holds a weak reference (a freed tensor whose id
# is reused never matches) and the tensor's in-place version counter (any
# in-place change invalidates the entry).
_FP_CACHE: dict = {}


def _tensor_fp(t: torch.Tensor) -> str:
    import weakref
    from ..utils import tensor_hash
    ent = _FP_CACHE.get(id(t))
    if ent is not None:
        ref, ver, val = ent
        if ref() is t and ver == t._version:
            return val
    val = tensor_hash(t, 24)
    if len(_FP_CACHE) > 200_000:
        _FP_CACHE.clear()
    try:
        _FP_CACHE[id(t)] = (weakref.ref(t), t._version, val)
    except TypeError:
        pass
    return val


def _module_fingerprint(m: nn.Module) -> str:
    items = [(k, _tensor_fp(v)) for k, v in sorted(m.state_dict(keep_vars=True).items())]
    return sha256_str(canonical_json([type(m).__name__, items]))


class InvalidDeletion(Exception):
    pass


class GraphError(Exception):
    pass


@dataclass
class Node:
    id: str
    op: str
    inputs: list[str]
    attrs: dict
    pkey: Optional[str] = None
    owner: Optional[str] = None      # implant id owning this node (None = original backbone)
    role: str = ""


@dataclass
class Implant:
    id: str
    construction: str
    kind: str                         # 'series' | 'branch'
    parent: Optional[str]
    generation: int
    entry: Optional[str]              # value the implant replaces / reads
    exit: Optional[str]               # node whose value replaces entry (series) or the branch term (branch)
    nodes: list[str]
    cut: dict
    identity: str                     # 'exact_identity' | 'output_preserving' | 'approximate' | 'none'
    deletion: str = "bypass"          # 'bypass' | 'drop_term' | 'fold' | 'forbidden'
    merge: Optional[str] = None       # merge node holding this branch's term
    slot: str = ""                    # structural slot label (used for common random numbers)
    round: Optional[int] = None
    meta: dict = field(default_factory=dict)


class GraphNet(nn.Module):
    def __init__(self, layout: str, family: str = ""):
        super().__init__()
        self.layout = layout
        self.family = family
        self.mods = nn.ModuleDict()
        self.nodes: dict[str, Node] = {}
        self.implants: dict[str, Implant] = {}
        self.inputs: dict[str, str] = {}
        self.output: Optional[str] = None
        self.side_outputs: dict[str, str] = {}
        self.gate_vals: dict[str, float] = {}
        self.pkey_src: dict[str, dict] = {}
        self.ctr = {"n": 0, "p": 0, "I": 0, "g": 0}
        self.meta: dict[str, Any] = {"cutpoints": [], "history": [], "twins": {}, "deleted": []}
        self.frozen_bn: set[str] = set()
        self._plan = None
        self._idx_cache: dict = {}

    # ------------------------------------------------------------------ ids
    def _new(self, kind: str) -> str:
        self.ctr[kind] += 1
        return f"{kind}{self.ctr[kind]}"

    def new_gate(self, value: float = 1.0) -> str:
        gid = self._new("g")
        self.gate_vals[gid] = float(value)
        return gid

    def index_buffer(self, idx: list[int], device) -> torch.Tensor:
        key = (tuple(idx), str(device))
        t = self._idx_cache.get(key)
        if t is None:
            t = torch.tensor(list(idx), dtype=torch.long, device=device)
            self._idx_cache[key] = t
        return t

    # --------------------------------------------------------------- building
    def add_node(self, op: str, inputs: list[str], attrs: dict, owner: Optional[str] = None, role: str = "",
                 module: Optional[nn.Module] = None, pkey: Optional[str] = None, build: bool = False) -> str:
        if op not in FORWARD:
            raise GraphError(f"unknown op {op}")
        for i in inputs:
            if i not in self.nodes:
                raise GraphError(f"input {i} of new {op} node does not exist")
        attrs = dict(attrs)
        attrs.setdefault("layout", self.layout)
        if build and module is None:
            module = build_module(op, attrs)
            dev, dt = self._dev_dtype()
            module.to(device=dev, dtype=dt)
        if module is not None:
            if pkey is not None:
                raise GraphError("give either module or shared pkey")
            pkey = self._new("p")
            self.mods[pkey] = module
            self.pkey_src[pkey] = {"op": op, "attrs": copy.deepcopy(attrs)}
        elif pkey is not None and pkey not in self.mods:
            raise GraphError(f"shared pkey {pkey} does not exist")
        nid = self._new("n")
        self.nodes[nid] = Node(nid, op, list(inputs), attrs, pkey, owner, role)
        self._plan = None
        return nid

    def set_input(self, stream: str, dim: int, **attrs) -> str:
        nid = self.add_node("input", [], {"stream": stream, "dim": dim, **attrs}, role="input")
        self.inputs[stream] = nid
        return nid

    def set_output(self, nid: str) -> None:
        self.output = nid
        self._plan = None

    def add_cutpoint(self, name: str, kind: str, index: int, edges: list[tuple[str, int]], **extra) -> None:
        self.meta["cutpoints"].append({"name": name, "kind": kind, "index": index,
                                       "edges": [list(e) for e in edges], **extra})

    # ------------------------------------------------------------- structure
    def consumers(self, nid: str, nodes: Optional[Iterable[str]] = None) -> list[tuple[str, int]]:
        out = []
        for cid in (nodes if nodes is not None else self.nodes):
            n = self.nodes[cid]
            for s, i in enumerate(n.inputs):
                if i == nid:
                    out.append((cid, s))
        return out

    def live_nodes(self) -> set[str]:
        roots = [self.output] + list(self.side_outputs.values())
        live, stack = set(), [r for r in roots if r is not None]
        while stack:
            n = stack.pop()
            if n in live:
                continue
            live.add(n)
            stack.extend(self.nodes[n].inputs)
        return live

    def topo_order(self, nodes: Optional[set[str]] = None) -> list[str]:
        nodes = self.live_nodes() if nodes is None else nodes
        order, state = [], {}
        for root in sorted(nodes, key=lambda s: int(s[1:])):
            if root in state:
                continue
            stack = [(root, False)]
            while stack:
                n, done = stack.pop()
                if done:
                    state[n] = 2
                    order.append(n)
                    continue
                st = state.get(n, 0)
                if st == 2:
                    continue
                if st == 1:
                    raise GraphError(f"cycle through {n}")
                state[n] = 1
                stack.append((n, True))
                for i in self.nodes[n].inputs:
                    if i in nodes and state.get(i, 0) != 2:
                        if state.get(i, 0) == 1:
                            raise GraphError(f"cycle through {i}")
                        stack.append((i, False))
        return order

    def ancestors(self, nid: str) -> set[str]:
        out, stack = set(), list(self.nodes[nid].inputs)
        while stack:
            n = stack.pop()
            if n not in out:
                out.add(n)
                stack.extend(self.nodes[n].inputs)
        return out

    def descendants(self, nid: str) -> set[str]:
        cons: dict[str, list[str]] = {}
        for n in self.nodes.values():
            for i in n.inputs:
                cons.setdefault(i, []).append(n.id)
        out, stack = set(), list(cons.get(nid, []))
        while stack:
            n = stack.pop()
            if n not in out:
                out.add(n)
                stack.extend(cons.get(n, []))
        return out

    def implant_children(self, iid: Optional[str]) -> list[str]:
        return [k for k, v in self.implants.items() if v.parent == iid]

    def implant_descendants(self, iid: str) -> list[str]:
        out, stack = [], self.implant_children(iid)
        while stack:
            k = stack.pop()
            out.append(k)
            stack.extend(self.implant_children(k))
        return out

    def implant_ancestors(self, iid: str) -> list[str]:
        out, p = [], self.implants[iid].parent
        while p is not None:
            out.append(p)
            p = self.implants[p].parent
        return out

    def region(self, iid: str) -> set[str]:
        ids = {iid, *self.implant_descendants(iid)}
        return {nid for nid, n in self.nodes.items() if n.owner in ids}

    def owner_chain(self, nid: str) -> list[Optional[str]]:
        o = self.nodes[nid].owner
        chain = []
        while o is not None:
            chain.append(o)
            o = self.implants[o].parent
        return chain + [None]

    def lca_owner(self, nids: list[str]) -> Optional[str]:
        chains = [self.owner_chain(n) for n in nids]
        common = set(chains[0])
        for c in chains[1:]:
            common &= set(c)
        for o in chains[0]:
            if o in common:
                return o
        return None

    def node_dim(self, nid: str) -> int:
        return int(self.nodes[nid].attrs["dim"])

    # ---------------------------------------------------------------- rewiring
    def replace_uses(self, old: str, new: str, exclude: set[str] = frozenset(),
                     only: Optional[list[tuple[str, int]]] = None) -> None:
        if only is not None:
            for cid, s in only:
                if self.nodes[cid].inputs[s] != old:
                    raise GraphError(f"edge {old}->{cid}[{s}] does not exist")
                self.nodes[cid].inputs[s] = new
        else:
            for n in self.nodes.values():
                if n.id in exclude:
                    continue
                n.inputs = [new if i == old else i for i in n.inputs]
            if self.output == old:
                self.output = new
            for k, v in list(self.side_outputs.items()):
                if v == old:
                    self.side_outputs[k] = new
        self._plan = None

    # ---------------------------------------------------------------- forward
    def _compile(self):
        live = self.live_nodes()
        order = self.topo_order(live)
        last_use: dict[str, int] = {}
        for t, nid in enumerate(order):
            for i in self.nodes[nid].inputs:
                last_use[i] = t
        keep = {self.output, *self.side_outputs.values()}
        frees: dict[int, list[str]] = {}
        for nid, t in last_use.items():
            if nid not in keep:
                frees.setdefault(t, []).append(nid)
        plan = []
        for t, nid in enumerate(order):
            n = self.nodes[nid]
            mod = self.mods[n.pkey] if n.pkey is not None else None
            plan.append((nid, FORWARD[n.op], n, mod, tuple(n.inputs), tuple(frees.get(t, ()))))
        self._plan = plan

    def forward(self, X, ctx: Optional[dict] = None, return_nodes: Optional[Iterable[str]] = None):
        if isinstance(X, torch.Tensor):
            X = {"x": X}
        if self._plan is None:
            self._compile()
        ctx = {} if ctx is None else ctx
        ctx["X"] = X
        keep = set(return_nodes) if return_nodes else set()
        vals: dict[str, torch.Tensor] = {}
        col = ctx.get("collect")
        if col:
            ctx["collected"] = {}
        # value interventions {nid: fn(tensor) -> tensor}: per call (ctx["patch"], e.g. training-time route
        # erasure) or set on the object for analysis (value_patch)
        patch = ctx.get("patch") or getattr(self, "value_patch", None)
        for nid, fn, node, mod, ins, frees in self._plan:
            vals[nid] = fn(node, [vals[i] for i in ins], mod, self, ctx)
            if patch is not None and nid in patch:
                vals[nid] = patch[nid](vals[nid])
            if col and nid in col:
                ctx["collected"][nid] = vals[nid]
            for f in frees:
                if f not in keep:
                    vals.pop(f, None)
        if self.side_outputs:
            ctx["side"] = {k: vals[v] for k, v in self.side_outputs.items()}
        if return_nodes:
            missing = [k for k in keep if k not in vals]
            if missing:
                raise GraphError(f"requested nodes not live: {missing}")
            return vals[self.output], {k: vals[k] for k in keep}
        return vals[self.output]

    def train(self, mode: bool = True):
        super().train(mode)
        for pk in self.frozen_bn:
            if pk in self.mods:
                self.mods[pk].eval()
        return self

    # ---------------------------------------------------------- serialisation
    def to_spec(self) -> dict:
        return {
            "layout": self.layout, "family": self.family,
            "nodes": [dataclasses.asdict(n) for n in self.nodes.values()],
            "implants": [dataclasses.asdict(i) for i in self.implants.values()],
            "inputs": dict(self.inputs), "output": self.output, "side_outputs": dict(self.side_outputs),
            "gate_vals": dict(self.gate_vals), "pkey_src": copy.deepcopy(self.pkey_src), "ctr": dict(self.ctr),
            "meta": copy.deepcopy(self.meta), "frozen_bn": sorted(self.frozen_bn),
        }

    @classmethod
    def from_spec(cls, spec: dict, build_modules: bool = True) -> "GraphNet":
        g = cls(spec["layout"], spec.get("family", ""))
        for nd in spec["nodes"]:
            n = Node(**copy.deepcopy(nd))
            g.nodes[n.id] = n
        for idd in spec["implants"]:
            i = Implant(**copy.deepcopy(idd))
            g.implants[i.id] = i
        g.inputs = dict(spec["inputs"])
        g.output = spec["output"]
        g.side_outputs = dict(spec["side_outputs"])
        g.gate_vals = dict(spec["gate_vals"])
        g.pkey_src = copy.deepcopy(spec["pkey_src"])
        g.ctr = dict(spec["ctr"])
        g.meta = copy.deepcopy(spec["meta"])
        g.frozen_bn = set(spec.get("frozen_bn", []))
        if build_modules:
            for pk, src in g.pkey_src.items():
                g.mods[pk] = build_module(src["op"], src["attrs"])
        return g

    def checkpoint(self) -> dict:
        state = {k: v.detach().cpu().clone() for k, v in self.state_dict().items()}
        return {"spec": self.to_spec(), "state": state, "dtypes": {k: str(v.dtype) for k, v in state.items()}}

    @classmethod
    def from_checkpoint(cls, ck: dict, device="cpu") -> "GraphNet":
        """Rebuild modules, then give every floating parameter / buffer the dtype
        it was saved with BEFORE loading (load_state_dict would otherwise cast
        float64 values into freshly built float32 modules).  Integer and bool
        buffers keep their own dtypes."""
        g = cls.from_spec(ck["spec"])
        sd = ck["state"]
        with torch.no_grad():
            for name, t in itertools.chain(g.named_parameters(), g.named_buffers()):
                src = sd.get(name)
                if src is not None and t.is_floating_point() and src.is_floating_point() and t.dtype != src.dtype:
                    t.data = t.data.to(src.dtype)
        g.load_state_dict(sd)
        for name, t in itertools.chain(g.named_parameters(), g.named_buffers()):
            if name in sd and t.dtype != sd[name].dtype:
                raise GraphError(f"checkpoint dtype not preserved for {name}: {sd[name].dtype} -> {t.dtype}")
        return g.to(device)

    def clone(self, share_params: bool = True) -> "GraphNet":
        g = GraphNet.from_spec(self.to_spec(), build_modules=False)
        for k, m in self.mods.items():
            g.mods[k] = m if share_params else copy.deepcopy(m)
        g.train(self.training)
        return g

    def _dev_dtype(self):
        for p in self.parameters():
            if p.is_floating_point():
                return p.device, p.dtype
        return torch.device("cpu"), torch.float32

    def device(self):
        for p in self.parameters():
            return p.device
        for b in self.buffers():
            return b.device
        return torch.device("cpu")

    # ----------------------------------------------------------------- hashing
    def _transparent_input(self, n: Node) -> Optional[int]:
        """Index of the input this node passes through unchanged, else None."""
        if n.op == "identity":
            return 0
        if n.op == "add" and len(n.inputs) == 1 and n.attrs["coefs"][0] == 1.0 and \
                not (n.attrs.get("gates") and n.attrs["gates"][0] is not None):
            return 0
        if n.op == "scale" and n.attrs["c"] == 1.0:
            return 0
        if n.op == "gate_mix":
            gv = self.gate_vals[n.attrs["gate"]]
            return 1 if gv == 1.0 else (0 if gv == 0.0 else None)
        return None

    def structural_hash(self) -> str:
        """Id-independent Merkle hash of the live graph, including parameter
        sharing classes, dimensions, merge coefficients and gate values."""
        live = self.live_nodes()
        order = self.topo_order(live)

        def attrs_struct(n: Node):
            a = {k: v for k, v in n.attrs.items() if k not in NON_STRUCTURAL_ATTRS}
            if "gates" in a and a["gates"]:
                a["gates"] = [None if gg is None else self.gate_vals[gg] for gg in a["gates"]]
            if "gate" in a and a["gate"] is not None:
                a["gate"] = self.gate_vals[a["gate"]]
            a.pop("terms", None)
            return a

        transparent = self._transparent_input

        def run(share_cls: dict[str, str]) -> dict[str, str]:
            sig: dict[str, str] = {}
            for nid in order:
                n = self.nodes[nid]
                t = transparent(n)
                if t is not None:
                    sig[nid] = sig[n.inputs[t]]
                    continue
                sig[nid] = sha256_str(canonical_json([n.op, attrs_struct(n), [sig[i] for i in n.inputs],
                                                      share_cls.get(n.pkey, "")]))
            return sig

        sig0 = run({})
        users: dict[str, list[str]] = {}
        for nid in order:
            pk = self.nodes[nid].pkey
            if pk is not None:
                users.setdefault(pk, []).append(sig0[nid])
        share_cls = {pk: sha256_str(canonical_json(sorted(s))) for pk, s in users.items() if len(s) > 1}
        sig = run(share_cls)
        return sha256_str(canonical_json([sig[self.output], {k: sig[v] for k, v in self.side_outputs.items()}]))[:16]

    def instance_hash(self) -> str:
        """Hash of the live computation with every operation bound to the
        CONTENT of the parameters it uses: a Merkle hash in which each node's
        signature includes its op, structural attrs (coefficients, effective
        gate values), its inputs' signatures and a fingerprint of its module's
        tensors (parameters and buffers, dtype and shape included).  Two graphs
        get the same instance hash only if they compute the same composition
        with the same weights at the same positions; swapping two equal-shaped
        modules, folding new weights, or changing a gate changes the hash.
        Shared parameters are recognised by equal fingerprints."""
        live = self.live_nodes()
        order = self.topo_order(live)
        fp = {pk: _module_fingerprint(self.mods[pk]) for pk in {self.nodes[n].pkey for n in live} if pk is not None}
        sig: dict[str, str] = {}
        for nid in order:
            n = self.nodes[nid]
            t = self._transparent_input(n)
            if t is not None:              # value passes through unchanged: same computation
                sig[nid] = sig[n.inputs[t]]
                continue
            a = {k: v for k, v in n.attrs.items() if k not in NON_STRUCTURAL_ATTRS}
            if a.get("gates"):
                a["gates"] = [None if gg is None else self.gate_vals[gg] for gg in a["gates"]]
            if a.get("gate") is not None:
                a["gate"] = self.gate_vals[a["gate"]]
            a.pop("terms", None)
            sig[nid] = sha256_str(canonical_json([n.op, a, [sig[i] for i in n.inputs], fp.get(n.pkey, "")]))
        return sha256_str(canonical_json([sig[self.output], {k: sig[v] for k, v in self.side_outputs.items()}]))[:16]

    def param_hash(self) -> str:
        from ..utils import tensor_hash
        return stable_hash({k: tensor_hash(v) for k, v in self.state_dict().items()})

    # --------------------------------------------------------------- counting
    def live_pkeys(self) -> set[str]:
        return {self.nodes[n].pkey for n in self.live_nodes() if self.nodes[n].pkey is not None}

    def n_params(self, live_only: bool = True, trainable_only: bool = False) -> int:
        pks = self.live_pkeys() if live_only else set(self.mods.keys())
        tot = 0
        for pk in pks:
            for p in self.mods[pk].parameters():
                if trainable_only and not p.requires_grad:
                    continue
                tot += p.numel()
        return tot

    def atoms(self) -> list[str]:
        """Atomic deletion units: every implant whose deletion is allowed."""
        return [k for k, v in self.implants.items() if v.deletion in ("bypass", "drop_term", "fold")]

    # ----------------------------------------------------------------- export
    def to_json_graph(self) -> dict:
        live = self.live_nodes()
        return {
            "structural_hash": self.structural_hash(),
            "nodes": [{"id": n.id, "op": n.op, "inputs": n.inputs, "owner": n.owner, "role": n.role,
                       "pkey": n.pkey, "live": n.id in live,
                       "attrs": {k: v for k, v in n.attrs.items() if k not in ("idx",)} |
                                ({"n_idx": len(n.attrs["idx"])} if "idx" in n.attrs else {})}
                      for n in self.nodes.values()],
            "implants": [dataclasses.asdict(i) for i in self.implants.values()],
            "output": self.output, "side_outputs": self.side_outputs, "gates": self.gate_vals,
            "shared_pkeys": {pk: [n.id for n in self.nodes.values() if n.pkey == pk]
                             for pk in self.mods if sum(1 for n in self.nodes.values() if n.pkey == pk) > 1},
        }

    def to_dot(self) -> str:
        live = self.live_nodes()
        colors = ["#dbeafe", "#fde68a", "#bbf7d0", "#fecaca", "#e9d5ff", "#fed7aa", "#a5f3fc"]
        lines = ["digraph G {", "  rankdir=TB; node [shape=box, style=filled, fontsize=9];"]
        for n in self.nodes.values():
            if n.id not in live:
                continue
            gen = self.implants[n.owner].generation if n.owner else 0
            lab = f"{n.id}\\n{n.op}" + (f"\\n{n.attrs.get('fn')}" if n.op == "act" else "") + \
                  (f"\\nd={n.attrs.get('dim')}" if "dim" in n.attrs else "") + (f"\\n[{n.owner}]" if n.owner else "")
            shared = sum(1 for m in self.nodes.values() if m.pkey == n.pkey and n.pkey) > 1
            lines.append(f'  {n.id} [label="{lab}", fillcolor="{colors[gen % len(colors)]}"'
                         + (', peripheries=2' if shared else '') + "];")
            for s, i in enumerate(n.inputs):
                lines.append(f"  {i} -> {n.id} [label=\"{s}\", fontsize=7];")
        lines.append("}")
        return "\n".join(lines)
