"""Node operations for GraphNet.

Every node has an `op` name, ordered `inputs`, `attrs` and optionally a
parameter key `pkey` naming a module in GraphNet.mods (shared pkeys = shared
parameters).  Feature dimension is dim 1 for layout 'vec' (B,d) and 'img'
(B,C,H,W) and the last dim for 'seq' (B,T,d).

All parameter initialisation goes through `init_module(module, gen, scheme)`
with an explicit torch.Generator; nothing here touches the global RNG in a way
that experiments depend on.
"""
from __future__ import annotations

import math
from typing import Any, Callable

import torch
import torch.nn as nn
import torch.nn.functional as F


# ----------------------------------------------------------------------------
# Feature-dimension helpers
# ----------------------------------------------------------------------------

def fdim(layout: str) -> int:
    return {"vec": 1, "img": 1, "seq": -1}[layout]


def feat_linear(x: torch.Tensor, W: torch.Tensor, b: torch.Tensor | None, layout: str) -> torch.Tensor:
    if layout == "img":
        return F.conv2d(x, W[:, :, None, None], b)
    return F.linear(x, W, b)


def positions(layout: str, attrs: dict) -> int:
    """Number of positions a per-position op is applied at (per example)."""
    if layout == "img":
        h, w = attrs.get("hw", (1, 1))
        return int(h) * int(w)
    if layout == "seq":
        return int(attrs.get("T", 1) or 1)
    return 1


# ----------------------------------------------------------------------------
# Modules with non-trivial semantics
# ----------------------------------------------------------------------------

class TokenEmbed(nn.Module):
    def __init__(self, vocab: int, d: int, max_len: int = 512, pos: str = "sin"):
        super().__init__()
        self.tok = nn.Embedding(vocab, d)
        self.pos_kind = pos
        if pos == "learned":
            self.pos = nn.Embedding(max_len, d)
        else:
            pe = torch.zeros(max_len, d)
            p = torch.arange(max_len, dtype=torch.float64)[:, None]
            div = torch.exp(torch.arange(0, d, 2, dtype=torch.float64) * (-math.log(10000.0) / d))
            pe[:, 0::2] = torch.sin(p * div).float()
            pe[:, 1::2] = torch.cos(p * div[: d // 2]).float()
            self.register_buffer("pe", pe, persistent=False)

    def forward(self, idx: torch.Tensor) -> torch.Tensor:
        T = idx.shape[1]
        h = self.tok(idx)
        if self.pos_kind == "learned":
            return h + self.pos.weight[:T][None]
        return h + self.pe[:T][None].to(h.dtype)


class SelfAttention(nn.Module):
    def __init__(self, d: int, heads: int, causal: bool = True):
        super().__init__()
        if d % heads:
            raise ValueError(f"d={d} not divisible by heads={heads}")
        self.d, self.h, self.causal = d, heads, causal
        self.qkv = nn.Linear(d, 3 * d)
        self.out = nn.Linear(d, d)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T, d = x.shape
        q, k, v = self.qkv(x).view(B, T, 3, self.h, d // self.h).permute(2, 0, 3, 1, 4)
        y = F.scaled_dot_product_attention(q, k, v, is_causal=self.causal)
        return self.out(y.transpose(1, 2).reshape(B, T, d))


class Quantizer(nn.Module):
    """Peg quantiser.

    modes:
      'none'     identity on the code (continuous peg; communication counted at
                 the declared float precision, never as 1 bit per real number)
      'uniform'  per-coordinate uniform quantisation to `bits` bits on a clipping
                 range [lo, hi] calibrated on training/calibration data only
                 (buffers lo/hi, set by `calibrate`). Straight-through gradient.
      'vq'       single codebook of `codebook_size` vectors of dim k (nearest
                 neighbour, straight-through, commitment loss exposed in ctx)
      'multi'    `n_messages` independent codebooks, each over k/n_messages dims
    """

    def __init__(self, k: int, mode: str = "none", bits: int = 8, codebook_size: int = 16, n_messages: int = 1):
        super().__init__()
        self.k, self.mode, self.bits = k, mode, bits
        self.codebook_size, self.n_messages = codebook_size, n_messages
        self.register_buffer("lo", torch.full((k,), -1.0))
        self.register_buffer("hi", torch.full((k,), 1.0))
        self.register_buffer("calibrated", torch.zeros((), dtype=torch.bool))
        if mode == "vq":
            self.codebook = nn.Parameter(torch.zeros(codebook_size, k))
        elif mode == "multi":
            if k % n_messages:
                raise ValueError("k must be divisible by n_messages")
            self.codebook = nn.Parameter(torch.zeros(n_messages, codebook_size, k // n_messages))
        if mode not in ("none", "uniform", "vq", "multi"):
            raise ValueError(f"unknown quantiser mode {mode}")

    @torch.no_grad()
    def calibrate(self, z: torch.Tensor, q_lo: float = 0.001, q_hi: float = 0.999,
                  gen: torch.Generator | None = None) -> None:
        """Fit clipping range (and codebook initialisation) on calibration
        activations.  Callers must pass TRAINING/calibration data only."""
        zf = z.detach().reshape(-1, self.k).float()
        self.lo.copy_(torch.quantile(zf, q_lo, dim=0) if zf.shape[0] < 16_000_000 else zf.min(0).values)
        self.hi.copy_(torch.quantile(zf, q_hi, dim=0) if zf.shape[0] < 16_000_000 else zf.max(0).values)
        same = self.hi <= self.lo
        self.hi[same] = self.lo[same] + 1e-3
        if self.mode in ("vq", "multi"):
            n = zf.shape[0]
            g = gen if gen is not None else torch.Generator(device="cpu").manual_seed(0)
            idx = torch.randint(0, n, (self.codebook.shape[-2] * (self.n_messages if self.mode == "multi" else 1),),
                                generator=g)
            if self.mode == "vq":
                self.codebook.copy_(zf[idx.to(zf.device)])
            else:
                parts = zf.view(n, self.n_messages, -1)
                for m in range(self.n_messages):
                    self.codebook[m].copy_(parts[idx[m * self.codebook_size:(m + 1) * self.codebook_size].to(zf.device), m])
        self.calibrated.fill_(True)

    def codes(self, z: torch.Tensor) -> torch.Tensor:
        """Integer message symbols (for occupancy / entropy accounting)."""
        if self.mode == "uniform":
            L = 2 ** self.bits - 1
            u = ((z - self.lo) / (self.hi - self.lo)).clamp(0, 1)
            return torch.round(u * L).long()
        if self.mode == "vq":
            zz = z.reshape(-1, self.k)
            return torch.cdist(zz, self.codebook).argmin(-1)
        if self.mode == "multi":
            zz = z.reshape(-1, self.n_messages, self.k // self.n_messages)
            return torch.stack([torch.cdist(zz[:, m], self.codebook[m]).argmin(-1)
                                for m in range(self.n_messages)], -1)
        raise ValueError("continuous peg has no finite codes")

    @property
    def finite(self) -> bool:
        return self.mode != "none"

    def n_symbols(self) -> int | None:
        """Size of the message alphabet per example-position (None = continuous)."""
        if self.mode == "uniform":
            return (2 ** self.bits) ** self.k
        if self.mode == "vq":
            return self.codebook_size
        if self.mode == "multi":
            return self.codebook_size ** self.n_messages
        return None

    @torch.no_grad()
    def offalphabet_distance(self, z: torch.Tensor) -> float:
        """Distance of z from the message alphabet, scale-free: 0 (up to float
        rounding) iff every row of z already is a representable message.
        uniform: max over coordinates of |z - Q(z)| in units of the
        quantisation step (hi - lo) / (2^bits - 1); vq / multi: max ||z - Q(z)||
        relative to the mean codebook-row norm.  Layout: the code dimension is
        dim 1 for images (B, k, H, W) and the last dim otherwise."""
        if self.mode == "none" or not z.numel():
            return 0.0
        was = self.training
        self.eval()
        zz = z            # code dimension last (callers move image channels last)
        diff = zz - self.forward(zz)
        self.train(was)
        if self.mode == "uniform":
            step = ((self.hi - self.lo) / (2 ** self.bits - 1)).clamp_min(1e-12)
            return float((diff.abs() / step).max())
        scale = float(self.codebook.detach().reshape(-1, self.codebook.shape[-1]).norm(dim=-1).mean().clamp_min(1e-12))
        if self.mode == "vq":
            return float(diff.reshape(-1, self.k).norm(dim=-1).max()) / scale
        m = self.n_messages
        return float(diff.reshape(-1, m, self.k // m).norm(dim=-1).max()) / scale

    def forward(self, z: torch.Tensor, ctx: dict | None = None, name: str = "") -> torch.Tensor:
        if self.mode == "none":
            return z
        if self.training and getattr(self, "passthrough", False):
            # v15 capacity-relaxation warm-up (train.quant_warmup_updates): continuous during TRAINING updates
            # only; evaluation always quantises
            return z
        if self.mode == "uniform":
            L = 2 ** self.bits - 1
            u = ((z - self.lo) / (self.hi - self.lo)).clamp(0, 1)
            zq = torch.round(u * L) / L * (self.hi - self.lo) + self.lo
            lo_, hi_ = torch.minimum(self.lo, self.hi), torch.maximum(self.lo, self.hi)
            m = float(getattr(self, "ste_margin", 0.0) or 0.0)
            if self.training and m > 0.0:
                # v17 (train.quant_ste_margin): the straight-through gradient also passes for inputs up to
                # m x (hi - lo) outside the range; the forward value (zq) is unchanged
                w = (hi_ - lo_) * m
                lo_, hi_ = lo_ - w, hi_ + w
            zc = z.clamp(lo_, hi_)
            return zc + (zq - zc).detach()
        shape = z.shape
        if self.mode == "vq":
            zz = z.reshape(-1, self.k)
            idx = torch.cdist(zz.detach(), self.codebook.detach()).argmin(-1)
            q = self.codebook[idx]
        else:
            m = self.n_messages
            zz = z.reshape(-1, m, self.k // m)
            qs = []
            for j in range(m):
                idx = torch.cdist(zz[:, j].detach(), self.codebook[j].detach()).argmin(-1)
                qs.append(self.codebook[j][idx])
            q = torch.stack(qs, 1)
        if ctx is not None and self.training:
            commit = F.mse_loss(zz, q.detach()) * 0.25 + F.mse_loss(q, zz.detach())
            ctx.setdefault("aux_losses", []).append(("vq_" + name, commit))
        out = zz + (q - zz).detach()
        return out.reshape(shape)


# ----------------------------------------------------------------------------
# Generic sub-modules (known computations, pearl alternatives)
# ----------------------------------------------------------------------------

ACTS: dict[str, Callable[[torch.Tensor], torch.Tensor]] = {
    "relu": F.relu,
    "gelu": F.gelu,
    "tanh": torch.tanh,
    "silu": F.silu,
    "identity": lambda x: x,
    "sigmoid": torch.sigmoid,
}


class MLPModule(nn.Module):
    def __init__(self, d_in: int, hidden: list[int], d_out: int, act: str = "relu", layout: str = "vec"):
        super().__init__()
        dims = [d_in] + list(hidden) + [d_out]
        self.layers = nn.ModuleList(nn.Linear(a, b) for a, b in zip(dims[:-1], dims[1:]))
        self.act, self.layout = act, layout

    def forward(self, x):
        for i, l in enumerate(self.layers):
            x = feat_linear(x, l.weight, l.bias, self.layout)
            if i < len(self.layers) - 1:
                x = ACTS[self.act](x)
        return x

    def macs_per_position(self) -> int:
        return sum(l.in_features * l.out_features for l in self.layers)


class PolyModule(nn.Module):
    """Known polynomial computation: products of selected input coordinates.
    `terms` is a list of index tuples; output coordinate j = prod_i x[terms[j][i]]."""

    def __init__(self, terms: list[list[int]]):
        super().__init__()
        self.terms = [list(t) for t in terms]
        maxlen = max(len(t) for t in self.terms)
        idx = torch.full((len(self.terms), maxlen), -1, dtype=torch.long)
        for j, t in enumerate(self.terms):
            idx[j, :len(t)] = torch.tensor(t)
        self.register_buffer("idx", idx)

    def forward(self, x):
        out = torch.ones(x.shape[0], len(self.terms), device=x.device, dtype=x.dtype)
        for c in range(self.idx.shape[1]):
            col = self.idx[:, c]
            valid = col >= 0
            g = x[:, col.clamp(min=0)]
            out = out * torch.where(valid[None], g, torch.ones_like(g))
        return out

    def macs_per_position(self) -> int:
        return sum(len(t) for t in self.terms)


class TableModule(nn.Module):
    """Lookup table indexed by the canonical integer SYMBOLS of the incoming
    peg quantiser (one row per message).

    mode 'uniform'  per-coordinate symbol s_j = round(clamp((x_j - lo_j)/(hi_j - lo_j), 0, 1) * (L-1)),
                    L = levels = 2**bits, with lo/hi COPIED from the incoming quantiser
                    (the same map Quantizer.codes uses); row = sum_j s_j L^j
    mode 'vq'       symbol = nearest row of the incoming codebook (copied buffer)
    mode 'multi'    one nearest-codebook symbol per message; row = sum_m s_m C^m
    Build it with `TableModule.from_quantizer(q, d_out)`; the copied ranges /
    codebooks are buffers, so they are saved and restored with the module."""

    def __init__(self, k: int, levels: int, d_out: int, mode: str = "uniform", n_messages: int = 1):
        super().__init__()
        if mode not in ("uniform", "vq", "multi"):
            raise ValueError(f"table mode {mode}")
        self.k, self.levels, self.d_out, self.mode, self.n_messages = k, levels, d_out, mode, n_messages
        n_sym = levels ** k if mode == "uniform" else (levels if mode == "vq" else levels ** n_messages)
        if n_sym > 2 ** 20:
            raise ValueError(f"table with {n_sym} rows is too large")
        self.n_rows = n_sym
        self.table = nn.Parameter(torch.zeros(n_sym, d_out))
        self.register_buffer("lo", torch.full((k,), -1.0))
        self.register_buffer("hi", torch.full((k,), 1.0))
        # the symbol map must come from the incoming quantiser (from_quantizer, or a loaded state):
        # an unconfigured table refuses to index rather than silently assuming a [-1, 1] range
        self.register_buffer("configured", torch.zeros((), dtype=torch.bool))
        if mode == "uniform":
            self.register_buffer("radix", torch.tensor([levels ** i for i in range(k)], dtype=torch.long))
        elif mode == "vq":
            self.register_buffer("codebook", torch.zeros(levels, k))
        else:
            if k % n_messages:
                raise ValueError("k must be divisible by n_messages")
            self.register_buffer("codebook", torch.zeros(n_messages, levels, k // n_messages))
            self.register_buffer("radix", torch.tensor([levels ** i for i in range(n_messages)], dtype=torch.long))

    @classmethod
    def from_quantizer(cls, q: "Quantizer", d_out: int) -> "TableModule":
        if q.mode == "uniform":
            t = cls(q.k, 2 ** q.bits, d_out, "uniform")
            t.lo.copy_(q.lo.detach().to(t.lo))
            t.hi.copy_(q.hi.detach().to(t.hi))
        elif q.mode == "vq":
            t = cls(q.k, q.codebook_size, d_out, "vq")
            t.codebook.copy_(q.codebook.detach().to(t.codebook))
        elif q.mode == "multi":
            t = cls(q.k, q.codebook_size, d_out, "multi", q.n_messages)
            t.codebook.copy_(q.codebook.detach().to(t.codebook))
        else:
            raise ValueError("a table pearl needs a finite (quantised) input code")
        t.configured.fill_(True)
        return t

    def symbols(self, x):
        if self.mode == "uniform":
            u = ((x - self.lo) / (self.hi - self.lo)).clamp(0, 1)
            return torch.round(u * (self.levels - 1)).long()
        if self.mode == "vq":
            return torch.cdist(x.reshape(-1, self.k), self.codebook.to(x.dtype)).argmin(-1).reshape(x.shape[:-1])
        zz = x.reshape(-1, self.n_messages, self.k // self.n_messages)
        s = torch.stack([torch.cdist(zz[:, m], self.codebook[m].to(x.dtype)).argmin(-1)
                         for m in range(self.n_messages)], -1)
        return s.reshape(*x.shape[:-1], self.n_messages)

    def index(self, x):
        if not bool(self.configured):
            raise RuntimeError("TableModule has no symbol map: build it with TableModule.from_quantizer(q, d_out)")
        s = self.symbols(x)
        if self.mode == "vq":
            return s
        return (s * self.radix).sum(-1)

    def forward(self, x):
        return self.table[self.index(x)]

    def macs_per_position(self) -> int:
        return self.d_out


MODULE_TYPES: dict[str, Callable[..., nn.Module]] = {
    "mlp": MLPModule,
    "poly": PolyModule,
    "table": TableModule,
}


# ----------------------------------------------------------------------------
# Module construction from node attrs
# ----------------------------------------------------------------------------

def build_module(op: str, attrs: dict) -> nn.Module | None:
    a = attrs
    if op == "linear":
        return nn.Linear(a["in"], a["out"], bias=a.get("bias", True))
    if op == "conv":
        return nn.Conv2d(a["in"], a["out"], a["k"], stride=a.get("stride", 1), padding=a.get("padding", a["k"] // 2),
                         bias=a.get("bias", True))
    if op == "bn":
        return nn.BatchNorm2d(a["dim"]) if a["layout"] == "img" else nn.BatchNorm1d(a["dim"])
    if op == "ln":
        return nn.LayerNorm(a["dim"])
    if op == "embed":
        return TokenEmbed(a["vocab"], a["dim"], a.get("max_len", 512), a.get("pos", "sin"))
    if op == "attn":
        return SelfAttention(a["dim"], a["heads"], a.get("causal", True))
    if op == "gru":
        return nn.GRU(a["in"], a["dim"], batch_first=True)
    if op == "concat_proj":
        return nn.Linear(sum(a["term_dims"]), a["dim"], bias=a.get("bias", False))
    if op == "route":
        return nn.Linear(a["router_in"], len(a["terms"]))
    if op == "quant":
        return Quantizer(a["dim"], a.get("mode", "none"), a.get("bits", 8), a.get("codebook_size", 16),
                         a.get("n_messages", 1))
    if op == "module":
        if a["module_type"] not in MODULE_TYPES:
            from ..cop_pegs import modules as _register  # noqa: F401  (registers CoP module types)
        return MODULE_TYPES[a["module_type"]](**a["module_args"])
    if op == "head_seq":
        return nn.Linear(a["in"], a["out"])
    return None


@torch.no_grad()
def init_module(m: nn.Module, gen: torch.Generator, scheme: str = "default") -> None:
    """Re-initialise every parameter of m from `gen` (CPU generator)."""

    def u(t, bound):
        t.copy_((torch.rand(t.shape, generator=gen, dtype=torch.float64) * 2 - 1).mul(bound).to(t.dtype))

    def n(t, std):
        t.copy_((torch.randn(t.shape, generator=gen, dtype=torch.float64) * std).to(t.dtype))

    for mod in m.modules():
        if isinstance(mod, (nn.Linear, nn.Conv2d)):
            W = mod.weight
            fan_in = W.shape[1] * (W[0, 0].numel() if W.dim() > 2 else 1)
            fan_out = W.shape[0] * (W[0, 0].numel() if W.dim() > 2 else 1)
            if scheme == "zero":
                W.zero_()
            elif scheme == "kaiming":
                n(W, math.sqrt(2.0 / fan_in))
            elif scheme == "xavier":
                n(W, math.sqrt(2.0 / (fan_in + fan_out)))
            elif scheme == "lecun":
                n(W, math.sqrt(1.0 / fan_in))
            else:  # torch default: kaiming_uniform(a=sqrt(5)) == U(-1/sqrt(fan_in), 1/sqrt(fan_in))
                u(W, 1.0 / math.sqrt(fan_in))
            if mod.bias is not None:
                if scheme in ("zero", "kaiming", "xavier", "lecun"):
                    mod.bias.zero_()
                else:
                    u(mod.bias, 1.0 / math.sqrt(fan_in))
        elif isinstance(mod, nn.Embedding):
            n(mod.weight, 1.0 if scheme != "zero" else 0.0)
        elif isinstance(mod, nn.GRU):
            bound = 1.0 / math.sqrt(mod.hidden_size)
            for p in mod.parameters():
                u(p, bound if scheme != "zero" else 0.0)
        elif isinstance(mod, (nn.LayerNorm, nn.BatchNorm1d, nn.BatchNorm2d)):
            if mod.weight is not None:
                mod.weight.fill_(1.0)
                mod.bias.zero_()
            if isinstance(mod, (nn.BatchNorm1d, nn.BatchNorm2d)):
                mod.reset_running_stats()
        elif isinstance(mod, Quantizer):
            if hasattr(mod, "codebook"):
                n(mod.codebook, 1.0)
        elif isinstance(mod, TableModule):
            mod.table.zero_()


# ----------------------------------------------------------------------------
# Forward functions:  fn(node, xs, module, graph, ctx) -> Tensor
# ----------------------------------------------------------------------------

def _f_input(node, xs, mod, g, ctx):
    return ctx["X"][node.attrs["stream"]]


def _f_identity(node, xs, mod, g, ctx):
    return xs[0]


def _param_route_mask(node, g, ctx):
    """v26: under ctx["mask_param_only"], the 0 / 1 mask of the specialised branch that owns this node (None for
    every other node)."""
    if not ctx or not ctx.get("mask_param_only") or node.owner is None:
        return None
    imp = g.implants.get(node.owner)
    key = (((imp.meta or {}).get("specialization") or {}).get("mask_key")) if imp is not None else None
    return ctx.get("grad_masks", {}).get(key) if key else None


def _f_linear(node, xs, mod, g, ctx):
    m = _param_route_mask(node, g, ctx)
    if m is None:
        return feat_linear(xs[0], mod.weight, mod.bias, node.attrs["layout"])
    # v26 parameter route: same forward value; the layer's PARAMETERS get gradient only from the examples whose
    # mask is 1, while the gradient with respect to the layer's input flows for every example (so the branch
    # still passes every example's gradient into the upstream backbone)
    b = mod.bias
    y1 = feat_linear(xs[0], mod.weight, b, node.attrs["layout"])
    y0 = feat_linear(xs[0], mod.weight.detach(), None if b is None else b.detach(), node.attrs["layout"])
    mm = m.view([-1] + [1] * (y1.dim() - 1)).to(y1.dtype)
    return mm * y1 + (1 - mm) * y0


def _f_linear_inverse(node, xs, mod, g, ctx):
    # enforced inverse of a square linear node sharing pkey: y = W^{-1}(x - b)
    W, b = mod.weight, mod.bias
    x = xs[0]
    if b is not None:
        x = x - (b.view(1, -1, 1, 1) if node.attrs["layout"] == "img" else b)
    Winv = torch.linalg.inv(W.double()).to(W.dtype) if W.dtype != torch.float64 else torch.linalg.inv(W)
    return feat_linear(x, Winv, None, node.attrs["layout"])


def _f_conv(node, xs, mod, g, ctx):
    return mod(xs[0])


def _f_bn(node, xs, mod, g, ctx):
    return mod(xs[0])


def _f_ln(node, xs, mod, g, ctx):
    return mod(xs[0])


def _f_act(node, xs, mod, g, ctx):
    fn = node.attrs["fn"]
    if fn == "mix":
        # controlled departure from linearity (strengthening F01d): (1 - s) x + s act(x); s = 0 is linear
        s_ = float(node.attrs["s"])
        x = xs[0]
        return x if s_ == 0.0 else (1.0 - s_) * x + s_ * ACTS[node.attrs["base"]](x)
    return ACTS[fn](xs[0])


def _gate(g, gid):
    return 1.0 if gid is None else g.gate_vals[gid]


def _f_add(node, xs, mod, g, ctx):
    coefs = node.attrs["coefs"]
    gates = node.attrs.get("gates") or [None] * len(xs)
    out = None
    for x, c, gid in zip(xs, coefs, gates):
        w = c * _gate(g, gid)
        if w == 0.0:
            continue
        t = x if w == 1.0 else x * w
        out = t if out is None else out + t
    if out is None:
        out = torch.zeros_like(xs[0])
    return out


def _f_gate_mix(node, xs, mod, g, ctx):
    # base + gate * (val - base);  gate=1 -> val, gate=0 -> base
    gv = _gate(g, node.attrs["gate"])
    if gv == 1.0:
        return xs[1]
    if gv == 0.0:
        return xs[0]
    return xs[0] + gv * (xs[1] - xs[0])


def _f_concat(node, xs, mod, g, ctx):
    return torch.cat(xs, dim=fdim(node.attrs["layout"]))


def _f_concat_proj(node, xs, mod, g, ctx):
    # node.inputs holds only the ACTIVE terms; deleted terms keep their columns
    # in the (possibly shared) weight but are excluded here.
    a = node.attrs
    active = a["active"]
    W = mod.weight
    if not all(active):
        cols, start = [], 0
        for d, on in zip(a["term_dims"], active):
            if on:
                cols.extend(range(start, start + d))
            start += d
        W = W[:, g.index_buffer(cols, W.device)]
    gates = a.get("gates") or [None] * len(xs)
    Wa = W
    xs2 = [x if gid is None else x * _gate(g, gid) for x, gid in zip(xs, gates)]
    x = torch.cat(xs2, dim=fdim(a["layout"]))
    return feat_linear(x, Wa, mod.bias, a["layout"])


def _f_route(node, xs, mod, g, ctx):
    # xs[0] = router input; xs[1:] = expert outputs (active terms only)
    a = node.attrs
    rows = [i for i, on in enumerate(a["active"]) if on]
    W, b = mod.weight[rows], mod.bias[rows]
    logits = feat_linear(xs[0], W, b, a["layout"])
    p = torch.softmax(logits, dim=fdim(a["layout"]))
    if ctx is not None and ctx.get("collect_routes"):
        ctx.setdefault("routes", {})[node.id] = p.detach()
    out = None
    for j, x in enumerate(xs[1:]):
        pj = p.select(fdim(a["layout"]), j).unsqueeze(fdim(a["layout"]))
        t = pj * x
        out = t if out is None else out + t
    return out


def _f_select(node, xs, mod, g, ctx):
    idx = g.index_buffer(node.attrs["idx"], xs[0].device)
    return xs[0].index_select(fdim(node.attrs["layout"]) % xs[0].dim(), idx)


def _f_scatter(node, xs, mod, g, ctx):
    base, val = xs
    d = fdim(node.attrs["layout"]) % base.dim()
    idx = g.index_buffer(node.attrs["idx"], base.device)
    return base.index_copy(d, idx, val)


def position_mask(spec: dict, x: torch.Tensor, layout: str) -> torch.Tensor:
    if layout == "seq":
        T = x.shape[1]
        m = torch.zeros(T, device=x.device, dtype=x.dtype)
        if "last" in spec:
            m[-int(spec["last"]):] = 1
        elif "from" in spec:
            m[int(spec["from"]):] = 1
        elif "tokens" in spec:
            idx = [t for t in spec["tokens"] if t < T]
            m[idx] = 1
        return m.view(1, T, 1)
    if layout == "img":
        H, W = x.shape[2], x.shape[3]
        h0, h1, w0, w1 = spec["region"]
        m = torch.zeros(H, W, device=x.device, dtype=x.dtype)
        m[h0:h1, w0:w1] = 1
        return m.view(1, 1, H, W)
    raise ValueError("position subsets need layout seq or img")


def _f_pos_mix(node, xs, mod, g, ctx):
    base, val = xs
    m = position_mask(node.attrs["positions"], base, node.attrs["layout"])
    return base + m * (val - base)


def _f_flatten(node, xs, mod, g, ctx):
    return xs[0].flatten(1)


def _f_gap(node, xs, mod, g, ctx):
    return xs[0].mean(dim=(2, 3))


def _f_pool(node, xs, mod, g, ctx):
    k = node.attrs.get("k", 2)
    return F.max_pool2d(xs[0], k) if node.attrs.get("kind", "max") == "max" else F.avg_pool2d(xs[0], k)


def _f_embed(node, xs, mod, g, ctx):
    return mod(xs[0])


def _f_attn(node, xs, mod, g, ctx):
    return mod(xs[0])


def _f_gru(node, xs, mod, g, ctx):
    return mod(xs[0])[0]


def _f_quant(node, xs, mod, g, ctx):
    """Quantisers work on the code dimension LAST.  Image codes (B, k, H, W)
    are moved to channels-last and back, so per-coordinate ranges / codebooks
    apply per channel (as calibrated), never along the width axis."""
    x = xs[0]
    if ctx is not None and ctx.get("collect_codes"):
        ctx.setdefault("codes", {})[node.id] = x.detach()
    if x.dim() == 4 and node.attrs.get("layout", g.layout) == "img":
        return mod(x.movedim(1, -1), ctx, node.id).movedim(-1, 1)
    return mod(x, ctx, node.id)


def _f_module(node, xs, mod, g, ctx):
    return mod(xs[0])


def _f_mask_grad(node, xs, mod, g, ctx):
    # forward value unchanged; gradient only from examples whose mask is 1.  v25: with ctx["mask_forward"] the
    # value itself is masked (the branch's output is zero for the examples whose mask is 0), which masks the
    # gradient as well (the forward-masked comparator)
    key = node.attrs["mask_key"]
    m = None if ctx is None else ctx.get("grad_masks", {}).get(key)
    if m is None:
        return xs[0]
    shape = [-1] + [1] * (xs[0].dim() - 1)
    m = m.view(shape).to(xs[0].dtype)
    if ctx.get("mask_forward"):
        return m * xs[0]
    if ctx.get("mask_param_only"):
        return xs[0]                    # v26: the branch's linear layers mask their own parameter gradients
    return m * xs[0] + (1 - m) * xs[0].detach()


def _f_scale(node, xs, mod, g, ctx):
    return xs[0] * node.attrs["c"]


def _f_head_seq(node, xs, mod, g, ctx):
    return mod(xs[0])


def _f_onehot_embed(node, xs, mod, g, ctx):
    return xs[0]


FORWARD: dict[str, Callable] = {
    "input": _f_input,
    "identity": _f_identity,
    "linear": _f_linear,
    "linear_inverse": _f_linear_inverse,
    "conv": _f_conv,
    "bn": _f_bn,
    "ln": _f_ln,
    "act": _f_act,
    "add": _f_add,
    "gate_mix": _f_gate_mix,
    "concat": _f_concat,
    "concat_proj": _f_concat_proj,
    "route": _f_route,
    "select": _f_select,
    "scatter": _f_scatter,
    "pos_mix": _f_pos_mix,
    "flatten": _f_flatten,
    "gap": _f_gap,
    "pool": _f_pool,
    "embed": _f_embed,
    "attn": _f_attn,
    "gru": _f_gru,
    "quant": _f_quant,
    "module": _f_module,
    "mask_grad": _f_mask_grad,
    "scale": _f_scale,
    "head_seq": _f_head_seq,
}

# ops whose map from (single) input to output is affine and position-wise
POSITIONWISE_AFFINE = {"identity", "linear", "add", "scale", "select", "scatter", "concat", "concat_proj",
                       "gate_mix", "linear_inverse"}
