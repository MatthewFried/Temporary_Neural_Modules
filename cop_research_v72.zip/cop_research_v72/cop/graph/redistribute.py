"""v65: function-preserving redistributions of an expansion's computation (the mechanism forks).

A specialised expansion at the middle cut is one group implant G (a sum merge z = h + sum of branch terms) with
branch pairs per round, spec/r<k>/a (gradient mask spec_a) and spec/r<k>/b (spec_b), read by one backbone layer
(the receiving layer, W z + b).  Both edits keep the network's forward function and change how its computation is
split, so continued training under the same gradient routing can separate WHAT the additions compute (the forward
map, unchanged) from HOW they pass gradients to the backbone (the individual branch maps an example's gradient
flows through under routing):

  swap      the parameters of the a and b branch of every round are exchanged.  The sum is unchanged; under
            routing, the examples of split a now reach the backbone through the map learned on split b and the
            other way round.  The tensors are moved exactly (not recomputed); the forward sum of the branch terms
            is the same in exact arithmetic, but in floating point its value can differ by summation order.
  shift t   a share t of the additions' map moves into the receiving layer: every branch's output is scaled by
            s = 1 - t (its last linear layer's weight and bias times s) and the receiving layer becomes
            W' = W (I + M) (I + s M)^-1,  b' = b + W m - s W' m
            for the exact float64 map z = (I + M) h + m of the merge, so W' z' + b' = W z + b for every h.  t = 1
            leaves the additions in place with zero output (their first layers keep their values, their output
            layers are zero and stay trainable, so they can grow back from the first update: not a removal) and the
            whole map in the receiving layer.  Under ordinary gradients the gradient that reaches h is unchanged at the edit
            (W' (I + s M) = W (I + M)); under routing it is not.  Computed in float64, stored in the network's dtype
            (the rounding of the stored W' is amplified by the conditioning of I + s M, which is recorded).

Both refuse anything but this structure: one top-level group with a sum merge, untied branches in a / b pairs with
their masks, read by exactly one backbone linear (position-wise; a 1x1 layer in an image network)."""
from __future__ import annotations

import re

import torch

from . import edits as E
from .graph import GraphNet, GraphError

REDISTRIBUTIONS = {"keep_swap": ("swap", 0.0), "keep_shift50": ("shift", 0.5), "keep_shift100": ("shift", 1.0)}


def the_group(g: GraphNet) -> str:
    tops = [i for i, im in g.implants.items() if im.parent is None]
    if len(tops) != 1:
        raise GraphError(f"redistribution needs one top-level addition, found {len(tops)}")
    G = tops[0]
    if g.implants[G].meta.get("merge_mode") != "sum":
        raise GraphError("redistribution needs a sum merge")
    return G


def branch_pairs(g: GraphNet, G: str) -> list[tuple[str, str]]:
    """[(a branch, b branch)] per round, checked: both untied, without nested additions, with their masks."""
    kids = [k for k in g.implant_children(G)]
    by = {}
    for k in kids:
        im = g.implants[k]
        m = re.fullmatch(r".*/r(\d+)/([ab])", im.slot or "")
        if im.kind != "branch" or m is None:
            raise GraphError(f"branch {k} (slot {im.slot!r}) is not a specialised a / b branch")
        if im.meta.get("tied_to") or g.implant_children(k):
            raise GraphError(f"branch {k} is tied or has nested additions")
        key = (im.meta.get("specialization") or {}).get("mask_key")
        if key != f"spec_{m.group(2)}":
            raise GraphError(f"branch {k} (slot {im.slot}) has mask {key!r}")
        by.setdefault(int(m.group(1)), {})[m.group(2)] = k
    if not by or any(set(v) != {"a", "b"} for v in by.values()):
        raise GraphError(f"redistribution needs an a and a b branch in every round: {by}")
    return [(by[r]["a"], by[r]["b"]) for r in sorted(by)]


def _role_node(g: GraphNet, bid: str, role: str) -> str:
    ns = [n for n in g.implants[bid].nodes if g.nodes[n].role == role]
    if len(ns) != 1 or g.nodes[ns[0]].op != "linear":
        raise GraphError(f"branch {bid}: {len(ns)} linear nodes with role {role}")
    return ns[0]


def receiving_layer(g: GraphNet, G: str) -> str:
    ex = g.implants[G].exit
    cons = g.consumers(ex)
    if len(cons) != 1 or cons[0][1] != 0:
        raise GraphError(f"the merge has {len(cons)} readers; redistribution needs one")
    r = cons[0][0]
    n = g.nodes[r]
    if n.op != "linear" or n.owner is not None or not n.attrs.get("bias", True):
        raise GraphError(f"the merge is read by {n.op} (owner {n.owner}); redistribution needs a backbone linear "
                         f"layer with a bias (in an image network a 1x1 layer: a padded spatial convolution cannot "
                         f"absorb the offset exactly at the border)")
    return r


@torch.no_grad()
def swap_branches(g: GraphNet) -> dict:
    G = the_group(g)
    pairs = branch_pairs(g, G)
    moved = []
    for a, b in pairs:
        for role in ("A", "B"):
            ma, mb = g.mods[g.nodes[_role_node(g, a, role)].pkey], g.mods[g.nodes[_role_node(g, b, role)].pkey]
            sa, sb = ma.state_dict(), mb.state_dict()
            if {k: v.shape for k, v in sa.items()} != {k: v.shape for k, v in sb.items()}:
                raise GraphError(f"branches {a} and {b} differ in shape at {role}")
            tmp = {k: v.clone() for k, v in sa.items()}
            ma.load_state_dict(sb)
            mb.load_state_dict(tmp)
            moved.append(f"{a}.{role}<->{b}.{role}")
    g._plan = None
    return {"kind": "swap", "group": G, "pairs": [list(p) for p in pairs], "moved": moved}


@torch.no_grad()
def shift_to_receiver(g: GraphNet, t: float) -> dict:
    if not 0.0 < float(t) <= 1.0:
        raise GraphError("shift share t must be in (0, 1]")
    s = 1.0 - float(t)
    G = the_group(g)
    pairs = branch_pairs(g, G)
    region = g.region(G)
    masks = E.grad_mask_nodes(g, region)
    if not E.region_is_affine(g, set(region) - set(masks)):
        raise GraphError("redistribution shift needs affine additions")
    Mfull, m = E.affine_map(g, g.implants[G].entry, g.implants[G].exit, region)   # float64; masks are identities
    Mfull, m = Mfull.double().cpu(), m.double().cpu()
    d = Mfull.shape[0]
    eye = torch.eye(d, dtype=torch.float64)
    M = Mfull - eye
    r = receiving_layer(g, G)
    lin = g.mods[g.nodes[r].pkey]
    W, b = lin.weight.double().cpu(), lin.bias.double().cpu()
    K = eye + s * M
    WM = W @ Mfull
    Wn = torch.linalg.solve(K.T, WM.T).T                     # W' = W (I + M) K^-1
    bn = b + W @ m - s * (Wn @ m)
    resid = float((Wn @ K - WM).abs().max()) / max(1.0, float(WM.abs().max()))
    lin.weight.copy_(Wn.to(lin.weight.device, lin.weight.dtype))
    lin.bias.copy_(bn.to(lin.bias.device, lin.bias.dtype))
    scaled = []
    for a, bb in pairs:
        for bid in (a, bb):
            mod = g.mods[g.nodes[_role_node(g, bid, "B")].pkey]
            mod.weight.mul_(s)
            if mod.bias is not None:
                mod.bias.mul_(s)
            scaled.append(bid)
    g._plan = None
    sv = torch.linalg.svdvals(K)
    sf = torch.linalg.svdvals(Mfull)
    return {"kind": "shift", "t": float(t), "s": s, "group": G, "receiver": r, "scaled_branches": scaled,
            "cond_I_plus_sM": float(sv.max() / sv.min().clamp_min(1e-300)),
            "cond_I_plus_M": float(sf.max() / sf.min().clamp_min(1e-300)),
            "solve_relative_residual": resid, "map_norm_M": float(M.norm()), "offset_norm_m": float(m.norm())}


def redistribute(g: GraphNet, method: str) -> dict:
    kind, t = REDISTRIBUTIONS[method]
    return swap_branches(g) if kind == "swap" else shift_to_receiver(g, t)
