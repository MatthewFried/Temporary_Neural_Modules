"""Measured cost of representative jobs on THIS machine, and manifest estimates.

calibrate: for each family (synthetic MLP, tabular, CNN/ResNet on CIFAR-10,
Transformer/GRU sequences) runs one baseline and one 3-round trajectory, and
for the CoP families (vector, image, sequence) one chain, one P3 alternatives
job and one P5 cycles job, at the requested scale, recording wall time,
optimizer updates, peak GPU memory and run-directory size.  Timing excludes
dataset download (fetch data first) but includes data loading.  A job that is
already complete is NOT re-timed by wall clock (that would measure a cache
hit): its stored measured elapsed time is used and the record says so
(`timing_source`); pass a fresh --results directory to re-measure.  The output
is per-update cost per family, which `estimate` multiplies by every manifest
entry's update count.  Estimates are approximate: different topologies have
different compute; CoP local fits and code caches are included in the CoP
families' measured time.
"""
from __future__ import annotations

import json
import os
import shutil
import time
from pathlib import Path
from typing import Optional

from ..config import resolve, run_id
from ..utils import read_json, read_jsonl, atomic_write_json
from .runner import run_job, status_of
from .manifest import Builder, teacher_data, MLP

FAMILIES = {
    "synthetic_mlp": (teacher_data(3, 8192), MLP(128)),
    "tabular_covertype": ({"name": "covertype", "n_train": 50000}, MLP(128)),
    "cifar10_resnet": ({"name": "cifar10", "n_train": 5000}, {"family": "resnet", "width_mult": 1.0}),
    "cifar10_cnn": ({"name": "cifar10", "n_train": 5000}, {"family": "cnn", "width_mult": 1.0}),
    "fmnist_cnn": ({"name": "fashion_mnist", "n_train": 5000}, {"family": "cnn", "width_mult": 1.0}),
    "seq_transformer": ({"name": "seq_select", "n_train": 8192, "n_val": 1024, "n_test": 4096},
                        {"family": "transformer", "depth": 4, "width": 64}),
    "seq_gru": ({"name": "seq_compose", "n_train": 8192, "n_val": 1024, "n_test": 4096},
                {"family": "gru", "depth": 2, "width": 64}),
}

COP_FAMILIES = {
    "cop_vec": ({"name": "compose", "n_train": 8192}, MLP(64, depth=6)),
    "cop_img": ({"name": "cifar10", "n_train": 5000}, {"family": "resnet", "width_mult": 1.0, "blocks_per_stage": 2}),
    "cop_seq": ({"name": "seq_select", "n_train": 8192, "n_val": 1024, "n_test": 4096},
                {"family": "transformer", "depth": 6, "width": 64}),
}


def _dir_size(p: Path) -> int:
    return sum(f.stat().st_size for f in p.rglob("*") if f.is_file())


def family_of(cfg: dict) -> str:
    name = cfg.get("data", {}).get("name", "")
    fam = cfg.get("model", {}).get("family", "mlp")
    if cfg.get("kind") == "cop":
        return "cop_img" if fam in ("cnn", "resnet") else ("cop_seq" if fam in ("transformer", "gru") else "cop_vec")
    if name in ("cifar10", "cifar100"):
        return "cifar10_resnet" if fam == "resnet" else "cifar10_cnn"
    if name == "fashion_mnist":
        return "fmnist_cnn"
    if name in ("covertype", "california", "digits"):
        return "tabular_covertype"
    if name.startswith("seq_"):
        return "seq_transformer" if fam == "transformer" else "seq_gru"
    return "synthetic_mlp"


def _time_job(e: dict, root: Path, exec_cfg: dict) -> dict:
    rid = e["run_id"]
    d = root / "runs" / rid
    pre = status_of(root, rid)["status"]
    t0 = time.time()
    st = run_job(e["cfg"], root, exec_cfg, resume=True)
    el = time.time() - t0
    summ = read_json(d / "summary.json") if (d / "summary.json").exists() else {}
    if pre == "complete":
        el, src = summ.get("elapsed_seconds"), "stored measured time (job was already complete)"
    else:
        src = "wall clock of this calibration run"
    c = e["cfg"]
    upd = updates_of(c)
    work = (summ.get("work") or {})
    meas = sum(w.get("updates", 0) for w in work.values()) if work else None
    return {"kind": c["kind"], "task": (c.get("cop") or {}).get("task_kind") or c.get("growth", {}).get("topology"),
            "status": st, "seconds": el, "timing_source": src, "updates_nominal": upd,
            "updates_measured": meas, "sec_per_update": (el / max(1, meas or upd)) if el is not None else None,
            "peak_memory_bytes": summ.get("peak_memory_bytes"), "disk_bytes": _dir_size(d) if d.exists() else 0}


def calibrate(results: str, exec_cfg: dict, scale: str = "pilot", families: Optional[list[str]] = None) -> dict:
    B = Builder(scale)
    out = {"scale": scale, "device": exec_cfg.get("device"), "families": {}}
    root = Path(results)
    for fam, (data, model) in {**FAMILIES, **COP_FAMILIES}.items():
        if families and fam not in families:
            continue
        rec = {}
        try:
            B.entries.clear()
            if fam in COP_FAMILIES:
                B.cop(data, model, {"task_kind": "chain", "n_pearls": 3}, {"dim": 8}, 0, 5, "calibration", ["P1"])
                B.cop(data, model, {"task_kind": "alternatives", "n_pearls": 4,
                                    "alt_kinds": ["conv_small", "linear"] if model["family"] in ("cnn", "resnet")
                                    else ["mlp_small", "linear"]}, {"dim": 8}, 0, 5, "calibration", ["P3"],
                      parents_chain=True)
                B.cop(data, model, {"task_kind": "cycles", "n_pearls": 3, "cycles": 2}, {"dim": 8}, 0, 5,
                      "calibration", ["P5"])
            else:
                ck = "post_act" if model["family"] in ("mlp", "cnn") else {"resnet": "block_out", "transformer": "resid",
                                                                           "gru": "gru_out"}[model["family"]]
                B.traj(data, model, {"topology": "recursive_branch", "cut_kind": ck}, 0, 0, "calibration", ["E1"])
            for e in B.entries_list():
                if e["run_id"] not in rec:
                    rec[e["run_id"]] = _time_job(e, root, exec_cfg)
            spu = lambda kinds: [r["sec_per_update"] for r in rec.values() if r["kind"] in kinds and
                                 r["sec_per_update"] is not None]
            out["families"][fam] = {
                "jobs": rec,
                "sec_per_update_baseline": next(iter(spu(("baseline",))), None),
                "sec_per_update_trajectory_max": max(spu(("trajectory", "cop")), default=None),
                "disk_bytes_per_trajectory_max": max((r["disk_bytes"] for r in rec.values()
                                                      if r["kind"] in ("trajectory", "cop")), default=None),
                "peak_memory_bytes_max": max((r["peak_memory_bytes"] or 0 for r in rec.values()), default=None)}
        except Exception as ex:
            out["families"][fam] = {"error": repr(ex)}
    atomic_write_json(root / "calibration_timing.json", out)
    return out


def updates_of(cfg: dict) -> int:
    k = cfg["kind"]
    if k == "baseline":
        return cfg["train"]["baseline_updates"]
    if k == "trajectory":
        g = cfg["growth"]
        u = g["rounds"] * g["updates_per_round"] if g["compute_schedule"] == "per_round" else g["total_updates"]
        if g["schedule"] == "from_scratch":
            u += cfg["train"]["baseline_updates"]
        if g["policy"] in ("dependence_seeking", "removability_preserving"):
            u += g["rounds"] * g["policy_candidates"] * g["policy_probe_updates"]
        return u
    if k == "repair":
        g = cfg["growth"]
        return int(cfg["repair"]["budget_multiplier"] * g["rounds"] * g["updates_per_round"] * 2)
    if k == "dissipation":
        d = cfg["dissipation"]
        return 3 * (d["speed_updates"] + d["post_updates"])
    if k == "cop":
        c = cfg["cop"]
        return c["global_updates"] * 2 + c["local_updates"] * (2 + 2 * c.get("cycles", 2))
    return 0


def estimate(manifest: str, timing: str, workers: int = 1) -> dict:
    T = read_json(timing)["families"]
    ents = read_jsonl(manifest)
    tot_s, tot_disk, missing = 0.0, 0, set()
    by_kind = {}
    for e in ents:
        c = e["cfg"]
        if c["kind"] in ("finite", "control"):
            s = 60.0 if c["kind"] == "finite" else 120.0
        else:
            fam = family_of(c)
            t = T.get(fam, {})
            spu = t.get("sec_per_update_trajectory_max") or t.get("sec_per_update_baseline")
            if spu is None:
                missing.add(fam)
                continue
            s = spu * updates_of(c)
            tot_disk += t.get("disk_bytes_per_trajectory_max") or 0
        tot_s += s
        by_kind[c["kind"]] = by_kind.get(c["kind"], 0.0) + s
    return {"jobs": len(ents), "estimated_hours_single_worker": tot_s / 3600,
            "estimated_hours_with_workers": tot_s / 3600 / max(1, workers),
            "hours_by_kind": {k: v / 3600 for k, v in by_kind.items()},
            "estimated_disk_gb": tot_disk / 1e9, "families_without_timing": sorted(missing),
            "caveat": "per-update cost measured on one representative job per family; deletion enumeration, "
                      "evaluation and topology differences are approximated; concurrent workers share the GPU"}
