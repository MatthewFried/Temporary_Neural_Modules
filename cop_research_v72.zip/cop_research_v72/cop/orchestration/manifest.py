"""Manifest generation for Waves 0-6 with a named coverage matrix.

Every entry is a fully RESOLVED config (run id = hash of the logical config and
CODE_VERSION), its prerequisite run ids, and the named blocks / work packages
it serves.  Shared prerequisites (baselines, continued baselines, reference
chains) are de-duplicated by run id across blocks and waves.

Scales: full (spec budgets from configs/budgets.yaml), pilot (budgets x0.25,
seed 0 only, for GPU timing), smoke (tiny budgets, CPU check of the pipeline).
Different scales have different run ids, so they never collide.
"""
from __future__ import annotations

import copy
import itertools
import math
from pathlib import Path
from typing import Any, Iterable, Optional

import yaml

from ..config import resolve, run_id
from ..utils import read_jsonl, read_json, stable_hash

ROOT = Path(__file__).resolve().parents[2]

SYNTHETIC = {"linear_rank", "teacher", "frequency", "compose", "flat", "easy_teacher", "shortcut"}
FINITE = {"parity", "multiplexer", "delayed_query", "later_query"}
SEQ = {"seq_copy", "seq_select", "seq_compose"}
CORE5 = ["none", "layered", "parallel", "recursive", "recursive_branch"]
WPS = ["E1", "E2", "E3", "E4", "E5", "R1", "R2", "R3", "R4", "R5", "I1", "I2", "I3", "I4", "I5",
       "P1", "P2", "P3", "P4", "P5"]


def budget_key(name: str) -> str:
    if name in SYNTHETIC:
        return "synthetic"
    if name in FINITE:
        return "finite_bits"
    if name in SEQ:
        return "sequence"
    if name == "toy_images":
        return "fashion_mnist"
    return name


class Builder:
    def __init__(self, scale: str = "full", budgets_path: Optional[Path] = None):
        self.scale = scale
        b = yaml.safe_load(open(budgets_path or ROOT / "configs" / "budgets.yaml"))
        self.mult = b.pop("scales")[scale]
        self.budgets = b
        self.entries: dict[str, dict] = {}
        self.blocks: dict[str, dict] = {}

    # ---------------------------------------------------------------- basics
    def seeds(self, full: list[int]) -> list[int]:
        return full[:1] if self.scale in ("pilot", "smoke") else full

    def train(self, data_name: str, **over) -> dict:
        b = dict(self.budgets[budget_key(data_name)])
        t = {"batch_size": b["batch_size"], "lr": b["lr"],
             "baseline_updates": max(10, int(round(b["baseline_updates"] * self.mult))),
             "eval_every": max(0, int(round(b["eval_every"] * self.mult)))}
        t.update(over)
        return t

    def upr(self, data_name: str) -> int:
        return max(5, int(round(self.budgets[budget_key(data_name)]["updates_per_round"] * self.mult)))

    def add(self, cfg: dict, block: str, deps: Iterable[str] = ()) -> str:
        c = resolve(cfg)
        rid = run_id(c)
        e = self.entries.get(rid)
        if e is None:
            self.entries[rid] = {"run_id": rid, "cfg": c, "deps": sorted(set(deps)), "blocks": [block],
                                 "wp": sorted(set(c.get("wp", []))), "wave": c.get("wave")}
        else:
            if block not in e["blocks"]:
                e["blocks"].append(block)
            e["wp"] = sorted(set(e["wp"]) | set(c.get("wp", [])))
        self.blocks.setdefault(block, {"jobs": [], "wp": set()})
        if rid not in self.blocks[block]["jobs"]:
            self.blocks[block]["jobs"].append(rid)
        self.blocks[block]["wp"] |= set(c.get("wp", []))
        return rid

    def baseline(self, data: dict, model: dict, opt_seed: int, wave: int, train_over: Optional[dict] = None,
                 block: str = "") -> str:
        cfg = {"kind": "baseline", "data": data, "model": model, "train": self.train(data["name"], **(train_over or {})),
               "seeds": {"optimizer": opt_seed}, "wave": wave, "block": block or "baselines"}
        return self.add(cfg, block or "baselines")

    def traj(self, data: dict, model: dict, growth: dict, opt_seed: int, wave: int, block: str, wp: list[str],
             controlled: str = "", train_over: Optional[dict] = None, seeds_over: Optional[dict] = None,
             with_fc: bool = True, deletion: Optional[dict] = None, extra: Optional[dict] = None,
             base_train_over: Optional[dict] = None, parents_extra: Optional[dict] = None) -> str:
        """extra: further top-level config sections (e.g. design, tags) of the trajectory job;
        base_train_over: train overrides of its baseline f0 (default: the optimizer-type keys of train_over)."""
        tr = self.train(data["name"], **(train_over or {}))
        bto = base_train_over if base_train_over is not None else \
            {k: v for k, v in (train_over or {}).items() if k in ("optimizer", "momentum", "weight_decay", "lr",
                                                                  "batch_size", "precision", "stream")}
        base = self.baseline(data, model, opt_seed, wave, bto)
        g = {"rounds": 3, "updates_per_round": self.upr(data["name"])}
        g.update(growth)
        seeds = {"optimizer": opt_seed, **(seeds_over or {})}
        parents = {"baseline": base}
        deps = [base]
        # the continued baseline fc: ONE canonical config per cell (only budget/driver keys), so that the
        # 'none' topology of a cell and the fc reference of its other topologies are the same run
        fc_g = {k: g[k] for k in ("rounds", "updates_per_round", "compute_schedule", "total_updates", "driver",
                                  "driver_strength") if k in g}
        fc_cfg = {"kind": "trajectory", "data": data, "model": model, "train": {**tr, "freeze": "none"},
                  "growth": {"topology": "none", **fc_g, "evaluate_deletions": False, "crossover": False},
                  "seeds": seeds, "parents": {"baseline": base}, "wave": wave, "wp": ["E1"]}
        if g.get("topology", "none") == "none":
            return self.add({**fc_cfg, "block": block, "wp": wp}, block, [base])
        if with_fc:
            fc = self.add({**fc_cfg, "block": "continued_baselines"}, "continued_baselines", [base])
            parents["continued"] = fc
            deps.append(fc)
        for role, rid_ in (parents_extra or {}).items():
            parents[role] = rid_
            deps.append(rid_)
        cfg = {"kind": "trajectory", "data": data, "model": model, "train": tr, "growth": g, "seeds": seeds,
               "parents": parents, "wave": wave, "block": block, "wp": wp, "controlled": controlled}
        if deletion:
            cfg["deletion"] = deletion
        if extra:
            cfg.update(copy.deepcopy(extra))
        return self.add(cfg, block, deps)

    def finite(self, fcfg: dict, wave: int, block: str, wp: list[str]) -> str:
        return self.add({"kind": "finite", "finite": fcfg, "wave": wave, "block": block, "wp": wp}, block)

    def control(self, data: dict, model: dict, wave: int, block: str, device: str = "cpu") -> str:
        return self.add({"kind": "control", "data": data, "model": model, "wave": wave, "block": block,
                         "control": {"device": device}, "wp": ["E5", "R1", "R3"]}, block)

    def child(self, kind: str, parent: str, parent_cfg: dict, section: dict, wave: int, block: str, wp: list[str],
              seeds_over: Optional[dict] = None, tags: Optional[dict] = None) -> str:
        pc = parent_cfg
        cfg = {"kind": kind, "data": pc["data"], "model": pc["model"], "train": pc["train"], "growth": pc["growth"],
               "seeds": {**pc["seeds"], **(seeds_over or {})}, "parents": {"trajectory": parent}, "wave": wave,
               "block": block, "wp": wp, **section}
        if tags:
            cfg["tags"] = tags
        return self.add(cfg, block, [parent])

    def cop(self, data: dict, model: dict, cop: dict, peg: dict, opt_seed: int, wave: int, block: str, wp: list[str],
            parents_chain: bool = False, train_over: Optional[dict] = None,
            parents_extra: Optional[dict] = None, extra: Optional[dict] = None) -> str:
        tr = self.train(data["name"], **(train_over or {}))
        base = self.baseline(data, model, opt_seed, wave)
        upr = self.upr(data["name"])
        cop = {"local_updates": upr // 2, "global_updates": upr, **cop}
        peg = {"anneal_updates": max(1, upr // 4), **peg}
        parents, deps = {"baseline": base}, [base]
        if parents_chain:
            chain_cop = {k: v for k, v in cop.items() if k in ("n_pearls", "pearl_depth", "pearl_width", "placement",
                                                              "global_updates", "local_updates", "interface_weight")}
            ch = self.add({"kind": "cop", "data": data, "model": model, "train": tr, "peg": peg,
                           "cop": {**chain_cop, "task_kind": "chain"}, "seeds": {"optimizer": opt_seed},
                           "parents": {"baseline": base}, "wave": wave, "block": "cop_reference_chains",
                           "wp": ["P1", "P2"]}, "cop_reference_chains", [base])
            parents["chain"] = ch
            deps.append(ch)
        for role, rid in (parents_extra or {}).items():
            parents[role] = rid
            deps.append(rid)
        cfg = {"kind": "cop", "data": data, "model": model, "train": tr, "peg": peg, "cop": cop,
               "seeds": {"optimizer": opt_seed}, "parents": parents, "wave": wave, "block": block, "wp": wp}
        if extra:
            cfg.update(copy.deepcopy(extra))
        return self.add(cfg, block, deps)

    # ---------------------------------------------------------------- output
    def entries_list(self) -> list[dict]:
        # dependency order: an entry appears after all its deps
        out, seen = [], set()

        def visit(rid):
            if rid in seen:
                return
            for d in self.entries[rid]["deps"]:
                visit(d)
            seen.add(rid)
            out.append(self.entries[rid])
        for rid in self.entries:
            visit(rid)
        return out

    def coverage(self) -> dict:
        wp_jobs = {w: 0 for w in WPS}
        for e in self.entries.values():
            for w in e["wp"]:
                if w in wp_jobs:
                    wp_jobs[w] += 1
        kinds = {}
        for e in self.entries.values():
            kinds[e["cfg"]["kind"]] = kinds.get(e["cfg"]["kind"], 0) + 1
        extra = {}
        if getattr(self, "variant_map", None):
            extra["strengthening"] = {"variants": {k: sorted(v) for k, v in sorted(self.variant_map.items())},
                                      "inapplicable": self.inapplicable}
        return {**extra, "n_entries": len(self.entries), "by_kind": kinds, "jobs_per_work_package": wp_jobs,
                "missing_work_packages": [w for w, n in wp_jobs.items() if n == 0],
                "blocks": {b: {"n_jobs": len(v["jobs"]), "wp": sorted(v["wp"])} for b, v in sorted(self.blocks.items())}}


# =============================================================================
# Settings shared by waves
# =============================================================================

def teacher_data(depth=3, n=2048, seed=0, task="regression", width=48, activation=None, **kw):
    p = {"teacher_depth": depth, "teacher_width": width, "task": task}
    if activation is not None:
        p["activation"] = activation       # default (None) keeps the dataset default, tanh
    d = {"name": "teacher", "n_train": n, "teacher_seed": seed, "data_seed": seed, "params": p}
    d.update(kw)
    return d


MLP = lambda w=64, depth=4, act="relu", **kw: {"family": "mlp", "width": w, "depth": depth, "act": act, **kw}

# the four Wave-3 settings: simple teacher, harder synthetic, CIFAR-10, sequence
def wave3_settings(scale):
    return {
        "simple": (teacher_data(1, 2048), MLP(64)),
        "hard": (teacher_data(6, 8192), MLP(64)),
        "cifar10": ({"name": "cifar10", "n_train": 5000}, {"family": "resnet", "width_mult": 0.5}),
        "sequence": ({"name": "seq_select", "n_train": 8192, "n_val": 1024, "n_test": 4096},
                     {"family": "transformer", "depth": 4, "width": 64, "heads": 4}),
    }


# =============================================================================
# Waves
# =============================================================================

def wave0(B: Builder):
    for data, model in [(teacher_data(3, 2048), MLP(64)),
                        ({"name": "digits", "n_train": 512}, MLP(64)),
                        ({"name": "toy_images", "n_train": 1000}, {"family": "cnn", "width_mult": 0.5}),
                        ({"name": "toy_images", "n_train": 1000}, {"family": "resnet", "width_mult": 0.5}),
                        ({"name": "cifar10", "n_train": 1000}, {"family": "resnet", "width_mult": 0.5}),
                        ({"name": "seq_select", "n_train": 1024, "n_val": 256, "n_test": 256},
                         {"family": "transformer", "depth": 2, "width": 64}),
                        ({"name": "seq_compose", "n_train": 1024, "n_val": 256, "n_test": 256},
                         {"family": "gru", "depth": 2, "width": 64})]:
        B.control(data, model, 0, "W0_controls_cpu", "cpu")
        B.control(data, model, 0, "W0_controls_cuda", "cuda")
    # R3 / I5 finite validation instances (known reducible / irreducible first)
    for f in [{"kind": "boolean_class", "boolean_class": {"target": "xor", "hidden_widths": []}},
              {"kind": "boolean_class", "boolean_class": {"target": "and", "hidden_widths": []}},
              {"kind": "boolean_class", "boolean_class": {"target": "xor", "hidden_widths": [2]}},
              {"kind": "rank", "rank": {"mode": "exact", "true_rank": 3, "bottleneck": 2}},
              {"kind": "rank", "rank": {"mode": "exact", "true_rank": 2, "bottleneck": 2}},
              {"kind": "rank", "rank": {"mode": "approx", "true_rank": 4, "bottleneck": 2}},
              {"kind": "message", "message": {"n_bits": 3, "k_bits": 2}},
              {"kind": "message", "message": {"n_bits": 3, "k_bits": 3}},
              {"kind": "piecewise", "piecewise": {"width": 3}},
              {"kind": "piecewise", "piecewise": {"width": 1}},
              {"kind": "transition", "transition": {"system": "permutation_chain"}},
              {"kind": "transition", "transition": {"system": "absorbing_toy"}},
              {"kind": "transition", "transition": {"system": "quantized_chain"}}]:
        B.finite(f, 0, "W0_finite_validation", ["R3", "I5"])


def wave1(B: Builder):
    """Core factorial: teacher depth x n_train x student width x topology x teacher seed x optimizer seed."""
    for depth, n, w, ts, os_ in itertools.product([1, 3, 6], [512, 2048, 8192], [32, 128], B.seeds([0, 1, 2]),
                                                  B.seeds([0, 1, 2])):
        for topo in CORE5:
            B.traj(teacher_data(depth, n, ts), MLP(w, 4), {"topology": topo, "width": 32}, os_, 1, "W1_core",
                   ["E1", "E2", "E3", "R1", "I1"], controlled="topology (final graph differs by design)")
    # frequency / composition factorial with a paired easy construction
    tasks = [{"name": "frequency", "params": {"omega": 1.0}}, {"name": "frequency", "params": {"omega": 4.0}},
             {"name": "compose"}, {"name": "flat"}, {"name": "easy_teacher"}]
    for t, n, ts, os_, topo in itertools.product(tasks, [512, 8192], B.seeds([0, 1]), B.seeds([0, 1]), CORE5):
        d = {**t, "n_train": n, "teacher_seed": ts, "data_seed": ts}
        B.traj(d, MLP(64), {"topology": topo, "width": 32}, os_, 1, "W1_frequency_composition",
               ["E1", "E3", "R1"], controlled="task structure at matched normalisation")
    # train-only noise
    for kind, lv, ts, os_, topo in itertools.product(["regression", "classification"], [0.0, 0.1, 0.3], B.seeds([0, 1, 2]),
                                                     B.seeds([0]), CORE5):
        d = teacher_data(3, 2048, ts, task=kind, **({"target_noise": lv} if kind == "regression" else
                                                    {"label_noise": lv}))
        B.traj(d, MLP(64), {"topology": topo, "width": 32}, os_, 1, "W1_noise", ["E1", "I4"],
               controlled="train-only noise level")
    # sample size: matched updates vs matched epochs, and fresh-sample stream
    for n, match, ts, topo in itertools.product([512, 2048, 8192, 32768], ["updates", "epochs"], B.seeds([0, 1, 2]),
                                                ["none", "layered", "recursive"]):
        upr = B.upr("teacher")
        if match == "epochs":
            upr = max(5, int(round(upr * n / 2048)))
        g = {"topology": topo, "updates_per_round": upr}
        B.traj(teacher_data(3, n, ts), MLP(64), g, 0, 1, "W1_sample_size_matching", ["E1", "I2"],
               controlled=f"matched {match}")
    for ts, topo in itertools.product(B.seeds([0, 1, 2]), ["none", "layered", "recursive"]):
        B.traj(teacher_data(3, 2048, ts), MLP(64), {"topology": topo, "driver": "fresh"}, 0, 1,
               "W1_fresh_vs_fixed", ["I2"], controlled="fresh samples of the same target",
               train_over={"stream": "fresh"})
    # D04 / D05 / D01 synthetic breadth
    for k, s, topo in itertools.product([2, 4, 8, 12], B.seeds([0, 1, 2]), CORE5):
        # fixed 20 input bits so the domain (2^20) and sampling are comparable across k; disjoint splits
        B.traj({"name": "parity", "n_train": 8192, "params": {"k": k, "n_irrelevant": 20 - k}}, MLP(128),
               {"topology": topo}, s, 1, "W1_parity", ["E1", "R1"], controlled="relevant bits at fixed input size")
    for k, s, topo in itertools.product([2, 4], B.seeds([0, 1, 2]), CORE5):
        # small domain (2^10): complete-domain evaluation partition attached
        B.traj({"name": "parity", "n_train": 512, "n_val": 128, "n_test": 256,
                "params": {"k": k, "n_irrelevant": 10 - k}}, MLP(64), {"topology": topo}, s, 1,
               "W1_parity_complete_domain", ["E1", "R1"])
    for s, topo in itertools.product(B.seeds([0, 1, 2]), CORE5):
        B.traj({"name": "multiplexer", "n_train": 1024, "params": {"address_bits": 3}}, MLP(64), {"topology": topo},
               s, 1, "W1_multiplexer", ["E1", "R1"])
        for ql in (1, -1):
            B.traj({"name": "delayed_query", "n_train": 8192, "params": {"n_bits": 12}}, MLP(64, query_at_layer=ql),
                   {"topology": topo}, s, 1, "W1_delayed_query", ["E1", "R4"],
                   controlled="query after layer 1" if ql == 1 else "query known early (control)")
    for prev, s, topo in itertools.product([0.01, 0.05, 0.2], B.seeds([0, 1, 2]), CORE5):
        B.traj({"name": "shortcut", "n_train": 8192, "params": {"rare_prevalence": prev}}, MLP(64), {"topology": topo},
               s, 1, "W1_shortcut_rare", ["E1", "R4"], controlled="rare-subpopulation prevalence")
    for rank, din, topo in itertools.product([2, 8], [16, 64], ["none", "layered", "bridge", "linear_factor"]):
        d = {"name": "linear_rank", "n_train": 8192, "params": {"d_in": din, "d_out": 16, "rank": rank}}
        m = {"family": "mlp", "widths": [32, 4, 32], "act": "identity"}
        g = {"topology": topo, "act": "identity", "cut_kind": "post_act", "cut_where": 2 if topo == "bridge" else 1}
        B.traj(d, m, g, 0, 1, "W1_linear_rank", ["E1", "R3"],
               controlled="series implants cannot raise rank through the width-4 bottleneck; a bridge can")


def wave2(B: Builder):
    for ds, n, wm, s, topo in itertools.product(["fashion_mnist", "cifar10", "cifar100"], [1000, 5000, "full"], [0.5, 1.0],
                                                B.seeds([0, 1, 2]), CORE5):
        fam = "cnn" if ds == "fashion_mnist" else "resnet"
        B.traj({"name": ds, "n_train": n}, {"family": fam, "width_mult": wm}, {"topology": topo, "cut_kind":
               "post_act" if fam == "cnn" else "block_out", "width": 16}, s, 2, "W2_images", ["E1", "E2", "E3", "R1"])
    for wm, s, topo in itertools.product([0.5, 1.0], B.seeds([0, 1, 2]), CORE5):
        B.traj({"name": "cifar10", "n_train": 5000}, {"family": "cnn", "width_mult": wm},
               {"topology": topo, "width": 16}, s, 2, "W2_cifar10_plain_cnn", ["E1"])
    for n, s, topo in itertools.product([256, 512, 1000], B.seeds([0, 1, 2]), CORE5):
        B.traj({"name": "digits", "n_train": n}, MLP(64), {"topology": topo}, s, 2, "W2_tabular_digits", ["E1", "R1"])
    for n, s, topo in itertools.product([2000, 10000, 50000, "full"], B.seeds([0, 1, 2]), CORE5):
        B.traj({"name": "covertype", "n_train": n}, MLP(128), {"topology": topo}, s, 2, "W2_tabular_covertype",
               ["E1", "R1"])
    for n, s, topo in itertools.product([2000, "full"], B.seeds([0, 1, 2]), CORE5):
        B.traj({"name": "california", "n_train": n}, MLP(64), {"topology": topo}, s, 2, "W2_tabular_california", ["E1"])
    for task, fam, s, topo in itertools.product(["seq_copy", "seq_select", "seq_compose"], ["transformer", "gru"],
                                                B.seeds([0, 1, 2]), CORE5):
        model = {"family": fam, "depth": 4 if fam == "transformer" else 2, "width": 64, "heads": 4}
        ck = "resid" if fam == "transformer" else "gru_out"
        B.traj({"name": task, "n_train": 8192, "n_val": 1024, "n_test": 4096}, model,
               {"topology": topo, "cut_kind": ck}, s, 2, "W2_sequence", ["E1", "E3", "R1"])


def _cut_kind(model):
    return {"mlp": "post_act", "cnn": "post_act", "resnet": "block_out", "transformer": "resid", "gru": "gru_out"}[
        model["family"]]


def wave3(B: Builder):
    S = wave3_settings(B.scale)
    seeds = B.seeds([0, 1, 2])
    for sname, (data, model) in S.items():
        ck = _cut_kind(model)
        rounds_list = [1, 2, 4, 8, 16, 32] if sname in ("simple", "hard") else [1, 4, 16]
        # E1 layered shapes and history length; controlled quantity is named per cell
        for shape, act, R, s in itertools.product(["chain", "wide", "alternating", "separated"], ["relu", "identity"],
                                                  rounds_list, seeds):
            if act == "identity" and sname not in ("simple", "hard"):
                continue
            g = {"topology": "layered", "shape": shape, "act": act, "rounds": R, "cut_kind": ck, "width": 8,
                 "narrow_width": 8, "wide_width": 8 * R}
            B.traj(data, model, g, s, 3, f"W3_E1_{sname}", ["E1", "I1"],
                   controlled="final topology" if shape == "chain" else ("param budget (wide = rounds x narrow)"
                                                                         if shape == "wide" else "shape"))
        for s in seeds:
            for sched in ["per_round", "total"]:
                g = {"topology": "layered", "rounds": 8, "cut_kind": ck, "compute_schedule": sched,
                     "total_updates": 3 * B.upr(data["name"]) if sched == "total" else 0}
                B.traj(data, model, g, s, 3, f"W3_I1_compute_{sname}", ["I1"],
                       controlled="constant compute per round" if sched == "per_round" else "constant total compute")
        # E2 branch families
        e2 = [("dup_branch", {"tie": "untied"}), ("dup_branch", {"tie": "tied"}), ("dup_branch", {"split": 0.3}),
              ("cancel_pair", {"tie": "untied"}), ("cancel_pair", {"tie": "tied"}),
              ("cancel_pair", {"symmetry_noise": 1e-3}), ("complementary", {}), ("specialized", {}),
              ("specialized", {"specialize": "aux"})]
        e2 += [("parallel", {"merge": m, "tie": t}) for m in ("sum", "concat", "route") for t in ("untied", "tied")]
        for (topo, extra), s in itertools.product(e2, seeds):
            B.traj(data, model, {"topology": topo, "cut_kind": ck, **extra}, s, 3, f"W3_E2_{sname}", ["E2", "R1"])
        # E3 recursive families, construction order, schedules
        for topo, s in itertools.product(["recursive", "recursive_branch", "hard_submodule", "recursive_descendants",
                                          "chain_in_branch"], seeds):
            B.traj(data, model, {"topology": topo, "cut_kind": ck, "rounds": 4}, s, 3, f"W3_E3_{sname}", ["E3", "R1"])
        for order, sched, s in itertools.product(["breadth_first", "depth_first"], ["incremental", "all_at_once",
                                                                                   "from_scratch"], seeds):
            if order == "depth_first" and sched != "incremental":
                continue   # same final graph; one non-incremental reference suffices
            B.traj(data, model, {"topology": "tree_depth2", "order": order, "schedule": sched, "cut_kind": ck}, s, 3,
                   f"W3_E3_order_{sname}", ["E3", "I1"], controlled="same final graph (structural hash checked)")
        for sched, s in itertools.product(["all_at_once", "from_scratch"], seeds):
            B.traj(data, model, {"topology": "recursive_branch", "schedule": sched, "cut_kind": ck}, s, 3,
                   f"W3_schedules_{sname}", ["E3", "I1"], controlled="same final graph")
        # E4 cut location and granularity
        wheres = ["early", "middle", "late"]
        chans = [1, 4, 16, None]
        for where, ch, s in itertools.product(wheres, chans, seeds):
            g = {"topology": "layered", "cut_kind": ck, "cut_where": where, "channels": ch, "rounds": 2}
            B.traj(data, model, g, s, 3, f"W3_E4_{sname}", ["E4"], controlled="cut location x granularity")
        for ch, order, s in itertools.product([4, 16], ["first", "random", "top_variance"], seeds):
            g = {"topology": "layered", "cut_kind": ck, "channels": ch, "channel_order": order, "rounds": 2}
            B.traj(data, model, g, s, 3, f"W3_E4_permutation_{sname}", ["E4"],
                   controlled="permutation control (unit order is a symmetry) vs feature-guided selection")
        if model["family"] in ("resnet", "transformer"):
            for sub, s in itertools.product(["skip", "branch"], seeds):
                g = {"topology": "layered", "cut_kind": ck, "cut_subset": sub, "rounds": 2, "cut_where": 0}
                B.traj(data, model, g, s, 3, f"W3_E4_edge_cuts_{sname}", ["E4"],
                       controlled="edge cut affecting one consumer")
            extra_kinds = ["resid_branch", "post_act", "pre_bn", "post_bn"] if model["family"] == "resnet" else \
                ["attn_out", "mlp_out", "mlp_hidden"]
            for kk, s in itertools.product(extra_kinds, seeds):
                B.traj(data, model, {"topology": "layered", "cut_kind": kk, "rounds": 2}, s, 3, f"W3_E4_kinds_{sname}",
                       ["E4"])
        if model["family"] == "transformer":
            for s in seeds:
                B.traj(data, model, {"topology": "layered", "cut_kind": ck, "positions": {"last": 1}, "rounds": 2}, s, 3,
                       f"W3_E4_token_local_{sname}", ["E4"], controlled="token-local implant (last token)")
        if model["family"] == "mlp":
            for kk, s in itertools.product(["pre_act", "input"], seeds):
                B.traj(data, model, {"topology": "layered", "cut_kind": kk, "rounds": 2, "cut_where": "middle"
                                     if kk == "pre_act" else 0}, s, 3, f"W3_E4_kinds_{sname}", ["E4"])
        # E5 how dependence begins
        constr = [("layered", {"construction": "residual_zero"}), ("layered", {"construction": "linear_factor"}),
                  ("layered", {"construction": "concat_expand"}),
                  ("inverse_pair", {"tie": "enforced"}), ("inverse_pair", {"tie": "untied"}),
                  ("inverse_pair", {"tie": "learned"}), ("cancel_pair", {"tie": "untied"}), ("cancel_pair", {"tie": "tied"})]
        if sname in ("simple", "hard"):
            for (topo, extra), fr, s in itertools.product(constr, ["none", "original_frozen", "implants_frozen",
                                                                   "upstream_only", "downstream_only"], seeds):
                B.traj(data, model, {"topology": topo, "cut_kind": ck, "rounds": 2, **extra}, s, 3,
                       f"W3_E5_freeze_{sname}", ["E5"], train_over={"freeze": fr}, controlled="freeze policy")
            for (topo, extra), opt, wd, st, s in itertools.product(
                    [("layered", {"construction": "residual_zero"}), ("inverse_pair", {"tie": "untied"})],
                    ["adamw", "sgd"], [0.0, 1e-4], ["preserve", "reset"], seeds):
                tro = {"optimizer": opt, "weight_decay": wd, "opt_state_on_edit": st}
                if opt == "sgd":
                    tro.update({"momentum": 0.9, "lr": 0.01})
                B.traj(data, model, {"topology": topo, "cut_kind": ck, "rounds": 2, **extra}, s, 3,
                       f"W3_E5_optimizer_{sname}", ["E5"], train_over=tro, controlled="optimizer / decay / state policy")
        # I2 drivers (stationary control needs regression)
        if sname in ("simple", "hard"):
            for drv, strength, s in itertools.product(["fixed", "changing_target", "output_constrained",
                                                       "neutral_mutation", "stationary_self"], [0.5], seeds):
                st = {"neutral_mutation": 1e-3, "output_constrained": 1.0, "changing_target": 0.5}.get(drv, 0.0)
                tro = {"optimizer": "sgd", "momentum": 0.0, "lr": 0.01} if drv == "stationary_self" else {}
                B.traj(data, model, {"topology": "layered", "cut_kind": ck, "rounds": 4, "driver": drv,
                                     "driver_strength": st}, s, 3, f"W3_I2_{sname}", ["I2"], train_over=tro,
                       controlled="history driver")
            for mom, wd, s in itertools.product([0.0, 0.9], [0.0, 1e-4], seeds):
                B.traj(data, model, {"topology": "layered", "cut_kind": ck, "rounds": 4, "driver": "stationary_self"},
                       s, 3, f"W3_I2_stationary_{sname}", ["I2"],
                       train_over={"optimizer": "sgd", "momentum": mom, "weight_decay": wd, "lr": 0.01},
                       controlled="exact zero-loss start; momentum / decay switch movement on")
        # I3 insertion policy
        for pol, s in itertools.product(["random", "dependence_seeking", "removability_preserving"], seeds):
            B.traj(data, model, {"topology": "layered", "cut_kind": ck, "rounds": 4, "policy": pol,
                                 "policy_candidates": 4, "policy_probe_updates": max(5, B.upr(data["name"]) // 10)}, s, 3,
                   f"W3_I3_{sname}", ["I3"], controlled="equal search budget across adaptive policies")
        # I4 switches
        i4 = [({"peg_dim": 2}, "communication limit 2"), ({"peg_dim": 8}, "communication limit 8"),
              ({"peg_dim": 4, "stable_pegs": True}, "stable pegs"), ({"aux_objective": "aligned"}, "aligned aux"),
              ({"aux_objective": "antagonistic"}, "antagonistic aux (deliberate)"),
              ({"replacement_pressure": 1e-3}, "replacement pressure 1e-3"),
              ({"replacement_pressure": 1e-2}, "replacement pressure 1e-2")]
        for (extra, lab), s in itertools.product(i4, seeds):
            B.traj(data, model, {"topology": "layered", "cut_kind": ck, "rounds": 4, **extra}, s, 3, f"W3_I4_{sname}",
                   ["I4"], controlled=lab)
        for merge, tie, s in itertools.product(["sum", "route"], ["untied", "tied"], seeds):
            B.traj(data, model, {"topology": "parallel", "cut_kind": ck, "rounds": 4, "merge": merge, "tie": tie}, s, 3,
                   f"W3_I4_competition_sharing_{sname}", ["I4", "E2"],
                   controlled="competition (route) vs cooperation (sum); sharing")
        # explicit cross: recursive growth x cut granularity x stable pegs
        for topo, ch, pegc, s in itertools.product(["recursive", "recursive_branch"], [4, None],
                                                    [{}, {"peg_dim": 4}, {"peg_dim": 4, "stable_pegs": True}], seeds):
            B.traj(data, model, {"topology": topo, "cut_kind": ck, "channels": ch, **pegc}, s, 3,
                   f"W3_cross_recursion_granularity_pegs_{sname}", ["E3", "E4", "I4"])
    # full fixed matrix of chosen hard settings (not selected by effect size)
    data, model = teacher_data(6, 512), MLP(32)
    for topo, sched, s in itertools.product(CORE5 + ["tree_depth2", "hard_submodule"],
                                            ["incremental", "all_at_once", "from_scratch"], B.seeds([0, 1, 2])):
        if topo == "none" and sched != "incremental":
            continue
        if topo == "hard_submodule" and sched != "incremental":
            continue
        B.traj(data, model, {"topology": topo, "schedule": sched}, s, 3, "W3_hard_fixed_matrix", ["E1", "E3", "I1"])
    # E5 known computations
    for km, s in itertools.product(["poly", "pretrained", "random_matched"], B.seeds([0, 1, 2])):
        B.traj({"name": "compose", "n_train": 8192}, MLP(64), {"topology": "known_module", "known_module": km,
                                                               "cut_kind": "post_act", "cut_where": "early"},
               s, 3, "W3_E5_known_modules", ["E5"])
    # 64 growth events on a selected small case
    for s in B.seeds([0, 1, 2]):
        B.traj(teacher_data(1, 2048), MLP(32), {"topology": "layered", "rounds": 64, "width": 4,
                                                "updates_per_round": max(5, B.upr("teacher") // 4)}, s, 3,
               "W3_I1_64_events", ["I1"], deletion={"family": "structured"})


def wave4(B: Builder, results: Optional[Path] = None, per_cell: int = 2):
    """Deletion, repair, return paths and finite certificates.  With --results,
    parents are selected from completed trajectories by a PRESPECIFIED balanced
    rule: within each (block, topology) family, rank by the maximum single-
    deletion validation effect, split into low / medium / high tertiles and take
    the first `per_cell` runs of each tertile in run-id hash order (not by
    effect size).  Without results, Wave-1/3 trajectories with the same configs
    are declared as prerequisites (same run ids, so nothing is retrained)."""
    parents: list[tuple[str, dict]] = []
    if results and (Path(results) / "runs").exists():
        parents = select_balanced(Path(results), per_cell)
    if not parents:
        for depth, topo in itertools.product([1, 6], ["layered", "parallel", "recursive", "recursive_branch"]):
            rid = B.traj(teacher_data(depth, 2048), MLP(64), {"topology": topo, "width": 32}, 0, 4,
                         "W4_parents_standalone", ["R1"])
            parents.append((rid, B.entries[rid]["cfg"]))
        for topo in ["cancel_pair", "dup_branch", "inverse_pair", "tree_depth2"]:
            rid = B.traj(teacher_data(3, 2048), MLP(64), {"topology": topo}, 0, 4, "W4_parents_standalone", ["R1"])
            parents.append((rid, B.entries[rid]["cfg"]))
        for topo in ["recursive_branch"]:
            rid = B.traj({"name": "cifar10", "n_train": 5000}, {"family": "resnet", "width_mult": 0.5},
                         {"topology": topo, "cut_kind": "block_out", "width": 16}, 0, 4, "W4_parents_standalone", ["R1"])
            parents.append((rid, B.entries[rid]["cfg"]))
            rid = B.traj({"name": "seq_select", "n_train": 8192, "n_val": 1024, "n_test": 4096},
                         {"family": "transformer", "depth": 4, "width": 64}, {"topology": topo, "cut_kind": "resid"},
                         0, 4, "W4_parents_standalone", ["R1"])
            parents.append((rid, B.entries[rid]["cfg"]))
    for k, (pid, pcfg) in enumerate(parents):
        B.child("deletion", pid, pcfg, {"deletion": {"family": "auto", "max_exhaustive_atoms": 12}}, 4, "W4_R1_deletion",
                ["R1"], tags={"parent_stage": "final"})
        for region, target in itertools.product(["none", "incident_adapters", "adjacent", "containing_pearl",
                                                 "downstream", "full", "fresh_original", "fresh_smaller"],
                                                ["task", "expanded", "original"]):
            ladder = [0.1, 0.5, 1.0, 4.0] if region in ("full", "incident_adapters", "fresh_smaller") else [1.0]
            if region == "none":
                ladder = [0.0]
            for mult, rs in itertools.product(ladder, B.seeds([0, 1])):
                B.child("repair", pid, pcfg, {"repair": {"region": region, "target": target,
                                                         "budget_multiplier": mult}}, 4, "W4_R2_R4_repair",
                        ["R2", "R4"], seeds_over={"repair": rs})
        for method, order, speed in itertools.product(["abrupt", "linear", "cosine", "residual_penalty",
                                                       "branch_merge", "group_removal", "peg_replacement",
                                                       "inverse_restore"], ["joint", "ancestor_first",
                                                                            "descendant_first"], ["fast", "slow"]):
            if method in ("branch_merge",) and pcfg["growth"]["topology"] not in ("parallel", "recursive_branch",
                                                                                 "tree_depth2", "dup_branch"):
                continue
            if method == "inverse_restore" and pcfg["growth"]["topology"] != "inverse_pair":
                continue
            upr = pcfg["growth"]["updates_per_round"]
            sp = upr // 4 if speed == "fast" else upr
            B.child("dissipation", pid, pcfg, {"dissipation": {"method": method, "order": order, "speed_updates": max(5, sp),
                                                               "post_updates": max(5, upr // 2)}}, 4, "W4_R5_paths",
                    ["R5"])
    # repair cost over the history (I1): repairs at intermediate rounds of long layered histories
    for s in B.seeds([0, 1, 2]):
        data, model = teacher_data(1, 2048), MLP(64)
        g = {"topology": "layered", "shape": "chain", "act": "relu", "rounds": 32, "cut_kind": "post_act", "width": 8,
             "narrow_width": 8, "wide_width": 8 * 32}
        pid = B.traj(data, model, g, s, 3, "W3_E1_simple", ["E1", "I1"], controlled="final topology")
        pcfg = B.entries[pid]["cfg"]
        for k in (1, 2, 4, 8, 16, 32):
            B.child("repair", pid, pcfg, {"repair": {"region": "full", "target": "task", "budget_multiplier": 1.0,
                                                     "deletion": "all"}}, 4, "W4_I1_repair_over_history", ["I1", "R2"],
                    tags={"parent_stage": f"round_{k}"})
    # finite certificates and transition systems (R3, I5)
    for n_in, widths, target in itertools.product([2, 3], [[], [1], [2]], ["xor", "and", "parity", "majority"]):
        B.finite({"kind": "boolean_class", "boolean_class": {"n_inputs": n_in, "target": target, "hidden_widths": widths}},
                 4, "W4_R3_boolean", ["R3"])
    for n, k in itertools.product([2, 3, 4], [1, 2, 3]):
        if k <= n:
            B.finite({"kind": "message", "message": {"n_bits": n, "k_bits": k}}, 4, "W4_R3_message", ["R3"])
    for tr_, bn, mode in itertools.product([2, 3, 4], [1, 2, 3], ["exact", "approx"]):
        B.finite({"kind": "rank", "rank": {"mode": mode, "true_rank": tr_, "bottleneck": bn}}, 4, "W4_R3_rank", ["R3"])
    for w in [1, 2, 3, 4]:
        B.finite({"kind": "piecewise", "piecewise": {"width": w}}, 4, "W4_R3_piecewise", ["R3"])
    for system, params in [("permutation_chain", {"m": 3, "K": 3}), ("permutation_chain", {"m": 3, "K": 4}),
                           ("permutation_chain", {"m": 4, "K": 3}), ("absorbing_toy", {}),
                           ("quantized_chain", {}), ("quantized_chain", {"K": 1, "rule": "metropolis"}),
                           ("quantized_chain", {"rule": "nonincreasing"})]:
        B.finite({"kind": "transition", "transition": {"system": system, "params": params}}, 4, "W4_I5_transition",
                 ["I5"])


def select_balanced(results: Path, per_cell: int) -> list[tuple[str, dict]]:
    fam: dict[tuple, list] = {}
    for d in sorted((results / "runs").glob("traj-*")):
        st = d / "status.json"
        if not st.exists():
            continue
        sd = read_json(st)
        if sd.get("status") != "complete" or sd.get("validity", "valid") != "valid":
            continue          # quarantined / unverified trajectories are never selected as parents
        cfg = read_json(d / "config.json")
        if cfg["growth"]["topology"] == "none":
            continue
        best = None
        for r in read_jsonl(d / "metrics.jsonl"):
            if r["stage"] == "final" or not r["metric_name"].startswith("delete[") or \
                    not r["metric_name"].endswith("delta_risk") or r["evaluation_partition"] != "val":
                continue
            if r["stage"] == f"round_{cfg['growth']['rounds']}":
                best = max(best or -1e30, r["metric_value"])
        if best is None:
            continue
        fam.setdefault((cfg.get("block"), cfg["growth"]["topology"]), []).append((d.name, cfg, best))
    out = []
    for key, items in sorted(fam.items(), key=lambda kv: str(kv[0])):
        items.sort(key=lambda t: t[2])
        n = len(items)
        terc = [items[: n // 3], items[n // 3: 2 * n // 3], items[2 * n // 3:]]
        for t in terc:
            for rid, cfg, _ in sorted(t, key=lambda x: stable_hash(x[0]))[:per_cell]:
                out.append((rid, cfg))
    return out


def wave5(B: Builder):
    tasks = {
        "compose": ({"name": "compose", "n_train": 8192}, MLP(64, depth=6)),
        "delayed_query": ({"name": "delayed_query", "n_train": 8192, "params": {"n_bits": 12}},
                          MLP(64, depth=4, query_at_layer=1)),
        "covertype": ({"name": "covertype", "n_train": 50000}, MLP(128, depth=6)),
        "cifar10": ({"name": "cifar10", "n_train": "full"}, {"family": "resnet", "width_mult": 1.0,
                                                             "blocks_per_stage": 2}),
        "sequence": ({"name": "seq_select", "n_train": 8192, "n_val": 1024, "n_test": 4096},
                     {"family": "transformer", "depth": 6, "width": 64}),
    }
    seeds = B.seeds([0, 1, 2])
    for tname, (data, model) in tasks.items():
        npearl = 2 if tname == "delayed_query" else 3
        # P1 placement, edits, branch pegs
        places = ["regular", "random", "adaptive"] + (["known"] if tname == "compose" else [])
        for pl, k, s in itertools.product(places, [4, 16], seeds):
            B.cop(data, model, {"task_kind": "chain", "placement": pl, "n_pearls": npearl}, {"dim": k}, s, 5,
                  f"W5_P1_placement_{tname}", ["P1"])
        for ed, s in itertools.product(["move", "split", "merge"], seeds):
            if tname == "delayed_query" and ed == "merge":
                continue
            B.cop(data, model, {"task_kind": "chain", "peg_edit": ed, "n_pearls": npearl}, {"dim": 8}, s, 5,
                  f"W5_P1_edits_{tname}", ["P1"])
        if tname in ("compose", "covertype"):
            for bp, s in itertools.product(["shared", "separate"], seeds):
                B.cop(data, model, {"task_kind": "chain", "branch_pegs": bp}, {"dim": 8}, s, 5,
                      f"W5_P1_branch_pegs_{tname}", ["P1"])
        # P2 what a peg transmits
        for k, s in itertools.product([1, 2, 4, 8, 16, 32], seeds):
            B.cop(data, model, {"task_kind": "chain", "n_pearls": npearl}, {"dim": k, "mode": "none"}, s, 5,
                  f"W5_P2_dims_{tname}", ["P2"])
        for bits, s in itertools.product([1, 2, 4, 8], seeds):
            B.cop(data, model, {"task_kind": "chain", "n_pearls": npearl}, {"dim": 8, "mode": "uniform", "bits": bits},
                  s, 5, f"W5_P2_bits_{tname}", ["P2"])
        for pc, s in itertools.product([{"mode": "vq", "codebook_size": 16}, {"mode": "vq", "codebook_size": 256},
                                        {"mode": "multi", "n_messages": 2, "codebook_size": 16},
                                        {"mode": "multi", "n_messages": 4, "codebook_size": 16}], seeds):
            B.cop(data, model, {"task_kind": "chain", "n_pearls": npearl}, {"dim": 8, **pc}, s, 5,
                  f"W5_P2_codebooks_{tname}", ["P2"])
        for tc, s in itertools.product([0, 4, 16], seeds):
            B.cop(data, model, {"task_kind": "chain", "n_pearls": npearl}, {"dim": 4, "temp_channel": tc}, s, 5,
                  f"W5_P2_temp_channel_{tname}", ["P2"])
        if tname == "delayed_query":
            continue
        # P3 alternatives (needs >=2 middle pearls)
        alt_kinds = {"cifar10": ["conv_large", "conv_small", "lowrank", "linear"],
                     "sequence": ["attn_block", "mlp_large", "mlp_small", "lowrank"]}.get(
            tname, ["mlp_large", "mlp_small", "lowrank", "linear", "sparse"])
        combos = [("independent", "fixed_teacher"), ("independent", "aligned"), ("joint", "learned"),
                  ("joint", "task_only"), ("shared_interface", "fixed_teacher")]
        for (mode, ck), s in itertools.product(combos, seeds):
            if ck == "aligned" and tname == "cifar10":
                continue
            B.cop(data, model, {"task_kind": "alternatives", "n_pearls": 4, "alt_training": mode, "code_kind": ck,
                                "alt_kinds": alt_kinds}, {"dim": 8}, s, 5, f"W5_P3_{tname}", ["P3"], parents_chain=True)
        for w, li, s in itertools.product([0.1, 1.0, 10.0], ["teacher", "on_policy"], seeds):
            if li == "on_policy" and w != 1.0:
                continue
            mode = "shared_interface" if li == "teacher" else "independent"
            B.cop(data, model, {"task_kind": "alternatives", "n_pearls": 4, "alt_training": mode,
                                "code_kind": "fixed_teacher", "interface_weight": w, "local_inputs": li,
                                "alt_kinds": alt_kinds}, {"dim": 8}, s, 5, f"W5_P3_interface_sweep_{tname}", ["P3"],
                  parents_chain=True)
        if tname == "compose":
            B.cop(data, model, {"task_kind": "alternatives", "n_pearls": 4, "alt_kinds": ["mlp_small", "table"]},
                  {"dim": 4, "mode": "uniform", "bits": 2}, 0, 5, "W5_P3_tables_compose", ["P3"], parents_chain=True)
        # P4 recursive splitting (vector / sequence pearls)
        if tname != "cifar10":
            for sp, bud, s in itertools.product([2, 4, 8], ["matched", "unconstrained"], seeds):
                B.cop(data, model, {"task_kind": "split", "n_pearls": 4, "split_into": sp, "split_budget": bud},
                      {"dim": 8}, s, 5, f"W5_P4_{tname}", ["P4"], parents_chain=True)
        # P5 cycles and section-10 baselines
        for order, pegs_, cyc, s in itertools.product(["input_to_output", "output_to_input", "center_out", "leaf_inward"],
                                                      ["fixed", "relearned", "none"], [2, 4], seeds):
            B.cop(data, model, {"task_kind": "cycles", "cycle_order": order, "cycle_pegs": pegs_, "cycles": cyc,
                                "n_pearls": 3}, {"dim": 8}, s, 5, f"W5_P5_{tname}", ["P5"])
        # section-10 baselines: one full cycle per pearl (cycles = n_pearls); the matched controls
        # (direct_small, distill) copy the EXPORTED ENDPOINT of the expand_peg_replace history of the same seed
        for s in seeds:
            bl_cop = {"task_kind": "baseline", "n_pearls": 4, "cycles": 4}
            full = B.cop(data, model, {**bl_cop, "baseline": "expand_peg_replace"}, {"dim": 8}, s, 5,
                         f"W5_baselines_{tname}", ["P5", "P3"])
            for bl in ["direct_small", "distill"]:
                B.cop(data, model, {**bl_cop, "baseline": bl}, {"dim": 8}, s, 5, f"W5_baselines_{tname}",
                      ["P5", "P3"], parents_extra={"cycles": full})
            for bl in ["direct_small_all_pearls", "replace_no_expand", "progressive_no_peg", "peg_no_expand",
                       "expand_no_peg", "shared_fold"]:
                if bl == "replace_no_expand" and model["family"] != "mlp":
                    continue
                B.cop(data, model, {**bl_cop, "baseline": bl}, {"dim": 8}, s, 5, f"W5_baselines_{tname}",
                      ["P5", "P3"])
        # matched endpoint controls for every P5 history variant of seed 0 (orders x pegs x cycle counts)
        for order, pegs_, cyc in itertools.product(["input_to_output", "output_to_input", "center_out", "leaf_inward"],
                                                   ["fixed", "relearned", "none"], [2, 4]):
            hist = B.cop(data, model, {"task_kind": "cycles", "cycle_order": order, "cycle_pegs": pegs_,
                                       "cycles": cyc, "n_pearls": 3}, {"dim": 8}, seeds[0], 5, f"W5_P5_{tname}", ["P5"])
            B.cop(data, model, {"task_kind": "baseline", "baseline": "direct_small", "cycle_order": order,
                                "cycle_pegs": pegs_, "cycles": cyc, "n_pearls": 3}, {"dim": 8}, seeds[0], 5,
                  f"W5_P5_matched_{tname}", ["P5"], parents_extra={"cycles": hist})


def wave6(B: Builder, selection: Path):
    """Confirmation: re-run FROZEN selected blocks with 10 optimizer seeds and
    3 fresh data/teacher seeds (100-102).  The selection file must be written
    BEFORE these runs (git-commit it); see configs/confirmation.yaml."""
    sel = yaml.safe_load(open(selection))
    if not sel or not sel.get("cells"):
        raise ValueError("confirmation selection is empty; edit configs/confirmation.yaml first")
    for cell in sel["cells"]:
        data, model, growth = cell["data"], cell["model"], cell["growth"]
        for ds, os_ in itertools.product(cell.get("data_seeds", [100, 101, 102]), cell.get("optimizer_seeds",
                                                                                          list(range(10)))):
            d = dict(data)
            if d["name"] in SYNTHETIC | FINITE | SEQ:
                d["data_seed"] = ds
                d["teacher_seed"] = ds
            B.traj(d, model, growth, os_, 6, f"W6_{cell['name']}", cell.get("wp", ["E1"]),
                   controlled="confirmation (frozen before running)", train_over=cell.get("train"))


def wave9_integration_pilot(B: Builder):
    """GPU integration pilot (not a scientific wave): one small valid case per
    major model family and job kind, including the cache-heavy CoP image case,
    so memory, runtime, checkpoints, metrics and predictions can be inspected
    on the real device before any sweep.  Use with --scale pilot."""
    fams = [("synthetic_mlp", teacher_data(3, 2048), MLP(64), "post_act"),
            ("fmnist_cnn", {"name": "fashion_mnist", "n_train": 2000}, {"family": "cnn", "width_mult": 0.5}, "post_act"),
            ("cifar10_resnet", {"name": "cifar10", "n_train": 2000}, {"family": "resnet", "width_mult": 0.5},
             "block_out"),
            ("seq_transformer", {"name": "seq_select", "n_train": 2048, "n_val": 512, "n_test": 1024},
             {"family": "transformer", "depth": 4, "width": 64}, "resid"),
            ("seq_gru", {"name": "seq_compose", "n_train": 2048, "n_val": 512, "n_test": 1024},
             {"family": "gru", "depth": 2, "width": 64}, "gru_out")]
    for name, data, model, ck in fams:
        rid = B.traj(data, model, {"topology": "recursive_branch", "cut_kind": ck, "rounds": 2}, 0, 9,
                     f"W9_pilot_{name}", ["E1"])
        if name in ("synthetic_mlp", "cifar10_resnet"):
            pcfg = B.entries[rid]["cfg"]
            B.child("deletion", rid, pcfg, {"deletion": {"family": "auto"}}, 9, f"W9_pilot_{name}", ["R1"],
                    tags={"parent_stage": "final"})
            B.child("repair", rid, pcfg, {"repair": {"region": "full", "budget_multiplier": 0.5}}, 9,
                    f"W9_pilot_{name}", ["R2"])
            B.child("dissipation", rid, pcfg, {"dissipation": {"method": "linear", "speed_updates": 50,
                                                               "post_updates": 50}}, 9, f"W9_pilot_{name}", ["R5"])
    for data, model, tag in [({"name": "compose", "n_train": 4096}, MLP(64, depth=6), "vec"),
                             ({"name": "cifar10", "n_train": 5000}, {"family": "resnet", "width_mult": 1.0,
                                                                     "blocks_per_stage": 2}, "img"),
                             ({"name": "seq_select", "n_train": 4096, "n_val": 1024, "n_test": 2048},
                              {"family": "transformer", "depth": 6, "width": 64}, "seq")]:
        blk = f"W9_pilot_cop_{tag}"
        B.cop(data, model, {"task_kind": "chain", "n_pearls": 3}, {"dim": 8, "mode": "uniform", "bits": 4}, 0, 9, blk,
              ["P1", "P2"])
        kinds = ["conv_small", "linear"] if tag == "img" else (["attn_block", "mlp_small"] if tag == "seq"
                                                                 else ["mlp_small", "linear", "table"])
        B.cop(data, model, {"task_kind": "alternatives", "n_pearls": 4, "alt_kinds": kinds},
              {"dim": 4 if tag == "vec" else 8, "mode": "uniform", "bits": 2 if tag == "vec" else 4}, 0, 9, blk, ["P3"],
              parents_chain=True)
        if tag != "img":
            B.cop(data, model, {"task_kind": "split", "n_pearls": 4, "split_into": 2}, {"dim": 8}, 0, 9, blk, ["P4"],
                  parents_chain=True)
        cyc = B.cop(data, model, {"task_kind": "cycles", "n_pearls": 3, "cycles": 2, "cycle_pegs": "relearned"},
                    {"dim": 8}, 0, 9, blk, ["P5"])
        B.cop(data, model, {"task_kind": "baseline", "baseline": "direct_small", "n_pearls": 3, "cycles": 2,
                            "cycle_pegs": "relearned"}, {"dim": 8}, 0, 9, blk, ["P5"], parents_extra={"cycles": cyc})
    B.finite({"kind": "transition", "transition": {"system": "quantized_chain"}}, 9, "W9_pilot_finite", ["I5"])


def wave7(B: Builder):
    from .wave7 import wave7_strengthening
    wave7_strengthening(B)


def wave13(B: Builder):
    from .wave13 import wave13_repilot
    wave13_repilot(B)


def wave14(B: Builder):
    from .wave13 import wave14_confirmation
    wave14_confirmation(B)


def wave15(B: Builder):
    from .wave13 import wave15_control_development
    wave15_control_development(B)


def wave16(B: Builder):
    from .wave13 import wave16_finite_followup
    wave16_finite_followup(B)


def wave18(B: Builder):
    from .wave13 import wave18_v22_panel
    wave18_v22_panel(B)


def wave19(B: Builder):
    from .wave13 import wave19_v25_panel
    wave19_v25_panel(B)


def wave20(B: Builder):
    from .wave13 import wave20_v26_panel
    wave20_v26_panel(B)


def wave21(B: Builder):
    from .wave13 import wave21_v30_panel
    wave21_v30_panel(B)


def wave22(B: Builder):
    from .wave13 import wave22_v39_panel
    wave22_v39_panel(B)


def wave23(B: Builder):
    from .wave13 import wave23_v42_panel
    wave23_v42_panel(B)


def wave24(B: Builder):
    from .wave13 import wave24_v44_panel
    wave24_v44_panel(B)


def wave25(B: Builder):
    from .wave13 import wave25_v45_panel
    wave25_v45_panel(B)


def wave26(B: Builder):
    from .wave13 import wave26_v53_panel
    wave26_v53_panel(B)


def wave28(B: Builder):
    from .wave13 import wave28_v58_panel
    wave28_v58_panel(B)


def wave29(B: Builder):
    from .wave13 import wave29_v62_panel
    wave29_v62_panel(B)


def wave30(B: Builder):
    from .wave13 import wave30_v65_image_panel
    wave30_v65_image_panel(B)


def wave31(B: Builder):
    from .wave13 import wave31_v65_mechanism_panel
    wave31_v65_mechanism_panel(B)


def wave32(B: Builder):
    from .wave13 import wave32_v66_reset_compacts
    wave32_v66_reset_compacts(B)


def wave27(B: Builder):
    from .wave13 import wave27_v57_panel
    wave27_v57_panel(B)


def wave17(B: Builder):
    from .wave13 import wave17_mechanism_panel
    wave17_mechanism_panel(B)


WAVES = {0: wave0, 1: wave1, 2: wave2, 3: wave3, 4: wave4, 5: wave5, 7: wave7, 9: wave9_integration_pilot,
         13: wave13, 14: wave14, 15: wave15, 16: wave16, 17: wave17, 18: wave18, 19: wave19, 20: wave20, 21: wave21, 22: wave22, 23: wave23, 24: wave24, 25: wave25,
         26: wave26, 27: wave27, 28: wave28, 29: wave29, 30: wave30, 31: wave31, 32: wave32}


def generate(waves: list[int], scale: str = "full", results: Optional[Path] = None,
             selection: Optional[Path] = None) -> Builder:
    B = Builder(scale)
    for w in waves:
        if w == 4:
            wave4(B, results)
        elif w == 6:
            wave6(B, selection or ROOT / "configs" / "confirmation.yaml")
        else:
            WAVES[w](B)
    return B


def factorial_checks(B: Builder) -> dict:
    """Recompute the two registry factorial counts from the manifest."""
    w1 = [e for e in B.entries.values() if "W1_core" in e["blocks"] and e["cfg"]["kind"] == "trajectory"]
    w2 = [e for e in B.entries.values() if "W2_images" in e["blocks"] and e["cfg"]["kind"] == "trajectory"]
    cells1 = {(e["cfg"]["data"]["params"]["teacher_depth"], e["cfg"]["data"]["n_train"], e["cfg"]["model"]["width"],
               e["cfg"]["growth"]["topology"], e["cfg"]["data"]["teacher_seed"], e["cfg"]["seeds"]["optimizer"])
              for e in w1}
    cells2 = {(e["cfg"]["data"]["name"], e["cfg"]["data"]["n_train"], e["cfg"]["model"]["width_mult"],
               e["cfg"]["growth"]["topology"], e["cfg"]["seeds"]["optimizer"]) for e in w2}
    return {"wave1_core_trajectories": len(w1), "wave1_core_distinct_cells": len(cells1),
            "wave2_images_trajectories": len(w2), "wave2_images_distinct_cells": len(cells2)}
