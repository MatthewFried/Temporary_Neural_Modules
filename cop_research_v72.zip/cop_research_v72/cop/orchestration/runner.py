"""Job execution with claims, statuses, attempts and resume.

* A job is claimed with an O_EXCL lock file in its run dir; two workers never
  train the same job unknowingly (stale locks of dead local pids are broken).
* status.json values: pending, running, complete, failed, timed_out,
  unsupported, skipped_with_reason.  Completed / unsupported jobs are skipped
  (idempotent); failed / timed_out / interrupted jobs are retried on --resume
  with a NEW attempt id and the same run id, resuming from checkpoints.
* OOM is logged as a failure; no silent change of batch size or precision.
* Scientific validity is separate from completion: a run that violates a
  claimed contract (ScientificInvalid) gets status 'invalid' (quarantined, its
  dependants skipped); a complete run whose claims could not all be checked
  gets validity 'unverified' in status.json.
* Provenance: every completed run writes provenance.json with the semantic
  code hash (code that determines results).  A completed / unsupported run
  produced by different result-determining code is 'stale': it is NOT reused
  and blocks its dependants until it is rerun (--rerun-stale archives the old
  directory under runs_archive/ and recomputes) or an explicit reuse is
  recorded (cop.cli accept-stale, written to reuse_accepted.jsonl).
* SIGINT/SIGTERM: the trainer checkpoints and the job is left 'pending'
  (interrupted) so --resume continues it.
* A wall-time limit per job sets the interrupt flag; the job checkpoints and is
  recorded as 'timed_out'.
"""
from __future__ import annotations

import os
import socket
import threading
import time
import traceback
import uuid
from pathlib import Path
from typing import Optional

import torch

from ..config import run_id as make_run_id, CODE_VERSION
from ..env import environment_hash
from ..experiments.context import RunContext, Unsupported, ScientificInvalid, StaleParent, reuse_accepted
from ..utils import (configure_torch, FileLock, INTERRUPT, GracefulInterrupt, atomic_write_json, read_json,
                     read_jsonl, code_hash, stable_hash, semantic_code_hash, append_jsonl)

BLOCKING = ("failed", "unsupported", "timed_out", "invalid", "stale")


def status_of(results_root: Path, rid: str) -> dict:
    p = Path(results_root) / "runs" / rid / "status.json"
    if not p.exists():
        return {"status": "pending"}
    try:
        return read_json(p)
    except Exception:
        return {"status": "unknown"}


def set_status(run_dir: Path, status: str, **kw) -> None:
    atomic_write_json(run_dir / "status.json", {"status": status, "time": time.time(), **kw})


def provenance_ok(run_dir: Path, sem_hash: str) -> bool:
    p = Path(run_dir) / "provenance.json"
    if not p.exists():
        return False
    return read_json(p).get("semantic_hash") == sem_hash or reuse_accepted(run_dir, sem_hash)


def effective_status(results_root: Path, rid: str, sem_hash: str) -> str:
    """Status on disk, except that a complete / unsupported run produced by
    different result-determining code is reported as 'stale'."""
    rec = status_of(results_root, rid)
    st = rec["status"]
    if st in ("complete", "unsupported") and not provenance_ok(Path(results_root) / "runs" / rid, sem_hash):
        return "stale"
    if st == "invalid" and rec.get("semantic_hash") != sem_hash:
        return "stale"          # quarantined by different code: recompute (--rerun-stale) before trusting either way
    return st


def archive_run(results_root: Path, rid: str, tag: str) -> Path:
    src = Path(results_root) / "runs" / rid
    dst = Path(results_root) / "runs_archive" / f"{rid}__{tag}__{time.strftime('%Y%m%d-%H%M%S')}"
    dst.parent.mkdir(parents=True, exist_ok=True)
    os.replace(src, dst)
    return dst


def dispatch(ctx: RunContext) -> dict:
    kind = ctx.cfg["kind"]
    if kind == "baseline":
        from ..experiments.trajectory import run_baseline
        return run_baseline(ctx)
    if kind == "trajectory":
        from ..experiments.trajectory import run_trajectory
        return run_trajectory(ctx)
    if kind == "deletion":
        from ..experiments.deletion import run_deletion_job
        return run_deletion_job(ctx)
    if kind == "repair":
        from ..experiments.repair import run_repair
        return run_repair(ctx)
    if kind == "dissipation":
        from ..experiments.dissipation import run_dissipation
        return run_dissipation(ctx)
    if kind == "control":
        from ..experiments.control import run_control
        return run_control(ctx)
    if kind == "finite":
        from ..finite import run_finite_ctx
        return run_finite_ctx(ctx)
    if kind == "cop":
        from ..cop_pegs.jobs import run_cop
        return run_cop(ctx)
    if kind == "continue":
        from ..experiments.continuation import run_continue
        return run_continue(ctx)
    if kind == "transplant":
        from ..experiments.transplant_job import run_transplant
        return run_transplant(ctx)
    raise Unsupported(f"unknown kind {kind}")


def run_job(cfg: dict, results_root: str | Path, exec_cfg: dict, resume: bool = True,
            worker: str = "w0", time_limit: Optional[float] = None, allow_code_change: bool = False,
            rerun_stale: bool = False) -> str:
    results_root = Path(results_root)
    rid = make_run_id(cfg)
    run_dir = results_root / "runs" / rid
    sem = semantic_code_hash()
    st = status_of(results_root, rid)
    if st["status"] == "invalid" and st.get("semantic_hash") != sem:
        if not rerun_stale:
            return "stale"
        archive_run(results_root, rid, f"invalid_{st.get('semantic_hash')}")
        st = {"status": "pending"}
    if st["status"] in ("complete", "unsupported"):
        if provenance_ok(run_dir, sem):
            return st["status"]
        if not rerun_stale:
            return "stale"
        old = read_json(run_dir / "provenance.json").get("semantic_hash", "none") if \
            (run_dir / "provenance.json").exists() else "none"
        archive_run(results_root, rid, f"stale_{old}")
        st = {"status": "pending"}
    if st["status"] in ("skipped_with_reason", "invalid"):
        return st["status"]
    if st["status"] in ("failed", "timed_out") and not resume:
        return st["status"]
    run_dir.mkdir(parents=True, exist_ok=True)
    lock = FileLock(run_dir / "lock", owner=f"{socket.gethostname()}:{os.getpid()}:{worker}")
    if not lock.acquire():
        return "locked"
    attempt = time.strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:6]
    ch = code_hash()
    prev_attempts = sorted((run_dir / "attempts").glob("*.json")) if (run_dir / "attempts").exists() else []
    if prev_attempts:
        last = read_json(prev_attempts[-1])
        changed = last.get("semantic_hash", last.get("code_hash")) not in (None, sem)
        if changed and any((run_dir / "ckpt").glob("*.pt")):
            if not allow_code_change:
                lock.release()
                set_status(run_dir, "failed", reason="result-determining code changed since the checkpoints were "
                                                     "written; rerun with --allow-code-change to continue (recorded "
                                                     "in the attempt) or delete the run dir")
                return "failed"
    env_h = environment_hash()
    rec = {"attempt_id": attempt, "run_id": rid, "worker": worker, "host": socket.gethostname(), "pid": os.getpid(),
           "exec": exec_cfg, "code_hash": ch, "semantic_hash": sem, "code_version": CODE_VERSION,
           "environment_hash": env_h, "allow_code_change": bool(allow_code_change),
           "start": time.time(), "resumed_from_checkpoints": sorted(p.name for p in (run_dir / "ckpt").glob("*.pt"))
           if (run_dir / "ckpt").exists() else []}
    atomic_write_json(run_dir / "attempts" / f"{attempt}.json", rec)
    set_status(run_dir, "running", attempt_id=attempt, worker=worker)
    timer = None
    timed_out = {"flag": False}
    if time_limit:
        def _expire():
            timed_out["flag"] = True
            INTERRUPT["flag"] = True
        timer = threading.Timer(time_limit, _expire)
        timer.daemon = True
        timer.start()
    status = "failed"
    try:
        numerics = configure_torch(exec_cfg)
        if str(exec_cfg.get("device", "cpu")).startswith("cuda"):
            torch.cuda.reset_peak_memory_stats()
        ctx = RunContext(cfg, results_root, {**exec_cfg, "_semantic_hash": sem}, attempt, ch, env_h)
        t0 = time.time()
        out = dispatch(ctx)
        rec.update({"end": time.time(), "elapsed_seconds": time.time() - t0, "peak_memory_bytes": ctx.peak_mem(),
                    "status": "complete", "validity": ctx.validity, "work": ctx.work})
        ctx.summary({"run_id": rid, "kind": cfg["kind"], "wp": cfg.get("wp"), "block": cfg.get("block"),
                     "result": out, "elapsed_seconds": rec["elapsed_seconds"], "peak_memory_bytes": rec["peak_memory_bytes"],
                     "attempt_id": attempt, "validity": ctx.validity, "validity_reasons": ctx.validity_reasons,
                     "work": ctx.work})
        atomic_write_json(run_dir / "provenance.json", {"semantic_hash": sem, "code_hash": ch,
                                                        "code_version": CODE_VERSION, "attempt_id": attempt,
                                                        "numerics": numerics, "time": time.time()})
        status = "complete"
        set_status(run_dir, "complete", attempt_id=attempt, validity=ctx.validity,
                   validity_reasons=ctx.validity_reasons)
    except Unsupported as ex:
        status = "unsupported"
        rec.update({"end": time.time(), "status": status, "reason": str(ex)})
        atomic_write_json(run_dir / "provenance.json", {"semantic_hash": sem, "code_hash": ch,
                                                        "code_version": CODE_VERSION, "attempt_id": attempt,
                                                        "time": time.time()})
        set_status(run_dir, "unsupported", reason=str(ex), attempt_id=attempt)
    except ScientificInvalid as ex:
        status = "invalid"
        rec.update({"end": time.time(), "status": status, "reason": ex.reason})
        atomic_write_json(run_dir / "invalid.json", {"reason": ex.reason, "diagnostics": ex.diagnostics,
                                                     "attempt_id": attempt, "semantic_hash": sem})
        set_status(run_dir, "invalid", reason=ex.reason, attempt_id=attempt, semantic_hash=sem)
    except StaleParent as ex:
        status = "failed"
        rec.update({"end": time.time(), "status": status, "reason": f"stale parent: {ex}"})
        set_status(run_dir, "failed", reason=f"stale parent: {ex}", attempt_id=attempt)
    except KeyboardInterrupt as ex:
        status = "timed_out" if timed_out["flag"] else "pending"
        rec.update({"end": time.time(), "status": status, "reason": "wall-time limit" if timed_out["flag"] else
                    "interrupted (checkpointed; resume with --resume)"})
        set_status(run_dir, status, reason=rec["reason"], attempt_id=attempt)
    except torch.cuda.OutOfMemoryError as ex:
        status = "failed"
        rec.update({"end": time.time(), "status": status, "reason": "cuda_oom", "traceback": traceback.format_exc()})
        set_status(run_dir, "failed", reason="cuda_oom", attempt_id=attempt,
                   restart=f"python -m cop.cli run --manifest <manifest> --only {rid} --resume")
    except Exception as ex:
        status = "failed"
        rec.update({"end": time.time(), "status": status, "reason": repr(ex), "traceback": traceback.format_exc()})
        (run_dir / "attempts" / f"{attempt}.stderr.txt").write_text(traceback.format_exc())
        set_status(run_dir, "failed", reason=repr(ex), attempt_id=attempt,
                   restart=f"python -m cop.cli run --manifest <manifest> --only {rid} --resume")
    finally:
        if timer:
            timer.cancel()
        if not (status == "pending" and not timed_out["flag"]):
            INTERRUPT["flag"] = False   # keep a user interrupt set so the manifest loop stops too
        atomic_write_json(run_dir / "attempts" / f"{attempt}.json", rec)
        lock.release()
    return status


def run_manifest(manifest: str | Path, results_root: str | Path, exec_cfg: dict, resume: bool = True,
                 worker: str = "w0", only: Optional[list[str]] = None, kinds: Optional[list[str]] = None,
                 time_limit: Optional[float] = None, max_jobs: Optional[int] = None,
                 allow_code_change: bool = False, rerun_stale: bool = False, log=print) -> dict:
    entries = read_jsonl(manifest)
    if only:
        entries = [e for e in entries if e["run_id"] in set(only)]
    if kinds:
        entries = [e for e in entries if e["cfg"]["kind"] in kinds]
    results_root = Path(results_root)
    counts: dict[str, int] = {}
    n_run = 0
    INTERRUPT["flag"] = False
    sem = semantic_code_hash()
    est = lambda r: effective_status(results_root, r, sem)
    with GracefulInterrupt() as gi:
        progress = True
        while progress:
            progress = False
            for e in entries:
                if gi.flag:
                    INTERRUPT["flag"] = True
                rid = e["run_id"]
                st_rec = status_of(results_root, rid)
                st = est(rid)
                deps = e.get("deps", [])
                if st == "skipped_with_reason" and str(st_rec.get("reason", "")).startswith("prerequisite") and \
                        all(est(d) == "complete" for d in deps):
                    set_status(results_root / "runs" / rid, "pending", reason="prerequisites now complete")
                    st = "pending"
                if st == "stale" and not rerun_stale:
                    counts["stale"] = counts.get("stale", 0) + 1
                    continue
                if st in ("complete", "unsupported", "skipped_with_reason", "invalid"):
                    continue
                req = (e["cfg"].get("control") or {}).get("device")
                if req and not str(exec_cfg.get("device", "cpu")).startswith(req):
                    continue      # backend-specific control job: runs only on its own device
                if st in ("failed", "timed_out") and not resume:
                    continue
                deps = e.get("deps", [])
                dst = [est(d) for d in deps]
                if any(s == "stale" for s in dst):
                    continue          # a stale prerequisite blocks until it is rerun or its reuse is recorded
                if any(s in BLOCKING for s in dst):
                    rd = results_root / "runs" / rid
                    rd.mkdir(parents=True, exist_ok=True)
                    if not (rd / "config.json").exists():
                        atomic_write_json(rd / "config.json", e["cfg"])
                    set_status(rd, "skipped_with_reason", reason=f"prerequisite not complete: "
                               f"{[d for d, s in zip(deps, dst) if s != 'complete']}")
                    continue
                if any(s != "complete" for s in dst):
                    continue
                if gi.flag:
                    break
                log(f"[{worker}] run {rid} ({e['cfg']['kind']}, {e['cfg'].get('block')})")
                s = run_job(e["cfg"], results_root, exec_cfg, resume, worker, time_limit, allow_code_change,
                            rerun_stale)
                log(f"[{worker}]   -> {s}")
                counts[s] = counts.get(s, 0) + 1
                if s in ("complete", "unsupported"):
                    progress = True
                n_run += 1
                if gi.flag or INTERRUPT["flag"] or (max_jobs and n_run >= max_jobs):
                    progress = False
                    break
    return counts
