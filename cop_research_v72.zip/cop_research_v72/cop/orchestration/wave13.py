"""v13 manifests (audit of v12, Part D): the engineering re-pilot (wave 13) and the confirmation blocks (wave 14).

Both keep the project's question: where computation moves during expansion, when additions can be removed or
replaced and at what repair cost.  Final compact accuracy is one outcome among the mechanism records.

Common rules for every job built here
  * f0 is selected inside its own baseline run by a declared validation rule (train.select_candidates = K;
    lowest validation risk, ties to the earlier point).  Every descendant of a cell starts from that one selected
    state (tags.f0_stage / continue.start_stage = best_val), so paired arms share the full baseline checkpoint
    (model, optimizer, RNG and data streams).  The baseline's whole run is its cost.
  * every compact-phase job (continuations, dissipations, repairs, CoP chains over their endpoint segment)
    records BOTH its fixed-budget endpoint (endpoint.json) and its validation-selected endpoint
    (endpoint_best_val.json) over K declared candidates of its final compact phase.  Trajectories, cycles and
    locality jobs have no selector; the analysis never pairs a selected endpoint across unequal selection
    opportunities.
  * learning-rate tuning is offered to treated arms and to direct-training arms alike (base and 0.3x).
  * every entry carries 'info_access' (what each arm may see: group ids, labels for routing, a random
    partition, teachers, privileged targets) and 'budget' metadata (budget rule, removal / repair split, MAC
    matching, selection opportunities).

Wave 13 uses the discovery seed only (data / teacher / optimizer seed 0): smoke, debugging and protocol
development, never confirmation.  Wave 14 uses fresh draws: five data/teacher draws (101-105) with optimizer
seed 0, crossed with optimizer seeds 1 and 2 on draws 101 and 102, so optimizer-seed variation and
teacher/data-draw variation can be separated.
"""
from __future__ import annotations

from collections import defaultdict
from typing import Optional

from .manifest import MLP, teacher_data

K_SELECT = 8                    # declared validation-selection opportunities per compact phase
CONFIRM_DRAWS = [101, 102, 103, 104, 105]
# finite-peg recipes and learning rates carried into confirmation, set after wave 16 (30 October 2026): the
# strict fixed and adaptive ranges for treated and scratch, warm-up as the labelled relaxation control, scratch
# update- and compute-matched.  The straight-through margin variants are not carried: the probe found at most
# 1.4% of peg inputs clipped by rounding, and the margin did not remove the 1-bit clipping
CONFIRM_FINITE_RECIPES = ("fixed", "ema", "warmup")
CONFIRM_TREATED_RECIPES = ("fixed", "ema")
CONFIRM_SCRATCH_PANELS = ("updates", "compute")          # v17: update- and compute-matched scratch
CONFIRM_LR_FACTORS = (1.0, 0.3)
# v17: the fixed-vs-redrawn partition contrast on the primary draws, crossed with partition seeds
CONFIRM_PARTITION_SEEDS = (None, 1, 2)
CONFIRM_SEEDED_PARTITION_MODES = ("fixed_random_matched", "redrawn_random_matched")
CONFIRM_CROSSED = {101: [1, 2], 102: [1, 2]}


def info_access(cfg: dict) -> dict:
    """What information an arm's training may use (read from its resolved config)."""
    t, g = cfg.get("train") or {}, cfg.get("growth") or {}
    spec = g.get("topology") == "specialized" and g.get("specialize") in ("class_halves", "class_halves_oracle")
    sp = g.get("spec_partition", "auto") if spec else None
    cc = cfg.get("continue") or {}
    return {"group_ids_for_routing": bool(spec and sp in ("group", "auto") and cfg["data"]["name"] == "shortcut"),
            "group_ids_for_sampling": t.get("sampler") == "group_balanced",
            "labels_for_routing": bool(spec and sp == "observed_label"),
            "random_partition_for_routing": bool(spec and sp in ("random_matched", "redrawn_random", "cyclic_blocks",
                                                                 "matched_quota")),
            "example_identity_masks": ("example-tied dropout: fixed random units per training example in training, "
                                       "generalization units only at evaluation" if cc.get("arm") ==
                                       "example_tied_dropout" else None),
            "partition_membership": (_membership_label(sp, g) if spec else None),
            "partition_masks_control": (("gradients only (the forward route is unchanged)"
                                         if g.get("spec_mask_route", "gradient") != "forward" else
                                         "forward and gradient (a branch's output is zero in training for the "
                                         "examples not assigned to it; evaluation unmasked)") if spec else None),
            "clean_labels": bool(spec and g.get("specialize") == "class_halves_oracle"),
            "teacher_targets": t.get("target") == "teacher_star",
            "distillation_teacher": cc.get("arm") in ("distill", "self_distill"),
            "group_ids_at_inference": False,
            # v43: train.freeze_inputs uses the data's known feature layout (which input column is the shortcut):
            # privileged knowledge of the generator, not per-example group labels.  Disclosed for expanded and
            # compact arms alike.  It holds that column's first-layer weights; other layers, biases and additions
            # can still change the network's shortcut sensitivity
            "privileged_feature_layout": ("the shortcut input column's first-layer weights are held at their "
                                          "start values" + (" for a frozen prefix of the segments"
                                                            if cc.get("freeze_segments") else "")
                                          if t.get("freeze_inputs", "none") != "none" else None),
            # v44: train.freeze_backbone holds backbone layers 2..K at their start values (no data knowledge used)
            "backbone_hold": (("backbone layers after the first held at their start values" +
                               (" for a frozen prefix of the segments" if cc.get("freeze_segments") else ""))
                              if t.get("freeze_backbone", "none") != "none" else None),
            "selection_partition": t.get("select_partition", "val"),
            "selection_opportunities": int(t.get("select_candidates", 0)) if _has_selector(cfg) else 0}


def _membership_label(sp, g: dict) -> str:
    if sp == "redrawn_random":
        return "redrawn every batch"
    if sp == "all_examples":
        return "all examples"
    if sp == "matched_quota":
        sq = g.get("spec_quota") or {}
        return (f"per appearance: every example gets the same integer branch-a quota per round (fraction "
                f"{sq.get('fraction')}) on the replayed minibatch stream; b-run length {sq.get('b_run')} "
                "(0 = one run)")
    if sp == "cyclic_blocks":
        return (f"cyclic: every example alternates between the branches with period {g.get('spec_block_period')} "
                "updates, equal exposure per example, uniformly spread phases")
    ra = g.get("spec_reassign") or {}
    if sp == "random_matched" and ra.get("mode", "none") != "none":
        return (f"fixed per example, reassigned by schedule {ra['mode']} (start {ra.get('start')}, period "
                f"{ra.get('period')}, fraction {ra.get('fraction')} of the smaller side)")
    return "fixed per example"


def _has_selector(cfg: dict) -> bool:
    k = cfg["kind"]
    if k in ("baseline", "continue", "dissipation", "repair"):
        return True
    return k == "cop" and (cfg.get("cop") or {}).get("task_kind") == "chain"


def budget_meta(cfg: dict) -> dict:
    k = cfg["kind"]
    t = cfg.get("train") or {}
    out = {"lr": t.get("lr"), "lr_schedule": t.get("lr_schedule", "constant"),
           "select_candidates": int(t.get("select_candidates", 0))}
    if k == "continue":
        cc = cfg["continue"]
        out.update({"budget_rule": cc["budget"], "budget_parent": cc.get("budget_parent"),
                    "adds_f0_budget": bool(cc.get("budget_add_f0")), "start": cc["start"],
                    "start_stage": cc["start_stage"], "reinit": bool(cc.get("reinit")),
                    "segments": list(cc.get("segments") or []), "arm": cc.get("arm")})
    elif k == "dissipation":
        dc = cfg["dissipation"]
        out.update({"removal_method": dc["method"], "removal_updates": dc["speed_updates"],
                    "repair_updates": None if dc.get("post_match_macs_of") else dc["post_updates"],
                    "mac_matched_to": dc.get("post_match_macs_of") or None,
                    "path_eval_points": dc["path_eval_points"], "early_eval": list(dc.get("early_eval") or []),
                    "rebuild": dc.get("rebuild"), "removal_masks": dc.get("removal_masks"),
                    "gate_schedule": dc.get("gate_schedule")})
    elif k == "cop":
        cc = cfg["cop"]
        out.update({"task_kind": cc["task_kind"], "global_updates": cc["global_updates"],
                    "mac_matched_to": cc.get("global_match_macs_of") or None,
                    "decoder_refit_updates": cc.get("decoder_refit_updates", 0)})
    elif k == "baseline":
        out["baseline_updates"] = t.get("baseline_updates")
    return out


class Cell:
    def __init__(self, name: str, data: dict, model: dict, ck: str = "post_act", train_over: Optional[dict] = None):
        self.name, self._data, self.model, self.ck = name, data, model, ck
        self.train_over = dict(train_over or {})

    def data(self, ds: int) -> dict:
        d = dict(self._data)
        d["data_seed"], d["teacher_seed"] = ds, ds
        return d


class W13:  # noqa: D101 (wave 13 / 14 manifest builder)
    def __init__(self, B, wave: int):
        self.B, self.W = B, wave
        if getattr(B, "variant_map", None) is None:
            B.variant_map = defaultdict(set)
        if getattr(B, "inapplicable", None) is None:
            B.inapplicable = []

    # ------------------------------------------------------------ plumbing
    def add(self, cfg: dict, block: str, deps) -> str:
        rid = self.B.add({**cfg, "wave": self.W, "block": block}, block, deps)
        e = self.B.entries[rid]
        e["info_access"] = info_access(e["cfg"])
        e["budget"] = budget_meta(e["cfg"])
        if (e["cfg"].get("design") or {}).get("variant"):
            self.B.variant_map[e["cfg"]["design"]["variant"]].add(block)
        return rid

    def na(self, var: str, cell: str, reason: str) -> None:
        self.B.inapplicable.append({"variant": var, "cell": cell, "reason": reason})

    def upr(self, cell: Cell) -> int:
        return self.B.upr(cell._data["name"])

    def train(self, cell: Cell, **over) -> dict:
        t = self.B.train(cell._data["name"], **{**cell.train_over, **over})
        t["select_candidates"] = K_SELECT
        return t

    role = ""                               # v31: confirmation | exploratory, stamped on every design

    def design(self, fam, var, arm, contrast, panel="", regime="T1") -> dict:
        d = {"family": fam, "variant": var, "arm": arm, "budget_panel": panel, "target_regime": regime,
             "contrast": contrast}
        if self.role:
            d["role"] = self.role
        return d

    def baseline(self, cell: Cell, ds: int, os_: int) -> str:
        return self.add({"kind": "baseline", "data": cell.data(ds), "model": cell.model, "train": self.train(cell),
                         "seeds": {"optimizer": os_}, "wp": ["V13"]}, "baselines_v13", [])

    def traj(self, cell, ds, os_, growth, block, train_over=None, design=None, wp=("V13",),
             seeds_over=None) -> tuple[str, dict]:
        base = self.baseline(cell, ds, os_)
        g = {"cut_kind": cell.ck, "rounds": 2, "updates_per_round": self.upr(cell), **growth}
        cfg = {"kind": "trajectory", "data": cell.data(ds), "model": cell.model,
               "train": self.train(cell, **(train_over or {})), "growth": g,
               "seeds": {"optimizer": os_, "insertion": os_, **(seeds_over or {})}, "parents": {"baseline": base},
               "tags": {"f0_stage": "best_val"}, "wp": list(wp)}
        if design:
            cfg["design"] = design
        rid = self.add(cfg, block, [base])
        return rid, self.B.entries[rid]["cfg"]

    def dissipation(self, traj, tcfg, sec, design, block, lr_factor=None, extra_parents=None, tags=None,
                    train_over=None) -> str:
        tr = dict(tcfg["train"])
        if lr_factor is not None:
            tr["lr"] = tr["lr"] * lr_factor
        if train_over:
            tr.update(train_over)           # v26: e.g. a learning-rate warmup at every removal phase start
        parents = {"trajectory": traj, **(extra_parents or {})}
        cfg = {"kind": "dissipation", "data": tcfg["data"], "model": tcfg["model"], "train": tr,
               "growth": tcfg["growth"], "seeds": tcfg["seeds"], "parents": parents,
               "dissipation": {"path_eval_points": 20, "save_path_checkpoints": True, "path_full_eval": True, **sec},
               "design": design, "wp": [design["family"]], **({"tags": tags} if tags else {})}
        return self.add(cfg, block, list(parents.values()))

    def cont(self, cell, ds, os_, base, treated, arm, sec, design, block, train_over=None,
             start_stage="best_val", seeds_over=None, extra_parents=None) -> str:
        parents = {"baseline": base, "treated": treated, **(extra_parents or {})}
        cfg = {"kind": "continue", "data": cell.data(ds), "model": cell.model,
               "train": self.train(cell, **(train_over or {})),
               "seeds": {"optimizer": os_, "insertion": os_, **(seeds_over or {})},
               "parents": parents,
               "continue": {"budget_parent": "treated", "start": "baseline", "start_stage": start_stage, **sec},
               "design": design, "wp": [design["family"]]}
        return self.add(cfg, block, list(parents.values()))

    def compact_controls(self, cell, ds, os_, base, treated, fam, var, contrast, block, lr, gb=True):
        """Strong compact controls from the same selected f0, budgets from the treated chain: plain at base and
        0.3x LR, LR restart, a cosine schedule over the control's own budget, equal compute, and (shortcut data)
        group-balanced sampling."""
        out = []
        for arm, sec, to, panel in (
                ("C1", {"budget": "parent_updates"}, {}, "updates"),
                ("C1_lr0.3", {"budget": "parent_updates"}, {"lr": lr * 0.3}, "updates"),
                ("C7_lr", {"budget": "parent_updates", "arm": "lr_restart", "segments": [1, 1],
                           "restart_warmup": max(1, self.upr(cell) // 20)}, {}, "updates"),
                ("C1_cosine", {"budget": "parent_updates"}, {"lr_schedule": "cosine"}, "updates"),
                ("C2", {"budget": "parent_compute"}, {}, "compute")):
            out.append(self.cont(cell, ds, os_, base, treated, arm, sec, self.design(fam, var, arm, contrast, panel),
                                 block, to))
        if gb:
            out.append(self.cont(cell, ds, os_, base, treated, "C1_group_balanced", {"budget": "parent_updates"},
                                 self.design(fam, var, "C1_group_balanced", contrast, "updates"), block,
                                 {"sampler": "group_balanced"}))
        return out

    def cop(self, cell, ds, os_, cop, peg, design, block, train_over=None, extra_parents=None) -> str:
        base = self.baseline(cell, ds, os_)
        upr = self.upr(cell)
        parents = {"baseline": base, **(extra_parents or {})}
        cfg = {"kind": "cop", "data": cell.data(ds), "model": cell.model, "train": self.train(cell, **(train_over or {})),
               "peg": {"anneal_updates": max(1, upr // 4), **peg},
               "cop": {"local_updates": upr // 2, "global_updates": upr, **cop},
               "seeds": {"optimizer": os_}, "parents": parents, "tags": {"f0_stage": "best_val"},
               "design": design, "wp": [design["family"]]}
        return self.add(cfg, block, list(parents.values()))

    def matched(self, cell, ds, os_, treated, fam, var, contrast, block, lr, cop_kind="chain", compute=True):
        """Direct training of the treated endpoint's architecture from scratch (M1 at base and 0.3x LR, M2 at
        equal compute), with the f0 budget added: the stronger direct comparator of audit C4 (1)."""
        base = self.baseline(cell, ds, os_)
        if cop_kind == "cycles":
            cfg = {"kind": "cop", "data": cell.data(ds), "model": cell.model, "train": self.train(cell),
                   "peg": self.B.entries[treated]["cfg"]["peg"],
                   "cop": {**self.B.entries[treated]["cfg"]["cop"], "task_kind": "baseline", "baseline": "direct_small"},
                   "seeds": {"optimizer": os_}, "parents": {"baseline": base, "cycles": treated},
                   "tags": {"f0_stage": "best_val"},
                   "design": self.design(fam, var, "M1", contrast, "updates"), "wp": [fam]}
            return [self.add(cfg, block, [base, treated])]
        out = []
        for arm, budget, to, ok in (("M1", "parent_updates", {}, True), ("M1_lr0.3", "parent_updates", {"lr": lr * 0.3}, True),
                                    ("M2", "parent_compute", {}, compute)):
            if not ok:
                continue
            parents = {"baseline": base, "treated": treated}
            cfg = {"kind": "continue", "data": cell.data(ds), "model": cell.model, "train": self.train(cell, **to),
                   "seeds": {"optimizer": os_, "insertion": os_}, "parents": parents,
                   "continue": {"start": "treated", "start_stage": "export", "reinit": True, "budget": budget,
                                "budget_parent": "treated", "budget_add_f0": True},
                   "design": self.design(fam, var, arm, contrast, "updates" if budget == "parent_updates" else "compute"),
                   "wp": [fam]}
            out.append(self.add(cfg, block, list(parents.values())))
        return out


class W15(W13):
    def __init__(self, B):
        super().__init__(B, 15)


class W16(W13):
    def __init__(self, B):
        super().__init__(B, 16)


# =============================================================================
# blocks (shared by wave 13 and wave 14; `reps` = list of (data draw, optimizer seed))
# =============================================================================

def block_x4(S: W13, reps, rhos=(0.7, 0.95)):
    """D1: group information x routing x removal protocol on the shortcut task."""
    blk = "V13_X4_information_routing_removal"
    for rho in rhos:
        cell = Cell(f"shortcut_rho{rho}", {"name": "shortcut", "n_train": 4096, "params": {"rho_train": rho}}, MLP(64))
        upr = S.upr(cell)
        R = int(round(1.5 * upr))
        g_short = max(1, int(round(0.1 * upr)))
        lr = S.B.train("shortcut")["lr"]
        expansions = (("parallel", {"topology": "parallel"}, {}),
                      ("specialized_group", {"topology": "specialized", "spec_partition": "group"}, {}),
                      ("specialized_group_gb", {"topology": "specialized", "spec_partition": "group"},
                       {"sampler": "group_balanced"}),
                      ("specialized_random_matched", {"topology": "specialized", "spec_partition": "random_matched"}, {}),
                      ("specialized_observed_label", {"topology": "specialized", "spec_partition": "observed_label"}, {}))
        for ds, os_ in reps:
            base = S.baseline(cell, ds, os_)
            for ename, growth, to in expansions:
                traj, tcfg = S.traj(cell, ds, os_, growth, blk, train_over=to)
                contrast = f"X4r|{cell.name}|{ename}"
                D = lambda arm, panel="updates": S.design("X4r", ename, arm, contrast, panel)
                ref = S.dissipation(traj, tcfg, {"method": "linear", "speed_updates": g_short, "post_updates": R - g_short},
                                    D("treated"), blk)
                S.dissipation(traj, tcfg, {"method": "abrupt", "speed_updates": 0, "post_updates": R},
                              D("removal_abrupt_repair"), blk)
                S.dissipation(traj, tcfg, {"method": "linear", "speed_updates": upr, "post_updates": R - upr},
                              D("removal_slow_repair_short"), blk)
                # the v9 protocol, kept as historical context only: its own contrast, so it is never paired as
                # a budget-matched comparator
                S.dissipation(traj, tcfg, {"method": "linear", "speed_updates": g_short,
                                           "post_updates": max(1, upr // 2)},
                              S.design("X4r", ename, "historical_short_total", f"{contrast}|historical_context",
                                       "updates"), blk)
                S.dissipation(traj, tcfg, {"method": "abrupt", "speed_updates": 0, "post_updates": 1,
                                           "post_match_macs_of": "mac_reference"}, D("removal_abrupt_mac_matched", "compute"),
                              blk, extra_parents={"mac_reference": ref})
                S.dissipation(traj, tcfg, {"method": "linear", "speed_updates": g_short, "post_updates": R - g_short},
                              D("treated_lr0.3"), blk, lr_factor=0.3)
                S.compact_controls(cell, ds, os_, base, ref, "X4r", ename, contrast, blk, lr, gb=True)
    S.na("X4r", "group_dro", "no group-DRO training rule is implemented; group-balanced sampling is the group-aware "
                             "compact comparator (it changes group exposure, not branch-specific gradients)")


FINITE_RECIPES = {
    # name: (train overrides, label)
    "fixed": ({}, "strict finite capacity, range calibrated once at the reset (v13 recipe)"),
    "ema": ({"quant_range": "ema"}, "strict finite capacity, train-only adaptive global range (EMA of quantiles)"),
    "warmup": (None, "capacity-relaxation history control: continuous for the first updates, then calibrated and "
                     "quantised (counted; NOT strict finite-capacity training)"),
    # v17: the same two strict recipes with the straight-through margin (inputs that rounding puts just outside
    # the range keep their gradient; the forward pass, hence the capacity, is unchanged)
    "fixed_m": ({"quant_ste_margin": 1e-3}, "strict finite capacity, fixed range, straight-through margin 1e-3"),
    "ema_m": ({"quant_range": "ema", "quant_ste_margin": 1e-3},
              "strict finite capacity, adaptive range, straight-through margin 1e-3"),
}
TREATED_RECIPE_SUFFIX = {"fixed": "", "ema": "_ema", "fixed_m": "_m", "ema_m": "_ema_m"}


def finite_recipe_arms(S: W13, cell, ds, os_, treated_by_recipe: dict, fam, var, contrast, block, lr,
                       recipes=("fixed", "ema", "warmup"), lr_factors=(1.0, 0.3, 0.1), panels=("updates",)) -> dict:
    """v15 (review item 5): direct scratch training of the treated endpoint architecture under each finite-peg
    recipe and each declared learning rate (the same rates as the treated arms).  Budget panels: updates (M1) =
    treated chain + f0 updates; compute (M2, v17) = treated chain + f0 training MACs, so the scratch arm gets the
    whole treated procedure's computation."""
    base = S.baseline(cell, ds, os_)
    upr = S.upr(cell)
    treated = treated_by_recipe["fixed"]
    ids = {}
    for panel in panels:
        prefix, budget = {"updates": ("M1", "parent_updates"), "compute": ("M2", "parent_compute")}[panel]
        for rec in recipes:
            if panel == "compute" and rec == "warmup":
                continue                        # the relaxation control stays update-matched only
            over, _ = FINITE_RECIPES[rec]
            if over is None:
                over = {"quant_warmup_updates": max(1, upr // 2)}
            for f in lr_factors:
                arm = f"{prefix}_{rec}" + ("" if f == 1.0 else f"_lr{f}")
                parents = {"baseline": base, "treated": treated}
                cfg = {"kind": "continue", "data": cell.data(ds), "model": cell.model,
                       "train": S.train(cell, lr=lr * f, **over),
                       "seeds": {"optimizer": os_, "insertion": os_}, "parents": parents,
                       "continue": {"start": "treated", "start_stage": "export", "reinit": True, "budget": budget,
                                    "budget_parent": "treated", "budget_add_f0": True},
                       "design": S.design(fam, var, arm, contrast, panel), "wp": [fam]}
                ids[arm] = S.add(cfg, block, list(parents.values()))
    return ids


def block_finite_recipes(S: W13, reps, cells=None, lr_factors=(1.0, 0.3, 0.1), recipes=("fixed", "ema", "warmup"),
                         blk="V15_finite_peg_recipes", treated_recipes=("fixed", "ema"), panels=("updates",)):
    """v15 control-development panel for finite pegs: the F07 bit cells and the M_E 2-bit cell.  Treated chains
    under each treated recipe (the same quantiser options and learning rates as the scratch arms); scratch under
    every recipe and budget panel.  Clipping, active messages, per-coordinate entropy, code drift, ranges and
    gradient norms are recorded at the start, end and selected checkpoint of every scratch arm, and at export and
    the selected checkpoint of every treated chain (v17)."""
    deep = Cell("teacher3_n2048_d6", teacher_data(3, 2048), MLP(64, depth=6))
    lq = Cell("later_query_tb1", {"name": "later_query", "n_train": 2048, "n_val": 512, "n_test": 1024,
                                  "params": {"n_bits": 12, "task_bits": 1}}, MLP(64, depth=6))
    cells = cells or ([(deep, f"bits{b}", {"dim": 1, "mode": "uniform", "bits": b}, "teacher") for b in (1, 4, 16)]
                      + [(lq, "uniform_d4_b2", {"dim": 4, "mode": "uniform", "bits": 2}, "later_query")])
    for ds, os_ in reps:
        for cell, tag, peg, bname in cells:
            lr = S.B.train(bname)["lr"]
            contrast = f"FQr|{cell.name}|{tag}"
            tb = {}
            for rec in treated_recipes:
                over_rec, _ = FINITE_RECIPES[rec]
                for f in lr_factors:
                    arm = "treated" + TREATED_RECIPE_SUFFIX[rec] + ("" if f == 1.0 else f"_lr{f}")
                    over = {"lr": lr * f, **over_rec}
                    t = S.cop(cell, ds, os_, {"task_kind": "chain", "n_pearls": 3}, peg,
                              S.design("FQr", tag, arm, contrast), blk, train_over=over)
                    if f == 1.0:
                        tb[rec] = t
            finite_recipe_arms(S, cell, ds, os_, tb, "FQr", tag, contrast, blk, lr, recipes, lr_factors, panels)


PARTITION_MODES = (("all_examples", {"spec_partition": "all_examples"}, False),
                   ("fixed_random_matched", {"spec_partition": "random_matched"}, True),
                   ("redrawn_random_matched", {"spec_partition": "redrawn_random"}, True),
                   ("fixed_random_half", {"spec_partition": "random_matched", "spec_random_fraction": 0.5}, True),
                   ("redrawn_random_half", {"spec_partition": "redrawn_random", "spec_random_fraction": 0.5}, True),
                   ("observed_label", {"spec_partition": "observed_label"}, False),
                   ("true_group", {"spec_partition": "group"}, False))


def block_partition_dynamics(S: W13, reps, rho=0.95, blk="V15_partition_dynamics", partition_seeds=(None,),
                             seeded_modes=None):
    """v15 (review Family 2): the same specialized branch graph and starting checkpoint with different gradient
    partitions: every example to both branches, a fixed random split, a split redrawn every batch (each at the
    matched share and at 0.5), observed labels and true groups; one removal protocol (treated) with the frozen-
    weight sweep at its start, plus the plain compact control.  v17: random modes in `seeded_modes` (default all
    random modes) also run at each explicit partition seed in `partition_seeds` (None = the default draw, which
    follows the insertion seed); a seeded run is a within-draw replication (replication key ..._part<p>), and
    its C1 control carries the same key so pairs stay within it.  Non-random modes run once."""
    cell = Cell(f"shortcut_rho{rho}", {"name": "shortcut", "n_train": 4096, "params": {"rho_train": rho}}, MLP(64))
    upr = S.upr(cell)
    R = int(round(1.5 * upr))
    g_short = max(1, int(round(0.1 * upr)))
    for ds, os_ in reps:
        base = S.baseline(cell, ds, os_)
        for name, gp, random_mode in PARTITION_MODES:
            pss = partition_seeds if (random_mode and (seeded_modes is None or name in seeded_modes)) else (None,)
            for ps in pss:
                so = {} if ps is None else {"partition": ps}
                traj, tcfg = S.traj(cell, ds, os_, {"topology": "specialized", **gp}, blk, seeds_over=so)
                contrast = f"P2|{cell.name}|{name}"
                ref = S.dissipation(traj, tcfg, {"method": "linear", "speed_updates": g_short,
                                                 "post_updates": R - g_short},
                                    S.design("P2", name, "treated", contrast), blk)
                S.cont(cell, ds, os_, base, ref, "C1", {"budget": "parent_updates"},
                       S.design("P2", name, "C1", contrast, "updates"), blk, seeds_over=so)


def wave15_control_development(B) -> None:
    """v15 control-development panel (EXPLORATORY, discovery draw 0 only): finite-peg scratch recipes, gradient-
    partition dynamics and the confirmation's locality cell, to choose the confirmation protocol.  Never
    confirmation evidence."""
    S = W15(B)
    reps = [(0, 0)]
    block_finite_recipes(S, reps)
    block_partition_dynamics(S, reps)
    # the three locality outcomes (task recovery, function agreement, transmitted-code agreement) first appear in
    # v15: one look at the confirmation's locality cell on the discovery draw before it is frozen
    block_locality(S, reps, widths=(4, 16), budgets=("2upr",))


def wave16_finite_followup(B) -> None:
    """v17 follow-up panel (EXPLORATORY, discovery draw 0 only), after the wave-15 review: the finite-peg recipes
    with the straight-through margin (fixed_m, ema_m) beside the v15 recipes, for treated and scratch alike, and
    compute-matched scratch arms (M2: treated chain + f0 training MACs) beside the update-matched ones (M1); the
    two learning rates carried into confirmation.  Chooses the confirmation's finite recipes; never confirmation
    evidence."""
    S = W16(B)
    block_finite_recipes(S, [(0, 0)], lr_factors=(1.0, 0.3), recipes=("fixed", "ema", "fixed_m", "ema_m", "warmup"),
                         treated_recipes=("fixed", "ema", "fixed_m", "ema_m"), panels=("updates", "compute"),
                         blk="V17_finite_followup")


class W17(W13):
    def __init__(self, B):
        super().__init__(B, 17)


MECH_REPS = [(0, 0), (201, 0), (202, 0)]          # discovery draw plus two draws used nowhere else
SWAP_PLAYERS = ["spec/r1/a", "spec/r1/b", "spec/r2/a", "spec/r2/b"]   # v20: the four disjoint branch players
SWAP_SLOT_SETS = {"all": list(SWAP_PLAYERS), "r1_pair": ["spec/r1/a", "spec/r1/b"], "r2_pair": ["spec/r2/a", "spec/r2/b"],
                  "r1a": ["spec/r1/a"], "r1b": ["spec/r1/b"], "r2a": ["spec/r2/a"], "r2b": ["spec/r2/b"],
                  "side_a": ["spec/r1/a", "spec/r2/a"], "side_b": ["spec/r1/b", "spec/r2/b"]}


def block_swaps(S: W13, reps, rho=0.95, blk="V19_swaps"):
    """v19 swap experiments on the specialised branch graph (X4 shortcut cell).  Two lineages from the same f0
    and the same insertion state (same insertion seed; they differ only in the gradient partition): a FIXED
    random 95/5 split and a split REDRAWN every batch.  Each trajectory also saves the middle of round 2.
      ages        removal from the state right after the round-2 insertion, from mid round 2 and from the end
                  (co-adaptation duration), same removal protocol
      ancestral   end backbone + implants from right after the round-2 insertion, and the reverse
      cross       end of one lineage + implants of the other lineage (every implant, each round's pair, each
                  single branch, each side's pair), both directions
      controls    C1 (compact continuation, same updates) and C4 (distillation from the expanded model, same
                  updates: is the expanded model just a good teacher?); v20: matched compact controls C1_lr0.3,
                  C1_cosine and C7_opt (optimizer reset at the removal's phase boundary)
      v20         the end-state removal of each lineage first scores every one of the 16 subsets of the four branch
                  players copied from the other lineage (frozen; raw and with an affine interface alignment fitted
                  on training inputs); the fixed lineage also crosses gate schedule {anneal, hold} with removal
                  masks {released, retained} at the same transition and repair budgets; hybrids use the four
                  explicit players, never the parent container
    Every removal starts with the frozen-weight sweep (intact, gate scaling, every single deletion with its
    damage split by the training examples each branch was assigned, joint deletion) and then repairs with the
    same protocol, so immediate damage and repair are both measured on every start state."""
    cell = Cell(f"shortcut_rho{rho}", {"name": "shortcut", "n_train": 4096, "params": {"rho_train": rho}}, MLP(64))
    upr = S.upr(cell)
    R = int(round(1.5 * upr))
    g_short = max(1, int(round(0.1 * upr)))
    mid = upr + upr // 2
    rem = {"method": "linear", "speed_updates": g_short, "post_updates": R - g_short}
    for ds, os_ in reps:
        base = S.baseline(cell, ds, os_)
        lin = {}
        for name, gp in (("fixed", {"spec_partition": "random_matched"}),
                         ("redrawn", {"spec_partition": "redrawn_random"})):
            lin[name] = S.traj(cell, ds, os_, {"topology": "specialized", **gp}, blk,
                               train_over={"snapshot_at": [mid]})
        for name, (traj, tcfg) in lin.items():
            contrast = f"SW|{cell.name}|{name}"
            D = lambda arm, var: S.design("SW", var, arm, contrast)
            other = lin["redrawn" if name == "fixed" else "fixed"][0]
            ref = S.dissipation(traj, tcfg, {**rem, "swap_scan": {"donor_role": "scan_donor", "donor_stage": "final"}},
                                D("treated", f"{name}_age_end"), blk, extra_parents={"scan_donor": other})
            if name == "fixed":
                for gs, mk in (("hold", "released"), ("anneal", "retained"), ("hold", "retained")):
                    S.dissipation(traj, tcfg, {**rem, "gate_schedule": gs, "removal_masks": mk},
                                  D(f"crossing_{gs}_{mk}", f"{name}_crossing"), blk)
            S.dissipation(traj, tcfg, rem, D("age_mid", f"{name}_age_mid"), blk, tags={"parent_stage": f"snap_{mid}"})
            S.dissipation(traj, tcfg, rem, D("age_insert", f"{name}_age_insert"), blk,
                          tags={"parent_stage": "post_insert_r2"})
            S.dissipation(traj, tcfg, {**rem, "hybrid": {"donor_role": "donor", "donor_stage": "post_insert_r2",
                                                          "slots": list(SWAP_PLAYERS)}},
                          D("end_backbone_young_implants", f"{name}_ancestral"), blk, extra_parents={"donor": traj})
            S.dissipation(traj, tcfg, {**rem, "hybrid": {"donor_role": "donor", "donor_stage": "final",
                                                          "slots": list(SWAP_PLAYERS)}},
                          D("young_backbone_end_implants", f"{name}_ancestral"), blk, extra_parents={"donor": traj},
                          tags={"parent_stage": "post_insert_r2"})
            S.cont(cell, ds, os_, base, ref, "C1", {"budget": "parent_updates"}, D("C1", name), blk)
            lr = S.train(cell)["lr"]
            S.cont(cell, ds, os_, base, ref, "C1_lr0.3", {"budget": "parent_updates"}, D("C1_lr0.3", name), blk,
                   train_over={"lr": lr * 0.3})
            S.cont(cell, ds, os_, base, ref, "C1_cosine", {"budget": "parent_updates"}, D("C1_cosine", name), blk,
                   train_over={"lr_schedule": "cosine"})
            S.cont(cell, ds, os_, base, ref, "C7_opt", {"budget": "parent_updates", "arm": "opt_reset",
                                                        "segments": [g_short, R - g_short]}, D("C7_opt", name), blk)
            S.cont(cell, ds, os_, base, ref, "C4", {"budget": "parent_updates", "arm": "distill", "teacher": "teacher",
                                                    "teacher_stage": "final"}, D("C4", name), blk,
                   extra_parents={"teacher": traj})
        for recv, donor in (("fixed", "redrawn"), ("redrawn", "fixed")):
            traj, tcfg = lin[recv]
            for sname, slots in SWAP_SLOT_SETS.items():
                S.dissipation(traj, tcfg, {**rem, "hybrid": {"donor_role": "donor", "donor_stage": "final",
                                                              "slots": slots}},
                              S.design("SW", f"{recv}_receives_{donor}", f"swap_{sname}", f"SW|{cell.name}|{recv}"),
                              blk, extra_parents={"donor": lin[donor][0]})


REASSIGN_MODES = lambda U: {
    "fixed": None,
    "exchange_all_early": {"mode": "abrupt", "start": U // 2, "fraction": 1.0},
    "exchange_all_round2": {"mode": "abrupt", "start": U, "fraction": 1.0},
    "exchange_all_late": {"mode": "abrupt", "start": 2 * U - U // 4, "fraction": 1.0},
    "redraw_once_round2": {"mode": "abrupt_redraw", "start": U},
    "exchange_10pct_periodic": {"mode": "periodic", "start": 0, "period": max(1, U // 10), "fraction": 0.1},
    "exchange_ramp_round2": {"mode": "ramp", "start": U, "period": max(1, U // 10), "fraction": 0.5},
    "redraw_every_tenth_round": {"mode": "periodic_redraw", "start": 0, "period": max(1, U // 10)},
    "redraw_every_half_round": {"mode": "periodic_redraw", "start": 0, "period": max(1, U // 2)},
}


def block_reassignment(S: W13, reps, rho=0.95, blk="V19_reassignment"):
    """v19: change the responsibilities of a FIXED random 95/5 split during training (pair exchanges keep each
    branch's example count exact; redraws keep the share), from early to just before contraction, abruptly,
    gradually or periodically; the per-batch redrawn split is the other end of the dose-response.  Same removal
    protocol and frozen sweep (membership damage is measured against the split at the END of training) and a C1
    per arm."""
    cell = Cell(f"shortcut_rho{rho}", {"name": "shortcut", "n_train": 4096, "params": {"rho_train": rho}}, MLP(64))
    upr = S.upr(cell)
    R = int(round(1.5 * upr))
    g_short = max(1, int(round(0.1 * upr)))
    rem = {"method": "linear", "speed_updates": g_short, "post_updates": R - g_short}
    for ds, os_ in reps:
        base = S.baseline(cell, ds, os_)
        for name, ra in REASSIGN_MODES(upr).items():
            gp = {"topology": "specialized", "spec_partition": "random_matched", **({"spec_reassign": ra} if ra else {})}
            traj, tcfg = S.traj(cell, ds, os_, gp, blk)
            contrast = f"RA|{cell.name}|{name}"
            ref = S.dissipation(traj, tcfg, rem, S.design("RA", name, "treated", contrast), blk)
            S.cont(cell, ds, os_, base, ref, "C1", {"budget": "parent_updates"},
                   S.design("RA", name, "C1", contrast, "updates"), blk)


# v20 (review item 9): scale-aware recode grids.  Smoke exercises every code path (every relabelling, side and
# regime, a logistic and an MLP class, both validity controls) with tiny budgets; pilot and full grow the budgets
# and the paired restart sets.  The full grid per middle pearl: 2 regimes x 28 relabel / side conditions x
# classes x fit seeds (cop/cop_pegs/recode.plan_fits; audit_v5/tools/runtime_v13.recode_work prices it).
RECODE_BUDGETS = {
    "smoke": {"recode_updates": 20, "recode_eval_every": 5, "recode_relabel_seeds": 1, "recode_fit_seeds": 1,
              "recode_classes": ["linear", "mlp16"]},
    "pilot": {"recode_updates": 300, "recode_eval_every": 15, "recode_relabel_seeds": 1, "recode_fit_seeds": 2},
    "full": {"recode_updates": 1000, "recode_eval_every": 25, "recode_relabel_seeds": 2, "recode_fit_seeds": 2},
}
# v20 (review item 6): matched source recipes.  Every history (gradual CoP, abrupt calibrated interfaces,
# compute-matched scratch) is trained under BOTH quantiser-range recipes, so a difference between histories is
# never also a difference between the fixed and the adaptive range; each recipe is its own stratum (contrast).
RECODE_STRATA = ("fixed", "ema")


def block_recode(S: W13, reps, blk="V19_recode"):
    """v19 / v20 interface recoding on chains with uniform 4 x 2-bit pegs (8-bit messages, 4 pearls: two middle
    pearls), for three histories that end in the same architecture: the gradual CoP history, abruptly imposed
    calibrated interfaces, and compute-matched scratch training of that architecture.  v20: each history under
    the fixed and the adaptive (EMA) quantiser range (strata RC|<cell>|d4b2_<recipe>), the same learning rate,
    and the recode job reads the parent's FINAL checkpoint (its training endpoint, not a validation-selected
    one).  Does training through expansion leave codes that are harder for a small replacement to reproduce
    than codes of the same capacity learned otherwise, and does relabelling them change that?  An association
    across histories: their maps differ in support and source risk, which the recode table reports."""
    cells = [(Cell("later_query_tb1", {"name": "later_query", "n_train": 2048, "n_val": 512, "n_test": 1024,
                                       "params": {"n_bits": 12, "task_bits": 1}}, MLP(64, depth=6)), "later_query"),
             (Cell("teacher3_n2048_d6", teacher_data(3, 2048), MLP(64, depth=6)), "teacher")]
    peg = {"dim": 4, "mode": "uniform", "bits": 2}
    rb = RECODE_BUDGETS[S.B.scale if S.B.scale in RECODE_BUDGETS else "full"]
    for ds, os_ in reps:
        for cell, bname in cells:
            lr = S.B.train(bname)["lr"]
            chain = {"task_kind": "chain", "n_pearls": 4}
            for rec in RECODE_STRATA:
                over_rec, _ = FINITE_RECIPES[rec]
                var = f"d4b2_{rec}"
                contrast = f"RC|{cell.name}|{var}"
                t = S.cop(cell, ds, os_, chain, peg, S.design("RC", var, "treated", contrast), blk,
                          train_over=dict(over_rec))
                a = S.cop(cell, ds, os_, chain, {**peg, "anneal_updates": 1},
                          S.design("RC", var, "abrupt_calibrated_interfaces", contrast), blk, train_over=dict(over_rec))
                sc = finite_recipe_arms(S, cell, ds, os_, {"fixed": t}, "RC", var, contrast, blk, lr, recipes=(rec,),
                                        lr_factors=(1.0,), panels=("compute",))
                for arm, src in (("treated", t), ("abrupt_calibrated_interfaces", a), (f"M2_{rec}", sc[f"M2_{rec}"])):
                    S.cop(cell, ds, os_, {"task_kind": "recode", "n_pearls": 4, **rb}, peg,
                          S.design("RC", var, f"recode_{arm}", contrast), blk, extra_parents={"chain": src},
                          train_over=dict(over_rec))


def wave17_mechanism_panel(B) -> None:
    """v19 mechanism panel (EXPLORATORY; the discovery draw and draws 201 / 202, used nowhere else): swap
    experiments, gradual reassignment of branch responsibilities, interface recoding.  Never confirmation
    evidence."""
    S = W17(B)
    block_swaps(S, MECH_REPS)
    block_reassignment(S, MECH_REPS)
    block_recode(S, MECH_REPS)


class W18(W13):
    def __init__(self, B):
        super().__init__(B, 18)


# v22: the discovery-panel draws plus three fresh draws used nowhere else (fresh replication of the v20 leads)
V22_REPS = [(0, 0), (201, 0), (202, 0), (203, 0), (204, 0), (205, 0)]
EARLY_EVAL = [1, 2, 4, 8, 16, 32, 64, 128, 256]    # dense evaluation early in every repair phase
V22_PARTITION_SEEDS = (1, 2)                       # extra partition draws of the fixed / redrawn contrast


def _v22_setup(S: W13, rho=0.95):
    cell = Cell(f"shortcut_rho{rho}", {"name": "shortcut", "n_train": 4096, "params": {"rho_train": rho}}, MLP(64))
    U = S.upr(cell)
    R = int(round(1.5 * U))
    g_short = max(1, int(round(0.1 * U)))
    rem = {"method": "linear", "speed_updates": g_short, "post_updates": R - g_short, "early_eval": list(EARLY_EVAL)}
    return cell, U, R, g_short, rem


def persistence_periods(U: int) -> list[int]:
    """cycle lengths from one cycle over the whole 2-round run to the shortest cycle with a 95 / 5 split (19 + 1
    updates); periods under 20 cannot hold the share and are dropped (smoke scale)."""
    return sorted({T for T in (2 * U, U, U // 4, U // 20, 20) if T >= 20}, reverse=True)


def block_persistence(S: W13, reps, blk="V22_persistence") -> dict:
    """v22 / v23 (review of v20, experiment 1): EQUAL exposure, different persistence.  matched_quota arms: every
    example gets the same integer number of branch-a and branch-b appearances per growth round on the same
    replayed minibatch stream, ordered in one run, in runs of 8 or alternating (families 95 / 5 and 50 / 50).
    Historical references on the same draws (not exposure-matched): the fixed split (each example in ONE branch
    for the whole run), the per-batch redrawn split, the 10 % periodic exchange (the v20 lead, now on fresh
    draws), and fixed / redrawn half splits.  Same removal (with dense early repair evaluation) and one C1 per draw.  Returns
    {draw: {"fixed": (traj, cfg), "redrawn": (traj, cfg)}} for the backbone block."""
    cell, U, R, g_short, rem = _v22_setup(S)
    out = {}
    contrast = f"PE|{cell.name}"
    for ds, os_ in reps:
        base = S.baseline(cell, ds, os_)
        arms = {"fixed": {"spec_partition": "random_matched"},
                "redrawn_every_batch": {"spec_partition": "redrawn_random"},
                "exchange_10pct_periodic": {"spec_partition": "random_matched",
                                            "spec_reassign": REASSIGN_MODES(U)["exchange_10pct_periodic"]}}
        # v23: the matched-exposure contrast.  On the same replayed minibatch stream (same seeds), every example
        # gets identical integer branch-a / branch-b quotas per growth round in every arm of one family; only the
        # ORDER of its appearances differs (b-appearances in one run, in runs of 8, or alternating).  Two families:
        # 95 / 5 (the shortcut share; about 3 b-appearances per example and round, so only one-run vs alternating
        # is possible) and 50 / 50 (a wide range of run lengths).  References for the 50 / 50 family: a fixed and
        # a per-batch redrawn half split.  The global-clock cyclic schedules of the first v22 draft are dropped:
        # their exposure depended on when the sampler drew each example.
        for fam, f, runs in (("q95", 0.95, (0, 1)), ("q50", 0.5, (0, 8, 1))):
            for br in runs:
                nm = {0: "one_run", 1: "alternating"}.get(br, f"runs{br}")
                arms[f"{fam}_{nm}"] = {"spec_partition": "matched_quota", "spec_quota": {"fraction": f, "b_run": br}}
        arms["fixed_half"] = {"spec_partition": "random_matched", "spec_random_fraction": 0.5}
        arms["redrawn_half"] = {"spec_partition": "redrawn_random", "spec_random_fraction": 0.5}
        lin, ref = {}, None
        for name, gp in arms.items():
            traj, tcfg = S.traj(cell, ds, os_, {"topology": "specialized", **gp}, blk)
            r = S.dissipation(traj, tcfg, rem, S.design("PE", name, "treated", contrast), blk)
            if name == "fixed":
                ref = r
                lin["fixed"] = (traj, tcfg)
            if name == "redrawn_every_batch":
                lin["redrawn"] = (traj, tcfg)
        S.cont(cell, ds, os_, base, ref, "C1", {"budget": "parent_updates"},
               S.design("PE", "compact", "C1", contrast, "updates"), blk)
        # v22: compute-matched compact control (the fixed treatment's trajectory + removal training MACs)
        S.cont(cell, ds, os_, base, ref, "C2", {"budget": "parent_compute"},
               S.design("PE", "compact", "C2", contrast, "compute"), blk)
        # v22: the closest prior method, example-tied dropout (Maini et al. 2023), on the same compact network:
        # continued from f0 for the treated trajectory's updates, then its memorization neurons dropped (native
        # test-time function, recorded) and the same repair budget as the removal; and trained from scratch with
        # f0's updates added (the paper trains from scratch)
        etd = {"budget": "fixed", "arm": "example_tied_dropout", "repair_early_eval": list(EARLY_EVAL)}
        S.cont(cell, ds, os_, base, ref, "ETD_from_f0", {**etd, "segments": [2 * U, R]},
               S.design("PE", "etd", "ETD_from_f0", contrast, "updates"), blk)
        B0 = int(S.train(cell)["baseline_updates"])
        S.cont(cell, ds, os_, base, ref, "ETD_scratch", {**etd, "reinit": True, "inherit_state": False,
                                                         "segments": [B0 + 2 * U, R]},
               S.design("PE", "etd", "ETD_scratch", contrast, "updates"), blk)
        # v22: the fixed / redrawn contrast at two more partition draws per data draw (within-draw replications,
        # key ..._part<p>); C1 carries the same key so pairs stay within it
        for ps in V22_PARTITION_SEEDS:
            so = {"partition": ps}
            r_ps = None
            for name in ("fixed", "redrawn_every_batch"):
                traj, tcfg = S.traj(cell, ds, os_, {"topology": "specialized", **arms[name]}, blk, seeds_over=so)
                r_ = S.dissipation(traj, tcfg, rem, S.design("PE", name, "treated", contrast), blk)
                r_ps = r_ if name == "fixed" else r_ps
            S.cont(cell, ds, os_, base, r_ps, "C1", {"budget": "parent_updates"},
                   S.design("PE", "compact", "C1", contrast, "updates"), blk, seeds_over=so)
        out[(ds, os_)] = lin
    return out


def block_backbone(S: W13, lineages: dict, blk="V22_backbone"):
    """v22 (review of v20, experiment 2): where does the benefit live?  Start states rebuilt from parts of the
    fixed and redrawn lineages at their end, all with the same removal and dense early repair evaluation:
      pristine            the untouched f0 backbone with every addition at its insertion state: the same final
                          graph, still function-preserving, no intervening training (checked = f0)
      f0_trained_branches the untouched f0 backbone with the lineage's trained branches
      trained_fresh       the lineage's trained backbone with every branch reset to its insertion state
    The plain removal of each lineage (block V22_persistence, same trajectory and protocol) is the reference.
    The pristine state is identical for both lineages (same f0 and insertion seed), so it runs once per draw."""
    cell, U, R, g_short, rem = _v22_setup(S)
    contrast = f"BB|{cell.name}"
    for _, lin in lineages.items():
        traj, tcfg = lin["fixed"]
        S.dissipation(traj, tcfg, {**rem, "rebuild": {"backbone": "f0", "implants": "fresh"}},
                      S.design("BB", "pristine", "f0_backbone_fresh_implants", contrast), blk)
        for name, (traj, tcfg) in lin.items():
            S.dissipation(traj, tcfg, {**rem, "rebuild": {"backbone": "f0", "implants": "receiver"}},
                          S.design("BB", name, "f0_backbone_trained_branches", contrast), blk)
            S.dissipation(traj, tcfg, {**rem, "rebuild": {"backbone": "receiver", "implants": "fresh"}},
                          S.design("BB", name, "trained_backbone_fresh_branches", contrast), blk)


def wave18_v22_panel(B) -> None:
    """v22 panel (EXPLORATORY): exposure-matched persistence and backbone / branch rebuilds, on the discovery
    draws and three fresh draws.  Never confirmation evidence."""
    S = W18(B)
    lin = block_persistence(S, V22_REPS)
    block_backbone(S, lin)


# =============================================================================
# v25 panel (wave 19, EXPLORATORY)
# =============================================================================

class W19(W13):
    def __init__(self, B):
        super().__init__(B, 19)


V25_REPS = list(V22_REPS)                              # discovery draws 0, 201, 202 and draws 203, 204, 205
V25_OPT_REPS = [(0, 1), (203, 1), (204, 1)]            # fresh optimizer / initialisation seeds (f0 retrained too)
V25_NOISE_LEVELS = (0.1, 0.3)
V25_NOISE_REPS = [(0, 0), (201, 0), (203, 0)]
V25_WIDTHS = (8, 128)                                  # branch hidden width (the panel's default is 32)
V25_WIDTH_REPS = [(0, 0), (203, 0), (204, 0)]
V25_TASK2_REPS = [(0, 0), (201, 0), (203, 0)]
V25_SCOPES = ("readout", "top2", "full")


def v25_shortcut_cell(noise: float = 0.0) -> Cell:
    d = {"name": "shortcut", "n_train": 4096, "params": {"rho_train": 0.95}}
    if noise:
        d["label_noise"] = float(noise)
    return Cell("shortcut_rho0.95" + (f"_noise{noise}" if noise else ""), d, MLP(64))


def v25_covertype_cell() -> Cell:
    """the second task: real tabular data (54 features, 7 classes), the same training-set size and network as the
    shortcut cell; smaller evaluation splits than the dataset default (5000 val, 20000 test)."""
    return Cell("covertype_n4096", {"name": "covertype", "n_train": 4096,
                                    "params": {"n_val": 5000, "n_test": 20000}}, MLP(64))


def _v25_protocol(S: W13, cell: Cell) -> tuple:
    """the v24 removal protocol on any cell: linear gate anneal over 0.1 U, repair to 1.5 U in total, dense early
    evaluation; and its branch-free counterpart: immediate (abrupt) deletion, then the same 1.5 U of repair."""
    U = S.upr(cell)
    R = int(round(1.5 * U))
    g = max(1, int(round(0.1 * U)))
    lin = {"method": "linear", "speed_updates": g, "post_updates": R - g, "early_eval": list(EARLY_EVAL)}
    abr = {"method": "abrupt", "post_updates": R, "early_eval": list(EARLY_EVAL)}
    return U, R, g, lin, abr


def v25_arms(frac=None) -> dict:
    """growth settings of the v25 arms.  frac: branch-a share of the fixed / redrawn splits (None = the training
    set's group-0 share, 95 / 5 on the shortcut data; the second task has no groups and passes 0.95)."""
    fx, rd = {"spec_partition": "random_matched"}, {"spec_partition": "redrawn_random"}
    if frac is not None:
        fx["spec_random_fraction"] = rd["spec_random_fraction"] = float(frac)
    return {"fixed": fx, "redrawn": rd,
            "q50_one_run": {"spec_partition": "matched_quota", "spec_quota": {"fraction": 0.5, "b_run": 0}},
            "q50_alternating": {"spec_partition": "matched_quota", "spec_quota": {"fraction": 0.5, "b_run": 1}},
            "fixed_forward": {**fx, "spec_mask_route": "forward"},
            "redrawn_forward": {**rd, "spec_mask_route": "forward"}}


def v25_lineages(S: W13, cell: Cell, reps, arm_names, controls, blk: str, frac=None, growth_over=None,
                 suffix: str = "") -> dict:
    """trajectories and their plain (linear) removals for the named arms, plus the draw's compact controls:
      C1           f0 continued for the fixed removal's measured updates (2 U + 1.5 U), one segment
      C1_phase     the same updates in the treated history's phases (U, U, 0.1 U, 1.4 U) with the optimizer state
                   carried where the history carries it (rounds 1 and 2) and reset where it resets (transition and
                   repair): the phase-matched compact control
      ETD_from_f0  example-tied dropout from f0 (2 U), its memorization units dropped, 1.5 U of repair
    Returns {(draw, opt): {arm: (trajectory run, its config)}}."""
    U, R, g, lin, _ = _v25_protocol(S, cell)
    arms = v25_arms(frac)
    contrast = f"X25|{cell.name}"
    out = {}
    for ds, os_ in reps:
        base = S.baseline(cell, ds, os_)
        got, ref = {}, None
        for name in arm_names:
            traj, tcfg = S.traj(cell, ds, os_, {"topology": "specialized", **arms[name], **(growth_over or {})}, blk)
            r = S.dissipation(traj, tcfg, lin, S.design("X25", name + suffix, "treated", contrast), blk)
            got[name] = (traj, tcfg)
            if name == "fixed":
                ref = r
        if ref is None:
            raise ValueError("v25_lineages: the compact controls need the fixed arm")
        if "C1" in controls:
            S.cont(cell, ds, os_, base, ref, "C1", {"budget": "parent_updates"},
                   S.design("X25", "compact", "C1", contrast, "updates"), blk)
        if "C1_phase" in controls:
            S.cont(cell, ds, os_, base, ref, "C1_phase", {"budget": "fixed", "segments": [U, U, g, R - g],
                                                          "segment_reset": [False, False, True, True]},
                   S.design("X25", "compact", "C1_phase", contrast, "updates"), blk)
        if "ETD_from_f0" in controls:
            S.cont(cell, ds, os_, base, ref, "ETD_from_f0",
                   {"budget": "fixed", "arm": "example_tied_dropout", "repair_early_eval": list(EARLY_EVAL),
                    "segments": [2 * U, R]},
                   S.design("X25", "etd", "ETD_from_f0", contrast, "updates"), blk)
        out[(ds, os_)] = got
    return out


def v25_rebuilds(S: W13, cell: Cell, lineages: dict, blk: str, starts=("fixed", "redrawn"),
                 scopes=V25_SCOPES, pristine: bool = True, linear_rebuilds=("trained_fresh",)) -> None:
    """repair scope and start-state rebuilds from IDENTICAL trained states (the lineages' end checkpoints):
      abrupt_<scope>     the branches deleted at once (the trained backbone alone, no transition), then 1.5 U of
                         repair in which only the scope's parameters learn (readout: the last layer; top2: the last
                         two; full: all)
      pristine           the same on f0 (rebuilt: f0 backbone with every addition at insertion, certified = f0):
                         what each scope does from the starting network
      linear_trained_fresh   the trained backbone with every branch reset to insertion, then the plain linear
                             removal (the fresh-branch transition)
      linear_f0_trained      f0's backbone with the trained branches, then the plain linear removal"""
    U, R, g, lin, abr = _v25_protocol(S, cell)
    contrast = f"X25|{cell.name}"
    for _, got in lineages.items():
        for name in starts:
            if name not in got:
                continue
            traj, tcfg = got[name]
            for sc in scopes:
                S.dissipation(traj, tcfg, {**abr, "repair_scope": sc},
                              S.design("X25", name, f"abrupt_{sc}", contrast), blk)
            if "trained_fresh" in linear_rebuilds:
                S.dissipation(traj, tcfg, {**lin, "rebuild": {"backbone": "receiver", "implants": "fresh"}},
                              S.design("X25", name, "linear_trained_fresh", contrast), blk)
            if "f0_trained" in linear_rebuilds:
                S.dissipation(traj, tcfg, {**lin, "rebuild": {"backbone": "f0", "implants": "receiver"}},
                              S.design("X25", name, "linear_f0_trained", contrast), blk)
        if pristine and "fixed" in got:
            traj, tcfg = got["fixed"]
            for sc in scopes:
                S.dissipation(traj, tcfg, {**abr, "repair_scope": sc, "rebuild": {"backbone": "f0", "implants": "fresh"}},
                              S.design("X25", "pristine", f"abrupt_{sc}", contrast), blk)


def wave19_v25_panel(B) -> None:
    """v25 panel (EXPLORATORY; never confirmation evidence).  The primary hypothesis from v24: a persistent
    example-to-branch assignment leaves a recoverable benefit in the backbone.  Blocks:
      V25_core     shortcut cell, 6 draws: fixed, redrawn, q50 one run / alternating (matched exposure), and the
                   forward-masked fixed / redrawn arms (memorization-sink style routing); C1, C1_phase, ETD
      V25_scope    repair scope (readout / top2 / full) after immediate deletion, from the fixed and redrawn
                   lineages and from f0; the fresh-branch transition beside it
      V25_optseed  the decisive contrasts at fresh optimizer / initialisation seeds (3 draws)
      V25_noise    label noise 0.1 and 0.3 (3 draws): fixed, redrawn, fixed_forward, C1, ETD
      V25_width    branch width 8 and 128 for fixed and redrawn (3 draws): dependence varied directly
      V25_task2    covertype (real data, 3 draws): the core arms, controls and rebuilds"""
    v25_blocks(W19(B))


def v25_blocks(S: W13) -> dict:
    """the v25 blocks on a builder (wave 19 in v25; reused unchanged by wave 20).  Returns the core lineages."""
    core = ("fixed", "redrawn", "q50_one_run", "q50_alternating", "fixed_forward", "redrawn_forward")
    sc = v25_shortcut_cell()
    lin = v25_lineages(S, sc, V25_REPS, core, ("C1", "C1_phase", "ETD_from_f0"), "V25_core")
    v25_rebuilds(S, sc, lin, "V25_scope")
    lo = v25_lineages(S, sc, V25_OPT_REPS, ("fixed", "redrawn", "q50_one_run", "q50_alternating"),
                      ("C1", "C1_phase"), "V25_optseed")
    v25_rebuilds(S, sc, lo, "V25_optseed", starts=("fixed",), scopes=(), pristine=False)
    for nz in V25_NOISE_LEVELS:
        v25_lineages(S, v25_shortcut_cell(nz), V25_NOISE_REPS, ("fixed", "redrawn", "fixed_forward"),
                     ("C1", "ETD_from_f0"), "V25_noise")
    for w in V25_WIDTHS:
        # compared with the same draws' V25_core arms and C1 (the compact network does not depend on branch width)
        _v25_width(S, sc, w)
    ct = v25_covertype_cell()
    lt = v25_lineages(S, ct, V25_TASK2_REPS, ("fixed", "redrawn", "q50_one_run", "q50_alternating", "fixed_forward"),
                      ("C1", "C1_phase", "ETD_from_f0"), "V25_task2", frac=0.95)
    v25_rebuilds(S, ct, lt, "V25_task2", starts=("fixed",), scopes=("readout", "full"), pristine=False,
                 linear_rebuilds=("trained_fresh", "f0_trained"))
    return lin


class W20(W13):
    def __init__(self, B):
        super().__init__(B, 20)


V26_DATA_REPS = [(0, 0), (203, 0), (204, 0)]
V26_REPAIR_SUBSETS = (256, 1024)


def v26_arms() -> dict:
    """v26 routes beside v25's: the parameter route (only the branch parameters are masked, every example's gradient
    reaches the upstream backbone through the branches), forward-masked quota arms, and an unmasked expansion
    (every example in both branches)."""
    a = v25_arms()
    out = {f"{k}_param": {**a[k], "spec_mask_route": "parameter"}
           for k in ("fixed", "redrawn", "q50_one_run", "q50_alternating")}
    out.update({f"{k}_forward": {**a[k], "spec_mask_route": "forward"} for k in ("q50_one_run", "q50_alternating")})
    out["unmasked"] = {"spec_partition": "all_examples"}
    return out


def v26_routes(S: W13, cell: Cell, reps, blk: str = "V26_route") -> None:
    """which gradient path carries the persistence effect: the parameter route crossed with persistence (fixed /
    redrawn, q50 one run / alternating), the forward route for the quota arms, and an unmasked expansion; same
    removal protocol, compared with the V25_core arms and controls of the same draws."""
    U, R, g, lin, _ = _v25_protocol(S, cell)
    contrast = f"X25|{cell.name}"
    for ds, os_ in reps:
        for name, gp in v26_arms().items():
            traj, tcfg = S.traj(cell, ds, os_, {"topology": "specialized", **gp}, blk)
            S.dissipation(traj, tcfg, lin, S.design("X25", name, "treated", contrast), blk)


def v26_contractions(S: W13, cell: Cell, lineages: dict, blk: str = "V26_contraction",
                     starts=("fixed", "redrawn", "q50_one_run")) -> None:
    """equal-budget contraction procedures from IDENTICAL trained states (the V25_core end checkpoints):
      linear_imitate   the linear removal and its repair trained to match the frozen expanded model's outputs
                       (dissipation.target = expanded) instead of the labels
      bypass           stochastic bypass during the transition (each addition kept with probability 0.5 per
                       batch, unscaled), then removal and the same repair
      linear_warmup    the plain linear removal with a learning-rate warmup of U / 20 updates at the start of each
                       removal phase (each starts with a fresh optimizer: is the post-removal error spike an
                       optimizer artefact?)"""
    U, R, g, lin, _ = _v25_protocol(S, cell)
    contrast = f"X25|{cell.name}"
    wu = max(1, U // 20)
    for _, got in lineages.items():
        for name in starts:
            if name not in got:
                continue
            traj, tcfg = got[name]
            S.dissipation(traj, tcfg, {**lin, "target": "expanded"},
                          S.design("X25", name, "linear_imitate", contrast), blk)
            S.dissipation(traj, tcfg, {**lin, "method": "stochastic_bypass", "bypass_keep": 0.5,
                                       "bypass_rescale": False},
                          S.design("X25", name, "bypass", contrast), blk)
            S.dissipation(traj, tcfg, lin, S.design("X25", name, "linear_warmup", contrast), blk,
                          train_over={"warmup": wu})


def v26_repair_data(S: W13, cell: Cell, lineages: dict, blk: str = "V26_repair_data") -> None:
    """how much repair DATA recovery needs: immediate deletion, then the same 1.5 U of repair updates drawn from
    a fixed random subset of 256 or 1024 of the 4096 training examples, readout-only or full; from the fixed
    and redrawn end states and from f0 (pristine rebuild)."""
    U, R, g, lin, abr = _v25_protocol(S, cell)
    contrast = f"X25|{cell.name}"
    for key, got in lineages.items():
        if key not in V26_DATA_REPS:
            continue
        for nsub in V26_REPAIR_SUBSETS:
            for sc in ("readout", "full"):
                sec = {**abr, "repair_scope": sc, "repair_subset": int(nsub)}
                for name in ("fixed", "redrawn"):
                    traj, tcfg = got[name]
                    S.dissipation(traj, tcfg, sec, S.design("X25", name, f"abrupt_{sc}_n{nsub}", contrast), blk)
                traj, tcfg = got["fixed"]
                S.dissipation(traj, tcfg, {**sec, "rebuild": {"backbone": "f0", "implants": "fresh"}},
                              S.design("X25", "pristine", f"abrupt_{sc}_n{nsub}", contrast), blk)


def wave20_v26_panel(B) -> None:
    """v26 panel (EXPLORATORY): every v25 block (wave 19's design, rebuilt under wave 20) plus
      V26_route        parameter-only masking x persistence, forward-masked quota arms, an unmasked expansion
      V26_contraction  imitation of the expanded model, stochastic bypass, and an LR warmup at each removal phase,
                       from the same fixed / redrawn / q50 one-run end states
      V26_repair_data  repair from 256 or 1024 training examples (readout or full) after immediate deletion"""
    S = W20(B)
    lin = v25_blocks(S)
    sc = v25_shortcut_cell()
    v26_routes(S, sc, V25_REPS)
    v26_contractions(S, sc, lin)
    v26_repair_data(S, sc, lin)


class W21(W13):
    def __init__(self, B):
        super().__init__(B, 21)


class W22(W13):
    """v41: the wave-22 builder (v39 used W21 and stamped wave 21 into the wave-22 entries)."""
    def __init__(self, B):
        super().__init__(B, 22)


V30_DRAWS = (301, 302, 303, 304, 305, 306)            # data draws never used before
V30_REPS = [(d, o) for o in (0, 1) for d in V30_DRAWS]  # balanced: every draw at both optimizer seeds
V30_MECH_REPS = [(d, 0) for d in V30_DRAWS]
V30_BOUNDARY_REPS = [(301, 0), (302, 0), (303, 0)]


def v33_snapshots(U: int) -> list[int]:
    """v33: trajectory checkpoints at these job updates (the ages of the additions), avoiding the round boundary U."""
    return sorted({u for u in (U // 8, U // 4, U // 2, 3 * U // 4, U + U // 8, U + U // 4, U + U // 2, U + 3 * U // 4)
                   if 0 < u < 2 * U and u != U})


def _v30_core(S: W13, cell: Cell, reps, blk: str, controls=("C1", "C2", "C1_phase"), snapshots: bool = False,
              c1_checkpoints: bool = False) -> dict:
    """fixed and redrawn trajectories with the plain linear removal and the draw's compact controls.  Returns
    {(draw, opt): {"fixed": (traj, cfg), "redrawn": (traj, cfg)}}.  snapshots: v33 age checkpoints.
    c1_checkpoints (v41): C1 also saves its states at the trajectory's boundaries, the age times and the removal's
    dense repair offsets (job-update times, so a C1 state and a trajectory / removal state share the clock)."""
    U, R, g, lin, _ = _v25_protocol(S, cell)
    arms = v25_arms()
    contrast = f"X25|{cell.name}"
    out = {}
    tov = {"snapshot_at": v33_snapshots(U)} if snapshots else None
    for ds, os_ in reps:
        base = S.baseline(cell, ds, os_)
        ref, got = None, {}
        for name in ("fixed", "redrawn"):
            traj, tcfg = S.traj(cell, ds, os_, {"topology": "specialized", **arms[name]}, blk, train_over=tov)
            got[name] = (traj, tcfg)
            r = S.dissipation(traj, tcfg, lin, S.design("X25", name, "treated", contrast), blk)
            ref = r if name == "fixed" else ref
        if "C1" in controls:
            c1x = {}
            if c1_checkpoints:
                # the linear removal's repair offsets (from 2U + g) and the keep forks' offsets (from 2U)
                c1x = {"eval_at": sorted({U, 2 * U, 2 * U + g, *[2 * U + g + k for k in EARLY_EVAL if k <= R - g],
                                          *[2 * U + k for k in EARLY_EVAL if k <= R],
                                          *(v33_snapshots(U) if snapshots else [])}),
                       "save_eval_checkpoints": True}
            S.cont(cell, ds, os_, base, ref, "C1", {"budget": "parent_updates", **c1x},
                   S.design("X25", "compact", "C1", contrast, "updates"), blk)
        if "C2" in controls:
            S.cont(cell, ds, os_, base, ref, "C2", {"budget": "parent_compute"},
                   S.design("X25", "compact", "C2", contrast, "compute"), blk)
        if "C1_phase" in controls:
            # v31: checkpoints at the treated history's boundaries and at the removal's dense repair offsets
            ea = sorted({U, 2 * U, 2 * U + g, *[2 * U + g + k for k in EARLY_EVAL if k <= R - g],
                         *(v33_snapshots(U) if snapshots else [])})      # v34: compact states at the age times
            S.cont(cell, ds, os_, base, ref, "C1_phase", {"budget": "fixed", "segments": [U, U, g, R - g],
                                                          "segment_reset": [False, False, True, True],
                                                          "eval_at": ea, "save_eval_checkpoints": True},
                   S.design("X25", "compact", "C1_phase", contrast, "updates"), blk)
        if "C1_first" in controls:
            S.cont(cell, ds, os_, base, ref, "C1_first", {"budget": "parent_updates", "trainable_scope": "first"},
                   S.design("X25", "compact", "C1_first", contrast, "updates"), blk)
        out[(ds, os_)] = got
    return out


V39_DRAWS = (307, 308, 309, 310, 311, 312)            # data draws never used before
V39_REPS = [(d, o) for o in (0, 1) for d in V39_DRAWS]


def wave22_v39_panel(B) -> None:
    """v39 panel (wave 22) after the v36 first-layer decomposition (the causal-input columns of the fixed
    expansion's first-layer change already help f0 at the expansion's end; the shortcut column hurts, less after
    the repair).  Data draws 307-312, never used, every draw at optimizer seeds 0 and 1.
      V39_core         fixed / redrawn trajectories, the plain linear removal and C1: the replication of the
                       first-layer transplant and of its decomposition, read by selective_reversal --decompose
                       --cross --scale-controls (the cross of the causal and shortcut changes from before and after
                       the repair, and the rescaling controls)
      V39_continuation from the IDENTICAL expanded end state of each fixed trajectory, the additions kept and
                       trained for the removal's 1.5 U, crossed: gradient masks retained (the parent's split) or
                       released, x the AdamW state carried from the trajectory or reset.  All four cells start a
                       MATCHED FRESH continuation stream (the removal jobs' minibatch stream, not the trajectory's
                       own sampler position), so retained + carried is 'the parent's weights and Adam state with
                       its masks on a fresh stream', not a literal uninterrupted continuation; released + reset is
                       v30's keep.  The redrawn trajectories get the released pair (no stable membership).
    v41: wave 22 is stamped wave 22 (v39 stamped 21); the trajectories save the v33 age snapshots and C1 saves its
    states on the same clock (both evaluation only)."""
    S = W22(B)
    cell = v25_shortcut_cell()
    U, R, g, lin, _ = _v25_protocol(S, cell)
    contrast = f"X25|{cell.name}"
    S.role = "confirmation"
    # v41: the expansion's age snapshots (training-neutral) and C1 states on the same clock, for the component traces
    core = _v30_core(S, cell, V39_REPS, "V39_core", controls=("C1",), snapshots=True, c1_checkpoints=True)
    S.role = "exploratory"
    kp = {"method": "keep", "post_updates": R, "early_eval": list(EARLY_EVAL), "save_path_checkpoints": True}
    for key, got in core.items():
        for name, (traj, tcfg) in got.items():
            for masks in (("retained", "released") if name == "fixed" else ("released",)):
                for opt in ("carry_from_parent", "reset_each_phase"):
                    arm = "keep" if (masks, opt) == ("released", "reset_each_phase") else \
                        f"keep_{'masks' if masks == 'retained' else 'released'}_{'carry' if opt != 'reset_each_phase' else 'reset'}"
                    S.dissipation(traj, tcfg, {**kp, "removal_masks": masks, "optimizer_policy": opt},
                                  S.design("X25", name, arm, contrast), "V39_continuation")


class W23(W13):
    def __init__(self, B):
        super().__init__(B, 23)


V42_DRAWS = (313, 314, 315, 316, 317, 318)            # data draws never used before
V42_REPS = [(d, o) for o in (0, 1) for d in V42_DRAWS]
EARLY_EVAL_V42 = EARLY_EVAL + [512, 1024, 2048]        # v42: the repair / keep interval v41 could not resolve


def wave23_v42_panel(B) -> None:
    """v42/v43 panel (wave 23).  Does the fixed expansion need its harmful shortcut-input change to build the useful
    causal-input change?  Data draws 313-318 (never used), every draw at optimizer seeds 0 and 1.  In this cell the
    shortcut feature is one unrotated input column, so train.freeze_inputs=shortcut holds the first layer's
    shortcut column at f0's values (no gradient; restored after every update).  The branches read the middle hidden
    layer, so later layers can still amplify f0's own shortcut use: the freeze removes the first-layer route only.
      fixed            the fixed trajectory, its linear removal (treated) and the released / reset keep fork
                       (keep): the within-wave reference and a replication of v39 / v41
      fixed_scfrozen   the fixed trajectory with the shortcut column frozen throughout the expansion; its linear
                       removal with the freeze lifted (treated) and kept (treated_frozen), and the keep fork with
                       the freeze lifted (keep)
      compact          f0 continued for the removal's 2U + R updates, one minibatch stream, a declared boundary at
                       2U: C1 (optimizer carried), C1_reset (one reset at 2U, the keep fork's schedule) and C1_phase
                       (resets at 2U and 2U + g, the removal's schedule)
      compact_scfrozen the same with the shortcut column frozen: C1 (carried, frozen throughout) and C1_phase
                       (frozen throughout, the removal's resets: the match of fixed_scfrozen / treated_frozen)
      compact_scfrozen_lift  C1_phase frozen for the first 2U and released at 2U (the removal's resets: the match
                       of fixed_scfrozen / treated)
    Every compact arm audits its fork point (model, optimizer by name, sampler, RNG and minibatch stream at each
    segment start) and saves its states on the trace clock; every job but f0 logs its update norms (path length).
    Every removal and keep phase also saves its states at +512, +1024 and +2048 (evaluation only); the
    trajectories save the v33 age snapshots."""
    S = W23(B)
    cell = v25_shortcut_cell()
    if int(((cell.data(V42_DRAWS[0]).get("params") or {}).get("input_rotation", 0)) or 0):
        raise ValueError("wave 23 needs unrotated inputs")
    U, R, g, lin, _ = _v25_protocol(S, cell)
    lin = {**lin, "early_eval": list(EARLY_EVAL_V42)}
    kp = {"method": "keep", "post_updates": R, "early_eval": list(EARLY_EVAL_V42), "save_path_checkpoints": True}
    arms = v25_arms()
    contrast = f"X25|{cell.name}"
    snaps = v33_snapshots(U)
    LOG = {"log_update_norms": True}
    FZ = {"freeze_inputs": "shortcut", **LOG}
    ea = sorted({U, 2 * U, 2 * U + g, *[2 * U + g + k for k in EARLY_EVAL_V42 if k <= R - g],
                 *[2 * U + k for k in EARLY_EVAL_V42 if k <= R], *snaps})
    two = {"budget": "fixed", "segments": [2 * U, R], "eval_at": ea, "save_eval_checkpoints": True, "fork_audit": True}
    four = {"budget": "fixed", "segments": [U, U, g, R - g], "segment_reset": [False, False, True, True],
            "eval_at": ea, "save_eval_checkpoints": True, "fork_audit": True}
    S.role = "exploratory"
    for ds, os_ in V42_REPS:
        base = S.baseline(cell, ds, os_)
        ref = None
        for var, tov in (("fixed", LOG), ("fixed_scfrozen", FZ)):
            traj, tcfg = S.traj(cell, ds, os_, {"topology": "specialized", **arms["fixed"]}, "V42_core",
                                train_over={"snapshot_at": snaps, **tov})
            r = S.dissipation(traj, tcfg, lin, S.design("X25", var, "treated", contrast), "V42_core",
                              train_over={"freeze_inputs": "none"})
            ref = r if var == "fixed" else ref
            S.dissipation(traj, tcfg, kp, S.design("X25", var, "keep", contrast), "V42_core",
                          train_over={"freeze_inputs": "none"})
            if var == "fixed_scfrozen":
                S.dissipation(traj, tcfg, lin, S.design("X25", var, "treated_frozen", contrast), "V42_core")
        for var, arm, cc_, tov in (
                ("compact", "C1", {**two, "segment_reset": [False, False]}, LOG),
                ("compact", "C1_reset", {**two, "segment_reset": [False, True]}, LOG),
                ("compact", "C1_phase", four, LOG),
                ("compact_scfrozen", "C1", {**two, "segment_reset": [False, False]}, FZ),
                ("compact_scfrozen", "C1_phase", four, FZ),
                ("compact_scfrozen_lift", "C1_phase", {**four, "freeze_segments": [True, True, False, False]}, FZ)):
            S.cont(cell, ds, os_, base, ref, arm, cc_, S.design("X25", var, arm, contrast, "updates"), "V42_core",
                   train_over=tov)


class W24(W13):
    def __init__(self, B):
        super().__init__(B, 24)


V44_DRAWS = (319, 320, 321, 322, 323, 324)            # data draws never used before
V44_REPS = [(d, o) for o in (0, 1) for d in V44_DRAWS]


def wave24_v44_panel(B) -> None:
    """v44 panel (wave 24).  Can the expansion's useful first-layer change be built with every later layer held at
    f0, and is the extraction rule (at the end of the expansion: delete the additions, keep the first layer,
    restore every other layer to f0) better than removal and repair, the compact controls and the rescaling
    controls?  Data draws 319-324 (never used), every draw at optimizer seeds 0 and 1.
      fixed            the fixed trajectory, its linear removal (treated) and the released / reset keep fork
                       (keep): the within-wave reference
      fixed_dsfrozen   the fixed trajectory with train.freeze_backbone=downstream: the additions and the first
                       layer train (its shortcut column too), layers 2 to 5 (the output head included) stay f0's;
                       its linear removal (treated) and keep fork (keep) with the hold lifted
      compact          f0 continued for 2U + R updates, one minibatch stream, a boundary at 2U: C1 (carried),
                       C1_reset (one reset at 2U, the keep fork's schedule), C1_phase (resets at 2U and 2U + g, the
                       removal's)
      compact_dsfrozen_lift  the same with layers 2 to 5 held for the first 2U and released at 2U: C1_phase (the
                       match of fixed_dsfrozen / treated) and C1_reset (the match of fixed_dsfrozen / keep)
    Every compact arm audits its fork point and saves its states on the trace clock; every job but f0 logs its
    update norms.  Every removal and keep phase also saves its states at +512, +1024 and +2048; the trajectories save
    the v33 age snapshots."""
    S = W24(B)
    cell = v25_shortcut_cell()
    U, R, g, lin, _ = _v25_protocol(S, cell)
    lin = {**lin, "early_eval": list(EARLY_EVAL_V42)}
    kp = {"method": "keep", "post_updates": R, "early_eval": list(EARLY_EVAL_V42), "save_path_checkpoints": True}
    arms = v25_arms()
    contrast = f"X25|{cell.name}"
    snaps = v33_snapshots(U)
    LOG = {"log_update_norms": True}
    DS = {"freeze_backbone": "downstream", **LOG}
    ea = sorted({U, 2 * U, 2 * U + g, *[2 * U + g + k for k in EARLY_EVAL_V42 if k <= R - g],
                 *[2 * U + k for k in EARLY_EVAL_V42 if k <= R], *snaps})
    two = {"budget": "fixed", "segments": [2 * U, R], "eval_at": ea, "save_eval_checkpoints": True, "fork_audit": True}
    four = {"budget": "fixed", "segments": [U, U, g, R - g], "segment_reset": [False, False, True, True],
            "eval_at": ea, "save_eval_checkpoints": True, "fork_audit": True}
    S.role = "exploratory"
    for ds, os_ in V44_REPS:
        base = S.baseline(cell, ds, os_)
        ref = None
        for var, tov in (("fixed", LOG), ("fixed_dsfrozen", DS)):
            traj, tcfg = S.traj(cell, ds, os_, {"topology": "specialized", **arms["fixed"]}, "V44_core",
                                train_over={"snapshot_at": snaps, **tov})
            r = S.dissipation(traj, tcfg, lin, S.design("X25", var, "treated", contrast), "V44_core",
                              train_over={"freeze_backbone": "none"})
            ref = r if var == "fixed" else ref
            S.dissipation(traj, tcfg, kp, S.design("X25", var, "keep", contrast), "V44_core",
                          train_over={"freeze_backbone": "none"})
        for var, arm, cc_, tov in (
                ("compact", "C1", {**two, "segment_reset": [False, False]}, LOG),
                ("compact", "C1_reset", {**two, "segment_reset": [False, True]}, LOG),
                ("compact", "C1_phase", four, LOG),
                ("compact_dsfrozen_lift", "C1_phase", {**four, "freeze_segments": [True, True, False, False]}, DS),
                ("compact_dsfrozen_lift", "C1_reset", {**two, "segment_reset": [False, True],
                                                       "freeze_segments": [True, False]}, DS)):
            S.cont(cell, ds, os_, base, ref, arm, cc_, S.design("X25", var, arm, contrast, "updates"), "V44_core",
                   train_over=tov)


class W25(W13):
    def __init__(self, B):
        super().__init__(B, 25)


V45_DRAWS = tuple(range(325, 337))                     # 12 data draws never used before (checked against every wave)
V45_REPS = [(d, o) for o in (0, 1) for d in V45_DRAWS]
# the freezing factorial: first-layer shortcut column held at f0 x backbone layers 2..5 held at f0
V45_CONDITIONS = {"A": {}, "B": {"freeze_inputs": "shortcut"}, "C": {"freeze_backbone": "downstream"},
                  "D": {"freeze_inputs": "shortcut", "freeze_backbone": "downstream"}}
V45_VARIANT = {"A": "A_free", "B": "B_scfrozen", "C": "C_dsfrozen", "D": "D_bothfrozen"}


def wave25_v45_panel(B) -> None:
    """v45 panel (wave 25): the freezing factorial on 12 unused data draws (325-336), optimizer seeds 0 and 1.
    Per draw and seed, one f0 and four expansions to 2U that differ only in what they hold at f0 (same data,
    minibatch stream, partition assignment, insertion initialization, optimizer settings and schedule):
      A_free        nothing held
      B_scfrozen    the first layer's shortcut column (train.freeze_inputs=shortcut): the v43 recipe
      C_dsfrozen    backbone layers 2 to 5, output head included (train.freeze_backbone=downstream)
      D_bothfrozen  both
    Each expansion's removal (treated) lifts both holds at 2U and runs the linear removal / repair schedule
    (secondary).  Each condition has its own compact control (compact_A .. compact_D, arm C1_phase): f0
    continued with the same holds for 2U, released at 2U, with the removal's optimizer resets at 2U and 2U + g.
    The extraction (the first layer kept, layers 2 to 5 restored to f0, additions deleted) is read at 2U on the
    expansion and on its compact control alike.  Every job but f0 audits its minibatch stream and logs update
    norms; the compact controls audit their fork points."""
    S = W25(B)
    cell = v25_shortcut_cell()
    U, R, g, lin, _ = _v25_protocol(S, cell)
    lin = {**lin, "early_eval": list(EARLY_EVAL_V42)}
    arms = v25_arms()
    contrast = f"X25|{cell.name}"
    snaps = v33_snapshots(U)
    AUD = {"log_update_norms": True, "audit_batches": True}
    LIFT = {"freeze_inputs": "none", "freeze_backbone": "none"}
    ea = sorted({U, 2 * U, 2 * U + g, *[2 * U + g + k for k in EARLY_EVAL_V42 if k <= R - g],
                 *[2 * U + k for k in EARLY_EVAL_V42 if k <= R], *snaps})
    four = {"budget": "fixed", "segments": [U, U, g, R - g], "segment_reset": [False, False, True, True],
            "eval_at": ea, "save_eval_checkpoints": True, "fork_audit": True}
    S.role = "exploratory"
    for ds, os_ in V45_REPS:
        base = S.baseline(cell, ds, os_)
        ref = None
        for k, hold in V45_CONDITIONS.items():
            traj, tcfg = S.traj(cell, ds, os_, {"topology": "specialized", **arms["fixed"]}, "V45_core",
                                train_over={"snapshot_at": snaps, **AUD, **hold})
            r = S.dissipation(traj, tcfg, lin, S.design("X25", V45_VARIANT[k], "treated", contrast), "V45_core",
                              train_over=LIFT)
            ref = r if k == "A" else ref
        for k, hold in V45_CONDITIONS.items():
            cc_ = {**four, **({"freeze_segments": [True, True, False, False]} if hold else {})}
            S.cont(cell, ds, os_, base, ref, "C1_phase", cc_,
                   S.design("X25", f"compact_{k}", "C1_phase", contrast, "updates"), "V45_core",
                   train_over={**AUD, **hold})


class W26(W13):
    def __init__(self, B):
        super().__init__(B, 26)


V53_DRAWS = tuple(range(337, 349))                     # 12 data draws never used before (checked against every wave)
V53_REPS = [(d, o) for o in (0, 1) for d in V53_DRAWS]
V53_HOLDS = {"A": {}, "B": {"freeze_inputs": "shortcut"}}
# the two crossed factors of the expansion.  routed: each addition gets the gradient of its own fixed random part of
# the examples (wave 25's arm); all: every addition gets every example's gradient (the same graph, masks all ones).
# relu: the additions as in wave 25; affine: their activation is the identity, so each is B(A h + a) + b
V53_ROUTES = {"routed": {"spec_partition": "random_matched"}, "all": {"spec_partition": "all_examples"}}
V53_ACTS = {"relu": {}, "affine": {"act": "identity"}}
V53_LR_FACTOR = 0.3                                    # the lower learning rate of the routed relu arm's repeat
V53_LONG = 2                                           # the compact controls train for V53_LONG x 2U updates


def v53_variants() -> dict:
    """the wave-26 expansion arms: name -> (hold key, growth settings, learning-rate factor)."""
    out = {}
    for h in V53_HOLDS:
        for rn, rg in V53_ROUTES.items():
            for an, ag in V53_ACTS.items():
                out[f"{h}_{rn}_{an}"] = (h, {**rg, **ag}, 1.0)
        out[f"{h}_routed_relu_lr{V53_LR_FACTOR}"] = (h, {**V53_ROUTES["routed"], **V53_ACTS["relu"]}, V53_LR_FACTOR)
    return out


def v53_compacts() -> dict:
    """the wave-26 compact controls: name -> (hold key, learning-rate factor)."""
    out = {}
    for h in V53_HOLDS:
        out[f"compact_{h}"] = (h, 1.0)
        out[f"compact_{h}_lr{V53_LR_FACTOR}"] = (h, V53_LR_FACTOR)
    return out


def wave26_v53_panel(B) -> None:
    """v53 panel (wave 26): what drives the expansion's drift (v52: the additions' output grows to many times the
    activations it joins, the training loss rises about twentyfold, and the first layer's causal columns grow)?
    12 unused data draws (337-348), optimizer seeds 0 and 1.  Per draw and seed, one f0 and ten expansions to 2U
    from it (same data, minibatch stream, insertion initialization and schedule), each with wave 25's linear removal
    (holds lifted; secondary):
      {A, B} x {routed, all} x {relu, affine}   A: nothing held; B: the first layer's shortcut column held at f0.
                                                routed: gradients routed by a fixed random split (wave 25's arms);
                                                all: every addition gets every example's gradient.
                                                relu: wave 25's additions; affine: identity activation
      {A, B}_routed_relu_lr0.3                  the wave-25 arms at 0.3 x the learning rate (expansion and removal)
    and four compact controls: f0 continued for 4U updates (twice the expansion's, at least its training compute:
    the analysis checks the counters) with the same hold throughout, one minibatch stream, the optimizer carried,
    states saved at the expansion's snapshot times, at 2U and every U / 2 after it: compact_A, compact_B and both at
    0.3 x the learning rate.  Every job but f0 audits its minibatch stream and logs update norms; the compact
    controls audit their fork points.  Nothing in cop/ outside the manifest builders changed: the semantics are
    v45's."""
    S = W26(B)
    cell = v25_shortcut_cell()
    U, R, g, lin, _ = _v25_protocol(S, cell)
    lin = {**lin, "early_eval": list(EARLY_EVAL_V42)}
    contrast = f"X25|{cell.name}"
    snaps = v33_snapshots(U)
    lr = S.B.train(cell._data["name"])["lr"]
    AUD = {"log_update_norms": True, "audit_batches": True}
    LIFT = {"freeze_inputs": "none", "freeze_backbone": "none"}
    n_long = V53_LONG * 2 * U
    ea = sorted({*snaps, U, *range(2 * U, n_long + 1, max(1, U // 2))})
    long_ = {"budget": "fixed", "segments": [2 * U, n_long - 2 * U], "segment_reset": [False, False],
             "eval_at": ea, "save_eval_checkpoints": True, "fork_audit": True}
    S.role = "exploratory"
    for ds, os_ in V53_REPS:
        base = S.baseline(cell, ds, os_)
        ref = None
        for name, (h, growth, f) in v53_variants().items():
            tov = {"snapshot_at": snaps, **AUD, **V53_HOLDS[h], **({"lr": lr * f} if f != 1.0 else {})}
            traj, tcfg = S.traj(cell, ds, os_, {"topology": "specialized", **growth}, "V53_core", train_over=tov)
            r = S.dissipation(traj, tcfg, lin, S.design("X25", name, "treated", contrast), "V53_core",
                              train_over=LIFT)
            ref = r if name == "A_routed_relu" else ref
        for name, (h, f) in v53_compacts().items():
            S.cont(cell, ds, os_, base, ref, "C1", long_, S.design("X25", name, "C1", contrast, "updates"),
                   "V53_core", train_over={**AUD, **V53_HOLDS[h], **({"lr": lr * f} if f != 1.0 else {})})


class W27(W13):
    def __init__(self, B):
        super().__init__(B, 27)


# v57 (wave 27): what about routing matters?  Three ways an example's gradient can meet the two additions of a round,
# on the same graph, split and forward value (growth.spec_mask_route, v26):
#   routed  the gradient route (waves 25 and 26): a masked example's gradient does not enter the addition at all, so
#           neither the addition's parameters nor the backbone below it see that example through that addition
#   param   the parameter route: only the additions' PARAMETERS are masked; every example's gradient still reaches
#           the backbone through both additions
#   all     no routing: every addition gets every example's gradient (masks of ones)
V57_ROUTES = {"routed": {"spec_partition": "random_matched"},
              "param": {"spec_partition": "random_matched", "spec_mask_route": "parameter"},
              "all": {"spec_partition": "all_examples"}}


def v57_variants() -> dict:
    """the wave-27 expansion arms (relu additions, the base learning rate): name -> (hold key, growth settings,
    learning-rate factor).  The routed and all arms are wave 26's arms of the same name."""
    return {f"{h}_{rn}_relu": (h, dict(rg), 1.0) for h in V53_HOLDS for rn, rg in V57_ROUTES.items()}


def v57_compacts() -> dict:
    """the wave-27 compact controls (wave 26's at the base learning rate): name -> (hold key, lr factor)."""
    return {f"compact_{h}": (h, 1.0) for h in V53_HOLDS}


def wave27_v57_panel(B) -> None:
    """v57 panel (wave 27): which part of routing produces the first-layer change?  Wave 26's draws and seeds
    (337-348, optimizer seeds 0 and 1) and its protocol.  Per draw and seed, one f0 and six expansions to 2U from
    it (same data, minibatch stream, insertion initialization, schedule and split), each with wave 25's linear
    removal (holds lifted; secondary):
      {A, B} x {routed, param, all}, relu additions   A: nothing held; B: the first layer's shortcut column held
    and two compact controls trained for 4U with the same hold (compact_A, compact_B).
    Only the param arms are new jobs (wave 27, block V57_core).  Every f0, the routed and all arms with their
    removals and the two compact controls are wave 26's own jobs, included here unchanged (same configuration,
    wave and block tags, hence the same run ids and checkpoint lineage): a panel folder may be seeded with those
    finished runs (scripts/seed_panel.py) or train them again.
    Nothing in cop/ outside the manifest builders changed: the semantics are v45's, the parameter route is v26's."""
    S26, S = W26(B), W27(B)
    cell = v25_shortcut_cell()
    U, R, g, lin, _ = _v25_protocol(S26, cell)
    lin = {**lin, "early_eval": list(EARLY_EVAL_V42)}
    contrast = f"X25|{cell.name}"
    snaps = v33_snapshots(U)
    AUD = {"log_update_norms": True, "audit_batches": True}
    LIFT = {"freeze_inputs": "none", "freeze_backbone": "none"}
    n_long = V53_LONG * 2 * U
    ea = sorted({*snaps, U, *range(2 * U, n_long + 1, max(1, U // 2))})
    long_ = {"budget": "fixed", "segments": [2 * U, n_long - 2 * U], "segment_reset": [False, False],
             "eval_at": ea, "save_eval_checkpoints": True, "fork_audit": True}
    S26.role = S.role = "exploratory"
    old = v53_variants()
    for ds, os_ in V53_REPS:
        base = S26.baseline(cell, ds, os_)
        ref = None
        for name, (h, growth, f) in v57_variants().items():
            own, blk = (S26, "V53_core") if name in old else (S, "V57_core")
            if name in old and old[name] != (h, growth, f):
                raise ValueError(f"wave 27: {name} is not wave 26's arm of that name")
            tov = {"snapshot_at": snaps, **AUD, **V53_HOLDS[h]}
            traj, tcfg = own.traj(cell, ds, os_, {"topology": "specialized", **growth}, blk, train_over=tov)
            r = own.dissipation(traj, tcfg, lin, own.design("X25", name, "treated", contrast), blk,
                                train_over=LIFT)
            ref = r if name == "A_routed_relu" else ref
        for name, (h, f) in v57_compacts().items():
            S26.cont(cell, ds, os_, base, ref, "C1", long_, S26.design("X25", name, "C1", contrast, "updates"),
                     "V53_core", train_over={**AUD, **V53_HOLDS[h]})


class W28(W13):
    def __init__(self, B):
        super().__init__(B, 28)


# v58 (wave 28): forks from identical functions.  At a saved state of a routed AFFINE expansion (wave 26's
# A_routed_affine and B_routed_affine trajectories), continuations of the same network to the expansion's end (2U),
# all with the same minibatch stream:
#   routed_reset    the additions trained on, the parent's gradient masks kept (routing continues), fresh optimizer
#   ordinary_reset  the additions trained on, masks released (every example's gradient reaches both additions)
#   frozen_reset    frozen affine scaffold, ordinary gradients: the additions' parameters frozen at their fork
#                   values, masks released.  The function equals the folded compact network's at the fork, but the
#                   backbone trains THROUGH the fixed map h -> A h + c between layer 2 and layer 3, so its updates
#                   are not the compact network's (with SGD layer 3's effective weight moves by -lr G A^T A, not
#                   -lr G; Adam differs too), and a singular A restricts the effective weights reachable
#   routed_carry    as routed_reset with the parent's optimizer state carried over (the reference for the reset)
# v59 adds (block V59_folded, method fold_unrouted, a semantic change):
#   folded_reset    the additions folded exactly into layer 3 and removed (the forward function is unchanged), then
#                   the compact network trained directly, every example's gradient reaching every weight, fresh
#                   optimizer.  The fold drops the additions' gradient-mask nodes, so this is NOT a function- and
#                   training-preserving edit: it keeps the function and replaces routed training by compact training
# Contrasts: routed vs ordinary (continued routing), ordinary vs frozen (continued learning of the additions), frozen
# vs folded (a fixed affine parametrisation kept or removed), routed carry vs routed reset (optimizer state).
# The fork points: snap_1000 (while the first-layer change is still developing) and snap_2500 (after most of it).
V58_PARENTS = ("A_routed_affine", "B_routed_affine")
V58_FORKS = ("snap_1000", "snap_2500")
V58_CONTS = {"routed_reset": {"method": "keep", "removal_masks": "retained", "optimizer_policy": "reset_each_phase"},
             "ordinary_reset": {"method": "keep", "removal_masks": "released",
                                "optimizer_policy": "reset_each_phase"},
             "frozen_reset": {"method": "keep", "removal_masks": "released", "optimizer_policy": "reset_each_phase",
                              "keep_frozen_implants": True},
             "routed_carry": {"method": "keep", "removal_masks": "retained",
                              "optimizer_policy": "carry_from_parent"}}
V59_CONTS = {"folded_reset": {"method": "fold_unrouted", "removal_masks": "released",
                              "optimizer_policy": "reset_each_phase"}}


def v58_forks(U: int) -> dict:
    """{fork stage: updates since f0} for the expansion length U per round (stages are snapshots of the trajectory)."""
    out = {f: int(f.split("_")[1]) for f in V58_FORKS}
    snaps = set(v33_snapshots(U))
    if not set(out.values()) <= snaps or max(out.values()) >= 2 * U:
        raise ValueError("wave 28: a fork point is not a saved snapshot before the expansion's end")
    return out


def wave28_v58_panel(B) -> None:
    """v58 panel (wave 28): does the backbone keep changing because of the ongoing routed additions, or does the state
    reached already carry the change?  Wave 26's draws and seeds (337-348 x {0, 1}); per f0, wave 26's routed affine
    trajectories (A: nothing held; B: the first layer's shortcut column held) and, from each at two saved states,
    the four continuations V58_CONTS to 2U (the same hold as the parent).  Every f0 and trajectory is wave 26's own
    job (same configuration and run id); the 384 continuations are wave 28's block V58_core (v58) and the 96
    folded continuations (V59_CONTS) its block V59_folded (v59: method fold_unrouted, new in cop/)."""
    S26, S = W26(B), W28(B)
    cell = v25_shortcut_cell()
    U, R, g, lin, _ = _v25_protocol(S26, cell)
    contrast = f"X28|{cell.name}"
    snaps = v33_snapshots(U)
    forks = v58_forks(U)
    AUD = {"log_update_norms": True, "audit_batches": True}
    S26.role = S.role = "exploratory"
    va = v53_variants()
    for ds, os_ in V53_REPS:
        S26.baseline(cell, ds, os_)
        for name in V58_PARENTS:
            h, growth, f = va[name]
            if f != 1.0 or growth.get("act") != "identity" or growth.get("spec_partition") != "random_matched":
                raise ValueError(f"wave 28: {name} is not a routed affine arm at the base learning rate")
            tov = {"snapshot_at": snaps, **AUD, **V53_HOLDS[h]}
            traj, tcfg = S26.traj(cell, ds, os_, {"topology": "specialized", **growth}, "V53_core", train_over=tov)
            for stage, u in forks.items():
                for cn, sec, blk in ([(c, s_, "V58_core") for c, s_ in V58_CONTS.items()]
                                     + [(c, s_, "V59_folded") for c, s_ in V59_CONTS.items()]):
                    S.dissipation(traj, tcfg, {**sec, "post_updates": 2 * U - u, "early_eval": [],
                                               "path_eval_points": 4},
                                  S.design("X28", f"{name}@{stage}", cn, contrast), blk,
                                  tags={"parent_stage": stage}, train_over=dict(V53_HOLDS[h]))


class W29(W13):
    def __init__(self, B):
        super().__init__(B, 29)


# v62 (wave 29): the v60 separation in a second setting.  Another network (width 128, six hidden layers, so the
# middle cut and the additions' merge sit after layer 3) and another shortcut task (12 causal inputs, 12 noise
# inputs), 12 data draws never used before, optimizer seeds 0 and 1.  The measures and contrasts are v61's, unchanged.
V62_DRAWS = tuple(range(349, 361))                     # 12 data draws never used before (checked against every wave)
V62_REPS = [(d, o) for o in (0, 1) for d in V62_DRAWS]
V62_ARMS = ("A_routed_affine", "A_all_affine", "B_routed_affine", "B_all_affine")
V62_COMPACTS = ("compact_A", "compact_B")


def v62_cell() -> Cell:
    return Cell("shortcut_rho0.95_c12_n12_w128d6",
                {"name": "shortcut", "n_train": 4096, "params": {"rho_train": 0.95, "d_causal": 12, "d_noise": 12}},
                MLP(128, depth=6))


def wave29_v62_panel(B) -> None:
    """v62 panel (wave 29): does v60's separation hold in a second setting (v62_cell: another network and task)?
    Per draw and optimizer seed, one f0 and from it:
      the affine arms of wave 26  {A, B} x {routed, all} affine to 2U (same schedule, snapshots, holds), each with
                                  wave 26's linear removal (the structure the merge geometry reads)
      compact_A, compact_B        wave 26's compact controls (f0 continued for 4U with the same hold)
      the forks of wave 28        from each routed affine arm at snap_1000 and snap_2500, the five continuations
                                  (V58_CONTS and V59_CONTS) to 2U with the parent's hold
    744 jobs: 24 f0, 96 trajectories, 96 linear removals, 48 compact controls, 480 forks.  Nothing in cop/ changed:
    every job kind and method is v60's."""
    S = W29(B)
    cell = v62_cell()
    U, R, g, lin, _ = _v25_protocol(S, cell)
    lin = {**lin, "early_eval": list(EARLY_EVAL_V42)}
    contrast = f"X25|{cell.name}"
    fcontrast = f"X28|{cell.name}"
    snaps = v33_snapshots(U)
    forks = v58_forks(U)
    lr = S.B.train(cell._data["name"])["lr"]
    AUD = {"log_update_norms": True, "audit_batches": True}
    LIFT = {"freeze_inputs": "none", "freeze_backbone": "none"}
    n_long = V53_LONG * 2 * U
    ea = sorted({*snaps, U, *range(2 * U, n_long + 1, max(1, U // 2))})
    long_ = {"budget": "fixed", "segments": [2 * U, n_long - 2 * U], "segment_reset": [False, False],
             "eval_at": ea, "save_eval_checkpoints": True, "fork_audit": True}
    S.role = "exploratory"
    va, vc = v53_variants(), v53_compacts()
    for ds, os_ in V62_REPS:
        base = S.baseline(cell, ds, os_)
        ref = None
        for name in V62_ARMS:
            h, growth, f = va[name]
            if f != 1.0 or growth.get("act") != "identity":
                raise ValueError(f"wave 29: {name} is not an affine arm at the base learning rate")
            tov = {"snapshot_at": snaps, **AUD, **V53_HOLDS[h]}
            traj, tcfg = S.traj(cell, ds, os_, {"topology": "specialized", **growth}, "V62_core", train_over=tov)
            r = S.dissipation(traj, tcfg, lin, S.design("X25", name, "treated", contrast), "V62_core",
                              train_over=LIFT)
            ref = r if name == "A_routed_affine" else ref
            if growth.get("spec_partition") != "random_matched":
                continue
            for stage, u in forks.items():
                for cn, sec in {**V58_CONTS, **V59_CONTS}.items():
                    S.dissipation(traj, tcfg, {**sec, "post_updates": 2 * U - u, "early_eval": [],
                                               "path_eval_points": 4},
                                  S.design("X28", f"{name}@{stage}", cn, fcontrast), "V62_forks",
                                  tags={"parent_stage": stage}, train_over=dict(V53_HOLDS[h]))
        for name in V62_COMPACTS:
            h, f = vc[name]
            if f != 1.0:
                raise ValueError(f"wave 29: {name} is not at the base learning rate")
            S.cont(cell, ds, os_, base, ref, "C1", long_, S.design("X25", name, "C1", contrast, "updates"),
                   "V62_core", train_over={**AUD, **V53_HOLDS[h]})


class W30(W13):
    def __init__(self, B):
        super().__init__(B, 30)


class W31(W13):
    def __init__(self, B):
        super().__init__(B, 31)


# v65 (wave 30): the v60 design on images.  A binary CIFAR-10 task (vehicles against four animal classes) with a
# shortcut input channel (data image_shortcut), a small CNN whose middle cut feeds a 1x1 receiving layer present in
# every network (model cnn_cut), 12 data draws never used before, optimizer seeds 0 and 1.  The arms of wave 29 (affine
# additions at the middle cut, {A, B} x {routed, all}; the routed split 95 / 5 as on the shortcut data, whose
# group-0 share sets it there), the compact controls, the five forks of each routed arm, and one more arm: a late
# temporary head (ReLU additions at the pooled features before the classifier, every example's gradient), the
# projection-head comparison.
V65_DRAWS = tuple(range(361, 373))                     # 12 data draws never used before (checked against every wave)
V65_REPS = [(d, o) for o in (0, 1) for d in V65_DRAWS]
V65_FRAC = 0.95                                        # branch a's share of the routed split (wave 29's group-0 share)
V65_HEAD = "A_head_all_relu"


def v65_image_cell() -> Cell:
    return Cell("image_shortcut_cifar10_veh4_ani4_rho0.95_cnncut",
                {"name": "image_shortcut", "n_train": 8192, "params": {"rho_train": 0.95}},
                {"family": "cnn_cut"})


def v65_image_arms() -> dict:
    """wave 30's expansion arms: name -> (hold key, growth settings).  The four affine arms at the middle cut (the
    routed ones with branch a's share 0.95) and the late head (relu, every example, at the penultimate cut)."""
    out = {}
    for h in V53_HOLDS:
        out[f"{h}_routed_affine"] = (h, {"spec_partition": "random_matched", "spec_random_fraction": V65_FRAC,
                                         "act": "identity"})
        out[f"{h}_all_affine"] = (h, {"spec_partition": "all_examples", "act": "identity"})
    out[V65_HEAD] = ("A", {"spec_partition": "all_examples", "act": "relu", "cut_kind": "penultimate"})
    return out


def wave30_v65_image_panel(B) -> None:
    """v65 panel (wave 30): does the v60 separation hold on images, and does it differ from a late temporary head?
    Per draw and optimizer seed, one f0 (cnn_cut on image_shortcut) and from it:
      the affine arms   {A, B} x {routed, all} affine additions at the middle cut to 2U, each with the linear removal
      the late head     A_head_all_relu: ReLU additions on the pooled features before the classifier, every example's
                        gradient, to 2U, with the linear removal (the projection-head comparison)
      compact_A, compact_B   f0 continued for 4U with the same hold
      the forks         from each routed affine arm at snap_1000 and snap_2500, the five continuations of wave 28
    792 jobs: 24 f0, 120 trajectories, 120 linear removals, 48 compact controls, 480 forks."""
    S = W30(B)
    cell = v65_image_cell()
    U, R, g, lin, _ = _v25_protocol(S, cell)
    lin = {**lin, "early_eval": list(EARLY_EVAL_V42)}
    contrast = f"X25|{cell.name}"
    fcontrast = f"X28|{cell.name}"
    snaps = v33_snapshots(U)
    forks = v58_forks(U)
    AUD = {"log_update_norms": True, "audit_batches": True}
    LIFT = {"freeze_inputs": "none", "freeze_backbone": "none"}
    n_long = V53_LONG * 2 * U
    ea = sorted({*snaps, U, *range(2 * U, n_long + 1, max(1, U // 2))})
    long_ = {"budget": "fixed", "segments": [2 * U, n_long - 2 * U], "segment_reset": [False, False],
             "eval_at": ea, "save_eval_checkpoints": True, "fork_audit": True}
    S.role = "exploratory"
    vc = v53_compacts()
    for ds, os_ in V65_REPS:
        base = S.baseline(cell, ds, os_)
        ref = None
        for name, (h, growth) in v65_image_arms().items():
            tov = {"snapshot_at": snaps, **AUD, **V53_HOLDS[h]}
            traj, tcfg = S.traj(cell, ds, os_, {"topology": "specialized", **growth}, "V65_image", train_over=tov)
            r = S.dissipation(traj, tcfg, lin, S.design("X25", name, "treated", contrast), "V65_image",
                              train_over=LIFT)
            ref = r if name == "A_routed_affine" else ref
            if growth.get("spec_partition") != "random_matched":
                continue
            for stage, u in forks.items():
                for cn, sec in {**V58_CONTS, **V59_CONTS}.items():
                    S.dissipation(traj, tcfg, {**sec, "post_updates": 2 * U - u, "early_eval": [],
                                               "path_eval_points": 4},
                                  S.design("X28", f"{name}@{stage}", cn, fcontrast), "V65_image_forks",
                                  tags={"parent_stage": stage}, train_over=dict(V53_HOLDS[h]))
        for name in V62_COMPACTS:
            h, f = vc[name]
            S.cont(cell, ds, os_, base, ref, "C1", long_, S.design("X25", name, "C1", contrast, "updates"),
                   "V65_image", train_over={**AUD, **V53_HOLDS[h]})


# v65 (wave 31): the mechanism forks.  From wave 29's routed affine trajectories (second setting) at snap_1000 and
# snap_2500, continuations from a function-preserving redistribution of the additions' computation
# (cop.graph.redistribute): the network computes the same function at the fork, and the continuation is the keep
# fork of wave 28 (fresh optimizer, the parent's hold).  routed_*: the parent's gradient masks kept; ordinary_*:
# released.  swap: the a and b branches' parameters exchanged; shift50 / shift100: half / all of the additions' map
# moved into the receiving layer (the additions' output scaled by 0.5 / 0).  Compared with wave 29's routed_reset
# and ordinary_reset forks of the same fork point (included here unchanged: same configuration, same run ids).
V65_CONTS = {"routed_swap": {"method": "keep_swap", "removal_masks": "retained", "optimizer_policy": "reset_each_phase"},
             "ordinary_swap": {"method": "keep_swap", "removal_masks": "released",
                               "optimizer_policy": "reset_each_phase"},
             "routed_shift50": {"method": "keep_shift50", "removal_masks": "retained",
                                "optimizer_policy": "reset_each_phase"},
             "routed_shift100": {"method": "keep_shift100", "removal_masks": "retained",
                                 "optimizer_policy": "reset_each_phase"},
             "ordinary_shift100": {"method": "keep_shift100", "removal_masks": "released",
                                   "optimizer_policy": "reset_each_phase"}}


def wave31_v65_mechanism_panel(B) -> None:
    """v65 panel (wave 31): what the additions compute against how they teach the backbone.  Wave 29's f0s, its two
    routed affine trajectories per f0 and their twenty forks (wave 29's own jobs, unchanged, so a panel folder may be
    seeded with v64's finished runs) and, from each trajectory at snap_1000 and snap_2500, the five redistribution
    forks V65_CONTS to 2U.  1032 jobs, of which 480 are new (block V65_mechanism)."""
    S29, S = W29(B), W31(B)
    cell = v62_cell()
    U, R, g, lin, _ = _v25_protocol(S29, cell)
    fcontrast = f"X28|{cell.name}"
    snaps = v33_snapshots(U)
    forks = v58_forks(U)
    AUD = {"log_update_norms": True, "audit_batches": True}
    S29.role = S.role = "exploratory"
    va = v53_variants()
    for ds, os_ in V62_REPS:
        S29.baseline(cell, ds, os_)
        for name in V58_PARENTS:
            h, growth, f = va[name]
            if f != 1.0 or growth.get("act") != "identity" or growth.get("spec_partition") != "random_matched":
                raise ValueError(f"wave 31: {name} is not a routed affine arm at the base learning rate")
            tov = {"snapshot_at": snaps, **AUD, **V53_HOLDS[h]}
            traj, tcfg = S29.traj(cell, ds, os_, {"topology": "specialized", **growth}, "V62_core", train_over=tov)
            for stage, u in forks.items():
                sec0 = {"post_updates": 2 * U - u, "early_eval": [], "path_eval_points": 4}
                for cn, sec in {**V58_CONTS, **V59_CONTS}.items():
                    S29.dissipation(traj, tcfg, {**sec, **sec0}, S29.design("X28", f"{name}@{stage}", cn, fcontrast),
                                    "V62_forks", tags={"parent_stage": stage}, train_over=dict(V53_HOLDS[h]))
                for cn, sec in V65_CONTS.items():
                    S.dissipation(traj, tcfg, {**sec, **sec0}, S.design("X28", f"{name}@{stage}", cn, fcontrast),
                                  "V65_mechanism", tags={"parent_stage": stage}, train_over=dict(V53_HOLDS[h]))


class W32(W13):
    def __init__(self, B):
        super().__init__(B, 32)


# v66 (wave 32): compact controls matched to the forks' optimizer reset.  The compact controls of waves 29 and 30
# continue f0 with the optimizer state f0 ended with; the forks start a fresh optimizer at their fork point.  Here f0
# is continued with the same hold to the fork point u carrying its optimizer state, the optimizer is reset at u, and
# training continues to 2U: the compact network with the forks' reset schedule (segments [u, 2U - u], segment_reset
# [False, True]).  One per f0, hold and fork point, for wave 29's f0s (second setting) and wave 30's (images).  Each
# f0's baseline and its A_routed_affine trajectory and linear removal (the continuation's formal 'treated' parent, as
# in waves 29 and 30) are those waves' own jobs (same run ids), copied from v64 and v65.
def _v66_reset_compacts(S, Sw, cell, reps, arms_of_A) -> None:
    U, R, g, lin, _ = _v25_protocol(Sw, cell)
    lin = {**lin, "early_eval": list(EARLY_EVAL_V42)}
    contrast = f"X25|{cell.name}"
    snaps = v33_snapshots(U)
    forks = v58_forks(U)
    AUD = {"log_update_norms": True, "audit_batches": True}
    LIFT = {"freeze_inputs": "none", "freeze_backbone": "none"}
    Sw.role = S.role = "exploratory"
    vc = v53_compacts()
    h_a, growth_a, block = arms_of_A
    for ds, os_ in reps:
        base = Sw.baseline(cell, ds, os_)
        tov = {"snapshot_at": snaps, **AUD, **V53_HOLDS[h_a]}
        traj, tcfg = Sw.traj(cell, ds, os_, {"topology": "specialized", **growth_a}, block, train_over=tov)
        ref = Sw.dissipation(traj, tcfg, lin, Sw.design("X25", "A_routed_affine", "treated", contrast), block,
                             train_over=LIFT)
        for name in V62_COMPACTS:
            h, f = vc[name]
            for stage, u in forks.items():
                sec = {"budget": "fixed", "segments": [u, 2 * U - u], "segment_reset": [False, True],
                       "eval_at": [u, 2 * U], "save_eval_checkpoints": True, "fork_audit": True}
                S.cont(cell, ds, os_, base, ref, "C1R", sec, S.design("X25", f"{name}@{stage}", "C1R", contrast,
                                                                      "updates"),
                       "V66_reset_compacts", train_over={**AUD, **V53_HOLDS[h]})


def wave32_v66_reset_compacts(B) -> None:
    """v66 panel (wave 32): the reset-matched compact controls (see _v66_reset_compacts).  336 jobs, of which 192
    are new: 24 f0 x 2 holds x 2 fork points in each of the second setting (wave 29) and the image setting (wave
    30); the rest are those waves' baselines, A_routed_affine trajectories and linear removals."""
    S = W32(B)
    va = v53_variants()
    h, growth, f = va["A_routed_affine"]
    _v66_reset_compacts(S, W29(B), v62_cell(), V62_REPS, (h, growth, "V62_core"))
    h_i, growth_i = v65_image_arms()["A_routed_affine"]
    _v66_reset_compacts(S, W30(B), v65_image_cell(), V65_REPS, (h_i, growth_i, "V65_image"))


def wave21_v30_panel(B) -> None:
    """v30 panel (wave 21) around the v24 first-layer transplant lead (after the fixed-assignment removal and
    repair, the repaired first layer alone in f0 keeps most of the gain).  Data draws 301-306 were never used.
      V30_replication  fixed / redrawn removals, C1, C2, C1_phase, every draw at optimizer seeds 0 and 1: the
                       first-layer transplant (code 0-1-1-1-1) is the replication target, read the same way for
                       every arm by audit_v5/tools/selective_reversal.py
      V30_forks        from the IDENTICAL expanded end state of each fixed / redrawn trajectory (seed 0), the same
                       1.5 U of training under four treatments, all removal jobs with the same minibatch stream and a
                       fresh optimizer: linear removal (in V30_replication), abrupt removal, keep (the additions stay
                       and train), keep_frozen (the additions stay with frozen parameters)
      V30_restricted   the linear removal with only the first layer learning in the repair, the other layers
                       either at their post-expansion values (repair_first) or reset to f0 (repair_first_restored);
                       beside C1_first (f0 with only its first layer learning, C1's updates)
      V30_cut          the insertion cut early and late (the core uses the middle), fixed and redrawn
      V30_boundary     three variants of the task, fixed / redrawn / C1: inputs rotated by a fixed orthogonal map,
                       a nonlinear (product) rule of the causal variables, and no shortcut (rho_train 0.5)
      V32_coupling_time  hold_<h>[_frozen]: the additions stay coupled for h updates, then the repair gets R - h.
                       The total budget R is fixed, so h trades coupling time against repair time (and moves the
                       second optimizer reset): a fixed-budget ALLOCATION experiment, not an isolated duration effect
      V32_rebuild      the rebuilt-start factorial from the same end state: trained backbone + fresh additions,
                       f0 + trained additions, and (v34) f0 + fresh additions; the plain removal is the fourth corner
      V32_disturbance  C1_disturbed (v34 phase-matched to abrupt_pm): f0 trained on for 2 U, the matched random
                       perturbation at the removal time, then R updates with a fresh optimizer at 0 and at g; matched
                       on the validation error (C1_disturbed) and on the validation risk (C1_disturbed_loss, v36)
    v34: the replication C1_phase also saves its states at the v33 age times (the time-matched compact reference
    of audit_v5/tools/portability_age.py)."""
    S = W21(B)
    cell = v25_shortcut_cell()
    U, R, g, lin, abr = _v25_protocol(S, cell)
    contrast = f"X25|{cell.name}"
    arms = v25_arms()
    S.role = "confirmation"
    core = _v30_core(S, cell, V30_REPS, "V30_replication", snapshots=True)
    S.role = "exploratory"
    for key in V30_MECH_REPS:
        ds, os_ = key
        for name, (traj, tcfg) in core[key].items():
            S.dissipation(traj, tcfg, abr, S.design("X25", name, "abrupt", contrast), "V30_forks")
            S.dissipation(traj, tcfg, {"method": "keep", "post_updates": R, "early_eval": list(EARLY_EVAL)},
                          S.design("X25", name, "keep", contrast), "V30_forks")
            S.dissipation(traj, tcfg, {"method": "keep", "post_updates": R, "early_eval": list(EARLY_EVAL),
                                       "keep_frozen_implants": True},
                          S.design("X25", name, "keep_frozen", contrast), "V30_forks")
            # v31: the same forks with the linear removal's reset times (fresh optimizer at 0 and at g)
            S.dissipation(traj, tcfg, {**abr, "split_updates": g}, S.design("X25", name, "abrupt_pm", contrast),
                          "V31_forks_phase_matched")
            S.dissipation(traj, tcfg, {"method": "keep", "post_updates": R, "early_eval": list(EARLY_EVAL),
                                       "split_updates": g},
                          S.design("X25", name, "keep_pm", contrast), "V31_forks_phase_matched")
            S.dissipation(traj, tcfg, {"method": "keep", "post_updates": R, "early_eval": list(EARLY_EVAL),
                                       "keep_frozen_implants": True, "split_updates": g},
                          S.design("X25", name, "keep_frozen_pm", contrast), "V31_forks_phase_matched")
            S.dissipation(traj, tcfg, {**lin, "repair_scope": "first"},
                          S.design("X25", name, "linear_repair_first", contrast), "V30_restricted")
            S.dissipation(traj, tcfg, {**lin, "repair_scope": "first", "restore_before_repair": "all_but_first"},
                          S.design("X25", name, "linear_repair_first_restored", contrast), "V30_restricted")
        base = S.baseline(cell, ds, os_)
        S.role = "confirmation"          # the replication arm's own removal (same config, so the same run)
        fixed_removal = S.dissipation(*core[key]["fixed"], lin, S.design("X25", "fixed", "treated", contrast),
                                      "V30_replication")
        S.role = "exploratory"
        S.cont(cell, ds, os_, base, fixed_removal, "C1_first", {"budget": "parent_updates", "trainable_scope": "first"},
               S.design("X25", "compact", "C1_first", contrast, "updates"), "V30_restricted")
        # v32: what the trained additions contribute, how long they stay coupled, and generic damage + recovery
        for name, (traj, tcfg) in core[key].items():
            for h in (U // 2, U):
                for frozen in (False, True):
                    sec = {"method": "linear", "gate_schedule": "hold", "speed_updates": int(h), "post_updates": R - int(h),
                           "early_eval": list(EARLY_EVAL), **({"keep_frozen_implants": True} if frozen else {})}
                    S.dissipation(traj, tcfg, sec, S.design("X25", name, f"hold_{h}" + ("_frozen" if frozen else ""),
                                                            contrast), "V32_coupling_time")
            S.dissipation(traj, tcfg, {**lin, "rebuild": {"backbone": "receiver", "implants": "fresh"}},
                          S.design("X25", name, "linear_trained_fresh", contrast), "V32_rebuild")
            S.dissipation(traj, tcfg, {**lin, "rebuild": {"backbone": "f0", "implants": "receiver"}},
                          S.design("X25", name, "linear_f0_trained", contrast), "V32_rebuild")
            # v34: the fourth corner of the rebuilt-start factorial: f0 + the additions at insertion (neutral)
            S.dissipation(traj, tcfg, {**lin, "rebuild": {"backbone": "f0", "implants": "fresh"}},
                          S.design("X25", name, "linear_f0_fresh", contrast), "V32_rebuild")
        # v34: phase-matched to the abrupt_pm fork (V31_forks_phase_matched): f0 continued for the trajectory's 2 U
        # (no reset), the matched perturbation at the removal time, then the repair with a fresh optimizer at 0 and
        # at g, as abrupt_pm's recover_0 / recover_0b
        # v36: matched on the validation error (stops at chance) and, separately, on the validation risk (no ceiling)
        for arm_, met_ in (("C1_disturbed", "val_err"), ("C1_disturbed_loss", "val_risk")):
            S.cont(cell, ds, os_, base, fixed_removal, arm_,
                   {"budget": "fixed", "segments": [U, U, g, R - g], "segment_reset": [False, False, True, True],
                    "perturb_match": "parent_frozen_deletion", "perturb_segment": 2, "perturb_estimand": "absolute",
                    "perturb_match_metric": met_},
                   S.design("X25", "compact", arm_, contrast, "updates"), "V32_disturbance")
        # v31: f0 with only its first layer learning for the restricted repair's own window (R - g updates)
        S.cont(cell, ds, os_, base, fixed_removal, "C1_first_window",
               {"budget": "fixed", "updates": R - g, "trainable_scope": "first"},
               S.design("X25", "compact", "C1_first_window", contrast, "updates"), "V30_restricted")
        for cut in ("early", "late"):
            for name in ("fixed", "redrawn"):
                traj, tcfg = S.traj(cell, ds, os_, {"topology": "specialized", **arms[name], "cut_where": cut},
                                    "V30_cut")
                S.dissipation(traj, tcfg, lin, S.design("X25", f"{name}_cut_{cut}", "treated", contrast), "V30_cut")
    for nm, params in (("rotated", {"rho_train": 0.95, "input_rotation": 1}),
                       ("product_rule", {"rho_train": 0.95, "rule": "product"}),
                       ("no_shortcut", {"rho_train": 0.5})):
        bc = Cell(f"shortcut_{nm}", {"name": "shortcut", "n_train": 4096, "params": params}, MLP(64))
        _v30_core(S, bc, V30_BOUNDARY_REPS, "V30_boundary", controls=("C1",))


def _v25_width(S: W13, cell: Cell, w: int) -> None:
    U, R, g, lin, _ = _v25_protocol(S, cell)
    arms = v25_arms()
    contrast = f"X25|{cell.name}"
    for ds, os_ in V25_WIDTH_REPS:
        for name in ("fixed", "redrawn"):
            traj, tcfg = S.traj(cell, ds, os_, {"topology": "specialized", **arms[name], "width": int(w)}, "V25_width")
            S.dissipation(traj, tcfg, lin, S.design("X25", f"{name}_w{w}", "treated", contrast), "V25_width")


def block_matched(S: W13, reps, full: bool = True, confirm: bool = False):
    """D2: matched architectures: F07 replication, the four history ingredients (C4), F09 query timing, M_E
    retention and representative X3 failures.  confirm=True (wave 14, v15): the F07 finite-bit cells use the
    finite-peg recipe panel (block_finite_recipes) instead of the collapsed strict scratch comparison, and M_E
    adds the warm-start abrupt-interface arm."""
    deep = Cell("teacher3_n2048_d6", teacher_data(3, 2048), MLP(64, depth=6))
    upr = S.upr(deep)
    lr = S.B.train("teacher")["lr"]
    hb = {"temp_channel": 8, "temp_on": "middle", "temp_open_updates": max(1, upr // 4)}
    for ds, os_ in reps:
        # F07 replication: continuous widths and a compact bit sweep
        # (confirm: dim 8 is the C4i dim-8 cell below, the same configuration; it is not run twice)
        for tag, peg in ([(f"dim{k}", {"dim": k, "mode": "none"}) for k in ((2, 32) if confirm else (2, 8, 32))] +
                         ([] if confirm else [(f"bits{b}", {"dim": 1, "mode": "uniform", "bits": b})
                                              for b in (1, 4, 16)])):
            contrast = f"F07r|{deep.name}|{tag}"
            t = S.cop(deep, ds, os_, {"task_kind": "chain", "n_pearls": 3}, peg,
                      S.design("F07r", tag, "treated", contrast), "V13_F07_replication")
            S.cop(deep, ds, os_, {"task_kind": "chain", "n_pearls": 3}, peg,
                  S.design("F07r", tag, "treated_lr0.3", contrast), "V13_F07_replication", train_over={"lr": lr * 0.3})
            S.matched(deep, ds, os_, t, "F07r", tag, contrast, "V13_F07_replication", lr)
        # the four ingredients at one endpoint architecture (peg dim 4 and dim 8)
        for dim in (4, 8):
            contrast = f"C4i|{deep.name}|dim{dim}"
            blk = "V13_history_ingredients"
            D = lambda arm, panel="updates": S.design("C4i", f"dim{dim}", arm, contrast, panel)
            t = S.cop(deep, ds, os_, {"task_kind": "chain", "n_pearls": 3}, {"dim": dim}, D("treated"), blk)
            S.cop(deep, ds, os_, {"task_kind": "chain", "n_pearls": 3}, {"dim": dim, "anneal_updates": 1},
                  D("abrupt_calibrated_interfaces"), blk)
            S.cop(deep, ds, os_, {"task_kind": "chain", "n_pearls": 3}, {"dim": dim, **hb, "temp_target": "all"},
                  D("gradual_with_bridge_all"), blk)
            S.cop(deep, ds, os_, {"task_kind": "chain", "n_pearls": 3}, {"dim": dim, **hb, "temp_target": "peg"},
                  D("gradual_with_local_bridge"), blk)
            S.cop(deep, ds, os_, {"task_kind": "chain", "n_pearls": 3}, {"dim": dim}, D("treated_lr0.3"), blk,
                  train_over={"lr": lr * 0.3})
            S.matched(deep, ds, os_, t, "C4i", f"dim{dim}", contrast, blk, lr)
        # F09: query before / after encoding for every existing query type (the interaction is the result)
        for qa in (-1, 1):
            for op in ("bit", "xor_next", "two_bits"):
                c = Cell(f"delayed_query_{op}_q{qa}", {"name": "delayed_query", "n_train": 8192,
                                                        "params": {"n_bits": 12, "query_op": op}},
                         MLP(64, depth=4, query_at_layer=qa))
                lrq = S.B.train("delayed_query")["lr"]
                contrast = f"F09r|{c.name}|query_at{qa}_{op}"
                t = S.cop(c, ds, os_, {"task_kind": "chain", "n_pearls": 2}, {"dim": 4, "mode": "uniform", "bits": 2},
                          S.design("F09r", f"query_at{qa}_{op}", "treated", contrast), "V13_F09_query_timing")
                S.cop(c, ds, os_, {"task_kind": "chain", "n_pearls": 2}, {"dim": 4, "mode": "uniform", "bits": 2},
                      S.design("F09r", f"query_at{qa}_{op}", "treated_lr0.3", contrast), "V13_F09_query_timing",
                      train_over={"lr": lrq * 0.3})
                S.matched(c, ds, os_, t, "F09r", f"query_at{qa}_{op}", contrast, "V13_F09_query_timing", lrq)
        # M_E: original-task error and later-query oracle error, for treated AND controls
        for mode, dim, bits in (("uniform", 4, 2), ("none", 4, 0)):
            c = Cell("later_query_tb1", {"name": "later_query", "n_train": 2048, "n_val": 512, "n_test": 1024,
                                          "params": {"n_bits": 12, "task_bits": 1}}, MLP(64, depth=6))
            tag = f"{mode}_d{dim}_b{bits}"
            contrast = f"M_Er|{c.name}|{tag}"
            peg = {"dim": dim, "mode": mode, **({"bits": bits} if mode == "uniform" else {})}
            lrl = S.B.train("later_query")["lr"]
            t = S.cop(c, ds, os_, {"task_kind": "chain", "n_pearls": 3}, peg,
                      S.design("M_Er", tag, "treated", contrast), "V13_M_E_retention")
            S.cop(c, ds, os_, {"task_kind": "chain", "n_pearls": 3}, peg,
                  S.design("M_Er", tag, "treated_lr0.3", contrast), "V13_M_E_retention", train_over={"lr": lrl * 0.3})
            if confirm:
                # v15: warm start with abruptly imposed calibrated interfaces, same readout budget
                S.cop(c, ds, os_, {"task_kind": "chain", "n_pearls": 3}, {**peg, "anneal_updates": 1},
                      S.design("M_Er", tag, "abrupt_calibrated_interfaces", contrast), "V13_M_E_retention")
            S.matched(c, ds, os_, t, "M_Er", tag, contrast, "V13_M_E_retention", lrl)
        # X3: representative failures kept as boundary controls
        for b, maps, qa in ((1, "frozen", -1), (4, "learned", 1)):
            c = Cell(f"delayed_query_q{qa}", {"name": "delayed_query", "n_train": 8192, "params": {"n_bits": 12}},
                     MLP(64, depth=6, query_at_layer=qa))
            tag = f"bits{b}_maps_{maps}_q{qa}"
            contrast = f"X3r|{c.name}|{tag}"
            cop = {"task_kind": "cycles", "cycles": 2, "n_pearls": 3, "cycle_pegs": "relearned",
                   "cycle_peg_maps": maps, "cycle_peg_width": "constant", "cycle_peg_recalibrate": "yes"}
            t = S.cop(c, ds, os_, cop, {"dim": 4, "mode": "uniform", "bits": b}, S.design("X3r", tag, "treated", contrast),
                      "V13_X3_boundary")
            S.matched(c, ds, os_, t, "X3r", tag, contrast, "V13_X3_boundary", S.B.train("delayed_query")["lr"],
                      cop_kind="cycles")


def block_finite(S: W13, reps):
    """D3: finite codes with two-bit capacity: no / abrupt / gradual bridge, updates and MAC panels, model vs
    optimal-decoder vs global-optimum errors, and a decoder-only refit with the encoder frozen."""
    blk = "V13_finite_codes"
    for ds, os_ in reps:
        for n_b in (3, 4, 5):
            for fam, dname, extra_p, qa in (("FIN_A", "delayed_query", {}, 1),
                                            ("FIN_B", "later_query", {"task_bits": 1}, None)):
                data = {"name": dname, "n_train": "full", "params": {"n_bits": n_b, "split_mode": "complete", **extra_p}}
                model = MLP(32, depth=3, **({"query_at_layer": qa} if qa is not None else {}))
                c = Cell(f"{dname}_n{n_b}", data, model)
                fin_up = max(20, S.upr(c))
                hbf = {"temp_channel": 8, "temp_open_updates": max(1, fin_up // 4)}
                contrast = f"{fam}r|{c.name}|K2"
                cop = {"task_kind": "chain", "n_pearls": 2, "global_updates": fin_up,
                       "decoder_refit_updates": max(1, fin_up // 2)}
                peg = {"dim": 2, "mode": "uniform", "bits": 1}
                D = lambda arm, panel="updates": S.design(f"{fam}r", f"n{n_b}", arm, contrast, panel)
                gr = S.cop(c, ds, os_, cop, {**peg, **hbf}, D("treated"), blk)            # gradual bridge
                S.cop(c, ds, os_, cop, peg, D("no_bridge"), blk)
                S.cop(c, ds, os_, cop, {**peg, **hbf, "temp_anneal_updates": 1}, D("bridge_abrupt"), blk)
                S.cop(c, ds, os_, {**cop, "global_match_macs_of": "mac_reference"}, peg,
                      D("no_bridge_mac_matched", "compute"), blk, extra_parents={"mac_reference": gr})
                S.cop(c, ds, os_, cop, {**peg, **hbf, "temp_target": "adapter"}, D("bridge_permanent_diagnostic"), blk)


def block_locality(S: W13, reps, widths=(4, 16), budgets=("half_upr", "2upr")):
    """D4: local repair with exact-replacement, frozen-code and representation-matching controls; replacement
    width and repair budget swept (tolerances are swept inside every job); failures are censored, not
    irreducible.  Outcomes: task recovery, function agreement and transmitted-code agreement (v15)."""
    blk = "V13_locality"
    deep = Cell("teacher3_n2048_d6", teacher_data(3, 2048), MLP(64, depth=6))
    upr = S.upr(deep)
    bud = {"half_upr": max(1, upr // 2), "2upr": 2 * upr}
    for ds, os_ in reps:
        for width in widths:
            for rep_u in (bud[b] for b in budgets):
                loc = {"task_kind": "locality", "n_pearls": 5, "global_updates": 2 * upr, "local_updates": max(1, upr // 2),
                       "locality_repair_updates": rep_u, "locality_checkpoints": [0.25, 0.5, 1.0],
                       "locality_controls": True, "replace_width": width}
                for arm, peg in (("none", {"mode": "none"}), ("continuous", {"mode": "none"}),
                                 ("continuous_stabilized", {"mode": "none"}),
                                 ("finite_learned", {"mode": "uniform", "bits": 2}),
                                 ("finite_stabilized", {"mode": "uniform", "bits": 2})):
                    S.cop(deep, ds, os_, {**loc, "locality_interface": arm}, {"dim": 8, **peg},
                          S.design("LOCr", f"w{width}_r{rep_u}", arm, f"LOCr|{deep.name}|w{width}_r{rep_u}"), blk)


def wave13_repilot(B) -> None:
    S = W13(B, 13)
    reps = [(0, 0)]                       # discovery seed only
    block_x4(S, reps)
    block_matched(S, reps)
    block_finite(S, reps)
    block_locality(S, reps)


def confirmation_reps() -> list[tuple[int, int]]:
    reps = [(d, 0) for d in CONFIRM_DRAWS]
    for d, oss in CONFIRM_CROSSED.items():
        reps += [(d, o) for o in oss]
    return reps


def wave14_confirmation(B) -> None:
    """Fresh paired replications for the shortlisted contrasts.  The protocol (metrics, selection rule,
    contrasts) is the frozen wave-13 protocol; nothing here may be changed after confirmation results are
    opened.  Shortlist: X4 at rho 0.95 (all routing / information conditions and removal protocols), the F07 and
    history-ingredient matched-architecture contrasts, the F09 query-timing interaction, and the finite-code
    decomposition."""
    S = W13(B, 14)
    reps = confirmation_reps()
    block_x4(S, reps, rhos=(0.95,))
    block_matched(S, reps, confirm=True)
    # finite-peg cells under the recipe panel; prune CONFIRM_FINITE_RECIPES after wave 15 and before the freeze
    # (the F07 bit cells only: the M_E 2-bit cell's treated and strict scratch arms already run in block_matched)
    deep = Cell("teacher3_n2048_d6", teacher_data(3, 2048), MLP(64, depth=6))
    block_finite_recipes(S, reps, cells=[(deep, f"bits{b}", {"dim": 1, "mode": "uniform", "bits": b}, "teacher")
                                         for b in (1, 4, 16)],
                         recipes=CONFIRM_FINITE_RECIPES, lr_factors=CONFIRM_LR_FACTORS, blk="V15_finite_peg_recipes",
                         treated_recipes=CONFIRM_TREATED_RECIPES, panels=CONFIRM_SCRATCH_PANELS)
    # v17: gradient-partition dynamics (the strongest wave-15 lead): every partition mode on the five primary
    # draws; the fixed and redrawn 95/5 splits also at two further partition seeds (within-draw replications)
    block_partition_dynamics(S, [(d, 0) for d in CONFIRM_DRAWS], partition_seeds=CONFIRM_PARTITION_SEEDS,
                             seeded_modes=CONFIRM_SEEDED_PARTITION_MODES)
    block_finite(S, reps)
    # v15: a modest locality panel (the CoP boundary question): every interface, both widths, one repair budget
    # (primary draws only: locality jobs are the most expensive, and the crossed optimizer seeds are secondary)
    block_locality(S, [(d, 0) for d in CONFIRM_DRAWS], widths=(4, 16), budgets=("2upr",))
