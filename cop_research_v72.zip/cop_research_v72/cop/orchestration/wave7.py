"""Wave 7: the strengthening extension (addendum Phase 1, mechanism screening).

Every one of the 50 registry variants (F01a-F10e) is covered by at least one
applicable cell; mechanisms A-H, the controls C0-C8, the target regimes T0/T1,
the budget panels and the five mandatory crosses are built from the same
pieces.  Combinations that cannot be built are recorded with a reason in the
coverage file (strengthening.inapplicable); combinations that are built but
turn out to be unsupported at run time end as 'unsupported' jobs with their
reason, and stay visible in the coverage matrix.

Structure of one contrast (pairing label design.contrast; replication = the
paired data/teacher/optimizer seed):
  treated   the compact endpoint of a treated history (a trajectory, then a
            contraction back to the f0 architecture: dissipation, repair, or
            grow/contract cycles inside the trajectory; or a CoP chain export)
  C0        f0 itself (no job: the analysis reads f0's metrics)
  C1 / C2   f0 continued for the treated chain's measured post-f0 updates /
            training MACs (budget panels 'updates' / 'compute')
  full control set (one primary cell per family, the T0 panel and the CNN cell):
  C3        the expanded graph trained from scratch, then the same contraction
  C4        distillation from the treated expanded model into the f0 architecture
  C5        same-architecture self-distillation (teacher f0)
  C6        exact folding / branch merging where the implant allows it
  C7        learning-rate restart, optimizer reset, matched-size perturbation
  C8        pruning and regrowth (CNN cell)
Intermediate jobs (baselines, trajectories feeding several contractions) carry
no design fields so that they are shared, not duplicated.

Seeds: three paired data/teacher seeds at full scale (seed s sets data, teacher
and optimizer seed); one at pilot and smoke scale (Builder.seeds).
"""
from __future__ import annotations

from collections import defaultdict
from typing import Optional

W = 7
CTRL_TRAIN_KEYS = ("optimizer", "momentum", "weight_decay", "lr", "batch_size", "precision", "stream", "target",
                   "sampler", "lr_schedule")


class Cell:
    def __init__(self, name: str, data, model: dict, ck: str = "post_act", train_over: Optional[dict] = None,
                 image: bool = False):
        self.name, self._data, self.model, self.ck = name, data, model, ck
        self.train_over = dict(train_over or {})
        self.image = image

    def data(self, s: int) -> dict:
        d = self._data(s) if callable(self._data) else dict(self._data)
        d.setdefault("data_seed", s)
        d.setdefault("teacher_seed", s)
        return d


class W7:
    def __init__(self, B):
        self.B = B
        if not hasattr(B, "variant_map") or B.variant_map is None:
            B.variant_map = defaultdict(set)
        if not hasattr(B, "inapplicable") or B.inapplicable is None:
            B.inapplicable = []
        self.seeds = B.seeds([0, 1, 2])

    # ------------------------------------------------------------ helpers
    def upr(self, cell: Cell) -> int:
        return self.B.upr(cell.data(0)["name"])

    def base_updates(self, cell: Cell) -> int:
        return self.B.train(cell.data(0)["name"])["baseline_updates"]

    def na(self, var: str, cell: str, reason: str) -> None:
        self.B.inapplicable.append({"variant": var, "cell": cell, "reason": reason})

    @staticmethod
    def design(fam, var, arm, contrast, panel="", regime="T1") -> dict:
        return {"family": fam, "variant": var, "arm": arm, "budget_panel": panel, "target_regime": regime,
                "contrast": contrast}

    def _mark(self, var: str, block: str) -> None:
        self.B.variant_map[var].add(block)

    def history(self, cell: Cell, growth: dict, s: int, train_over: Optional[dict] = None,
                extra: Optional[dict] = None, block: str = "W7_histories", base_train_over: Optional[dict] = None,
                parents_extra: Optional[dict] = None):
        g = {"cut_kind": cell.ck, "rounds": 2, **growth}
        to = {**cell.train_over, **(train_over or {})}
        bto = {k: v for k, v in to.items() if k in ("optimizer", "momentum", "weight_decay", "lr", "batch_size",
                                                     "precision", "stream", "baseline_updates")}
        if base_train_over:
            bto.update(base_train_over)
        rid = self.B.traj(cell.data(s), cell.model, g, s, W, block, ["S"], with_fc=False, train_over=to,
                          extra=extra, base_train_over=bto, seeds_over={"insertion": s},
                          parents_extra=parents_extra)
        return rid, self.B.entries[rid]["cfg"]

    def contract(self, traj: str, tcfg: dict, sec: dict, design: Optional[dict], block: str,
                 tags: Optional[dict] = None, kind: str = "dissipation") -> str:
        cell_upr = tcfg["growth"]["updates_per_round"]
        if kind == "dissipation":
            section = {"dissipation": {"method": "linear", "speed_updates": max(1, cell_upr // 2),
                                       "post_updates": max(1, cell_upr // 2), "path_eval_points": 10, **sec}}
        else:
            section = {kind: sec}
        if design:
            section["design"] = design
            self._mark(design["variant"], block)
        return self.B.child(kind, traj, tcfg, section, W, block, [design["family"] if design else "S"], tags=tags)

    def _base_of(self, rid: str) -> str:
        c = self.B.entries[rid]["cfg"]
        par = c.get("parents") or {}
        if "baseline" in par:
            return par["baseline"]
        return self._base_of(par["trajectory"])

    def controls(self, cell: Cell, s: int, treated: str, contrast: str, fam: str, var: str, block: str,
                 level: str = "core", regime: str = "T1", traj: Optional[str] = None, growth: Optional[dict] = None,
                 contraction: Optional[dict] = None, fold: Optional[str] = None, train_over: Optional[dict] = None,
                 start_stage: str = "baseline", base: Optional[str] = None, compute_panel: bool = True) -> list[str]:
        """C1/C2 always; the full set adds C3 (needs growth + contraction), C4 (needs traj), C5, C6 (fold),
        C7 and, for an image cell, C8."""
        B = self.B
        base = base or self._base_of(treated)
        to = {**cell.train_over, **(train_over or {})}
        ctr = B.train(cell.data(s)["name"], **{k: v for k, v in to.items() if k in CTRL_TRAIN_KEYS})
        # V3-11d: plain controls would need the treated history's segment schedule rebuilt from its record.
        # The guard reads the treated job's RESOLVED train config (schedule and warmup are not control keys)
        # as well as the overrides and the control's own config
        ttr = (self.B.entries.get(treated) or {}).get("cfg", {}).get("train", {})
        for src in (ctr, to, ttr):
            if src.get("lr_schedule", "constant") != "constant" or int(src.get("warmup", 0) or 0):
                raise ValueError("wave-7 controls assume a constant learning rate; segment matching is not built")
        upr = self.upr(cell)
        out = []

        def cont(arm, sec, extra_parents=None, panel="updates", lr=None):
            parents = {"baseline": base, "treated": treated, **(extra_parents or {})}
            cfg = {"kind": "continue", "data": cell.data(s), "model": cell.model,
                   "train": ctr if lr is None else {**ctr, "lr": lr},
                   "seeds": {"optimizer": s, "insertion": s}, "parents": parents,
                   "continue": {"budget_parent": "treated", "start_stage": start_stage, **sec},
                   "design": self.design(fam, var, arm, contrast, panel, regime), "wave": W, "block": block,
                   "wp": [fam]}
            out.append(B.add(cfg, block, list(parents.values())))
        cont("C1", {"budget": "parent_updates"}, panel="updates")
        if compute_panel:
            cont("C2", {"budget": "parent_compute"}, panel="compute")
        if level == "full":
            # a stronger continued baseline: the same updates at two other learning rates
            for f in (0.3, 3.0):
                cont(f"C1_lr{f}", {"budget": "parent_updates"}, panel="updates", lr=ctr["lr"] * f)
            if traj:
                cont("C4", {"budget": "parent_updates", "arm": "distill", "teacher": "teacher",
                            "teacher_stage": "final"}, {"teacher": traj})
            cont("C5", {"budget": "parent_updates", "arm": "self_distill", "teacher": "baseline",
                        "teacher_stage": start_stage, "distill_alpha": 0.5})
            cont("C7_lr", {"budget": "parent_updates", "arm": "lr_restart", "segments": [1, 1],
                           "restart_warmup": max(1, upr // 20)})
            cont("C7_opt", {"budget": "parent_updates", "arm": "opt_reset", "segments": [1, 1]})
            cont("C7_perturb", {"budget": "parent_updates", "arm": "perturb", "segments": [1, 1],
                                "perturb_rel": 0.01})
            if cell.image:
                cont("C8", {"budget": "parent_updates", "arm": "prune_regrow", "prune_period": max(4, upr // 4),
                            "prune_duration": max(1, upr // 16)})
            if growth is not None and contraction is not None:
                r3, c3 = self.history(cell, {**growth, "schedule": "from_scratch"}, s, train_over=train_over)
                out.append(self.contract(r3, c3, contraction, self.design(fam, var, "C3", contrast, "updates", regime),
                                         block))
            if fold and traj:
                out.append(self.contract(traj, self.B.entries[traj]["cfg"], {"method": fold, "post_updates": 0,
                                                                             "speed_updates": 0},
                                         self.design(fam, var, "C6", contrast, "updates", regime), block))
        return out

    def grown(self, cell: Cell, fam: str, var: str, tag: str, growth: dict, contraction: Optional[dict] = None,
              level: str = "core", train_over: Optional[dict] = None, regime: str = "T1", fold: Optional[str] = None,
              block: Optional[str] = None, seeds=None) -> list[str]:
        """Standard contrast: history (growth) -> contraction (dissipation) = treated, plus controls."""
        block = block or f"W7_{fam}_{var}"
        contraction = contraction if contraction is not None else {}
        out = []
        for s in (seeds or self.seeds):
            traj, tcfg = self.history(cell, growth, s, train_over=train_over)
            contrast = f"{var}|{cell.name}|{tag}"
            t = self.contract(traj, tcfg, contraction, self.design(fam, var, "treated", contrast, "", regime), block)
            out.append(t)
            self.controls(cell, s, t, contrast, fam, var, block, level, regime, traj=traj, growth=growth,
                          contraction=contraction, fold=fold, train_over=train_over)
        return out

    def cycles(self, cell: Cell, fam: str, var: str, tag: str, growth: dict, level: str = "core",
               train_over: Optional[dict] = None, regime: str = "T1", block: Optional[str] = None) -> list[str]:
        """Grow/contract cycles inside one trajectory: the trajectory is the compact endpoint."""
        block = block or f"W7_{fam}_{var}"
        out = []
        for s in self.seeds:
            contrast = f"{var}|{cell.name}|{tag}"
            rid, cfg = self.history(cell, growth, s, train_over=train_over,
                                    extra={"design": self.design(fam, var, "treated", contrast, "", regime)},
                                    block=block)
            self._mark(var, block)
            out.append(rid)
            self.controls(cell, s, rid, contrast, fam, var, block, level, regime, train_over=train_over)
        return out

    def cop(self, cell: Cell, fam: str, var: str, tag: str, cop: dict, peg: dict, level: str = "core",
            block: Optional[str] = None, controls: bool = True, parents_extra=None) -> list[str]:
        block = block or f"W7_{fam}_{var}"
        out = []
        for s in self.seeds:
            contrast = f"{var}|{cell.name}|{tag}"
            rid = self.B.cop(cell.data(s), cell.model, cop, peg, s, W, block, [fam],
                             train_over=cell.train_over, parents_extra=parents_extra(s) if parents_extra else None,
                             extra={"design": self.design(fam, var, "treated", contrast)})
            self._mark(var, block)
            out.append(rid)
            if controls:
                # local fits of cycles / alternatives jobs count updates but no MACs: no compute panel there
                exact_macs = cop.get("task_kind") not in ("cycles", "alternatives")
                # C1 / C2 continue f0: a COST-FRONTIER reference whenever the CoP export differs from f0
                self.controls(cell, s, rid, contrast, fam, var, block, level, compute_panel=exact_macs)
                # endpoint-matched controls (V3-03): the treated CoP export re-initialised and trained directly
                self.matched_cop_controls(cell, s, rid, contrast, fam, var, block, cop, peg, exact_macs)
        return out

    def matched_cop_controls(self, cell, s, treated, contrast, fam, var, block, cop, peg, compute_panel):
        B = self.B
        base = self._base_of(treated)
        ctr = B.train(cell.data(s)["name"], **{k: v for k, v in cell.train_over.items() if k in CTRL_TRAIN_KEYS})
        if cop.get("task_kind") == "cycles":
            # the existing P5 matched control: the cycles run's exported endpoint, re-initialised, quantisers
            # re-calibrated, architecture and accounting asserted equal; exposure = parent updates + f0 updates
            B.cop(cell.data(s), cell.model, {**cop, "task_kind": "baseline", "baseline": "direct_small"}, peg, s, W,
                  block, [fam], train_over=cell.train_over, parents_extra={"cycles": treated},
                  extra={"design": self.design(fam, var, "M1", contrast, "updates")})
            return
        for arm, budget, ok in (("M1", "parent_updates", True), ("M2", "parent_compute", compute_panel)):
            if not ok:
                continue
            parents = {"baseline": base, "treated": treated}
            B.add({"kind": "continue", "data": cell.data(s), "model": cell.model, "train": ctr,
                   "seeds": {"optimizer": s, "insertion": s}, "parents": parents,
                   "continue": {"start": "treated", "start_stage": "export", "reinit": True,
                                "budget": budget, "budget_parent": "treated", "budget_add_f0": True},
                   "design": self.design(fam, var, arm, contrast, "updates" if arm == "M1" else "compute"),
                   "wave": W, "block": block, "wp": [fam]}, block, list(parents.values()))


# =============================================================================

def wave7_strengthening(B) -> None:
    from .manifest import teacher_data, MLP
    S = W7(B)
    smoke = B.scale == "smoke"
    main = Cell("teacher3_n2048", lambda s: teacher_data(3, 2048, s), MLP(64))
    deep = Cell("teacher3_n2048_d6", lambda s: teacher_data(3, 2048, s), MLP(64, depth=6))
    noisy = Cell("teacher3_n2048_noise0.5", lambda s: teacher_data(3, 2048, s, target_noise=0.5), MLP(64))
    short = Cell("shortcut_n4096", {"name": "shortcut", "n_train": 4096}, MLP(64))
    compose = Cell("compose_n4096", {"name": "compose", "n_train": 4096}, MLP(64, depth=6))
    seq = Cell("seq_select_n2048", {"name": "seq_select", "n_train": 2048, "n_val": 512, "n_test": 1024},
               {"family": "transformer", "depth": 4, "width": 64}, "resid")
    # image cell: Fashion-MNIST at pilot / full scale; engineering toy images at smoke scale (no download)
    img_data = {"name": "toy_images", "n_train": 1600} if smoke else {"name": "fashion_mnist", "n_train": 8000}
    img = Cell("fmnist_cnn" if not smoke else "toy_images_cnn", img_data, {"family": "cnn", "width_mult": 0.5},
               "post_act", image=True)
    resnet = Cell("fmnist_resnet" if not smoke else "toy_images_resnet", img_data,
                  {"family": "resnet", "width_mult": 0.5}, "block_out", image=True)
    upr = S.upr(main)
    LIN = {"method": "linear"}

    # ------------------------------------------------------------------ F01 foldability
    S.grown(main, "F01", "F01a", "linear_factor", {"topology": "linear_factor"}, {"method": "fold", "post_updates": 0,
                                                                                    "speed_updates": 0}, level="full")
    S.grown(img, "F01", "F01a", "conv_factor", {"topology": "node_factorization"},
            {"method": "fold", "post_updates": 0, "speed_updates": 0})
    for sp in (0.5, 0.1):
        S.grown(main, "F01", "F01b", f"split{sp}", {"topology": "node_split", "split": sp, "rounds": 1},
                {"method": "fold", "post_updates": 0, "speed_updates": 0})
    for cond in (1.0, 100.0):
        for tie in ("enforced", "untied"):
            # poorly conditioned pairs in fp64 (fp32 cannot hold the identity at cond 100)
            to = {"precision": "fp64"} if cond > 10 else None
            S.grown(main, "F01", "F01c", f"cond{cond}_{tie}", {"topology": "inverse_pair", "inverse_kind": "linear",
                                                               "inverse_cond": cond, "tie": tie, "rounds": 1},
                    {"method": "fold", "post_updates": 0, "speed_updates": 0}, train_over=to)
    for nl in (0.0, 0.25, 1.0):
        S.grown(main, "F01", "F01d", f"nonlin{nl}", {"topology": "layered", "nonlinearity": nl}, LIN,
                level="full" if nl == 0.0 else "core", fold="fold" if nl == 0.0 else None)
    for k, bits in ((2, 0), (8, 0), (8, 2)):
        S.grown(main, "F01", "F01e", f"rank{k}_bits{bits}", {"topology": "bottleneck", "bottleneck_dim": k,
                                                             "bottleneck_bits": bits, "rounds": 1}, LIN)

    # weight decay is a separate control (addendum section 3): none / factor-wise (uniform on every tensor) /
    # on the composite map, for a real layer factorised in place (node_factorization: the composite is the layer)
    for wd, dm in ((0.0, "uniform"), (1e-4, "uniform"), (1e-4, "composite")):
        S.grown(main, "F01", "F01a", f"node_factor_decay{wd}_{dm}", {"topology": "node_factorization", "rounds": 1},
                {"method": "fold", "post_updates": 0, "speed_updates": 0},
                train_over={"weight_decay": wd, "decay_mode": dm})
    S.na("C1", "decay panel", "controls of the decay panel use uniform decay at the same strength (f0 has no factors)")

    # ------------------------------------------------------------------ F02 what is cut
    for where in ("early", "middle", "late"):
        S.grown(main, "F02", "F02a", where, {"topology": "layered", "cut_where": where}, LIN,
                level="full" if where == "middle" else "core")
    for ch in (1, 8, None):
        S.grown(main, "F02", "F02b", f"channels{ch}", {"topology": "layered", "channels": ch}, LIN)
    for sub in ("branch", "skip", None):
        S.grown(seq, "F02", "F02c", f"subset_{sub}", {"topology": "layered", "cut_subset": sub, "cut_where": 0}, LIN)
    for w in ("probe:z", "probe_random:z"):
        S.grown(compose, "F02", "F02d", w.replace(":", "_"), {"topology": "layered", "cut_where": w}, LIN)
    S.grown(main, "F02", "F02e", "inside_implant", {"topology": "recursive"}, LIN)
    S.grown(main, "F02", "F02e", "fresh_cut", {"topology": "layered"}, LIN)

    # ------------------------------------------------------------------ F03 topology at measured cost
    # equal added cost PER ROUND (three rounds each): parameters of, or forward MACs of, one 64-32-64 residual
    # implant; programs inserting several modules per round split the round's budget between them
    for panel, match in (("params", {"width_match": "params", "width_match_target": 4192}),
                         ("macs", {"width_match": "macs", "width_match_target": 4096})):
        for var, tag, g in (("F03a", "serial", {"topology": "layered"}),
                            ("F03b", "siblings", {"topology": "parallel", "merge": "sum"}),
                            ("F03d", "diamond", {"topology": "diamond"}),
                            ("F03e", "chunks4", {"topology": "chunked", "n_chunks": 4})):
            S.grown(main, "F03", var, f"{tag}3_equal_{panel}", {**g, "rounds": 3, **match}, LIN)
    S.grown(main, "F03", "F03c", "tree", {"topology": "tree_depth2", "rounds": 3}, LIN, level="full")
    S.na("F03c", main.name, "a depth-2 tree doubles its insertions per round: it is reported at its actual added "
                            "cost (export accounting), not in the equal-cost panels")
    S.na("C6", "F03b", "branch merging averages nonlinear siblings and then removes the group: it does not "
                       "return the trained function to f0 exactly, so it is no exact-folding control")

    # ------------------------------------------------------------------ F04 who learns
    # F04b: the implant first learns alone (a zero-output implant frozen from the start would stay zero),
    # then it is frozen and only the backbone learns
    for var, to in (("F04a", {"freeze": "original_frozen"}),
                    ("F04b", {"freeze": "implants_frozen", "freeze_schedule": "release",
                              "release_after": max(1, upr // 4)}),
                    ("F04c", {"freeze": "none"}),
                    ("F04d", {"freeze_schedule": "alternate", "freeze_period": max(1, upr // 4)})):
        # the freeze policy names the GROWTH phase; the contraction (dissipation) trains every surviving tensor
        S.grown(main, "F04", var, "layered2_growth_policy__contraction_trains_all", {"topology": "layered"}, LIN,
                train_over=to, level="full" if var == "F04c" else "core")
    # F04e + mechanism B: route learning into the implant, release, repair from later checkpoints
    for rel in (max(1, upr // 4), max(1, (3 * upr) // 4)):
        # the release schedule restarts with each round's new implant: both snapshots lie after the
        # release of round 2, at half and all of the remaining round (time since release (upr - rel)/2, upr - rel - 1)
        snaps = [upr + rel + max(1, (upr - rel) // 2), 2 * upr - 1]
        to = {"freeze_schedule": "release", "release_after": rel, "snapshot_at": snaps}
        for s in S.seeds:
            traj, tcfg = S.history(main, {"topology": "recursive_branch"}, s, train_over=to)
            contrast = f"F04e|{main.name}|release{rel}"
            t = S.contract(traj, tcfg, LIN, S.design("F04", "F04e", "treated", contrast), "W7_F04_F04e")
            S.controls(main, s, t, contrast, "F04", "F04e", "W7_F04_F04e", train_over=to)
            for st in [f"snap_{u}" for u in snaps] + ["final"]:
                for reg in ("readout", "adjacent", "full"):
                    S.contract(traj, tcfg, {"region": reg, "deletion": "all", "budget_multiplier": 0.25},
                               S.design("M_B", "M_B", f"repair_{reg}@{st}", f"M_B|{main.name}|release{rel}"),
                               "W7_M_B_dependence_spreading", tags={"parent_stage": st}, kind="repair")
    S.na("M_B", main.name, "random-routing control not implemented: routing is defined by the implant region; "
                           "the equal-update unconstrained control is F04c")

    # ------------------------------------------------------------------ F05 routes back to compactness
    rb = {"topology": "recursive_branch"}
    S.grown(main, "F05", "F05a", "abrupt_repair", rb, {"method": "abrupt", "speed_updates": 0})
    for s in S.seeds:
        traj, tcfg = S.history(main, rb, s)
        contrast = f"F05a|{main.name}|repair_full"
        t = S.contract(traj, tcfg, {"region": "full", "deletion": "all", "budget_multiplier": 0.5},
                       S.design("F05", "F05a", "treated", contrast), "W7_F05_F05a", kind="repair")
        S.controls(main, s, t, contrast, "F05", "F05a", "W7_F05_F05a")
    for meth in ("linear", "cosine"):
        for speed in (max(1, upr // 10), upr):
            for tgt in ("task", "expanded"):
                S.grown(main, "F05", "F05b", f"{meth}_speed{speed}_{tgt}", rb,
                        {"method": meth, "speed_updates": speed, "target": tgt},
                        level="full" if (meth, speed, tgt) == ("linear", upr, "task") else "core")
    for resc in (False, True):
        S.grown(main, "F05", "F05c", f"bypass_rescale{resc}", rb,
                {"method": "stochastic_bypass", "bypass_keep": 0.5, "bypass_rescale": resc})
    # F05d: local replacement between pegs; the immediate (no global update) risk is logged per cycle
    # (pre_finetune_*), the global repair is the separately costed fine-tune
    S.cop(deep, "F05", "F05d", "local_replace", {"task_kind": "cycles", "cycles": 2, "n_pearls": 3,
                                                  "cycle_pegs": "fixed"}, {"dim": 8})
    S.grown(main, "F05", "F05e", "group_removal", {"topology": "cancel_pair", "rounds": 1},
            {"method": "group_removal"})
    for s in S.seeds:
        traj, tcfg = S.history(main, {"topology": "cancel_pair", "rounds": 1}, s)
        S.contract(traj, tcfg, {"family": "exhaustive", "compare_greedy": True}, None, "W7_F05_F05e",
                   kind="deletion", tags={"parent_stage": "final"})
    S._mark("F05e", "W7_F05_F05e")

    # ------------------------------------------------------------------ F06 history
    U, Cb = 2 * upr, max(4, upr // 2)
    for K in (1, 2, 4, 8):
        S.cycles(main, "F06", "F06a", f"cycles{K}_equal_total",
                 {"topology": "layered", "rounds": K, "contract_every": 1, "updates_per_round": max(1, U // K),
                  "contract_updates": max(1, Cb // K)}, level="full" if K == 2 else "core")
        S.cycles(main, "F06", "F06a", f"cycles{K}_scaling",
                 {"topology": "layered", "rounds": K, "contract_every": 1, "updates_per_round": upr,
                  "contract_updates": max(1, Cb // 2)})
    S.cycles(main, "F06", "F06a", "roundtrip_no_training",
             {"topology": "node_factorization", "rounds": 2, "contract_every": 1, "updates_per_round": 0,
              "contract_updates": 0})
    for sched in ("incremental", "all_at_once"):
        S.grown(main, "F06", "F06b", sched, {"topology": "tree_depth2", "rounds": 3, "schedule": sched}, LIN)
    for order in ("oldest_first", "newest_first", "ancestor_first", "descendant_first", "joint"):
        S.grown(main, "F06", "F06c", order, {"topology": "tree_depth2", "rounds": 3},
                {"method": "abrupt", "order": order, "speed_updates": 0})
    # F06d: expansion early / middle / late along a saved baseline trajectory, equal remaining opportunity
    nb = S.base_updates(main)
    for frac in (0.25, 0.5, 0.75):
        u = max(1, int(round(nb * frac)))
        rem = max(1, nb - u)
        for s in S.seeds:
            contrast = f"F06d|{main.name}|at{frac}"
            traj, tcfg = S.history(main, {"topology": "recursive_branch", "rounds": 1, "updates_per_round": rem},
                                   s, extra={"tags": {"f0_stage": f"snap_{u}"}},
                                   base_train_over={"snapshot_at": [u]})
            t = S.contract(traj, tcfg, LIN, S.design("F06", "F06d", "treated", contrast), "W7_F06_F06d")
            S.controls(main, s, t, contrast, "F06", "F06d", "W7_F06_F06d", start_stage=f"snap_{u}",
                       base=tcfg["parents"]["baseline"])
    # policies (compound: the fixed schedule contracts every round, the trigger at most every 2 rounds) and
    # V3-11b matched factors: a fixed schedule with the same maximum interval, and a replay of the realised
    # adaptive schedule without its probes (same contractions, no selection)
    f06e = {"topology": "layered", "rounds": 4, "updates_per_round": max(1, U // 4),
            "contract_updates": max(1, Cb // 4)}
    for tag, extra in (("policy_fixed_every1", {"contract_every": 1}),
                       ("fixed_every2_matched_max_interval", {"contract_every": 2}),
                       ("policy_damage_trigger", {"contract_every": 2, "contract_trigger": "damage",
                                                  "contract_threshold": 0.05})):
        S.cycles(main, "F06", "F06e", tag, {**f06e, **extra})
    for s in S.seeds:
        src, _ = S.history(main, {**f06e, "contract_every": 2, "contract_trigger": "damage",
                                  "contract_threshold": 0.05}, s,
                           extra={"design": S.design("F06", "F06e", "treated",
                                                     f"F06e|{main.name}|policy_damage_trigger")},
                           block="W7_F06_F06e")
        contrast = f"F06e|{main.name}|replay_of_damage_trigger"
        rid, _ = S.history(main, {**f06e, "contract_every": 2, "contract_trigger": "replay"}, s,
                           extra={"design": S.design("F06", "F06e", "treated", contrast)}, block="W7_F06_F06e",
                           parents_extra={"schedule": src})
        S._mark("F06e", "W7_F06_F06e")
        S.controls(main, s, rid, contrast, "F06", "F06e", "W7_F06_F06e")

    # ------------------------------------------------------------------ F07 pegs (CoP chains)
    for k in (2, 8, 32):
        S.cop(deep, "F07", "F07a", f"dim{k}", {"task_kind": "chain", "n_pearls": 3}, {"dim": k, "mode": "none"},
              level="full" if k == 8 else "core")
    for b in (1, 2, 3, 4, 8, 16):
        S.cop(deep, "F07", "F07b", f"bits{b}", {"task_kind": "chain", "n_pearls": 3},
              {"dim": 1, "mode": "uniform", "bits": b})
    # V3-07: interface-map adaptation x width schedule (recalibration held on in all four cells), so a paired
    # maps comparison has identical per-peg dimensions, bits and narrowing events; plus the compound presets
    for maps in ("frozen", "learned"):
        for width in ("constant", "narrowed"):
            S.cop(deep, "F07", "F07c", f"maps_{maps}_width_{width}",
                  {"task_kind": "cycles", "cycles": 2, "n_pearls": 3, "cycle_pegs": "relearned",
                   "cycle_peg_maps": maps, "cycle_peg_width": width, "cycle_peg_recalibrate": "yes"},
                  {"dim": 8, "mode": "uniform", "bits": 4})
    for pg in ("fixed", "relearned"):
        S.cop(deep, "F07", "F07c", f"compound_preset_{pg}", {"task_kind": "cycles", "cycles": 2, "n_pearls": 3,
                                                              "cycle_pegs": pg}, {"dim": 8, "mode": "uniform", "bits": 4})
    for mode, ck in (("independent", "aligned"), ("joint", "learned")):
        S.cop(compose, "F07", "F07d", f"{mode}_{ck}", {"task_kind": "alternatives", "n_pearls": 4,
                                                        "alt_training": mode, "code_kind": ck,
                                                        "alt_kinds": ["mlp_small", "linear"]},
              {"dim": 4, "mode": "uniform", "bits": 2}, controls=False)
    rr = max(1, upr // 4)
    S.cop(deep, "F07", "F07e", "plain_blocks2", {"task_kind": "chain", "n_pearls": 3, "route_blocks": 2,
                                                 "route_repair_updates": rr}, {"dim": 8, "mode": "uniform", "bits": 2})
    S.cop(deep, "F07", "F07e", "repeat2", {"task_kind": "chain", "n_pearls": 3, "route_repair_updates": rr},
          {"dim": 8, "mode": "uniform", "bits": 2, "redundancy": 2})
    S.cop(deep, "F07", "F07e", "repeat2_erasure", {"task_kind": "chain", "n_pearls": 3, "route_repair_updates": rr},
          {"dim": 8, "mode": "uniform", "bits": 2, "redundancy": 2, "route_dropout": 0.5})
    S.cop(deep, "F07", "F07e", "plain_blocks2_erasure", {"task_kind": "chain", "n_pearls": 3, "route_blocks": 2,
                                                         "route_repair_updates": rr},
          {"dim": 8, "mode": "uniform", "bits": 2, "route_dropout": 0.5})

    # ------------------------------------------------------------------ F08 recovery boundary
    for s in S.seeds:
        traj, tcfg = S.history(main, rb, s)
        ladder = [("F08a", "readout", {}), ("F08b", "incident_adapters", {}), ("F08b", "adjacent1", {"adjacent_radius": 1}),
                  ("F08b", "adjacent2", {"adjacent_radius": 2}), ("F08c", "full_reset", {"opt_state": "reset"}),
                  ("F08c", "full_preserve", {"opt_state": "preserve"}),
                  ("F08d", "fresh_labels", {"region": "fresh_original", "target": "task"}),
                  ("F08d", "fresh_teacher", {"region": "fresh_original", "target": "expanded"}),
                  ("F08e", "access_calibration", {"data_access": "calibration", "target": "expanded"}),
                  ("F08e", "access_train", {"data_access": "train"}),
                  ("F08e", "access_train_teacher", {"data_access": "train", "target": "expanded"}),
                  ("F08e", "access_fresh", {"data_access": "fresh"}),
                  ("F08e", "access_checkpoint", {"data_access": "checkpoint"})]
        for var, tag, extra in ladder:
            region = extra.pop("region", None) or {"readout": "readout", "incident_adapters": "incident_adapters"}.get(
                tag, "adjacent" if tag.startswith("adjacent") else "full")
            contrast = f"{var}|{main.name}|{tag}"
            sec = {"region": region, "deletion": "all", "budget_multiplier": 0.5, **extra}
            t = S.contract(traj, tcfg, sec, S.design("F08", var, "treated", contrast), f"W7_F08_{var}", kind="repair")
            S.controls(main, s, t, contrast, "F08", var, f"W7_F08_{var}",
                       level="full" if tag == "full_reset" else "core", traj=traj)

    # ------------------------------------------------------------------ F09 data demands
    for n in (256, 2048, 16384):
        c = Cell(f"teacher3_n{n}", lambda s, n=n: teacher_data(3, n, s), MLP(64))
        S.grown(c, "F09", "F09a", f"n{n}", rb, LIN, level="full" if n == 2048 else "core")
    for depth in (1, 3, 6):
        c = Cell(f"teacher{depth}_n2048", lambda s, d=depth: teacher_data(d, 2048, s), MLP(64))
        S.grown(c, "F09", "F09b", f"depth{depth}", rb, LIN)
    for tn in (0.0, 0.5):
        c = Cell(f"teacher3_n2048_noise{tn}", lambda s, t=tn: teacher_data(3, 2048, s, target_noise=t), MLP(64))
        S.grown(c, "F09", "F09c", f"target_noise{tn}", rb, LIN)
    for rho in (0.5, 0.9):
        c = Cell(f"shortcut_rho{rho}", {"name": "shortcut", "n_train": 4096, "params": {"rho_train": rho}}, MLP(64))
        S.grown(c, "F09", "F09c", f"shortcut_rho{rho}", rb, LIN)
    for prev in (0.01, 0.05, 0.2):
        for samp in ("uniform", "group_balanced"):
            c = Cell(f"shortcut_prev{prev}", {"name": "shortcut", "n_train": 4096,
                                              "params": {"rare_prevalence": prev}}, MLP(64))
            S.grown(c, "F09", "F09d", f"prev{prev}_{samp}", rb, LIN, train_over={"sampler": samp})
    for qa in (-1, 1):
        for op in ("bit", "xor_next", "two_bits"):
            c = Cell(f"delayed_query_{op}_q{qa}", {"name": "delayed_query", "n_train": 8192,
                                                    "params": {"n_bits": 12, "query_op": op}},
                     MLP(64, depth=4, query_at_layer=qa))
            S.cop(c, "F09", "F09e", f"query_at{qa}_{op}", {"task_kind": "chain", "n_pearls": 2},
                  {"dim": 4, "mode": "uniform", "bits": 2})

    # ------------------------------------------------------------------ F10 what the implant is good at
    S.grown(main, "F10", "F10a", "mlp_residual", {"topology": "layered"}, LIN, level="full")
    S.grown(img, "F10", "F10b", "conv3x3", {"topology": "layered", "kernel": 3}, LIN, level="full")
    S.grown(img, "F10", "F10b", "conv1x1", {"topology": "layered", "kernel": 1}, LIN)
    S.grown(seq, "F10", "F10c", "attention", {"topology": "layered", "mixer": "attention"}, LIN)
    S.grown(seq, "F10", "F10c", "pointwise_control", {"topology": "layered", "mixer": "mlp"}, LIN)
    for km in ("mixing_random", "mixing_aligned"):
        S.grown(compose, "F10", "F10d", km, {"topology": "known_module", "known_module": km, "known_access": "cut",
                                             "rounds": 1}, LIN)
    pre = max(5, upr // 2)
    for tag, extra in (("frozen", {"known_trainable": False}), ("partial", {"known_partial": True}),
                       ("full", {"known_trainable": True})):
        S.grown(compose, "F10", "F10e", f"specialist_{tag}", {"topology": "known_module", "known_module": "pretrained",
                                                              "pretrain_updates": pre, "rounds": 1, **extra}, LIN)

    # ------------------------------------------------------------------ mechanisms
    # A: transfer from a temporary helper reading the causal / shortcut / random features
    for sel in ("causal", "shortcut", "random"):
        S.grown(short, "M_A", "M_A", f"bridge_{sel}", {"topology": "bridge", "bridge_inputs": sel, "rounds": 1}, LIN)
    # C: cut-level transplants between f0 and the post-cycle model (both directions), aligned or not
    for cell, ck in ((main, "post_act"), (img, "post_act")):
        for s in S.seeds:
            cyc, ccfg = S.history(cell, {"topology": "layered", "rounds": 2, "contract_every": 1,
                                         "contract_updates": max(1, Cb // 2)}, s)
            base = ccfg["parents"]["baseline"]
            for (up, ups), (dn, dns) in (((base, "baseline"), (cyc, "final")), ((cyc, "final"), (base, "baseline"))):
                for al in ("none", "affine"):
                    for bn in ((False, True) if cell.image else (False,)):
                        B.add({"kind": "transplant", "data": cell.data(s), "model": cell.model,
                               "train": B.train(cell.data(s)["name"]), "seeds": {"optimizer": s},
                               "parents": {"upstream": up, "downstream": dn},
                               "transplant": {"upstream_stage": ups, "downstream_stage": dns, "cut_kind": ck,
                                              "cut_where": "middle", "align": al, "bn_recalibrate": bn},
                               "design": S.design("M_C", "M_C", f"{'f0' if up == base else 'post'}_up_{al}"
                                                  f"{'_bn' if bn else ''}", f"M_C|{cell.name}"),
                               "wave": W, "block": "W7_M_C_transplants", "wp": ["M_C"]},
                              "W7_M_C_transplants", [up, dn])
        S._mark("M_C", "W7_M_C_transplants")
    # D: removal order in a tree and a reconvergent graph, equal repair budget; rare cases tracked
    for cell, topo in ((main, "tree_depth2"), (main, "diamond"), (short, "tree_depth2")):
        for order in ("descendant_first", "ancestor_first", "oldest_first", "newest_first", "joint"):
            S.grown(cell, "M_D", "M_D", f"{topo}_{order}", {"topology": topo, "rounds": 3 if topo != "diamond" else 2},
                    {"method": "abrupt", "order": order, "speed_updates": 0}, block="W7_M_D_order")
    # E: later queries (decoders on training codes; input re-access control in the result)
    for mode, dim, bits in (("uniform", 2, 1), ("uniform", 4, 2), ("uniform", 8, 4), ("none", 4, 0)):
        for tb in (1, 2):
            # 12 bits: 4096 inputs; train 2048, val 512, test 1024 disjoint, plus the complete domain
            c = Cell(f"later_query_tb{tb}", {"name": "later_query", "n_train": 2048, "n_val": 512, "n_test": 1024,
                                             "params": {"n_bits": 12, "task_bits": tb}}, MLP(64, depth=6))
            S.cop(c, "M_E", "M_E", f"{mode}_d{dim}_b{bits}", {"task_kind": "chain", "n_pearls": 3},
                  {"dim": dim, "mode": mode, **({"bits": bits} if mode == "uniform" else {})},
                  block="W7_M_E_later_queries")
    # F: repeated cycles, then a common continuation for every export (durability)
    # nested cycles need contract_every >= 2; same / moving run at 1 (compound) AND at 2 (matched contraction
    # frequency and total contraction training, V3-11a)
    for cut, ce in (("same", 1), ("moving", 1), ("nested", 2), ("same", 2), ("moving", 2)):
        topo = "recursive" if cut == "nested" else "layered"
        g = {"topology": topo, "rounds": 4, "contract_every": ce, "cycle_cut": cut,
             "updates_per_round": max(1, U // 4), "contract_updates": max(1, Cb // 2)}
        for s in S.seeds:
            contrast = f"M_F|{main.name}|{cut}_every{ce}"
            rid, cfg = S.history(main, g, s, extra={"design": S.design("M_F", "M_F", "treated", contrast)},
                                 block="W7_M_F_cycles")
            ctl = S.controls(main, s, rid, contrast, "M_F", "M_F", "W7_M_F_cycles")
            # durability: the same continuation schedule from every endpoint
            dur = f"M_F|{main.name}|{cut}_every{ce}|durability"
            for arm, start in (("treated", rid), ("C1", ctl[0])):
                B.add({"kind": "continue", "data": main.data(s), "model": main.model, "train": B.train("teacher"),
                       "seeds": {"optimizer": s}, "parents": {"start": start},
                       "continue": {"start": "start", "start_stage": "final", "budget": "fixed", "updates": upr,
                                    "inherit_state": False, "eval_at": [upr // 4, upr // 2]},
                       "design": S.design("M_F", "M_F", arm, dur, "updates"), "wave": W,
                       "block": "W7_M_F_cycles", "wp": ["M_F"]}, "W7_M_F_cycles", [start])
        S._mark("M_F", "W7_M_F_cycles")
    # G: alternating helpers vs both / single / stochastic at the same cost, then remove both
    for cell in (main, short):
        for sch in ("alternate", "both", "single", "stochastic"):
            S.grown(cell, "M_G", "M_G", f"helpers_{sch}", {"topology": "twin_helpers", "helper_schedule": sch,
                                                           "helper_period": max(1, upr // 8), "rounds": 1},
                    {"method": "abrupt", "speed_updates": 0}, block="W7_M_G_helpers")
    # H: a temporary bridge across one interface, retired into one peg / every peg / kept as an adapter
    hb = {"temp_channel": 8, "temp_on": "middle", "temp_open_updates": max(1, upr // 4)}
    S.cop(deep, "M_H", "M_H", "no_bridge", {"task_kind": "chain", "n_pearls": 3}, {"dim": 4},
          block="W7_M_H_bridge")
    for tt in ("all", "peg", "pegs", "adapter"):
        S.cop(deep, "M_H", "M_H", f"bridge_{tt}", {"task_kind": "chain", "n_pearls": 3},
              {"dim": 4, **hb, "temp_target": tt}, block="W7_M_H_bridge")

    # ------------------------------------------------------------------ target regimes T0 / T1 (noisy targets)
    for regime, to in (("T0", {"target": "teacher_star"}), ("T1", {})):
        # partially learned f0 (a quarter of the baseline budget) improving toward the known teacher
        to = {**to, "baseline_updates": max(10, S.base_updates(noisy) // 4)}
        for var, g, cont in (("F01a", {"topology": "linear_factor"}, {"method": "fold", "post_updates": 0,
                                                                      "speed_updates": 0}),
                             ("F03c", {"topology": "tree_depth2", "rounds": 3}, LIN),
                             ("F10a", {"topology": "layered"}, LIN)):
            S.grown(noisy, var[:3], var, f"regime_{regime}", g, cont, train_over=to, regime=regime,
                    level="full", block=f"W7_targets_{regime}")
        S.cycles(noisy, "F06", "F06a", f"cycles2_regime_{regime}",
                 {"topology": "layered", "rounds": 2, "contract_every": 1, "updates_per_round": max(1, U // 2),
                  "contract_updates": max(1, Cb // 2)}, train_over=to, regime=regime, block=f"W7_targets_{regime}")

    # ------------------------------------------------------------------ two sizes x two complexities
    for n in (512, 8192):
        for depth in (2, 5):
            c = Cell(f"teacher{depth}_n{n}", lambda s, n=n, d=depth: teacher_data(d, n, s), MLP(64))
            for var, g, cont in (("F01a", {"topology": "linear_factor"}, {"method": "fold", "post_updates": 0,
                                                                          "speed_updates": 0}),
                                 ("F03c", {"topology": "tree_depth2", "rounds": 3}, LIN),
                                 ("F05b", rb, {"method": "linear", "speed_updates": upr}),
                                 ("F10a", {"topology": "layered"}, LIN)):
                S.grown(c, var[:3], var, f"size_complexity_n{n}_d{depth}", g, cont, block="W7_size_complexity")
            S.cycles(c, "F06", "F06a", f"size_complexity_n{n}_d{depth}",
                     {"topology": "layered", "rounds": 2, "contract_every": 1, "updates_per_round": max(1, U // 2),
                      "contract_updates": max(1, Cb // 2)}, block="W7_size_complexity")

    # ------------------------------------------------------------------ mandatory crosses
    # 1. foldability x conditioning x optimizer
    for tie in ("enforced", "untied"):
        for cond in (1.0, 100.0):
            for opt in ("adamw", "sgd"):
                to = {"optimizer": opt, **({"momentum": 0.9, "lr": 0.01} if opt == "sgd" else {}),
                      **({"precision": "fp64"} if cond > 10 else {})}
                S.grown(main, "X1", "X1", f"{tie}_cond{cond}_{opt}",
                        {"topology": "inverse_pair", "inverse_kind": "linear", "inverse_cond": cond, "tie": tie,
                         "rounds": 1}, {"method": "fold", "post_updates": 0, "speed_updates": 0}, train_over=to,
                        block="W7_cross_fold_cond_opt")
    # 2. recursive depth x co-adaptation duration x contraction order
    for R in (2, 4):
        for co in ("short", "long"):
            snap = max(1, upr // 4)
            for order in ("descendant_first", "ancestor_first"):
                for s in S.seeds:
                    traj, tcfg = S.history(main, {"topology": "tree_depth2", "rounds": R}, s,
                                           train_over={"snapshot_at": [R * upr - upr + snap]})
                    contrast = f"X2|{main.name}|R{R}_{co}_{order}"
                    st = f"snap_{R * upr - upr + snap}" if co == "short" else "final"
                    t = S.contract(traj, tcfg, {"method": "abrupt", "order": order, "speed_updates": 0},
                                   S.design("X2", "X2", "treated", contrast), "W7_cross_depth_coadapt_order",
                                   tags={"parent_stage": st})
                    S.controls(main, s, t, contrast, "X2", "X2", "W7_cross_depth_coadapt_order",
                               train_over={"snapshot_at": [R * upr - upr + snap]})
    # 3. peg bits x semantic drift (interface-map adaptation at a CONSTANT width) x query timing
    for b in (1, 4):
        for maps in ("frozen", "learned"):
            for qa in (-1, 1):
                c = Cell(f"delayed_query_q{qa}", {"name": "delayed_query", "n_train": 8192, "params": {"n_bits": 12}},
                         MLP(64, depth=6, query_at_layer=qa))
                S.cop(c, "X3", "X3", f"bits{b}_maps_{maps}_q{qa}",
                      {"task_kind": "cycles", "cycles": 2, "n_pearls": 3, "cycle_pegs": "relearned",
                       "cycle_peg_maps": maps, "cycle_peg_width": "constant", "cycle_peg_recalibrate": "yes"},
                      {"dim": 4, "mode": "uniform", "bits": b}, block="W7_cross_bits_drift_query")
    # 4. shortcut correlation x branch specialization x contraction schedule
    for rho in (0.7, 0.95):
        c = Cell(f"shortcut_rho{rho}", {"name": "shortcut", "n_train": 4096, "params": {"rho_train": rho}}, MLP(64))
        for topo in ("parallel", "specialized"):
            for speed in (max(1, upr // 10), upr):
                S.grown(c, "X4", "X4", f"rho{rho}_{topo}_speed{speed}", {"topology": topo, "rounds": 2},
                        {"method": "linear", "speed_updates": speed}, block="W7_cross_shortcut_branch_schedule")
    # 5. cut location x joint / local training x repair scope
    for where in ("early", "late"):
        for fr in ("none", "original_frozen"):
            for s in S.seeds:
                traj, tcfg = S.history(main, {"topology": "layered", "cut_where": where}, s,
                                       train_over={"freeze": fr})
                for reg in ("readout", "adjacent", "full"):
                    contrast = f"X5|{main.name}|{where}_{fr}_{reg}"
                    t = S.contract(traj, tcfg, {"region": reg, "deletion": "all", "budget_multiplier": 0.5},
                                   S.design("X5", "X5", "treated", contrast), "W7_cross_cut_training_repair",
                                   kind="repair")
                    S.controls(main, s, t, contrast, "X5", "X5", "W7_cross_cut_training_repair",
                               train_over={"freeze": fr})

    # ================================================================== v5 additions (review of v4)
    # review P0: a known teacher that is EXACTLY realisable in the student (relu, width 64, depth 4 = MLP(64)): every f0
    # of this cell carries a verified constructive witness (witness.json); the tanh teacher cells stay as the
    # approximation-mismatch condition.  Review P1: the backbone-frozen fold control separates the fold itself (an exact
    # algebraic rewrite of an affine implant into existing weights) from learned repair by the backbone.
    wit = Cell("witness_relu4_w64_n2048", lambda s: teacher_data(4, 2048, s, width=64, activation="relu"), MLP(64))
    FOLD = {"method": "fold", "post_updates": 0, "speed_updates": 0}
    S.grown(wit, "F01", "F01a", "witness_linear_factor", {"topology": "linear_factor"}, FOLD, level="full",
            block="W7_v5_witness")
    for cell in (wit, main):
        S.grown(cell, "F01", "F01a", "linear_factor_backbone_frozen", {"topology": "linear_factor"}, FOLD,
                train_over={"freeze": "original_frozen"}, block="W7_v5_fold_frozen_backbone")
    S.grown(wit, "F01", "F01d", "witness_nonlin0.25", {"topology": "layered", "nonlinearity": 0.25}, LIN,
            block="W7_v5_witness")
    S.grown(wit, "F05", "F05b", "witness_linear_speed_upr", rb, {"method": "linear", "speed_updates": upr},
            block="W7_v5_witness")
    S.cycles(wit, "F06", "F06a", "witness_cycles2",
             {"topology": "layered", "rounds": 2, "contract_every": 1, "updates_per_round": max(1, U // 2),
              "contract_updates": max(1, Cb // 2)}, block="W7_v5_witness")
    witn = Cell("witness_relu4_w64_n2048_noise0.5",
                lambda s: teacher_data(4, 2048, s, width=64, activation="relu", target_noise=0.5), MLP(64))
    for regime, to in (("T0", {"target": "teacher_star"}), ("T1", {})):
        to = {**to, "baseline_updates": max(10, S.base_updates(witn) // 4)}
        for var, g, cont in (("F01a", {"topology": "linear_factor"}, FOLD), ("F10a", {"topology": "layered"}, LIN)):
            S.grown(witn, var[:3], var, f"witness_regime_{regime}", g, cont, train_over=to, regime=regime,
                    level="full", block=f"W7_v5_witness_targets_{regime}")

    # review P2: exact finite-interface benchmark on complete cubes.  A: direct delayed-query learning; B: original
    # task (x_0, or the parity of two bits) with later-query retention.  One peg of K = dim x 1 bit; a
    # temporary bridge across it (gradual / abrupt retirement) and a permanent bridge (diagnostic: the bound does
    # not apply while a bypass exists) at one K per n, with matched total updates.
    fin_up = max(20, upr)
    hbf = {"temp_channel": 8, "temp_open_updates": max(1, fin_up // 4)}
    for n_b in (3, 4, 5):
        for fam, dname, extra_p, qa in (("FIN_A", "delayed_query", {}, 1),
                                        ("FIN_B", "later_query", {"task_bits": 1}, None),
                                        ("FIN_B", "later_query", {"task_bits": 2}, None)):
            if fam == "FIN_B" and extra_p["task_bits"] == 2 and n_b > 4:
                S.na("FIN_B", f"parity2_n{n_b}", "the exact task-preserving optimum for a parity task is enumerated "
                                                 "for n <= 4 only (labelled codebooks)")
                continue
            data = {"name": dname, "n_train": "full", "params": {"n_bits": n_b, "split_mode": "complete", **extra_p}}
            model = MLP(32, depth=3, **({"query_at_layer": qa} if qa is not None else {}))
            tagd = f"{dname}{'_parity2' if extra_p.get('task_bits') == 2 else ''}_n{n_b}"
            c = Cell(tagd, data, model)
            for K in range(1, min(3, n_b) + 1):
                arms = [("no_bridge", {})]
                if K == min(2, n_b):
                    arms += [("bridge_gradual", dict(hbf)), ("bridge_abrupt", {**hbf, "temp_anneal_updates": 1}),
                             ("bridge_permanent_diagnostic", {**hbf, "temp_target": "adapter"})]
                for arm, hb in arms:
                    S.cop(c, "FIN", fam, f"K{K}_{arm}", {"task_kind": "chain", "n_pearls": 2, "global_updates": fin_up},
                          {"dim": K, "mode": "uniform", "bits": 1, **hb}, block="W7_v5_finite_interfaces",
                          controls=False)

    # review P3: paired interface-locality experiment on one f0 per seed (same placement, schedule and data stream)
    loc_cop = {"task_kind": "locality", "n_pearls": 5, "global_updates": 2 * upr, "local_updates": max(1, upr // 2),
               "locality_repair_updates": max(1, upr // 2), "locality_checkpoints": [0.25, 0.5, 1.0]}
    for arm, peg in (("none", {"mode": "none"}), ("continuous", {"mode": "none"}),
                     ("continuous_stabilized", {"mode": "none"}), ("finite_learned", {"mode": "uniform", "bits": 2}),
                     ("finite_stabilized", {"mode": "uniform", "bits": 2})):
        for s in S.seeds:
            B.cop(deep.data(s), deep.model, {**loc_cop, "locality_interface": arm}, {"dim": 8, **peg}, s, W,
                  "W7_v5_locality", ["LOC"], train_over=deep.train_over,
                  extra={"design": S.design("LOC", "LOC", arm, f"LOC|{deep.name}|dim8")})
        S._mark("LOC", "W7_v5_locality")

    # review P5: the full 2 x 2 (f0 / post-cycle upstream x downstream) at matched adapter families and budgets
    fams = ["identity", "orthogonal", "affine", "mlp", "affine_task", "mlp_task"]
    for cell in (main, short, img):
        for s in S.seeds:
            cyc, ccfg = S.history(cell, {"topology": "layered", "rounds": 2, "contract_every": 1,
                                         "contract_updates": max(1, Cb // 2)}, s)
            base = ccfg["parents"]["baseline"]
            for bn in ((False, True) if cell.image else (False,)):
                B.add({"kind": "transplant", "data": cell.data(s), "model": cell.model,
                       "train": B.train(cell.data(s)["name"]), "seeds": {"optimizer": s},
                       "parents": {"upstream": base, "downstream": cyc},
                       "transplant": {"upstream_stage": "baseline", "downstream_stage": "final", "cut_kind": cell.ck,
                                      "cut_where": "middle", "design": "grid", "align_families": fams,
                                      "adapter_updates": max(1, upr // 2), "bn_recalibrate": bn},
                       "design": S.design("M_C", "M_C", f"grid{'_bn' if bn else ''}", f"M_C_grid|{cell.name}"),
                       "wave": W, "block": "W7_v5_transplant_grid", "wp": ["M_C"]}, "W7_v5_transplant_grid", [base, cyc])
            # work-matched reference: model A is f0 continued for the cycle history's measured updates (C1), so the
            # new-versus-old contrast is not just extra training
            c1 = B.add({"kind": "continue", "data": cell.data(s), "model": cell.model,
                        "train": B.train(cell.data(s)["name"], **{k: v for k, v in cell.train_over.items()
                                                                   if k in CTRL_TRAIN_KEYS}),
                        "seeds": {"optimizer": s, "insertion": s}, "parents": {"baseline": base, "treated": cyc},
                        "continue": {"budget": "parent_updates", "budget_parent": "treated", "start_stage": "baseline"},
                        "wave": W, "block": "W7_v5_transplant_grid", "wp": ["M_C"]}, "W7_v5_transplant_grid",
                       [base, cyc])
            B.add({"kind": "transplant", "data": cell.data(s), "model": cell.model,
                   "train": B.train(cell.data(s)["name"]), "seeds": {"optimizer": s},
                   "parents": {"upstream": c1, "downstream": cyc},
                   "transplant": {"upstream_stage": "final", "downstream_stage": "final", "cut_kind": cell.ck,
                                  "cut_where": "middle", "design": "grid", "align_families": fams,
                                  "adapter_updates": max(1, upr // 2), "bn_recalibrate": False},
                   "design": S.design("M_C", "M_C", "grid_vs_C1", f"M_C_grid_vsC1|{cell.name}"),
                   "wave": W, "block": "W7_v5_transplant_grid", "wp": ["M_C"]}, "W7_v5_transplant_grid", [c1, cyc])
    S._mark("M_C", "W7_v5_transplant_grid")
    # review P4 needs no new jobs: every trajectory evaluates its exhaustive deletion landscape (deletion.family auto,
    # up to max_exhaustive_atoms); the static dependence game is computed from those files in the analysis

    # ------------------------------------------------------------------ declared inapplicable cells
    S.na("F01a", "resnet", "padded k x k convolutions inside residual blocks do not fold back to one kernel "
                           "in general; the conv factorization cell uses the plain CNN")
    S.na("F02c", main.name, "an MLP cut has a single consumer: residual-branch versus skip-path cuts need a "
                            "residual architecture (sequence transformer cell)")
    S.na("F10c", main.name, "attention needs positions: covered on the sequence transformer cell")
    S.na("F07e", "cycles/alternatives", "redundant routes are implemented for chain jobs")
    S.na("C8", "vector/sequence cells", "pruning-and-regrowth is the CNN confirmation control (image cell only)")
    S.na("C3", "cycles / CoP / repair endpoints", "a from-scratch expanded graph exists for growth histories "
                                                  "contracted by dissipation only")
