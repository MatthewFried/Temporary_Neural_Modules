"""Task metrics, function drift and preservation criteria (spec section 13).

All functions take raw model outputs (logits / regression values) so every
metric can be recomputed from saved predictions.
"""
from __future__ import annotations

import math
from typing import Optional

import torch
import torch.nn.functional as F

EPS = 1e-12


def wilson(k: float, n: int, z: float = 1.96) -> tuple[float, float]:
    if n == 0:
        return (float("nan"), float("nan"))
    p = k / n
    den = 1 + z * z / n
    c = (p + z * z / (2 * n)) / den
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return (c - h, c + h)


def cluster_ratio_ci(k_i: torch.Tensor, n_i: torch.Tensor, z: float = 1.96) -> tuple[float, float]:
    """95% interval for sum(k_i)/sum(n_i) with clusters i as the independent
    units (linearised ratio estimator with the S/(S-1) small-sample factor)."""
    S = int(k_i.numel())
    N = float(n_i.sum())
    if S < 2 or N == 0:
        return (float("nan"), float("nan"))
    r = float(k_i.sum()) / N
    var = S / (S - 1) * float(((k_i - r * n_i) ** 2).sum()) / (N * N)
    h = z * math.sqrt(max(var, 0.0))
    return (r - h, r + h)


def paired_delta(out: torch.Tensor, ref: torch.Tensor, y: torch.Tensor, task: str) -> dict:
    """Paired per-unit difference (candidate minus reference) on the same
    examples, with its standard error.  Units: examples (vector tasks) or
    sequences (sequence tasks: the per-sequence sums are the clustered unit).
    Quantities: correctness (classification: 1[correct]), squared error
    (regression, mean over output dims) and cross-entropy loss (classification)."""
    out, ref = out.double(), ref.double()
    res = {}
    if task == "regression":
        yy = y.double().view_as(out)
        d = ((out - yy) ** 2 - (ref - yy) ** 2).reshape(out.shape[0], -1).mean(1)
        res["sq_error"] = _mean_se(d)
        res["unit"] = "example"
        return res
    if task == "seq_classification":
        mask = y != -100
        yy = y.clamp_min(0)
        ca = (out.argmax(-1) == yy) & mask
        cb = (ref.argmax(-1) == yy) & mask
        la = F.cross_entropy(out.transpose(1, 2), yy, reduction="none") * mask
        lb = F.cross_entropy(ref.transpose(1, 2), yy, reduction="none") * mask
        n_i = mask.sum(1).double().clamp_min(1)
        res["correct"] = _mean_se((ca.double().sum(1) - cb.double().sum(1)) / n_i)
        res["loss"] = _mean_se((la.sum(1) - lb.sum(1)) / n_i)
        res["unit"] = "sequence (per-sequence mean over target positions)"
        return res
    yl = y.long()
    res["correct"] = _mean_se((out.argmax(-1) == yl).double() - (ref.argmax(-1) == yl).double())
    res["loss"] = _mean_se(F.cross_entropy(out, yl, reduction="none") - F.cross_entropy(ref, yl, reduction="none"))
    res["unit"] = "example"
    return res


def _mean_se(d: torch.Tensor) -> dict:
    n = int(d.numel())
    mean = float(d.mean()) if n else float("nan")
    se = float(d.std(unbiased=True) / math.sqrt(n)) if n > 1 else float("nan")
    return {"mean": mean, "se": se, "n": n}


def _flatten_seq(out: torch.Tensor, y: torch.Tensor):
    mask = y != -100
    return out[mask], y[mask], mask


def task_metrics(out: torch.Tensor, y: torch.Tensor, task: str, groups: Optional[torch.Tensor] = None,
                 target_scale: float = 1.0) -> dict:
    out = out.float()
    m: dict = {"n": int(y.shape[0])}
    if task == "regression":
        yy = y.float().view_as(out)
        mse = ((out - yy) ** 2).mean().item()
        m.update({"loss": mse, "mse": mse, "nmse": mse / (target_scale ** 2 + EPS)})
        if groups is not None:
            for gval in torch.unique(groups).tolist():
                sel = groups == gval
                m[f"mse_g{gval}"] = ((out[sel] - yy[sel]) ** 2).mean().item()
                m[f"n_g{gval}"] = int(sel.sum())
            gm = [m[f"mse_g{gv}"] for gv in torch.unique(groups).tolist()]
            m["worst_group_mse"], m["balanced_group_mse"] = max(gm), sum(gm) / len(gm)
        return m
    if task == "seq_classification":
        o, t, mask = _flatten_seq(out, y)
        ce = F.cross_entropy(o, t).item() if t.numel() else float("nan")
        corr = (o.argmax(-1) == t).float()
        # exact match over sequences: all target positions correct
        per_seq_ok = torch.ones(y.shape[0], dtype=torch.bool, device=y.device)
        pred = out.argmax(-1)
        wrong = (pred != y) & mask
        per_seq_ok &= ~wrong.any(dim=1)
        k = int(corr.sum().item())
        n = int(t.numel())
        # token accuracy is a point metric; its interval treats SEQUENCES as the independent
        # units (cluster-robust ratio estimator), since tokens within a sequence are dependent
        k_i = ((pred == y) & mask).sum(1).double()
        n_i = mask.sum(1).double()
        m.update({"loss": ce, "acc": k / max(n, 1), "n_positions": n, "n_sequences": int(y.shape[0]),
                  "seq_exact": per_seq_ok.float().mean().item(), "seq_exact_ci95": wilson(int(per_seq_ok.sum()),
                                                                                          int(y.shape[0])),
                  "acc_ci95_cluster": cluster_ratio_ci(k_i, n_i)})
        return m
    # classification
    yl = y.long()
    ce = F.cross_entropy(out, yl).item()
    pred = out.argmax(-1)
    corr = (pred == yl)
    k, n = int(corr.sum()), int(yl.numel())
    p = torch.softmax(out, -1)
    conf, _ = p.max(-1)
    m.update({"loss": ce, "acc": k / n, "acc_ci95": wilson(k, n), "ece": ece(conf, corr)})
    top2 = out.topk(min(2, out.shape[-1]), -1).values
    if top2.shape[-1] == 2:
        m["mean_margin"] = (top2[:, 0] - top2[:, 1]).mean().item()
    if groups is not None:
        for gval in torch.unique(groups).tolist():
            sel = groups == gval
            kk, nn = int(corr[sel].sum()), int(sel.sum())
            m[f"acc_g{gval}"] = kk / max(nn, 1)
            m[f"acc_g{gval}_ci95"] = wilson(kk, nn)
            m[f"n_g{gval}"] = nn
        accs = [m[f"acc_g{gv}"] for gv in torch.unique(groups).tolist()]
        m["worst_group_acc"] = min(accs)
        m["balanced_group_acc"] = sum(accs) / len(accs)        # balanced test: every group weighted equally
    return m


def ece(conf: torch.Tensor, corr: torch.Tensor, bins: int = 15) -> float:
    e = torch.zeros((), device=conf.device)
    edges = torch.linspace(0, 1, bins + 1, device=conf.device)
    for i in range(bins):
        sel = (conf > edges[i]) & (conf <= edges[i + 1])
        if sel.any():
            e += sel.float().mean() * (conf[sel].mean() - corr[sel].float().mean()).abs()
    return float(e)


def drift(a: torch.Tensor, b: torch.Tensor, task: str, y: Optional[torch.Tensor] = None,
          target_scale: float = 1.0) -> dict:
    """Function difference between two output sets on the same inputs."""
    a, b = a.double(), b.double()
    if task == "regression":
        mse = ((a - b) ** 2).mean().item()
        return {"out_mse": mse, "nmse": mse / (target_scale ** 2 + 1e-8),
                "max_abs": (a - b).abs().max().item()}
    if task == "seq_classification":
        mask = (y != -100) if y is not None else torch.ones(a.shape[:2], dtype=torch.bool, device=a.device)
        a, b = a[mask], b[mask]
    la, lb = torch.log_softmax(a, -1), torch.log_softmax(b, -1)
    pa, pb = la.exp(), lb.exp()
    kl = (pa * (la - lb)).sum(-1).mean().item()
    mlog = torch.log((pa + pb) / 2 + 1e-300)
    js = 0.5 * ((pa * (la - mlog)).sum(-1) + (pb * (lb - mlog)).sum(-1)).mean().item()
    dis = (a.argmax(-1) != b.argmax(-1)).double().mean().item()
    # logit MSE after removing per-example mean (softmax is shift invariant); scale caveat recorded
    ca, cb = a - a.mean(-1, keepdim=True), b - b.mean(-1, keepdim=True)
    lmse = ((ca - cb) ** 2).mean().item()
    out = {"kl": kl, "js": js, "disagreement": dis, "centered_logit_mse": lmse,
           "max_abs_logit": (a - b).abs().max().item()}
    if a.shape[-1] >= 2:
        ta, tb = a.topk(2, -1).values, b.topk(2, -1).values
        out["margin_change"] = ((ta[:, 0] - ta[:, 1]) - (tb[:, 0] - tb[:, 1])).abs().mean().item()
    return out


def equivalence(a: torch.Tensor, b: torch.Tensor) -> dict:
    """Numerical identity check: absolute and scale-normalised errors."""
    a, b = a.double(), b.double()
    err = (a - b).abs()
    scale = a.abs().mean().item()
    return {"max_abs": err.max().item(), "mean_abs": err.mean().item(), "scale": scale,
            "max_rel": err.max().item() / (scale + 1e-30)}


def headline(m: dict, task: str) -> float:
    """Single task-risk number R(f) used for Delta_A (lower is better)."""
    if task == "regression":
        return m["mse"]
    return m["loss"]


def error_rate(m: dict, task: str) -> Optional[float]:
    if task == "regression":
        return None
    return 1.0 - m["acc"]
