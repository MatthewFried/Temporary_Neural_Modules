"""Training loop with explicit random streams, freeze policies, optimizer-state
policy across graph edits, distillation targets, and exact resume.

Resume contract (T19): the trainer state (global/segment step, epoch,
permutation and position, generator states, optimizer state) is checkpointed
atomically; resuming reproduces the uninterrupted run on CPU (bitwise in our
tests) and never repeats or skips an update.
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

import torch
import torch.nn.functional as F

from ..data.augment import augment_batch
from ..data.bundle import DataBundle, Partition
from ..graph.graph import GraphNet, GraphError
from ..utils import torch_gen, interrupted, tensor_hash
from . import metrics as M


# =============================================================================
# Freeze policies (T13)
# =============================================================================

FREEZE_POLICIES = ("none", "original_frozen", "implants_frozen", "upstream_only", "downstream_only",
                   "upstream_plus_implants", "downstream_plus_implants")


def region_sets(g: GraphNet, ref_implant: Optional[str]) -> dict[str, set[str]]:
    """Partition live parameterised nodes into backbone-upstream / implant /
    backbone-downstream relative to an implant (the latest cut)."""
    live = g.live_nodes()
    implant_nodes = {n for n in live if g.nodes[n].owner is not None}
    backbone = {n for n in live if g.nodes[n].owner is None}
    if ref_implant is None or ref_implant not in g.implants:
        return {"backbone": backbone, "implants": implant_nodes, "upstream": set(), "downstream": set()}
    imp = g.implants[ref_implant]
    region = g.region(ref_implant)
    up = g.ancestors(imp.entry) | {imp.entry}
    down = set()
    for n in region:
        down |= g.descendants(n)
    down -= region
    return {"backbone": backbone, "implants": implant_nodes, "upstream": up & backbone,
            "downstream": down & backbone}


def trainable_pkeys(g: GraphNet, policy: str, ref_implant: Optional[str] = None,
                    extra_frozen: set[str] = frozenset(), extra_trainable: Optional[set[str]] = None) -> set[str]:
    """Return trainable pkeys; raise if a shared pkey straddles frozen and trainable regions."""
    if policy not in FREEZE_POLICIES:
        raise ValueError(policy)
    R = region_sets(g, ref_implant)
    live = g.live_nodes()
    if policy == "none":
        allowed = live
    elif policy == "original_frozen":
        allowed = R["implants"]
    elif policy == "implants_frozen":
        allowed = R["backbone"]
    elif policy == "upstream_only":
        allowed = R["upstream"]
    elif policy == "downstream_only":
        allowed = R["downstream"]
    elif policy == "upstream_plus_implants":
        allowed = R["upstream"] | R["implants"]
    else:
        allowed = R["downstream"] | R["implants"]
    if extra_trainable is not None:
        allowed = allowed & extra_trainable
    pk_nodes: dict[str, set[str]] = {}
    for n in live:
        pk = g.nodes[n].pkey
        if pk is not None:
            pk_nodes.setdefault(pk, set()).add(n)
    out = set()
    for pk, ns in pk_nodes.items():
        inside = ns & allowed
        if inside and inside != ns:
            raise GraphError(f"shared parameters {pk} used by nodes inside and outside the trainable region "
                             f"({sorted(inside)} vs {sorted(ns - inside)}); choose a policy that keeps ties intact")
        if inside and pk not in extra_frozen:
            out.add(pk)
    return out


def _has_bn(m) -> bool:
    return any(isinstance(x, (torch.nn.BatchNorm1d, torch.nn.BatchNorm2d)) for x in m.modules())


def apply_trainable(g: GraphNet, pkeys: set[str], bn_stats: str = "follow") -> None:
    """Set requires_grad and choose which normalisation layers keep their running
    statistics fixed (eval mode during training):
      follow  BN statistics update iff the BN parameters are trainable (v2 behaviour)
      frozen  every BN keeps its statistics (eval mode) during training
      update  every BN updates its statistics, also when its parameters are frozen."""
    g.frozen_bn = set()
    for pk, m in g.mods.items():
        on = pk in pkeys
        for p in m.parameters():
            p.requires_grad_(on)
        if _has_bn(m) and (bn_stats == "frozen" or (bn_stats == "follow" and not on)):
            g.frozen_bn.add(pk)
    # partially trainable modules (e.g. a specialist whose last layer only learns): named tensors kept frozen
    for pk, names in (g.meta.get("frozen_param_names") or {}).items():
        if pk in g.mods:
            for nm, p in g.mods[pk].named_parameters():
                if nm in names:
                    p.requires_grad_(False)
    g.train(g.training)


def ordered_params(g: GraphNet, pkeys: set[str]) -> list[tuple[str, torch.nn.Parameter]]:
    out = []
    for pk in sorted(pkeys, key=lambda s: int(s[1:])):
        for name, p in sorted(g.mods[pk].named_parameters(), key=lambda t: t[0]):
            out.append((f"{pk}.{name}", p))
    return out


# =============================================================================
# Optimizer
# =============================================================================

def make_optimizer(params: list[torch.nn.Parameter], tcfg: dict,
                   no_decay: Optional[list[torch.nn.Parameter]] = None) -> torch.optim.Optimizer:
    """`no_decay`: parameters placed in a second group with weight_decay 0 (composite decay mode)."""
    if not params and not no_decay:
        return None
    groups = [{"params": list(params)}] if params else []
    if no_decay:
        groups.append({"params": list(no_decay), "weight_decay": 0.0})
    if tcfg["optimizer"] == "sgd":
        return torch.optim.SGD(groups, lr=tcfg["lr"], momentum=tcfg["momentum"], weight_decay=tcfg["weight_decay"])
    return torch.optim.AdamW(groups, lr=tcfg["lr"], betas=tuple(tcfg["betas"]), weight_decay=tcfg["weight_decay"])


# =============================================================================
# Composite weight decay (strengthening F01 / Section 3)
# =============================================================================

FACTOR_CONSTRUCTIONS = ("linear_factor", "node_factorization", "node_split")


def composite_maps(g: GraphNet) -> list[dict]:
    """Factorised linear implants whose composite map is penalised in composite
    decay mode: [{'implant', 'kind' (product | sum), 'pkeys': [...] in data order}].
    node_factorization / linear_factor: M = W2 W1; node_split: M = Wa + Wb."""
    out = []
    for iid, imp in g.implants.items():
        if imp.construction not in FACTOR_CONSTRUCTIONS:
            continue
        if any(g.nodes[n].op == "conv" for n in imp.nodes if n in g.nodes):
            from ..experiments.context import Unsupported
            raise Unsupported("train.decay_mode=composite is implemented for linear factors (not conv factors)")
        lin = [n for n in g.topo_order() if g.nodes[n].owner == iid and g.nodes[n].op == "linear"]
        if imp.construction == "node_split":
            out.append({"implant": iid, "kind": "sum", "pkeys": [g.nodes[n].pkey for n in lin]})
        elif len(lin) == 2:
            out.append({"implant": iid, "kind": "product", "pkeys": [g.nodes[n].pkey for n in lin]})
    return out


def composite_penalty(g: GraphNet, maps: list[dict], wd: float) -> torch.Tensor:
    """(wd / 2) * sum ||M||_F^2 (weights; biases are not decayed as a composite)."""
    tot = None
    for m in maps:
        Ws = [g.mods[pk].weight for pk in m["pkeys"]]
        M = (Ws[1] @ Ws[0]) if m["kind"] == "product" else sum(Ws)
        v = (M ** 2).sum()
        tot = v if tot is None else tot + v
    return 0.5 * wd * tot if tot is not None else None


# =============================================================================
# Training compute (MACs) and freeze schedules
# =============================================================================

def forward_macs(g: GraphNet, T: int, cache: dict) -> int:
    """Analytic forward MACs per example of the effective graph.  Cached per set of
    zero gates; an entry is valid only while the graph's execution plan is the
    same object (every edit rebuilds the plan; holding the reference keeps ids unique)."""
    from ..graph.accounting import count_macs
    plan = getattr(g, "_plan", None)
    key = (tuple(sorted(k for k, v in g.gate_vals.items() if v == 0)), int(T))
    hit = cache.get(key)
    if plan is not None and hit is not None and hit[0] is plan:
        return hit[1]
    v = int(count_macs(g, T)["macs"])
    if plan is not None:
        cache[key] = (plan, v)
    return v


def backward_aware_macs(g: GraphNet, T: int, cache: dict) -> int:
    """Backward-aware training MACs per example (an estimate, V3-09): the forward pass, the weight
    gradient of every node whose parameters train, and the input gradient of every node that has a
    training tensor upstream (backpropagation stops below the earliest one).  Same per-node analytic
    counts as forward_macs; elementwise work is not counted."""
    from ..graph.accounting import count_macs, effective_live
    plan = getattr(g, "_plan", None)
    trainable_pk = tuple(sorted(pk for pk, m in g.mods.items() if any(p.requires_grad for p in m.parameters())))
    key = ("bwd", tuple(sorted(k for k, v in g.gate_vals.items() if v == 0)), int(T), trainable_pk)
    hit = cache.get(key)
    if plan is not None and hit is not None and hit[0] is plan:
        return hit[1]
    cm = count_macs(g, T)
    per = cm["by_node"]
    live = effective_live(g)
    tp = set(trainable_pk)
    trains = {n for n in live if g.nodes[n].pkey in tp}
    up: dict[str, bool] = {}
    for n in g.topo_order(live):
        up[n] = any((i in trains) or up.get(i, False) for i in g.nodes[n].inputs if i in live)
    v = int(cm["macs"] + sum(per.get(n, 0) for n in trains) + sum(per.get(n, 0) for n in live if up[n]))
    if plan is not None:
        cache[key] = (plan, v)
    return v


def training_mac_parts(g: GraphNet, T: int, cache: dict, held: dict) -> dict:
    """v45: the backward-aware training MACs per example split into their parts (an analytic estimate: the same
    per-node counts as forward_macs, linear-type nodes only, elementwise work not counted):
      forward               every effective node, once;
      input_grad            the input gradient of every node with a training tensor upstream (backpropagation stops
                            below the earliest one);
      param_grad            the parameter gradient of every node whose parameters require gradients: what autograd
                            computes.  A parameter HOLD (train.freeze_inputs, train.freeze_backbone) keeps
                            requires_grad on and zeroes the gradient after backward, so its gradient is computed;
      param_grad_discarded  the part of param_grad that a hold zeroes (held: pkey -> fraction of that node's
                            parameter-gradient work discarded; a held column is its share of the input columns).
    forward + input_grad + param_grad equals backward_aware_macs."""
    from ..graph.accounting import count_macs, effective_live
    plan = getattr(g, "_plan", None)
    trainable_pk = tuple(sorted(pk for pk, m in g.mods.items() if any(p.requires_grad for p in m.parameters())))
    key = ("parts", tuple(sorted(k for k, v in g.gate_vals.items() if v == 0)), int(T), trainable_pk,
           tuple(sorted(held.items())))
    hit = cache.get(key)
    if plan is not None and hit is not None and hit[0] is plan:
        return dict(hit[1])
    cm = count_macs(g, T)
    per = cm["by_node"]
    live = effective_live(g)
    tp = set(trainable_pk)
    trains = {n for n in live if g.nodes[n].pkey in tp}
    up: dict[str, bool] = {}
    for n in g.topo_order(live):
        up[n] = any((i in trains) or up.get(i, False) for i in g.nodes[n].inputs if i in live)
    v = {"forward": int(cm["macs"]),
         "input_grad": int(sum(per.get(n, 0) for n in live if up[n])),
         "param_grad": int(sum(per.get(n, 0) for n in trains)),
         "param_grad_discarded": int(round(sum(per.get(n, 0) * float(held.get(g.nodes[n].pkey, 0.0))
                                               for n in trains)))}
    if plan is not None:
        cache[key] = (plan, dict(v))
    return v


MAC_PARTS = ("forward", "input_grad", "param_grad", "param_grad_discarded")


def compute_counters(state: dict) -> dict:
    """v45: the trainer's cumulative compute counters (copied into checkpoints that carry no trainer state)."""
    return {"train_macs": int(state.get("train_macs", 0)), "train_macs_bwd": int(state.get("train_macs_bwd", 0)),
            "mac_parts": {k: int((state.get("mac_parts") or {}).get(k, 0)) for k in MAC_PARTS},
            "global_step": int(state.get("global_step", 0)), "examples": int(state.get("examples", 0))}


def schedule_policies(tcfg: dict) -> list[str]:
    """Freeze policies of the phases of train.freeze_schedule."""
    if tcfg["freeze_schedule"] == "alternate":
        return ["original_frozen", "implants_frozen"]           # implant-only, backbone-only
    if tcfg["freeze_schedule"] == "release":
        return ["original_frozen", tcfg["freeze"]]              # routed into the implant, then released
    return [tcfg["freeze"]]


def schedule_phase(tcfg: dict, seg_step: int) -> int:
    if tcfg["freeze_schedule"] == "alternate":
        return (seg_step // int(tcfg["freeze_period"])) % 2
    if tcfg["freeze_schedule"] == "release":
        return 0 if seg_step < int(tcfg["release_after"]) else 1
    return 0


def lr_at(step: int, total: int, base: float, schedule: str, warmup: int) -> float:
    if warmup and step < warmup:
        return base * (step + 1) / warmup
    if schedule == "cosine" and total > 0:
        t = (step - warmup) / max(1, total - warmup)
        return base * 0.5 * (1 + math.cos(math.pi * min(1.0, t)))
    return base


class NumericalDivergence(RuntimeError):
    """A local (manual) optimisation loop produced a non-finite loss or parameters.  The job fails
    with this reason; it is never reported as complete (Trainer runs instead stop and mark the
    endpoint diverged)."""


class LocalOpt:
    """The training policy of the `train` config section (optimizer, lr, betas,
    momentum, weight decay, lr schedule + warmup over the loop length, gradient
    clipping) for manual loops (CoP local fits, adapters, Theseus, pretraining).
    One implementation shared with Trainer (make_optimizer / lr_at), so a local
    fit never silently uses different hyper-parameters.  Precision: local loops
    run in the dtype of the modules they train; kind=cop is fp32 only (checked in
    config).  `resolved()` is recorded with every result."""

    def __init__(self, params: list, tcfg: dict, total: int, lr: Optional[float] = None):
        self.params = [p for p in params if p.requires_grad]
        self.t = tcfg
        self.total = int(total)
        self.base_lr = float(lr if lr is not None else tcfg["lr"])
        self.opt = make_optimizer(self.params, tcfg) if self.params else None
        self.updates = 0

    def step(self, loss: torch.Tensor, k: int) -> None:
        if self.opt is None:
            raise GraphError("local loop has no trainable parameters")
        lr = lr_at(k, self.total, self.base_lr, self.t["lr_schedule"], self.t["warmup"])
        for gp in self.opt.param_groups:
            gp["lr"] = lr
        if not bool(torch.isfinite(loss.detach()).all()):
            raise NumericalDivergence(f"local loop: non-finite loss before update {self.updates + 1}")
        self.opt.zero_grad(set_to_none=True)
        loss.backward()
        if self.t["grad_clip"]:
            torch.nn.utils.clip_grad_norm_(self.params, self.t["grad_clip"])
        self.opt.step()
        self.updates += 1
        # numerical boundary after every local update (V3-02): local fits feed the exported model, and they
        # have no later endpoint training to absorb a failure, so a non-finite update fails the job
        if not bool(torch.isfinite(torch.stack([p_.detach().abs().amax().float() for p_ in self.params])).all()):
            raise NumericalDivergence(f"local loop: non-finite parameters after update {self.updates}")

    def state_dict(self) -> dict:
        return {"opt": None if self.opt is None else self.opt.state_dict(), "updates": self.updates}

    def load_state_dict(self, d: dict) -> None:
        if d.get("opt") is not None and self.opt is not None:
            self.opt.load_state_dict(d["opt"])
        self.updates = int(d.get("updates", 0))

    def resolved(self) -> dict:
        o = self.opt
        return {"optimizer": type(o).__name__ if o else None, "lr": self.base_lr,
                "defaults": {k: (list(v) if isinstance(v, tuple) else v) for k, v in (o.defaults if o else {}).items()
                             if k in ("lr", "betas", "momentum", "weight_decay", "eps", "nesterov")},
                "lr_schedule": self.t["lr_schedule"], "warmup": self.t["warmup"], "grad_clip": self.t["grad_clip"],
                "total_updates": self.total}


def local_policy(tcfg: dict) -> dict:
    """What a LocalOpt built from this train config uses (for result files)."""
    keys = ("optimizer", "lr", "betas", "momentum", "weight_decay", "lr_schedule", "warmup", "grad_clip", "precision")
    return {k: tcfg[k] for k in keys}


# =============================================================================
# Losses
# =============================================================================

def teacher_star_target_available(bundle) -> bool:
    """T0 needs the known compact teacher's clean output: y_clean for regression,
    the teacher's logits for classification."""
    if bundle.task == "regression":
        return bundle.train.y_clean is not None or bundle.fresh_sampler is not None
    return bundle.task == "classification" and isinstance(bundle.meta.get("teacher"), dict)


def teacher_star_loss(out: torch.Tensor, batch, X: dict, bundle, T: float) -> torch.Tensor:
    if bundle.task == "regression":
        if batch.y_clean is None:
            raise ValueError("train.target=teacher_star needs clean targets (y_clean)")
        return F.mse_loss(out, batch.y_clean.to(out.dtype).view_as(out))
    from ..data.synthetic import teacher_forward
    if not isinstance(bundle.meta.get("teacher"), dict):
        raise ValueError("train.target=teacher_star needs a dataset with a known teacher")
    with torch.no_grad():
        logits = teacher_forward(bundle.meta["teacher"], X["x"]).to(out.dtype)
    return distill_loss(out, logits, bundle.task, T)


def task_loss(out: torch.Tensor, y: torch.Tensor, task: str) -> torch.Tensor:
    if task == "regression":
        return F.mse_loss(out, y.to(out.dtype).view_as(out))
    if task == "seq_classification":
        return F.cross_entropy(out.reshape(-1, out.shape[-1]), y.reshape(-1), ignore_index=-100)
    return F.cross_entropy(out, y.long())


def distill_loss(out: torch.Tensor, t: torch.Tensor, task: str, T: float = 1.0,
                 y: Optional[torch.Tensor] = None) -> torch.Tensor:
    if task == "regression":
        return F.mse_loss(out, t.to(out.dtype))
    if task == "seq_classification":
        mask = (y != -100) if y is not None else torch.ones(out.shape[:2], dtype=torch.bool, device=out.device)
        out, t = out[mask], t[mask]
    ls = torch.log_softmax(out / T, -1)
    lt = torch.log_softmax(t.to(out.dtype) / T, -1)
    return (lt.exp() * (lt - ls)).sum(-1).mean() * (T * T)


# =============================================================================
# Trainer
# =============================================================================

@dataclass
class Segment:
    name: str
    updates: int
    target: str = "task"                     # task | expanded | original | custom
    teacher: Optional[GraphNet] = None
    extra_loss: Optional[Callable] = None    # (model, ctx, batch, step) -> tensor
    batch_ctx: Optional[Callable] = None     # (batch) -> dict merged into ctx (e.g. grad masks)
    on_step: Optional[Callable] = None       # (trainer, seg_step) -> None, e.g. gate schedules
    eval_points: list[int] = field(default_factory=list)
    eval_fn: Optional[Callable] = None       # (trainer, seg_step) -> dict
    lr: Optional[float] = None
    target_fn: Optional[Callable] = None     # custom target: (batch) -> tensor
    post_step: Optional[Callable] = None     # (trainer, seg_step) -> None, right after optimizer.step (e.g. masks)
    trainable: Optional[set] = None          # pkeys that learn in this segment; the optimizer keeps covering every
                                             # configured tensor (frozen ones get no gradient and keep their state)
    freeze_inputs: Optional[str] = None      # v43: this segment's train.freeze_inputs (None: the job's setting)
    freeze_backbone: Optional[str] = None    # v44: this segment's train.freeze_backbone (None: the job's setting)


class Trainer:
    def __init__(self, model: GraphNet, bundle: DataBundle, tcfg: dict, seeds: dict, device: str,
                 log: Optional[Callable[[dict], None]] = None, stream_key: str = ""):
        self.model = model
        self.bundle = bundle
        self.t = tcfg
        self.device = device
        self.log = log or (lambda r: None)
        self.task = bundle.task
        self.dtype = torch.float64 if tcfg["precision"] == "fp64" else torch.float32
        self.gens = {
            "minibatch": torch_gen(seeds["minibatch"], "minibatch", stream_key),
            "augmentation": torch_gen(seeds["augmentation"], "augmentation", stream_key),
            "fresh": torch_gen(seeds["minibatch"], "fresh", stream_key),
        }
        N = len(bundle.train)
        self.B = min(int(tcfg["batch_size"]), N)
        self.state = {"global_step": 0, "examples": 0, "epoch": 0, "pos": 0, "perm": None,
                      "segment": None, "seg_step": 0, "pkeys": None, "ref_implant": None, "policy": "none",
                      # v3: measured training compute, divergence, freeze-schedule phases
                      "train_macs": 0, "train_macs_bwd": 0, "teacher_macs": 0, "diverged": False,
                      "diverged_at": None,
                      "phase_pkeys": None, "phase": 0}
        self.T = int(bundle.test.X["x"].shape[1]) if bundle.layout == "seq" else 1
        self._macs_cache: dict = {}
        self._teacher_macs_cache: dict = {}
        self.composite: list[dict] = []
        self.opt = None
        self.curves: list[dict] = []
        self.timing = {"train_seconds": 0.0}
        self.policy_extra_frozen: set[str] = set()
        self.extra_trainable: Optional[set[str]] = None
        # parameters trained alongside the model but not part of it (training-only readouts); a second
        # optimizer param group, rebuilt identically by configure() and load_state_dict()
        self.extra_params: list[torch.nn.Parameter] = []

    def _first_layer(self):
        """the first backbone layer (the first module in topological order owned by no addition): (pkey, weight)."""
        for n in self.model.topo_order(self.model.live_nodes()):
            nd = self.model.nodes[n]
            if nd.pkey is not None and nd.owner is None and any(True for _ in self.model.mods[nd.pkey].parameters()):
                return nd.pkey, getattr(self.model.mods[nd.pkey], "weight", None)
        return None, None

    def _input_freeze(self, seg_mode: Optional[str] = None) -> Optional[dict]:
        """v42 (train.freeze_inputs): the first backbone layer's weight, the input columns of the named group and
        their current values (held there for this segment: no gradient, restored after every update, so neither
        momentum nor weight decay moves them).  None when off.  v43: a segment may set its own mode (a compact
        continuation's freeze schedule); the values are those at the segment's start, which in a frozen prefix
        are the job's start values (the column never moved)."""
        mode = seg_mode if seg_mode is not None else self.t.get("freeze_inputs", "none")
        if mode == "none":
            return None
        lay = (self.bundle.meta or {}).get("feature_layout") or {}
        if mode != "shortcut" or "shortcut" not in lay or lay.get("input_rotation"):
            raise GraphError("train.freeze_inputs=shortcut needs an unrotated shortcut feature layout")
        pk, W = self._first_layer()
        n_in = int(self.bundle.train.X["x"].shape[1])
        # v65: a convolution's input channels are its dim 1 too (weight out x in x kh x kw): the shortcut channel's
        # kernels are held the same way
        if W is None or W.dim() not in (2, 4) or int(W.shape[1]) != n_in or \
                (W.dim() == 4) != (self.bundle.layout == "img"):
            raise GraphError(f"train.freeze_inputs: the first backbone layer {pk} does not read the {n_in} inputs")
        cols = torch.tensor([int(lay["shortcut"])], device=W.device)
        return {"pkey": pk, "W": W, "cols": cols, "values": W.detach()[:, cols].clone()}

    def _backbone_hold(self, seg_mode: Optional[str] = None) -> Optional[dict]:
        """v44 (train.freeze_backbone=downstream): every backbone parameter outside the first layer, held at its
        value at the segment start (no gradient; restored after every update, so momentum and decay cannot move
        it); the first layer and the additions train.  None when off."""
        mode = seg_mode if seg_mode is not None else self.t.get("freeze_backbone", "none")
        if mode == "none":
            return None
        if mode != "downstream":
            raise GraphError(f"train.freeze_backbone={mode!r}")
        pk0, _ = self._first_layer()
        pks = []
        for n in self.model.topo_order(self.model.live_nodes()):
            nd = self.model.nodes[n]
            if nd.pkey is not None and nd.owner is None and nd.pkey != pk0 and nd.pkey not in pks:
                pks.append(nd.pkey)
        ps = [p for pk in pks for p in self.model.mods[pk].parameters()]
        if not ps:
            raise GraphError("train.freeze_backbone=downstream: no backbone layer after the first")
        return {"pkeys": pks, "params": ps, "values": [p.detach().clone() for p in ps]}

    def _norm_groups(self) -> Optional[dict]:
        """v43 (train.log_update_norms): the tensors whose per-update change is measured: the backbone, its first
        layer's weight, that weight's causal and shortcut input columns (shortcut data with unrotated inputs), and
        the additions.  None when off."""
        if not self.t.get("log_update_norms", False):
            return None
        bb, ad = [], []
        for n in self.model.topo_order(self.model.live_nodes()):
            nd = self.model.nodes[n]
            if nd.pkey is None:
                continue
            (bb if nd.owner is None else ad).extend(p for p in self.model.mods[nd.pkey].parameters())
        pk, W = self._first_layer()
        g = {"backbone": bb, "additions": ad, "first_layer": [W] if W is not None else []}
        lay = (self.bundle.meta or {}).get("feature_layout") or {}
        cols = {}
        if W is not None and "shortcut" in lay and "causal" in lay and not lay.get("input_rotation"):
            c0, c1 = lay["causal"]
            cols = {"first_layer_causal": list(range(int(c0), int(c1))), "first_layer_shortcut": [int(lay["shortcut"])]}
        return {"groups": g, "W": W, "cols": cols}

    def _update_norms_before(self, ng: dict) -> dict:
        return {k: [p.detach().clone() for p in ps] for k, ps in ng["groups"].items()}

    def _update_norms_after(self, ng: dict, before: dict) -> None:
        """the Euclidean norm of this update for each group, added to the job's cumulative path length (trainer
        state, so it is checkpointed and survives a resume); the first 32 updates of each segment are kept."""
        st = self.state
        acc = st.setdefault("update_norms", {"n_updates": 0, "path": {}, "early": []})
        out = {}
        with torch.no_grad():
            for k, ps in ng["groups"].items():
                out[k] = float(sum(float(((p.detach().double() - b.double()) ** 2).sum())
                                   for p, b in zip(ps, before[k])) ** 0.5) if ps else 0.0
            if ng["W"] is not None:
                d = ng["W"].detach().double() - before["first_layer"][0].double()
                for k, cs in ng["cols"].items():
                    out[k] = float(d[:, cs].norm())
        for k, v in out.items():
            acc["path"][k] = acc["path"].get(k, 0.0) + v
        acc["n_updates"] += 1
        if st["seg_step"] < 32:
            acc["early"].append({"global_step": int(st["global_step"]), "seg_step": int(st["seg_step"]), **out})

    def _trainable_now(self) -> dict:
        """Parameters that currently require gradients and are in the optimizer (what an update can move)."""
        in_opt = {id(p_) for gp in self.opt.param_groups for p_ in gp["params"]} if self.opt is not None else set()
        mods = sorted(pk for pk, m in self.model.mods.items()
                      if any(p_.requires_grad and id(p_) in in_opt for p_ in m.parameters()))
        n = sum(p_.numel() for p_ in self.model.parameters() if p_.requires_grad and id(p_) in in_opt)
        n_all = sum(p_.numel() for p_ in self.model.parameters())
        return {"trainable_params": int(n), "total_params": int(n_all), "trainable_modules": mods}

    def _build_opt(self, params: list) -> Optional[torch.optim.Optimizer]:
        """Composite decay mode: the factor tensors of factorised implants go to a
        weight_decay = 0 group and their composite map is penalised in the loss."""
        nd: list = []
        if self.t.get("decay_mode", "uniform") == "composite":
            self.composite = composite_maps(self.model)
            fac = {id(p) for m in self.composite for pk in m["pkeys"] for p in self.model.mods[pk].parameters()}
            nd = [p for p in params if id(p) in fac]
            params = [p for p in params if id(p) not in fac]
        else:
            self.composite = []
        opt = make_optimizer(params, self.t, nd)
        if opt is not None and self.extra_params:
            opt.add_param_group({"params": list(self.extra_params)})
        return opt

    def _record_names(self, named: list) -> None:
        """Parameter names in optimizer order (state_dict index -> 'pkey.name'), so that a later job can
        carry this optimizer's state to the tensors that survive an edit (repair.opt_state=preserve)."""
        name_of = {id(p): n for n, p in named}
        self.opt_param_names = [] if self.opt is None else \
            [name_of.get(id(p), "<extra>") for gp in self.opt.param_groups for p in gp["params"]]

    def _phase_sets(self, policy: str, ref_implant: Optional[str]) -> list[set[str]]:
        """Trainable pkey sets of the freeze-schedule phases (one set when the schedule
        is fixed, or when the model has no implant to route learning into)."""
        if self.t.get("freeze_schedule", "fixed") == "fixed" or ref_implant is None or not self.model.implants:
            return [trainable_pkeys(self.model, policy, ref_implant, self.policy_extra_frozen, self.extra_trainable)]
        pols = schedule_policies(self.t)
        return [trainable_pkeys(self.model, p_, ref_implant, self.policy_extra_frozen, self.extra_trainable)
                for p_ in pols]

    def _apply_phase(self, i: int) -> None:
        sets = self.state.get("phase_pkeys")
        if sets:
            apply_trainable(self.model, set(sets[i]), self.t.get("bn_stats", "follow"))
            self.state["phase"] = i

    # ------------------------------------------------------------ trainability
    def configure(self, policy: Optional[str] = None, ref_implant: Optional[str] = None,
                  reset_state: Optional[bool] = None, extra_trainable: Optional[set[str]] = None) -> dict:
        """(Re)build the optimizer after a graph edit.  State of surviving
        parameters is preserved unless reset (train.opt_state_on_edit)."""
        policy = policy or self.t["freeze"]
        if extra_trainable is not None:
            self.extra_trainable = extra_trainable
        sets = self._phase_sets(policy, ref_implant)
        pk = set().union(*sets)                       # the optimizer covers every phase; inactive tensors get
        named = ordered_params(self.model, pk)        # no gradient and are skipped by the optimizer
        params = [p for _, p in named]
        self.state["phase_pkeys"] = [sorted(x, key=lambda s_: int(s_[1:])) for x in sets] if len(sets) > 1 else None
        if len(sets) > 1:
            self._apply_phase(schedule_phase(self.t, self.state.get("seg_step", 0)))
        else:
            apply_trainable(self.model, pk, self.t.get("bn_stats", "follow"))
        reset = (self.t["opt_state_on_edit"] == "reset") if reset_state is None else reset_state
        old = self.opt
        self.opt = self._build_opt(params)
        self._record_names(named)
        carried = 0
        if old is not None and self.opt is not None and not reset:
            ids = {id(p) for p in params}
            for p, st in old.state.items():
                if id(p) in ids:
                    self.opt.state[p] = st
                    carried += 1
        self.state.update({"pkeys": sorted(pk, key=lambda s: int(s[1:])), "ref_implant": ref_implant,
                           "policy": policy})
        return {"policy": policy, "ref_implant": ref_implant, "n_trainable_params": sum(p.numel() for p in params),
                "trainable_pkeys": len(pk), "opt_state_carried": carried, "opt_state_reset": bool(reset),
                "freeze_schedule": self.t.get("freeze_schedule", "fixed"),
                "phase_trainable_params": [sum(p.numel() for _, p in ordered_params(self.model, x)) for x in sets],
                "frozen_bn_modules": len(self.model.frozen_bn), "bn_stats": self.t.get("bn_stats", "follow"),
                "composite_decay_maps": len(self.composite)}

    # ---------------------------------------------------------------- batches
    def _audit_batch(self, idx) -> None:
        """v45 (train.audit_batches): the ordered stream of training-example ids as a hash chain in the trainer state
        (resume-safe), the same construction as the v43 compact fork audit, so chains of different jobs that start
        from the same trainer state are comparable."""
        if not self.t.get("audit_batches", False):
            return
        import hashlib as _hl
        st = self.state
        st["batch_id_hash"] = _hl.sha256(str(st.get("batch_id_hash", "")).encode()
                                         + idx.detach().cpu().to(torch.int64).numpy().tobytes()).hexdigest()[:24]
        st["batches_drawn"] = int(st.get("batches_drawn", 0)) + 1

    def next_batch(self) -> Partition:
        if self.t["stream"] == "fresh":
            if self.bundle.fresh_sampler is None:
                raise ValueError("fresh stream requested but dataset has no fresh sampler")
            part = self.bundle.fresh_sampler(self.B, self.gens["fresh"]).to(self.device)
            self.state["examples"] += self.B
            return part
        N = len(self.bundle.train)
        st = self.state
        if self.t.get("sampler", "uniform") == "group_balanced":
            gr = self.bundle.train.groups
            if gr is None:
                raise ValueError("train.sampler=group_balanced needs a dataset with groups")
            # each group equally likely, uniform within a group, with replacement (disclosed oversampling)
            cnt = torch.bincount(gr.long().cpu())
            w = (1.0 / cnt.clamp_min(1).double())[gr.long().cpu()]
            idx = torch.multinomial(w, self.B, replacement=True, generator=self.gens["minibatch"])
            self._audit_batch(idx)
            idx = idx.to(self.device)
            st["examples"] += self.B
            return self.bundle.train.index(idx)
        if st["perm"] is None or st["pos"] + self.B > N:
            st["perm"] = torch.randperm(N, generator=self.gens["minibatch"])
            st["pos"] = 0
            st["epoch"] += 1
        idx = st["perm"][st["pos"]:st["pos"] + self.B]
        self._audit_batch(idx)
        idx = idx.to(self.device)
        st["pos"] += self.B
        st["examples"] += self.B
        part = self.bundle.train.index(idx)
        if self.bundle.layout == "img" and self.bundle.augment != "none":
            pad = self.bundle.preprocess.get("pad_value")
            if pad is not None and not isinstance(pad, torch.Tensor):
                pad = torch.tensor(pad)
            part.X = dict(part.X)
            part.X["x"] = augment_batch(part.X["x"], self.bundle.augment, self.gens["augmentation"],
                                        None if pad is None else pad.to(part.X["x"].device))
        return part

    def _cast(self, X: dict) -> dict:
        return {k: (v.to(self.dtype) if v.is_floating_point() else v) for k, v in X.items()}

    # ---------------------------------------------------------------- finite-peg recipes (v15)
    def _uniform_quantizers(self) -> list:
        from ..graph.ops import Quantizer
        out = []
        for nid in self.model.topo_order():
            n = self.model.nodes[nid]
            if n.op == "quant" and n.pkey is not None:
                q = self.model.mods[n.pkey]
                if isinstance(q, Quantizer) and q.mode != "none":
                    out.append((nid, q))
        return out

    def _quant_recipe_before_update(self) -> None:
        """train.quant_warmup_updates: uniform pegs pass values through for the job's first W updates, then are
        calibrated (in topological order, on the first 2048 training inputs, eval mode, upstream pegs already
        quantising) and quantise from update W on.  Resume-safe: the switch is recorded in the trainer state and
        the calibrated ranges are model buffers."""
        W = int(self.t.get("quant_warmup_updates", 0) or 0)
        if not W:
            return
        st = self.state
        qs = self._uniform_quantizers()
        if any(q.mode != "uniform" for _, q in qs):
            raise GraphError("train.quant_warmup_updates is implemented for uniform pegs")
        if "quant_warm_start" not in st:
            st["quant_warm_start"] = int(st["global_step"])          # W counts this job's own updates
        if st["global_step"] - st["quant_warm_start"] < W:
            for _, q in qs:
                q.passthrough = True
            return
        if not st.get("quant_warm_calibrated"):
            X = self._cast({k: v[:2048] for k, v in self.bundle.train.X.items()})
            was = self.model.training
            self.model.eval()
            for _, q in qs:
                q.passthrough = False
            with torch.no_grad():
                for nid, q in qs:
                    _, vals = self.model(X, return_nodes=[self.model.nodes[nid].inputs[0]])
                    z = vals[self.model.nodes[nid].inputs[0]]
                    q.calibrate(z.permute(0, 2, 3, 1).reshape(-1, q.k) if z.dim() == 4 else z.reshape(-1, q.k))
            self.model.train(was)
            st["quant_warm_calibrated"] = True
            st.setdefault("quant_events", []).append({"event": "warmup_end_calibration",
                                                      "global_step": int(st["global_step"])})
            self.log({"event": "quant_warmup_calibrated", "global_step": int(st["global_step"])})
        for _, q in qs:
            q.passthrough = False

    def _quant_ema_hooks(self) -> list:
        """train.quant_range = ema: during training forwards each uniform peg records the 0.001 / 0.999 quantiles of
        its input (per coordinate, over the minibatch: with a batch of 128 these are the batch minimum and maximum);
        after the optimizer step lo / hi move toward them with momentum quant_range_momentum.  Evaluation never updates the range (the range is a training-only global statistic,
        shared across examples; no per-example scale crosses the peg)."""
        if self.t.get("quant_range", "fixed") != "ema":
            return []
        self._ema_obs = {}
        hooks = []
        for nid, q in self._uniform_quantizers():
            if q.mode != "uniform":
                raise GraphError("train.quant_range = ema is implemented for uniform pegs")

            def hook(mod, inp, out, nid=nid):
                if mod.training and not getattr(mod, "passthrough", False):
                    z = inp[0].detach()
                    zf = (z.movedim(1, -1) if z.dim() == 4 else z).reshape(-1, mod.k).float()
                    self._ema_obs[nid] = (torch.quantile(zf, 0.001, dim=0), torch.quantile(zf, 0.999, dim=0))
            hooks.append(q.register_forward_hook(hook))
        return hooks

    @torch.no_grad()
    def _quant_ema_after_step(self) -> None:
        if self.t.get("quant_range", "fixed") != "ema" or not getattr(self, "_ema_obs", None):
            return
        m = float(self.t.get("quant_range_momentum", 0.99))
        mods = dict(self._uniform_quantizers())
        for nid, (lo, hi) in self._ema_obs.items():
            q = mods.get(nid)
            if q is None:
                continue
            q.lo.mul_(m).add_((1 - m) * lo.to(q.lo.dtype))
            q.hi.mul_(m).add_((1 - m) * hi.to(q.hi.dtype))
            bad = q.hi <= q.lo
            q.hi[bad] = q.lo[bad] + 1e-3
        self._ema_obs = {}

    # ---------------------------------------------------------------- training
    def run(self, seg: Segment, checkpoint_cb: Optional[Callable[[], None]] = None) -> dict:
        # the adaptive range never runs in a restricted segment (seg.trainable set: decoder refits, locality repair
        # scopes, bridge retirement): an interface held fixed there must keep its range, hence its code
        ema_hooks = self._quant_ema_hooks() if seg.trainable is None else []
        margin = float(self.t.get("quant_ste_margin", 0.0) or 0.0)
        for _, q in self._uniform_quantizers():
            q.ste_margin = margin                  # v17: training-mode gradient margin (forward unchanged)
        try:
            return self._run(seg, checkpoint_cb)
        finally:
            for h in ema_hooks:
                h.remove()
            for _, q in self._uniform_quantizers():
                q.passthrough = False
                q.ste_margin = 0.0

    def _record_once(self, key: str, seg: Segment, rec: dict) -> None:
        """v45: append a per-segment record once.  A segment is identified by its name and the global step at its
        start; a job resumed from a checkpoint written after the record but before the segment's first update (seg_step
        still 0) must not record it again (before v45 such a resume duplicated the record; training was unaffected)."""
        st = self.state
        start = int(st["global_step"]) - int(st["seg_step"])
        lst = st.get(key) or []
        if any(r.get("segment") == seg.name and int(r.get("segment_start_step", -1)) == start for r in lst):
            return
        st[key] = list(lst) + [{**rec, "segment_start_step": start}]     # a new list: state_dict() copies shallowly

    def _run(self, seg: Segment, checkpoint_cb: Optional[Callable[[], None]] = None) -> dict:
        st = self.state
        if st["segment"] != seg.name:
            st["segment"], st["seg_step"] = seg.name, 0
        if self.opt is None and seg.updates > st["seg_step"]:
            info = self.configure(st["policy"] if st["pkeys"] is not None else None, st["ref_implant"])
            if self.opt is None:
                raise GraphError("no trainable parameters for this segment")
        self.model.train()
        base_lr = seg.lr if seg.lr is not None else self.t["lr"]
        ck_every = int(self.t.get("checkpoint_every") or 0)
        t0 = time.time()
        loss_acc = torch.zeros((), device=self.device, dtype=torch.float64)
        n_acc = 0
        teacher = seg.teacher
        if teacher is not None:
            teacher.eval()
        if st.get("diverged"):
            # a diverged history stops training; the actual (not the requested) updates are what is reported
            self.log({"event": "segment_skipped_after_divergence", "segment": seg.name})
            return {"segment": seg.name, "updates": 0, "global_step": st["global_step"], "examples": st["examples"],
                    "final_train_loss_avg": None, "diverged": True}
        star = self.t.get("target", "task") == "teacher_star" and seg.target == "task"
        record_start = st["seg_step"] == 0 and self.opt is not None
        if seg.trainable is not None:
            if st.get("phase_pkeys"):
                raise GraphError("a segment trainable set cannot be combined with a freeze schedule")
            apply_trainable(self.model, set(seg.trainable) & set(st["pkeys"] or []), self.t.get("bn_stats", "follow"))
            st["restricted"] = True
            self.model.train()
        elif st.get("restricted"):
            apply_trainable(self.model, set(st["pkeys"] or []), self.t.get("bn_stats", "follow"))
            st["restricted"] = False
            self.model.train()
        if record_start:
            # V3-11c: phase-by-phase trainable-state record: what actually learns in THIS segment (after the
            # segment's own trainable set is applied); freeze-schedule phase changes are logged below
            rec = {"segment": seg.name, **self._trainable_now(), "policy": st.get("policy"),
                   "freeze_schedule": self.t.get("freeze_schedule"), "global_step": int(st["global_step"])}
            self._record_once("trainable_record", seg, rec)
            self.log({"event": "trainable_state", **rec})
        fz = self._input_freeze(seg.freeze_inputs) if seg.updates > st["seg_step"] else None
        ng = self._norm_groups() if seg.updates > st["seg_step"] else None
        bh = self._backbone_hold(seg.freeze_backbone) if seg.updates > st["seg_step"] else None
        if bh is not None:
            rec_bh = {"segment": seg.name, "pkeys": bh["pkeys"], "seg_step": int(st["seg_step"]),
                      "values_hash": tensor_hash(torch.cat([v.reshape(-1).cpu() for v in bh["values"]]))}
            if st["seg_step"] == 0:                  # once per segment (a resumed segment logs, never re-records)
                self._record_once("backbone_hold_record", seg, rec_bh)
            self.log({"event": "backbone_hold", **rec_bh})
        if fz is not None:
            rec_fz = {"segment": seg.name, "pkey": fz["pkey"], "columns": fz["cols"].tolist(),
                      "values_hash": tensor_hash(fz["values"].cpu()), "seg_step": int(st["seg_step"])}
            if st["seg_step"] == 0:                  # once per segment (a resumed segment logs, never re-records)
                self._record_once("input_freeze_record", seg, rec_fz)
            self.log({"event": "input_freeze", **rec_fz})
        while st["seg_step"] < seg.updates:
            if interrupted():
                if checkpoint_cb:
                    checkpoint_cb()
                raise KeyboardInterrupt("interrupted; checkpoint written")
            k = st["seg_step"]
            if st.get("phase_pkeys"):
                ph = schedule_phase(self.t, k)
                if ph != st.get("phase"):
                    self._apply_phase(ph)
                    self.model.train()
                    self.log({"event": "trainable_state", "segment": seg.name, "phase": str(ph),
                              **self._trainable_now(), "global_step": int(st["global_step"])})
            if seg.on_step is not None:
                seg.on_step(self, k)
            lr = lr_at(k, seg.updates, base_lr, self.t["lr_schedule"], self.t["warmup"])
            for gp in self.opt.param_groups:
                gp["lr"] = lr
            self._quant_recipe_before_update()
            batch = self.next_batch()
            X = self._cast(batch.X)
            ctx = {}
            if seg.batch_ctx is not None:
                ctx.update(seg.batch_ctx(batch))
            if self.t["precision"] == "bf16_autocast" and str(self.device).startswith("cuda"):
                with torch.autocast("cuda", dtype=torch.bfloat16):
                    out = self.model(X, ctx)
                out = out.float()
            else:
                out = self.model(X, ctx)
            if star:
                loss = teacher_star_loss(out, batch, X, self.bundle, self.t["distill_temperature"])
            elif seg.target == "task":
                loss = task_loss(out, batch.y, self.task)
            elif seg.target in ("expanded", "original"):
                with torch.no_grad():
                    tout = teacher(X)
                loss = distill_loss(out, tout, self.task, self.t["distill_temperature"], batch.y)
            elif seg.target == "custom":
                loss = seg.target_fn(out, batch, X)
            else:
                raise ValueError(seg.target)
            ctx["__out__"] = out
            for name, al in ctx.get("aux_losses", []):
                loss = loss + al
            if seg.extra_loss is not None:
                loss = loss + seg.extra_loss(self.model, ctx, batch, k)
            if self.composite:
                pen = composite_penalty(self.model, self.composite, float(self.t["weight_decay"]))
                if pen is not None:
                    loss = loss + pen
            if not bool(torch.isfinite(loss.detach())):
                st["diverged"], st["diverged_at"] = True, st["global_step"]
                st["diverged_reason"] = "non-finite loss"
                self.log({"event": "diverged", "segment": seg.name, "seg_step": k, "global_step": st["global_step"],
                          "reason": st["diverged_reason"]})
                break
            self.opt.zero_grad(set_to_none=True)
            loss.backward()
            if fz is not None and fz["W"].grad is not None:
                fz["W"].grad[:, fz["cols"]] = 0.0          # before clipping: the frozen entries carry no gradient
            if bh is not None:
                for p_ in bh["params"]:
                    if p_.grad is not None:
                        p_.grad.zero_()                    # v44: the held downstream layers carry no gradient
            if self.t["grad_clip"]:
                torch.nn.utils.clip_grad_norm_([p for g in self.opt.param_groups for p in g["params"]],
                                               self.t["grad_clip"])
            nb = self._update_norms_before(ng) if ng is not None else None
            self.opt.step()
            if fz is not None:
                with torch.no_grad():
                    fz["W"][:, fz["cols"]] = fz["values"]  # exact: momentum and decay cannot move them either
            if bh is not None:
                with torch.no_grad():
                    for p_, v_ in zip(bh["params"], bh["values"]):
                        p_.copy_(v_)                       # v44: exact, as the column freeze
            if ng is not None:
                self._update_norms_after(ng, nb)
            self._quant_ema_after_step()
            if seg.post_step is not None:
                seg.post_step(self, k)
            loss_acc += loss.detach().double()
            n_acc += 1
            st["seg_step"] += 1
            st["global_step"] += 1
            # numerical validation boundary after EVERY update (also the last one): a finite loss can still
            # give non-finite gradients or an overflowing update; one fused check of the updated tensors
            upd = [p_ for gp in self.opt.param_groups for p_ in gp["params"] if p_.grad is not None]
            if upd and not bool(torch.isfinite(torch.stack([p_.detach().abs().amax().float() for p_ in upd])).all()):
                st["diverged"], st["diverged_at"] = True, st["global_step"]
                st["diverged_reason"] = "non-finite parameters after the optimizer update"
                self.log({"event": "diverged", "segment": seg.name, "seg_step": k, "global_step": st["global_step"],
                          "reason": st["diverged_reason"]})
            # training compute: forward + backward ~ 3 x forward MACs per example (analytic, effective graph)
            st["train_macs"] = int(st.get("train_macs", 0)) + 3 * forward_macs(self.model, self.T, self._macs_cache) \
                * int(batch.y.shape[0])
            st["train_macs_bwd"] = int(st.get("train_macs_bwd", 0)) + \
                backward_aware_macs(self.model, self.T, self._macs_cache) * int(batch.y.shape[0])
            # v45: the same estimate by part, with the gradient work a parameter hold discards
            held_ = {}
            if bh is not None:
                held_.update({pk_: 1.0 for pk_ in bh["pkeys"]})
            if fz is not None:
                held_[fz["pkey"]] = held_.get(fz["pkey"], 0.0) + float(len(fz["cols"])) / float(fz["W"].shape[1])
            parts_ = training_mac_parts(self.model, self.T, self._macs_cache, held_)
            mp_ = st.get("mac_parts") or {}
            # a new dict each update: state_dict() copies the state shallowly, so a nested dict is never mutated
            st["mac_parts"] = {k_: int(mp_.get(k_, 0)) + parts_[k_] * int(batch.y.shape[0]) for k_ in MAC_PARTS}
            if teacher is not None and seg.target in ("expanded", "original"):
                st["teacher_macs"] = int(st.get("teacher_macs", 0)) + \
                    forward_macs(teacher, self.T, self._teacher_macs_cache) * int(batch.y.shape[0])
            if st.get("diverged"):
                break                         # the work of the failed update is counted; training stops here
            if seg.eval_fn is not None and st["seg_step"] in seg.eval_points:
                rec = {"segment": seg.name, "seg_step": st["seg_step"], "global_step": st["global_step"],
                       "examples": st["examples"], "train_loss_avg": (loss_acc / max(n_acc, 1)).item()}
                loss_acc.zero_()
                n_acc = 0
                rec.update(seg.eval_fn(self, st["seg_step"]))
                self.curves.append(rec)
                self.log({"type": "curve", **rec})
                self.model.train()
            if ck_every and checkpoint_cb and st["seg_step"] % ck_every == 0 and st["seg_step"] < seg.updates:
                checkpoint_cb()
        self.timing["train_seconds"] += time.time() - t0
        # actual updates of this segment (fewer than requested when training stopped on divergence)
        return {"segment": seg.name, "updates": int(st["seg_step"]), "requested": seg.updates,
                "global_step": st["global_step"],
                "examples": st["examples"], "final_train_loss_avg": (loss_acc / max(n_acc, 1)).item() if n_acc else None,
                "diverged": bool(st.get("diverged"))}

    # ------------------------------------------------------------- checkpoint
    def state_dict(self) -> dict:
        st = dict(self.state)
        st["perm"] = None if st["perm"] is None else st["perm"].clone()
        return {"state": st, "gens": {k: g.get_state() for k, g in self.gens.items()},
                "opt": None if self.opt is None else self.opt.state_dict(), "curves": list(self.curves),
                "timing": dict(self.timing), "policy_extra_frozen": sorted(self.policy_extra_frozen),
                "opt_param_names": list(getattr(self, "opt_param_names", [])),
                "extra_trainable": None if self.extra_trainable is None else sorted(self.extra_trainable)}

    def load_state_dict(self, d: dict) -> None:
        self.state = dict(d["state"])
        for k, s in d["gens"].items():
            self.gens[k].set_state(s)
        self.curves = list(d["curves"])
        self.timing = dict(d["timing"])
        self.policy_extra_frozen = set(d.get("policy_extra_frozen", []))
        et = d.get("extra_trainable")
        self.extra_trainable = None if et is None else set(et)
        if self.state["pkeys"] is not None:
            pk = set(self.state["pkeys"])
            apply_trainable(self.model, pk, self.t.get("bn_stats", "follow"))
            named = ordered_params(self.model, pk)
            params = [p for _, p in named]
            self.opt = self._build_opt(params)
            self._record_names(named)
            if d["opt"] is not None and self.opt is not None:
                self.opt.load_state_dict(d["opt"])
            if self.state.get("phase_pkeys"):
                self._apply_phase(int(self.state.get("phase", 0)))


# =============================================================================
# Evaluation
# =============================================================================

def model_dtype(model) -> torch.dtype:
    """Floating dtype of a model's parameters (float32 if it has none)."""
    for p in model.parameters():
        if p.is_floating_point():
            return p.dtype
    for b in model.buffers():
        if b.is_floating_point():
            return b.dtype
    return torch.float32


@torch.no_grad()
def predict(model: GraphNet, part: Partition, batch: int = 4096, dtype=None) -> torch.Tensor:
    """Outputs on a partition.  Floating inputs are cast to `dtype`, which
    defaults to the model's own parameter dtype (so an fp64 model is evaluated
    in fp64 without the caller having to remember it)."""
    dtype = dtype or model_dtype(model)
    was = model.training
    model.eval()
    outs = []
    N = len(part)
    for i in range(0, N, batch):
        X = {k: (v[i:i + batch].to(dtype) if v.is_floating_point() else v[i:i + batch]) for k, v in part.X.items()}
        outs.append(model(X))
    model.train(was)
    return torch.cat(outs) if outs else torch.zeros(0)


def evaluate(model: GraphNet, bundle: DataBundle, partitions: list[str], batch: int = 4096,
             dtype=None, return_preds: bool = False) -> tuple[dict, dict]:
    parts = bundle.partitions()
    res, preds = {}, {}
    for name in partitions:
        if name not in parts:
            continue
        p = parts[name]
        out = predict(model, p, batch, dtype)
        res[name] = M.task_metrics(out, p.y, bundle.task, p.groups, bundle.target_scale)
        if return_preds:
            preds[name] = out
    return res, preds
