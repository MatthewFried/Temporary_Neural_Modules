"""Shared utilities: canonical hashing, named RNG streams, atomic IO, JSONL logging.

Random streams
--------------
Every source of randomness is drawn from a *named stream* derived from
(base_seed, stream_name, *extra_keys) through SHA-256.  Two streams with
different names never share state, so consuming random numbers in one stream
(e.g. initialising a new implant) can never shift another stream (e.g. the
minibatch order).  This is the mechanism behind acceptance test T20.
"""
from __future__ import annotations

import contextlib
import dataclasses
import hashlib
import json
import math
import os
import signal
import tempfile
import time
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import torch

STREAM_NAMES = (
    "data",          # dataset generation (synthetic inputs, teacher sampling inputs)
    "teacher",       # teacher / target-function parameters
    "split",         # partitioning into train pool / val / test
    "subset",        # nested training-subset selection
    "noise",         # train-only label / target corruption
    "init",          # model parameter initialisation
    "insertion",     # implant initialisation and symmetry-breaking perturbations
    "minibatch",     # minibatch order
    "augmentation",  # image augmentation
    "deletion",      # sampled deletion subsets
    "repair",        # repair initialisation / order
    "policy",        # adaptive cut-selection search
    "mutation",      # explicit neutral-drift / mutation processes
    "fresh",         # fresh-sample streams (I2)
    "peg",           # peg / codebook initialisation
    "assembly",      # CoP module-assembly sampling
)


# ----------------------------------------------------------------------------
# Canonical JSON and hashing
# ----------------------------------------------------------------------------

def _canon(o: Any) -> Any:
    if dataclasses.is_dataclass(o) and not isinstance(o, type):
        o = dataclasses.asdict(o)
    if isinstance(o, dict):
        return {str(k): _canon(o[k]) for k in sorted(o, key=str)}
    if isinstance(o, (list, tuple)):
        return [_canon(v) for v in o]
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        o = float(o)
    if isinstance(o, float):
        if math.isnan(o) or math.isinf(o):
            return repr(o)
        return float(o)  # int/float typing is normalised by config validation
    if isinstance(o, Path):
        return str(o)
    return o


def canonical_json(o: Any) -> str:
    return json.dumps(_canon(o), sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def sha256_str(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def stable_hash(o: Any, n: int = 16) -> str:
    return sha256_str(canonical_json(o))[:n]


def tensor_hash(t: torch.Tensor | np.ndarray, n: int = 16) -> str:
    if isinstance(t, torch.Tensor):
        a = t.detach().cpu().contiguous().numpy()
    else:
        a = np.ascontiguousarray(t)
    h = hashlib.sha256()
    h.update(str(a.dtype).encode())
    h.update(str(a.shape).encode())
    h.update(a.tobytes())
    return h.hexdigest()[:n]


def file_hash(path: str | Path, n: int = 16) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()[:n]


def code_hash(root: str | Path | None = None) -> str:
    """Hash of every .py file in the cop package (sorted by relative path)."""
    root = Path(root) if root else Path(__file__).resolve().parent
    h = hashlib.sha256()
    for p in sorted(root.rglob("*.py")):
        h.update(str(p.relative_to(root)).encode())
        h.update(p.read_bytes())
    return h.hexdigest()[:16]


# Files that cannot change what a job computes: orchestration (scheduling,
# manifests, calibration), analysis, the CLI and the environment report.
NON_SEMANTIC = ("orchestration/", "analysis/", "cli.py", "env.py", "__main__.py")


def semantic_code_hash(root: str | Path | None = None) -> str:
    """Hash of the code that determines job results (everything in the cop
    package except NON_SEMANTIC files).  Completed runs and parents are reused
    only when this hash matches, or when a reuse is explicitly recorded."""
    root = Path(root) if root else Path(__file__).resolve().parent
    h = hashlib.sha256()
    for p in sorted(root.rglob("*.py")):
        rel = p.relative_to(root).as_posix()
        if rel.startswith(NON_SEMANTIC):
            continue
        h.update(rel.encode())
        h.update(p.read_bytes())
    return h.hexdigest()[:16]


# ----------------------------------------------------------------------------
# Named RNG streams
# ----------------------------------------------------------------------------

def stream_seed(base_seed: int, stream: str, *keys: Any) -> int:
    if stream not in STREAM_NAMES:
        raise ValueError(f"unknown RNG stream {stream!r}; add it to STREAM_NAMES explicitly")
    s = canonical_json([int(base_seed), stream, [str(k) for k in keys]])
    return int(hashlib.sha256(s.encode()).hexdigest()[:15], 16)  # < 2**60


def torch_gen(base_seed: int, stream: str, *keys: Any, device: str = "cpu") -> torch.Generator:
    g = torch.Generator(device=device)
    g.manual_seed(stream_seed(base_seed, stream, *keys))
    return g


def np_gen(base_seed: int, stream: str, *keys: Any) -> np.random.Generator:
    return np.random.default_rng(stream_seed(base_seed, stream, *keys))


# ----------------------------------------------------------------------------
# Atomic IO, locks, JSONL
# ----------------------------------------------------------------------------

def atomic_write_bytes(path: str | Path, data: bytes) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except BaseException:
        with contextlib.suppress(FileNotFoundError):
            os.unlink(tmp)
        raise


def atomic_write_json(path: str | Path, obj: Any, indent: int | None = 1) -> None:
    atomic_write_bytes(path, (json.dumps(_canon(obj), indent=indent, sort_keys=True) + "\n").encode())


def atomic_torch_save(obj: Any, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    os.close(fd)
    try:
        torch.save(obj, tmp)
        os.replace(tmp, path)
    except BaseException:
        with contextlib.suppress(FileNotFoundError):
            os.unlink(tmp)
        raise


def read_json(path: str | Path) -> Any:
    with open(path) as f:
        return json.load(f)


def append_jsonl(path: str | Path, rec: dict) -> None:
    """Append one record. Single write() of a full line under O_APPEND is atomic
    for reasonable record sizes on Linux local filesystems."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    line = (json.dumps(_canon(rec), sort_keys=True) + "\n").encode()
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o644)
    try:
        os.write(fd, line)
    finally:
        os.close(fd)


def read_jsonl(path: str | Path) -> list[dict]:
    out = []
    p = Path(path)
    if not p.exists():
        return out
    with open(p) as f:
        for line in f:
            line = line.strip()
            if line:
                out.append(json.loads(line))
    return out


class FileLock:
    """Exclusive claim via O_CREAT|O_EXCL.  Stale locks (owner pid dead on the
    same host) can be broken explicitly with `break_stale=True`."""

    def __init__(self, path: str | Path, owner: str):
        self.path = Path(path)
        self.owner = owner
        self.held = False

    def acquire(self, break_stale: bool = True) -> bool:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        info = canonical_json({"owner": self.owner, "pid": os.getpid(), "host": os.uname().nodename,
                               "time": time.time()}).encode()
        for _ in range(2):
            try:
                fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644)
                os.write(fd, info)
                os.close(fd)
                self.held = True
                return True
            except FileExistsError:
                if not break_stale or not self._stale():
                    return False
                with contextlib.suppress(FileNotFoundError):
                    os.unlink(self.path)
        return False

    def _stale(self) -> bool:
        try:
            d = json.loads(self.path.read_text())
        except Exception:
            return False
        if d.get("host") != os.uname().nodename:
            return False
        pid = int(d.get("pid", -1))
        if pid <= 0:
            return False
        try:
            os.kill(pid, 0)
            return False
        except ProcessLookupError:
            return True
        except PermissionError:
            return False

    def release(self) -> None:
        if self.held:
            with contextlib.suppress(FileNotFoundError):
                os.unlink(self.path)
            self.held = False


class GracefulInterrupt:
    """Converts the first SIGINT/SIGTERM into a flag so training loops can
    checkpoint and exit cleanly; a second signal raises KeyboardInterrupt."""

    def __init__(self):
        self.flag = False
        self._old = {}

    def __enter__(self):
        for s in (signal.SIGINT, signal.SIGTERM):
            try:
                self._old[s] = signal.signal(s, self._handler)
            except ValueError:  # not main thread
                pass
        return self

    def _handler(self, signum, frame):
        if self.flag:
            raise KeyboardInterrupt
        self.flag = True
        INTERRUPT["flag"] = True      # polled by the training loop, which checkpoints and stops

    def __exit__(self, *exc):
        for s, h in self._old.items():
            signal.signal(s, h)
        return False


# global handle the training loops poll (set by the runner).  'countdown' is a
# test hook: when set to k, the k-th poll from now raises the flag, which lets
# the job-level resume tests interrupt any loop at a chosen point.
INTERRUPT = {"flag": False, "countdown": None, "polls": 0}


def interrupted() -> bool:
    INTERRUPT["polls"] += 1
    cd = INTERRUPT.get("countdown")
    if cd is not None:
        cd -= 1
        INTERRUPT["countdown"] = cd
        if cd <= 0:
            INTERRUPT["flag"] = True
            INTERRUPT["countdown"] = None
    return bool(INTERRUPT["flag"])


def now() -> float:
    return time.time()


def sync(device: str | torch.device) -> None:
    if str(device).startswith("cuda") and torch.cuda.is_available():
        torch.cuda.synchronize()


def to_jsonable(x: Any) -> Any:
    if isinstance(x, torch.Tensor):
        return x.detach().cpu().tolist()
    if isinstance(x, np.ndarray):
        return x.tolist()
    return _canon(x)


def chunks(seq: list, n: int) -> Iterable[list]:
    for i in range(0, len(seq), n):
        yield seq[i:i + n]


def configure_torch(exec_cfg: dict) -> dict:
    """Numerics settings of a job (part of the semantic code: changing a default
    here changes results).  Returns the settings applied, for provenance."""
    tf32 = bool(exec_cfg.get("allow_tf32", False))
    torch.backends.cuda.matmul.allow_tf32 = tf32
    torch.backends.cudnn.allow_tf32 = tf32
    torch.backends.cudnn.benchmark = bool(exec_cfg.get("cudnn_benchmark", False))
    if exec_cfg.get("deterministic", True):
        os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
        torch.use_deterministic_algorithms(True, warn_only=True)
    nt = exec_cfg.get("torch_threads")
    if nt:
        torch.set_num_threads(int(nt))
    return {"allow_tf32": tf32, "cudnn_benchmark": bool(exec_cfg.get("cudnn_benchmark", False)),
            "deterministic": bool(exec_cfg.get("deterministic", True)), "torch_threads": nt or None,
            "device": str(exec_cfg.get("device", "cpu"))}
