# Finite certificates and finite transition systems (R3, I5)

This document states exactly what each certificate produced by `cop.finite` asserts, the assumptions under which the assertion holds, and the scope beyond which it says nothing. Every certificate is a JSON file with the fields `type`, `status`, `domain`, `class`, `edit_rules`, `tolerance`, `precision`, `coverage`, `witness`, `data`, `scope`, `notes` and `generator` (package and code hash). Every certificate written by `run_finite_job` is re-checked by `cop/finite/checker.py`, which imports nothing else from `cop.finite`; its verdict is stored in the job's `summary.json`.

## Status values

| status | meaning |
|---|---|
| `witness_found` | An explicit member of the class meeting the criterion is attached and has been verified by evaluation. |
| `certified_no_member` | No member of the class meets the criterion. Issued only after every member of a finite class was evaluated, or from an exact theorem whose hypotheses are checked in exact arithmetic. |
| `certified_lower_bound` | A sound lower bound on the error of every member strictly exceeds the tolerance. |
| `complete_analysis` | Transition system: the reachable state space was enumerated completely, so graph statements about it are exact. |
| `numerical_bound` | A floating-point bound with a heuristic error margin exceeds the tolerance. This is evidence, not a proof label. |
| `incomplete` | A member budget, a state cap or the wall-clock budget was reached. Coverage is reported exactly; no proof label is issued. |
| `no_certificate` | The method ran to completion but neither a witness nor a bound settles the question. |
| `unsupported` | No sound method is implemented for this case (for example approximate representation in `piecewise`). |

Proof statuses are `certified_no_member`, `certified_lower_bound` and `complete_analysis`. The generator's single exit point (`finalize_certificate`) downgrades a proof status to `incomplete` whenever `coverage.complete` is false, and the checker independently rejects any certificate that carries a proof status with incomplete coverage, with `examined != total` for an enumeration, or after a timeout.

## 1. Threshold-network classes on the Boolean cube (`boolean_class`)

**Domain.** All of $\{0,1\}^n$. Domain index $i$ encodes $x_j = \lfloor i/2^j \rfloor \bmod 2$.

**Class.** Networks with the stated hidden widths and one output unit. Each unit computes $\mathrm{step}(w\cdot h + b)$ with $\mathrm{step}(z)=1$ if $z>0$ and $0$ otherwise. Every weight and bias ranges over a stated finite set $S$ of integers (default $\{-1,0,1\}$). With $P$ parameters the class has exactly $|S|^P$ members; member $m$ assigns parameter $p$ the value $S[d_p(m)]$, where $d_p$ is the $p$-th base-$|S|$ digit of $m$, least significant first. Parameters are ordered per layer: the weight matrix in row-major (output, input) order, then the biases.

**Criterion.** The error of a member is the number of domain points where it differs from the target truth table; the member meets tolerance $t$ when the error is at most $t$.

**Statement.** `certified_no_member` asserts that all $|S|^P$ members were evaluated on all $2^n$ points and none meets the tolerance; `data.min_error_examined` is then the exact minimum error over the class. `witness_found` attaches the parameters and outputs of a member meeting the tolerance.

**Scope.** The statement concerns only this architecture, this finite weight set, this step convention and the complete Boolean domain. It implies nothing about real-valued weights, wider sets $S$, or other architectures. The validation pair is: AND is realised by one unit; XOR is not realised by any single unit with weights in $\{-1,0,1\}$ (all 27 members fail, minimum error 1), and is realised with one hidden layer of width 2.

## 2. Linear rank bottleneck (`rank_exact`, `rank_approx`)

**Class.** $\mathcal L_k = \{x \mapsto ABx : A\in\mathbb R^{m\times k}, B\in\mathbb R^{k\times n}\}$, a linear network with a width-$k$ bottleneck. The target is $y = Mx$, so biases play no role and are excluded.

**Exact representation.** Every member satisfies $\mathrm{rank}(AB)\le k$. For a matrix with rational entries the rank over $\mathbb Q$ equals the rank over $\mathbb R$, because rank is the order of the largest non-vanishing minor and minors are the same rational numbers in both fields. Exact Gaussian elimination over the rationals therefore proves $M\notin\mathcal L_k$ whenever $\mathrm{rank}(M)>k$ (`certified_no_member`). When $\mathrm{rank}(M)=r\le k$, $M = CR$ with $C$ the pivot columns of $M$ and $R$ the non-zero rows of its reduced row echelon form; padded with zeros this is a member, verified by exact multiplication (`witness_found`). Floating-point input is `unsupported` for this type.

**Approximate representation.** By the Eckart-Young-Mirsky theorem, $\min_{N:\,\mathrm{rank}(N)\le k}\|M-N\|_F^2 = \sum_{i>k}\sigma_i(M)^2$, attained by the truncated singular value decomposition. If the input satisfies $\mathbb E[xx^\top]=I$ (for instance $x\sim N(0,I)$), then $\mathbb E\|Mx-ABx\|^2 = \|M-AB\|_F^2$ for every member, so the same number lower-bounds the expected squared error over the class. Additive observation noise is outside this statement. The bound is evaluated in one of two modes.

* `exact_rational_interval` (dimension at most `exact_max_dim`). The eigenvalues of the smaller Gram matrix ($MM^\top$ or $M^\top M$) are isolated in disjoint rational intervals by exact real-root isolation of its characteristic polynomial. Their squares-of-singular-values interpretation gives $\sum_{i>k}\sigma_i^2 \ge \sum_j a_j$, where $a_j$ are the lower endpoints of the intervals of the $\dim-k$ smallest eigenvalues, clipped at zero. A float entry is treated as its exact binary value. `certified_lower_bound` requires $\sum_j a_j > $ tolerance in exact arithmetic. The checker verifies each endpoint by a different method: by Sylvester's law of inertia, the number of eigenvalues of the Gram matrix $G$ below $a$ equals the number of sign changes in the sequence of leading principal minors of $G-aI$ (computed exactly), and the checker requires that at most $j-1$ eigenvalues lie below the $j$-th endpoint.
* `float64_with_margin`. Singular values from LAPACK minus a margin $\delta = 10\max(m,n)\,2^{-52}\sigma_1$ per value. The constant in this margin is heuristic, so the result is reported as `numerical_bound`, never as a proof.

A truncated-SVD witness is stored in float64; its error is recomputed exactly in rational arithmetic on the stored entries, and `witness_found` is issued only if that exact error is within tolerance.

## 3. Delayed-query communication bound (`message`)

**Task and domain.** $x\in\{0,1\}^n$, query $q\in\{0,\dots,n-1\}$, target $x_q$, over all $n2^n$ pairs.

**Communication restriction.** An encoder $e:\{0,1\}^n\to\{0,\dots,2^k-1\}$ sees $x$ but not $q$. A decoder $d(m,q)$ sees only the message and the query. There is no other path from $x$ to the decoder. The certificate is about this restricted class and says nothing about networks in which the query or the input can bypass the message.

**Exact minimum.** For a fixed encoder the error-minimising decoder outputs the majority value of $x_q$ in the block $e^{-1}(m)$, so $\mathrm{err}(e) = \sum_m\sum_q \min(o_{m,q}, |e^{-1}(m)|-o_{m,q})$ with $o_{m,q}$ the number of ones. The enumeration certificate evaluates all $(2^k)^{2^n}$ encoders, so its minimum is exact when `coverage.complete` is true (feasible for $(n,k)$ such as $(3,2)$ with 65536 encoders).

**Analytic bound.** A block of $s$ distinct vectors must vary in at least $\lceil\log_2 s\rceil$ coordinates, and each varying coordinate contributes at least one error. Hence $\mathrm{err}(e)\ge \min \sum_i \lceil\log_2 s_i\rceil$ over block sizes $s_i\ge 1$ with $\sum s_i = 2^n$ and at most $2^k$ blocks. In particular zero error is impossible if and only if $2^n>2^k$ (pigeonhole). This bound needs no enumeration and is issued as a separate `certified_lower_bound` certificate, which remains valid when the enumeration is `incomplete`.

## 4. One-hidden-layer ReLU networks on the real line (`piecewise`)

**Class.** $\mathcal N_w = \{x\mapsto c+\sum_{j=1}^{w} a_j\,\mathrm{relu}(u_jx+b_j)\}$ with real parameters, on the domain $\mathbb R$. The criterion is exact equality.

**Target.** A continuous piecewise-linear function given by rational points $t_1<\dots<t_p$, values $v_i$, and the slopes $s_L$ left of $t_1$ and $s_R$ right of $t_p$. Its genuine knots are the points where the slope changes, with slope changes $\Delta_j\neq 0$; with $r$ genuine knots it has $m=r+1$ affine pieces, the minimal number.

**Piece-count bound.** Each unit has at most one kink, so every member has at most $w$ kinks and at most $w+1$ pieces. Hence $m>w+1$ excludes exact representation. This bound is sound for any target.

**Exact characterisation.** For $r\ge 1$ the target lies in $\mathcal N_w$ if and only if $w\ge r+1$, or $w=r$ and some subset $J$ of the genuine knots has $\sum_{j\in J}\Delta_j = -s_L$. For $r=0$ it lies in $\mathcal N_w$ if and only if $s_L=0$ or $w\ge 2$.

*Proof sketch.* A unit with $u_j\neq0$ has its kink at $-b_j/u_j$ with slope change $a_j|u_j|$; it is left-facing ($u_j<0$, contributing slope $-a_j|u_j|$ for $x\to-\infty$) or right-facing (contributing nothing for $x\to-\infty$). Each genuine knot needs at least one unit kinking there, and a kink at a non-knot point must be cancelled by a second unit at the same point. With $w=r$ every knot has exactly one unit whose change equals $\Delta_j$, and the left slope equals $-\sum_{\text{left-facing}}\Delta_j$, which gives the subset condition. With $w\ge r+1$ a left-facing unit at $t_1$ with coefficient $-s_L$ and a right-facing unit at $t_1$ carrying the remaining change $\Delta_1+s_L$ fix the left slope, and the other knots get right-facing units. For $r=0$ a single unit with non-zero change creates a kink, while $s_L\,\mathrm{relu}(x-p) - s_L\,\mathrm{relu}(p-x)$ is affine.

Every witness is verified exactly by evaluating target and witness at all kinks of both functions and at one point beyond each end; two continuous piecewise-linear functions whose kinks lie in that set and that agree on it agree everywhere. Approximate representation (tolerance $>0$) is `unsupported`.

## 5. Finite transition systems (`transition`, work package I5)

**Process.** A system is a finite Markov chain specified by explicit moves. From each state a deterministic list of proposals is formed; each proposal has probability $1/(\text{number of proposals})$; an accepted proposal moves to its target state and a rejected proposal (or the rejected part of a Metropolis acceptance) is an explicit self-loop. Probabilities are exact rationals and must sum to one in every state. Tie breaking is fixed by the deterministic proposal order. Each state has an integer complexity and a rational loss.

**Systems provided.**

* `permutation_chain(m, K)`: a chain of $1\le L\le K$ permutations of $\{0,\dots,m-1\}$ with composed function $f=T_{L-1}\circ\dots\circ T_0$. Proposals: paired compensating mutations $T_i\leftarrow\tau T_i$, $T_{i+1}\leftarrow T_{i+1}\tau$ for every adjacent pair and transposition $\tau$ (always neutral); single mutations $T_i\leftarrow\tau T_i$ (never neutral, always rejected); insertion of an identity module at any position when $L<K$; deletion of a module, accepted only if $f$ is unchanged. Acceptance is exact neutrality of $f$. Complexity is $L$; loss is zero on reachable states. This is a positive control: the single-module state is reachable from every state. State counts: 43 for $(m,K)=(3,3)$, 259 for $(3,4)$, 601 for $(4,3)$.
* `absorbing_toy`: seven hand-specified states with a closed class $\{c_3,c_4\}$ that cannot return to the simple state $s_0$, a state $s_5$ whose only route to $s_0$ passes through a higher-loss state, and a variant in which $s_0$ is itself closed. It validates every label: from $s_1$ the process hits $s_0$ with probability $2/3$ yet entrenchment in $\{c_3,c_4\}$ is inevitable; from $s_5$ the expected time to $s_0$ is exactly 6.
* `quantized_chain(m, K, rule)`: a chain of up to $K$ modules acting on $m$ hidden bits. The input $x\in\{0,1\}^m$ is the initial hidden state; each module applies $m$ ternary threshold units ($w,b\in\{-1,0,1\}$, strict step); the output is bit 0 of the final state. Loss is the number of inputs on which the output differs from the target. Proposals: insert an identity module (when $L<K$), change one parameter of one module to one of its two other values, delete a module (when $L$ exceeds `min_len`). Acceptance rules: `neutral` (the full-domain output function is unchanged), `nonincreasing` (loss does not increase), `metropolis` (probability $\min(1, r^{\Delta\text{loss}})$ with rational $r\in(0,1)$, which is exact because loss changes are integers). Complexity is $L$. The default ($m=2$, $K=2$, target AND, neutral) has 3618 reachable states; with $K=1$ and Metropolis acceptance it has 730.

**Simple set.** $S^\ast$ is the set of states of complexity at most a threshold. The threshold is given explicitly or, for complete searches only, defaults to the minimum complexity among reachable states whose loss does not exceed the minimum initial loss.

**Return labels** (per state $s$, relative to $S^\ast$; all computed on the reachable graph of positive-probability moves):

* `in_simple_set`: $s\in S^\ast$.
* `return_possible_zero_loss_path`: some path from $s$ to $S^\ast$ never visits a state with loss above $\mathrm{loss}(s)$.
* `return_possible_only_via_higher_loss`: $S^\ast$ is reachable, but every path to it visits a state with higher loss (a positive loss barrier under this process).
* `return_impossible`: no path to $S^\ast$ exists in the complete reachable graph.
* `unsearched`: the search was incomplete and no path was found.
* `return_possible_witnessed_incomplete`: the search was incomplete, the threshold was given, and an explicit path to $S^\ast$ was found. This is a sound positive statement, but no barrier classification is made.

**Quantities.** Strongly connected components (iterative Tarjan; the checker uses Kosaraju) and closed classes (components with no outgoing positive-probability edge). The probability of ever entering $S^\ast$ and, where it equals one, the expected number of steps to enter it. Whether that probability equals one is decided graph-exactly: with $S^\ast$ made absorbing, it equals one if and only if no closed class avoiding $S^\ast$ is reachable. The remaining values come from linear systems solved in exact rational arithmetic when the number of unknowns is at most `exact_max_transient`, and in float64 otherwise (`hitting_arithmetic`, `time_arithmetic` record which). A long expected return time is flagged against `long_time_threshold`.

**Inevitability.** A closed class is bad if it contains no state of $S^\ast$. In a finite chain the process enters some closed class with probability one. Hence entrenchment is inevitable from an initial state if and only if every closed class reachable from it is bad (`entrenchment_inevitable`). This is decided by graph reachability in the complete state space and is never reported for incomplete searches. A reachable bad class alone (`bad_class_reachable`) shows that entrenchment is possible, not that it is inevitable.

**Scope.** Every statement concerns the stated finite stochastic process, with its proposal list, acceptance rule and state space. It does not transfer to stochastic gradient descent on real-valued networks, or to biological evolution, without a separate argument.

## Independent checker

`verify_certificate(path_or_dict)` returns `ok`, a `verdict`, `reasons` and `checks` (per claimed field: `exact`, `numerical` or `unchecked`).

* `verified` (ok = true): every claimed field was checked (exactly, or numerically where the certificate itself claims float arithmetic).
* `partially_checked` (ok = false): no contradiction was found but some claimed fields could not be checked (for example an exact hitting probability with more than 200 unknowns, or enumeration statistics above the brute-force limit).
* `unchecked` (ok = false): nothing beyond the schema could be checked.
* `rejected`: a claim is false or the certificate is malformed.

A finite JOB whose certificate is rejected gets status `invalid`; a job whose certificates are not all verified is `complete` with validity `unverified`.

What is re-derived, per type:

* **boolean_class / message**: the examined prefix (member index order 0 .. examined-1, digits least-significant first) is re-enumerated by brute force up to 400,000 members: minimum error, number of members meeting the tolerance, witness index inside the prefix, decoder attainment; proof claims re-enumerate the whole class. The analytic message bound is recomputed by a different recursion and the pigeonhole flag is checked.
* **rank_exact**: rank (and pivot columns) by exact Gaussian elimination; witness product exactly.
* **rank_approx**: singular values and tail numerically; interval lower bounds by inertia counts (exact); numerical bounds numerically.
* **piecewise**: knots, slopes, piece count and the subset condition; witnesses evaluated exactly at every breakpoint.
* **transition**: only the system specification `data.system` is trusted, and it must equal `class.system` and `edit_rules` (the threshold override is `class.simple_threshold_override`). From it the checker re-derives, with its own implementation:
  * the initial states and the whole reachable state space (its own BFS and move derivation, up to 300,000 states);
  * complexity and loss of every state and the simple-set threshold (given, or the minimum complexity over states with loss at most the minimum initial loss);
  * every return label, by a bottleneck shortest-path computation (minimal over paths of the maximal loss), which differs from the generator's per-level reverse searches;
  * closed classes with their full member sets, sizes, simple-set membership, complexity range and losses (Kosaraju);
  * reachable closed classes, inevitability and bad-class reachability for every initial state;
  * P(hit S*) = 1 graph-exactly;
  * hitting probabilities and expected hitting times by its own solver (exact rational Gaussian elimination when the certificate claims exact arithmetic, up to 200 unknowns, otherwise `unchecked`; a sparse float64 solve with a residual check and a relative tolerance of 1e-7 when the certificate claims float64);
  * the long-time flag, required exactly on initial states with a finite hitting time, against the configured threshold recorded in the class;
  * aggregate counts (states, edges, simple states, SCCs, label counts);
  * duplicated fields: `domain.n_states` = `data.n_states` = `coverage.examined`; `domain.state_cap` = `data.state_cap` = `class.state_cap`; `data.long_time_threshold` = `class.long_time_threshold`; `coverage.complete` and `coverage.incomplete_reason` against `data`; the `precision` string against the claimed arithmetic.

  When the per-state graph was exported, every state, complexity, loss, label and edge probability is compared. Nothing is sampled.

  **Incomplete analyses** claim only an explored subgraph and witnessed return paths inside it. The checker requires: the exported initial states are the specified ones; every exported state is reachable from them over exported edges; every exported edge is a transition of the specified system (for an expanded state the full re-derived distribution, zero-probability moves dropped; for the partially expanded state at the cap a subset of it with equal probabilities); at least one state is unexpanded; labels are `in_simple_set`, `return_possible_witnessed_incomplete` exactly for states with an exported path to S*, or `unsearched`; initial reports, threshold, counts and label counts recomputed; no closed-class, inevitability, hitting or arithmetic claims. Because every exported edge is a true transition and every exported state is truly reachable, a witnessed return path is a real path of the specified process. Without an exported graph, only the initial states are checked and the verdict is `partially_checked`.

  `run_finite_job` additionally rejects a transition certificate whose class (system, threshold override, state cap, long-time threshold) differs from the job configuration.

Adversarial tests (`tests/test_v2_audit.py::test_F1_*`) corrupt each claimed field in turn, including an internally consistent certificate built from a wrong complexity map with the true specification restored, and require rejection.
