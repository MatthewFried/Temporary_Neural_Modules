# Semantics of graphs, edits, training and claims

This document states exactly what the code does. Where the specification left a choice open, the choice made here is listed in DEVIATIONS.md as well.

## 1. Computation graphs

Every model is a `GraphNet` (cop/graph/graph.py). A node has a persistent id (`n<k>`), an op name, an ordered list of input node ids, attributes (feature dimension, layout, spatial size, coefficients), an optional parameter key `pkey` and an `owner` (the implant that created it, or `None` for the original backbone). Feature dimension is dimension 1 for vectors `(B,d)` and images `(B,C,H,W)` and the last dimension for sequences `(B,T,d)`.

Parameters live in `mods[pkey]`. Two nodes with the same pkey share storage; this is how tied copies, enforced inverses and recurrent or shared pearls are represented. Parameter counts are taken once per pkey; compute is counted once per node, so a module used s times costs s times its compute.

Because inputs are explicit per slot, a node cut (all consumers of a node) and an edge cut (selected consumers) are different edits. A residual block's input feeds both its branch and its skip; an edge cut on the skip edge changes only the skip.

The structural hash is a Merkle hash over the live graph that ignores node ids, so the same final graph built in a different order hashes equal. Identity nodes, single-input unit-coefficient sums and gates at 0 or 1 are transparent to the hash. The instance hash is a second Merkle hash in which every node's signature also contains a content fingerprint of its own module (all parameters and buffers, with dtype and shape), so it binds each weight tensor to its position: swapping two equal-shaped modules, folding new weights or changing a gate changes it, while equal computations (including transparent pass-throughs) hash equal. Deletion enumeration de-duplicates by instance hash and confirms every match on a probe batch before skipping an evaluation.

## 2. Cutpoints

Builders tag cutpoints: `input`, `pre_act` and `post_act` (MLP); `pre_bn`, `post_bn`, `post_act`, `block_out`, `resid_branch` (CNN and ResNet); `resid`, `attn_out`, `mlp_out`, `mlp_hidden` (Transformer); `gru_out` (GRU). A cutpoint stores the consumer edges it feeds. It is resolved at insertion time to whatever node currently feeds those edges, so inserting twice at the same cutpoint builds a chain. Cutpoints with several consumers carry named edge subsets (`branch`, `skip`).

An implant can be restricted to a coordinate or channel subset (select, transform, scatter back) or to a token or spatial subset (`base + mask * (T(base) - base)`). Implants also record their own internal cutpoints (`hidden`, `pre_act`, `branch_input`, `skip`, `mid`), which is where recursive insertions go.

The parent of a new implant is the innermost implant containing all consumer nodes of the cut. For a node cut it is the implant that owns the source as an internal value, or that implant's parent when the source is its exit; in addition every implant whose entry was the source is re-pointed to the new exit, so a node cut placed before an existing implant stays before it.

## 3. Insertion constructions and identity guarantees

| Construction | Code | Guarantee at insertion |
|---|---|---|
| A residual zero output `h + B act(A h)`, `B = 0`, A random | `insert_residual_zero` | exact identity |
| bridge `h_dst + B act(A h_src)` (skip over a bottleneck, complementary input, known module) | `insert_bridge` | exact identity |
| B identity factorisation `W2 W1 = I` (orthogonal `m >= d`, or invertible `m = d`) | `insert_linear_factor` | identity up to float rounding |
| B node factorisation of an existing linear map, `W = W2 W1` by SVD | `factorize_node` | output preserving; deletion means folding |
| C duplicated segment, merge `lambda orig + (1 - lambda) copy` | `insert_dup_branch` | output preserving; `lambda != 0.5` is an exact symmetry breaker; parameter noise is labelled approximate |
| D cancelling pair `h + u(h) - v(h)`, `u = v`, nonzero output layers | `insert_cancel_pair` | output preserving; tied (shared storage) or untied; noise labelled approximate |
| E inverse pair `T^{-1} T`: additive coupling or linear | `insert_inverse_pair` | `enforced`: global identity for all parameter values (shared m, or exact inverse of the live W); `untied`: identity at insertion only, measured afterwards; `learned`: approximate |
| F concatenation expansion `P [h; act(A h)]`, `P = [I, 0]` | `insert_concat_expand` | exact identity; projection counted |
| groups with deletable branches, merge by sum, concatenation projection, or softmax routing | `insert_group`, `add_branch` | exact identity (zero-output branches, zero projection columns). Routing: a zero expert is exact only while every existing expert outputs zero; next to trained experts the new expert is an exact split of the most recent expert (copied or tied parameters, router logits `l + log s`, `l + log(1-s)`, `s = growth.route_split`); otherwise declared approximate |
| communication-limited implant `h + D(Q(E act(A h)))`, `D = 0` | `insert_residual_peg` | exact identity |
| peg `alpha h + (1 - alpha)[D(Q(E h)) + beta R(h)]`, `alpha = 1` | `insert_peg` | identity because of the recorded bypass, not because the code suffices |

A bare ReLU between signed activations is not an identity and is never used as one. Every insertion in a trajectory (incremental and all-at-once) is checked on training calibration inputs, validation inputs (fresh IID) and stress inputs. Labels: `exact` (within the identity tolerance); `L0_approximate` (the round contains implants DECLARED approximate and deleting exactly those restores the outputs within tolerance); otherwise `L0_failed_exact_insertion`, which is a violated contract: the offending model and diagnostics are saved, the job ends with status `invalid`, and it never trains on or enters the exact-expansion population. From-scratch schedules carry `not_applicable_from_scratch`. These checks are empirical; only the guarantees in the table are claimed globally.

## 4. Deletion

Atoms are implants whose deletion is allowed. Region(I) is the set of nodes owned by I or any descendant of I.

* Series implant: remove the region; every use of its exit outside the region reads its entry instead; other implants pointing at the exit are re-pointed.
* Branch implant: remove the region; drop its term from the parent's merge. Duplicated-branch merges renormalise their coefficients; deleting every term of such a merge is invalid. Cancelling merges do not renormalise.
* Fold implant (node factorisation): replace the region by the exact affine map it computes (float64 probe).

Deleting an ancestor removes its descendants, so subsets are canonicalised by dropping descendants of deleted ancestors, and resulting graphs are grouped by instance hash. Up to `max_exhaustive_atoms` (default 10) atoms every subset is enumerated; above that the family is singles, sibling groups, generation groups, descendant-only groups, contiguous chain segments, all pairs (up to 16 atoms) and a seeded sample. The output records which family was used.

`Delta_A = R(D_A(f)) - R(f)` with R the cross-entropy (classification) or MSE (regression) on the stated partition. `J(A,B) = R(D_{A u B}) - R(D_A) - R(D_B) + R(f)`. Negative values are kept.

## 5. Outcome labels and what produces them

| Label | Produced by | Scope |
|---|---|---|
| L0 insertion changed the function | trajectory insertion checks, control jobs | measured on calibration, fresh and stress inputs |
| L1 deleting an addition changes the trained function | `L1_single_deletion_changes_function` in `deletions_*.json`, single-deletion rows every round | fixed remaining weights |
| L2 no allowed deletion subset preserves the criterion | `L2_certificate_no_valid_deletion` in deletion certificates, only when the family was exhaustive | fixed weights, that deletion family, that evaluation partition (complete finite domain when available), fp32 |
| L3 a repair procedure fails in a region and budget | repair jobs: `reach` table, `None` means right-censored at the budget | that region, target, optimizer, seeds and budget only |
| L4 every member of a finite class fails, or a lower bound applies | finite certificates (cop/finite) | the stated class, domain and exactness |
| L5 a simplification path is obstructed in a finite state space | transition-system certificates | the stated finite process |

A failed optimisation is never reported as L4. A timeout or a capped search is `incomplete` or `unsearched`, never a proof.

## 6. Export

`export_compact` removes gates at 0 or 1 (a peg at `alpha = 0` loses its bypass edge; a temporary channel at `beta = 0` loses its term), drops auxiliary heads, slices inactive merge terms, removes transparent nodes and dead modules, and optionally folds adjacent linear maps when that does not increase parameters (decoders fold into the next linear map, so pearls consume codes directly). The exported model is evaluated against the source model on supplied inputs, and for every peg the code checks whether a path from the input to the output avoids the quantiser (`has_bypass`, which ignores edges whose effective weight is exactly zero).

## 7. Accounting

Parameters: once per storage over effectively live nodes, including adapters, encoders, decoders, routers, codebooks and retained bypass maps. Compute: analytic multiply-accumulates per node per invocation, multiplied by spatial positions or tokens. Communication through a peg per example: positions times coordinates times bits for continuous and uniform pegs (continuous coordinates are charged `float_bits`, default 32), positions times messages times `ceil(log2 codebook)` for codebooks. A one-channel feature map is `H*W` numbers, not one scalar.

## 8. Training

All randomness comes from named streams (`data`, `teacher`, `split`, `subset`, `noise`, `init`, `insertion`, `minibatch`, `augmentation`, `deletion`, `repair`, `policy`, `mutation`, `fresh`, `peg`, `assembly`) derived by SHA-256 from (seed, stream, keys). Implant initialisation is keyed by a structural slot label, so different histories that build the same graph draw the same initial implant weights. Every topology of a cell continues from the same baseline checkpoint including its optimizer and minibatch-generator state, so the minibatch sequence after the baseline is identical across topologies.

Optimizer state on an edit is preserved for surviving parameters (or reset when `opt_state_on_edit = reset`); new parameters start with fresh state; inherited momentum is therefore an explicit factor. Freeze policies set `requires_grad`, exclude parameters from the optimizer, and force frozen normalisation layers into eval mode so their running statistics do not change. A shared parameter used inside and outside the trainable region is an error.

Learning-rate schedules are computed from the segment step, so resume is exact. Checkpoints hold the graph spec, parameters and buffers, optimizer state, generator states, epoch permutation and position, and the stage. On CPU an interrupted and resumed run reproduces the uninterrupted run bitwise (T19). TF32 is disabled by default; `--allow-tf32` is a named speed variant.

Targets: `task` (labels), `expanded` (distillation to the current expanded model), `original` (distillation to the baseline). Classification distillation is temperature-scaled KL; regression uses MSE.

History drivers: fixed finite data; fresh samples of the same target; a changing teacher `(1 - lambda_r) T0 + lambda_r T1`; output-constrained training toward the round-start model; an explicit neutral-mutation process (Gaussian proposals accepted when output change and calibration risk stay within tolerance; labelled as a deliberate perturbation); and the exact stationary control (squared error to the model's own round-start outputs, which has zero gradient, so plain SGD stays put while inherited momentum or weight decay moves the parameters).

## 9. Selection and partitions

Data-driven choices use training calibration data (hard-submodule selection, adaptive cut policies, adaptive peg placement, quantiser calibration, PCA initialisation) or validation data (deletion choice for repair, hard-pearl selection). Test partitions are evaluated at prespecified stages and never select anything. Wave 4's parent selection uses validation deletion effects with a fixed tertile rule and run-id hash order.


## 10. Validity, provenance and analysis cells (v2)

* **Completion vs validity.** `complete` means the job finished; `status.json` also carries `validity`: `valid`, or `unverified` when a claimed property could not be checked (for example a finite certificate above the checker's limits). A violated contract (failed exactness, failed required control, rejected certificate, off-alphabet codes under an enforced interface, matched-control architecture mismatch, held-out assembly used in training) raises `ScientificInvalid`: status `invalid`, diagnostics in `invalid.json`, dependants `skipped_with_reason`. Validity propagates: a child of an `unverified` parent is `unverified`.
* **Provenance.** `provenance.json` records the semantic code hash (every file except orchestration, analysis, the CLI and the environment report). A completed, unsupported or invalid run whose hash differs from the running code is `stale`: it is not reused, not accepted as a parent (one validation API, `RunContext.parent_dir`), and blocks its dependants until it is rerun or a reasoned reuse is recorded in `reuse_accepted.jsonl`. The analysis uses the same effective status, so stale runs are never pooled. The numerics settings (TF32, cuDNN benchmark, deterministic algorithms) are semantic code and the applied values are recorded in `provenance.json`.
* **Analysis cells.** A cell is a condition: `condition_id` = hash of the full logical config with replication fields (data seed, teacher seed, every `seeds.*`), lineage (parent run ids) and pure I/O settings (`train.checkpoint_every`, `eval.save_predictions`) removed. Every manipulated setting separates cells. Within a cell the replication key must be unique. A treated run is paired with its continued baseline only if they agree on data, model, train (freeze excepted), seeds, baseline parent, exposure and driver. Figures plot condition-level means (one point per condition).

## 11. Interfaces in Chain-of-Pearls replacements (v2)

A peg's interface is its quantiser: mode, bits or codebook, calibrated range buffers, shape and positions. With `cop.interface_enforce = enforced` (default) every replacement output and every adapter output passes the destination quantiser (its value is exactly the code; in training the gradient passes unchanged, an unclipped straight-through estimator, so saturated outputs are pulled back into range), and every evaluated assembly is checked for membership (distance in quantisation steps, or relative to the codebook scale, below 1e-3). Communication is recomputed per assembly from its actual boundaries. `relaxed` is a separately named continuous condition (replacement codes charged at `float_bits`). Table alternatives are indexed by the canonical integer symbols of the incoming quantiser (copied ranges / codebooks), one row per message. Image codes are quantised per channel (channels-last). Alternatives and sub-pearls read only the incoming code, so a reference whose middle pearl reads a late input is refused (`unsupported`).

## 12. Matched controls and measured work (v2)

`direct_small` and `distill` copy the exported endpoint of the parent cycles history, re-initialise every trainable tensor (named stream), re-calibrate every quantiser on training activations of the re-initialised network and again on the control's own training activations at K - 1 evenly spaced points of one continuous run (K = `cycles`), and assert equal structural hash, parameters and MACs with the parent endpoint before training and after export. Exposure is the parent's MEASURED training updates (+ baseline updates for direct_small, which has no pretrained parent). Every job records measured work by phase (`work`: updates, examples, forward examples for code caches, seconds); equal updates are not equal FLOPs.

## 13. Resume contract (v2)

Every training phase resumes at update granularity; every manual local loop (P3 / P4 fits, adapters, P5 replacement fits, Theseus, shared fold, neutral mutation) at step granularity, with module, optimizer and generator states. Multi-stage jobs checkpoint each completed stage with its bookkeeping (curves, assembly usage counts, cycle boundaries, created replacements, measured work), and replay finished stages from their saved results. A resumed job restores its measured work and exposure counters from the checkpoint it resumes from (including stages it does not rerun, such as finished chain training or known-module pretraining). An interrupted job reproduces the uninterrupted one bitwise on CPU (test_F11_*, sandbox_checks/resume_comparisons.json). Deletion and finite jobs are evaluation-only and recompute on restart.
