# Strengthening extension (v5, semantics `cop-5.0.0`)

What the strengthening addendum asks for, and where it is in the code. Wave 7 (`cop/orchestration/wave7.py`) builds the jobs. `cop/analysis/strengthening.py` computes the tables and figures 1 to 7; `cop/analysis/v5_tables.py` adds the v5 tables and figures 8 and 9. The registry status is in `configs/strengthening_registry_status.json`.

## Treated histories and controls

A treated history starts from a saved f0 (a `baseline` job) and is a chain of jobs:

* `trajectory`: grow and train. With `growth.contract_every > 0` it runs grow/contract cycles itself and ends in the f0 architecture.
* `dissipation`: contraction back to f0's architecture. The export must have f0's architecture (Merkle `architecture_hash`, no node ids). Otherwise the job is `invalid`.
* `repair`: abrupt removal plus a repair region, data access and optimizer-state policy.
* CoP `cop` jobs: chains, cycles and alternatives.

The endpoint carries the META `design` section: `family`, `variant`, `arm`, `budget_panel`, `target_regime` and `contrast`. This section enters the run id. Intermediate jobs carry no design, so several contrasts share them.

| control | job | budget |
|---|---|---|
| C0 | f0 itself (no job; the analysis reads f0's `baseline` metrics) | none |
| C1 | `continue` from f0, arm `plain` (full set: also at 0.3x and 3x the learning rate, `C1_lr0.3`, `C1_lr3.0`) | `parent_updates`: the treated chain's measured post-f0 updates |
| C2 | `continue` from f0, arm `plain` | `parent_compute`: ceil((estimated chain training MACs + teacher forward MACs) / (3 x forward MACs x batch)); refused when the parent's compute is incomplete (CoP cycles / alternatives, whose local fits count updates but no MACs). The rounding overshoot is in `budget.json` (`overshoot_macs`) |
| C3 | `trajectory` with `growth.schedule = from_scratch`, then the same contraction | matched exposure |
| C4 | `continue`, arm `distill`, teacher = the treated expanded model (`final`) | `parent_updates`; teacher forwards charged as `teacher_macs` |
| C5 | `continue`, arm `self_distill`, teacher = f0, `distill_alpha 0.5` | `parent_updates` |
| C6 | `dissipation` `fold` of the same trajectory, where the implant is affine (F01d at s = 0) | no training |
| C7 | `continue` arms `lr_restart`, `opt_reset`, `perturb` (relative norm 0.01) | `parent_updates`, split into two segments |
| C8 | `continue`, arm `prune_regrow` (weight-norm pruning, orthogonal regrowth). Masked rows are re-zeroed after every optimizer step, so evaluation and checkpoints see the pruned model; optimizer moments of the affected rows are zeroed at prune and at regrowth (`moment_policy reset_at_prune_and_regrow`); masks and events resume exactly | `parent_updates`, image cell only |
| M1 / M2 | endpoint-matched CoP controls: `continue` with `start treated`, `start_stage export`, `reinit true`, so the control trains the treated export's architecture from re-initialisation (tables zeroed, quantisers re-calibrated, architecture asserted). Budget = the treated chain's updates (M1) or estimated compute (M2) plus f0's own budget (`budget_add_f0`). CoP cycles use the existing `direct_small` baseline as M1 | as stated |

Training MACs are an estimate, not a measurement. `Trainer.state.train_macs` adds 3 x forward MACs x batch per update (`macs_method estimated_dense_3x_forward`), where forward MACs are the analytic count of the effective graph at that step. A backward-aware estimate is kept beside it (`train_macs_bwd`: forward, plus weight gradients of trainable nodes, plus input gradients of nodes with a trainable ancestor). Every phase records `macs_complete`; a phase with local fits or other uncounted work is incomplete, and so is any chain containing it. Updates, examples, estimated MACs, wall time and peak memory are reported separately.

`chain_work` (in `experiments/continuation.py`) works as follows:

* It sums the treated chain's own work and that of its `trajectory` ancestors, and excludes f0.
* A child that starts from `snap_<u>` of its trajectory is charged the trajectory's counters up to that snapshot.
* Phases named `diagnostic:*` are excluded. One example is the repaired clone of F07e, which is not the exported chain.

## Endpoints and estimands (v4)

Every job that produces a model writes `endpoint.json`. It names the checkpoint, reloads it, and evaluates it under stage `endpoint` on every partition (predictions saved). It records the update count, `diverged` and `diverged_reason`, finiteness of tensors and metrics, `architecture_hash`, parameters, MACs and peg bits. Repair always evaluates at its last update, so a curve can never stop at an earlier point. The trainer checks the loss before backward and the updated parameters after every optimizer step, including the last; a failure marks the run diverged and stops it, and the run stays in every denominator.

The analysis compares endpoints under three estimands:

* `fixed_architecture`: treated, control and f0 have one architecture hash (which includes parameter sharing).
* `matched_endpoint`: treated and control share an architecture that differs from f0's (M1 / M2 against a CoP export).
* `cost_frontier`: the architectures differ (for example C1 from f0 against a smaller CoP export). These rows are descriptive.

A pairing key is (contrast, f0 run, arm, replication, budget panel). Pairs must also agree on data identity, model identity and target regime. A duplicated key is an error in strict mode and is excluded and recorded otherwise. Every summary row reports expected, eligible, diverged, ineligible and unmatched counts. Intervals are exploratory percentile bootstraps over replications.

Specialist pretraining (F10e) is charged at 3 x its forward MACs, plus one frozen-model forward with cut access. Damage-trigger probes (F06e) are charged at one forward per example. Wall time is reported separately (`seconds`), never as compute. The analysis uses the same walk.

Target regimes: T1 is `train.target = task`. T0 is `train.target = teacher_star`, which trains on the known teacher's clean output. Regression uses `y_clean`; classification uses the teacher's logits (distillation). Validation enforces `design.target_regime T0 <=> train.target teacher_star`. The T0/T1 panel uses noisy targets and a partially trained f0 (a quarter of the baseline budget), so the two regimes differ. Teacher-imitation error is logged separately from task risk: `teacher_imitation_mse`/`nmse` for regression, `kl`/`disagreement` for classification.

## Variant map (wave 7)

Cell names are in the contrast labels. `main` = teacher depth 3, n = 2048, MLP 64 x 4. Each history uses `linear` gate contraction (`speed = post = upr / 2`) unless stated otherwise.

| id | config |
|---|---|
| F01a | `topology linear_factor`; CNN `node_factorization` (k x k conv -> 1 x 1, SVD); contraction `fold`. Decay panel on an MLP `node_factorization`: no decay, uniform (factor-wise) 1e-4, composite-map 1e-4 |
| F01b | `node_split`, `split` 0.5 / 0.1 (branch balance); `fold` |
| F01c | `inverse_pair` linear, `inverse_cond` 1 / 100, `tie` enforced / untied; fp64 at 100; `fold` |
| F01d | residual-zero with `growth.nonlinearity` 0 / 0.25 / 1 (act `mix`); s = 0 is affine and gets C6 `fold` |
| F01e | `bottleneck` (PCA-initialised rank k, optional uniform bits); recorded as approximate at insertion |
| F02a | `cut_where` early / middle / late |
| F02b | `channels` 1 / 8 / all |
| F02c | transformer `cut_subset` branch / skip / all consumers |
| F02d | compose `cut_where probe:z` versus `probe_random:z` (matched dimension and scale) |
| F02e | `recursive` (cut inside the earlier implant) versus `layered` (fresh cut) |
| F03a-e | `layered`, `parallel` sum, `diamond`, `chunked`, three rounds each, at equal added cost PER ROUND in two panels (`width_match params` 4192 = one 64-32-64 implant; `width_match macs` 4096). A program with several modules per round splits the round's budget: chunked over its chunks, diamond round 1 over branch and bridge. `tree_depth2` (F03c) is reported at its actual cost |
| F04a-d | growth-phase policy (tag `..._growth_policy__contraction_trains_all`; each phase's trainable set is logged as `trainable_state`): `train.freeze` original_frozen; implants_frozen after the implant first learns alone for upr/4 (`freeze_schedule release`, since a zero-output implant frozen from the start stays zero); none; `freeze_schedule alternate` |
| F04e | `freeze_schedule release` (two release times; the schedule restarts with each round's new implant), two snapshots after the last release, and repair ladders from each (mechanism B) |
| F05a | `dissipation abrupt` + post updates; `repair full` |
| F05b | `linear` / `cosine`, two speeds, `target` task / expanded (teacher matching); the final gate is exactly 0 |
| F05c | `stochastic_bypass`, `bypass_rescale` off / on; the deterministic export is evaluated |
| F05d | CoP cycles: `pre_finetune_*` is the assembled risk with no global update; the fine-tune is costed separately |
| F05e | `group_removal`; deletion job with `compare_greedy` (greedy at the group search's evaluation count) |
| F06a | `contract_every 1`, 1/2/4/8 cycles at equal total, and a per-cycle budget-scaling panel; round trip without training |
| F06b | `schedule` incremental / all_at_once |
| F06c | dissipation `order` oldest_first / newest_first / ancestor_first / descendant_first / joint. The total contraction and post-removal budget is split over the phases, so every order costs the same. A descendant scheduled after its ancestor has no phase of its own, so ancestor_first is one joint removal. An implant whose internal values another target reads is removed in the reader's phase |
| F06d | f0 snapshots at 25 / 50 / 75% (`tags.f0_stage`), equal remaining updates; controls continue from the same snapshot |
| F06e | `contract_trigger` damage (threshold 0.05, maximum interval 2; probe cost counted) versus fixed every 1 (the v3 policy comparison) and fixed every 2 (matched maximum interval), plus `contract_trigger replay`, which contracts at the rounds the damage-triggered run actually used (read from its `contractions.json`) |
| F07a | CoP chain, continuous pegs, dim 2 / 8 / 32 (float bits counted) |
| F07b | uniform pegs with 1, 2, 3, 4, 8, 16 bits (dim 1) |
| F07c | CoP cycles, 2 x 2: `cycle_peg_maps` frozen / learned x `cycle_peg_width` constant / narrowed, recalibration on; plus the compound presets `fixed` (frozen, constant, no recalibration) and `relearned` (learned, narrowed, recalibrated). Each cycle records `peg_dims` and `peg_bits_per_example`, so paired map-adaptation cells can be checked for equal widths and narrowing events. Frozen maps fix the encoder and decoder, not the codes: upstream activations still change |
| F07d | CoP alternatives `independent/aligned` versus `joint/learned` (the alignment map is counted) |
| F07e | `peg.redundancy 2` (repetition code at equal bits) versus `cop.route_blocks 2`; `peg.route_dropout`; per-route damage; removal of one route plus repair |
| F08a-e | repair ladder: readout, incident adapters, adjacent 1/2, full with optimizer reset/preserve, fresh compact (labels or teacher), data access. The access arms are: 256 retained calibration inputs with the expanded model as the label-free target; train (labels or teacher); fresh; checkpoint oracle |
| F09a-d | n 256 / 2048 / 16384; teacher depth 1 / 3 / 6; target noise, shortcut rho; rare prevalence x `sampler` uniform / group_balanced |
| F09e | delayed query, `query_at_layer` -1 (before the peg) / 1 (after), `query_op` bit / xor_next / two_bits |
| F10a-c | residual MLP; CNN `kernel` 3 versus 1; transformer `growth.mixer attention` versus `mlp` |
| F10d | `known_module mixing_random` / `mixing_aligned` (frozen mixing, trainable adapters) |
| F10e | pretrained specialist, frozen / partially trainable / fully trainable |

Mechanisms:

* A: `bridge` helper reading causal / shortcut / random features (shortcut data). Exports are evaluated on the paired counterfactual partitions `cf_base`, `cf_causal` and `cf_shortcut`, and on `shift` and `rare`.
* B: release snapshots, then repair ladders from each.
* C: `transplant` jobs. The transplant runs in both directions between f0 and the post-cycle model, with `align` none or affine. Alignment is fitted on training inputs only. The image cell adds BN recalibration.
* D: removal order in a tree and in a diamond, at equal post-removal updates, with rare cases tracked.
* E: `later_query` data. Decoders are fitted on training codes: a majority table per message for finite codes, least squares for continuous codes. An input re-access control uses the same decoder.
* F: same, moving and nested cycle cuts, each at `contract_every` 1 and 2, so topology and contraction frequency are crossed; then a common continuation from every export (durability).
* G: `twin_helpers` with schedule alternate / both / single / stochastic, after which both helpers are removed.
* H: `peg.temp_channel` with `temp_on middle` and `temp_open_updates`. The bridge is then retired into the bridged peg (`temp_target peg`) or every peg (`pegs`), or kept as an adapter (`adapter`; its parameters and float bits are counted).

Mandatory crosses: X1 to X5 (blocks `W7_cross_*`). X3 compares map adaptation at constant width.

Controls assume a constant learning rate (wave 7's default). A non-constant schedule or warmup makes the manifest generator refuse to build controls, because segment matching to the treatment's schedule is not implemented.

Size and complexity panel: n 512 / 8192 x depth 2 / 5, for F01a, F03c, F05b, F06a and F10a.

Inapplicable cells and their reasons are listed under `strengthening.inapplicable` in the manifest's coverage file.

## v5 additions (review of v4)

P0 to P5 below are the review's priorities, not the specification's CoP work packages P1 to P5.

Terminology. The ratio eta = (R_C1 - R_compact) / (R_C1 - R_expanded) is called gain retention. It is descriptive, not a mechanism and not a fraction of computation "absorbed". Both the numerator and the denominator are always reported. R_expanded is the test risk of the model the contraction job actually started from, read from its own diagnostics record (this covers starts from snapshots, where the parent logs no metrics), with the parent's stage metrics as a fallback; when neither exists the row says why. eta is undefined (None, with the reason) when the denominator is at or below `DELTA = 1e-3`, including zero and negative denominators, and it is never clipped, so it can exceed 1 or be negative.

Four operations are kept apart in every table: bypass (gate to 0 or deletion of the implant, fixed weights), fold (an exact algebraic rewrite of an affine implant into existing weights, F01a), fitted replacement (the affine map of P1 below, used only as a diagnostic on a clone), and learned repair (post-removal updates or a repair job).

Review P0, compact witness. `cop/data/witness.py` builds the teacher exactly inside the student when that is possible: same activation, MLP without BN or late query, student width and depth at least the teacher's (extra layers are ReLU identity blocks), with the output standardisation folded into the head. It is verified against the noiseless teacher on train, val, test and a fresh sample (maximum absolute error at most 1e-4) and saved as checkpoint `witness` with `witness.json`. Wave 7 adds a ReLU teacher (depth 4, width 64) that the MLP 64 x 4 realises exactly (blocks `W7_v5_witness`, `W7_v5_witness_targets_T0/T1`). The tanh teacher cells stay as the approximation-mismatch condition, and `witness.json` says why. With a witness, gap closure (R_C1 - R_compact) / (R_C1 - R_witness) is reported for regression on clean held-out targets. A witness separates approximation error from the rest; estimation error and label noise remain.

Review P1, contraction diagnostics (`cop/experiments/diagnostics.py`). Before every contraction (dissipation start, repair start, each grow / contract cycle) and for every implant that will be removed:

* affine residual of the implant map, fitted on the first `eval.calib_size` training inputs and scored on validation inputs: `rho_raw`, `rho_rel_output` (fraction of output variance left), `rho_rel_change` (relative to the implant's change of its input), condition number and rank;
* downstream residual: mean squared Jacobian-vector product of the residual through the rest of the network (first order);
* virtual affine replacement: a clone in which the implant's output is replaced by the fitted map, evaluated on val and test (an intervention measurement of immediate damage);
* baseline predictors beside them: single deletion damage, implant output size, gate values, pre-contraction risk.

Nothing is changed: parameters, buffers, gates and the CPU and CUDA RNG states are fingerprinted before and after, and a difference fails the job. Maps are saved (`diagnostics/<tag>.pt`), records go to `contraction_diagnostics.json`, and fit, replacement and JVP seconds are recorded. rho is not scale-free and is not a damage predictor on its own: a residual of size epsilon can carry the whole task signal, and a large residual can be ignored downstream (both are tests). Block `W7_v5_fold_frozen_backbone` folds a linear factor with the backbone frozen, which isolates the fold from learned repair.

Review P2, exact finite interfaces (`cop/finite/codebook.py`, `cop/cop_pegs/finite_interface.py`). On the uniform complete cube {0,1}^n with an independent uniform query, a query-blind encoder of at most 2^K messages and a decoder that sees only the message and the query, the minimum error is a minimum over decoder codebooks (exact enumeration with an XOR anchor). Retention with the original task kept at zero error forces task-pure cells and is solved by labelled codebooks. The full trade-off frontier comes from encoder enumeration where that is small. Precomputed values with their cross-checks are in `configs/finite_interface_optima.json`; incomplete enumerations are reported as incomplete, never as optimal.

* Family A (`FIN_A`, delayed query): e_model (the network), e_oracle (the best decoder of the network's own code) and e_star (the optimum), with e_model - e_star = (e_model - e_oracle) + (e_oracle - e_star).
* Family B (`FIN_B`, original task x_0 or a two-bit parity, later queries): the code's later-query oracle error against the unconstrained optimum, the task-preserving optimum, and the frontier at the code's own task error.
* K counts every bit at the bottleneck peg (dim x bits). A score is only computed after any bridge is removed, with no bypass around the peg and a query-blind encoder (checked statically and on the data); otherwise the row says why it does not apply.
* Bridge arms at one K per n, matched in total updates: no bridge, temporary bridge retired gradually or abruptly (scored before, right after and after recovery), and a permanent bridge (diagnostic: the bound does not apply).
* These splits are labelled complete-domain: train, val and test are the whole cube, so the scores are analysis diagnostics of a finite problem, not generalisation estimates.

Review P3, interface locality (`cop/cop_pegs/locality.py`, task kind `locality`, block `W7_v5_locality`). Five arms on one f0 per seed, with the same placement, schedule and data stream: no interface, continuous pegs, continuous pegs with the pegs frozen after the anneal (stabilized), learned finite pegs, and stabilized finite pegs. At co-adaptation checkpoints (25, 50, 100% of endpoint training) the middle pearl is replaced by a locally fitted module, and forks repair it with nested scopes: 0 nothing, 1 the replacement, 2 plus the incident peg maps (equal to 1 for the no-interface arm, recorded as such), 3 the contiguous region from the previous to the next pearl (the neighbouring pearls and, for pegged arms, the rest of the two incident pegs), 4 everything. Success at a tolerance is the declared criterion against the checkpoint's own exported model. The reported value is the smallest successful tested scope; diverged or failed forks never count, and no success is censored (not an infinite cost). Also recorded: literal and permutation-invariant code change between checkpoints, and for finite pegs a certificate that compares the pearl's outgoing code for every incoming code. The full table is enumerated up to 65,536 incoming codes (the wave-7 peg, 8 coordinates x 2 bits, has exactly that many), so a change on a code never seen in the data is caught; above that only the calibration codes are checked and the record says the result is coverage-conditional.

Review P4, static dependence game (`cop/analysis/dependence_game.py`). Built from complete exhaustive deletion landscapes only; a structured, sampled or partly invalid landscape is rejected with its reason. Damage sign: d(S) = R(delete S) - R(checkpoint). Reported: Shapley values, pair and Shapley interactions, Moebius terms by order, greedy against best-k, the min-max removal path and the minimum batch size per tolerance. The inverse pair has Shapley values 0 and an interaction of -2, and needs a batch of 2. Strong interactions do not by themselves make greedy fail. This is a fixed-weight analysis; repaired removal paths are a separate experiment.

Review P5, transplant grid (`transplant.design grid`, block `W7_v5_transplant_grid`). All four upstream x downstream pairs of f0 and the post-cycle model, for each adapter family: identity, orthogonal (centred Procrustes), affine, residual MLP (activation matching), and affine and MLP adapters trained on the task through the frozen network. Every pair, including the two self pairs, gets the same family and fitting budget, and adapter parameters are reported. The contrast is whether the new upstream improves the old downstream over the old upstream under equivalent adapter fitting, per partition. Because the post-cycle model has trained longer than f0, a second grid (arm `grid_vs_C1`) uses as model A f0 continued for the cycle history's measured updates (C1), so the contrast is not just extra training. A transplant does not separate features from conventions: a private convention can itself be an affine map.

## Section 7 calibrations

`cop/calibration/boundary.py` is a byte-identical port of the supplied `boundary_checks.py` (its output is checked against the supplied `boundary_results.json`). It adds `query_before_encoding()`, which replaces a vacuous assertion in the supplied script. `tests/test_strengthening.py` runs the same examples through the graph code: the factorised scalar's one-step update through the real optimizer, the finite message certificates (n = 3: 12/6/4/0 errors; before-encoding 12/0/0; x0-only 8 of 24), single-versus-group necessity on an inverse pair, and incompatible code conventions with their alignment.

## Outputs (`cop summarize` -> `summary/strengthening/`)

* `s_endpoints.csv`: every design job, with status, design fields, endpoint risk on every partition, teacher-imitation error, export parameters and MACs, and post-f0 updates, examples and MACs. The teacher chain is included for C4.
* `s_<estimand>_<metric>.csv` and `s_<estimand>_pairs_<metric>.csv`: G = R(control) - R(treated) per estimand, with the counts above. A synthetic C0 row compares against f0.
* `s_endpoint_eligibility.csv/json` (every design job with its reasons), `s_rejected.csv/json` (every excluded entry or pairing with its reason), `s_untested_or_ineligible_cells.json`.
* `s_cycles.csv`, `s_repair_scope.csv` (trainable parameters and graph distance), `s_repair_curves.csv`, `s_transplants.csv`, `s_cop_extension.csv` (bridges, routes, later queries). Transplant and alternatives jobs hold several models, so they are reported per row there, not as paired endpoints.
* v5: `s_gain_retention.csv`, `s_witness.csv`, `s_contraction_diagnostics.csv`, `s_predictor_screen.json` (exploratory; discovery replication and held-out replications), `s_finite_interface.csv`, `s_locality.csv`, `s_dependence_game.csv/json`, `s_transplant_grid.csv`; figures `s_fig8_locality.png` and `s_fig9_finite_interfaces.png`.
* Figures `s_fig1` to `s_fig7`, matching the addendum's list. Figures are faceted by estimand, task and metric; MACs, parameters and bits are never on one axis; no figure truncates to the first runs. They are screening views.
