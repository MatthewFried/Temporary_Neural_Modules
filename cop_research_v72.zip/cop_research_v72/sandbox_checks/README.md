# Sandbox checks for v2 (CPU, smoke scale)

These files come from the machine where the code was written. It has 2 CPU cores and no GPU, and runs Python 3.13 with torch 2.14.1+cpu.

They show that the v2 code paths run and that the audit's contracts hold. **They are not experimental results.**
- Budgets are the `smoke` scale, about 2% of the specified updates.
- Only one job per manifest block was sampled.
- Nothing ran on a GPU.

Every run here was produced by the frozen v2 code (semantic hash `5f0fc17a02584937`, recorded in each run's `provenance.json`).

## Test results

`test_results/` holds the full pytest output: `pytest.txt` and `junit.xml`. Result: 190 passed, 2 skipped, 0 failed. The suite consists of:
- T01-T24;
- the data tests and finite tests;
- `tests/test_v2_audit.py`, which holds the regression tests derived from the audit and from the second-pass review (R1-R11), including the adversarial certificate tests and the job-level resume tests.

Skips: T22 (CPU vs GPU), which runs on the GPU machine, and the CIFAR-100 real-data test, because CIFAR-100 could not be downloaded here (the test never downloads). The other real-data tests ran against the downloaded Covertype, California, Fashion-MNIST and CIFAR-10.

## Interrupt and resume

`resume_comparisons.json` holds the job-level interrupted-versus-uninterrupted comparisons. For each job kind:
- the job runs once uninterrupted;
- it runs once interrupted at about 30% and 70% of its loop polls (30% and 90% for the two late-interruption cases from the second-pass review), then resumed to completion;
- checkpoints (parameter hashes), metrics (latest attempt per key), result files and measured work are compared.

`equal: true` means bitwise equal. All 30 job kinds are equal.

## P3 / P4 reload

`reload_checks.json` covers every P3 / P4 run in the samples. For each run, a fresh process rebuilds the saved reference, modules, interfaces and adapters. It then reproduces every saved assembly / variant prediction bitwise, along with the risks, parameter counts, communication bits and local errors. All 10 sampled runs (7 alternatives, 3 split) reload with maximum difference 0.

## Matched controls

`matched_controls.json` covers every matched control in the samples. It records parent and control exported parameters and structural hashes, which must be equal, the exposure (the parent's measured updates, plus the baseline updates for `direct_small`) and the updates at which the control re-fitted its quantisers. All 3 sampled controls are equal to their parent endpoints.

## Sampled runs

`sampled_runs/` covers waves 0-5 and the wave-9 integration pilot. For each block, the first job and its prerequisites were run: 200 runs, all complete and valid.

CIFAR-10 jobs take 4 to 9 minutes each on this CPU. Those already run are included. The remaining 29 were not sampled (`not_sampled` in `sample_log_part2.txt`); the wave-9 pilot covers CIFAR-10 on the GPU. Two CIFAR-10 trajectories are not complete: `W3_I1_compute_cifar10` reached the 900 s per-job limit (`timed_out`, resumable), and one `W3_schedules_cifar10` job shows `running` because I stopped the sampler while it ran. The CUDA control job is left for the GPU machine.
- `status_counts.json`: status and validity of every sampled job.
- `summary/`: `summarize` output, including tables, conditions, analysis errors, the validity quarantine and figures.
- `examples/`: nine complete run directories (trajectory, repair, dissipation, deletion, finite transition, P3, P4, P5 cycles, matched control), without checkpoints.
- `sample_log_part1.txt`, `sample_log_part2.txt`: the sampler's output (part 1 was stopped to skip the remaining CIFAR-10 jobs; part 2 reused every finished run).

## How these were produced

Every file here can be regenerated with the scripts in `audit_v2/tools/`: `resume_comparisons.py`, `sample_waves.py` and `collect_evidence.py`.

## Other files

- `manifest_counts.txt`: job counts per wave and block at full scale, the factorial checks, validation, and the condition-collision check.
- `environment_sandbox.json`: the sandbox environment report.

## v3

`v3/` holds the v3 checks:

* `wave7_smoke_status.json`: all 1,098 wave-7 jobs at smoke scale on CPU, all complete and valid.
* `wave7_smoke_summary/`: strengthening tables and figures at smoke scale. These test the pipeline only; they are not results.
* `wave7_smoke_coverage.json`
* `resume_comparisons_v3.json`: 16 new job paths, each bitwise equal to its uninterrupted run.
* `pytest_full.txt`: 245 passed, 2 skipped.
