# v10 sandbox evidence (CPU only)

v10 = v9 plus summary robustness (DEVIATIONS 123). Only analysis code, scripts and tests changed; the semantic code hash is the same as v9 (e2a10a454f51abe7), so the v9 lab pilot's results stay current.

* full CPU suite: 366 passed, 13 skipped (12 need CUDA, 1 needs CIFAR-100 data), 0 failed (`pytest_full.txt`, `junit.xml`)
* `test_summary_survives_nonfinite_dissipation_risks_and_a_failing_figure` reproduces the lab crash on v9 code (TypeError in Fig 7) and passes on v10; it also checks that a failing figure leaves the later figures and summary.json in place
* `cop summarize` on the v8 CPU wave-7 smoke (1359 jobs): exit 0, 20 figures, no figure errors, no strengthening error
