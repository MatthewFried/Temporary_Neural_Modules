# v11 sandbox evidence (CPU only)

v11 = v10 plus gate handling of recorded numerical failures (DEVIATIONS 124). Only analysis code, audit tools and tests changed; the semantic code hash is still e2a10a454f51abe7, the same as the v9 lab pilot.

* full CPU suite: 369 passed, 13 skipped (12 need CUDA, 1 needs CIFAR-100 data), 0 failed (`pytest_full.txt`, `junit.xml`)
* new tests: `test_a_child_of_a_recorded_invalid_parent_is_excluded_by_record_not_passed` (excluded only by the parent's own record of that checkpoint; otherwise still a failure), `test_reload_accepts_a_recorded_invalid_endpoint_only_if_it_reproduces_exactly`, `test_recompute_compares_nonfinite_recorded_risks_correctly`
* v11 checker on the v8 CPU wave-7 smoke: passes, nothing excluded (`check_v8_smoke_with_v11.json`)
