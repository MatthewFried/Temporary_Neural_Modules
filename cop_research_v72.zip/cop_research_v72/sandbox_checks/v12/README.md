# v12 sandbox evidence (CPU only)

v12 = v11 plus the amended stability rule of the identity check (DEVIATIONS 125). Semantic code changed (hash 1f35d905ce3f2bc8; v9 was e2a10a454f51abe7).

* full CPU suite: 370 passed, 13 skipped (12 need CUDA, 1 needs CIFAR-100 data), 0 failed (`pytest_full.txt`, `junit.xml`)
* `test_preexisting_execution_roundoff_does_not_quarantine_an_exact_edit` uses the lab case (a = 0, u_pre = u_post = 5.0e-4 on stress): exact with the stress set flagged; an edit that adds 5e-4 of round-off is still `unstable`; a perturbed weight is still `changed`. The earlier identity tests (cancellation example, ill-conditioned inverse pair at condition 1e7, digits control) pass unchanged.
* not rerun here: the wave-7 smoke and Wave 0 (the validation phase on the lab machine runs both with v12)
