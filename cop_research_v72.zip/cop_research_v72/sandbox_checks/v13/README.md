# v13 sandbox checks (CPU only, Python 3.13, torch CPU)

These are engineering checks of the final v13 code. Nothing here is a scientific result: the re-pilot ran at smoke
scale (budget multiplier 0.02) on CPU. CUDA tests cannot run here; scripts/15 runs them on the GPU and fails if any
is skipped.

| File | What it shows |
|---|---|
| pytest_full_cpu.txt / .xml | full suite: 401 passed, 15 skipped (14 CUDA tests, 1 test that needs downloaded CIFAR-100) |
| cuda_tests_on_cpu_all_skipped.txt | the CUDA selection (`-k "cuda or gpu_equivalence"`): all skipped here, as expected |
| probe_identity_on_v13.json | the audit's GraphNet counterexample: `execution_changed`, d_edit = 6.0 (v12 said `exact`) |
| probe_baseline_cost_on_v13.json | the audit's 5-update baseline: run_work reports its 26,880 MACs (v12 reported 0) |
| scripts15_smoke_run.log, smoke_repilot_verdict.json | scripts/15 end to end at smoke scale on CPU with a stand-in v9 folder: every step passed except `cuda_skips` (no GPU); the stand-in v9 folder was not modified |
| smoke_status13.txt, smoke_checks13.json, smoke_fresh_reload13.json | all 288 wave-13 jobs complete and valid; every endpoint reloads in a fresh process |
| smoke_numeric_validity.json | 0 own-invalid endpoints, 0 invalid descendants, 60 complete diagnostic rows, 20 multi-model jobs listed apart |
| s13_analyses.json | which table answers which of the three analyses |
| manifest_counts.json | wave 13 (288 jobs) and wave 14 (1818 jobs) by block and arm; wave-14 replications (data draw, optimizer seed) |
| rates_from_v9_gpu_pilot.json, runtime_*_v9rates.json | runtime estimates from the v9 GPU pilot's measured timings (see below) |
| runtime_wave14_pilot_from_cpu_smoke_rates.json | the same estimator fitted on the CPU smoke run (a plumbing check, not a GPU estimate) |

Smoke re-pilot engineering observations (smoke budgets; not results): the exact-local-replacement control matched
the reference in 180 / 180 locality rows and the frozen-code lookup in 72 / 72 finite-peg rows; group metadata never
changed a prediction (60 / 60 specialization-derived rows); scratch resets left no trained tensor (48 / 48); finite-code
MAC matching landed at 1.001-1.019 x the reference (one update of granularity at this scale); validation-selected
tables formed 110 fixed-architecture and 88 matched-endpoint pairs, and the tuned table 26.

## Runtime (RTX A4500, one worker, from the v9 GPU pilot's timings)

| Manifest | Jobs | Estimate |
|---|---|---|
| wave 13 re-pilot, pilot scale | 288 | about 0.8 h |
| wave 14 confirmation, pilot scale | 1818 | about 3.5 h |
| wave 14 confirmation, full scale | 1818 | about 10.6 h by the fit; about 14 h after the correction below |

The fit (sec = a + b x trained updates per kind, data and model family) reproduces the v9 pilot (2.33 h) but
underestimates the v9 full-scale runtime sample of wave 7 by 1.41 x overall (continuations by about 2 x), so
full-scale figures are low. scripts/15 re-fits on the re-pilot's own timings and writes the wave-14 estimate
(`v13_reports/runtime14_*.json`); scripts/16 freeze records it with the frozen protocol.
