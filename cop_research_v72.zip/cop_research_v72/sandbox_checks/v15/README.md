# v15 sandbox checks (CPU only)

Engineering checks of the final v15 code; nothing here is a scientific result (smoke scale, budget multiplier
0.02, CPU). CUDA tests run on the GPU in scripts/17 (a skip fails that script).

| File | What it shows |
|---|---|
| pytest_full_cpu.txt / .xml | full suite: 427 passed, 15 skipped (14 CUDA, 1 needs downloaded CIFAR-100) |
| ../../audit_v7/evidence/review_probes_on_v15.json | the v14 review's own probe script (audit_v7/probes) on v15: retention overwrite, cross-seed pairing, removal metrics omitted and launcher failure masking all no longer reproduce (the launcher exits 1 with the injected stage failures 7 / 8 / 9) |
| scripts17_smoke_run.log, smoke_panel_verdict.json | scripts/17 end to end on CPU at smoke scale, with the v13 smoke re-pilot as the stand-in v13 folder: every step passed except `cuda_skips` (no GPU); the v13 folder was not modified; the v13 rebuild ran read-only |
| smoke_status15.txt, smoke_checks15.json, smoke_fresh_reload15.json | all 84 wave-15 jobs complete and valid; every endpoint reloads in a fresh process |
| runtime_wave15_full_from_lab_rates.json, runtime_wave14_full_from_lab_rates.json | estimates from the lab re-pilot's measured timings: wave 15 (84 jobs) about 0.7 h; revised wave 14 (1976 jobs) about 17 h serial |
