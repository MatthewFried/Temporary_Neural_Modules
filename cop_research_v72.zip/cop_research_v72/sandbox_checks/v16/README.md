# v16 sandbox checks (CPU only)

Unit tests only; no smoke run of the waves this time. Nothing here is a scientific result.

| File | What it shows |
|---|---|
| pytest_full_cpu.txt / .xml | full suite: 432 passed, 19 skipped (14 need CUDA, 5 need downloaded datasets) |
| runtime_wave15_full_from_lab_rates.json | wave 15, 94 jobs, about 1.6 h serial from the lab re-pilot's measured timings |
| runtime_wave14_full_from_lab_rates.json | revised wave 14, 1976 jobs, about 17.1 h serial |
