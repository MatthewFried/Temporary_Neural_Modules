# v17 sandbox checks (CPU only)

Unit tests only; no wave was run here. Nothing here is a scientific result.

| File | What it shows |
|---|---|
| pytest_full_cpu.txt / .xml | full suite: 446 passed, 19 skipped (14 need CUDA, 5 need downloaded datasets) |
| runtime_wave16_full_planning.json | wave 16, 106 jobs, about 1.1 h serial (re-pilot and v16 panel rates; panel preferred where measured) |
| runtime_wave14_full_planning.json | revised wave 14, 2234 jobs, about 20.9 h serial; scripts/18 refits on all measured runs |
