# v19 sandbox checks (CPU only)

Nothing here is a scientific result.

| File | What it shows |
|---|---|
| pytest_full_cpu.txt / .xml | full suite: 467 passed, 19 skipped (14 need CUDA, 5 need downloaded datasets) |
| subset40_status.txt, subset40_checks.json, subset40_fresh_reload.json | 40 wave-17 jobs at smoke scale (draw 0; every block, three swap sets, three reassignment arms, the recode chain cell): all complete and valid, result checks pass, every endpoint reloads bitwise in a fresh process, strict summary passes |
| runtime_wave17_full.json | 228 jobs, about 1.5 h serial from the lab's combined timing fit (recode jobs priced as chains) |
