# Sandbox checks for v4 (CPU only)

Machine: 2 CPU cores, no GPU, Python 3.13, torch 2.14.1+cpu. Code: `cop-4.0.0`, semantic hash `932d3eadcd8c26ac` (in every run's `provenance.json`). Nothing here is an experimental result, and nothing ran on a GPU.

| file | what it shows |
|---|---|
| `pytest_full.txt`, `junit.xml` | the whole suite on v4: 274 passed, 9 skipped (7 CUDA; CIFAR-10 / CIFAR-100 not downloadable here); per-test device and status in `../../TEST_MATRIX.md` / `.json` |
| `wave7_smoke_status.json` / `.txt` | all 1,201 wave-7 smoke jobs `complete` and `valid` on CPU, 710 s wall with 3 workers |
| `wave7_smoke_summary/` | `cop summarize` strengthening output for that run: per-estimand tables, `s_endpoint_eligibility.csv/json`, `s_rejected.csv/json`, `s_untested_or_ineligible_cells.json`, figures |
| `rejection_examples.json` | deliverable E: a duplicated control, a control with another data identity and a diverged treated row injected into the real smoke table; the strict error, the non-strict records, the affected summary rows, and real CoP exports classified against C1 (cost frontier) and M1 / M2 (matched endpoint) |
| `fresh_reload.json` | deliverable D: a new process reloaded 1,232 endpoint and transplant checkpoints of the smoke run; all reproduce the saved test predictions bitwise, with equal architecture hashes |
| `resume_comparisons_v4.json` / `.log` | 21 interrupted-versus-uninterrupted job paths (the 16 v3 paths plus C8 ending mid-prune, M1, cycle peg switches, repair final evaluation, replay) bitwise equal; the transplant has no training loop to interrupt, and its rerun outputs are equal |
| `runtime_smoke.json`, `runtime_pilot_cpu.json` | deliverable G: the estimator checked against the measured smoke run (predicted 687 s, measured 710 s), and a measured CPU estimate for the pilot from a stratum sample |
| `manifest_counts.txt` | job counts of the regenerated v4 manifests |

The 14 ineligible design jobs in the smoke summary are the 12 transplants and 2 CoP alternatives runs. They hold several models each and are reported per row in `s_transplants.csv` and `s_cop_extension.csv`.
