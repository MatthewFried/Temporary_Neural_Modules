# Sandbox checks for v5 (CPU only)

Machine: 2 CPU cores, no GPU, Python 3.13, torch 2.14.1+cpu. Code: `cop-5.0.0`, semantic hash `4a2a4a3e2d634443` (in every run's `provenance.json`). Nothing here is an experimental result, and nothing ran on a GPU.

| file | what it shows |
|---|---|
| `pytest_full.txt`, `junit.xml` | the whole suite on v5: 312 passed, 11 skipped (9 CUDA; CIFAR-10 / CIFAR-100 not downloadable here); per-test device and status in `../../TEST_MATRIX.md` / `.json` |
| `wave7_smoke_status.json` / `.txt` | all 1,359 wave-7 smoke jobs `complete` and `valid` on CPU, 651 s wall with 2 workers (`wave7_smoke_wall.txt`) |
| `wave7_smoke_summary/` | `cop summarize` strengthening output, including the v5 tables (`s_gain_retention`, `s_witness`, `s_contraction_diagnostics`, `s_predictor_screen`, `s_finite_interface`, `s_locality`, `s_dependence_game`, `s_transplant_grid`) and figures 8 and 9 |
| `fresh_reload.json` | a new process reloaded 1,546 endpoint and transplant checkpoints (single and grid designs); all reproduce the saved test predictions bitwise with equal architecture hashes; both realisable witnesses reload, re-verify against the teacher and reproduce their recorded test risk |
| `resume_comparisons_v5.json` / `.log` | the 8 new job paths (dissipation and repair with diagnostics, three locality arms, a finite chain with a gradual bridge, the transplant grid, a witness baseline) are bitwise equal after interruption |
| `resume_comparisons_v4_on_v5.json` / `.log` | the 22 v4 paths rerun on v5 code: 21 bitwise equal after interruption; the affine transplant has no training loop to interrupt and its rerun outputs are equal |
| `runtime_smoke.json` | runtime estimator against the measured smoke run: predicted 627 s, measured 651 s (2 workers) |
| `added_work_v5_blocks.json` | serial seconds of the v5 blocks at smoke scale (about 103 s of 1,254 s), plus the diagnostics' own fit, replacement and JVP seconds inside the older blocks (about 28 s); smoke scale on CPU, so this only shows the order of the added work |
| `manifest_counts.txt` | job counts of the regenerated v5 manifests |

Smoke-scale budgets are tiny (tens of updates), so almost every locality fork is censored and the finite codes are far from optimal. These files show that the code paths run end to end; they are not results.
