# v8 sandbox evidence (CPU only)

Host: 2 CPU cores, no GPU, Python 3.13, torch 2.14.1+cpu (the lab's torch version), code `cop-5.0.0` (v8). Produced by `evidence_v8.sh` then `evidence_v8_part2.sh`; full console logs are `evidence_run.log` and `evidence_run_part2.log`; every step's exit status is in `step_exit_codes.txt`.

## Results

| check | result | file |
|---|---|---|
| full CPU test suite (final code) | 362 passed, 11 skipped (10 need CUDA, 1 needs CIFAR-100), 0 failed | `pytest_full.txt`, `junit.xml`, `../../TEST_MATRIX.md` |
| full CPU test suite (first run, kept visible) | 5 failed: the historical grid-table test, after I made the grid table select jobs by their config only. Fixed (a job counts as grid if its config or its result says grid) and rerun above | `evidence_run.log` |
| Wave 0 on CPU (20 control and finite jobs) | 20 complete and valid, `cop gate` exit 0. The digits float32 control that failed under v6 passes: high-precision gap 9.8e-7 (tolerance 1e-5), post-edit round-off 9.2e-6 (bound 1e-4). The CIFAR ResNet control took 57 min on one thread | `wave0_cpu_gate.txt`, `wave0_cpu_run.log` |
| wave-7 smoke, fresh, v8 code | 1359 of 1359 jobs complete and valid (599 s, 2 workers) | `wave7_smoke_wall.txt` |
| v8 checks on that smoke | passed: manifest 1359/1359, 432 diagnostic rows in 267 files all complete, 168 grid assemblies all eligible | `check_v8_smoke.json` |
| audit scanner on that smoke | 0 flags of any kind | `scan_v8_smoke.json` |
| recovery manifest on that smoke | 1359 `reusable_unchanged` | `recovery_manifest_v8_smoke.json` |
| fresh-process reload | 1546 of 1546 bitwise equal after restoring recorded numerics; 2 of 2 witnesses; 0 excluded | `fresh_reload_v8_smoke.json` |
| resume, v5 helper | passed: 8 cases, all interrupted and equal | `resume_comparisons_v5.json` |
| resume, v4 helper | passed: 22 cases, 21 interrupted and equal, `transplant_affine` repeatability only (no training loop) | `resume_comparisons_v4_on_v8.json` |
| review archive | built; checkpoints beyond the 50 MB default budget listed as omissions | `package_for_review.txt` |
| the audit's probes, unmodified | exit 1 as expected: 6 no longer reproduce; `identity_gate` errors because the gate now requires `pre=`; `divergent_transplant` flags by its own criterion although the job is `unverified` and every affine_task contrast is null | `audit_probes_on_v8.txt` |

## Scanner: my results versus the audit's injected failures

* My own v5 sandbox smoke (real results): 16 incomplete diagnostic rows in 11 dissipation runs (6 float64/float32 dtype errors, 10 attention-derivative errors), exactly the rows in the audit's `supplied_smoke_errors.csv`. No diverged fits, no non-finite contrasts or deletion values, no relaxed insertion gates (that code predates the v7 rule). `scan_sandbox_v5_smoke.json`.
* The audit's divergent-transplant fixture (injected on purpose by its probe): 4 diverged affine_task fits and 18 non-finite contrasts in one job. `scan_audit_injected_fixture.json`. These are not problems in any real results.

## Recovery applied to my v5 sandbox smoke

* before: 11 runs `needs_diagnostic_recompute`, 1348 `reusable_unchanged`; `check_results --diagnostics` fails with the 16 rows.
* `recompute-diagnostics`: 11 records written, every one `ok` (`diag-8.0`, source = the parent checkpoint, recorded and loaded parameter hashes equal, original pre-contraction risk reproduced, all measurements complete). The original `contraction_diagnostics.json` files are unchanged. Records: `recomputed_diagnostics_sandbox_v5_smoke/`.
* `replay-cycles`: nothing to replay (no incomplete cycle diagnostic). `recheck-insertions`: nothing flagged.
* after: 1359 `reusable_unchanged`; `check_results --diagnostics` passes with the 16 rows listed as resolved by recompute.

## Not covered here

CUDA: every CUDA test (Transformer JVP with the math kernel, GRU JVP with cuDNN off, float64 diagnostics, a GPU Transformer dissipation job, CPU versus GPU control) runs only on the lab GPU in scripts/12, where a skip fails the gate. Cycle replay and insertion rechecks on real v7 results are tested only by the unit tests (`tests/test_v8_audit.py`), since no sandbox results have those flags. The user's live pilot was not inspected.
