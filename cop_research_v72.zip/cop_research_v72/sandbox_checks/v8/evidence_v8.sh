#!/usr/bin/env bash
# v8 sandbox evidence on the final code (CPU).  Writes into $R/sandbox_checks/v8 (keeps the earlier v8 files).
set -uo pipefail
R=/home/claude/cop_research
S=/tmp/claude-0/-home-claude/f4b400f2-b7e5-526a-8f3a-bc104cf81cd6/scratchpad
E=$R/sandbox_checks/v8
cd "$R"
export PYTHONPATH="$R" COP_DATA_ROOT="${COP_DATA_ROOT:-$HOME/cop_data}"
mkdir -p "$E"
find . -name __pycache__ -prune -exec rm -rf {} + 2>/dev/null
st() { echo "$1 $2" >> "$E/step_exit_codes.txt"; echo "== $1 exit $2"; }
: > "$E/step_exit_codes.txt"
echo "== pytest"; date
python -m pytest tests -q -p no:cacheprovider -rs --junitxml "$E/junit.xml" > "$E/pytest_full.txt" 2>&1; st pytest $?
tail -3 "$E/pytest_full.txt"
python audit_v4/tools/test_matrix.py "$E/junit.xml" "$R/TEST_MATRIX" --host-note "2 CPU cores, no GPU, Python 3.13, torch 2.14.1+cpu, code cop-5.0.0 (v8)" > /dev/null; st test_matrix $?
echo "== manifests"; date
: > "$E/manifest_counts.txt"
for w in 0 1 2 3 4 5; do python -m cop.cli generate-manifest --wave $w --scale full --out manifests/wave${w}_full.jsonl >> "$E/manifest_counts.txt" 2>&1; done
python -m cop.cli generate-manifest --wave 7 --scale full --out manifests/wave7_full.jsonl >> "$E/manifest_counts.txt" 2>&1
python -m cop.cli generate-manifest --wave 7 --scale pilot --out manifests/wave7_pilot.jsonl >> "$E/manifest_counts.txt" 2>&1
python -m cop.cli generate-manifest --wave 9 --scale pilot --out manifests/wave9_pilot.jsonl >> "$E/manifest_counts.txt" 2>&1
for f in manifests/*.jsonl; do python -m cop.cli validate-manifest --manifest "$f" > /dev/null || echo "INVALID $f" | tee -a "$E/manifest_counts.txt"; done
echo "== wave-0 CPU controls"; date
W0=$S/w0_v8; rm -rf "$W0"
python -m cop.cli run --manifest manifests/wave0_full.jsonl --results "$W0" --device cpu --data-root "$COP_DATA_ROOT" --workers 2 --threads 1 > "$S/w0_v8_run.log" 2>&1; st wave0_run $?
python -m cop.cli gate --manifest manifests/wave0_full.jsonl --results "$W0" --device cpu > "$E/wave0_cpu_gate.txt" 2>&1; st wave0_gate $?
tail -5 "$E/wave0_cpu_gate.txt"
echo "== wave-7 smoke"; date
M=$S/w7v8f_smoke.jsonl; RES=$S/w7v8f
rm -rf "$RES"
python -m cop.cli generate-manifest --wave 7 --scale smoke --out "$M" > /dev/null
t0=$(date +%s)
python -m cop.cli run --manifest "$M" --results "$RES" --device cpu --data-root "$COP_DATA_ROOT" --workers 2 --threads 1 --resume > "$S/w7v8f_run.log" 2>&1; st smoke_run $?
t1=$(date +%s); echo "smoke wall seconds $((t1-t0))" | tee "$E/wave7_smoke_wall.txt"
python audit_v8/tools/check_results.py "$RES" "$E/check_v8_smoke.json" --manifest "$M" --diagnostics --transplants > "$E/check_v8_smoke.txt" 2>&1; st smoke_checks $?
cat "$E/check_v8_smoke.txt" | head -20
python audit_v8/tools/scan_v7_results.py "$RES" --out "$E/scan_v8_smoke.json" --check-insertions > "$E/scan_v8_smoke.txt" 2>&1; st smoke_scan $?
tail -5 "$E/scan_v8_smoke.txt"
python -m cop.cli recovery-manifest --results "$RES" --out "$E/recovery_manifest_v8_smoke.json" > /dev/null 2>&1; st smoke_recovery_manifest $?
echo "== summarize"; date
rm -rf "$S/w7v8f_sum"
python -m cop.cli summarize --results "$RES" --manifest "$M" --out "$S/w7v8f_sum" > "$S/w7v8f_sum.log" 2>&1; st summarize $?
rm -rf "$E/wave7_smoke_summary"; mkdir -p "$E/wave7_smoke_summary"
cp -r "$S/w7v8f_sum/strengthening" "$E/wave7_smoke_summary/" 2>/dev/null
cp "$S/w7v8f_sum/summary.json" "$S/w7v8f_sum/analysis_errors.json" "$E/wave7_smoke_summary/" 2>/dev/null
echo "== fresh reload"; date
python audit_v5/tools/fresh_reload.py "$RES" "$E/fresh_reload_v8_smoke.json" --device cpu --data-root "$COP_DATA_ROOT" > "$E/fresh_reload_v8_smoke.txt" 2>&1; st fresh_reload $?
head -c 800 "$E/fresh_reload_v8_smoke.txt"
echo "== review archive"; date
python -m cop.cli package-for-review --results "$RES" --out "$S/review_v8_smoke.zip" --manifests manifests > "$E/package_for_review.txt" 2>&1; st package_for_review $?
cat "$E/package_for_review.txt"
echo "== resume"; date
rm -rf "$S/resume_v5_v8" "$S/resume_v4_v8"
python audit_v5/tools/resume_comparisons_v5.py "$S/resume_v5_v8" > "$E/resume_comparisons_v5.log" 2>&1; st resume_v5 $?; cp "$S/resume_v5_v8/report.json" "$E/resume_comparisons_v5.json"
python audit_v4/tools/resume_comparisons_v4.py "$S/resume_v4_v8" > "$E/resume_comparisons_v4_on_v8.log" 2>&1; st resume_v4 $?; cp "$S/resume_v4_v8/report.json" "$E/resume_comparisons_v4_on_v8.json"
echo "== probes"; date
rm -rf "$S/probe_v8_final"; python -I $S/v7audit/independent_probes.py "$R" "$S/probe_v8_final" > "$E/audit_probes_on_v8.txt" 2>&1; st audit_probes_expected_1 $?
echo "== done"; date
cat "$E/step_exit_codes.txt"
