#!/usr/bin/env bash
# Part 2: final full pytest, and the v8 recovery tooling applied to my v5 sandbox smoke (which has the 16
# incomplete diagnostic rows the audit pointed at).
set -uo pipefail
R=/home/claude/cop_research
S=/tmp/claude-0/-home-claude/f4b400f2-b7e5-526a-8f3a-bc104cf81cd6/scratchpad
E=$R/sandbox_checks/v8
cd "$R"
export PYTHONPATH="$R" COP_DATA_ROOT="${COP_DATA_ROOT:-$HOME/cop_data}"
find . -name __pycache__ -prune -exec rm -rf {} + 2>/dev/null
st() { echo "$1 $2" >> "$E/step_exit_codes.txt"; echo "== $1 exit $2"; }
echo "== pytest (final)"; date
python -m pytest tests -q -p no:cacheprovider -rs --junitxml "$E/junit.xml" > "$E/pytest_full.txt" 2>&1; st pytest_final $?
tail -3 "$E/pytest_full.txt"
python audit_v4/tools/test_matrix.py "$E/junit.xml" "$R/TEST_MATRIX" --host-note "2 CPU cores, no GPU, Python 3.13, torch 2.14.1+cpu, code cop-5.0.0 (v8)" > /dev/null; st test_matrix_final $?
echo "== recovery on the v5 sandbox smoke"; date
V5=$S/w7v5_final
[ -d "$V5/recomputed_diagnostics" ] && mv "$V5/recomputed_diagnostics" "$S/w7v5_final_recomputed_prereview_$(date +%s)"
python audit_v8/tools/scan_v7_results.py "$V5" --out "$E/scan_sandbox_v5_smoke.json" --check-insertions > "$E/scan_sandbox_v5_smoke.txt" 2>&1; st v5smoke_scan_expected_1 $?
python audit_v8/tools/check_results.py "$V5" "$E/check_sandbox_v5_smoke_before.json" --diagnostics-if-any --transplants-if-any > "$E/check_sandbox_v5_smoke_before.txt" 2>&1; st v5smoke_check_before_expected_1 $?
python -m cop.cli recovery-manifest --results "$V5" --out "$E/recovery_manifest_sandbox_v5_smoke_before.json" > /dev/null 2>&1; st v5smoke_manifest_before $?
python -m cop.cli recompute-diagnostics --results "$V5" --out "$E/recompute_sandbox_v5_smoke.json" --device cpu --data-root "$COP_DATA_ROOT" > "$E/recompute_sandbox_v5_smoke.txt" 2>&1; st v5smoke_recompute $?
rm -rf "$S/replay_v5smoke"
python -m cop.cli replay-cycles --results "$V5" --out "$E/replay_sandbox_v5_smoke.json" --scratch "$S/replay_v5smoke" --device cpu --data-root "$COP_DATA_ROOT" > "$E/replay_sandbox_v5_smoke.txt" 2>&1; st v5smoke_replay $?
python -m cop.cli recheck-insertions --results "$V5" --out "$E/recheck_insertions_sandbox_v5_smoke.json" --device cpu --data-root "$COP_DATA_ROOT" > "$E/recheck_insertions_sandbox_v5_smoke.txt" 2>&1; st v5smoke_recheck $?
python -m cop.cli recovery-manifest --results "$V5" --out "$E/recovery_manifest_sandbox_v5_smoke_after.json" > /dev/null 2>&1; st v5smoke_manifest_after $?
python audit_v8/tools/check_results.py "$V5" "$E/check_sandbox_v5_smoke_after.json" --diagnostics --transplants-if-any > "$E/check_sandbox_v5_smoke_after.txt" 2>&1; st v5smoke_check_after $?
cp "$S/v8evidence/scan_audit_injected_fixture.json" "$E/" 2>/dev/null
echo "== done2"; date
