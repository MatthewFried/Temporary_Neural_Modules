# v9 sandbox evidence (CPU only)

v9 = v8 plus three CPU/GPU device fixes (DEVIATIONS 122). The lab GPU found the first one: both MLP Wave-0 GPU controls failed in the fold check on v7 and on v8 with "mat1 is on cpu, different from other tensors on cuda:0". A full code audit for the same bug class found the other two (probe-selected cuts, task-aligned known module) and one latent case.

* full CPU suite: 365 passed, 13 skipped (12 need CUDA, 1 needs CIFAR-100 data), 0 failed (`pytest_full.txt`, `junit.xml`, `../../TEST_MATRIX.md`)
* the new meta-device tests fail on v8 code and pass on v9 (`test_fold_runs_on_the_models_device_not_on_cpu`, `test_probe_cut_and_bottleneck_build_tensors_on_the_activation_device`); `test_mixing_aligned_known_module_is_fitted_on_cpu` checks the CPU fit and orthogonality but cannot reproduce the GPU failure on meta, so `test_cuda_probe_cut_and_mixing_aligned` (GPU) is the real check for that path
* the two MLP Wave-0 controls on CPU with v9: complete and valid, `cop gate` exit 0 (`wave0_mlp_cpu_controls_gate.txt`)
* not run again here: the wave-7 smoke and reload (CPU results are unchanged by these fixes; the v8 evidence in `../v8/` stands). The GPU paths run in scripts/02 and scripts/12 on the lab machine.
