#!/usr/bin/env bash
# Download FashionMNIST, CIFAR-10/100 (torchvision) and Covertype / California housing (sklearn)
# into $COP_DATA_ROOT so every later run is offline.  Download time is not training time.
source "$(dirname "$0")/common.sh"
cop fetch-data --root "$COP_DATA_ROOT"
