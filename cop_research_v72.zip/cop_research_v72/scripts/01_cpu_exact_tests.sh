#!/usr/bin/env bash
# Wave 0 on CPU: acceptance tests T01-T24 (pytest) and the Wave-0 control/finite jobs.
source "$(dirname "$0")/common.sh"
TS=$(date +%Y%m%d-%H%M%S)
mkdir -p "$COP_RESULTS/tests"
COP_DATA_ROOT="$COP_DATA_ROOT" python -m pytest tests -q -rs --junitxml "$COP_RESULTS/tests/junit_$TS.xml" \
   2>&1 | tee "$COP_RESULTS/tests/acceptance_$TS.txt"
DEVICE=cpu WORKERS=1 run_wave 0
# gate: every CPU control and finite validation job must be complete and valid
cop gate --manifest "$COP_HOME/manifests/wave0_${SCALE}.jsonl" --results "$COP_RESULTS" --device cpu
