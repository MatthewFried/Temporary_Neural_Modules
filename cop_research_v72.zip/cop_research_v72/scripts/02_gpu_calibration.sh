#!/usr/bin/env bash
# GPU: real CUDA training check, Wave-0 controls on the GPU (dtype/backend, CPU-vs-GPU),
# timing of representative jobs, and runtime/disk estimates for every wave manifest.
source "$(dirname "$0")/common.sh"
cop inspect-environment --out "$COP_RESULTS/environment.json"
python - "$COP_RESULTS/environment.json" <<'PY'
import json, sys
e = json.load(open(sys.argv[1])); s = e.get("cuda_smoke", {})
if not s.get("ok"):
    sys.exit(f"CUDA check failed: {s}")
print("CUDA forward/backward/update and checkpoint reload: ok", s.get("max_diff_vs_cpu"))
PY
DEVICE=cuda WORKERS=1 run_wave 0 --kinds control
# gate: every CUDA control job must be complete and valid before any GPU training wave
cop gate --manifest "$COP_HOME/manifests/wave0_${SCALE}.jsonl" --results "$COP_RESULTS" --device cuda --kinds control
cop calibrate --results "$COP_RESULTS/calibration" --device cuda --data-root "$COP_DATA_ROOT" --scale pilot \
    --threads "$THREADS"
for w in 1 2 3 4 5; do
  m="$COP_HOME/manifests/wave${w}_${SCALE}.jsonl"
  cop generate-manifest --wave "$w" --scale "$SCALE" --results "$COP_RESULTS" --out "$m" >/dev/null
  echo "== wave $w ($SCALE)"; cop estimate --manifest "$m" --timing "$COP_RESULTS/calibration/calibration_timing.json" --workers "$WORKERS"
done
echo "Pilot timings measured at scale=pilot; full-scale per-update cost is similar, total cost scales with updates."
