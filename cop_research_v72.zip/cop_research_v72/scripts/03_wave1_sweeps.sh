#!/usr/bin/env bash
# Wave 1: complexity x sample size x capacity x topology (810-trajectory core) + noise,
# sample-size matching, fresh-vs-fixed, parity / multiplexer / delayed query / shortcut / linear-rank blocks.
source "$(dirname "$0")/common.sh"
run_wave 1 "$@"
