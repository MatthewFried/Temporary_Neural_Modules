#!/usr/bin/env bash
# Wave 2: Fashion-MNIST / CIFAR-10 / CIFAR-100 end-to-end (270-trajectory block), tabular, sequences.
source "$(dirname "$0")/common.sh"
run_wave 2 "$@"
