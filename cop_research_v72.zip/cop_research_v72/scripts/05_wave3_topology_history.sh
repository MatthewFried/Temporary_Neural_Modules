#!/usr/bin/env bash
# Wave 3: E1-E5 and I1-I4 on simple teacher, harder synthetic, CIFAR-10 and a sequence task.
source "$(dirname "$0")/common.sh"
run_wave 3 "$@"
