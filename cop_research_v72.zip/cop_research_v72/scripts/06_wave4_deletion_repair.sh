#!/usr/bin/env bash
# Wave 4: R1-R5 on checkpoints from earlier waves (balanced prespecified selection when
# $COP_RESULTS contains completed trajectories; otherwise standalone parents), R3 and I5.
source "$(dirname "$0")/common.sh"
run_wave 4 "$@"
