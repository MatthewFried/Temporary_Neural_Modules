#!/usr/bin/env bash
# Wave 5: Chain of Pearls P1-P5 and the section-10 baselines on compose, delayed query,
# covertype, CIFAR-10 and a sequence model.
source "$(dirname "$0")/common.sh"
run_wave 5 "$@"
