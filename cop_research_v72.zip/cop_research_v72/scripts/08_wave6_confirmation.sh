#!/usr/bin/env bash
# Wave 6: confirmation with new seeds.  Edit configs/confirmation.yaml FIRST (commit it), then run.
source "$(dirname "$0")/common.sh"
m="$COP_HOME/manifests/wave6_${SCALE}.jsonl"
cop generate-manifest --wave 6 --scale "$SCALE" --selection "$COP_HOME/configs/confirmation.yaml" --out "$m"
cop validate-manifest --manifest "$m"
cop run --manifest "$m" --results "$COP_RESULTS" --device "$DEVICE" --data-root "$COP_DATA_ROOT" --workers "$WORKERS" \
    --threads "$THREADS" --resume "$@"
