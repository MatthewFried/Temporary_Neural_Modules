#!/usr/bin/env bash
# Aggregate every manifest in manifests/, draw figures, and build the review archive.
source "$(dirname "$0")/common.sh"
args=()
for m in "$COP_HOME"/manifests/*.jsonl; do args+=(--manifest "$m"); done
cop summarize --results "$COP_RESULTS" "${args[@]}"
V="${BUNDLE_VERSION:-v2}"
cop package-for-review --results "$COP_RESULTS" --out "$HOME/cop_review_${V}.zip"
