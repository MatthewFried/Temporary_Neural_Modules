#!/usr/bin/env bash
# Small real WSL / CUDA integration pilot (Gate C of the audit).  Run AFTER 01 and 02.
#  1. environment report incl. a CUDA forward/backward/update and checkpoint reload check
#  2. one small valid case per model family and job kind on the GPU (wave 9 at pilot scale),
#     including the cache-heavy CoP image case; 1 worker
#  3. job-level interrupt / resume comparison on the GPU for a few job kinds
#  4. fresh-process reload of every P3 / P4 run
#  5. pilot_report.json (env, configs, status / validity, runtime, peak memory, work, checkpoint and
#     prediction hashes) and a zip of everything for review: ~/cop_wsl_pilot_v5.zip
source "$(dirname "$0")/common.sh"
P="$COP_RESULTS/pilot"
mkdir -p "$P"
cop inspect-environment --out "$P/environment.json"
m="$COP_HOME/manifests/wave9_pilot.jsonl"
cop generate-manifest --wave 9 --scale pilot --out "$m"
cop validate-manifest --manifest "$m"
rc=0
cop run --manifest "$m" --results "$P" --device "$DEVICE" --data-root "$COP_DATA_ROOT" --workers 1 \
    --threads "$THREADS" --resume || rc=$?
cop status --manifest "$m" --results "$P"
python - "$P" <<'PY'
import json, sys, os
sys.path.insert(0, os.path.join(os.environ["COP_HOME"], "tests"))
from pathlib import Path
from resume_harness import compare_interrupted
import tiny_configs as T
from cop.config import run_id
root = Path(sys.argv[1]) / "resume_gpu"
ex = {"device": os.environ.get("DEVICE", "cuda"), "data_root": os.environ.get("COP_DATA_ROOT")}
TR = {**T.TRAIN, "checkpoint_every": 7}
p = T.traj({"topology": "recursive_branch"}, train=TR)
cy = T.cop({"task_kind": "cycles", "cycle_pegs": "relearned", "cycles": 3, "n_pearls": 3}, train=TR)
cases = {"trajectory": p,
         "repair": p + [T.child("repair", p[-1], {"repair": {"region": "full", "budget_multiplier": 1.0}})],
         "dissipation": p + [T.child("dissipation", p[-1], {"dissipation": {"method": "linear", "speed_updates": 10,
                                                                            "post_updates": 10}})],
         "cop_alternatives": T.cop({"task_kind": "alternatives", "alt_kinds": ["mlp_small", "linear"]}, train=TR),
         "cop_cycles": cy}
rep = {k: compare_interrupted(v, root / k, ex=ex) for k, v in cases.items()}
json.dump(rep, open(Path(sys.argv[1]) / "resume_gpu.json", "w"), indent=1, default=str)
for k, v in rep.items():
    print("resume", k, "equal" if v["equal"] else "DIFFERENT", v["attempts"], v["checkpoints_differing"],
          v["n_metrics_differing"])
PY
python - "$P" <<'PY'
# checkpoint dtype and device relocation on this GPU (audit finding 13): fp32 / fp64, cuda <-> cpu
import json, sys, os, torch
from pathlib import Path
from cop.graph.builders import build_mlp
from cop.graph import edits as E
from cop.graph.graph import GraphNet
from cop.cop_pegs.pegs import insert_peg
from cop.utils import torch_gen
dev = os.environ.get("DEVICE", "cuda")
out = {}
for dt in (torch.float32, torch.float64):
    g = build_mlp(8, [16, 16, 16], 3, torch_gen(0, "init")).to(dt)
    insert_peg(g, E.cut_at(g, "post_act", 1), torch_gen(1, "init"), k=4, mode="uniform", bits=3)
    g = g.to(dev)
    x = {"x": torch.randn(64, 8, dtype=dt, device=dev)}
    y = g(x)
    h = GraphNet.from_checkpoint(g.checkpoint(), "cpu")
    yc = h({"x": x["x"].cpu()})
    k = GraphNet.from_checkpoint(h.checkpoint(), dev)
    yk = k(x)
    out[str(dt)] = {"dtypes_preserved": all(a.dtype == b.dtype for a, b in zip(g.state_dict().values(),
                                                                                 k.state_dict().values())),
                    "gpu_roundtrip_bitwise": bool(torch.equal(y, yk)),
                    "gpu_vs_cpu_max_abs": float((y.cpu() - yc).abs().max())}
json.dump(out, open(Path(sys.argv[1]) / "device_checks.json", "w"), indent=1)
print("device checks", out)
PY
python -m cop.analysis.pilot_report --results "$P" --manifest "$m" --data-root "$COP_DATA_ROOT" --device "$DEVICE" \
    --out "$P/pilot_report.json"
cop summarize --results "$P" --manifest "$m" --out "$P/summary"
python - "$P" "$HOME/cop_wsl_pilot_v5.zip" <<'PY'
import sys, zipfile
from pathlib import Path
P, out = Path(sys.argv[1]), Path(sys.argv[2])
skip = ("partial", "state__")
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for f in sorted(P.rglob("*")):
        if f.is_file() and not any(s in f.name for s in skip) and f.stat().st_size < 20e6:   # larger checkpoints: hashes are in pilot_report.json
            z.write(f, f"cop_wsl_pilot_v5/{f.relative_to(P)}")
print("wrote", out)
PY
exit "$rc"
