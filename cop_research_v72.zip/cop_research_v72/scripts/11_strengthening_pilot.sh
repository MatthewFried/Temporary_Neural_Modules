#!/usr/bin/env bash
# Strengthening extension pilot (wave 7 at pilot scale: budgets x0.25, seed 0), v5.  Run AFTER 01, 02, 10 and 12.
#  1. environment report and the CPU regression tests of the extension
#  2. runtime sample: one job per stratum (kind, block, data, model) plus prerequisites, at pilot scale;
#     the measured times give the pilot estimate (runtime_pilot.json); the pilot itself then gives the
#     full-scale estimate only after a full-scale stratum sample (step 5, optional, RUN_FULL_SAMPLE=1)
#  3. the wave-7 pilot (all 50 registry variants, controls C0-C8 and M1/M2, mechanisms A-H, crosses)
#  4. job-level interrupt / resume comparisons on the GPU (v4 and v5 paths), fresh-process reload of every
#     endpoint, transplant and witness, eligibility / rejected records, pilot report, tables and figures
#  6. a zip for review: ~/cop_strengthening_pilot_v5.zip
# Nothing here is the confirmatory campaign; send the zip for review before any full-scale wave-7 run.
source "$(dirname "$0")/common.sh"
P="$COP_RESULTS/strengthening_pilot"
mkdir -p "$P"
cop inspect-environment --out "$P/environment.json"
python -m pytest -q tests/test_strengthening.py tests/test_strengthening_v3.py tests/test_v4_audit.py \
    tests/test_v5_review.py tests/test_v3_audit_supplied.py 2>&1 | tee "$P/pytest_strengthening.txt"
m="$COP_HOME/manifests/wave7_pilot.jsonl"
cop generate-manifest --wave 7 --scale pilot --out "$m"
cop validate-manifest --manifest "$m"
# 2. runtime sample (shares the results root: its jobs are pilot jobs and are not rerun in step 3)
python audit_v4/tools/runtime_estimate.py sample "$m" "$P/runtime_sample.jsonl"
cop run --manifest "$P/runtime_sample.jsonl" --results "$P" --device "$DEVICE" --data-root "$COP_DATA_ROOT" \
    --workers "$WORKERS" --threads "$THREADS" --resume || true
python audit_v4/tools/runtime_estimate.py estimate "$m" "$P" --workers "$WORKERS" --out "$P/runtime_pilot.json"
echo "pilot estimate written to $P/runtime_pilot.json; stop here (Ctrl-C) if it is too long"; sleep "${PAUSE:-20}"
# 3. the pilot
rc=0
cop run --manifest "$m" --results "$P" --device "$DEVICE" --data-root "$COP_DATA_ROOT" --workers "$WORKERS" \
    --threads "$THREADS" --resume || rc=$?
cop status --manifest "$m" --results "$P"
# 4. checks and analysis
# v8: each check exits 1 on failure; the failure is recorded in rc and the remaining steps still run
python audit_v4/tools/resume_comparisons_v4.py "$P/resume_gpu" 2>&1 | tee "$P/resume_gpu.txt" || rc=1
python audit_v5/tools/resume_comparisons_v5.py "$P/resume_gpu_v5" 2>&1 | tee "$P/resume_gpu_v5.txt" || rc=1
python audit_v8/tools/check_results.py "$P" "$P/pilot_checks.json" --manifest "$m" --diagnostics --transplants \
    2>&1 | tee "$P/pilot_checks.txt" || rc=1
python audit_v5/tools/fresh_reload.py "$P" "$P/fresh_reload.json" --device "$DEVICE" --data-root "$COP_DATA_ROOT" || rc=1
python -m cop.analysis.pilot_report --results "$P" --manifest "$m" --data-root "$COP_DATA_ROOT" --device "$DEVICE" \
    --out "$P/pilot_report.json" || rc=1
# v10: analysis failures are recorded (rc) and never stop the full-scale sample or the review zip
bash "$COP_HOME/scripts/14_finish_pilot.sh" || rc=1
exit "$rc"
