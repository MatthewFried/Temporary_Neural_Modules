#!/usr/bin/env bash
# GPU acceptance gates (v8).  Run on the GPU machine after 01 / 02 and BEFORE 11.  Every step runs even
# if an earlier one fails, so the zip holds all the evidence; the script then exits 1 if ANY step failed.
#  1. every CUDA test (v3 supplied gates, v4, v5 and v8 tests, acceptance); a skip is a failure here.
#     The CUDA tests cover the contraction diagnostics (fit, virtual replacement, JVP incl. a Transformer
#     with attention after the cut, float64 models, saved-map reload) and the v5 jobs
#  2. interrupt / resume comparisons of the v4 and v5 paths on the GPU (the helpers exit 1 on any mismatch,
#     error, unknown case or empty check set)
#  3. a GPU wave-7 smoke run, then: every manifest job complete and valid, every contraction-diagnostic
#     row complete, every grid transplant assembly eligible, fresh-process reload of every endpoint,
#     transplant and witness (bitwise after restoring the recorded numerics), and the summary
# Writes $COP_RESULTS/v5_gpu_gates/gate_verdict.json and ~/cop_v5_gpu_gates.zip; send the zip for review.
source "$(dirname "$0")/common.sh"
set +e                                    # collect every step's status instead of stopping at the first failure
G="$COP_RESULTS/v5_gpu_gates"
mkdir -p "$G"
declare -A RC
step() { local name="$1"; shift; echo "=== $name"; "$@"; RC[$name]=$?; echo "=== $name exit ${RC[$name]}"; }
cop inspect-environment --out "$G/environment.json"
python -c "import torch, sys; sys.exit(0 if torch.cuda.is_available() else 'CUDA is not available: these gates must run on the GPU')" || exit 1
step cuda_tests bash -c "python -m pytest -v -rs tests/test_v3_audit_supplied.py tests/test_v4_audit.py \
    tests/test_v5_review.py tests/test_v8_audit.py tests/test_acceptance.py -k 'cuda or gpu_equivalence' \
    --junitxml '$G/cuda_tests.xml' 2>&1 | tee '$G/cuda_tests.txt'; exit \${PIPESTATUS[0]}"
if grep -q "SKIPPED" "$G/cuda_tests.txt"; then echo "a CUDA test was skipped: not accepted" >&2; RC[cuda_skips]=1; else RC[cuda_skips]=0; fi
if ! grep -Eq "[0-9]+ passed" "$G/cuda_tests.txt"; then echo "no CUDA test passed: not accepted" >&2; RC[cuda_ran]=1; else RC[cuda_ran]=0; fi
step resume_v4 bash -c "DEVICE=cuda python audit_v4/tools/resume_comparisons_v4.py '$G/resume_cuda_v4' 2>&1 | tee '$G/resume_cuda_v4.txt'; exit \${PIPESTATUS[0]}"
step resume_v5 bash -c "DEVICE=cuda python audit_v5/tools/resume_comparisons_v5.py '$G/resume_cuda_v5' 2>&1 | tee '$G/resume_cuda_v5.txt'; exit \${PIPESTATUS[0]}"
m="$G/wave7_smoke.jsonl"
step manifest cop generate-manifest --wave 7 --scale smoke --out "$m"
step smoke_run cop run --manifest "$m" --results "$G/smoke" --device cuda --data-root "$COP_DATA_ROOT" \
    --workers "$WORKERS" --threads "$THREADS" --resume
cop status --manifest "$m" --results "$G/smoke" > "$G/smoke_status.txt" 2>&1
step smoke_checks python audit_v8/tools/check_results.py "$G/smoke" "$G/smoke_checks.json" --manifest "$m" \
    --diagnostics --transplants
step reload python audit_v5/tools/fresh_reload.py "$G/smoke" "$G/fresh_reload_cuda.json" --device cuda \
    --data-root "$COP_DATA_ROOT"
step summarize cop summarize --results "$G/smoke" --manifest "$m" --out "$G/smoke_summary"
python - "$G" <<PY
import json, sys
rc = {$(for k in "${!RC[@]}"; do printf '"%s": %s, ' "$k" "${RC[$k]}"; done)}
v = {"steps": rc, "passed": all(c == 0 for c in rc.values()), "failed_steps": sorted(k for k, c in rc.items() if c)}
json.dump(v, open(sys.argv[1] + "/gate_verdict.json", "w"), indent=1)
print(json.dumps(v, indent=1))
PY
python - "$G" "$HOME/cop_v5_gpu_gates.zip" <<'PY'
import sys, zipfile
from pathlib import Path
G, out = Path(sys.argv[1]), Path(sys.argv[2])
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for f in sorted(G.rglob("*")):
        if f.is_file() and f.suffix in (".json", ".jsonl", ".txt", ".xml", ".csv", ".png") and f.stat().st_size < 20e6:
            z.write(f, f"cop_v5_gpu_gates/{f.relative_to(G)}")
print("wrote", out)
PY
fail=0
for k in "${!RC[@]}"; do [ "${RC[$k]}" -ne 0 ] && fail=1; done
exit "$fail"
