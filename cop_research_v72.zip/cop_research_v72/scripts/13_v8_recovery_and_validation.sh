#!/usr/bin/env bash
# v8 recovery of existing (v7) results and validation of v8, from a SEPARATE v8 checkout.  It never edits,
# deletes or resumes an existing run.  Phases (all on by default; set PHASES to a subset, e.g. PHASES="A"):
#   A  read-only: the audit's scanner and the v8 recovery manifest for every results root found under
#      OLD_RESULTS (default ~/cop_results_v5): the root itself, pilot/, v5_gpu_gates/smoke/, strengthening_pilot/
#   B  recomputation: incomplete contraction diagnostics recomputed from their source checkpoints (written ONLY
#      to <root>/recomputed_diagnostics/), insertion rechecks (report only), cycle replays in a scratch folder
#      (REPLAY_SCRATCH, default ~/cop_v8_replay), then the v8 checks over each root.  Refused while any
#      `cop run` process is active (the pilot must finish first); B needs the GPU the runs were made on
#   C  validation of v8 in its own results folder (COP_RESULTS, default ~/cop_results_v8_validation):
#      01 (CPU suite + Wave-0 CPU), 02 (GPU check + Wave-0 GPU), 12 (CUDA tests, resume, GPU smoke with every
#      v8 check, reload).  This is the small validation pilot; it does not run the large wave-7 pilot (11)
# Every step runs and is logged even if an earlier one failed; the script exits 1 if any step failed.
# Output: ~/cop_v8_recovery/ and ~/cop_v8_recovery_validation.zip
set -u
export COP_HOME="${COP_HOME:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
OLD="${OLD_RESULTS:-$HOME/cop_results_v5}"
OUT="${RECOVERY_OUT:-$HOME/cop_v8_recovery}"
SCR="${REPLAY_SCRATCH:-$HOME/cop_v8_replay}"
PHASES="${PHASES:-A B C}"
export COP_RESULTS="${COP_RESULTS:-$HOME/cop_results_v8_validation}"
export COP_DATA_ROOT="${COP_DATA_ROOT:-$HOME/cop_data}"
DEV="${DEVICE:-cuda}"
if [ -n "${COP_VENV:-}" ] && [ -f "$COP_VENV/bin/activate" ]; then source "$COP_VENV/bin/activate"; fi
export PYTHONPATH="$COP_HOME${PYTHONPATH:+:$PYTHONPATH}"
cd "$COP_HOME"
mkdir -p "$OUT"
fail=0
step() { local name="$1"; shift; echo; echo "=== $name  $(date)"; "$@"; local rc=$?; echo "=== $name exit $rc"; \
         echo "$name $rc" >> "$OUT/steps.txt"; [ "$rc" -ne 0 ] && fail=1; return 0; }
: > "$OUT/steps.txt"
roots=()
for r in "$OLD" "$OLD/pilot" "$OLD/v5_gpu_gates/smoke" "$OLD/strengthening_pilot"; do
  [ -d "$r/runs" ] && roots+=("$r")
done
echo "results roots: ${roots[*]:-none}" | tee "$OUT/roots.txt"
tag() { echo "$1" | sed "s#$HOME/##; s#/#__#g"; }

if [[ " $PHASES " == *" A "* ]]; then
  for r in "${roots[@]}"; do
    t=$(tag "$r")
    # the scanner exits 1 when it finds flags (intended); the step records that, it is not an error of the step
    step "A_scan_$t" python audit_v8/tools/scan_v7_results.py "$r" --out "$OUT/scan_$t.json" --check-insertions
    step "A_manifest_$t" python -m cop.cli recovery-manifest --results "$r" --out "$OUT/recovery_manifest_$t.json"
  done
fi

if [[ " $PHASES " == *" B "* ]]; then
  if pgrep -f "cop.cli run" > /dev/null; then
    echo "a 'cop run' process is active: phase B is refused until it finishes (phase A is read-only and ran)" | tee -a "$OUT/steps.txt"
    fail=1
  else
    for r in "${roots[@]}"; do
      t=$(tag "$r")
      step "B_recompute_$t" python -m cop.cli recompute-diagnostics --results "$r" --out "$OUT/recompute_$t.json" \
          --device "$DEV" --data-root "$COP_DATA_ROOT"
      step "B_recheck_$t" python -m cop.cli recheck-insertions --results "$r" --out "$OUT/recheck_insertions_$t.json" \
          --device "$DEV" --data-root "$COP_DATA_ROOT"
      step "B_replay_$t" python -m cop.cli replay-cycles --results "$r" --out "$OUT/replay_$t.json" \
          --scratch "$SCR/$t" --device "$DEV" --data-root "$COP_DATA_ROOT"
      step "B_manifest_after_$t" python -m cop.cli recovery-manifest --results "$r" --out "$OUT/recovery_manifest_after_$t.json"
      step "B_check_$t" python audit_v8/tools/check_results.py "$r" "$OUT/check_$t.json" --diagnostics-if-any --transplants-if-any
    done
  fi
fi

if [[ " $PHASES " == *" C "* ]]; then
  step C_01_cpu_tests bash scripts/01_cpu_exact_tests.sh
  step C_02_gpu_calibration bash scripts/02_gpu_calibration.sh
  step C_12_gpu_gates bash scripts/12_v5_gpu_gates.sh
  cp -f "$COP_RESULTS/v5_gpu_gates/gate_verdict.json" "$OUT/" 2>/dev/null
  cp -f "$HOME/cop_v5_gpu_gates.zip" "$OUT/cop_v8_gpu_gates.zip" 2>/dev/null
  cp -rf "$COP_RESULTS/tests" "$OUT/validation_tests" 2>/dev/null
fi

python - "$OUT" "$HOME/cop_v8_recovery_validation.zip" <<'PY'
import sys, zipfile
from pathlib import Path
O, out = Path(sys.argv[1]), Path(sys.argv[2])
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for f in sorted(O.rglob("*")):
        if f.is_file() and f.stat().st_size < 50e6:
            z.write(f, f"cop_v8_recovery/{f.relative_to(O)}")
print("wrote", out)
PY
cat "$OUT/steps.txt"
exit "$fail"
