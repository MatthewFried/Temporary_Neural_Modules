#!/usr/bin/env bash
# v10: the analysis and packaging tail of the wave-7 pilot (scripts/11 calls it after its checks).  Run it on its
# own to finish a pilot whose jobs and checks are done (e.g. the v9 pilot, whose summary step crashed):
#   COP_RESULTS=~/cop_results_v9 RUN_FULL_SAMPLE=1 bash scripts/14_finish_pilot.sh
# It only reads the pilot's runs; it writes summary/, rejection_examples.json, the optional full-scale runtime
# sample (separate results root) and ~/cop_strengthening_pilot_v5.zip.  Every step runs; exit 1 if any failed.
source "$(dirname "$0")/common.sh"
set +e
P="$COP_RESULTS/strengthening_pilot"
m="$COP_HOME/manifests/wave7_pilot.jsonl"
[ -f "$m" ] || cop generate-manifest --wave 7 --scale pilot --out "$m"
rc=0
cop summarize --results "$P" --manifest "$m" --out "$P/summary" 2>&1 | tee "$P/summarize.txt"
[ "${PIPESTATUS[0]}" -ne 0 ] && rc=1
python audit_v4/tools/rejection_examples.py "$P" "$P/rejection_examples.json" || true
# optional full-scale runtime sample (about 350 full-scale jobs; separate results root)
if [ "${RUN_FULL_SAMPLE:-0}" = "1" ]; then
  mf="$COP_HOME/manifests/wave7_full.jsonl"
  cop generate-manifest --wave 7 --scale full --out "$mf"
  python audit_v4/tools/runtime_estimate.py sample "$mf" "$P/runtime_sample_full.jsonl"
  cop run --manifest "$P/runtime_sample_full.jsonl" --results "$COP_RESULTS/runtime_sample_full" --device "$DEVICE" \
      --data-root "$COP_DATA_ROOT" --workers "$WORKERS" --threads "$THREADS" --resume || true
  python audit_v4/tools/runtime_estimate.py estimate "$mf" "$COP_RESULTS/runtime_sample_full" --workers "$WORKERS" \
      --out "$P/runtime_full.json" || rc=1
fi
cp "$m" "${m%.jsonl}.coverage.json" "$P/" 2>/dev/null || true
python - "$P" "$HOME/cop_strengthening_pilot_v5.zip" <<'PY'
import sys, zipfile
from pathlib import Path
P, out = Path(sys.argv[1]), Path(sys.argv[2])
skip = ("partial", "state__", "diss_state", "progress_")
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for f in sorted(P.rglob("*")):
        # checkpoints above 20 MB are left out (their hashes are in pilot_report.json)
        if f.is_file() and not any(s in f.name for s in skip) and f.stat().st_size < 20e6:
            z.write(f, f"cop_strengthening_pilot_v5/{f.relative_to(P)}")
print("wrote", out)
PY
exit "$rc"
