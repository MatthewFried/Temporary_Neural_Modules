#!/usr/bin/env bash
# v13: the audit's execution order, steps 1-3 (fixes checked, historical costs repaired, engineering re-pilot).
# It does NOT launch the confirmation wave (scripts/16) or any full sweep.
#
#   cd ~/research/cop_research_v13 && nohup bash scripts/15_v13_repilot.sh > ~/v13_repilot.log 2>&1 &
#
# Writes only under $COP_RESULTS (default ~/cop_results_v13).  The v9 results ($V9_RESULTS, default
# ~/cop_results_v9) are read, never written; the script checks that no file under them changed.
# Steps (each runs even if an earlier one failed; exit 1 if any failed):
#   1. environment; full CPU test suite (CUDA hidden); every CUDA test on the GPU (a skip is a failure)
#   2. the audit's two probes against this code (identity counterexample, baseline cost)
#   3. historical cost tables of the v9 pilot rebuilt read-only (cop summarize --historical)
#   4. wave 13 re-pilot (scale $SCALE, default pilot): generate, validate, run, status, result checks,
#      fresh-process reload, summary
#   5. runtime: fit on the re-pilot's own timings, estimate wave 14 at pilot and full scale
#   6. two zips in $ZIP_DIR: cop_v13_repilot_reports.zip (small; send this) and
#      cop_v13_repilot_raw.zip (every run folder incl. checkpoints)
export COP_RESULTS="${COP_RESULTS:-$HOME/cop_results_v13}"
export SCALE="${SCALE:-pilot}"      # set before common.sh, whose default is full (v14 fix: v13 ran full scale)
source "$(dirname "$0")/common.sh"
set +e
V9="${V9_RESULTS:-$HOME/cop_results_v9}"
ZIP_DIR="${ZIP_DIR:-/mnt/c/Users/Matthew Fried/Downloads}"
[ -d "$ZIP_DIR" ] || ZIP_DIR="$HOME"
R="$COP_RESULTS/repilot"
O="$COP_RESULTS/v13_reports"
mkdir -p "$R" "$O"
declare -A RC
step() { local name="$1"; shift; echo "=== $(date '+%F %T') $name"; "$@" > "$O/$name.txt" 2>&1; RC[$name]=$?;
         echo "=== $name exit ${RC[$name]}"; tail -3 "$O/$name.txt"; }
stamp="$O/.v9_stamp"; touch "$stamp"

cop inspect-environment --out "$O/environment.json"
step cpu_tests env CUDA_VISIBLE_DEVICES="" DEVICE=cpu python -m pytest -q -rs tests/ -p no:cacheprovider \
    --junitxml "$O/cpu_tests.xml"
step cuda_tests python -m pytest -v -rs tests/ -p no:cacheprovider -k "cuda or gpu_equivalence" \
    --junitxml "$O/cuda_tests.xml"
if grep -q "SKIPPED" "$O/cuda_tests.txt" || ! grep -Eq "[0-9]+ passed" "$O/cuda_tests.txt"; then
  echo "a CUDA test was skipped or none ran: not accepted" | tee -a "$O/cuda_tests.txt"; RC[cuda_skips]=1
else RC[cuda_skips]=0; fi
step probe_identity python audit_v6/probes/probe_v12_identity.py
step probe_baseline_cost python audit_v6/probes/probe_v12_baseline_cost.py "$O/probe_baseline_cost_runs"
for p in identity baseline_cost; do
  python -c "import json,sys; d=json.load(open('$O/probe_$p.txt')); sys.exit(1 if d.get('issue_reproduced') else 0)" \
    || { echo "probe $p reproduced the v12 issue" >&2; RC[probe_${p}_fixed]=1; }
done

# ---- 3. historical cost rebuild (read-only on v9)
HP="$V9/strengthening_pilot"
if [ -d "$HP" ]; then
  # the v9 manifest (its run ids carry the v9 code version); scripts/14 copied it into the pilot folder
  hm="$HP/wave7_pilot.jsonl"; [ -f "$hm" ] || hm="$HOME/research/cop_research_v11/manifests/wave7_pilot.jsonl"
  step historical_costs cop summarize --historical --results "$HP" --manifest "$hm" --out "$COP_RESULTS/historical_v9_pilot"
else
  echo "no v9 pilot at $HP; historical cost rebuild skipped" | tee "$O/historical_costs.txt"; RC[historical_costs]=1
fi

# ---- 4. re-pilot
m="$COP_HOME/manifests/wave13_${SCALE}.jsonl"
step manifest13 cop generate-manifest --wave 13 --scale "$SCALE" --out "$m"
step validate13 cop validate-manifest --manifest "$m"
step run13 cop run --manifest "$m" --results "$R" --device "$DEVICE" --data-root "$COP_DATA_ROOT" \
    --workers "$WORKERS" --threads "$THREADS" --resume
cop status --manifest "$m" --results "$R" > "$O/status13.txt" 2>&1
step checks13 python audit_v8/tools/check_results.py "$R" "$O/checks13.json" --manifest "$m" --transplants-if-any \
    --diagnostics-if-any
step reload13 python audit_v5/tools/fresh_reload.py "$R" "$O/fresh_reload13.json" --device "$DEVICE" \
    --data-root "$COP_DATA_ROOT"
step summary13 cop summarize --results "$R" --manifest "$m" --out "$R/summary"

# ---- 5. runtime from the re-pilot's own timings (measured on this machine)
for sc in pilot full; do
  cop generate-manifest --wave 14 --scale "$sc" --out "$COP_HOME/manifests/wave14_${sc}.jsonl" > /dev/null 2>&1
done
step runtime_fit python audit_v5/tools/runtime_v13.py fit "$m" "$R" "$O/rates_repilot.json"
for sc in pilot full; do
  for w in 1 "$WORKERS"; do
    step "runtime14_${sc}_w$w" python audit_v5/tools/runtime_v13.py estimate "$COP_HOME/manifests/wave14_${sc}.jsonl" \
        "$O/rates_repilot.json" --workers "$w" --out "$O/runtime14_${sc}_w$w.json"
  done
done

# ---- v9 untouched
changed=$(find "$V9" -newer "$stamp" -type f 2>/dev/null | head -5)
if [ -n "$changed" ]; then echo "files under $V9 changed: $changed" | tee "$O/v9_readonly.txt"; RC[v9_readonly]=1
else echo "no file under $V9 changed" > "$O/v9_readonly.txt"; RC[v9_readonly]=0; fi

python - "$O" <<PY
import json, sys
rc = {$(for k in "${!RC[@]}"; do printf '"%s": %s, ' "$k" "${RC[$k]}"; done)}
json.dump({"steps": rc, "all_passed": all(v == 0 for v in rc.values())}, open(sys.argv[1] + "/verdict.json", "w"), indent=1)
print(json.dumps(rc, indent=1))
PY
cp "$m" "${m%.jsonl}.coverage.json" "$O/" 2>/dev/null
cp "$COP_HOME"/manifests/wave14_*.jsonl "$O/" 2>/dev/null

# ---- 6. zips
python - "$COP_RESULTS" "$ZIP_DIR" <<'PY'
import sys, zipfile
from pathlib import Path
res, zd = Path(sys.argv[1]), Path(sys.argv[2])
skip = ("partial", "state__", "diss_state", "progress_")
rep = zd / "cop_v13_repilot_reports.zip"
with zipfile.ZipFile(rep, "w", zipfile.ZIP_DEFLATED) as z:
    for sub in ("v13_reports", "repilot/summary", "historical_v9_pilot"):
        for f in sorted((res / sub).rglob("*")):
            if f.is_file() and f.suffix != ".pt" and f.stat().st_size < 50e6:
                z.write(f, f"cop_v13_repilot_reports/{f.relative_to(res)}")
    for rd in sorted((res / "repilot" / "runs").glob("*")):        # per-run records without tensors
        for f in sorted(rd.rglob("*.json")) + sorted(rd.rglob("*.jsonl")):
            if f.stat().st_size < 20e6:
                z.write(f, f"cop_v13_repilot_reports/{f.relative_to(res)}")
raw = zd / "cop_v13_repilot_raw.zip"
with zipfile.ZipFile(raw, "w", zipfile.ZIP_DEFLATED) as z:
    for f in sorted((res / "repilot").rglob("*")):
        if f.is_file() and not any(s in f.name for s in skip):
            z.write(f, f"cop_v13_repilot_raw/{f.relative_to(res)}")
print("wrote", rep, rep.stat().st_size // 2**20, "MB;", raw, raw.stat().st_size // 2**20, "MB")
PY
python -c "import json,sys; sys.exit(0 if json.load(open('$O/verdict.json'))['all_passed'] else 1)"
