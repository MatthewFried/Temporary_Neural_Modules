#!/usr/bin/env bash
# v13 confirmation (wave 14): fresh paired replications of the shortlisted contrasts.  NOT run by any other
# script.  Launch it only after the re-pilot (scripts/15) has been reviewed and the protocol is frozen:
#
#   1. review cop_v13_repilot_reports.zip; change the protocol (cop/orchestration/wave13.py, metrics, selection
#      rule, shortlist in wave14_confirmation) only now, before any confirmation result exists
#   2. freeze it:   bash scripts/16_v13_confirmation.sh freeze
#      (writes $COP_RESULTS/confirmation/PROTOCOL_FROZEN.json: code hashes, manifest hash, job count, runtime
#      estimate from the re-pilot's timings)
#   3. launch:      CONFIRM=1 nohup bash scripts/16_v13_confirmation.sh run > ~/v13_confirm.log 2>&1 &
#      (refuses to start if the code or manifest changed since the freeze)
#   4. after it finishes, the summary and zip are written automatically.
#
# Replications: data/teacher draws 101-105 with optimizer seed 0, plus optimizer seeds 1 and 2 on draws 101
# and 102 (a small crossed design: optimizer-seed variation at fixed data, and variation across draws).
# SCALE defaults to full: the lab re-pilot (v13) ran at full scale, so the confirmation uses the same budgets.
# SCALE=pilot gives the 0.25x budgets of the v9 discovery pilot.
export COP_RESULTS="${COP_RESULTS:-$HOME/cop_results_v17}"     # a fresh results folder (v17)
export SCALE="${SCALE:-full}"
source "$(dirname "$0")/common.sh"
ZIP_DIR="${ZIP_DIR:-/mnt/c/Users/Matthew Fried/Downloads}"
[ -d "$ZIP_DIR" ] || ZIP_DIR="$HOME"
C="$COP_RESULTS/confirmation_${SCALE}"
gen="$COP_HOME/manifests/wave14_${SCALE}.jsonl"
m="$C/manifest_frozen.jsonl"          # the frozen copy; run always uses this file
mkdir -p "$C"
fingerprint() {
  # semantic code (what jobs compute), the whole cop package incl. analysis / orchestration, the launch scripts
  # and the audit tools the verdict relies on, and the manifest
  python - "$m" "$COP_HOME" <<'PY'
import hashlib, json, sys
from pathlib import Path
from cop.utils import semantic_code_hash, code_hash
m, home = sys.argv[1], Path(sys.argv[2])
h = hashlib.sha256()
for p in sorted([*(home / "scripts").glob("*.sh"), home / "audit_v5/tools/runtime_v13.py",
                 home / "audit_v5/tools/fresh_reload.py", home / "audit_v8/tools/check_results.py"]):
    if p.exists():
        h.update(p.name.encode()); h.update(p.read_bytes())
print(json.dumps({"semantic_code_hash": semantic_code_hash(), "code_hash": code_hash(),
                  "protocol_hash": code_hash() + ":" + h.hexdigest()[:16],
                  "manifest_sha256": hashlib.sha256(open(m, "rb").read()).hexdigest(),
                  "jobs": sum(1 for _ in open(m))}))
PY
}
case "${1:-}" in
  freeze)
    if [ -f "$C/PROTOCOL_FROZEN.json" ]; then
      [ -n "${REFREEZE_REASON:-}" ] || { echo "already frozen ($C/PROTOCOL_FROZEN.json); set REFREEZE_REASON=\"<reason>\" to re-freeze (recorded)" >&2; exit 1; }
      python - "$C" "$REFREEZE_REASON" <<'PY'
import json, sys, time
c, why = sys.argv[1], sys.argv[2]
p = c + "/PROTOCOL_AMENDMENTS.json"
try:
    am = json.load(open(p))
except FileNotFoundError:
    am = []
am.append({"time": time.strftime("%Y-%m-%d %H:%M:%S"), "event": "re-freeze", "reason": why,
           "previous_freeze": json.load(open(c + "/PROTOCOL_FROZEN.json"))})
json.dump(am, open(p, "w"), indent=1)
PY
    fi
    cop generate-manifest --wave 14 --scale "$SCALE" --out "$gen"
    cop validate-manifest --manifest "$gen"
    cp "$gen" "$m"
    # measured timings: v17 combined fit (re-pilot, v16 panel, wave 16; scripts/18), else the re-pilot's own
    rates="${RATES:-$COP_RESULTS/v17_reports/rates_combined.json}"
    [ -f "$rates" ] || rates="$HOME/cop_results_v13/v13_reports/rates_repilot.json"
    [ -f "$rates" ] || { echo "no measured timings ($rates): set RATES=<rates json> (scripts/18 writes one)" >&2; exit 1; }
    python audit_v5/tools/runtime_v13.py estimate "$m" "$rates" --workers "$WORKERS" --out "$C/runtime_estimate.json"
    python - "$C" "$(fingerprint)" <<'PY'
import json, sys, time
c, fp = sys.argv[1], json.loads(sys.argv[2])
est = json.load(open(c + "/runtime_estimate.json"))
json.dump({**fp, "frozen_at": time.strftime("%Y-%m-%d %H:%M:%S"), "runtime_estimate_hours": est["wall_hours"],
           "note": "run refuses a changed semantic_code_hash / manifest; a changed protocol_hash needs a recorded "
                   "PROTOCOL_AMENDMENT"},
          open(c + "/PROTOCOL_FROZEN.json", "w"), indent=1)
print(json.dumps({**fp, "wall_hours_estimate": est["wall_hours"], "serial_hours": est["serial_hours"]}, indent=1))
PY
    ;;
  run)
    [ "${CONFIRM:-0}" = "1" ] || { echo "set CONFIRM=1 to launch the confirmation wave" >&2; exit 1; }
    [ -f "$C/PROTOCOL_FROZEN.json" ] || { echo "freeze the protocol first (scripts/16 freeze)" >&2; exit 1; }
    # training code, manifest and job count must match the freeze exactly.  Analysis / orchestration / script
    # changes after the freeze are refused unless PROTOCOL_AMENDMENT="<reason>" is set: the amendment is then
    # recorded (old and new hashes, reason, time) in PROTOCOL_AMENDMENTS.json and the run proceeds.
    python - "$C" "$(fingerprint)" "${PROTOCOL_AMENDMENT:-}" <<'PY' || exit 1
import json, sys, time
c, b, why = sys.argv[1], json.loads(sys.argv[2]), sys.argv[3]
a = json.load(open(c + "/PROTOCOL_FROZEN.json"))
bad = [k for k in ("semantic_code_hash", "manifest_sha256", "jobs") if a.get(k) != b[k]]
if bad:
    sys.exit(f"training code or manifest changed since the freeze: {bad}; re-freeze deliberately or restore it")
if a.get("protocol_hash") != b["protocol_hash"]:
    if not why:
        sys.exit("analysis / orchestration / script code changed since the freeze (protocol_hash); set "
                 "PROTOCOL_AMENDMENT=\"<reason>\" to record a transparent amendment, or restore the frozen code")
    p = c + "/PROTOCOL_AMENDMENTS.json"
    try:
        am = json.load(open(p))
    except FileNotFoundError:
        am = []
    am.append({"time": time.strftime("%Y-%m-%d %H:%M:%S"), "reason": why, "frozen_protocol_hash": a.get("protocol_hash"),
               "current_protocol_hash": b["protocol_hash"]})
    json.dump(am, open(p, "w"), indent=1)
    print("protocol amendment recorded:", why)
print("frozen protocol verified")
PY
    set +e
    declare -A RC
    stage() { local name="$1"; shift; echo "=== $(date '+%F %T') $name"; "$@" > "$C/stage_$name.log" 2>&1; RC[$name]=$?;
              echo "=== $name exit ${RC[$name]}"; tail -3 "$C/stage_$name.log"; }
    stage run cop run --manifest "$m" --results "$C" --device "$DEVICE" --data-root "$COP_DATA_ROOT" \
        --workers "$WORKERS" --threads "$THREADS" --resume
    status_to_file() { cop status --manifest "$m" --results "$C" > "$C/status.txt" 2>&1; }
    stage status status_to_file
    stage completion python - "$m" "$C" <<'PY'
import json, sys
from pathlib import Path
m, c = sys.argv[1], Path(sys.argv[2])
ids = [json.loads(l)["run_id"] for l in open(m)]
st = {}
for r in ids:
    p = c / "runs" / r / "status.json"
    st[r] = json.load(open(p)).get("status") if p.exists() else "missing"
bad = {r: s for r, s in st.items() if s != "complete"}
json.dump({"expected": len(ids), "complete": len(ids) - len(bad), "not_complete": bad},
          open(c / "completion.json", "w"), indent=1)
print(f"{len(ids) - len(bad)} / {len(ids)} complete")
sys.exit(1 if bad else 0)
PY
    stage checks python audit_v8/tools/check_results.py "$C" "$C/checks.json" --manifest "$m" --diagnostics-if-any \
        --transplants-if-any
    stage reload python audit_v5/tools/fresh_reload.py "$C" "$C/fresh_reload.json" --device "$DEVICE" \
        --data-root "$COP_DATA_ROOT"
    stage reload_coverage python - "$C" <<'PY'
import json, sys
from pathlib import Path
c = Path(sys.argv[1])
with_ep = sum(1 for d in (c / "runs").glob("*") if (d / "endpoint.json").exists())
fr = json.load(open(c / "fresh_reload.json")).get("summary", {}) if (c / "fresh_reload.json").exists() else {}
covered = int(fr.get("n_checked", 0)) + int(fr.get("n_excluded", 0))
print(f"endpoints {with_ep}, reload checked + excluded {covered} (selected best_val checkpoints are not reloaded)")
sys.exit(0 if with_ep and covered >= with_ep else 1)
PY
    stage summary cop summarize --strict --results "$C" --manifest "$m" --out "$C/summary"
    stage protocol_unchanged python - "$C" "$(fingerprint)" <<'PY'
import json, sys
a, b = json.load(open(sys.argv[1] + "/PROTOCOL_FROZEN.json")), json.loads(sys.argv[2])
am = sys.argv[1] + "/PROTOCOL_AMENDMENTS.json"
recorded = {x.get("current_protocol_hash") for x in (json.load(open(am)) if __import__("os").path.exists(am) else [])}
ok = a["semantic_code_hash"] == b["semantic_code_hash"] and (a["protocol_hash"] == b["protocol_hash"]
                                                             or b["protocol_hash"] in recorded)
print("code at the end of the run:", "frozen or recorded amendment" if ok else "CHANGED during the run")
sys.exit(0 if ok else 1)
PY
    write_verdict() {
      python - "$C" "$(fingerprint)" <<PY
import json, sys
rc = {$(for k in "${!RC[@]}"; do printf '"%s": %s, ' "$k" "${RC[$k]}"; done)}
fp = json.loads(sys.argv[2])
json.dump({"stages": rc, "all_passed": all(v == 0 for v in rc.values()), "protocol_hash": fp["protocol_hash"],
           "semantic_code_hash": fp["semantic_code_hash"]}, open(sys.argv[1] + "/verdict.json", "w"), indent=1)
print(json.dumps(rc))
PY
    }
    write_verdict
    stage package python - "$C" "$ZIP_DIR/cop_v13_confirmation_${SCALE}_reports.zip" <<'PY'
import sys, zipfile
from pathlib import Path
c, out = Path(sys.argv[1]), Path(sys.argv[2])
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for f in sorted(c.rglob("*")):
        if f.is_file() and f.suffix not in (".pt", ".jsonl") and f.stat().st_size < 20e6 and "/ckpt/" not in str(f):
            z.write(f, f"cop_v13_confirmation/{f.relative_to(c)}")
print("wrote", out)
PY
    write_verdict
    # the exit status comes from the recorded stage codes in the shell itself, so it does not depend on the
    # verdict file being written
    fail=0
    for k in "${!RC[@]}"; do [ "${RC[$k]}" -ne 0 ] && { echo "stage $k failed (${RC[$k]})" >&2; fail=1; }; done
    exit "$fail"
    ;;
  *) echo "usage: bash scripts/16_v13_confirmation.sh freeze | run" >&2; exit 2 ;;
esac
