#!/usr/bin/env bash
# v15 / v16: (1) tests, (2) rebuild the v13 re-pilot report from its FULL lab results with the v15 analysis code
# (read-only; no training), (3) the exploratory control-development panel (wave 15: finite-peg scratch recipes and
# gradient-partition dynamics, the locality cell; discovery draw 0, full scale), (4) a runtime estimate for the revised wave 14.
# It does NOT launch the confirmation (scripts/16).
#
#   cd ~/research/cop_research_v16 && COP_VENV=~/fsc/.venv nohup bash scripts/17_v15_rebuild_and_panel.sh > ~/v16.log 2>&1 &
#
# Reads ~/cop_results_v13 (the re-pilot; never written). Writes ~/cop_results_v16. Every step runs; exit 1 if any
# failed. Zip: cop_v16_panel_reports.zip in Downloads (summaries and reports only).
export SCALE="${SCALE:-full}"
export COP_RESULTS="${COP_RESULTS:-$HOME/cop_results_v16}"
source "$(dirname "$0")/common.sh"
set +e
V13="${V13_RESULTS:-$HOME/cop_results_v13}"
ZIP_DIR="${ZIP_DIR:-/mnt/c/Users/Matthew Fried/Downloads}"
[ -d "$ZIP_DIR" ] || ZIP_DIR="$HOME"
O="$COP_RESULTS/v15_reports"
P="$COP_RESULTS/control_panel"
mkdir -p "$O" "$P"
declare -A RC
step() { local name="$1"; shift; echo "=== $(date '+%F %T') $name"; "$@" > "$O/$name.txt" 2>&1; RC[$name]=$?;
         echo "=== $name exit ${RC[$name]}"; tail -3 "$O/$name.txt"; }
stamp="$O/.v13_stamp"; touch "$stamp"

cop inspect-environment --out "$O/environment.json"
step cpu_tests env CUDA_VISIBLE_DEVICES="" DEVICE=cpu python -m pytest -q -rs tests/ -p no:cacheprovider \
    --junitxml "$O/cpu_tests.xml"
step cuda_tests python -m pytest -v -rs tests/ -p no:cacheprovider -k "cuda or gpu_equivalence" \
    --junitxml "$O/cuda_tests.xml"
if grep -q "SKIPPED" "$O/cuda_tests.txt" || ! grep -Eq "[0-9]+ passed" "$O/cuda_tests.txt"; then
  echo "a CUDA test was skipped or none ran" | tee -a "$O/cuda_tests.txt"; RC[cuda_skips]=1; else RC[cuda_skips]=0; fi

# ---- (2) the v13 re-pilot, re-analysed from its full results with the v15 analysis code
m13="${M13:-$V13/v13_reports/wave13_full.jsonl}"
[ -f "$m13" ] || m13="$HOME/research/cop_research_v13/manifests/wave13_full.jsonl"   # written by scripts/15
step rebuild_v13 cop summarize --strict --historical --results "$V13/repilot" --manifest "$m13" --out "$COP_RESULTS/repilot_v13_rebuilt"

# ---- (3) the control-development panel (exploratory)
m15="$COP_HOME/manifests/wave15_${SCALE}.jsonl"
step manifest15 cop generate-manifest --wave 15 --scale "$SCALE" --out "$m15"
step validate15 cop validate-manifest --manifest "$m15"
step run15 cop run --manifest "$m15" --results "$P" --device "$DEVICE" --data-root "$COP_DATA_ROOT" \
    --workers "$WORKERS" --threads "$THREADS" --resume
cop status --manifest "$m15" --results "$P" > "$O/status15.txt" 2>&1
step checks15 python audit_v8/tools/check_results.py "$P" "$O/checks15.json" --manifest "$m15" --transplants-if-any \
    --diagnostics-if-any
step reload15 python audit_v5/tools/fresh_reload.py "$P" "$O/fresh_reload15.json" --device "$DEVICE" \
    --data-root "$COP_DATA_ROOT"
step summary15 cop summarize --strict --results "$P" --manifest "$m15" --out "$P/summary"

# ---- (4) runtime of the revised confirmation from measured timings (re-pilot and panel)
m14="$COP_HOME/manifests/wave14_${SCALE}.jsonl"
step manifest14 cop generate-manifest --wave 14 --scale "$SCALE" --out "$m14"
step runtime_fit python audit_v5/tools/runtime_v13.py fit "$m15" "$P" "$O/rates_panel.json"
step runtime14 python audit_v5/tools/runtime_v13.py estimate "$m14" "$V13/v13_reports/rates_repilot.json" \
    --workers "$WORKERS" --out "$O/runtime14_from_repilot_rates.json"

changed=$(find "$V13" -newer "$stamp" -type f 2>/dev/null | head -5)
if [ -n "$changed" ]; then echo "files under $V13 changed: $changed" | tee "$O/v13_readonly.txt"; RC[v13_readonly]=1
else echo "no file under $V13 changed" > "$O/v13_readonly.txt"; RC[v13_readonly]=0; fi
python - "$O" <<PY
import json, sys
rc = {$(for k in "${!RC[@]}"; do printf '"%s": %s, ' "$k" "${RC[$k]}"; done)}
json.dump({"steps": rc, "all_passed": all(v == 0 for v in rc.values())}, open(sys.argv[1] + "/verdict.json", "w"), indent=1)
print(json.dumps(rc, indent=1))
PY
cp "$m15" "$m14" "$O/" 2>/dev/null
python - "$COP_RESULTS" "$ZIP_DIR/cop_v16_panel_reports.zip" <<'PY'
import sys, zipfile
from pathlib import Path
res, out = Path(sys.argv[1]), Path(sys.argv[2])
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for sub in ("v15_reports", "control_panel/summary", "repilot_v13_rebuilt"):
        for f in sorted((res / sub).rglob("*")):
            if f.is_file() and f.suffix not in (".pt", ".jsonl") and f.stat().st_size < 8e6:
                z.write(f, f"cop_v15_panel_reports/{f.relative_to(res)}")
print("wrote", out, out.stat().st_size // 2**20, "MB")
PY
python -c "import json,sys; sys.exit(0 if json.load(open('$O/verdict.json'))['all_passed'] else 1)"
