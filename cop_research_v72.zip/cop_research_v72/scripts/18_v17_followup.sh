#!/usr/bin/env bash
# v17 follow-up after the wave-15 review.  (1) tests, (2) the read-only quantiser edge probe on the v16 panel,
# (3) wave 16 (EXPLORATORY, discovery draw 0): finite-peg recipes with the straight-through margin and
# compute-matched scratch arms, (4) a runtime estimate for the revised wave 14 fitted on the re-pilot, the v16
# panel and wave 16 together.  It does NOT launch the confirmation (scripts/16).
#
#   cd ~/research/cop_research_v17 && COP_VENV=~/fsc/.venv nohup bash scripts/18_v17_followup.sh > ~/v17.log 2>&1 &
#
# Reads ~/cop_results_v13 and ~/cop_results_v16 (never written). Writes ~/cop_results_v17. Every step runs;
# exit 1 if any failed. Zip: cop_v17_followup_reports.zip in Downloads (summaries and reports only).
export SCALE="${SCALE:-full}"
export COP_RESULTS="${COP_RESULTS:-$HOME/cop_results_v17}"
source "$(dirname "$0")/common.sh"
set +e
V13="${V13_RESULTS:-$HOME/cop_results_v13}"
V16="${V16_RESULTS:-$HOME/cop_results_v16}"
V16_HOME="${V16_HOME:-$HOME/research/cop_research_v16}"       # the v16 checkout (its wave-15 manifest)
ZIP_DIR="${ZIP_DIR:-/mnt/c/Users/Matthew Fried/Downloads}"
[ -d "$ZIP_DIR" ] || ZIP_DIR="$HOME"
O="$COP_RESULTS/v17_reports"
P="$COP_RESULTS/followup16"
mkdir -p "$O" "$P"
declare -A RC
step() { local name="$1"; shift; echo "=== $(date '+%F %T') $name"; "$@" > "$O/$name.txt" 2>&1; RC[$name]=$?;
         echo "=== $name exit ${RC[$name]}"; tail -3 "$O/$name.txt"; }
stamp="$O/.readonly_stamp"; touch "$stamp"

# ---- (1) tests
cop inspect-environment --out "$O/environment.json"
step cpu_tests env CUDA_VISIBLE_DEVICES="" DEVICE=cpu python -m pytest -q -rs tests/ -p no:cacheprovider \
    --junitxml "$O/cpu_tests.xml"
step cuda_tests python -m pytest -v -rs tests/ -p no:cacheprovider -k "cuda or gpu_equivalence" \
    --junitxml "$O/cuda_tests.xml"
if grep -q "SKIPPED" "$O/cuda_tests.txt" || ! grep -Eq "[0-9]+ passed" "$O/cuda_tests.txt"; then
  echo "a CUDA test was skipped or none ran" | tee -a "$O/cuda_tests.txt"; RC[cuda_skips]=1; else RC[cuda_skips]=0; fi

# ---- (2) read-only probe: finite-peg inputs pushed just outside the clipping range by rounding (v16 panel)
step quant_probe python audit_v8/tools/quant_boundary_probe.py "$V16/control_panel" "$O/quant_boundary_probe_v16.json" \
    --device "$DEVICE" --data-root "$COP_DATA_ROOT"

# ---- (3) wave 16 (exploratory)
m16="$COP_HOME/manifests/wave16_${SCALE}.jsonl"
step manifest16 cop generate-manifest --wave 16 --scale "$SCALE" --out "$m16"
step validate16 cop validate-manifest --manifest "$m16"
step run16 cop run --manifest "$m16" --results "$P" --device "$DEVICE" --data-root "$COP_DATA_ROOT" \
    --workers "$WORKERS" --threads "$THREADS" --resume
cop status --manifest "$m16" --results "$P" > "$O/status16.txt" 2>&1
step checks16 python audit_v8/tools/check_results.py "$P" "$O/checks16.json" --manifest "$m16" --transplants-if-any \
    --diagnostics-if-any
step reload16 python audit_v5/tools/fresh_reload.py "$P" "$O/fresh_reload16.json" --device "$DEVICE" \
    --data-root "$COP_DATA_ROOT"
step summary16 cop summarize --strict --results "$P" --manifest "$m16" --out "$P/summary"
step quant_probe16 python audit_v8/tools/quant_boundary_probe.py "$P" "$O/quant_boundary_probe_w16.json" \
    --device "$DEVICE" --data-root "$COP_DATA_ROOT"

# ---- (4) runtime of the revised confirmation, fitted on every measured run (re-pilot, v16 panel, wave 16)
m13="${M13:-$V13/v13_reports/wave13_full.jsonl}"
[ -f "$m13" ] || m13="$HOME/research/cop_research_v13/manifests/wave13_full.jsonl"
m15="${M15:-$V16_HOME/manifests/wave15_full.jsonl}"
[ -f "$m15" ] || m15="$V16/v15_reports/wave15_full.jsonl"
m14="$COP_HOME/manifests/wave14_${SCALE}.jsonl"
step manifest14 cop generate-manifest --wave 14 --scale "$SCALE" --out "$m14"
step rates_combined python audit_v5/tools/runtime_v13.py fitmany "$O/rates_combined.json" \
    --pair "$m13" "$V13/repilot" --pair "$m15" "$V16/control_panel" --pair "$m16" "$P"
step runtime14 python audit_v5/tools/runtime_v13.py estimate "$m14" "$O/rates_combined.json" \
    --workers "$WORKERS" --out "$O/runtime14_combined_rates.json"

changed=$(find "$V13" "$V16" -newer "$stamp" -type f 2>/dev/null | head -5)
if [ -n "$changed" ]; then echo "files under the read-only folders changed: $changed" | tee "$O/readonly.txt"
  RC[readonly]=1; else echo "no file under $V13 or $V16 changed" > "$O/readonly.txt"; RC[readonly]=0; fi
python - "$O" <<PY
import json, sys
rc = {$(for k in "${!RC[@]}"; do printf '"%s": %s, ' "$k" "${RC[$k]}"; done)}
json.dump({"steps": rc, "all_passed": all(v == 0 for v in rc.values())}, open(sys.argv[1] + "/verdict.json", "w"), indent=1)
print(json.dumps(rc, indent=1))
PY
cp "$m16" "$m14" "$O/" 2>/dev/null
python - "$COP_RESULTS" "$ZIP_DIR/cop_v17_followup_reports.zip" <<'PY'
import sys, zipfile
from pathlib import Path
res, out = Path(sys.argv[1]), Path(sys.argv[2])
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for sub in ("v17_reports", "followup16/summary"):
        for f in sorted((res / sub).rglob("*")):
            if f.is_file() and f.suffix not in (".pt",) and f.stat().st_size < 8e6 \
                    and not (f.suffix == ".jsonl" and f.name.startswith("wave14")):
                z.write(f, f"cop_v17_followup_reports/{f.relative_to(res)}")
print("wrote", out, out.stat().st_size // 2**20, "MB")
PY
python -c "import json,sys; sys.exit(0 if json.load(open('$O/verdict.json'))['all_passed'] else 1)"
