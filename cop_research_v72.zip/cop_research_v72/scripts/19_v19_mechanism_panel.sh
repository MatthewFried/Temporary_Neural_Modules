#!/usr/bin/env bash
# Superseded in v20 (review item 10: this launcher could exit 0 after a packaging failure).
# Use scripts/21_v21_mechanism_panel.sh, which writes ~/cop_results_v21.
echo "scripts/19 is superseded: run scripts/21_v21_mechanism_panel.sh" >&2
exit 1
