#!/usr/bin/env bash
# Superseded in v21 (the v20 recode fits ran in float32, and the symmetry control failed on rounding drift).
# Use scripts/21_v21_mechanism_panel.sh, which writes ~/cop_results_v21.
echo "scripts/20 is superseded: run scripts/21_v21_mechanism_panel.sh" >&2
exit 1
