#!/usr/bin/env bash
# The v21 wave-17 panel runs from the v21 folder (~/research/cop_research_v21) into ~/cop_results_v21.  This v22
# folder has different code (cop-7.5.0); running wave 17 from here would not reuse those results.
echo "run scripts/21 from ~/research/cop_research_v21; this folder's panel is scripts/22_v22_panel.sh" >&2
exit 1
