#!/usr/bin/env bash
# Superseded in v23 (review of v22: matched exposure on the actual sampled stream, ETD selection and accounting).
# Use scripts/23_v23_panel.sh, which writes ~/cop_results_v23.
echo "scripts/22 is superseded: run scripts/23_v23_panel.sh" >&2
exit 1
