#!/usr/bin/env bash
# Superseded in v24 (the pristine certificate refused the group's pass-through identity node).
# Use scripts/24_v24_panel.sh, which writes ~/cop_results_v24.
echo "scripts/23 is superseded: run scripts/24_v24_panel.sh" >&2
exit 1
