#!/usr/bin/env bash
# Superseded in v25 (the v24 results in ~/cop_results_v24 are kept as they are).
# Use scripts/25_v25_panel.sh, which writes ~/cop_results_v25.
echo "scripts/24 is superseded: run scripts/25_v25_panel.sh" >&2
exit 1
