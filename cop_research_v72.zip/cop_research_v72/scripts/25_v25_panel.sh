#!/usr/bin/env bash
# Superseded in v26 before it ran (v26 holds every v25 block plus three new ones).
# Use scripts/26_v26_panel.sh, which writes ~/cop_results_v26.
echo "scripts/25 is superseded: run scripts/26_v26_panel.sh" >&2
exit 1
