#!/usr/bin/env bash
# Superseded in v29.  The v26 panel runs from the v26 / v27 / v28 folder (same semantics cop-7.8.0) into
# ~/cop_results_v26; this folder has different code (cop-7.9.0) and would not reuse those results.
echo "run scripts/26 from ~/research/cop_research_v28; this folder's panel is scripts/29_v29_panel.sh" >&2
exit 1
