#!/usr/bin/env bash
# Superseded in v30 before it ran (wave 21 was extended).  Use scripts/30_v30_panel.sh (~/cop_results_v30).
echo "scripts/29 is superseded: run scripts/30_v30_panel.sh" >&2
exit 1
