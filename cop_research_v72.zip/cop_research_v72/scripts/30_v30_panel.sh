#!/usr/bin/env bash
# Superseded in v31 before it ran (review fixes: phase-matched forks, strict transplant analysis).
echo "scripts/30 is superseded: run scripts/31_v31_panel.sh" >&2
exit 1
