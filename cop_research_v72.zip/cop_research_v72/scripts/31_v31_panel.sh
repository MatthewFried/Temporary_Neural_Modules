#!/usr/bin/env bash
# Superseded in v32 before it ran (wave 21 extended).  Use scripts/32_v32_panel.sh (~/cop_results_v32).
echo "scripts/31 is superseded: run scripts/32_v32_panel.sh" >&2
exit 1
