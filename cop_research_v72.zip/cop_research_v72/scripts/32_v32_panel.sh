#!/usr/bin/env bash
# Superseded in v33 before it ran.  Use scripts/33_v33_panel.sh (~/cop_results_v33).
echo "scripts/32 is superseded: run scripts/33_v33_panel.sh" >&2
exit 1
