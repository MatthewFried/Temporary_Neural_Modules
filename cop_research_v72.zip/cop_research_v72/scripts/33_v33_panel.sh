#!/usr/bin/env bash
# Superseded in v34 (review of v33: age-analysis accounting and integrity, the v32 control corrections).  Use
# scripts/34_v34_panel.sh (~/cop_results_v34).  Results of a v33 run, if any, stay in ~/cop_results_v33.
echo "scripts/33 is superseded: run scripts/34_v34_panel.sh" >&2
exit 1
