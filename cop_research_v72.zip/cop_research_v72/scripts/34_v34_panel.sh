#!/usr/bin/env bash
# Superseded in v36 (two disturbance controls, declared outcomes; semantics cop-7.15.0).  Use scripts/36_v36_panel.sh
# (~/cop_results_v36).  The v34 / v35 run's results stay in ~/cop_results_v34 and are not reused.
echo "scripts/34 is superseded: run scripts/36_v36_panel.sh" >&2
exit 1
