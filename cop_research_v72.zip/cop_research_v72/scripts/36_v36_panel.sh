#!/usr/bin/env bash
# v36 panel (wave 21, 402 jobs) around the v24 first-layer transplant lead.  Data draws 301-306, never used before.
#   V30_replication  fixed / redrawn removals, C1, C2, C1_phase at optimizer seeds 0 and 1 on every draw
#   V30_forks        from the same expanded end state: abrupt removal, keep (additions stay and train),
#                    keep_frozen (additions stay, frozen); the linear removal is in V30_replication
#   V31_forks_phase_matched  the same three forks with the linear removal's reset times (fresh optimizer at 0 and g)
#   V30_restricted   first-layer-only repair (all layers train in the transition) with the other layers at their
#                    POST-TRANSITION values or reset to f0; C1_first (C1's whole budget), C1_first_window (the repair
#                    window's budget)
#   V30_cut          early and late insertion cuts
#   V30_boundary     rotated inputs, a nonlinear (product) rule, no shortcut (rho 0.5)
#   V32_coupling_time  the trained additions kept coupled (gates at 1) for U/2 or U updates, trained or frozen,
#                    then removed (a fixed-budget allocation: longer coupling = shorter repair);
#                    V32_rebuild  trained backbone + fresh additions, f0 + trained additions, f0 + fresh additions;
#                    V32_disturbance  f0 continued, then a random weight perturbation matched to the fixed removal's
#                    immediate deletion error (C1_disturbed) or risk (C1_disturbed_loss), then the abrupt_pm
#                    repair schedule (generic damage and recovery).  An error match that cannot be reached (the
#                    deletion is already at chance) ends the job invalid with that DECLARED outcome: run21 then
#                    passes only if every job that did not complete has such an outcome (scripts/declared_outcomes.py),
#                    and the analyses list it as an exclusion
#   age analysis     the replication trajectories' age checkpoints and the time-matched C1_phase states
# Steps: environment, tests, manifest, validation, the panel, status, checks, fresh reload (recorded devices),
# strict summary, timing fit, the three analyses (layer transplant, cross-recipient transplant, portability by
# age), the evidence check (every analysis that exited 0 wrote its tables and a passing coverage report), manifest
# copy, packaging (verified), final verdict.  It does not touch any earlier results folder.
#
#   cd ~/research/cop_research_v36 && WORKERS=3 COP_VENV=~/fsc/.venv nohup bash scripts/36_v36_panel.sh > ~/v36.log 2>&1 &
#
# Writes ~/cop_results_v36 only.  Exit 0 only if EVERY step (packaging included) succeeded.  A failed test,
# CUDA-skip check, manifest generation or validation skips the training panel unless DIAGNOSTIC_OVERRIDE=1.
# A failed analysis still leaves a diagnostic archive (its tables are required only when the evidence check
# passed); the exit status stays nonzero.  Zip: cop_v36_panel_reports.zip.  The fitted age maps stay in
# ~/cop_results_v36/panel21/age_maps (not archived; their hashes are in the age coverage report).
# this release's own folder, never a COP_HOME inherited from an older release's shell
export COP_HOME="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export SCALE="${SCALE:-full}"
export COP_RESULTS="${COP_RESULTS:-$HOME/cop_results_v36}"
source "$(dirname "$0")/common.sh"
set +e
set +u
ZIP_DIR="${ZIP_DIR:-/mnt/c/Users/Matthew Fried/Downloads}"
[ -d "$ZIP_DIR" ] || ZIP_DIR="$HOME"
COP_PYTEST="${COP_PYTEST:-python -m pytest}"
O="$COP_RESULTS/v36_reports"
P="$COP_RESULTS/panel21"
ZIP="$ZIP_DIR/cop_v36_panel_reports.zip"
mkdir -p "$O" "$P"
rm -f "$O/declared21.json"
declare -A RC
ORDER=()
step() { local name="$1"; shift; ORDER+=("$name"); echo "=== $(date '+%F %T') $name"; "$@" > "$O/$name.txt" 2>&1
         RC[$name]=$?; echo "=== $name exit ${RC[$name]}"; tail -3 "$O/$name.txt"; }
skip() { ORDER+=("$1"); RC[$1]=99; echo "=== $1 SKIPPED: $2" | tee "$O/$1.txt"; }
verdict() {   # verdict <file> [pending-step ...]
  local f="$1"; shift
  local js="{"
  for k in "${ORDER[@]}"; do js+="\"$k\": ${RC[$k]}, "; done
  js="${js%, }}"
  python - "$f" "$js" "$@" <<'PY'
import json, sys
f, rc, pending = sys.argv[1], json.loads(sys.argv[2]), sys.argv[3:]
json.dump({"steps": rc, "pending": pending, "skipped_code": 99,
           "all_passed": not pending and all(v == 0 for v in rc.values()),
           "completed_steps_passed": all(v == 0 for v in rc.values()),
           "note": "pending steps cannot report inside the archive they write; the launcher's exit status and the "
                   "verdict.json next to the reports are final"}, open(f, "w"), indent=1)
print(json.dumps(rc, indent=1))
PY
}

step environment cop inspect-environment --out "$O/environment.json"
step cpu_tests env CUDA_VISIBLE_DEVICES="" DEVICE=cpu $COP_PYTEST -q -rs tests/ -p no:cacheprovider \
    --junitxml "$O/cpu_tests.xml"
step cuda_tests $COP_PYTEST -v -rs tests/ -p no:cacheprovider -k "cuda or gpu_equivalence" \
    --junitxml "$O/cuda_tests.xml"
ORDER+=(cuda_skips)
if grep -q "SKIPPED" "$O/cuda_tests.txt" || ! grep -Eq "[0-9]+ passed" "$O/cuda_tests.txt"; then
  echo "a CUDA test was skipped or none ran" | tee "$O/cuda_skips.txt"; RC[cuda_skips]=1
else echo "no CUDA test skipped" > "$O/cuda_skips.txt"; RC[cuda_skips]=0; fi

m21="$COP_HOME/manifests/wave21_${SCALE}.jsonl"
step manifest21 cop generate-manifest --wave 21 --scale "$SCALE" --out "$m21"
step validate21 cop validate-manifest --manifest "$m21"
pre=0
for k in environment cpu_tests cuda_tests cuda_skips manifest21 validate21; do [ "${RC[$k]}" = 0 ] || pre=1; done
if [ "$pre" = 0 ] || [ "${DIAGNOSTIC_OVERRIDE:-0}" = 1 ]; then
  [ "$pre" = 0 ] || echo "DIAGNOSTIC_OVERRIDE=1: running the panel after a failed prerequisite" | tee "$O/override.txt"
  run_panel() {      # v36: exit 1 from the runner passes only when every non-complete job has a declared outcome
    cop run --manifest "$m21" --results "$P" --device "$DEVICE" --data-root "$COP_DATA_ROOT" \
        --workers "$WORKERS" --threads "$THREADS" --resume
    local rc=$?
    [ "$rc" = 1 ] || return "$rc"
    echo "cop run exited 1: every job that did not complete must have a declared outcome of its design"
    python scripts/declared_outcomes.py "$m21" "$P" "$O/declared21.json"
  }
  step run21 run_panel
else
  skip run21 "a prerequisite failed (environment, tests, CUDA skips, manifest or validation); set DIAGNOSTIC_OVERRIDE=1 to run anyway"
fi
# v35: when the panel did not run, every step that reads its results is skipped (it would only see an empty folder)
if [ "${RC[run21]}" = 99 ]; then
  for k in status21 checks21 reload21 summary21 rates21 reversal21 cross21 age21; do
    skip "$k" "the training panel was skipped"
  done
else
step status21 cop status --manifest "$m21" --results "$P"
step checks21 python audit_v8/tools/check_results.py "$P" "$O/checks21.json" --manifest "$m21" --transplants-if-any \
    --diagnostics-if-any
step reload21 python audit_v5/tools/fresh_reload.py "$P" "$O/fresh_reload21.json" --device recorded \
    --data-root "$COP_DATA_ROOT"
step summary21 cop summarize --strict --results "$P" --manifest "$m21" --out "$P/summary"
step rates21 python audit_v5/tools/runtime_v13.py fit "$m21" "$P" "$O/rates21.json"
# analysis only: layer transplants without retraining (first layer into f0, with its trace over the history)
# the confirmatory analysis: manifest-driven coverage (exit 1 on any missing or failed required analysis), the
# fixed declared codes only (no grid search), the config-derived trace inventory and the first-layer update
# decomposition.  Each analysis first removes its own earlier outputs, so no stale file can stand in for them.
LT_FILES="coverage.json,codes_summary.csv,codes_by_draw.csv,contrasts.csv,checks.csv,decomposition_summary.csv,trace.csv"
CT_FILES="coverage.json,rows.csv,by_draw.csv,summary.csv"
AGE_FILES="coverage.json,rows.csv,by_draw.csv,summary.csv,checks.csv"
rm -f "$O"/layer_transplant21_*
step reversal21 python audit_v5/tools/selective_reversal.py "$P" "$O/layer_transplant21" --data-root "$COP_DATA_ROOT" \
    --manifest "$m21" --strict --codes auto --trace --decompose
# analysis only: the same first layers in an INDEPENDENTLY trained recipient (f0 at the other optimizer seed of the
# draw), through identity / permutation / affine interfaces, with donor-f0 and random-layer controls
rm -f "$O"/cross_transplant21_*
step cross21 python audit_v5/tools/cross_transplant.py "$P" "$O/cross_transplant21" --data-root "$COP_DATA_ROOT" \
    --manifest "$m21" --strict
# analysis only: portability over the growth history (the replication pairs), per branch cohort, with recipient
# baselines, alignment status, integrity checks, saved and re-verified maps, and the time-matched C1_phase states
rm -f "$O"/portability_age21_*
rm -rf "$P/age_maps"
step age21 python audit_v5/tools/portability_age.py "$P" "$O/portability_age21" --data-root "$COP_DATA_ROOT" \
    --manifest "$m21" --strict --maps-dir "$P/age_maps"
fi
rm -f "$O/evidence21.json"
step evidence21 python scripts/check_evidence.py "$O/evidence21.json" \
    "reversal21:${RC[reversal21]}:$O/layer_transplant21:$LT_FILES" \
    "cross21:${RC[cross21]}:$O/cross_transplant21:$CT_FILES" \
    "age21:${RC[age21]}:$O/portability_age21:$AGE_FILES"
step manifest_copy cp "$m21" "$O/"

# packaging: the archive carries the verdict of every step before it (packaging pending), is verified, then the
# external verdict is final; the archive is rewritten with that final verdict and verified again
verdict "$O/verdict.json" package package_final
# required members: the launcher's own step logs and, for each step that succeeded, the report it writes (a
# failed step may leave no report; the archive is still written so the diagnostics can be read)
REQ=(--require "v36_reports/verdict_steps.txt")
for k in "${ORDER[@]}"; do REQ+=(--require "v36_reports/$k.txt"); done
[ "${RC[checks21]}" = 0 ] && REQ+=(--require "v36_reports/checks21.json")
[ "${RC[reload21]}" = 0 ] && REQ+=(--require "v36_reports/fresh_reload21.json")
[ "${RC[manifest_copy]}" = 0 ] && REQ+=(--require "v36_reports/$(basename "$m21")")
[ -f "$O/evidence21.json" ] && REQ+=(--require "v36_reports/evidence21.json")
[ -f "$O/declared21.json" ] && REQ+=(--require "v36_reports/declared21.json")
# the analyses are part of the panel's evidence: when the evidence check passed, the coverage report and main
# tables of every analysis that succeeded must be in the archive; when it failed, the launcher already fails and
# the archive is written for diagnosis without them
if [ "${RC[evidence21]}" = 0 ]; then
  if [ "${RC[reversal21]}" = 0 ]; then for f in ${LT_FILES//,/ }; do REQ+=(--require "v36_reports/layer_transplant21_$f"); done; fi
  if [ "${RC[cross21]}" = 0 ]; then for f in ${CT_FILES//,/ }; do REQ+=(--require "v36_reports/cross_transplant21_$f"); done; fi
  if [ "${RC[age21]}" = 0 ]; then for f in ${AGE_FILES//,/ }; do REQ+=(--require "v36_reports/portability_age21_$f"); done; fi
fi
printf '%s\n' "${ORDER[@]}" > "$O/verdict_steps.txt"
step package python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" cop_v36_panel_reports \
    --include v36_reports --include panel21/summary "${REQ[@]}"
verdict "$O/verdict.json" package_final
if [ "${RC[package]}" = 0 ]; then
  step package_final python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" \
      cop_v36_panel_reports --include v36_reports --include panel21/summary "${REQ[@]}"
else
  skip package_final "packaging failed"
  rm -f "$ZIP"
fi
verdict "$O/verdict.json"
[ -f "$ZIP" ] || { echo "no archive at $ZIP"; RC[archive_present]=1; ORDER+=(archive_present); verdict "$O/verdict.json"; }
python -c "import json,sys; sys.exit(0 if json.load(open('$O/verdict.json'))['all_passed'] else 1)"
