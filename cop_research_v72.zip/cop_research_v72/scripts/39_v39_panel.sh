#!/usr/bin/env bash
# Superseded in v41 (the v40 review's fixes: component traces, the continuation factorial, intervention audits,
# strict inventories; semantics cop-7.17.0).  Use scripts/41_v41_panel.sh (~/cop_results_v41).  Any results in
# ~/cop_results_v39 stay there and are not reused.
echo "scripts/39 is superseded: run scripts/41_v41_panel.sh" >&2
exit 1
