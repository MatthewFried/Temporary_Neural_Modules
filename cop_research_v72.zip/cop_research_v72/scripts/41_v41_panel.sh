#!/usr/bin/env bash
# Superseded in v42 (semantics cop-7.18.0): scripts/42_v42_panel.sh runs wave 23 and re-reads the v41 panel
# (~/cop_results_v41 stays as it is and is read only).
echo "scripts/41 is superseded: run scripts/42_v42_panel.sh" >&2
exit 1
