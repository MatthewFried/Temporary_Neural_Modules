#!/usr/bin/env bash
# Superseded in v43 (semantics cop-7.19.0: the v42 review's controls and audits).  Use scripts/43_v43_panel.sh
# (~/cop_results_v43).  Any results in ~/cop_results_v42 stay there and are not reused.
echo "scripts/42 is superseded: run scripts/43_v43_panel.sh" >&2
exit 1
