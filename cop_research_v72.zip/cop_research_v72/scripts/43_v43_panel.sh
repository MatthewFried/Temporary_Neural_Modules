#!/usr/bin/env bash
# Superseded in v44 (semantics cop-7.20.0: the downstream-frozen expansion and the extraction rule).  Use
# scripts/44_v44_panel.sh (~/cop_results_v44).  The v43 results in ~/cop_results_v43 stay there and are read only.
echo "scripts/43 is superseded: run scripts/44_v44_panel.sh" >&2
exit 1
