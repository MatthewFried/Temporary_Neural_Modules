#!/usr/bin/env bash
# Superseded in v45 (semantics cop-7.21.0: the freezing factorial).  Use scripts/45_v45_panel.sh (~/cop_results_v45).
# The v44 results in ~/cop_results_v44 stay there and are read only.
echo "scripts/44 is superseded: run scripts/45_v45_panel.sh" >&2
exit 1
