#!/usr/bin/env bash
# Superseded in v46: its wave-25 evidence list required legacy tables that wave 25 never fills, so a successful panel
# would have failed its evidence step.  Use scripts/46_v46_panel.sh (~/cop_results_v46): it analyses a complete v45
# panel read-only (no retraining) or trains the panel itself.  ~/cop_results_v45 stays as it is.
echo "scripts/45 is superseded: run scripts/46_v46_panel.sh" >&2
exit 1
