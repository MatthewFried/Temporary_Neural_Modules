#!/usr/bin/env bash
# Superseded in v47.  Its wave-25 panel and reports stay in ~/cop_results_v46 (read only from v47 on); the next step
# is the analysis-only coordinated-reversal run, scripts/47_v47_coordinated_reversal.sh (~/cop_results_v47).
echo "scripts/46 is superseded: run scripts/47_v47_coordinated_reversal.sh (analysis only, reads the v46 panel)" >&2
exit 1
