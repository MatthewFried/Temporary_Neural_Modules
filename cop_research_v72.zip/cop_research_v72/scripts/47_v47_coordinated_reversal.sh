#!/usr/bin/env bash
# Superseded in v48.  Its reports stay in ~/cop_results_v47 (read only from v48 on); the corrected reanalysis of the
# same v46 checkpoints is scripts/48_v48_reversal_barriers.sh (~/cop_results_v48).
echo "scripts/47 is superseded: run scripts/48_v48_reversal_barriers.sh (analysis only, reads the v46 panel)" >&2
exit 1
