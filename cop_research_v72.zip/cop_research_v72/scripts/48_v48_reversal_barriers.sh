#!/usr/bin/env bash
# v48: the v47 coordinated-reversal analysis rerun with corrected path reporting (analysis only; no training;
# semantics cop-7.21.0, unchanged).  It reads the complete v46 wave-25 panel (~/cop_results_v46/panel25) read-only.
# This is an exploratory reanalysis of existing checkpoints.  Same measurements as v47:
#   * the 2x2 of additions present / deleted x layers 2..K trained / restored to f0 (the first layer kept) at every
#     saved expansion age of every trajectory, with the interaction; the restore is flagged where it is a no-op;
#   * at 2U, the 5x5 grid of leaf-addition gates x alpha and layers 2..K at f0 + beta (trained - f0), with the
#     corners checked bitwise against the existing models;
#   * three predeclared straight-line paths (diagonal, delete then rewind, rewind then delete).
# Changed in v48 (CHANGES_v48.md): per path the raw worst test error and cross-entropy plus the endpoint-relative
# barrier (worst - max(start, end)); v47's mean along a path is dropped (it weighted points by schedule and counted
# no-op dwell); the test cross-entropy is re-derived per example and must agree; correct-class margin, per-example
# loss and logit-size quantiles at every grid and 2x2 point; the test logits saved beside the decisions.
#
#   cd ~/research/cop_research_v48 && COP_VENV=~/fsc/.venv nohup bash scripts/48_v48_reversal_barriers.sh > ~/v48.log 2>&1 &
#
# Writes ~/cop_results_v48 only (saved predictions and logits in ~/cop_results_v48/preds25, outside the archive).
# Zip: cop_v48_reversal_reports.zip.  V46_RESULTS points elsewhere.
export COP_HOME="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export SCALE="${SCALE:-full}"
export COP_RESULTS="${COP_RESULTS:-$HOME/cop_results_v48}"
source "$(dirname "$0")/common.sh"
set +e
set +u
ZIP_DIR="${ZIP_DIR:-/mnt/c/Users/Matthew Fried/Downloads}"
[ -d "$ZIP_DIR" ] || ZIP_DIR="$HOME"
COP_PYTEST="${COP_PYTEST:-python -m pytest}"
O="$COP_RESULTS/v48_reports"
ZIP="$ZIP_DIR/cop_v48_reversal_reports.zip"
mkdir -p "$O"
declare -A RC
ORDER=()
step() { local name="$1"; shift; ORDER+=("$name"); echo "=== $(date '+%F %T') $name"; "$@" > "$O/$name.txt" 2>&1
         RC[$name]=$?; echo "=== $name exit ${RC[$name]}"; tail -3 "$O/$name.txt"; }
skip() { ORDER+=("$1"); RC[$1]=99; echo "=== $1 SKIPPED: $2" | tee "$O/$1.txt"; }
verdict() {   # verdict <file> [pending-step ...]
  local f="$1"; shift
  local js="{"
  for k in "${ORDER[@]}"; do js+="\"$k\": ${RC[$k]}, "; done
  js="${js%, }}"
  python - "$f" "$js" "$@" <<'PY'
import json, sys
f, rc, pending = sys.argv[1], json.loads(sys.argv[2]), sys.argv[3:]
json.dump({"steps": rc, "pending": pending, "skipped_code": 99,
           "all_passed": not pending and all(v == 0 for v in rc.values()),
           "completed_steps_passed": all(v == 0 for v in rc.values()),
           "note": "pending steps cannot report inside the archive they write; the launcher's exit status and the "
                   "verdict.json next to the reports are final"}, open(f, "w"), indent=1)
print(json.dumps(rc, indent=1))
PY
}

step environment cop inspect-environment --out "$O/environment.json"
# the panel: the complete v46 wave-25 panel, same semantics (checked job by job), read only
V46="${V46_RESULTS:-$HOME/cop_results_v46}"
P="$V46/panel25"
m25="$COP_HOME/manifests/wave25_${SCALE}.jsonl"
step manifest25 cop generate-manifest --wave 25 --scale "$SCALE" --out "$m25"
step panel_source python scripts/panel_state.py "$m25" "$P"
if [ "${RC[panel_source]}" = 0 ]; then
  step cpu_tests env CUDA_VISIBLE_DEVICES="" DEVICE=cpu $COP_PYTEST -q -rs tests/ -p no:cacheprovider \
      --junitxml "$O/cpu_tests.xml"
else
  skip cpu_tests "no complete v46 wave-25 panel at $P (see panel_source)"
fi
CODES="0-0-0-0-0,0-1-1-1-1,1-1-1-1-1"
REV_FILES="coverage.json,checks.csv,codes_summary.csv,codes_implants_summary.csv,compute.csv,trace.csv,reversal_2x2.csv,reversal_2x2_by_setting.csv,reversal_2x2_by_draw.csv,reversal_2x2_summary.csv,reversal_grid.csv,reversal_grid_by_draw.csv,reversal_grid_summary.csv,reversal_paths_by_setting.csv,reversal_paths.csv,reversal_path_contrasts.csv,reversal_path_contrasts_by_draw.csv"
rm -f "${O:?}"/coordinated25_*
PREDS="${COP_RESULTS:?}/preds25"
rm -f "${PREDS:?}"/*.npz
if [ "${RC[panel_source]}" = 0 ] && [ "${RC[cpu_tests]}" = 0 ]; then
  step reversal25 python audit_v5/tools/selective_reversal.py "$P" "$O/coordinated25" --data-root "$COP_DATA_ROOT" \
      --manifest "$m25" --strict --codes "$CODES" --implant-codes --trace --trace-codes "$CODES" \
      --trace-implants --reversal-grid --save-preds "$PREDS"
else
  skip reversal25 "the panel source or the CPU tests failed"
fi
rm -f "${O:?}/evidence25.json"
step evidence25 python scripts/check_evidence.py "$O/evidence25.json" \
    "reversal25:${RC[reversal25]}:$O/coordinated25:$REV_FILES"
step manifest_copy cp "$m25" "$O/"

# packaging: the archive carries the verdict of every step before it (packaging pending), is verified, then the
# external verdict is final; the archive is rewritten with that final verdict and verified again
verdict "$O/verdict.json" package package_final
REQ=(--require "v48_reports/verdict_steps.txt")
for k in "${ORDER[@]}"; do REQ+=(--require "v48_reports/$k.txt"); done
[ -f "$O/evidence25.json" ] && REQ+=(--require "v48_reports/evidence25.json")
if [ "${RC[evidence25]}" = 0 ] && [ "${RC[reversal25]}" = 0 ]; then
  for f in ${REV_FILES//,/ }; do REQ+=(--require "v48_reports/coordinated25_$f"); done
fi
printf '%s\n' "${ORDER[@]}" > "$O/verdict_steps.txt"
step package python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" cop_v48_reversal_reports \
    --include v48_reports "${REQ[@]}"
verdict "$O/verdict.json" package_final
if [ "${RC[package]}" = 0 ]; then
  step package_final python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" \
      cop_v48_reversal_reports --include v48_reports "${REQ[@]}"
else
  skip package_final "packaging failed"
  rm -f "$ZIP"
fi
verdict "$O/verdict.json"
[ -f "$ZIP" ] || { echo "no archive at $ZIP"; RC[archive_present]=1; ORDER+=(archive_present); verdict "$O/verdict.json"; }
python -c "import json,sys; sys.exit(0 if json.load(open('$O/verdict.json'))['all_passed'] else 1)"
