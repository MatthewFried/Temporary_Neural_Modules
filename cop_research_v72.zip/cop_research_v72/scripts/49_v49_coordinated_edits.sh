#!/usr/bin/env bash
# Superseded in v50 (its selection rule, summaries, rank schemes and grouping were revised after review; any v49
# reports stay in ~/cop_results_v49).  Run scripts/51_v51_coordinated_edits.sh (~/cop_results_v51).
echo "scripts/49 is superseded: run scripts/51_v51_coordinated_edits.sh (analysis only, reads the v46 panel)" >&2
exit 1
