#!/usr/bin/env bash
# Superseded in v51 (the CUDA agreement test, the fold's audit, diagnostics and path, and the rank accounting were
# revised after review; any v50 reports stay in ~/cop_results_v50).  Run scripts/51_v51_coordinated_edits.sh.
echo "scripts/50 is superseded: run scripts/51_v51_coordinated_edits.sh (analysis only, reads the v46 panel)" >&2
exit 1
