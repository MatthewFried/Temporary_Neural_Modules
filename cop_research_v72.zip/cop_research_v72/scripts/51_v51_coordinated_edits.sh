#!/usr/bin/env bash
# v51: coordinated edits on the existing wave-25 checkpoints, with the v50 review fixed (analysis only; no training;
# semantics cop-7.21.0, unchanged).  It reads the complete v46 wave-25 panel (~/cop_results_v46/panel25) read-only;
# an exploratory reanalysis of existing checkpoints.  Parts (audit_v5/tools/coordinated_edits.py, CHANGES_v51.md):
#   * deletion x whole-layer rewind edits and the validation-selected removal sets (unchanged from v50);
#   * rank-k restores, with changed entries, factor storage and intrinsic dimension reported separately;
#   * shared-ancestor cross-history packages (unchanged from v50);
#   * the fold in two segments: the additions' residual (output - surrogate) scaled away inside the expanded graph
#     with the backbone fixed, then the surrogate folded into the reading layer and the later layers moved to f0's;
#     the folded network is checked against the in-graph surrogate on every partition;
#   * training diagnostics of f0: where its remaining training loss sits and which subgroups' gradients would scale
#     its causal input block.
# The analysis runs on DEVICE (default cuda; cuda:N is recognised), passed explicitly.  On CUDA the tool's CUDA
# test must actually RUN and pass first (a skipped test stops the run): the miniature analysed on both devices
# and compared decision by decision (cuda_agreement.json).  scripts/48 is separate and still valid; scripts/49
# and scripts/50 are superseded.
#
#   cd ~/research/cop_research_v51 && COP_VENV=~/fsc/.venv nohup bash scripts/51_v51_coordinated_edits.sh > ~/v51.log 2>&1 &
#
# Writes ~/cop_results_v51 only (saved decisions and fold fits in ~/cop_results_v51/preds25, outside the archive).
# Zip: cop_v51_edits_reports.zip.  V46_RESULTS points elsewhere.
export COP_HOME="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export SCALE="${SCALE:-full}"
export COP_RESULTS="${COP_RESULTS:-$HOME/cop_results_v51}"
source "$(dirname "$0")/common.sh"
set +e
set +u
ZIP_DIR="${ZIP_DIR:-/mnt/c/Users/Matthew Fried/Downloads}"
[ -d "$ZIP_DIR" ] || ZIP_DIR="$HOME"
COP_PYTEST="${COP_PYTEST:-python -m pytest}"
O="$COP_RESULTS/v51_reports"
ZIP="$ZIP_DIR/cop_v51_edits_reports.zip"
mkdir -p "$O"
declare -A RC
ORDER=()
step() { local name="$1"; shift; ORDER+=("$name"); echo "=== $(date '+%F %T') $name"; "$@" > "$O/$name.txt" 2>&1
         RC[$name]=$?; echo "=== $name exit ${RC[$name]}"; tail -3 "$O/$name.txt"; }
skip() { ORDER+=("$1"); RC[$1]=99; echo "=== $1 SKIPPED: $2" | tee "$O/$1.txt"; }
verdict() {   # verdict <file> [pending-step ...]
  local f="$1"; shift
  local js="{"
  for k in "${ORDER[@]}"; do js+="\"$k\": ${RC[$k]}, "; done
  js="${js%, }}"
  python - "$f" "$js" "$@" <<'PY'
import json, sys
f, rc, pending = sys.argv[1], json.loads(sys.argv[2]), sys.argv[3:]
json.dump({"steps": rc, "pending": pending, "skipped_code": 99,
           "all_passed": not pending and all(v == 0 for v in rc.values()),
           "completed_steps_passed": all(v == 0 for v in rc.values()),
           "note": "pending steps cannot report inside the archive they write; the launcher's exit status and the "
                   "verdict.json next to the reports are final"}, open(f, "w"), indent=1)
print(json.dumps(rc, indent=1))
PY
}

step environment cop inspect-environment --out "$O/environment.json"
# the panel: the complete v46 wave-25 panel, same semantics (checked job by job), read only
V46="${V46_RESULTS:-$HOME/cop_results_v46}"
P="$V46/panel25"
m25="$COP_HOME/manifests/wave25_${SCALE}.jsonl"
rm -f "$m25"          # a failed generation must not fall through to a stale manifest
step manifest25 cop generate-manifest --wave 25 --scale "$SCALE" --out "$m25"
if [ "${RC[manifest25]}" = 0 ] && [ -s "$m25" ]; then
  step panel_source python scripts/panel_state.py "$m25" "$P"
else
  skip panel_source "the wave-25 manifest was not generated (see manifest25)"
fi
if [ "${RC[panel_source]}" = 0 ]; then
  step cpu_tests env CUDA_VISIBLE_DEVICES="" DEVICE=cpu $COP_PYTEST -q -rs tests/ -p no:cacheprovider \
      --junitxml "$O/cpu_tests.xml"
else
  skip cpu_tests "no complete v46 wave-25 panel at $P (see panel_source)"
fi
READY=0
[ "${RC[panel_source]}" = 0 ] && [ "${RC[cpu_tests]}" = 0 ] && READY=1
# the analysis backend: on a CUDA device (cuda or cuda:N) the tool's CUDA test must RUN and pass first (pytest exits
# 0 when the test is skipped, so the junit report is checked: tests ran, none skipped)
case "$DEVICE" in cuda|cuda:*) IS_CUDA=1 ;; *) IS_CUDA=0 ;; esac
rm -f "${O:?}/cuda_analysis_test.xml" "${O:?}/cuda_agreement.json"
if [ "$READY" = 1 ] && [ "$IS_CUDA" = 1 ]; then
  step cuda_analysis_test env DEVICE="$DEVICE" COP_TEST_CUDA_DEVICE="$DEVICE" \
      COP_CUDA_REPORT="$O/cuda_agreement.json" $COP_PYTEST -q -rs tests/test_v51.py -k cuda -p no:cacheprovider \
      --junitxml "$O/cuda_analysis_test.xml"
  step cuda_test_ran python scripts/junit_ran.py "$O/cuda_analysis_test.xml"
  { [ "${RC[cuda_analysis_test]}" = 0 ] && [ "${RC[cuda_test_ran]}" = 0 ]; } || READY=0
fi
VARIANTS="A_free,B_scfrozen,C_dsfrozen,D_bothfrozen"
EDIT_FILES="coverage.json,checks.csv,minimal_edits.csv,minimal_edits_by_draw.csv,minimal_edits_summary.csv,minimal_sets.csv,minimal_sets_counts.csv,minimal_sets_by_draw.csv,minimal_sets_summary.csv,minimal_sets_chosen.csv,rank_restores.csv,rank_restores_by_draw.csv,rank_restores_summary.csv,rank_layers.csv,rank_layers_summary.csv,transfer.csv,transfer_by_draw.csv,transfer_summary.csv,transfer_contrasts.csv,transfer_contrasts_by_draw.csv,transfer_contrasts_summary.csv,fold.csv,fold_by_draw.csv,fold_summary.csv,fold_fit.csv,fold_fit_summary.csv,fold_paths.csv,fold_paths_summary.csv,train_groups.csv,train_groups_summary.csv,f0_gradients.csv,f0_gradients_summary.csv,first_layer_change.csv,first_layer_change_summary.csv"
rm -f "${O:?}"/edits25_*
PREDS="${COP_RESULTS:?}/preds25"
rm -f "${PREDS:?}"/*.npz
if [ "$READY" = 1 ]; then
  step edits25 python audit_v5/tools/coordinated_edits.py "$P" "$O/edits25" --data-root "$COP_DATA_ROOT" \
      --manifest "$m25" --strict --device "$DEVICE" --expect-variants "$VARIANTS" --minimal-edits \
      --rank-restores --transfer --fold --train-diagnostics --save-preds "$PREDS"
else
  skip edits25 "the manifest, the panel source or the tests failed"
fi
rm -f "${O:?}/evidence25.json"
step evidence25 python scripts/check_evidence.py "$O/evidence25.json" \
    "edits25:${RC[edits25]}:$O/edits25:$EDIT_FILES"
step manifest_copy cp "$m25" "$O/"

# packaging: the archive carries the verdict of every step before it (packaging pending), is verified, then the
# external verdict is final; the archive is rewritten with that final verdict and verified again
verdict "$O/verdict.json" package package_final
REQ=(--require "v51_reports/verdict_steps.txt")
for k in "${ORDER[@]}"; do REQ+=(--require "v51_reports/$k.txt"); done
[ -f "$O/evidence25.json" ] && REQ+=(--require "v51_reports/evidence25.json")
[ "$IS_CUDA" = 1 ] && [ "${RC[cuda_analysis_test]:-1}" = 0 ] && REQ+=(--require "v51_reports/cuda_agreement.json")
if [ "${RC[evidence25]}" = 0 ] && [ "${RC[edits25]}" = 0 ]; then
  for f in ${EDIT_FILES//,/ }; do REQ+=(--require "v51_reports/edits25_$f"); done
fi
printf '%s\n' "${ORDER[@]}" > "$O/verdict_steps.txt"
step package python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" cop_v51_edits_reports \
    --include v51_reports "${REQ[@]}"
verdict "$O/verdict.json" package_final
if [ "${RC[package]}" = 0 ]; then
  step package_final python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" \
      cop_v51_edits_reports --include v51_reports "${REQ[@]}"
else
  skip package_final "packaging failed"
  rm -f "$ZIP"
fi
verdict "$O/verdict.json"
[ -f "$ZIP" ] || { echo "no archive at $ZIP"; RC[archive_present]=1; ORDER+=(archive_present); verdict "$O/verdict.json"; }
python -c "import json,sys; sys.exit(0 if json.load(open('$O/verdict.json'))['all_passed'] else 1)"
