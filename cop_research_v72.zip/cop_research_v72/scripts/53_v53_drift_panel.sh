#!/usr/bin/env bash
# v53: the wave-26 panel (600 jobs; semantics cop-7.21.0, unchanged: nothing under cop/ outside the manifest builders
# changed).  What drives the expansion's drift (v52: the additions' output grows to many times the activations it
# joins, the training loss rises about twentyfold, the first layer's causal columns grow)?  Data draws 337-348 (never
# used), optimizer seeds 0 and 1.  Per draw and seed, from one f0:
#   expansions to 2U    {A: nothing held, B: the first layer's shortcut column held} x {routed gradients, every
#                       example's gradient to every addition} x {relu, affine (identity activation) additions}, and
#                       the routed relu arm at 0.3 x the learning rate; each with wave 25's removal (secondary)
#   compact controls    f0 continued for 4U with the same hold (and at 0.3 x the rate): at least the expansion's
#                       training compute, states saved on the expansions' clock
#   gain-only training  f0's first-layer input gains trained alone for 2U on the expansions' minibatches (analysis
#                       tool; three modes)
# Steps: environment, manifest, validation, CPU tests, CUDA tests (run, none skipped), the tools' CUDA agreement
# test, the panel, status, result checks, fresh reload, strict summary, timing fit, then four analyses:
#   reversal26  audit_v5/tools/selective_reversal.py: the extraction at 2U of every expansion and compact control,
#               the compact states on the clock, the paired streams, the wave-26 registry of contrasts (CPU)
#   edits26     audit_v5/tools/coordinated_edits.py: the fold, the training diagnostics and the time course of every
#               expansion (DEVICE)
#   gains26     audit_v5/tools/gain_training.py (DEVICE)
#   tables26    audit_v5/tools/panel26_tables.py: one-factor contrasts, the common clock, the excess over the
#               matched compact control (same update; at least the same compute), the gain-trained f0
# then the evidence check, manifest copy, packaging and the final verdict.  It writes ~/cop_results_v53 only.
#
#   cd ~/research/cop_research_v53 && WORKERS=3 COP_VENV=~/fsc/.venv nohup bash scripts/53_v53_drift_panel.sh > ~/v53.log 2>&1 &
#
# Saved decisions: ~/cop_results_v53/preds26; trained gains: ~/cop_results_v53/gains26 (both outside the archive).  Zip: cop_v53_panel_reports.zip.
# A stopped run is continued by running the same command again (finished jobs are kept).
export COP_HOME="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export SCALE="${SCALE:-full}"
export COP_RESULTS="${COP_RESULTS:-$HOME/cop_results_v53}"
source "$(dirname "$0")/common.sh"
set +e
set +u
ZIP_DIR="${ZIP_DIR:-/mnt/c/Users/Matthew Fried/Downloads}"
[ -d "$ZIP_DIR" ] || ZIP_DIR="$HOME"
COP_PYTEST="${COP_PYTEST:-python -m pytest}"
O="$COP_RESULTS/v53_reports"
P="$COP_RESULTS/panel26"
ZIP="$ZIP_DIR/cop_v53_panel_reports.zip"
mkdir -p "$O" "$P"
declare -A RC
ORDER=()
step() { local name="$1"; shift; ORDER+=("$name"); echo "=== $(date '+%F %T') $name"; "$@" > "$O/$name.txt" 2>&1
         RC[$name]=$?; echo "=== $name exit ${RC[$name]}"; tail -3 "$O/$name.txt"; }
skip() { ORDER+=("$1"); RC[$1]=99; echo "=== $1 SKIPPED: $2" | tee "$O/$1.txt"; }
verdict() {   # verdict <file> [pending-step ...]
  local f="$1"; shift
  local js="{"
  for k in "${ORDER[@]}"; do js+="\"$k\": ${RC[$k]}, "; done
  js="${js%, }}"
  python - "$f" "$js" "$@" <<'PY'
import json, sys
f, rc, pending = sys.argv[1], json.loads(sys.argv[2]), sys.argv[3:]
json.dump({"steps": rc, "pending": pending, "skipped_code": 99,
           "all_passed": not pending and all(v == 0 for v in rc.values()),
           "completed_steps_passed": all(v == 0 for v in rc.values()),
           "note": "pending steps cannot report inside the archive they write; the launcher's exit status and the "
                   "verdict.json next to the reports are final"}, open(f, "w"), indent=1)
print(json.dumps(rc, indent=1))
PY
}

step environment cop inspect-environment --out "$O/environment.json"
m26="$COP_HOME/manifests/wave26_${SCALE}.jsonl"
rm -f "$m26"          # a failed generation must not fall through to a stale manifest
step manifest26 cop generate-manifest --wave 26 --scale "$SCALE" --out "$m26"
if [ "${RC[manifest26]}" = 0 ] && [ -s "$m26" ]; then
  step validate26 cop validate-manifest --manifest "$m26"
else
  skip validate26 "the wave-26 manifest was not generated (see manifest26)"
fi
PRE=0
[ "${RC[environment]}" = 0 ] && [ "${RC[manifest26]}" = 0 ] && [ "${RC[validate26]}" = 0 ] && PRE=1
if [ "$PRE" = 1 ]; then
  step cpu_tests env CUDA_VISIBLE_DEVICES="" DEVICE=cpu $COP_PYTEST -q -rs tests/ -p no:cacheprovider \
      --junitxml "$O/cpu_tests.xml"
else
  skip cpu_tests "the environment, the manifest or its validation failed"
fi
# on a CUDA device every CUDA test must RUN and pass (pytest exits 0 when a test is skipped, so the junit reports are
# checked: tests ran, none skipped): the training code's, and the wave-26 tools' agreement with their CPU analysis
case "$DEVICE" in cuda|cuda:*) IS_CUDA=1 ;; *) IS_CUDA=0 ;; esac
rm -f "${O:?}/cuda_tests.xml" "${O:?}/cuda_analysis_test.xml" "${O:?}/cuda_agreement.json"
READY=0
[ "$PRE" = 1 ] && [ "${RC[cpu_tests]}" = 0 ] && READY=1
if [ "$READY" = 1 ] && [ "$IS_CUDA" = 1 ]; then
  step cuda_tests env DEVICE="$DEVICE" COP_TEST_CUDA_DEVICE="$DEVICE" $COP_PYTEST -q -rs tests/ \
      -k "cuda or gpu_equivalence" --ignore tests/test_v53.py -p no:cacheprovider --junitxml "$O/cuda_tests.xml"
  step cuda_tests_ran python scripts/junit_ran.py "$O/cuda_tests.xml"
  step cuda_analysis_test env DEVICE="$DEVICE" COP_TEST_CUDA_DEVICE="$DEVICE" \
      COP_CUDA_REPORT="$O/cuda_agreement.json" $COP_PYTEST -q -rs tests/test_v53.py -k cuda -p no:cacheprovider \
      --junitxml "$O/cuda_analysis_test.xml"
  step cuda_test_ran python scripts/junit_ran.py "$O/cuda_analysis_test.xml"
  for k in cuda_tests cuda_tests_ran cuda_analysis_test cuda_test_ran; do [ "${RC[$k]}" = 0 ] || READY=0; done
fi

if [ "$READY" = 1 ] || [ "${DIAGNOSTIC_OVERRIDE:-0}" = 1 ]; then
  [ "$READY" = 1 ] || echo "DIAGNOSTIC_OVERRIDE=1: running the panel after a failed prerequisite" | tee "$O/override.txt"
  step run26 cop run --manifest "$m26" --results "$P" --device "$DEVICE" --data-root "$COP_DATA_ROOT" \
      --workers "$WORKERS" --threads "$THREADS" --resume
else
  skip run26 "a prerequisite failed (environment, manifest, validation or tests); set DIAGNOSTIC_OVERRIDE=1 to run anyway"
fi
LT26_FILES="coverage.json,checks.csv,codes.csv,codes_summary.csv,codes_by_draw.csv,codes_implants.csv,codes_implants_summary.csv,codes_implants_by_draw.csv,codes_implants_contrasts.csv,codes_implants_contrasts_by_draw.csv,contrasts.csv,decomposition_summary.csv,decomposition_trace.csv,native_summary.csv,trace.csv,registry_by_setting.csv,registry_by_draw.csv,registry_summary.csv,compact_fork_audit.csv,compute.csv,compute_summary.csv,paired_streams.csv,extraction_2u.csv,extraction_2u_by_setting.csv,extraction_2u_by_draw.csv,extraction_2u_summary.csv"
EDIT_FILES="coverage.json,checks.csv,fold.csv,fold_summary.csv,fold_fit.csv,fold_fit_summary.csv,fold_paths.csv,fold_paths_summary.csv,train_groups.csv,train_groups_summary.csv,f0_gradients.csv,f0_gradients_summary.csv,first_layer_change.csv,first_layer_change_summary.csv,age_course.csv,age_course_by_draw.csv,age_course_summary.csv"
GAIN_FILES="coverage.json,gain_runs.csv,gain_runs_by_draw.csv,gain_runs_summary.csv,gain_vectors.csv,gain_vectors_summary.csv,gain_stream.csv"
TABLE_FILES="coverage.json,arm_contrasts.csv,arm_contrasts_by_draw.csv,arm_contrasts_summary.csv,course.csv,course_by_draw.csv,course_summary.csv,excess.csv,excess_by_draw.csv,excess_summary.csv,gain_contrasts.csv,gain_contrasts_by_draw.csv,gain_contrasts_summary.csv"
PAIRED_VARY="growth.act,growth.spec_partition,train.lr"
# at the checkpoints away from 2U: the state itself, the extraction (its first layer in f0) and f0
TRACE_CODES="0-0-0-0-0,0-1-1-1-1,1-1-1-1-1"
rm -f "${O:?}"/reversal26_* "${O:?}"/edits26_* "${O:?}"/gains26_* "${O:?}"/tables26_*
PREDS="${COP_RESULTS:?}/preds26"
GAINS="${COP_RESULTS:?}/gains26"
rm -f "${PREDS:?}"/*.npz "${GAINS:?}"/*.npz
# when the panel did not run, every step that reads its results is skipped; when it ran but did not finish, only its
# status is reported (which jobs failed), since every analysis needs the complete panel
if [ "${RC[run26]}" = 99 ]; then
  for k in status26 checks26 reload26 summary26 rates26 reversal26 edits26 gains26 tables26; do
    skip "$k" "the training panel was skipped (see run26)"
  done
elif [ "${RC[run26]}" != 0 ]; then
  step status26 cop status --manifest "$m26" --results "$P"
  for k in checks26 reload26 summary26 rates26 reversal26 edits26 gains26 tables26; do
    skip "$k" "the training panel did not finish (see run26 and status26); run the same command again to continue"
  done
else
  step status26 cop status --manifest "$m26" --results "$P"
  step checks26 python audit_v8/tools/check_results.py "$P" "$O/checks26.json" --manifest "$m26" \
      --transplants-if-any --diagnostics-if-any
  step reload26 python audit_v5/tools/fresh_reload.py "$P" "$O/fresh_reload26.json" --device recorded \
      --data-root "$COP_DATA_ROOT"
  step summary26 cop summarize --strict --results "$P" --manifest "$m26" --out "$COP_RESULTS/summary26"
  step rates26 python audit_v5/tools/runtime_v13.py fit "$m26" "$P" "$O/rates26.json"
  step reversal26 python audit_v5/tools/selective_reversal.py "$P" "$O/reversal26" --data-root "$COP_DATA_ROOT" \
      --manifest "$m26" --strict --codes auto --trace --trace-codes "$TRACE_CODES" --codes-at-2u --implant-codes \
      --decompose --paired-streams --paired-vary "$PAIRED_VARY" --contrasts wave26
  step edits26 python audit_v5/tools/coordinated_edits.py "$P" "$O/edits26" --data-root "$COP_DATA_ROOT" \
      --manifest "$m26" --strict --device "$DEVICE" --fold --train-diagnostics --age-course --save-preds "$PREDS"
  step gains26 python audit_v5/tools/gain_training.py "$P" "$O/gains26" --data-root "$COP_DATA_ROOT" \
      --manifest "$m26" --strict --device "$DEVICE" --save-gains "$GAINS"
  if [ "${RC[reversal26]}" = 0 ] && [ "${RC[edits26]}" = 0 ] && [ "${RC[gains26]}" = 0 ]; then
    step tables26 python audit_v5/tools/panel26_tables.py "$O/tables26" --manifest "$m26" \
        --reversal "$O/reversal26" --edits "$O/edits26" --gains "$O/gains26" --strict
  else
    skip tables26 "an analysis it reads failed (reversal26, edits26 or gains26)"
  fi
fi
rm -f "${O:?}/evidence26.json"
step evidence26 python scripts/check_evidence.py "$O/evidence26.json" \
    "reversal26:${RC[reversal26]}:$O/reversal26:$LT26_FILES" \
    "edits26:${RC[edits26]}:$O/edits26:$EDIT_FILES" \
    "gains26:${RC[gains26]}:$O/gains26:$GAIN_FILES" \
    "tables26:${RC[tables26]}:$O/tables26:$TABLE_FILES"
if [ -s "$m26" ]; then step manifest_copy cp "$m26" "$O/"; else skip manifest_copy "no manifest"; fi

# packaging: the archive carries the verdict of every step before it (packaging pending), is verified, then the
# external verdict is final; the archive is rewritten with that final verdict and verified again
verdict "$O/verdict.json" package package_final
REQ=(--require "v53_reports/verdict_steps.txt")
for k in "${ORDER[@]}"; do REQ+=(--require "v53_reports/$k.txt"); done
[ "${RC[checks26]}" = 0 ] && REQ+=(--require "v53_reports/checks26.json")
[ "${RC[reload26]}" = 0 ] && REQ+=(--require "v53_reports/fresh_reload26.json")
[ "${RC[manifest_copy]}" = 0 ] && REQ+=(--require "v53_reports/$(basename "$m26")")
[ -f "$O/evidence26.json" ] && REQ+=(--require "v53_reports/evidence26.json")
# the agreement report exists when the tools' CUDA test ran (not skipped) and passed
[ "$IS_CUDA" = 1 ] && [ "${RC[cuda_analysis_test]:-1}" = 0 ] && [ "${RC[cuda_test_ran]:-1}" = 0 ] && \
  REQ+=(--require "v53_reports/cuda_agreement.json")
if [ "${RC[evidence26]}" = 0 ]; then
  [ "${RC[reversal26]}" = 0 ] && for f in ${LT26_FILES//,/ }; do REQ+=(--require "v53_reports/reversal26_$f"); done
  [ "${RC[edits26]}" = 0 ] && for f in ${EDIT_FILES//,/ }; do REQ+=(--require "v53_reports/edits26_$f"); done
  [ "${RC[gains26]}" = 0 ] && for f in ${GAIN_FILES//,/ }; do REQ+=(--require "v53_reports/gains26_$f"); done
  [ "${RC[tables26]}" = 0 ] && for f in ${TABLE_FILES//,/ }; do REQ+=(--require "v53_reports/tables26_$f"); done
fi
INC=(--include v53_reports)
[ -d "$COP_RESULTS/summary26" ] && INC+=(--include summary26)
printf '%s\n' "${ORDER[@]}" > "$O/verdict_steps.txt"
step package python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" cop_v53_panel_reports \
    "${INC[@]}" "${REQ[@]}"
verdict "$O/verdict.json" package_final
if [ "${RC[package]}" = 0 ]; then
  step package_final python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" \
      cop_v53_panel_reports "${INC[@]}" "${REQ[@]}"
else
  skip package_final "packaging failed"
  rm -f "$ZIP"
fi
verdict "$O/verdict.json"
[ -f "$ZIP" ] || { echo "no archive at $ZIP"; RC[archive_present]=1; ORDER+=(archive_present); verdict "$O/verdict.json"; }
python -c "import json,sys; sys.exit(0 if json.load(open('$O/verdict.json'))['all_passed'] else 1)"
