#!/usr/bin/env bash
# Superseded in v55.  Reports of a v54 run stay in ~/cop_results_v54 (untouched from v55 on).  The corrected analysis
# of the same checkpoints is scripts/56_v56_backbone_change.sh (~/cop_results_v56): CPU only from its first step,
# with the comparisons v54 lacked (CHANGES_v56.md).
echo "scripts/54 is superseded: run scripts/56_v56_backbone_change.sh (analysis only, CPU only)" >&2
exit 1
