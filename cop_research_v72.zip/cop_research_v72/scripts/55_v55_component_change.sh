#!/usr/bin/env bash
# Superseded in v56.  Reports of a v55 run stay in ~/cop_results_v55 (untouched from v56 on).  The same analysis,
# with the bias-controlled norm controls, the layer and age course and the update diagnostics, is
# scripts/56_v56_backbone_change.sh (~/cop_results_v56; CHANGES_v56.md).
echo "scripts/55 is superseded: run scripts/56_v56_backbone_change.sh (analysis only, CPU only)" >&2
exit 1
