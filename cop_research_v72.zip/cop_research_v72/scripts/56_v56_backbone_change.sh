#!/usr/bin/env bash
# v56: what the original network's layers hold after expanded training, where along the network and along training
# that changes, and how the routed updates relate to the ordinary gradient.  Analysis only; no network is trained;
# semantics cop-7.21.0, unchanged.  It replaces scripts/55 (retired).  It reads finished panels read-only:
#   wave 25  the v46 panel   ~/cop_results_v46/panel25   (V46_RESULTS points elsewhere)
#   wave 26  the v53 panel   ~/cop_results_v53/panel26   (V53_RESULTS points elsewhere)
# and runs three tools on each (CHANGES_v56.md):
#   change   audit_v5/tools/component_change.py   first layers, controls and probes at 2U
#   course   audit_v5/tools/layer_course.py       the same probes at every layer and every saved age
#   routing  audit_v5/tools/routing_updates.py    the last update against ordinary and routed gradients
# CPU only, start to finish: CUDA is hidden from every step (the environment report included).
#
#   cd ~/research/cop_research_v56 && COP_VENV=~/fsc/.venv nohup bash scripts/56_v56_backbone_change.sh > ~/v56.log 2>&1 &
#
# WAVES="25 26" (default) needs both panels complete; WAVES=25 or WAVES=26 runs one.
# Each choice of WAVES has its own reports folder, probe folder and archive (w25, w26 or w25_26).
# Writes ~/cop_results_v56 only.  Zip: cop_v56_reports_<w25|w26|w25_26>.zip.  The two largest per-row tables of
# the probe tools and the fitted probes stay in ~/cop_results_v56 (their per-draw and summary tables are archived).
export CUDA_VISIBLE_DEVICES=""
export DEVICE=cpu
export COP_HOME="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export SCALE="${SCALE:-full}"
export COP_RESULTS="${COP_RESULTS:-$HOME/cop_results_v56}"
source "$(dirname "$0")/common.sh"
set +e
set +u
export CUDA_VISIBLE_DEVICES=""          # again after common.sh: nothing here may touch the GPU
export DEVICE=cpu
ZIP_DIR="${ZIP_DIR:-/mnt/c/Users/Matthew Fried/Downloads}"
[ -d "$ZIP_DIR" ] || ZIP_DIR="$HOME"
COP_PYTEST="${COP_PYTEST:-python -m pytest}"
REQUESTED="${WAVES:-25 26}"
for w in $REQUESTED; do
  case "$w" in 25|26) ;; *) echo "WAVES takes 25 and/or 26, got '$w'"; exit 2 ;; esac
done
WAVES=""                      # in a fixed order, each wave once
for w in 25 26; do
  case " $REQUESTED " in *" $w "*) WAVES="${WAVES:+$WAVES }$w" ;; esac
done
[ -n "$WAVES" ] || { echo "WAVES is empty"; exit 2; }
TAG="w${WAVES// /_}"
R="v56_reports_$TAG"
O="$COP_RESULTS/$R"
NAME="cop_v56_reports_$TAG"
ZIP="$ZIP_DIR/$NAME.zip"
mkdir -p "$O"
declare -A RC
ORDER=()
step() { local name="$1"; shift; ORDER+=("$name"); echo "=== $(date '+%F %T') $name"; "$@" > "$O/$name.txt" 2>&1
         RC[$name]=$?; echo "=== $name exit ${RC[$name]}"; tail -3 "$O/$name.txt"; }
skip() { ORDER+=("$1"); RC[$1]=99; echo "=== $1 SKIPPED: $2" | tee "$O/$1.txt"; }
verdict() {   # verdict <file> [pending-step ...]
  local f="$1"; shift
  local js="{"
  for k in "${ORDER[@]}"; do js+="\"$k\": ${RC[$k]}, "; done
  js="${js%, }}"
  python - "$f" "$js" "$@" <<'PY'
import json, sys
f, rc, pending = sys.argv[1], json.loads(sys.argv[2]), sys.argv[3:]
json.dump({"steps": rc, "pending": pending, "skipped_code": 99,
           "all_passed": not pending and all(v == 0 for v in rc.values()),
           "completed_steps_passed": all(v == 0 for v in rc.values()),
           "note": "pending steps cannot report inside the archive they write; the launcher's exit status and the "
                   "verdict.json next to the reports are final"}, open(f, "w"), indent=1)
print(json.dumps(rc, indent=1))
PY
}

declare -A PANEL MULT MAN
PANEL[25]="${V46_RESULTS:-$HOME/cop_results_v46}/panel25"
PANEL[26]="${V53_RESULTS:-$HOME/cop_results_v53}/panel26"
# the compact controls are read at the expansion's end (2U); wave 26's also at 4U, where their hold is still on
MULT[25]="1"
MULT[26]="1,2"
CHANGE_FILES="coverage.json,states.csv,states_by_draw.csv,states_summary.csv,edits.csv,edits_by_draw.csv,edits_summary.csv,probes.csv,probes_by_draw.csv,probes_summary.csv,contrasts.csv,contrasts_by_draw.csv,contrasts_summary.csv"
COURSE_FILES="coverage.json,states.csv,states_by_draw.csv,states_summary.csv,probes.csv,probes_by_draw.csv,probes_summary.csv,contrasts.csv,contrasts_by_draw.csv,contrasts_summary.csv"
ROUTING_FILES="coverage.json,checkpoints.csv,checkpoints_by_draw.csv,checkpoints_summary.csv,updates.csv,updates_by_draw.csv,updates_summary.csv"
# checked as evidence but archived only when small: the per-row probe and contrast tables (kept on disk)
LARGE="probes.csv contrasts.csv"

step environment cop inspect-environment --no-cuda --out "$O/environment.json"
# each panel: complete, same semantics (checked job by job), read only
SOURCES=1
for w in $WAVES; do
  MAN[$w]="$COP_HOME/manifests/wave${w}_${SCALE}.jsonl"
  rm -f "${MAN[$w]}"          # a failed generation must not fall through to a stale manifest
  step "manifest$w" cop generate-manifest --wave "$w" --scale "$SCALE" --out "${MAN[$w]}"
  if [ "${RC[manifest$w]}" = 0 ] && [ -s "${MAN[$w]}" ]; then
    step "panel_source$w" python scripts/panel_state.py "${MAN[$w]}" "${PANEL[$w]}"
  else
    skip "panel_source$w" "the wave-$w manifest was not generated (see manifest$w)"
  fi
  [ "${RC[panel_source$w]}" = 0 ] || SOURCES=0
done
# the tests run once, when every requested panel is there (nothing is analysed without them)
if [ "$SOURCES" = 1 ] && [ "${RC[environment]}" = 0 ]; then
  step cpu_tests env CUDA_VISIBLE_DEVICES="" DEVICE=cpu $COP_PYTEST -q -rs tests/ -p no:cacheprovider \
      --junitxml "$O/cpu_tests.xml"
else
  skip cpu_tests "the environment check failed or a requested panel is not complete (see panel_source*)"
fi
rm -f "${O:?}"/change2[56]_* "${O:?}"/course2[56]_* "${O:?}"/routing2[56]_* "${O:?}/evidence.json"
PROBES="$COP_RESULTS/probes_$TAG"
rm -rf "${PROBES:?}"                       # a probe file from an earlier attempt is never this attempt's
EV=()
for w in $WAVES; do
  if [ "${RC[cpu_tests]}" = 0 ] && [ "${RC[panel_source$w]}" = 0 ]; then
    step "change$w" python audit_v5/tools/component_change.py "${PANEL[$w]}" "$O/change$w" \
        --data-root "$COP_DATA_ROOT" --manifest "${MAN[$w]}" --strict --device cpu \
        --compact-multiples "${MULT[$w]}" --save-probes "$PROBES/wave$w"
  else
    skip "change$w" "the manifest, the panel source or the tests failed"
  fi
  if [ "${RC[cpu_tests]}" = 0 ] && [ "${RC[panel_source$w]}" = 0 ]; then
    step "course$w" python audit_v5/tools/layer_course.py "${PANEL[$w]}" "$O/course$w" \
        --data-root "$COP_DATA_ROOT" --manifest "${MAN[$w]}" --strict --device cpu \
        --compact-multiples "${MULT[$w]}"
    step "routing$w" python audit_v5/tools/routing_updates.py "${PANEL[$w]}" "$O/routing$w" \
        --data-root "$COP_DATA_ROOT" --manifest "${MAN[$w]}" --strict --device cpu
  else
    skip "course$w" "the manifest, the panel source or the tests failed"
    skip "routing$w" "the manifest, the panel source or the tests failed"
  fi
  EV+=("change$w:${RC[change$w]}:$O/change$w:$CHANGE_FILES" "course$w:${RC[course$w]}:$O/course$w:$COURSE_FILES"
       "routing$w:${RC[routing$w]}:$O/routing$w:$ROUTING_FILES")
done
step evidence python scripts/check_evidence.py "$O/evidence.json" "${EV[@]}"
for w in $WAVES; do
  if [ -s "${MAN[$w]}" ]; then step "manifest_copy$w" cp "${MAN[$w]}" "$O/"; else skip "manifest_copy$w" "no manifest"; fi
done

# packaging: the archive carries the verdict of every step before it (packaging pending), is verified, then the
# external verdict is final; the archive is rewritten with that final verdict and verified again
verdict "$O/verdict.json" package package_final
REQ=(--require "$R/verdict_steps.txt")
for k in "${ORDER[@]}"; do REQ+=(--require "$R/$k.txt"); done
[ -f "$O/evidence.json" ] && REQ+=(--require "$R/evidence.json")
if [ "${RC[evidence]}" = 0 ]; then
  for w in $WAVES; do
    for t in change:$CHANGE_FILES course:$COURSE_FILES routing:$ROUTING_FILES; do
      [ "${RC[${t%%:*}$w]}" = 0 ] || continue
      for f in $(echo "${t#*:}" | tr ',' ' '); do
        case " $LARGE " in *" $f "*) [ "${t%%:*}" = routing ] || continue ;; esac
        REQ+=(--require "$R/${t%%:*}${w}_$f")
      done
    done
  done
fi
printf '%s\n' "${ORDER[@]}" > "$O/verdict_steps.txt"
step package python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" "$NAME" \
    --include "$R" "${REQ[@]}"
verdict "$O/verdict.json" package_final
if [ "${RC[package]}" = 0 ]; then
  step package_final python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" \
      "$NAME" --include "$R" "${REQ[@]}"
else
  skip package_final "packaging failed"
  rm -f "$ZIP"
fi
verdict "$O/verdict.json"
[ -f "$ZIP" ] || { echo "no archive at $ZIP"; RC[archive_present]=1; ORDER+=(archive_present); verdict "$O/verdict.json"; }
python -c "import json,sys; sys.exit(0 if json.load(open('$O/verdict.json'))['all_passed'] else 1)"
