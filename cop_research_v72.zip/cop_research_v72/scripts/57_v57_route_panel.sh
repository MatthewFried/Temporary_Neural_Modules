#!/usr/bin/env bash
# v57: which part of routing produces the first-layer change?  A training panel (wave 27; semantics cop-7.21.0,
# unchanged): wave 26's draws, f0 and protocol, with relu additions under three routes:
#   routed  the gradient route of waves 25 and 26 (a masked example's gradient does not enter the addition)
#   param   NEW: the parameter route (only the additions' parameters are masked; every example's gradient still
#           reaches the backbone through both additions)
#   all     no routing
# each with nothing held (A) and with the shortcut column held (B), and the compact controls compact_A, compact_B.
# 360 jobs, of which 96 are new (the param arms and their removals).  The other 264 are wave 26's own jobs (same run
# ids): when the finished v53 panel is on this machine they are COPIED into this panel's folder instead of being
# trained again (scripts/seed_panel.py; the v53 folder is only read).  SEED=0 trains everything.
#
#   seed27      copy wave 26's finished runs that this manifest shares
#   run27       train what is left (GPU)
#   status27, checks27, reload27, summary27, rates27   as in v53 (every job, copied or new, is reloaded and checked)
#   reversal27  audit_v5/tools/selective_reversal.py with the wave27 registry (extraction; the route contrasts)
#   change27    audit_v5/tools/component_change.py   first layers, controls, probes at 2U
#   course27    audit_v5/tools/layer_course.py       probes at every layer and saved age
#   routing27   audit_v5/tools/routing_updates.py    the last update against ordinary and routed gradients
# The four analyses run on the CPU.  It writes ~/cop_results_v57 only.
#
#   cd ~/research/cop_research_v57 && WORKERS=3 COP_VENV=~/fsc/.venv nohup bash scripts/57_v57_route_panel.sh > ~/v57.log 2>&1 &
#
# Zip: cop_v57_panel_reports.zip.  A stopped run is continued by running the same command again.
export COP_HOME="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export SCALE="${SCALE:-full}"
export COP_RESULTS="${COP_RESULTS:-$HOME/cop_results_v57}"
source "$(dirname "$0")/common.sh"
set +e
set +u
ZIP_DIR="${ZIP_DIR:-/mnt/c/Users/Matthew Fried/Downloads}"
[ -d "$ZIP_DIR" ] || ZIP_DIR="$HOME"
COP_PYTEST="${COP_PYTEST:-python -m pytest}"
O="$COP_RESULTS/v57_reports"
P="$COP_RESULTS/panel27"
ZIP="$ZIP_DIR/cop_v57_panel_reports.zip"
mkdir -p "$O" "$P"
declare -A RC
ORDER=()
step() { local name="$1"; shift; ORDER+=("$name"); echo "=== $(date '+%F %T') $name"; "$@" > "$O/$name.txt" 2>&1
         RC[$name]=$?; echo "=== $name exit ${RC[$name]}"; tail -3 "$O/$name.txt"; }
skip() { ORDER+=("$1"); RC[$1]=99; echo "=== $1 SKIPPED: $2" | tee "$O/$1.txt"; }
verdict() {   # verdict <file> [pending-step ...]
  local f="$1"; shift
  local js="{"
  for k in "${ORDER[@]}"; do js+="\"$k\": ${RC[$k]}, "; done
  js="${js%, }}"
  python - "$f" "$js" "$@" <<'PY'
import json, sys
f, rc, pending = sys.argv[1], json.loads(sys.argv[2]), sys.argv[3:]
json.dump({"steps": rc, "pending": pending, "skipped_code": 99,
           "all_passed": not pending and all(v == 0 for v in rc.values()),
           "completed_steps_passed": all(v == 0 for v in rc.values()),
           "note": "pending steps cannot report inside the archive they write; the launcher's exit status and the "
                   "verdict.json next to the reports are final"}, open(f, "w"), indent=1)
print(json.dumps(rc, indent=1))
PY
}

SEED="${SEED:-1}"
SEED_FROM="${SEED_FROM:-${V53_RESULTS:-$HOME/cop_results_v53}/panel26}"

step environment cop inspect-environment --out "$O/environment.json"
m27="$COP_HOME/manifests/wave27_${SCALE}.jsonl"
rm -f "$m27"          # a failed generation must not fall through to a stale manifest
step manifest27 cop generate-manifest --wave 27 --scale "$SCALE" --out "$m27"
if [ "${RC[manifest27]}" = 0 ] && [ -s "$m27" ]; then
  step validate27 cop validate-manifest --manifest "$m27"
else
  skip validate27 "the wave-27 manifest was not generated (see manifest27)"
fi
PRE=0
[ "${RC[environment]}" = 0 ] && [ "${RC[manifest27]}" = 0 ] && [ "${RC[validate27]}" = 0 ] && PRE=1
if [ "$PRE" = 1 ]; then
  step cpu_tests env CUDA_VISIBLE_DEVICES="" DEVICE=cpu $COP_PYTEST -q -rs tests/ -p no:cacheprovider \
      --junitxml "$O/cpu_tests.xml"
else
  skip cpu_tests "the environment, the manifest or its validation failed"
fi
# on a CUDA device every CUDA test of the training code must RUN and pass (pytest exits 0 when a test is skipped, so
# the junit report is checked: tests ran, none skipped)
case "$DEVICE" in cuda|cuda:*) IS_CUDA=1 ;; *) IS_CUDA=0 ;; esac
rm -f "${O:?}/cuda_tests.xml" "${O:?}/seed27.json"      # an earlier attempt's records are never this attempt's
READY=0
[ "$PRE" = 1 ] && [ "${RC[cpu_tests]}" = 0 ] && READY=1
if [ "$READY" = 1 ] && [ "$IS_CUDA" = 1 ]; then
  step cuda_tests env DEVICE="$DEVICE" COP_TEST_CUDA_DEVICE="$DEVICE" $COP_PYTEST -q -rs tests/ \
      -k "cuda or gpu_equivalence" --ignore tests/test_v53.py -p no:cacheprovider --junitxml "$O/cuda_tests.xml"
  step cuda_tests_ran python scripts/junit_ran.py "$O/cuda_tests.xml"
  for k in cuda_tests cuda_tests_ran; do [ "${RC[$k]}" = 0 ] || READY=0; done
fi

if [ "$READY" = 1 ] || [ "${DIAGNOSTIC_OVERRIDE:-0}" = 1 ]; then
  [ "$READY" = 1 ] || echo "DIAGNOSTIC_OVERRIDE=1: running the panel after a failed prerequisite" | tee "$O/override.txt"
  # wave 26's finished runs that this manifest shares are copied in (read from the v53 panel, never written to it)
  if [ "$SEED" = 1 ]; then
    step seed27 python scripts/seed_panel.py "$m27" "$SEED_FROM" "$P" "$O/seed27.json"
  else
    skip seed27 "SEED=0: every job is trained here"
    RC[seed27]=0
  fi
  if [ "${RC[seed27]}" = 0 ]; then
    step run27 cop run --manifest "$m27" --results "$P" --device "$DEVICE" --data-root "$COP_DATA_ROOT" \
        --workers "$WORKERS" --threads "$THREADS" --resume
  else
    skip run27 "copying wave 26's runs failed (see seed27); run again, or set SEED=0 to train everything"
  fi
else
  skip seed27 "a prerequisite failed"
  skip run27 "a prerequisite failed (environment, manifest, validation or tests); set DIAGNOSTIC_OVERRIDE=1 to run anyway"
fi
LT_FILES="coverage.json,checks.csv,codes.csv,codes_summary.csv,codes_by_draw.csv,codes_implants.csv,codes_implants_summary.csv,codes_implants_by_draw.csv,codes_implants_contrasts.csv,codes_implants_contrasts_by_draw.csv,contrasts.csv,decomposition_summary.csv,decomposition_trace.csv,native_summary.csv,trace.csv,registry_by_setting.csv,registry_by_draw.csv,registry_summary.csv,compact_fork_audit.csv,compute.csv,compute_summary.csv,paired_streams.csv,extraction_2u.csv,extraction_2u_by_setting.csv,extraction_2u_by_draw.csv,extraction_2u_summary.csv"
CHANGE_FILES="coverage.json,states.csv,states_by_draw.csv,states_summary.csv,edits.csv,edits_by_draw.csv,edits_summary.csv,probes.csv,probes_by_draw.csv,probes_summary.csv,contrasts.csv,contrasts_by_draw.csv,contrasts_summary.csv"
COURSE_FILES="coverage.json,states.csv,states_by_draw.csv,states_summary.csv,probes.csv,probes_by_draw.csv,probes_summary.csv,contrasts.csv,contrasts_by_draw.csv,contrasts_summary.csv"
ROUTING_FILES="coverage.json,checkpoints.csv,checkpoints_by_draw.csv,checkpoints_summary.csv,updates.csv,updates_by_draw.csv,updates_summary.csv"
# checked as evidence but archived only when small: the per-row probe and contrast tables (kept on disk)
LARGE="probes.csv contrasts.csv"
# arms of one f0 share the minibatch stream and differ in these settings only (and in the hold)
PAIRED_VARY="growth.spec_mask_route,growth.spec_partition"
# at the checkpoints away from 2U: the state itself, the extraction (its first layer in f0) and f0
TRACE_CODES="0-0-0-0-0,0-1-1-1-1,1-1-1-1-1"
# the primary arm of this panel in the component analysis: the held-shortcut parameter-route arm
PRIMARY="B_param_relu"
ANALYSES="reversal27 change27 course27 routing27"
rm -f "${O:?}"/reversal27_* "${O:?}"/change27_* "${O:?}"/course27_* "${O:?}"/routing27_*
PROBES="${COP_RESULTS:?}/probes27"
rm -rf "${PROBES:?}"                       # a probe file from an earlier attempt is never this attempt's
# when the panel did not run, every step that reads its results is skipped; when it ran but did not finish, only its
# status is reported (which jobs failed), since every analysis needs the complete panel
if [ "${RC[run27]}" = 99 ]; then
  for k in status27 checks27 reload27 summary27 rates27 $ANALYSES; do
    skip "$k" "the training panel was skipped (see run27)"
  done
elif [ "${RC[run27]}" != 0 ]; then
  step status27 cop status --manifest "$m27" --results "$P"
  for k in checks27 reload27 summary27 rates27 $ANALYSES; do
    skip "$k" "the training panel did not finish (see run27 and status27); run the same command again to continue"
  done
else
  step status27 cop status --manifest "$m27" --results "$P"
  step checks27 python audit_v8/tools/check_results.py "$P" "$O/checks27.json" --manifest "$m27" \
      --transplants-if-any --diagnostics-if-any
  step reload27 python audit_v5/tools/fresh_reload.py "$P" "$O/fresh_reload27.json" --device recorded \
      --data-root "$COP_DATA_ROOT"
  step summary27 cop summarize --strict --results "$P" --manifest "$m27" --out "$COP_RESULTS/summary27"
  step rates27 python audit_v5/tools/runtime_v13.py fit "$m27" "$P" "$O/rates27.json"
  step reversal27 python audit_v5/tools/selective_reversal.py "$P" "$O/reversal27" --data-root "$COP_DATA_ROOT" \
      --manifest "$m27" --strict --codes auto --trace --trace-codes "$TRACE_CODES" --codes-at-2u --implant-codes \
      --decompose --paired-streams --paired-vary "$PAIRED_VARY" --contrasts wave27
  step change27 env CUDA_VISIBLE_DEVICES="" python audit_v5/tools/component_change.py "$P" "$O/change27" \
      --data-root "$COP_DATA_ROOT" --manifest "$m27" --strict --device cpu --compact-multiples 1,2 \
      --save-probes "$PROBES" --primary-variants "$PRIMARY"
  step course27 env CUDA_VISIBLE_DEVICES="" python audit_v5/tools/layer_course.py "$P" "$O/course27" \
      --data-root "$COP_DATA_ROOT" --manifest "$m27" --strict --device cpu --compact-multiples 1,2
  step routing27 env CUDA_VISIBLE_DEVICES="" python audit_v5/tools/routing_updates.py "$P" "$O/routing27" \
      --data-root "$COP_DATA_ROOT" --manifest "$m27" --strict --device cpu
fi
rm -f "${O:?}/evidence27.json"
step evidence27 python scripts/check_evidence.py "$O/evidence27.json" \
    "reversal27:${RC[reversal27]}:$O/reversal27:$LT_FILES" \
    "change27:${RC[change27]}:$O/change27:$CHANGE_FILES" \
    "course27:${RC[course27]}:$O/course27:$COURSE_FILES" \
    "routing27:${RC[routing27]}:$O/routing27:$ROUTING_FILES"
if [ -s "$m27" ]; then step manifest_copy cp "$m27" "$O/"; else skip manifest_copy "no manifest"; fi

# packaging: the archive carries the verdict of every step before it (packaging pending), is verified, then the
# external verdict is final; the archive is rewritten with that final verdict and verified again
verdict "$O/verdict.json" package package_final
REQ=(--require "v57_reports/verdict_steps.txt")
for k in "${ORDER[@]}"; do REQ+=(--require "v57_reports/$k.txt"); done
[ "${RC[seed27]}" = 0 ] && [ -f "$O/seed27.json" ] && REQ+=(--require "v57_reports/seed27.json")
[ "${RC[checks27]}" = 0 ] && REQ+=(--require "v57_reports/checks27.json")
[ "${RC[reload27]}" = 0 ] && REQ+=(--require "v57_reports/fresh_reload27.json")
[ "${RC[manifest_copy]}" = 0 ] && REQ+=(--require "v57_reports/$(basename "$m27")")
[ -f "$O/evidence27.json" ] && REQ+=(--require "v57_reports/evidence27.json")
if [ "${RC[evidence27]}" = 0 ]; then
  for t in reversal27:$LT_FILES change27:$CHANGE_FILES course27:$COURSE_FILES routing27:$ROUTING_FILES; do
    [ "${RC[${t%%:*}]}" = 0 ] || continue
    for f in $(echo "${t#*:}" | tr ',' ' '); do
      case "${t%%:*}" in change27|course27) case " $LARGE " in *" $f "*) continue ;; esac ;; esac
      REQ+=(--require "v57_reports/${t%%:*}_$f")
    done
  done
fi
INC=(--include v57_reports)
[ -d "$COP_RESULTS/summary27" ] && INC+=(--include summary27)
printf '%s\n' "${ORDER[@]}" > "$O/verdict_steps.txt"
step package python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" cop_v57_panel_reports \
    "${INC[@]}" "${REQ[@]}"
verdict "$O/verdict.json" package_final
if [ "${RC[package]}" = 0 ]; then
  step package_final python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" \
      cop_v57_panel_reports "${INC[@]}" "${REQ[@]}"
else
  skip package_final "packaging failed"
  rm -f "$ZIP"
fi
verdict "$O/verdict.json"
[ -f "$ZIP" ] || { echo "no archive at $ZIP"; RC[archive_present]=1; ORDER+=(archive_present); verdict "$O/verdict.json"; }
python -c "import json,sys; sys.exit(0 if json.load(open('$O/verdict.json'))['all_passed'] else 1)"
