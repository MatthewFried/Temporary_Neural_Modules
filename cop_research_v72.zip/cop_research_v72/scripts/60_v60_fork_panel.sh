#!/usr/bin/env bash
# v60: the wave-28 fork panel (five continuations, CHANGES_v59.md) with the reuse verification gating training, a
# saved after-fold checkpoint audited against the expected composition, and tightened fork audits (CHANGES_v60.md).
# Semantics cop-7.21.0 (run ids unchanged); semantic code hash in configs/reuse_audits.json.
#  1. A training panel (wave 28): from wave 26's routed AFFINE trajectories (A: nothing held; B: shortcut column held),
#     at two saved states (snap_1000, snap_2500), five continuations of the same network to 2U:
#       routed_reset    routing continues, fresh optimizer
#       ordinary_reset  additions trained on with every example's gradient (masks released)
#       frozen_reset    frozen affine scaffold, ordinary gradients (additions fixed, backbone trained through them)
#       folded_reset    additions folded exactly into layer 3 and removed, the compact network trained directly
#       routed_carry    routing continues with the parent's optimizer state
#     552 jobs.  Earlier runs are COPIED under the audits in configs/reuse_audits.json (scripts/seed_panel.py
#     --audited), newest first: the v59 panel, the v58 panel, the v53 panel; every source is only read.  Folded forks
#     are never copied (the method changed).  Then every audited copy in the panel, whenever it was copied, is
#     verified: a sample covering every class of audited run is retrained from scratch and every checkpoint must
#     match section by section (scripts/reuse_reproduce.py).  The panel trains only when that verification passed
#     or there is no audited copy at all; otherwise the diagnostics are packaged and nothing is trained.
#     SEED=0 stops this attempt from copying anything.  It does not remove copies an earlier attempt made (they are
#     kept, verified and used, since the runner resumes); a genuinely fresh panel needs a fresh results folder:
#       COP_RESULTS=~/cop_results_v60_fresh SEED=0 ... bash scripts/60_v60_fork_panel.sh
#     Nothing here deletes earlier results.
#  2. Two CPU analyses:
#       fork28      audit_v5/tools/fork_continuation.py on this panel: per-fork audits, named contrasts
#       geometry26  audit_v5/tools/merge_geometry.py on the v53 wave-26 panel (read-only): exact merge maps, whitening
#                   comparability, the transport certificate
# It writes ~/cop_results_v60 only.
#
#   cd ~/research/cop_research_v60 && WORKERS=3 COP_VENV=~/fsc/.venv nohup bash scripts/60_v60_fork_panel.sh > ~/v60.log 2>&1 &
#
# Zip: cop_v60_panel_reports.zip.  A stopped run is continued by running the same command again.
export COP_HOME="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export SCALE="${SCALE:-full}"
export COP_RESULTS="${COP_RESULTS:-$HOME/cop_results_v60}"
source "$(dirname "$0")/common.sh"
set +e
set +u
ZIP_DIR="${ZIP_DIR:-/mnt/c/Users/Matthew Fried/Downloads}"
[ -d "$ZIP_DIR" ] || ZIP_DIR="$HOME"
COP_PYTEST="${COP_PYTEST:-python -m pytest}"
O="$COP_RESULTS/v60_reports"
P="$COP_RESULTS/panel28"
ZIP="$ZIP_DIR/cop_v60_panel_reports.zip"
mkdir -p "$O" "$P"
declare -A RC
ORDER=()
step() { local name="$1"; shift; ORDER+=("$name"); echo "=== $(date '+%F %T') $name"; "$@" > "$O/$name.txt" 2>&1
         RC[$name]=$?; echo "=== $name exit ${RC[$name]}"; tail -3 "$O/$name.txt"; }
skip() { ORDER+=("$1"); RC[$1]=99; echo "=== $1 SKIPPED: $2" | tee "$O/$1.txt"; }
verdict() {   # verdict <file> [pending-step ...]
  local f="$1"; shift
  local js="{"
  for k in "${ORDER[@]}"; do js+="\"$k\": ${RC[$k]}, "; done
  js="${js%, }}"
  python - "$f" "$js" "$@" <<'PY'
import json, sys
f, rc, pending = sys.argv[1], json.loads(sys.argv[2]), sys.argv[3:]
json.dump({"steps": rc, "pending": pending, "skipped_code": 99,
           "all_passed": not pending and all(v == 0 for v in rc.values()),
           "completed_steps_passed": all(v == 0 for v in rc.values()),
           "note": "pending steps cannot report inside the archive they write; the launcher's exit status and the "
                   "verdict.json next to the reports are final"}, open(f, "w"), indent=1)
print(json.dumps(rc, indent=1))
PY
}

SEED="${SEED:-1}"
SEED_FROM="${SEED_FROM:-${V53_RESULTS:-$HOME/cop_results_v53}/panel26}"
SEED_FROM58="${SEED_FROM58:-${V58_RESULTS:-$HOME/cop_results_v58}/panel28}"
SEED_FROM59="${SEED_FROM59:-${V59_RESULTS:-$HOME/cop_results_v59}/panel28}"
AUDITS="$COP_HOME/configs/reuse_audits.json"

step environment cop inspect-environment --out "$O/environment.json"
m28="$COP_HOME/manifests/wave28_${SCALE}.jsonl"
rm -f "$m28"          # a failed generation must not fall through to a stale manifest
step manifest28 cop generate-manifest --wave 28 --scale "$SCALE" --out "$m28"
if [ "${RC[manifest28]}" = 0 ] && [ -s "$m28" ]; then
  step validate28 cop validate-manifest --manifest "$m28"
else
  skip validate28 "the wave-28 manifest was not generated (see manifest28)"
fi
PRE=0
[ "${RC[environment]}" = 0 ] && [ "${RC[manifest28]}" = 0 ] && [ "${RC[validate28]}" = 0 ] && PRE=1
if [ "$PRE" = 1 ]; then
  step cpu_tests env CUDA_VISIBLE_DEVICES="" DEVICE=cpu $COP_PYTEST -q -rs tests/ -p no:cacheprovider \
      --junitxml "$O/cpu_tests.xml"
else
  skip cpu_tests "the environment, the manifest or its validation failed"
fi
# on a CUDA device every CUDA test of the training code must RUN and pass (pytest exits 0 when a test is skipped, so
# the junit report is checked: tests ran, none skipped)
case "$DEVICE" in cuda|cuda:*) IS_CUDA=1 ;; *) IS_CUDA=0 ;; esac
rm -f "${O:?}/cuda_tests.xml" "${O:?}"/seed28*.json "${O:?}/reuse_check.json" "${O:?}/reuse_sample.jsonl"      # an earlier attempt's records are never this attempt's
READY=0
[ "$PRE" = 1 ] && [ "${RC[cpu_tests]}" = 0 ] && READY=1
if [ "$READY" = 1 ] && [ "$IS_CUDA" = 1 ]; then
  step cuda_tests env DEVICE="$DEVICE" COP_TEST_CUDA_DEVICE="$DEVICE" $COP_PYTEST -q -rs tests/ \
      -k "cuda or gpu_equivalence" --ignore tests/test_v53.py -p no:cacheprovider --junitxml "$O/cuda_tests.xml"
  step cuda_tests_ran python scripts/junit_ran.py "$O/cuda_tests.xml"
  for k in cuda_tests cuda_tests_ran; do [ "${RC[$k]}" = 0 ] || READY=0; done
fi

if [ "$READY" = 1 ] || [ "${DIAGNOSTIC_OVERRIDE:-0}" = 1 ]; then
  [ "$READY" = 1 ] || echo "DIAGNOSTIC_OVERRIDE=1: running the panel after a failed prerequisite" | tee "$O/override.txt"
  # finished runs this manifest shares are copied in under the audits (newest panel first); sources are only read
  if [ "$SEED" = 1 ]; then
    step seed28_v59 python scripts/seed_panel.py "$m28" "$SEED_FROM59" "$P" "$O/seed28_v59.json" --audited "$AUDITS"
    step seed28_v58 python scripts/seed_panel.py "$m28" "$SEED_FROM58" "$P" "$O/seed28_v58.json" --audited "$AUDITS"
    step seed28 python scripts/seed_panel.py "$m28" "$SEED_FROM" "$P" "$O/seed28.json" --audited "$AUDITS"
    [ "${RC[seed28_v59]}" = 0 ] && [ "${RC[seed28_v58]}" = 0 ] || RC[seed28]=1
  else
    for k in seed28_v59 seed28_v58 seed28; do skip "$k" "SEED=0: nothing is copied in this attempt"; RC[$k]=0; done
  fi
  # the verification of every audited copy in the panel (this attempt's or an earlier one's): a sample retrained
  # from scratch in its own folder; training waits for it
  RS="$COP_RESULTS/reuse_check"
  VERIFIED=0
  if [ "${RC[seed28]}" = 0 ]; then
    step reuse_select python scripts/reuse_reproduce.py select "$m28" "$P" "$O/reuse_sample.jsonl"
    if [ "${RC[reuse_select]}" = 5 ]; then
      RC[reuse_select]=0
      skip reuse_run "the panel holds no audited copy: nothing to verify"; RC[reuse_run]=0
      skip reuse_compare "the panel holds no audited copy: nothing to verify"; RC[reuse_compare]=0
      VERIFIED=1
    elif [ "${RC[reuse_select]}" = 0 ]; then
      step reuse_run cop run --manifest "$O/reuse_sample.jsonl" --results "$RS" --device "$DEVICE" \
          --data-root "$COP_DATA_ROOT" --workers "$WORKERS" --threads "$THREADS" --resume
      if [ "${RC[reuse_run]}" = 0 ]; then
        step reuse_compare python scripts/reuse_reproduce.py compare "$O/reuse_sample.jsonl" "$P" "$RS" \
            "$O/reuse_check.json"
        [ "${RC[reuse_compare]}" = 0 ] && VERIFIED=1
      else
        skip reuse_compare "the sample did not retrain (see reuse_run)"
      fi
    else
      skip reuse_run "the sample could not be selected (see reuse_select)"
      skip reuse_compare "the sample could not be selected (see reuse_select)"
    fi
  else
    for k in reuse_select reuse_run reuse_compare; do skip "$k" "copying failed (see seed28_v59, seed28_v58, seed28)"; done
  fi
  if [ "${RC[seed28]}" != 0 ]; then
    skip run28 "copying earlier runs failed (see seed28_v59, seed28_v58, seed28); run again, or use a fresh results folder with SEED=0"
  elif [ "$VERIFIED" != 1 ]; then
    skip run28 "the reuse verification did not pass (see reuse_select, reuse_run, reuse_compare): nothing that descends from the copies is trained"
  else
    step run28 cop run --manifest "$m28" --results "$P" --device "$DEVICE" --data-root "$COP_DATA_ROOT" \
        --workers "$WORKERS" --threads "$THREADS" --resume
  fi
else
  skip seed28_v59 "a prerequisite failed"
  skip seed28_v58 "a prerequisite failed"
  skip seed28 "a prerequisite failed"
  for k in reuse_select reuse_run reuse_compare; do skip "$k" "a prerequisite failed"; done
  skip run28 "a prerequisite failed (environment, manifest, validation or tests); set DIAGNOSTIC_OVERRIDE=1 to run anyway"
fi
FORK_FILES="coverage.json,audits.csv,states.csv,states_by_draw.csv,states_summary.csv,contrasts.csv,contrasts_by_draw.csv,contrasts_summary.csv"
GEOM_FILES="coverage.json,whitening_coverage.csv,maps.csv,maps_by_draw.csv,maps_summary.csv,transport.csv,transport_by_draw.csv,transport_summary.csv,probes.csv,probes_by_draw.csv,probes_summary.csv,contrasts.csv,contrasts_by_draw.csv,contrasts_summary.csv"
# checked as evidence but archived only when small (kept on disk)
LARGE="probes.csv contrasts.csv"
GEOM_PANEL="${V53_RESULTS:-$HOME/cop_results_v53}/panel26"
rm -f "${O:?}"/fork28_* "${O:?}"/geometry26_*
# the wave-26 panel the geometry analysis reads: complete and of these semantics (read only)
m26="$COP_HOME/manifests/wave26_${SCALE}.jsonl"
rm -f "$m26"
if [ "$PRE" = 1 ]; then
  step manifest26 cop generate-manifest --wave 26 --scale "$SCALE" --out "$m26"
  if [ "${RC[manifest26]}" = 0 ] && [ -s "$m26" ]; then
    step panel_source26 python scripts/panel_state.py "$m26" "$GEOM_PANEL" --audited "$AUDITS"
  else
    skip panel_source26 "the wave-26 manifest was not generated (see manifest26)"
  fi
else
  skip manifest26 "a prerequisite failed"
  skip panel_source26 "a prerequisite failed"
fi
if [ "$READY" = 1 ] && [ "${RC[panel_source26]}" = 0 ]; then
  step geometry26 env CUDA_VISIBLE_DEVICES="" python audit_v5/tools/merge_geometry.py "$GEOM_PANEL" \
      "$O/geometry26" --data-root "$COP_DATA_ROOT" --manifest "$m26" --strict --device cpu
else
  skip geometry26 "the tests or the wave-26 panel source failed (see cpu_tests, panel_source26)"
fi
# when the panel did not run, every step that reads its results is skipped; when it ran but did not finish, only its
# status is reported (which jobs failed), since the analysis needs the complete panel
if [ "${RC[run28]}" = 99 ]; then
  for k in status28 checks28 reload28 summary28 rates28 fork28; do
    skip "$k" "the training panel was skipped (see run28)"
  done
elif [ "${RC[run28]}" != 0 ]; then
  step status28 cop status --manifest "$m28" --results "$P"
  for k in checks28 reload28 summary28 rates28 fork28; do
    skip "$k" "the training panel did not finish (see run28 and status28); run the same command again to continue"
  done
else
  step status28 cop status --manifest "$m28" --results "$P"
  step checks28 python audit_v8/tools/check_results.py "$P" "$O/checks28.json" --manifest "$m28" \
      --transplants-if-any --diagnostics-if-any
  step reload28 python audit_v5/tools/fresh_reload.py "$P" "$O/fresh_reload28.json" --device recorded \
      --data-root "$COP_DATA_ROOT"
  step summary28 cop summarize --strict --results "$P" --manifest "$m28" --out "$COP_RESULTS/summary28"
  step rates28 python audit_v5/tools/runtime_v13.py fit "$m28" "$P" "$O/rates28.json"
  step fork28 env CUDA_VISIBLE_DEVICES="" python audit_v5/tools/fork_continuation.py "$P" "$O/fork28" \
      --data-root "$COP_DATA_ROOT" --manifest "$m28" --strict --device cpu
fi
rm -f "${O:?}/evidence28.json"
step evidence28 python scripts/check_evidence.py "$O/evidence28.json" \
    "fork28:${RC[fork28]}:$O/fork28:$FORK_FILES" \
    "geometry26:${RC[geometry26]}:$O/geometry26:$GEOM_FILES"
if [ -s "$m28" ]; then step manifest_copy cp "$m28" "$O/"; else skip manifest_copy "no manifest"; fi
if [ -s "$m26" ]; then step manifest_copy26 cp "$m26" "$O/"; else skip manifest_copy26 "no wave-26 manifest"; fi

# packaging: the archive carries the verdict of every step before it (packaging pending), is verified, then the
# external verdict is final; the archive is rewritten with that final verdict and verified again
verdict "$O/verdict.json" package package_final
REQ=(--require "v60_reports/verdict_steps.txt")
for k in "${ORDER[@]}"; do REQ+=(--require "v60_reports/$k.txt"); done
[ "${RC[seed28]}" = 0 ] && [ -f "$O/seed28.json" ] && REQ+=(--require "v60_reports/seed28.json")
[ "${RC[seed28_v58]}" = 0 ] && [ -f "$O/seed28_v58.json" ] && REQ+=(--require "v60_reports/seed28_v58.json")
[ "${RC[seed28_v59]}" = 0 ] && [ -f "$O/seed28_v59.json" ] && REQ+=(--require "v60_reports/seed28_v59.json")
[ -f "$O/reuse_sample.jsonl" ] && REQ+=(--require "v60_reports/reuse_sample.jsonl")
[ -f "$O/reuse_check.json" ] && REQ+=(--require "v60_reports/reuse_check.json")
[ "${RC[checks28]}" = 0 ] && REQ+=(--require "v60_reports/checks28.json")
[ "${RC[reload28]}" = 0 ] && REQ+=(--require "v60_reports/fresh_reload28.json")
[ "${RC[manifest_copy]}" = 0 ] && REQ+=(--require "v60_reports/$(basename "$m28")")
[ "${RC[manifest_copy26]}" = 0 ] && REQ+=(--require "v60_reports/$(basename "$m26")")
[ -f "$O/evidence28.json" ] && REQ+=(--require "v60_reports/evidence28.json")
if [ "${RC[evidence28]}" = 0 ]; then
  for t in fork28:$FORK_FILES geometry26:$GEOM_FILES; do
    [ "${RC[${t%%:*}]}" = 0 ] || continue
    for f in $(echo "${t#*:}" | tr ',' ' '); do
      case " $LARGE " in *" $f "*) continue ;; esac
      REQ+=(--require "v60_reports/${t%%:*}_$f")
    done
  done
fi
INC=(--include v60_reports)
[ -d "$COP_RESULTS/summary28" ] && INC+=(--include summary28)
printf '%s\n' "${ORDER[@]}" > "$O/verdict_steps.txt"
step package python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" cop_v60_panel_reports \
    "${INC[@]}" "${REQ[@]}"
verdict "$O/verdict.json" package_final
if [ "${RC[package]}" = 0 ]; then
  step package_final python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" \
      cop_v60_panel_reports "${INC[@]}" "${REQ[@]}"
else
  skip package_final "packaging failed"
  rm -f "$ZIP"
fi
verdict "$O/verdict.json"
[ -f "$ZIP" ] || { echo "no archive at $ZIP"; RC[archive_present]=1; ORDER+=(archive_present); verdict "$O/verdict.json"; }
python -c "import json,sys; sys.exit(0 if json.load(open('$O/verdict.json'))['all_passed'] else 1)"
