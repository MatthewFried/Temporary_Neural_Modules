#!/usr/bin/env bash
# v61: analysis only (CHANGES_v61.md).  Trains nothing.  Reads the v60 wave-28 panel (~/cop_results_v60/panel28) and
# the v53 wave-26 panel (~/cop_results_v53/panel26), both only read, and writes ~/cop_results_v61:
#   fork28      audit_v5/tools/fork_continuation.py on the v60 panel: the fold check split into algebra (float64),
#               storage (the saved float32 fold in float64) and float32 forward rounding (here and, on a CUDA
#               machine, on the device the runs were trained on); the central paired table (complete network, raw
#               and normalised extraction, against f0 and against the fork start); summaries without flagged draws
#   geometry26  audit_v5/tools/merge_geometry.py on the v53 panel: the transport certificate in float64 (decisive)
#               and float32 (v60's, reported), and the precision diagnostic (forward residual, recovered error,
#               amplification, condition number)
#   status      scripts/panel_status.py: training completion, fork validity, transport validity and analysis
#               completion, each on its own
#
#   cd ~/research/cop_research_v61 && COP_VENV=~/fsc/.venv nohup bash scripts/61_v61_reanalysis.sh > ~/v61.log 2>&1 &
#
# Zip: cop_v61_reanalysis_reports.zip.  Running it again redoes the analyses.
export COP_HOME="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export SCALE="${SCALE:-full}"
export COP_RESULTS="${COP_RESULTS:-$HOME/cop_results_v61}"
source "$(dirname "$0")/common.sh"
set +e
set +u
ZIP_DIR="${ZIP_DIR:-/mnt/c/Users/Matthew Fried/Downloads}"
[ -d "$ZIP_DIR" ] || ZIP_DIR="$HOME"
COP_PYTEST="${COP_PYTEST:-python -m pytest}"
O="$COP_RESULTS/v61_reports"
ZIP="$ZIP_DIR/cop_v61_reanalysis_reports.zip"
mkdir -p "$O"
declare -A RC
ORDER=()
step() { local name="$1"; shift; ORDER+=("$name"); echo "=== $(date '+%F %T') $name"; "$@" > "$O/$name.txt" 2>&1
         RC[$name]=$?; echo "=== $name exit ${RC[$name]}"; tail -3 "$O/$name.txt"; }
skip() { ORDER+=("$1"); RC[$1]=99; echo "=== $1 SKIPPED: $2" | tee "$O/$1.txt"; }
verdict() {   # verdict <file> [pending-step ...]
  local f="$1"; shift
  local js="{"
  for k in "${ORDER[@]}"; do js+="\"$k\": ${RC[$k]}, "; done
  js="${js%, }}"
  python - "$f" "$js" "$@" <<'PY'
import json, sys
f, rc, pending = sys.argv[1], json.loads(sys.argv[2]), sys.argv[3:]
json.dump({"steps": rc, "pending": pending, "skipped_code": 99,
           "all_passed": not pending and all(v == 0 for v in rc.values()),
           "completed_steps_passed": all(v == 0 for v in rc.values()),
           "note": "pending steps cannot report inside the archive they write; the launcher's exit status and the "
                   "verdict.json next to the reports are final"}, open(f, "w"), indent=1)
print(json.dumps(rc, indent=1))
PY
}

AUDITS="$COP_HOME/configs/reuse_audits.json"
P60="${V60_RESULTS:-$HOME/cop_results_v60}/panel28"
GEOM_PANEL="${V53_RESULTS:-$HOME/cop_results_v53}/panel26"

step environment cop inspect-environment --out "$O/environment.json"
m28="$COP_HOME/manifests/wave28_${SCALE}.jsonl"
m26="$COP_HOME/manifests/wave26_${SCALE}.jsonl"
rm -f "$m28" "$m26"   # a failed generation must not fall through to a stale manifest
step manifest28 cop generate-manifest --wave 28 --scale "$SCALE" --out "$m28"
step manifest26 cop generate-manifest --wave 26 --scale "$SCALE" --out "$m26"
for w in 28 26; do
  m="$COP_HOME/manifests/wave${w}_${SCALE}.jsonl"
  if [ "${RC[manifest$w]}" = 0 ] && [ -s "$m" ]; then
    step validate$w cop validate-manifest --manifest "$m"
  else
    skip validate$w "the wave-$w manifest was not generated (see manifest$w)"
  fi
done
PRE=0
[ "${RC[environment]}" = 0 ] && [ "${RC[validate28]}" = 0 ] && [ "${RC[validate26]}" = 0 ] && PRE=1
if [ "$PRE" = 1 ]; then
  step cpu_tests env CUDA_VISIBLE_DEVICES="" DEVICE=cpu $COP_PYTEST -q -rs tests/ -p no:cacheprovider \
      --junitxml "$O/cpu_tests.xml"
else
  skip cpu_tests "the environment, a manifest or its validation failed"
fi
READY=0
[ "$PRE" = 1 ] && [ "${RC[cpu_tests]}" = 0 ] && READY=1
# the two panels: complete, of these semantics or under the reuse audit (read only)
if [ "$PRE" = 1 ]; then
  step panel28 python scripts/panel_state.py "$m28" "$P60" --audited "$AUDITS"
  step panel_source26 python scripts/panel_state.py "$m26" "$GEOM_PANEL" --audited "$AUDITS"
else
  skip panel28 "a prerequisite failed"
  skip panel_source26 "a prerequisite failed"
fi
FORK_FILES="coverage.json,audits.csv,central.csv,states.csv,states_by_draw.csv,states_summary.csv,contrasts.csv,contrasts_by_draw.csv,contrasts_summary.csv,contrasts_summary_sensitivity.csv"
GEOM_FILES="coverage.json,whitening_coverage.csv,maps.csv,maps_by_draw.csv,maps_summary.csv,transport.csv,transport_by_draw.csv,transport_summary.csv,precision.csv,precision_by_draw.csv,precision_summary.csv,probes.csv,probes_by_draw.csv,probes_summary.csv,contrasts.csv,contrasts_by_draw.csv,contrasts_summary.csv"
# checked as evidence but archived only when small (kept on disk)
LARGE="probes.csv contrasts.csv"
rm -f "${O:?}"/fork28_* "${O:?}"/geometry26_* "${O:?}/panel_status.json"
# on a CUDA machine each saved fold is also evaluated in float32 on the device the runs were trained on
case "$DEVICE" in cuda|cuda:*) FORK_EXTRA=(--recorded-device "$DEVICE") ;; *) FORK_EXTRA=() ;; esac
if [ "$READY" = 1 ] && [ "${RC[panel28]}" = 0 ]; then
  step fork28 python audit_v5/tools/fork_continuation.py "$P60" "$O/fork28" \
      --data-root "$COP_DATA_ROOT" --manifest "$m28" --strict --device cpu "${FORK_EXTRA[@]}"
else
  skip fork28 "the tests or the v60 panel failed (see cpu_tests, panel28)"
fi
if [ "$READY" = 1 ] && [ "${RC[panel_source26]}" = 0 ]; then
  step geometry26 env CUDA_VISIBLE_DEVICES="" python audit_v5/tools/merge_geometry.py "$GEOM_PANEL" \
      "$O/geometry26" --data-root "$COP_DATA_ROOT" --manifest "$m26" --strict --device cpu
else
  skip geometry26 "the tests or the wave-26 panel source failed (see cpu_tests, panel_source26)"
fi
step status python scripts/panel_status.py "$O/panel_status.json" "$O/panel28.txt" "$O/fork28_coverage.json" \
    "$O/geometry26_coverage.json"
rm -f "${O:?}/evidence28.json"
step evidence28 python scripts/check_evidence.py "$O/evidence28.json" \
    "fork28:${RC[fork28]}:$O/fork28:$FORK_FILES" \
    "geometry26:${RC[geometry26]}:$O/geometry26:$GEOM_FILES"
if [ -s "$m28" ]; then step manifest_copy cp "$m28" "$O/"; else skip manifest_copy "no manifest"; fi
if [ -s "$m26" ]; then step manifest_copy26 cp "$m26" "$O/"; else skip manifest_copy26 "no wave-26 manifest"; fi

# packaging: the archive carries the verdict of every step before it (packaging pending), is verified, then the
# external verdict is final; the archive is rewritten with that final verdict and verified again
verdict "$O/verdict.json" package package_final
REQ=(--require "v61_reports/verdict_steps.txt")
for k in "${ORDER[@]}"; do REQ+=(--require "v61_reports/$k.txt"); done
[ "${RC[manifest_copy]}" = 0 ] && REQ+=(--require "v61_reports/$(basename "$m28")")
[ "${RC[manifest_copy26]}" = 0 ] && REQ+=(--require "v61_reports/$(basename "$m26")")
[ -f "$O/evidence28.json" ] && REQ+=(--require "v61_reports/evidence28.json")
[ -f "$O/panel_status.json" ] && REQ+=(--require "v61_reports/panel_status.json")
if [ "${RC[evidence28]}" = 0 ]; then
  for t in fork28:$FORK_FILES geometry26:$GEOM_FILES; do
    [ "${RC[${t%%:*}]}" = 0 ] || continue
    for f in $(echo "${t#*:}" | tr ',' ' '); do
      case " $LARGE " in *" $f "*) continue ;; esac
      REQ+=(--require "v61_reports/${t%%:*}_$f")
    done
  done
fi
INC=(--include v61_reports)
printf '%s\n' "${ORDER[@]}" > "$O/verdict_steps.txt"
step package python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" cop_v61_reanalysis_reports \
    "${INC[@]}" "${REQ[@]}"
verdict "$O/verdict.json" package_final
if [ "${RC[package]}" = 0 ]; then
  step package_final python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" \
      cop_v61_reanalysis_reports "${INC[@]}" "${REQ[@]}"
else
  skip package_final "packaging failed"
  rm -f "$ZIP"
fi
verdict "$O/verdict.json"
[ -f "$ZIP" ] || { echo "no archive at $ZIP"; RC[archive_present]=1; ORDER+=(archive_present); verdict "$O/verdict.json"; }
python -c "import json,sys; sys.exit(0 if json.load(open('$O/verdict.json'))['all_passed'] else 1)"
