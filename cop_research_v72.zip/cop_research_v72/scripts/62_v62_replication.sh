#!/usr/bin/env bash
# v62: does v60's separation hold in a second setting?  Wave 29 (CHANGES_v62.md): another network (width 128, six
# hidden layers; the additions merge after layer 3) and another shortcut task (12 causal, 12 noise inputs), 12 new
# data draws (349-360) x optimizer seeds 0 and 1.  Per f0: the four affine arms of wave 26 ({A, B} x {routed, all})
# with their linear removals, the two compact controls, and from each routed affine arm at snap_1000 and snap_2500
# the five continuations of wave 28 (routed_reset, ordinary_reset, frozen_reset, folded_reset, routed_carry).
# 744 jobs, all trained here.  Nothing in cop/ changed (semantic code hash 09850974bb32663f, as v60 and v61).
# The analyses are v61's, unchanged apart from finding the merge at any depth:
#   fork29      audit_v5/tools/fork_continuation.py: per-fork audits, the central paired table, contrasts
#   geometry29  audit_v5/tools/merge_geometry.py: exact merge maps, transport (float64 decisive, float32 reported),
#               the precision diagnostic, whitening comparability
#   status      scripts/panel_status.py: training, fork validity, transport validity, analysis completion apart
# It writes ~/cop_results_v62 only.
#
#   cd ~/research/cop_research_v62 && WORKERS=3 COP_VENV=~/fsc/.venv nohup bash scripts/62_v62_replication.sh > ~/v62.log 2>&1 &
#
# Zip: cop_v62_panel_reports.zip.  A stopped run is continued by running the same command again.
export COP_HOME="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export SCALE="${SCALE:-full}"
if [ "$SCALE" != full ]; then
  echo "v62 needs SCALE=full: its fork points (updates 1000 and 2500), snapshots and draws are defined for the full"
  echo "schedule and a reduced scale cannot reach them.  The tests carry a miniature of the panel."
  exit 2
fi
export COP_RESULTS="${COP_RESULTS:-$HOME/cop_results_v62}"
source "$(dirname "$0")/common.sh"
set +e
set +u
ZIP_DIR="${ZIP_DIR:-/mnt/c/Users/Matthew Fried/Downloads}"
[ -d "$ZIP_DIR" ] || ZIP_DIR="$HOME"
COP_PYTEST="${COP_PYTEST:-python -m pytest}"
O="$COP_RESULTS/v62_reports"
P="$COP_RESULTS/panel29"
ZIP="$ZIP_DIR/cop_v62_panel_reports.zip"
mkdir -p "$O" "$P"
declare -A RC
ORDER=()
step() { local name="$1"; shift; ORDER+=("$name"); echo "=== $(date '+%F %T') $name"; "$@" > "$O/$name.txt" 2>&1
         RC[$name]=$?; echo "=== $name exit ${RC[$name]}"; tail -3 "$O/$name.txt"; }
skip() { ORDER+=("$1"); RC[$1]=99; echo "=== $1 SKIPPED: $2" | tee "$O/$1.txt"; }
verdict() {   # verdict <file> [pending-step ...]
  local f="$1"; shift
  local js="{"
  for k in "${ORDER[@]}"; do js+="\"$k\": ${RC[$k]}, "; done
  js="${js%, }}"
  python - "$f" "$js" "$@" <<'PY'
import json, sys
f, rc, pending = sys.argv[1], json.loads(sys.argv[2]), sys.argv[3:]
json.dump({"steps": rc, "pending": pending, "skipped_code": 99,
           "all_passed": not pending and all(v == 0 for v in rc.values()),
           "completed_steps_passed": all(v == 0 for v in rc.values()),
           "note": "pending steps cannot report inside the archive they write; the launcher's exit status and the "
                   "verdict.json next to the reports are final"}, open(f, "w"), indent=1)
print(json.dumps(rc, indent=1))
PY
}

step environment cop inspect-environment --out "$O/environment.json"
m29="$COP_HOME/manifests/wave29_${SCALE}.jsonl"
rm -f "$m29"          # a failed generation must not fall through to a stale manifest
step manifest29 cop generate-manifest --wave 29 --scale "$SCALE" --out "$m29"
if [ "${RC[manifest29]}" = 0 ] && [ -s "$m29" ]; then
  step validate29 cop validate-manifest --manifest "$m29"
else
  skip validate29 "the wave-29 manifest was not generated (see manifest29)"
fi
PRE=0
[ "${RC[environment]}" = 0 ] && [ "${RC[manifest29]}" = 0 ] && [ "${RC[validate29]}" = 0 ] && PRE=1
if [ "$PRE" = 1 ]; then
  step cpu_tests env CUDA_VISIBLE_DEVICES="" DEVICE=cpu $COP_PYTEST -q -rs tests/ -p no:cacheprovider \
      --junitxml "$O/cpu_tests.xml"
else
  skip cpu_tests "the environment, the manifest or its validation failed"
fi
# on a CUDA device every CUDA test of the training code must RUN and pass (pytest exits 0 when a test is skipped, so
# the junit report is checked: tests ran, none skipped)
case "$DEVICE" in cuda|cuda:*) IS_CUDA=1 ;; *) IS_CUDA=0 ;; esac
rm -f "${O:?}/cuda_tests.xml"      # an earlier attempt's record is never this attempt's
READY=0
[ "$PRE" = 1 ] && [ "${RC[cpu_tests]}" = 0 ] && READY=1
if [ "$READY" = 1 ] && [ "$IS_CUDA" = 1 ]; then
  step cuda_tests env DEVICE="$DEVICE" COP_TEST_CUDA_DEVICE="$DEVICE" $COP_PYTEST -q -rs tests/ \
      -k "cuda or gpu_equivalence" --ignore tests/test_v53.py -p no:cacheprovider --junitxml "$O/cuda_tests.xml"
  step cuda_tests_ran python scripts/junit_ran.py "$O/cuda_tests.xml"
  for k in cuda_tests cuda_tests_ran; do [ "${RC[$k]}" = 0 ] || READY=0; done
fi
if [ "$READY" = 1 ] || [ "${DIAGNOSTIC_OVERRIDE:-0}" = 1 ]; then
  [ "$READY" = 1 ] || echo "DIAGNOSTIC_OVERRIDE=1: running the panel after a failed prerequisite" | tee "$O/override.txt"
  step run29 cop run --manifest "$m29" --results "$P" --device "$DEVICE" --data-root "$COP_DATA_ROOT" \
      --workers "$WORKERS" --threads "$THREADS" --resume
else
  skip run29 "a prerequisite failed (environment, manifest, validation or tests); set DIAGNOSTIC_OVERRIDE=1 to run anyway"
fi
FORK_FILES="coverage.json,audits.csv,central.csv,states.csv,states_by_draw.csv,states_summary.csv,contrasts.csv,contrasts_by_draw.csv,contrasts_summary.csv,contrasts_summary_sensitivity.csv"
GEOM_FILES="coverage.json,whitening_coverage.csv,maps.csv,maps_by_draw.csv,maps_summary.csv,transport.csv,transport_by_draw.csv,transport_summary.csv,precision.csv,precision_by_draw.csv,precision_summary.csv,probes.csv,probes_by_draw.csv,probes_summary.csv,contrasts.csv,contrasts_by_draw.csv,contrasts_summary.csv"
# checked as evidence but archived only when small (kept on disk)
LARGE="probes.csv contrasts.csv"
rm -f "${O:?}"/fork29_* "${O:?}"/geometry29_* "${O:?}/panel_status.json" "${O:?}/panel29.txt"
# on a CUDA machine each saved fold is also evaluated in float32 on the device the runs were trained on
case "$DEVICE" in cuda|cuda:*) FORK_EXTRA=(--recorded-device "$DEVICE") ;; *) FORK_EXTRA=() ;; esac
# when the panel did not run, every step that reads its results is skipped; when it ran but did not finish, only its
# status is reported (which jobs failed), since the analyses need the complete panel
if [ "${RC[run29]}" = 99 ]; then
  for k in status29 checks29 reload29 summary29 rates29 fork29 geometry29; do
    skip "$k" "the training panel was skipped (see run29)"
  done
elif [ "${RC[run29]}" != 0 ]; then
  step status29 cop status --manifest "$m29" --results "$P"
  for k in checks29 reload29 summary29 rates29 fork29 geometry29; do
    skip "$k" "the training panel did not finish (see run29 and status29); run the same command again to continue"
  done
else
  step status29 cop status --manifest "$m29" --results "$P"
  step checks29 python audit_v8/tools/check_results.py "$P" "$O/checks29.json" --manifest "$m29" \
      --transplants-if-any --diagnostics-if-any
  step reload29 python audit_v5/tools/fresh_reload.py "$P" "$O/fresh_reload29.json" --device recorded \
      --data-root "$COP_DATA_ROOT"
  step summary29 cop summarize --strict --results "$P" --manifest "$m29" --out "$COP_RESULTS/summary29"
  step rates29 python audit_v5/tools/runtime_v13.py fit "$m29" "$P" "$O/rates29.json"
  step fork29 python audit_v5/tools/fork_continuation.py "$P" "$O/fork29" \
      --data-root "$COP_DATA_ROOT" --manifest "$m29" --strict --device cpu "${FORK_EXTRA[@]}"
  step geometry29 env CUDA_VISIBLE_DEVICES="" python audit_v5/tools/merge_geometry.py "$P" \
      "$O/geometry29" --data-root "$COP_DATA_ROOT" --manifest "$m29" --strict --device cpu
fi
python scripts/panel_state.py "$m29" "$P" > "$O/panel29.txt" 2>&1
step status python scripts/panel_status.py "$O/panel_status.json" "$O/panel29.txt" "$O/fork29_coverage.json" \
    "$O/geometry29_coverage.json"
rm -f "${O:?}/evidence29.json"
step evidence29 python scripts/check_evidence.py "$O/evidence29.json" \
    "fork29:${RC[fork29]}:$O/fork29:$FORK_FILES" \
    "geometry29:${RC[geometry29]}:$O/geometry29:$GEOM_FILES"
if [ -s "$m29" ]; then step manifest_copy cp "$m29" "$O/"; else skip manifest_copy "no manifest"; fi

# packaging: the archive carries the verdict of every step before it (packaging pending), is verified, then the
# external verdict is final; the archive is rewritten with that final verdict and verified again
verdict "$O/verdict.json" package package_final
REQ=(--require "v62_reports/verdict_steps.txt")
for k in "${ORDER[@]}"; do REQ+=(--require "v62_reports/$k.txt"); done
[ "${RC[manifest_copy]}" = 0 ] && REQ+=(--require "v62_reports/$(basename "$m29")")
[ -f "$O/evidence29.json" ] && REQ+=(--require "v62_reports/evidence29.json")
[ -f "$O/panel_status.json" ] && REQ+=(--require "v62_reports/panel_status.json")
[ "${RC[checks29]}" = 0 ] && REQ+=(--require "v62_reports/checks29.json")
[ "${RC[reload29]}" = 0 ] && REQ+=(--require "v62_reports/fresh_reload29.json")
if [ "${RC[evidence29]}" = 0 ]; then
  for t in fork29:$FORK_FILES geometry29:$GEOM_FILES; do
    [ "${RC[${t%%:*}]}" = 0 ] || continue
    for f in $(echo "${t#*:}" | tr ',' ' '); do
      case " $LARGE " in *" $f "*) continue ;; esac
      REQ+=(--require "v62_reports/${t%%:*}_$f")
    done
  done
fi
INC=(--include v62_reports)
[ -d "$COP_RESULTS/summary29" ] && INC+=(--include summary29)
printf '%s\n' "${ORDER[@]}" > "$O/verdict_steps.txt"
step package python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" cop_v62_panel_reports \
    "${INC[@]}" "${REQ[@]}"
verdict "$O/verdict.json" package_final
if [ "${RC[package]}" = 0 ]; then
  step package_final python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" \
      cop_v62_panel_reports "${INC[@]}" "${REQ[@]}"
else
  skip package_final "packaging failed"
  rm -f "$ZIP"
fi
verdict "$O/verdict.json"
[ -f "$ZIP" ] || { echo "no archive at $ZIP"; RC[archive_present]=1; ORDER+=(archive_present); verdict "$O/verdict.json"; }
python -c "import json,sys; sys.exit(0 if json.load(open('$O/verdict.json'))['all_passed'] else 1)"
