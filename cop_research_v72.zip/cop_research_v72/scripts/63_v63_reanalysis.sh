#!/usr/bin/env bash
# v63: analysis only (CHANGES_v63.md).  Trains nothing.  Run it after v62 has finished.  Reads the v62 wave-29 panel
# (~/cop_results_v62/panel29) and the v53 wave-26 panel (~/cop_results_v53/panel26), both only read, and writes
# ~/cop_results_v63:
#   fork29      audit_v5/tools/fork_continuation.py on the v62 panel, now with the compact controls (2U and 4U)
#               measured like every other state and each fork compared with them, the compute table, audit coverage
#   geometry29  audit_v5/tools/merge_geometry.py on the v62 panel: fitted against transported probes at MATCHED
#               precision (float32 with float32, float64 with float64; v61's mixed comparison kept and labelled),
#               whitening comparability carried into those comparisons
#   geometry26  the same on the v53 panel (corrects v61's fitted-minus-transported reading there)
#   registry29  scripts/replication_registry.py: the replication hypotheses of configs/v62_replication_registry.json
#   status      scripts/panel_status.py: training, fork validity (with audit coverage), transport (among eligible
#               states and across all planned states), analysis completion
#
#   cd ~/research/cop_research_v63 && COP_VENV=~/fsc/.venv nohup bash scripts/63_v63_reanalysis.sh > ~/v63.log 2>&1 &
#
# Zip: cop_v63_reanalysis_reports.zip.  Running it again redoes the analyses.
export COP_HOME="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export SCALE="${SCALE:-full}"
if [ "$SCALE" != full ]; then
  echo "v63 reanalyses the full v62 and v53 panels: SCALE must be full"
  exit 2
fi
export COP_RESULTS="${COP_RESULTS:-$HOME/cop_results_v63}"
source "$(dirname "$0")/common.sh"
set +e
set +u
ZIP_DIR="${ZIP_DIR:-/mnt/c/Users/Matthew Fried/Downloads}"
[ -d "$ZIP_DIR" ] || ZIP_DIR="$HOME"
COP_PYTEST="${COP_PYTEST:-python -m pytest}"
O="$COP_RESULTS/v63_reports"
ZIP="$ZIP_DIR/cop_v63_reanalysis_reports.zip"
mkdir -p "$O"
declare -A RC
ORDER=()
step() { local name="$1"; shift; ORDER+=("$name"); echo "=== $(date '+%F %T') $name"; "$@" > "$O/$name.txt" 2>&1
         RC[$name]=$?; echo "=== $name exit ${RC[$name]}"; tail -3 "$O/$name.txt"; }
skip() { ORDER+=("$1"); RC[$1]=99; echo "=== $1 SKIPPED: $2" | tee "$O/$1.txt"; }
verdict() {   # verdict <file> [pending-step ...]
  local f="$1"; shift
  local js="{"
  for k in "${ORDER[@]}"; do js+="\"$k\": ${RC[$k]}, "; done
  js="${js%, }}"
  python - "$f" "$js" "$@" <<'PY'
import json, sys
f, rc, pending = sys.argv[1], json.loads(sys.argv[2]), sys.argv[3:]
json.dump({"steps": rc, "pending": pending, "skipped_code": 99,
           "all_passed": not pending and all(v == 0 for v in rc.values()),
           "completed_steps_passed": all(v == 0 for v in rc.values()),
           "note": "pending steps cannot report inside the archive they write; the launcher's exit status and the "
                   "verdict.json next to the reports are final"}, open(f, "w"), indent=1)
print(json.dumps(rc, indent=1))
PY
}

AUDITS="$COP_HOME/configs/reuse_audits.json"
P62="${V62_RESULTS:-$HOME/cop_results_v62}/panel29"
GEOM_PANEL="${V53_RESULTS:-$HOME/cop_results_v53}/panel26"
REGISTRY="$COP_HOME/configs/v62_replication_registry.json"

step environment cop inspect-environment --out "$O/environment.json"
m29="$COP_HOME/manifests/wave29_${SCALE}.jsonl"
m26="$COP_HOME/manifests/wave26_${SCALE}.jsonl"
rm -f "$m29" "$m26"   # a failed generation must not fall through to a stale manifest
step manifest29 cop generate-manifest --wave 29 --scale "$SCALE" --out "$m29"
step manifest26 cop generate-manifest --wave 26 --scale "$SCALE" --out "$m26"
for w in 29 26; do
  m="$COP_HOME/manifests/wave${w}_${SCALE}.jsonl"
  if [ "${RC[manifest$w]}" = 0 ] && [ -s "$m" ]; then
    step validate$w cop validate-manifest --manifest "$m"
  else
    skip validate$w "the wave-$w manifest was not generated (see manifest$w)"
  fi
done
PRE=0
[ "${RC[environment]}" = 0 ] && [ "${RC[validate29]}" = 0 ] && [ "${RC[validate26]}" = 0 ] && PRE=1
if [ "$PRE" = 1 ]; then
  step cpu_tests env CUDA_VISIBLE_DEVICES="" DEVICE=cpu $COP_PYTEST -q -rs tests/ -p no:cacheprovider \
      --junitxml "$O/cpu_tests.xml"
else
  skip cpu_tests "the environment, a manifest or its validation failed"
fi
READY=0
[ "$PRE" = 1 ] && [ "${RC[cpu_tests]}" = 0 ] && READY=1
if [ "$PRE" = 1 ]; then
  step panel29 python scripts/panel_state.py "$m29" "$P62"
  step panel_source26 python scripts/panel_state.py "$m26" "$GEOM_PANEL" --audited "$AUDITS"
else
  skip panel29 "a prerequisite failed"
  skip panel_source26 "a prerequisite failed"
fi
FORK_FILES="coverage.json,audits.csv,compute.csv,central.csv,states.csv,states_by_draw.csv,states_summary.csv,contrasts.csv,contrasts_by_draw.csv,contrasts_summary.csv,contrasts_summary_sensitivity.csv"
GEOM_FILES="coverage.json,whitening_coverage.csv,maps.csv,maps_by_draw.csv,maps_summary.csv,transport.csv,transport_by_draw.csv,transport_summary.csv,precision.csv,precision_by_draw.csv,precision_summary.csv,probes.csv,probes_by_draw.csv,probes_summary.csv,contrasts.csv,contrasts_by_draw.csv,contrasts_summary.csv"
# checked as evidence but archived only when small (kept on disk)
LARGE="probes.csv contrasts.csv"
rm -f "${O:?}"/fork29_* "${O:?}"/geometry29_* "${O:?}"/geometry26_* "${O:?}"/registry29.* "${O:?}/panel_status.json"
case "$DEVICE" in cuda|cuda:*) FORK_EXTRA=(--recorded-device "$DEVICE") ;; *) FORK_EXTRA=() ;; esac
if [ "$READY" = 1 ] && [ "${RC[panel29]}" = 0 ]; then
  step fork29 python audit_v5/tools/fork_continuation.py "$P62" "$O/fork29" \
      --data-root "$COP_DATA_ROOT" --manifest "$m29" --strict --device cpu "${FORK_EXTRA[@]}"
  step geometry29 env CUDA_VISIBLE_DEVICES="" python audit_v5/tools/merge_geometry.py "$P62" \
      "$O/geometry29" --data-root "$COP_DATA_ROOT" --manifest "$m29" --strict --device cpu
else
  skip fork29 "the tests or the v62 panel failed (see cpu_tests, panel29)"
  skip geometry29 "the tests or the v62 panel failed (see cpu_tests, panel29)"
fi
if [ "$READY" = 1 ] && [ "${RC[panel_source26]}" = 0 ]; then
  step geometry26 env CUDA_VISIBLE_DEVICES="" python audit_v5/tools/merge_geometry.py "$GEOM_PANEL" \
      "$O/geometry26" --data-root "$COP_DATA_ROOT" --manifest "$m26" --strict --device cpu
else
  skip geometry26 "the tests or the wave-26 panel source failed (see cpu_tests, panel_source26)"
fi
# the registry reads only a fork analysis that passed (complete audit, no failed fork)
if [ "${RC[fork29]}" = 0 ] && [ -s "$O/fork29_contrasts.csv" ]; then
  step registry29 python scripts/replication_registry.py "$REGISTRY" "$O/fork29_contrasts.csv" "$O/registry29"
else
  skip registry29 "the fork analysis did not pass (see fork29)"
fi
step status python scripts/panel_status.py "$O/panel_status.json" "$O/panel29.txt" "$O/fork29_coverage.json" \
    "$O/geometry29_coverage.json"
rm -f "${O:?}/evidence29.json"
step evidence29 python scripts/check_evidence.py "$O/evidence29.json" \
    "fork29:${RC[fork29]}:$O/fork29:$FORK_FILES" \
    "geometry29:${RC[geometry29]}:$O/geometry29:$GEOM_FILES" \
    "geometry26:${RC[geometry26]}:$O/geometry26:$GEOM_FILES"
if [ -s "$m29" ]; then step manifest_copy cp "$m29" "$O/"; else skip manifest_copy "no manifest"; fi
if [ -s "$m26" ]; then step manifest_copy26 cp "$m26" "$O/"; else skip manifest_copy26 "no wave-26 manifest"; fi

# packaging: the archive carries the verdict of every step before it (packaging pending), is verified, then the
# external verdict is final; the archive is rewritten with that final verdict and verified again
verdict "$O/verdict.json" package package_final
REQ=(--require "v63_reports/verdict_steps.txt")
for k in "${ORDER[@]}"; do REQ+=(--require "v63_reports/$k.txt"); done
[ "${RC[manifest_copy]}" = 0 ] && REQ+=(--require "v63_reports/$(basename "$m29")")
[ "${RC[manifest_copy26]}" = 0 ] && REQ+=(--require "v63_reports/$(basename "$m26")")
[ -f "$O/evidence29.json" ] && REQ+=(--require "v63_reports/evidence29.json")
[ "${RC[registry29]}" = 0 ] && REQ+=(--require "v63_reports/registry29.json" --require "v63_reports/registry29.csv")
[ -f "$O/panel_status.json" ] && REQ+=(--require "v63_reports/panel_status.json")
if [ "${RC[evidence29]}" = 0 ]; then
  for t in fork29:$FORK_FILES geometry29:$GEOM_FILES geometry26:$GEOM_FILES; do
    [ "${RC[${t%%:*}]}" = 0 ] || continue
    for f in $(echo "${t#*:}" | tr ',' ' '); do
      case " $LARGE " in *" $f "*) continue ;; esac
      REQ+=(--require "v63_reports/${t%%:*}_$f")
    done
  done
fi
INC=(--include v63_reports)
printf '%s\n' "${ORDER[@]}" > "$O/verdict_steps.txt"
step package python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" cop_v63_reanalysis_reports \
    "${INC[@]}" "${REQ[@]}"
verdict "$O/verdict.json" package_final
if [ "${RC[package]}" = 0 ]; then
  step package_final python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" \
      cop_v63_reanalysis_reports "${INC[@]}" "${REQ[@]}"
else
  skip package_final "packaging failed"
  rm -f "$ZIP"
fi
verdict "$O/verdict.json"
[ -f "$ZIP" ] || { echo "no archive at $ZIP"; RC[archive_present]=1; ORDER+=(archive_present); verdict "$O/verdict.json"; }
python -c "import json,sys; sys.exit(0 if json.load(open('$O/verdict.json'))['all_passed'] else 1)"
