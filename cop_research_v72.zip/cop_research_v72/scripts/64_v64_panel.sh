#!/usr/bin/env bash
# v64: the whole second-setting replication in one run (CHANGES_v64.md): the training of wave 29 and the corrected
# analyses.  Wave 29: width 128, six hidden layers (the additions merge after layer 3), the shortcut task with 12 causal
# and 12 noise inputs, 12 new data draws (349-360) x optimizer seeds 0 and 1.  Per f0: the four affine arms
# ({A, B} x {routed, all}) with their linear removals, the two compact controls (4U), and from each routed affine arm
# at snap_1000 and snap_2500 the five continuations (routed_reset, ordinary_reset, frozen_reset, folded_reset,
# routed_carry).  744 jobs, all trained here.  Nothing in cop/ changed (semantic code hash 09850974bb32663f).
# Then:
#   fork29      fork_continuation.py: audits with coverage, the central table, the compact controls at 2U and 4U
#               measured like every other state, fork-minus-compact contrasts, the compute table
#   geometry29  merge_geometry.py: exact merge maps, transport (float64 decisive, float32 reported), fitted against
#               transported probes at matched precision, whitening comparability with planned and included pairs
#   registry29  replication_registry.py: the hypotheses of configs/v62_replication_registry.json (only after a
#               passed fork analysis)
#   geometry26  merge_geometry.py on the v53 wave-26 panel (only read), correcting v61's mixed-precision comparison;
#               independent of the training: a missing v53 panel never stops wave 29
#   status      panel_status.py: training, fork validity (with coverage), transport, analysis completion
# It writes ~/cop_results_v64 only.
#
#   cd ~/research/cop_research_v64 && WORKERS=3 COP_VENV=~/fsc/.venv nohup bash scripts/64_v64_panel.sh > ~/v64.log 2>&1 &
#
# Zip: cop_v64_panel_reports.zip.  A stopped run is continued by running the same command again.
export COP_HOME="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export SCALE="${SCALE:-full}"
if [ "$SCALE" != full ]; then
  echo "v64 needs SCALE=full: its fork points (updates 1000 and 2500), snapshots and draws are defined for the full"
  echo "schedule and a reduced scale cannot reach them.  The tests carry a miniature of the panel."
  exit 2
fi
export COP_RESULTS="${COP_RESULTS:-$HOME/cop_results_v64}"
source "$(dirname "$0")/common.sh"
set +e
set +u
ZIP_DIR="${ZIP_DIR:-/mnt/c/Users/Matthew Fried/Downloads}"
[ -d "$ZIP_DIR" ] || ZIP_DIR="$HOME"
COP_PYTEST="${COP_PYTEST:-python -m pytest}"
O="$COP_RESULTS/v64_reports"
P="$COP_RESULTS/panel29"
ZIP="$ZIP_DIR/cop_v64_panel_reports.zip"
mkdir -p "$O" "$P"
declare -A RC
ORDER=()
step() { local name="$1"; shift; ORDER+=("$name"); echo "=== $(date '+%F %T') $name"; "$@" > "$O/$name.txt" 2>&1
         RC[$name]=$?; echo "=== $name exit ${RC[$name]}"; tail -3 "$O/$name.txt"; }
skip() { ORDER+=("$1"); RC[$1]=99; echo "=== $1 SKIPPED: $2" | tee "$O/$1.txt"; }
verdict() {   # verdict <file> [pending-step ...]
  local f="$1"; shift
  local js="{"
  for k in "${ORDER[@]}"; do js+="\"$k\": ${RC[$k]}, "; done
  js="${js%, }}"
  python - "$f" "$js" "$@" <<'PY'
import json, sys
f, rc, pending = sys.argv[1], json.loads(sys.argv[2]), sys.argv[3:]
json.dump({"steps": rc, "pending": pending, "skipped_code": 99,
           "all_passed": not pending and all(v == 0 for v in rc.values()),
           "completed_steps_passed": all(v == 0 for v in rc.values()),
           "note": "pending steps cannot report inside the archive they write; the launcher's exit status and the "
                   "verdict.json next to the reports are final"}, open(f, "w"), indent=1)
print(json.dumps(rc, indent=1))
PY
}

step environment cop inspect-environment --out "$O/environment.json"
m29="$COP_HOME/manifests/wave29_${SCALE}.jsonl"
rm -f "$m29"          # a failed generation must not fall through to a stale manifest
step manifest29 cop generate-manifest --wave 29 --scale "$SCALE" --out "$m29"
if [ "${RC[manifest29]}" = 0 ] && [ -s "$m29" ]; then
  step validate29 cop validate-manifest --manifest "$m29"
else
  skip validate29 "the wave-29 manifest was not generated (see manifest29)"
fi
PRE=0
[ "${RC[environment]}" = 0 ] && [ "${RC[manifest29]}" = 0 ] && [ "${RC[validate29]}" = 0 ] && PRE=1
if [ "$PRE" = 1 ]; then
  step cpu_tests env CUDA_VISIBLE_DEVICES="" DEVICE=cpu $COP_PYTEST -q -rs tests/ -p no:cacheprovider \
      --junitxml "$O/cpu_tests.xml"
else
  skip cpu_tests "the environment, the manifest or its validation failed"
fi
# on a CUDA device every CUDA test of the training code must RUN and pass (pytest exits 0 when a test is skipped, so
# the junit report is checked: tests ran, none skipped)
case "$DEVICE" in cuda|cuda:*) IS_CUDA=1 ;; *) IS_CUDA=0 ;; esac
rm -f "${O:?}/cuda_tests.xml"      # an earlier attempt's record is never this attempt's
READY=0
[ "$PRE" = 1 ] && [ "${RC[cpu_tests]}" = 0 ] && READY=1
if [ "$READY" = 1 ] && [ "$IS_CUDA" = 1 ]; then
  step cuda_tests env DEVICE="$DEVICE" COP_TEST_CUDA_DEVICE="$DEVICE" $COP_PYTEST -q -rs tests/ \
      -k "cuda or gpu_equivalence" --ignore tests/test_v53.py -p no:cacheprovider --junitxml "$O/cuda_tests.xml"
  step cuda_tests_ran python scripts/junit_ran.py "$O/cuda_tests.xml"
  for k in cuda_tests cuda_tests_ran; do [ "${RC[$k]}" = 0 ] || READY=0; done
fi
if [ "$READY" = 1 ] || [ "${DIAGNOSTIC_OVERRIDE:-0}" = 1 ]; then
  [ "$READY" = 1 ] || echo "DIAGNOSTIC_OVERRIDE=1: running the panel after a failed prerequisite" | tee "$O/override.txt"
  step run29 cop run --manifest "$m29" --results "$P" --device "$DEVICE" --data-root "$COP_DATA_ROOT" \
      --workers "$WORKERS" --threads "$THREADS" --resume
else
  skip run29 "a prerequisite failed (environment, manifest, validation or tests); set DIAGNOSTIC_OVERRIDE=1 to run anyway"
fi
FORK_FILES="coverage.json,audits.csv,compute.csv,central.csv,states.csv,states_by_draw.csv,states_summary.csv,contrasts.csv,contrasts_by_draw.csv,contrasts_summary.csv,contrasts_summary_sensitivity.csv"
GEOM_FILES="coverage.json,whitening_coverage.csv,maps.csv,maps_by_draw.csv,maps_summary.csv,transport.csv,transport_by_draw.csv,transport_summary.csv,precision.csv,precision_by_draw.csv,precision_summary.csv,probes.csv,probes_by_draw.csv,probes_summary.csv,contrasts.csv,contrasts_by_draw.csv,contrasts_summary.csv"
# checked as evidence but archived only when small (kept on disk)
LARGE="probes.csv contrasts.csv"
rm -f "${O:?}"/fork29_* "${O:?}"/geometry29_* "${O:?}"/geometry26_* "${O:?}"/registry29.* "${O:?}/panel_status.json" \
    "${O:?}/panel29.txt"
# on a CUDA machine each saved fold is also evaluated in float32 on the device the runs were trained on
case "$DEVICE" in cuda|cuda:*) FORK_EXTRA=(--recorded-device "$DEVICE") ;; *) FORK_EXTRA=() ;; esac
# when the panel did not run, every step that reads its results is skipped; when it ran but did not finish, only its
# status is reported (which jobs failed), since the analyses need the complete panel
if [ "${RC[run29]}" = 99 ]; then
  for k in status29 checks29 reload29 summary29 rates29 fork29 geometry29 registry29; do
    skip "$k" "the training panel was skipped (see run29)"
  done
elif [ "${RC[run29]}" != 0 ]; then
  step status29 cop status --manifest "$m29" --results "$P"
  for k in checks29 reload29 summary29 rates29 fork29 geometry29 registry29; do
    skip "$k" "the training panel did not finish (see run29 and status29); run the same command again to continue"
  done
else
  step status29 cop status --manifest "$m29" --results "$P"
  step checks29 python audit_v8/tools/check_results.py "$P" "$O/checks29.json" --manifest "$m29" \
      --transplants-if-any --diagnostics-if-any
  step reload29 python audit_v5/tools/fresh_reload.py "$P" "$O/fresh_reload29.json" --device recorded \
      --data-root "$COP_DATA_ROOT"
  step summary29 cop summarize --strict --results "$P" --manifest "$m29" --out "$COP_RESULTS/summary29"
  step rates29 python audit_v5/tools/runtime_v13.py fit "$m29" "$P" "$O/rates29.json"
  step fork29 python audit_v5/tools/fork_continuation.py "$P" "$O/fork29" \
      --data-root "$COP_DATA_ROOT" --manifest "$m29" --strict --device cpu "${FORK_EXTRA[@]}"
  step geometry29 env CUDA_VISIBLE_DEVICES="" python audit_v5/tools/merge_geometry.py "$P" \
      "$O/geometry29" --data-root "$COP_DATA_ROOT" --manifest "$m29" --strict --device cpu
  # the registry reads only a fork analysis that passed (complete audit, no failed fork)
  if [ "${RC[fork29]}" = 0 ] && [ -s "$O/fork29_contrasts.csv" ]; then
    step registry29 python scripts/replication_registry.py "$COP_HOME/configs/v62_replication_registry.json" \
        "$O/fork29_contrasts.csv" "$O/registry29"
  else
    skip registry29 "the fork analysis did not pass (see fork29)"
  fi
fi
# the v53 wave-26 panel (only read), after the training and independent of it
GEOM_PANEL="${V53_RESULTS:-$HOME/cop_results_v53}/panel26"
m26="$COP_HOME/manifests/wave26_${SCALE}.jsonl"
rm -f "$m26"
step manifest26 cop generate-manifest --wave 26 --scale "$SCALE" --out "$m26"
if [ "${RC[manifest26]}" = 0 ] && [ -s "$m26" ]; then
  step validate26 cop validate-manifest --manifest "$m26"
else
  skip validate26 "the wave-26 manifest was not generated (see manifest26)"
fi
if [ "${RC[validate26]}" = 0 ]; then
  step panel_source26 python scripts/panel_state.py "$m26" "$GEOM_PANEL" --audited "$COP_HOME/configs/reuse_audits.json"
else
  skip panel_source26 "the wave-26 manifest failed (see manifest26, validate26)"
fi
if [ "${RC[cpu_tests]}" = 0 ] && [ "${RC[panel_source26]}" = 0 ]; then
  step geometry26 env CUDA_VISIBLE_DEVICES="" python audit_v5/tools/merge_geometry.py "$GEOM_PANEL" \
      "$O/geometry26" --data-root "$COP_DATA_ROOT" --manifest "$m26" --strict --device cpu
else
  skip geometry26 "the tests or the v53 wave-26 panel failed (see cpu_tests, panel_source26)"
fi
python scripts/panel_state.py "$m29" "$P" > "$O/panel29.txt" 2>&1
step status python scripts/panel_status.py "$O/panel_status.json" "$O/panel29.txt" "$O/fork29_coverage.json" \
    "$O/geometry29_coverage.json"
rm -f "${O:?}/evidence29.json"
step evidence29 python scripts/check_evidence.py "$O/evidence29.json" \
    "fork29:${RC[fork29]}:$O/fork29:$FORK_FILES" \
    "geometry29:${RC[geometry29]}:$O/geometry29:$GEOM_FILES" \
    "geometry26:${RC[geometry26]}:$O/geometry26:$GEOM_FILES"
if [ -s "$m29" ]; then step manifest_copy cp "$m29" "$O/"; else skip manifest_copy "no manifest"; fi
if [ -s "$m26" ]; then step manifest_copy26 cp "$m26" "$O/"; else skip manifest_copy26 "no wave-26 manifest"; fi

# packaging: the archive carries the verdict of every step before it (packaging pending), is verified, then the
# external verdict is final; the archive is rewritten with that final verdict and verified again
verdict "$O/verdict.json" package package_final
REQ=(--require "v64_reports/verdict_steps.txt")
for k in "${ORDER[@]}"; do REQ+=(--require "v64_reports/$k.txt"); done
[ "${RC[manifest_copy]}" = 0 ] && REQ+=(--require "v64_reports/$(basename "$m29")")
[ "${RC[manifest_copy26]}" = 0 ] && REQ+=(--require "v64_reports/$(basename "$m26")")
[ "${RC[registry29]}" = 0 ] && REQ+=(--require "v64_reports/registry29.json" --require "v64_reports/registry29.csv")
[ -f "$O/evidence29.json" ] && REQ+=(--require "v64_reports/evidence29.json")
[ -f "$O/panel_status.json" ] && REQ+=(--require "v64_reports/panel_status.json")
[ "${RC[checks29]}" = 0 ] && REQ+=(--require "v64_reports/checks29.json")
[ "${RC[reload29]}" = 0 ] && REQ+=(--require "v64_reports/fresh_reload29.json")
if [ "${RC[evidence29]}" = 0 ]; then
  for t in fork29:$FORK_FILES geometry29:$GEOM_FILES geometry26:$GEOM_FILES; do
    [ "${RC[${t%%:*}]}" = 0 ] || continue
    for f in $(echo "${t#*:}" | tr ',' ' '); do
      case " $LARGE " in *" $f "*) continue ;; esac
      REQ+=(--require "v64_reports/${t%%:*}_$f")
    done
  done
fi
INC=(--include v64_reports)
[ -d "$COP_RESULTS/summary29" ] && INC+=(--include summary29)
printf '%s\n' "${ORDER[@]}" > "$O/verdict_steps.txt"
step package python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" cop_v64_panel_reports \
    "${INC[@]}" "${REQ[@]}"
verdict "$O/verdict.json" package_final
if [ "${RC[package]}" = 0 ]; then
  step package_final python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" \
      cop_v64_panel_reports "${INC[@]}" "${REQ[@]}"
else
  skip package_final "packaging failed"
  rm -f "$ZIP"
fi
verdict "$O/verdict.json"
[ -f "$ZIP" ] || { echo "no archive at $ZIP"; RC[archive_present]=1; ORDER+=(archive_present); verdict "$O/verdict.json"; }
python -c "import json,sys; sys.exit(0 if json.load(open('$O/verdict.json'))['all_passed'] else 1)"
