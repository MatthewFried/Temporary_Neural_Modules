#!/usr/bin/env bash
# v65: the two follow-ups of the replication (CHANGES_v65.md), in one run.
#   wave 30  the v60 design on images: image_shortcut (CIFAR-10 vehicles against four animal classes, a shortcut
#            input channel), the cnn_cut network (its middle cut feeds a 1x1 receiving layer present in every arm),
#            12 new data draws x optimizer seeds 0 and 1: the affine arms {A, B} x {routed, all}, a late temporary
#            head (the projection-head comparison), the compact controls and the forks of the routed arms.  792 jobs.
#   wave 31  the mechanism forks: from wave 29's routed affine trajectories (v62's setting) at both fork points,
#            continuations from a function-preserving redistribution of the additions' computation (swap the a and
#            b branches; move half or all of the map into the receiving layer), routed and ordinary.  Wave 29's
#            f0s, routed trajectories and their forks are the same jobs (same run ids): they are copied from v64's
#            panel under the reuse audit v65_from_v60 and verified by retraining a sample before anything descends
#            from them; 480 new jobs.
# Then: image30 (image_forks.py) and registry30 (configs/v65_image_registry.json); fork31 (fork_continuation.py
# with the redistribution audits and interactions) and registry31 (configs/v65_mechanism_registry.json); the status
# of each panel, evidence, packaging.  It writes ~/cop_results_v65 only; v64's panel is only read.
#
#   cd ~/research/cop_research_v65 && WORKERS=3 COP_VENV=~/fsc/.venv nohup bash scripts/65_v65_panels.sh > ~/v65.log 2>&1 &
#
# Zip: cop_v65_panel_reports.zip.  A stopped run is continued by running the same command again.
export COP_HOME="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export SCALE="${SCALE:-full}"
if [ "$SCALE" != full ]; then
  echo "v65 needs SCALE=full: its fork points (updates 1000 and 2500), snapshots and draws are defined for the full"
  echo "schedule and a reduced scale cannot reach them.  The tests carry miniatures of both waves."
  exit 2
fi
export COP_RESULTS="${COP_RESULTS:-$HOME/cop_results_v65}"
source "$(dirname "$0")/common.sh"
set +e
set +u
ZIP_DIR="${ZIP_DIR:-/mnt/c/Users/Matthew Fried/Downloads}"
[ -d "$ZIP_DIR" ] || ZIP_DIR="$HOME"
COP_PYTEST="${COP_PYTEST:-python -m pytest}"
O="$COP_RESULTS/v65_reports"
P30="$COP_RESULTS/panel30"
P31="$COP_RESULTS/panel31"
ZIP="$ZIP_DIR/cop_v65_panel_reports.zip"
SEED="${SEED:-1}"
SEED_FROM="${SEED_FROM:-${V64_RESULTS:-$HOME/cop_results_v64}/panel29}"
AUDITS="$COP_HOME/configs/reuse_audits.json"
mkdir -p "$O" "$P30" "$P31"
declare -A RC
ORDER=()
step() { local name="$1"; shift; ORDER+=("$name"); echo "=== $(date '+%F %T') $name"; "$@" > "$O/$name.txt" 2>&1
         RC[$name]=$?; echo "=== $name exit ${RC[$name]}"; tail -3 "$O/$name.txt"; }
skip() { ORDER+=("$1"); RC[$1]=99; echo "=== $1 SKIPPED: $2" | tee "$O/$1.txt"; }
verdict() {   # verdict <file> [pending-step ...]
  local f="$1"; shift
  local js="{"
  for k in "${ORDER[@]}"; do js+="\"$k\": ${RC[$k]}, "; done
  js="${js%, }}"
  python - "$f" "$js" "$@" <<'PY'
import json, sys
f, rc, pending = sys.argv[1], json.loads(sys.argv[2]), sys.argv[3:]
json.dump({"steps": rc, "pending": pending, "skipped_code": 99,
           "all_passed": not pending and all(v == 0 for v in rc.values()),
           "completed_steps_passed": all(v == 0 for v in rc.values()),
           "note": "pending steps cannot report inside the archive they write; the launcher's exit status and the "
                   "verdict.json next to the reports are final"}, open(f, "w"), indent=1)
print(json.dumps(rc, indent=1))
PY
}

step environment cop inspect-environment --out "$O/environment.json"
m30="$COP_HOME/manifests/wave30_${SCALE}.jsonl"
m31="$COP_HOME/manifests/wave31_${SCALE}.jsonl"
rm -f "$m30" "$m31"          # a failed generation must not fall through to a stale manifest
step manifest30 cop generate-manifest --wave 30 --scale "$SCALE" --out "$m30"
step manifest31 cop generate-manifest --wave 31 --scale "$SCALE" --out "$m31"
for w in 30 31; do
  m="$COP_HOME/manifests/wave${w}_${SCALE}.jsonl"
  if [ "${RC[manifest$w]}" = 0 ] && [ -s "$m" ]; then
    step "validate$w" cop validate-manifest --manifest "$m"
  else
    skip "validate$w" "the wave-$w manifest was not generated (see manifest$w)"
  fi
done
PRE=0
[ "${RC[environment]}" = 0 ] && [ "${RC[validate30]}" = 0 ] && [ "${RC[validate31]}" = 0 ] && PRE=1
if [ "$PRE" = 1 ]; then
  step cpu_tests env CUDA_VISIBLE_DEVICES="" DEVICE=cpu $COP_PYTEST -q -rs tests/ -p no:cacheprovider \
      --junitxml "$O/cpu_tests.xml"
else
  skip cpu_tests "the environment, a manifest or its validation failed"
fi
case "$DEVICE" in cuda|cuda:*) IS_CUDA=1 ;; *) IS_CUDA=0 ;; esac
rm -f "${O:?}/cuda_tests.xml" "${O:?}"/seed31.json "${O:?}/reuse_check31.json" "${O:?}/reuse_sample31.jsonl"
READY=0
[ "$PRE" = 1 ] && [ "${RC[cpu_tests]}" = 0 ] && READY=1
if [ "$READY" = 1 ] && [ "$IS_CUDA" = 1 ]; then
  step cuda_tests env DEVICE="$DEVICE" COP_TEST_CUDA_DEVICE="$DEVICE" $COP_PYTEST -q -rs tests/ \
      -k "cuda or gpu_equivalence" --ignore tests/test_v53.py -p no:cacheprovider --junitxml "$O/cuda_tests.xml"
  step cuda_tests_ran python scripts/junit_ran.py "$O/cuda_tests.xml"
  for k in cuda_tests cuda_tests_ran; do [ "${RC[$k]}" = 0 ] || READY=0; done
fi

if [ "$READY" = 1 ] || [ "${DIAGNOSTIC_OVERRIDE:-0}" = 1 ]; then
  [ "$READY" = 1 ] || echo "DIAGNOSTIC_OVERRIDE=1: running the panels after a failed prerequisite" | tee "$O/override.txt"
  # ---- wave 31: wave 29's finished jobs copied in under the audit (v64's panel is only read), verified by a retrained
  # sample before anything that descends from them trains
  if [ "$SEED" = 1 ]; then
    step seed31 python scripts/seed_panel.py "$m31" "$SEED_FROM" "$P31" "$O/seed31.json" --audited "$AUDITS"
  else
    skip seed31 "SEED=0: nothing is copied in this attempt"; RC[seed31]=0
  fi
  RS="$COP_RESULTS/reuse_check31"
  VERIFIED=0
  if [ "${RC[seed31]}" = 0 ]; then
    step reuse_select31 python scripts/reuse_reproduce.py select "$m31" "$P31" "$O/reuse_sample31.jsonl"
    if [ "${RC[reuse_select31]}" = 5 ]; then
      RC[reuse_select31]=0
      skip reuse_run31 "the panel holds no audited copy: nothing to verify"; RC[reuse_run31]=0
      skip reuse_compare31 "the panel holds no audited copy: nothing to verify"; RC[reuse_compare31]=0
      VERIFIED=1
    elif [ "${RC[reuse_select31]}" = 0 ]; then
      step reuse_run31 cop run --manifest "$O/reuse_sample31.jsonl" --results "$RS" --device "$DEVICE" \
          --data-root "$COP_DATA_ROOT" --workers "$WORKERS" --threads "$THREADS" --resume
      if [ "${RC[reuse_run31]}" = 0 ]; then
        step reuse_compare31 python scripts/reuse_reproduce.py compare "$O/reuse_sample31.jsonl" "$P31" "$RS" \
            "$O/reuse_check31.json"
        [ "${RC[reuse_compare31]}" = 0 ] && VERIFIED=1
      else
        skip reuse_compare31 "the sample did not retrain (see reuse_run31)"
      fi
    else
      skip reuse_run31 "the sample could not be selected (see reuse_select31)"
      skip reuse_compare31 "the sample could not be selected (see reuse_select31)"
    fi
  else
    for k in reuse_select31 reuse_run31 reuse_compare31; do skip "$k" "copying failed (see seed31)"; done
  fi
  if [ "${RC[seed31]}" != 0 ]; then
    skip run31 "copying v64's runs failed (see seed31); run again, or use a fresh results folder with SEED=0"
  elif [ "$VERIFIED" != 1 ]; then
    skip run31 "the reuse verification did not pass (see reuse_select31, reuse_run31, reuse_compare31): nothing that descends from the copies is trained"
  else
    step run31 cop run --manifest "$m31" --results "$P31" --device "$DEVICE" --data-root "$COP_DATA_ROOT" \
        --workers "$WORKERS" --threads "$THREADS" --resume
  fi
  # ---- wave 30: the image panel (CIFAR-10 in the data root; downloaded once if missing)
  step data30 python scripts/check_image_data.py "$COP_DATA_ROOT"
  if [ "${RC[data30]}" = 0 ]; then
    step run30 cop run --manifest "$m30" --results "$P30" --device "$DEVICE" --data-root "$COP_DATA_ROOT" \
        --workers "$WORKERS" --threads "$THREADS" --resume
  else
    skip run30 "the image data could not be loaded (see data30)"
  fi
else
  skip seed31 "a prerequisite failed"
  for k in reuse_select31 reuse_run31 reuse_compare31; do skip "$k" "a prerequisite failed"; done
  skip run31 "a prerequisite failed (environment, manifests, validation or tests); set DIAGNOSTIC_OVERRIDE=1 to run anyway"
  skip data30 "a prerequisite failed"
  skip run30 "a prerequisite failed (environment, manifests, validation or tests); set DIAGNOSTIC_OVERRIDE=1 to run anyway"
fi
IMG_FILES="coverage.json,audits.csv,compute.csv,central.csv,states.csv,states_by_draw.csv,states_summary.csv,contrasts.csv,contrasts_by_draw.csv,contrasts_summary.csv"
FORK_FILES="coverage.json,audits.csv,compute.csv,central.csv,states.csv,states_by_draw.csv,states_summary.csv,contrasts.csv,contrasts_by_draw.csv,contrasts_summary.csv,contrasts_summary_sensitivity.csv"
# checked as evidence but archived only when small (kept on disk)
LARGE="contrasts.csv"
rm -f "${O:?}"/image30_* "${O:?}"/fork31_* "${O:?}"/registry30.* "${O:?}"/registry31.* "${O:?}"/panel_status*.json \
    "${O:?}/panel30.txt" "${O:?}/panel31.txt"
# on a CUDA machine each saved fold is also evaluated in float32 on the device the runs were trained on
case "$DEVICE" in cuda|cuda:*) FORK_EXTRA=(--recorded-device "$DEVICE") ;; *) FORK_EXTRA=() ;; esac
# per panel: when it did not run, every step that reads it is skipped; when it ran but did not finish, only its
# status is reported, since the analyses need the complete panel
for w in 31 30; do
  m="$COP_HOME/manifests/wave${w}_${SCALE}.jsonl"
  P="$COP_RESULTS/panel$w"
  if [ "$w" = 30 ]; then AN=image30; REG=registry30; else AN=fork31; REG=registry31; fi
  if [ "${RC[run$w]}" = 99 ]; then
    for k in status$w checks$w reload$w summary$w rates$w $AN $REG; do skip "$k" "the panel was skipped (see run$w)"; done
    continue
  fi
  step "status$w" cop status --manifest "$m" --results "$P"
  if [ "${RC[run$w]}" != 0 ]; then
    for k in checks$w reload$w summary$w rates$w $AN $REG; do
      skip "$k" "the panel did not finish (see run$w and status$w); run the same command again to continue"
    done
    continue
  fi
  step "checks$w" python audit_v8/tools/check_results.py "$P" "$O/checks$w.json" --manifest "$m" \
      --transplants-if-any --diagnostics-if-any
  step "reload$w" python audit_v5/tools/fresh_reload.py "$P" "$O/fresh_reload$w.json" --device recorded \
      --data-root "$COP_DATA_ROOT"
  step "summary$w" cop summarize --strict --results "$P" --manifest "$m" --out "$COP_RESULTS/summary$w"
  step "rates$w" python audit_v5/tools/runtime_v13.py fit "$m" "$P" "$O/rates$w.json"
  if [ "$w" = 30 ]; then
    # the image analysis evaluates on the training device (the panel's networks are convolutional)
    step image30 python audit_v5/tools/image_forks.py "$P" "$O/image30" --data-root "$COP_DATA_ROOT" \
        --manifest "$m" --strict --device "$DEVICE" "${FORK_EXTRA[@]}"
    RA="${RC[image30]}"; CS="$O/image30_contrasts.csv"; RG="$COP_HOME/configs/v65_image_registry.json"
  else
    step fork31 python audit_v5/tools/fork_continuation.py "$P" "$O/fork31" --data-root "$COP_DATA_ROOT" \
        --manifest "$m" --strict --device cpu "${FORK_EXTRA[@]}"
    RA="${RC[fork31]}"; CS="$O/fork31_contrasts.csv"; RG="$COP_HOME/configs/v65_mechanism_registry.json"
  fi
  # a registry reads only an analysis that passed (complete audits, no failed fork)
  if [ "$RA" = 0 ] && [ -s "$CS" ]; then
    step "$REG" python scripts/replication_registry.py "$RG" "$CS" "$O/$REG"
  else
    skip "$REG" "the analysis did not pass (see $AN)"
  fi
done
python scripts/panel_state.py "$m30" "$P30" > "$O/panel30.txt" 2>&1
python scripts/panel_state.py "$m31" "$P31" --audited "$AUDITS" > "$O/panel31.txt" 2>&1
step status_record30 python scripts/panel_status.py "$O/panel_status30.json" "$O/panel30.txt" "$O/image30_coverage.json" \
    "$O/none.json"
step status_record31 python scripts/panel_status.py "$O/panel_status31.json" "$O/panel31.txt" "$O/fork31_coverage.json" \
    "$O/none.json"
rm -f "${O:?}/evidence.json"
step evidence python scripts/check_evidence.py "$O/evidence.json" \
    "image30:${RC[image30]}:$O/image30:$IMG_FILES" \
    "fork31:${RC[fork31]}:$O/fork31:$FORK_FILES"
if [ -s "$m30" ]; then step manifest_copy30 cp "$m30" "$O/"; else skip manifest_copy30 "no manifest"; fi
if [ -s "$m31" ]; then step manifest_copy31 cp "$m31" "$O/"; else skip manifest_copy31 "no manifest"; fi

# packaging: the archive carries the verdict of every step before it (packaging pending), is verified, then the
# external verdict is final; the archive is rewritten with that final verdict and verified again
verdict "$O/verdict.json" package package_final
REQ=(--require "v65_reports/verdict_steps.txt")
for k in "${ORDER[@]}"; do REQ+=(--require "v65_reports/$k.txt"); done
[ "${RC[manifest_copy30]}" = 0 ] && REQ+=(--require "v65_reports/$(basename "$m30")")
[ "${RC[manifest_copy31]}" = 0 ] && REQ+=(--require "v65_reports/$(basename "$m31")")
[ -f "$O/evidence.json" ] && REQ+=(--require "v65_reports/evidence.json")
for f in panel_status30.json panel_status31.json; do [ -f "$O/$f" ] && REQ+=(--require "v65_reports/$f"); done
for w in 30 31; do
  [ "${RC[checks$w]}" = 0 ] && REQ+=(--require "v65_reports/checks$w.json")
  [ "${RC[reload$w]}" = 0 ] && REQ+=(--require "v65_reports/fresh_reload$w.json")
done
for r in registry30 registry31; do
  [ "${RC[$r]}" = 0 ] && REQ+=(--require "v65_reports/$r.json" --require "v65_reports/$r.csv")
done
[ -f "$O/seed31.json" ] && REQ+=(--require "v65_reports/seed31.json")
[ -f "$O/reuse_check31.json" ] && REQ+=(--require "v65_reports/reuse_check31.json")
if [ "${RC[evidence]}" = 0 ]; then
  for t in image30:$IMG_FILES fork31:$FORK_FILES; do
    [ "${RC[${t%%:*}]}" = 0 ] || continue
    for f in $(echo "${t#*:}" | tr ',' ' '); do
      case " $LARGE " in *" $f "*) continue ;; esac
      REQ+=(--require "v65_reports/${t%%:*}_$f")
    done
  done
fi
INC=(--include v65_reports)
for w in 30 31; do [ -d "$COP_RESULTS/summary$w" ] && INC+=(--include "summary$w"); done
printf '%s\n' "${ORDER[@]}" > "$O/verdict_steps.txt"
step package python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" cop_v65_panel_reports \
    "${INC[@]}" "${REQ[@]}"
verdict "$O/verdict.json" package_final
if [ "${RC[package]}" = 0 ]; then
  step package_final python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" \
      cop_v65_panel_reports "${INC[@]}" "${REQ[@]}"
else
  skip package_final "packaging failed"
  rm -f "$ZIP"
fi
verdict "$O/verdict.json"
[ -f "$ZIP" ] || { echo "no archive at $ZIP"; RC[archive_present]=1; ORDER+=(archive_present); verdict "$O/verdict.json"; }
python -c "import json,sys; sys.exit(0 if json.load(open('$O/verdict.json'))['all_passed'] else 1)"
