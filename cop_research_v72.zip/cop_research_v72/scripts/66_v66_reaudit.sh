#!/usr/bin/env bash
# v66: the saved runs of v64 (wave 29) and v65 (waves 30 and 31) re-audited under the corrected acceptance logic
# (CHANGES_v66.md), and the reset-matched compact controls (wave 32, the only training).
#   wave 32  for every f0 of waves 29 and 30: the compact control continued from its own checkpoint at each fork age
#            with a fresh optimizer for the fork's remaining updates.  The f0s and their parents are copied (v64's
#            panel under the reuse audit, v65's under the current code) and verified by a retrained sample before
#            anything descends from them; 192 new jobs.
#   re-audit fork29 (v64's panel29 + wave 32's MLP controls, through a read-only view), image30 (v65's panel30 +
#            wave 32's image controls), fork31 (v65's panel31), mech31 (gradients and branch regrowth at the saved
#            snapshots), the per-run validity tables, the registries v66_* bound to their coverage, manifest and
#            audits, and each against the earlier reading.  Nothing of v64 or v65 is written.
# A registry reads whatever its analysis wrote; a failed analysis coverage or a failed scientific prerequisite
# (v64's or v65's run, checks, fresh reload, strict summary, reuse verification; v66's tests and wave 32) labels its
# readings diagnostic, never validated.
#
#   cd ~/research/cop_research_v66 && WORKERS=3 COP_VENV=~/fsc/.venv nohup bash scripts/66_v66_reaudit.sh > ~/v66.log 2>&1 &
#
# Zip: cop_v66_reaudit_reports.zip.  A stopped run is continued by running the same command again.
export COP_HOME="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export SCALE="${SCALE:-full}"
if [ "$SCALE" != full ]; then
  echo "v66 needs SCALE=full: it re-audits the full panels.  The tests carry miniatures."
  exit 2
fi
export COP_RESULTS="${COP_RESULTS:-$HOME/cop_results_v66}"
source "$(dirname "$0")/common.sh"
set +e
set +u
ZIP_DIR="${ZIP_DIR:-/mnt/c/Users/Matthew Fried/Downloads}"
[ -d "$ZIP_DIR" ] || ZIP_DIR="$HOME"
COP_PYTEST="${COP_PYTEST:-python -m pytest}"
V64="${V64_RESULTS:-$HOME/cop_results_v64}"
V65="${V65_RESULTS:-$HOME/cop_results_v65}"
O="$COP_RESULTS/v66_reports"
P32="$COP_RESULTS/panel32"
ZIP="$ZIP_DIR/cop_v66_reaudit_reports.zip"
SEED="${SEED:-1}"
AUDITS="$COP_HOME/configs/reuse_audits.json"
mkdir -p "$O" "$P32"
declare -A RC
ORDER=()
step() { local name="$1"; shift; ORDER+=("$name"); echo "=== $(date '+%F %T') $name"; "$@" > "$O/$name.txt" 2>&1
         RC[$name]=$?; echo "=== $name exit ${RC[$name]}"; tail -3 "$O/$name.txt"; }
skip() { ORDER+=("$1"); RC[$1]=99; echo "=== $1 SKIPPED: $2" | tee "$O/$1.txt"; }
verdict() {   # verdict <file> [pending-step ...]
  local f="$1"; shift
  local js="{"
  for k in "${ORDER[@]}"; do js+="\"$k\": ${RC[$k]}, "; done
  js="${js%, }}"
  python - "$f" "$js" "$@" <<'PY'
import json, sys
f, rc, pending = sys.argv[1], json.loads(sys.argv[2]), sys.argv[3:]
json.dump({"steps": rc, "pending": pending, "skipped_code": 99,
           "all_passed": not pending and all(v == 0 for v in rc.values()),
           "completed_steps_passed": all(v == 0 for v in rc.values()),
           "note": "pending steps cannot report inside the archive they write; the launcher's exit status and the "
                   "verdict.json next to the reports are final"}, open(f, "w"), indent=1)
print(json.dumps(rc, indent=1))
PY
}

step environment cop inspect-environment --out "$O/environment.json"
for w in 29 30 31 32; do
  m="$COP_HOME/manifests/wave${w}_${SCALE}.jsonl"
  rm -f "$m"          # a failed generation must not fall through to a stale manifest
  step "manifest$w" cop generate-manifest --wave "$w" --scale "$SCALE" --out "$m"
done
for w in 29 30 31 32; do
  m="$COP_HOME/manifests/wave${w}_${SCALE}.jsonl"
  if [ "${RC[manifest$w]}" = 0 ] && [ -s "$m" ]; then
    step "validate$w" cop validate-manifest --manifest "$m"
  else
    skip "validate$w" "the wave-$w manifest was not generated (see manifest$w)"
  fi
done
m29="$COP_HOME/manifests/wave29_${SCALE}.jsonl"
m30="$COP_HOME/manifests/wave30_${SCALE}.jsonl"
m31="$COP_HOME/manifests/wave31_${SCALE}.jsonl"
m32="$COP_HOME/manifests/wave32_${SCALE}.jsonl"
PRE=0
[ "${RC[environment]}" = 0 ] && PRE=1
for w in 29 30 31 32; do [ "${RC[validate$w]}" = 0 ] || PRE=0; done
if [ "$PRE" = 1 ]; then
  step cpu_tests env CUDA_VISIBLE_DEVICES="" DEVICE=cpu $COP_PYTEST -q -rs tests/ -p no:cacheprovider \
      --junitxml "$O/cpu_tests.xml"
else
  skip cpu_tests "the environment, a manifest or its validation failed"
fi
case "$DEVICE" in cuda|cuda:*) IS_CUDA=1 ;; *) IS_CUDA=0 ;; esac
rm -f "${O:?}/cuda_tests.xml" "${O:?}"/seed32_*.json "${O:?}/reuse_check32.json" "${O:?}/reuse_sample32.jsonl"
READY=0
[ "$PRE" = 1 ] && [ "${RC[cpu_tests]}" = 0 ] && READY=1
if [ "$READY" = 1 ] && [ "$IS_CUDA" = 1 ]; then
  step cuda_tests env DEVICE="$DEVICE" COP_TEST_CUDA_DEVICE="$DEVICE" $COP_PYTEST -q -rs tests/ \
      -k "cuda or gpu_equivalence" --ignore tests/test_v53.py -p no:cacheprovider --junitxml "$O/cuda_tests.xml"
  step cuda_tests_ran python scripts/junit_ran.py "$O/cuda_tests.xml"
  for k in cuda_tests cuda_tests_ran; do [ "${RC[$k]}" = 0 ] || READY=0; done
fi
step data30 python scripts/check_image_data.py "$COP_DATA_ROOT"

# ---- wave 32: the reset-matched compact controls (the only training)
if [ "$READY" = 1 ] || [ "${DIAGNOSTIC_OVERRIDE:-0}" = 1 ]; then
  [ "$READY" = 1 ] || echo "DIAGNOSTIC_OVERRIDE=1: training wave 32 after a failed prerequisite" | tee "$O/override.txt"
  if [ "$SEED" = 1 ]; then
    step seed32_mlp python scripts/seed_panel.py "$m32" "$V64/panel29" "$P32" "$O/seed32_mlp.json" --audited "$AUDITS"
    step seed32_img python scripts/seed_panel.py "$m32" "$V65/panel30" "$P32" "$O/seed32_img.json" --audited "$AUDITS"
  else
    skip seed32_mlp "SEED=0: nothing is copied in this attempt"; RC[seed32_mlp]=0
    skip seed32_img "SEED=0: nothing is copied in this attempt"; RC[seed32_img]=0
  fi
  RS="$COP_RESULTS/reuse_check32"
  VERIFIED=0
  if [ "${RC[seed32_mlp]}" = 0 ] && [ "${RC[seed32_img]}" = 0 ]; then
    step reuse_select32 python scripts/reuse_reproduce.py select "$m32" "$P32" "$O/reuse_sample32.jsonl"
    if [ "${RC[reuse_select32]}" = 5 ]; then
      RC[reuse_select32]=0
      skip reuse_run32 "the panel holds no audited copy: nothing to verify"; RC[reuse_run32]=0
      skip reuse_compare32 "the panel holds no audited copy: nothing to verify"; RC[reuse_compare32]=0
      VERIFIED=1
    elif [ "${RC[reuse_select32]}" = 0 ]; then
      step reuse_run32 cop run --manifest "$O/reuse_sample32.jsonl" --results "$RS" --device "$DEVICE" \
          --data-root "$COP_DATA_ROOT" --workers "$WORKERS" --threads "$THREADS" --resume
      if [ "${RC[reuse_run32]}" = 0 ]; then
        step reuse_compare32 python scripts/reuse_reproduce.py compare "$O/reuse_sample32.jsonl" "$P32" "$RS" \
            "$O/reuse_check32.json"
        [ "${RC[reuse_compare32]}" = 0 ] && VERIFIED=1
      else
        skip reuse_compare32 "the sample did not retrain (see reuse_run32)"
      fi
    else
      skip reuse_run32 "the sample could not be selected (see reuse_select32)"
      skip reuse_compare32 "the sample could not be selected (see reuse_select32)"
    fi
  else
    for k in reuse_select32 reuse_run32 reuse_compare32; do skip "$k" "copying failed (see seed32_mlp, seed32_img)"; done
  fi
  if [ "${RC[seed32_mlp]}" != 0 ] || [ "${RC[seed32_img]}" != 0 ]; then
    skip run32 "copying the parents failed (see seed32_mlp, seed32_img); run again, or use a fresh results folder with SEED=0"
  elif [ "$VERIFIED" != 1 ]; then
    skip run32 "the reuse verification did not pass: nothing that descends from the copies is trained"
  elif [ "${RC[data30]}" != 0 ]; then
    skip run32 "the image data could not be loaded (see data30)"
  else
    step run32 cop run --manifest "$m32" --results "$P32" --device "$DEVICE" --data-root "$COP_DATA_ROOT" \
        --workers "$WORKERS" --threads "$THREADS" --resume
  fi
else
  for k in seed32_mlp seed32_img reuse_select32 reuse_run32 reuse_compare32; do skip "$k" "a prerequisite failed"; done
  skip run32 "a prerequisite failed (environment, manifests, validation or tests); set DIAGNOSTIC_OVERRIDE=1 to run anyway"
fi
WITH32=0
if [ "${RC[run32]}" = 99 ]; then
  for k in status32 checks32 reload32 summary32; do skip "$k" "wave 32 was not trained (see run32)"; done
else
  step status32 cop status --manifest "$m32" --results "$P32"
  if [ "${RC[run32]}" = 0 ]; then
    WITH32=1
    step checks32 python audit_v8/tools/check_results.py "$P32" "$O/checks32.json" --manifest "$m32" \
        --transplants-if-any --diagnostics-if-any
    step reload32 python audit_v5/tools/fresh_reload.py "$P32" "$O/fresh_reload32.json" --device recorded \
        --data-root "$COP_DATA_ROOT"
    step summary32 cop summarize --strict --results "$P32" --manifest "$m32" --out "$COP_RESULTS/summary32"
  else
    for k in checks32 reload32 summary32; do
      skip "$k" "wave 32 did not finish (see run32 and status32); run the same command again to continue"
    done
  fi
fi

# ---- the re-audit: read-only views, analyses, validity tables, registries
FORK_FILES="coverage.json,audits.csv,compute.csv,central.csv,states.csv,states_by_draw.csv,states_summary.csv,contrasts.csv,contrasts_by_draw.csv,contrasts_summary.csv,contrasts_summary_sensitivity.csv,validity.csv"
IMG_FILES="coverage.json,audits.csv,compute.csv,central.csv,states.csv,states_by_draw.csv,states_summary.csv,contrasts.csv,contrasts_by_draw.csv,contrasts_summary.csv,validity.csv"
MECH_FILES="coverage.json,gradients.csv,regrowth.csv"
LARGE="contrasts.csv"
rm -f "${O:?}"/fork29_* "${O:?}"/image30_* "${O:?}"/fork31_* "${O:?}"/mech31_* "${O:?}"/registry2?.* \
    "${O:?}"/registry3?.* "${O:?}"/changes*.csv "${O:?}"/prereq*.txt "${O:?}"/view*.json "${O:?}"/view*_manifest.jsonl
case "$DEVICE" in cuda|cuda:*) FORK_EXTRA=(--recorded-device "$DEVICE") ;; *) FORK_EXTRA=() ;; esac
X32_29=(); X32_30=()
if [ "$WITH32" = 1 ]; then
  X32_29=(--source "$P32" "$m32" --data shortcut)
  X32_30=(--source "$P32" "$m32" --data image_shortcut)
fi
step view29 python scripts/make_view.py "$COP_RESULTS/view29" "$O/view29_manifest.jsonl" "$O/view29.json" \
    --source "$V64/panel29" "$m29" "${X32_29[@]}"
step view30 python scripts/make_view.py "$COP_RESULTS/view30" "$O/view30_manifest.jsonl" "$O/view30.json" \
    --source "$V65/panel30" "$m30" "${X32_30[@]}"
if [ "${RC[view29]}" = 0 ]; then
  step fork29 python audit_v5/tools/fork_continuation.py "$COP_RESULTS/view29" "$O/fork29" \
      --data-root "$COP_DATA_ROOT" --manifest "$O/view29_manifest.jsonl" --strict --device cpu "${FORK_EXTRA[@]}"
else
  skip fork29 "the view could not be built (see view29)"
fi
if [ "${RC[view30]}" = 0 ] && [ "${RC[data30]}" = 0 ]; then
  step image30 python audit_v5/tools/image_forks.py "$COP_RESULTS/view30" "$O/image30" --data-root "$COP_DATA_ROOT" \
      --manifest "$O/view30_manifest.jsonl" --strict --device "$DEVICE" "${FORK_EXTRA[@]}"
else
  skip image30 "the view or the image data is not available (see view30, data30)"
fi
step fork31 python audit_v5/tools/fork_continuation.py "$V65/panel31" "$O/fork31" --data-root "$COP_DATA_ROOT" \
    --manifest "$m31" --strict --device cpu "${FORK_EXTRA[@]}"
step mech31 python audit_v5/tools/mechanism_diagnostics.py "$V65/panel31" "$O/mech31" --data-root "$COP_DATA_ROOT" \
    --manifest "$m31" --strict --device "$DEVICE"
for an in fork29 image30 fork31; do
  if [ -s "$O/${an}_audits.csv" ] && [ -s "$O/${an}_states.csv" ]; then
    step "validity_${an}" python scripts/validity_table.py "$O/$an"
  else
    skip "validity_${an}" "the analysis wrote no audits or states (see $an)"
  fi
done
# the scientific prerequisites of each registry (operational steps such as runtime estimates are not named)
verdict "$O/verdict_now.json" registries
W32_STEPS="cpu_tests,seed32_mlp,seed32_img,reuse_compare32,run32,checks32,reload32,summary32"
step prereq29 python scripts/prereq_status.py "$O/prereq29_failed.txt" \
    "v64=$V64/v64_reports/verdict.json:run29,checks29,reload29,summary29" \
    "v66=$O/verdict_now.json:$([ "$WITH32" = 1 ] && echo "$W32_STEPS" || echo cpu_tests),view29"
step prereq30 python scripts/prereq_status.py "$O/prereq30_failed.txt" \
    "v65=$V65/v65_reports/verdict.json:data30,run30,checks30,reload30,summary30" \
    "v66=$O/verdict_now.json:$([ "$WITH32" = 1 ] && echo "$W32_STEPS" || echo cpu_tests),view30,data30"
step prereq31 python scripts/prereq_status.py "$O/prereq31_failed.txt" \
    "v65=$V65/v65_reports/verdict.json:seed31,reuse_compare31,run31,checks31,reload31,summary31" \
    "v66=$O/verdict_now.json:cpu_tests"
reg() {   # reg <registry step> <analysis> <registry config> <manifest> <prereq file> <old registry json>
  local R="$1" A="$2" CFG="$3" MAN="$4" PF="$5" OLD="$6"
  if [ ! -s "$O/${A}_contrasts.csv" ] || [ ! -s "$O/${A}_coverage.json" ]; then
    skip "$R" "the analysis wrote no contrasts or coverage (see $A)"
    skip "changes_$R" "no registry"
    return
  fi
  local args=(--coverage "$O/${A}_coverage.json" --manifest "$MAN")
  [ -s "$O/${A}_audits.csv" ] && args+=(--audits "$O/${A}_audits.csv")
  if [ -f "$PF" ]; then
    while IFS= read -r ln; do [ -n "$ln" ] && args+=(--prerequisite-failed "$ln"); done < "$PF"
  else
    args+=(--prerequisite-failed "prerequisite status unavailable")
  fi
  step "$R" python scripts/replication_registry.py "$CFG" "$O/${A}_contrasts.csv" "$O/$R" "${args[@]}"
  if [ -s "$O/$R.json" ]; then
    step "changes_$R" python scripts/compare_registries.py "$OLD" "$O/$R.json" "$O/changes_$R.csv"
  else
    skip "changes_$R" "no registry output"
  fi
}
reg registry29 fork29 "$COP_HOME/configs/v66_wave29_registry.json" "$O/view29_manifest.jsonl" "$O/prereq29_failed.txt" \
    "$V64/v64_reports/registry29.json"
reg registry30 image30 "$COP_HOME/configs/v66_image_registry.json" "$O/view30_manifest.jsonl" "$O/prereq30_failed.txt" \
    "$V65/v65_reports/registry30.json"
reg registry31 fork31 "$COP_HOME/configs/v66_mechanism_registry.json" "$m31" "$O/prereq31_failed.txt" \
    "$V65/v65_reports/registry31.json"
python scripts/panel_state.py "$m32" "$P32" --audited "$AUDITS" > "$O/panel32.txt" 2>&1
rm -f "${O:?}/evidence.json"
step evidence python scripts/check_evidence.py "$O/evidence.json" \
    "fork29:${RC[fork29]}:$O/fork29:$FORK_FILES" \
    "image30:${RC[image30]}:$O/image30:$IMG_FILES" \
    "fork31:${RC[fork31]}:$O/fork31:$FORK_FILES" \
    "mech31:${RC[mech31]}:$O/mech31:$MECH_FILES"
for w in 29 30 31 32; do
  m="$COP_HOME/manifests/wave${w}_${SCALE}.jsonl"
  if [ -s "$m" ]; then step "manifest_copy$w" cp "$m" "$O/"; else skip "manifest_copy$w" "no manifest"; fi
done

# packaging: the archive carries the verdict of every step before it (packaging pending), is verified, then the
# external verdict is final; the archive is rewritten with that final verdict and verified again
verdict "$O/verdict.json" package package_final
REQ=(--require "v66_reports/verdict_steps.txt")
for k in "${ORDER[@]}"; do REQ+=(--require "v66_reports/$k.txt"); done
for w in 29 30 31 32; do
  [ "${RC[manifest_copy$w]}" = 0 ] && REQ+=(--require "v66_reports/wave${w}_${SCALE}.jsonl")
done
[ -f "$O/evidence.json" ] && REQ+=(--require "v66_reports/evidence.json")
[ "${RC[checks32]}" = 0 ] && REQ+=(--require "v66_reports/checks32.json")
[ "${RC[reload32]}" = 0 ] && REQ+=(--require "v66_reports/fresh_reload32.json")
for r in registry29 registry30 registry31; do
  [ -f "$O/$r.json" ] && REQ+=(--require "v66_reports/$r.json" --require "v66_reports/$r.csv")
  [ -f "$O/changes_$r.csv" ] && REQ+=(--require "v66_reports/changes_$r.csv")
done
for f in seed32_mlp.json seed32_img.json reuse_check32.json view29.json view30.json prereq29_failed.txt prereq30_failed.txt \
         prereq31_failed.txt; do
  [ -f "$O/$f" ] && REQ+=(--require "v66_reports/$f")
done
if [ "${RC[evidence]}" = 0 ]; then
  for t in fork29:$FORK_FILES image30:$IMG_FILES fork31:$FORK_FILES mech31:$MECH_FILES; do
    [ "${RC[${t%%:*}]}" = 0 ] || continue
    for f in $(echo "${t#*:}" | tr ',' ' '); do
      case " $LARGE " in *" $f "*) continue ;; esac
      REQ+=(--require "v66_reports/${t%%:*}_$f")
    done
  done
fi
INC=(--include v66_reports)
[ -d "$COP_RESULTS/summary32" ] && INC+=(--include summary32)
printf '%s\n' "${ORDER[@]}" > "$O/verdict_steps.txt"
step package python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" cop_v66_reaudit_reports \
    "${INC[@]}" "${REQ[@]}"
verdict "$O/verdict.json" package_final
if [ "${RC[package]}" = 0 ]; then
  step package_final python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" \
      cop_v66_reaudit_reports "${INC[@]}" "${REQ[@]}"
else
  skip package_final "packaging failed"
  rm -f "$ZIP"
fi
verdict "$O/verdict.json"
[ -f "$ZIP" ] || { echo "no archive at $ZIP"; RC[archive_present]=1; ORDER+=(archive_present); verdict "$O/verdict.json"; }
python -c "import json,sys; sys.exit(0 if json.load(open('$O/verdict.json'))['all_passed'] else 1)"
