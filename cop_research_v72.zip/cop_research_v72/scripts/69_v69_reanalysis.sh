#!/usr/bin/env bash
# v69: re-analysis of the saved runs of v64 (wave 29), v65 (waves 30, 31) and v67 (wave 32), after the second review
# of v68 (CHANGES_v69.md).  Trains nothing; v64's, v65's and v67's folders are only read.
#   preflight  the independent reference certifies a declared set of real checkpoints first (selected from v67's
#              states tables: the most harmful and the median f0, both fork points, every continuation, the saved
#              swap / shift starts and ends, the most ill-conditioned edit), with no table comparison yet.  A failed
#              or incomplete preflight stops here (FORCE=1 continues); the reports are packaged for diagnosis
#   analyses   fork29, image30, fork31, mech31 (every f0 of the design, every promised path point), validity tables
#   reference  the same plan again with the new states tables (table certificates on the analysis's device)
#   registries bound to tables, coverage, manifest and audits; a state the reference did not certify is excluded
#              from the rows that depend on it (conditional); an incomplete reference, a failed mech31 or any failed
#              scientific prerequisite (tests, CUDA tests by name, source checks) makes the registry diagnostic
#
#   cd ~/research/cop_research_v69 && COP_VENV=~/fsc/.venv nohup bash scripts/69_v69_reanalysis.sh > ~/v69.log 2>&1 &
#
# Zip: cop_v69_reanalysis_reports.zip.  A clean exit of the packaging step means the archive was written; the
# scientific outcome is verdict.json and each registry's statuses.
export COP_HOME="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export SCALE="${SCALE:-full}"
if [ "$SCALE" != full ]; then
  echo "v69 needs SCALE=full: it re-analyses the full panels.  The tests carry miniatures."
  exit 2
fi
export COP_RESULTS="${COP_RESULTS:-$HOME/cop_results_v69}"
source "$(dirname "$0")/common.sh"
set +e
set +u
ZIP_DIR="${ZIP_DIR:-/mnt/c/Users/Matthew Fried/Downloads}"
[ -d "$ZIP_DIR" ] || ZIP_DIR="$HOME"
COP_PYTEST="${COP_PYTEST:-python -m pytest}"
V64="${V64_RESULTS:-$HOME/cop_results_v64}"
V65="${V65_RESULTS:-$HOME/cop_results_v65}"
V67="${V67_RESULTS:-$HOME/cop_results_v66}"          # v67 ran the v66 re-audit launcher: its folder keeps that name
O="$COP_RESULTS/v69_reports"
ZIP="$ZIP_DIR/cop_v69_reanalysis_reports.zip"
mkdir -p "$O"
declare -A RC
ORDER=()
step() { local name="$1"; shift; ORDER+=("$name"); echo "=== $(date '+%F %T') $name"; "$@" > "$O/$name.txt" 2>&1
         RC[$name]=$?; echo "=== $name exit ${RC[$name]}"; tail -3 "$O/$name.txt"; }
skip() { ORDER+=("$1"); RC[$1]=99; echo "=== $1 SKIPPED: $2" | tee "$O/$1.txt"; }
na() { ORDER+=("$1"); RC[$1]=0; echo "=== $1 NOT APPLICABLE: $2" | tee "$O/$1.txt"; }
verdict() {   # verdict <file> [pending-step ...]
  local f="$1"; shift
  local js="{"
  for k in "${ORDER[@]}"; do js+="\"$k\": ${RC[$k]}, "; done
  js="${js%, }}"
  python - "$f" "$js" "$@" <<'PY'
import json, sys
f, rc, pending = sys.argv[1], json.loads(sys.argv[2]), sys.argv[3:]
json.dump({"steps": rc, "pending": pending, "skipped_code": 99,
           "all_passed": not pending and all(v == 0 for v in rc.values()),
           "completed_steps_passed": all(v == 0 for v in rc.values()),
           "note": "pending steps cannot report inside the archive they write; the launcher's exit status and the "
                   "verdict.json next to the reports are final"}, open(f, "w"), indent=1)
print(json.dumps(rc, indent=1))
PY
}

step environment cop inspect-environment --out "$O/environment.json"
for w in 29 30 31 32; do
  m="$COP_HOME/manifests/wave${w}_${SCALE}.jsonl"
  rm -f "$m"
  step "manifest$w" cop generate-manifest --wave "$w" --scale "$SCALE" --out "$m"
done
for w in 29 30 31 32; do
  m="$COP_HOME/manifests/wave${w}_${SCALE}.jsonl"
  if [ "${RC[manifest$w]}" = 0 ] && [ -s "$m" ]; then
    step "validate$w" cop validate-manifest --manifest "$m"
  else
    skip "validate$w" "the wave-$w manifest was not generated (see manifest$w)"
  fi
done
m29="$COP_HOME/manifests/wave29_${SCALE}.jsonl"
m30="$COP_HOME/manifests/wave30_${SCALE}.jsonl"
m31="$COP_HOME/manifests/wave31_${SCALE}.jsonl"
m32="$COP_HOME/manifests/wave32_${SCALE}.jsonl"
step cpu_tests env CUDA_VISIBLE_DEVICES="" DEVICE=cpu $COP_PYTEST -q -rs tests/ -p no:cacheprovider \
    --junitxml "$O/cpu_tests.xml"
case "$DEVICE" in cuda|cuda:*) IS_CUDA=1 ;; *) IS_CUDA=0 ;; esac
rm -f "${O:?}/cuda_tests.xml"
if [ "$IS_CUDA" = 1 ]; then
  step cuda_tests env DEVICE="$DEVICE" COP_TEST_CUDA_DEVICE="$DEVICE" $COP_PYTEST -q -rs tests/ \
      -k "cuda or gpu_equivalence" --ignore tests/test_v53.py -p no:cacheprovider --junitxml "$O/cuda_tests.xml"
  step cuda_tests_ran python scripts/junit_ran.py "$O/cuda_tests.xml" 1 \
      --require "test_cuda_float32_against_the_float64_reference:4"
else
  na cuda_tests "DEVICE=$DEVICE: every analysis runs on the CPU"
  na cuda_tests_ran "DEVICE=$DEVICE"
fi
step data30 python scripts/check_image_data.py "$COP_DATA_ROOT"

# ---- views: wave 32's controls enter only when v67 trained them completely
WITH32=$(python - "$V67/v66_reports/verdict.json" <<'PY'
import json, sys
try:
    s = json.load(open(sys.argv[1]))["steps"]
    print(1 if s.get("run32") == 0 else 0)
except Exception:
    print(0)
PY
)
X32_29=(); X32_30=()
if [ "$WITH32" = 1 ]; then
  X32_29=(--source "$V67/panel32" "$m32" --data shortcut)
  X32_30=(--source "$V67/panel32" "$m32" --data image_shortcut)
fi
rm -f "${O:?}"/fork29_* "${O:?}"/image30_* "${O:?}"/fork31_* "${O:?}"/mech31_* "${O:?}"/ref2?_* "${O:?}"/ref3?_* \
    "${O:?}"/pre_ref* \
    "${O:?}"/registry*.json "${O:?}"/registry*.csv "${O:?}"/changes_*.csv "${O:?}"/prereq*_failed.txt \
    "${O:?}"/view*.json "${O:?}"/view*_manifest.jsonl
step view29 python scripts/make_view.py "$COP_RESULTS/view29" "$O/view29_manifest.jsonl" "$O/view29.json" \
    --source "$V64/panel29" "$m29" "${X32_29[@]}"
step view30 python scripts/make_view.py "$COP_RESULTS/view30" "$O/view30_manifest.jsonl" "$O/view30.json" \
    --source "$V65/panel30" "$m30" "${X32_30[@]}"

case "$DEVICE" in cuda|cuda:*) FORK_EXTRA=(--recorded-device "$DEVICE"); XDEV=(--extra-device "$DEVICE") ;;
                  *) FORK_EXTRA=(); XDEV=() ;; esac
# ---- the reference preflight: real checkpoints before hours of analysis (selection from v67's states tables)
P67="$V67/v66_reports"
ref_run() {   # ref_run <step> <panel> <manifest> <states> <select-from> <cases> <device> [extra args]
  local R="$1" P_="$2" M_="$3" ST="$4" SF="$5" C_="$6" D_="$7"; shift 7
  step "$R" python audit_v5/tools/reference_recompute.py "$P_" "$O/$R" --manifest "$M_" --states "$ST" \
      --select-from "$SF" --cases "$C_" --data-root "$COP_DATA_ROOT" --device "$D_" "$@"
}
PRE_OK=1
if [ -s "$P67/fork29_states.csv" ] && [ -s "$P67/image30_states.csv" ] && [ -s "$P67/fork31_states.csv" ] && \
   [ -s "$P67/fork31_audits.csv" ] && [ "${RC[view29]}" = 0 ] && [ "${RC[view30]}" = 0 ]; then
  ref_run pre_ref29 "$COP_RESULTS/view29" "$O/view29_manifest.jsonl" "$P67/fork29_states.csv" \
      "$P67/fork29_states.csv" standard cpu --no-table "${XDEV[@]}"
  ref_run pre_ref30 "$COP_RESULTS/view30" "$O/view30_manifest.jsonl" "$P67/image30_states.csv" \
      "$P67/image30_states.csv" standard "$DEVICE" --no-table
  ref_run pre_ref31 "$V65/panel31" "$m31" "$P67/fork31_states.csv" "$P67/fork31_states.csv" mechanism cpu \
      --no-table --audits "$P67/fork31_audits.csv" "${XDEV[@]}"
  for k in pre_ref29 pre_ref30 pre_ref31; do [ "${RC[$k]}" = 0 ] || PRE_OK=0; done
else
  for k in pre_ref29 pre_ref30 pre_ref31; do skip "$k" "v67's states tables or the views are not available"; done
  PRE_OK=0
fi
GO=1
if [ "$PRE_OK" != 1 ] && [ "${FORCE:-0}" != 1 ]; then
  GO=0
  echo "=== the reference preflight did not pass: the analyses are not run (FORCE=1 runs them anyway)"
fi

# ---- analyses
if [ "$GO" = 1 ]; then
if [ "${RC[view29]}" = 0 ]; then
  step fork29 python audit_v5/tools/fork_continuation.py "$COP_RESULTS/view29" "$O/fork29" \
      --data-root "$COP_DATA_ROOT" --manifest "$O/view29_manifest.jsonl" --strict --device cpu "${FORK_EXTRA[@]}"
else
  skip fork29 "the view could not be built (see view29)"
fi
if [ "${RC[view30]}" = 0 ] && [ "${RC[data30]}" = 0 ]; then
  step image30 python audit_v5/tools/image_forks.py "$COP_RESULTS/view30" "$O/image30" --data-root "$COP_DATA_ROOT" \
      --manifest "$O/view30_manifest.jsonl" --strict --device "$DEVICE" "${FORK_EXTRA[@]}"
else
  skip image30 "the view or the image data is not available (see view30, data30)"
fi
step fork31 python audit_v5/tools/fork_continuation.py "$V65/panel31" "$O/fork31" --data-root "$COP_DATA_ROOT" \
    --manifest "$m31" --strict --device cpu "${FORK_EXTRA[@]}"
step mech31 python audit_v5/tools/mechanism_diagnostics.py "$V65/panel31" "$O/mech31" --data-root "$COP_DATA_ROOT" \
    --manifest "$m31" --strict --device "$DEVICE" --expect-forks snap_1000,snap_2500 --expect-f0 24
for an in fork29 image30 fork31; do
  if [ -s "$O/${an}_audits.csv" ] && [ -s "$O/${an}_states.csv" ]; then
    step "validity_${an}" python scripts/validity_table.py "$O/$an"
  else
    skip "validity_${an}" "the analysis wrote no audits or states (see $an)"
  fi
done
# ---- the reference again, with the new states tables (same selection: v67's tables when present)
sel() { [ -s "$P67/$1" ] && echo "$P67/$1" || echo "$O/$1"; }
if [ -s "$O/fork29_states.csv" ]; then
  ref_run ref29 "$COP_RESULTS/view29" "$O/view29_manifest.jsonl" "$O/fork29_states.csv" "$(sel fork29_states.csv)" \
      standard cpu "${XDEV[@]}"
else skip ref29 "the analysis wrote no states (see fork29)"; fi
if [ -s "$O/image30_states.csv" ]; then
  ref_run ref30 "$COP_RESULTS/view30" "$O/view30_manifest.jsonl" "$O/image30_states.csv" "$(sel image30_states.csv)" \
      standard "$DEVICE"
else skip ref30 "the analysis wrote no states (see image30)"; fi
if [ -s "$O/fork31_states.csv" ]; then
  ref_run ref31 "$V65/panel31" "$m31" "$O/fork31_states.csv" "$(sel fork31_states.csv)" mechanism cpu \
      --audits "$O/fork31_audits.csv" "${XDEV[@]}"
else skip ref31 "the analysis wrote no states (see fork31)"; fi
# a reference that checked its whole plan is complete (exit 0, or 4 with failed rows: those states are excluded)
for r in ref29 ref30 ref31; do
  step "${r}_complete" python -c "import json,sys; sys.exit(0 if json.load(open('$O/${r}_coverage.json')).get('complete') else 1)"
done
else
  for k in fork29 image30 fork31 mech31 validity_fork29 validity_image30 validity_fork31 ref29 ref30 ref31 \
           ref29_complete ref30_complete ref31_complete; do
    skip "$k" "the reference preflight did not pass (see pre_ref29, pre_ref30, pre_ref31)"
  done
fi

# ---- prerequisites and registries
verdict "$O/verdict_now.json" registries
SRC_T="cpu_tests,cuda_tests,cuda_tests_ran"
NOW_T="cpu_tests,cuda_tests,cuda_tests_ran"
W32="cpu_tests,cuda_tests,cuda_tests_ran,seed32_mlp,seed32_img,reuse_compare32,run32,checks32,reload32,summary32"
P29=("v64=$V64/v64_reports/verdict.json:$SRC_T,run29,checks29,reload29,summary29"
     "v69=$O/verdict_now.json:$NOW_T,view29,ref29_complete")
P30=("v65=$V65/v65_reports/verdict.json:$SRC_T,data30,run30,checks30,reload30,summary30"
     "v69=$O/verdict_now.json:$NOW_T,view30,data30,ref30_complete")
if [ "$WITH32" = 1 ]; then
  P29+=("v67=$V67/v66_reports/verdict.json:$W32")
  P30+=("v67=$V67/v66_reports/verdict.json:$W32")
fi
step prereq29 python scripts/prereq_status.py "$O/prereq29_failed.txt" "${P29[@]}"
step prereq30 python scripts/prereq_status.py "$O/prereq30_failed.txt" "${P30[@]}"
step prereq31 python scripts/prereq_status.py "$O/prereq31_failed.txt" \
    "v65=$V65/v65_reports/verdict.json:$SRC_T,seed31,reuse_compare31,run31,checks31,reload31,summary31" \
    "v69=$O/verdict_now.json:$NOW_T,ref29_complete,ref31_complete,mech31"
reg() {   # reg <registry step> <analysis> <registry config> <manifest> <prereq file> <v67 registry> <original registry>
  local R="$1" A="$2" CFG="$3" MAN="$4" PF="$5" OLD67="$6" OLD0="$7"
  if [ ! -s "$O/${A}_contrasts.csv" ] || [ ! -s "$O/${A}_coverage.json" ] || [ ! -s "$O/${A}_audits.csv" ] || \
     [ ! -s "$O/${A}_states.csv" ]; then
    skip "$R" "the analysis wrote no contrasts, coverage, audits or states (see $A)"
    skip "changes_v67_$R" "no registry"
    skip "changes_orig_$R" "no registry"
    return
  fi
  local args=(--coverage "$O/${A}_coverage.json" --manifest "$MAN" --audits "$O/${A}_audits.csv"
              --states "$O/${A}_states.csv")
  local x
  for x in $EXCL; do [ -f "$O/${x}_failed_states.txt" ] && args+=(--exclude-states "$O/${x}_failed_states.txt"); done
  if [ -f "$PF" ]; then
    while IFS= read -r ln; do [ -n "$ln" ] && args+=(--prerequisite-failed "$ln"); done < "$PF"
  else
    args+=(--prerequisite-failed "prerequisite status unavailable")
  fi
  step "$R" python scripts/replication_registry.py "$CFG" "$O/${A}_contrasts.csv" "$O/$R" "${args[@]}"
  if [ -s "$O/$R.json" ]; then
    step "changes_v67_$R" python scripts/compare_registries.py "$OLD67" "$O/$R.json" "$O/changes_v67_$R.csv"
    step "changes_orig_$R" python scripts/compare_registries.py "$OLD0" "$O/$R.json" "$O/changes_orig_$R.csv"
  else
    skip "changes_v67_$R" "no registry output"
    skip "changes_orig_$R" "no registry output"
  fi
}
EXCL="ref29"; reg registry29 fork29 "$COP_HOME/configs/v66_wave29_registry.json" "$O/view29_manifest.jsonl" "$O/prereq29_failed.txt" \
    "$V67/v66_reports/registry29.json" "$V64/v64_reports/registry29.json"
EXCL="ref30"; reg registry30 image30 "$COP_HOME/configs/v66_image_registry.json" "$O/view30_manifest.jsonl" "$O/prereq30_failed.txt" \
    "$V67/v66_reports/registry30.json" "$V65/v65_reports/registry30.json"
EXCL="ref29 ref31"; reg registry31 fork31 "$COP_HOME/configs/v66_mechanism_registry.json" "$m31" "$O/prereq31_failed.txt" \
    "$V67/v66_reports/registry31.json" "$V65/v65_reports/registry31.json"

# ---- evidence and packaging
FORK_FILES="coverage.json,audits.csv,compute.csv,central.csv,states.csv,states_by_draw.csv,states_summary.csv,contrasts.csv,contrasts_by_draw.csv,contrasts_summary.csv,contrasts_summary_sensitivity.csv,validity.csv"
IMG_FILES="coverage.json,audits.csv,compute.csv,central.csv,states.csv,states_by_draw.csv,states_summary.csv,contrasts.csv,contrasts_by_draw.csv,contrasts_summary.csv,validity.csv"
MECH_FILES="coverage.json,gradients.csv,regrowth.csv"
REF_FILES="coverage.json,rows.csv,plan.json"     # (failed_states.txt is empty when every row passed)
LARGE="contrasts.csv"
rm -f "${O:?}/evidence.json"
step evidence python scripts/check_evidence.py "$O/evidence.json" \
    "fork29:${RC[fork29]}:$O/fork29:$FORK_FILES" "image30:${RC[image30]}:$O/image30:$IMG_FILES" \
    "fork31:${RC[fork31]}:$O/fork31:$FORK_FILES" "mech31:${RC[mech31]}:$O/mech31:$MECH_FILES" \
    "ref29:${RC[ref29]}:$O/ref29:$REF_FILES" "ref30:${RC[ref30]}:$O/ref30:$REF_FILES" \
    "ref31:${RC[ref31]}:$O/ref31:$REF_FILES" "pre_ref29:${RC[pre_ref29]}:$O/pre_ref29:$REF_FILES" \
    "pre_ref30:${RC[pre_ref30]}:$O/pre_ref30:$REF_FILES" "pre_ref31:${RC[pre_ref31]}:$O/pre_ref31:$REF_FILES"
for w in 29 30 31 32; do
  m="$COP_HOME/manifests/wave${w}_${SCALE}.jsonl"
  if [ -s "$m" ]; then step "manifest_copy$w" cp "$m" "$O/"; else skip "manifest_copy$w" "no manifest"; fi
done
verdict "$O/verdict.json" package package_final
REQ=(--require "v69_reports/verdict_steps.txt")
for k in "${ORDER[@]}"; do REQ+=(--require "v69_reports/$k.txt"); done
for w in 29 30 31 32; do
  [ "${RC[manifest_copy$w]}" = 0 ] && REQ+=(--require "v69_reports/wave${w}_${SCALE}.jsonl")
done
[ -f "$O/evidence.json" ] && REQ+=(--require "v69_reports/evidence.json")
for r in registry29 registry30 registry31; do
  [ -f "$O/$r.json" ] && REQ+=(--require "v69_reports/$r.json" --require "v69_reports/$r.csv")
  for c in changes_v67 changes_orig; do
    [ -f "$O/${c}_$r.csv" ] && REQ+=(--require "v69_reports/${c}_$r.csv")
  done
done
for f in view29.json view30.json prereq29_failed.txt prereq30_failed.txt prereq31_failed.txt; do
  [ -f "$O/$f" ] && REQ+=(--require "v69_reports/$f")
done
if [ "${RC[evidence]}" = 0 ]; then
  for t in fork29:$FORK_FILES image30:$IMG_FILES fork31:$FORK_FILES mech31:$MECH_FILES ref29:$REF_FILES \
           ref30:$REF_FILES ref31:$REF_FILES pre_ref29:$REF_FILES pre_ref30:$REF_FILES pre_ref31:$REF_FILES; do
    [ "${RC[${t%%:*}]}" = 0 ] || continue
    for f in $(echo "${t#*:}" | tr ',' ' '); do
      case " $LARGE " in *" $f "*) continue ;; esac
      REQ+=(--require "v69_reports/${t%%:*}_$f")
    done
  done
fi
printf '%s\n' "${ORDER[@]}" > "$O/verdict_steps.txt"
step package python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" cop_v69_reanalysis_reports \
    --include v69_reports "${REQ[@]}"
verdict "$O/verdict.json" package_final
if [ "${RC[package]}" = 0 ]; then
  step package_final python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" \
      cop_v69_reanalysis_reports --include v69_reports "${REQ[@]}"
else
  skip package_final "packaging failed"
  rm -f "$ZIP"
fi
verdict "$O/verdict.json"
[ -f "$ZIP" ] || { echo "no archive at $ZIP"; RC[archive_present]=1; ORDER+=(archive_present); verdict "$O/verdict.json"; }
python -c "import json,sys; sys.exit(0 if json.load(open('$O/verdict.json'))['all_passed'] else 1)"
