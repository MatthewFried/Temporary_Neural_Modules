#!/usr/bin/env bash
# v72: the close-out, with release-integrity checks (CHANGES_v72.md).  Report-only: trains nothing, re-analyses
# nothing; reads v70's frozen reports (~/cop_results_v70/v70_reports, never written) and writes
# ~/cop_results_v72/v72_reports:
#   tests72           the close-out scripts' tests (CPU, a few minutes)
#   export29/30/31    registered_pairs: one row per hypothesis, draw and seed (operands, values, eligibility,
#                     exclusion; every operand needs a passing validation record of its kind), checked to reproduce
#                     every registry mean and interval
#   sensitivity       the registered contrasts recomputed from the reference's float64 error counts
#   diagnosis         a look at the one row that exceeded the rounding-error estimate (DIAG=0 skips it)
#   figures           paper figures from the registered pairs and the mechanism diagnostic
#   findings          FINAL_FINDINGS.md, every number with its source; NOT RELEASE-READY (exit 1) if a release check
#                     fails (configs/v72_declared_exceptions.json holds the two declared exceptions)
#   release_manifest  SHA-256 of the code, the v70 and v72 reports and every checkpoint of the three panels
#                     (CKPT=0 leaves the checkpoints out); files still being written are declared exclusions
#   verify_release    every listed code and report file re-hashed on disk, every file the archive delivers checked
#                     against the manifest (in the archive); verify_final repeats it on the final archive (local)
#
#   cd ~/research/cop_research_v72 && COP_VENV=~/fsc/.venv nohup bash scripts/72_v72_closeout.sh > ~/v72.log 2>&1 &
#
# Zip: cop_v72_closeout.zip.  A clean packaging step means the archive was written.
set -uo pipefail
export COP_HOME="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export COP_RESULTS="${COP_RESULTS:-$HOME/cop_results_v72}"
source "$(dirname "$0")/common.sh"
cd "$COP_HOME" || exit 2
set +e
set +u
ZIP_DIR="${ZIP_DIR:-/mnt/c/Users/Matthew Fried/Downloads}"
[ -d "$ZIP_DIR" ] || ZIP_DIR="$HOME"
COP_PYTEST="${COP_PYTEST:-python -m pytest}"
V70RES="${V70_RESULTS:-$HOME/cop_results_v70}"
V70R="$V70RES/v70_reports"
V65="${V65_RESULTS:-$HOME/cop_results_v65}"
O="$COP_RESULTS/v72_reports"
PFX=cop_v72_closeout
ZIP="$ZIP_DIR/$PFX.zip"
mkdir -p "$O"
declare -A RC
ORDER=()
step() { local name="$1"; shift; ORDER+=("$name"); echo "=== $(date '+%F %T') $name"; "$@" > "$O/$name.txt" 2>&1
         RC[$name]=$?; echo "=== $name exit ${RC[$name]}"; tail -3 "$O/$name.txt"; }
skip() { ORDER+=("$1"); RC[$1]=99; echo "=== $1 SKIPPED: $2" | tee "$O/$1.txt"; }
verdict() {   # verdict <file> [pending-step ...]
  local f="$1"; shift
  local js="{"
  for k in "${ORDER[@]}"; do js+="\"$k\": ${RC[$k]}, "; done
  js="${js%, }}"
  python - "$f" "$js" "$@" <<'PY'
import json, sys
f, rc, pending = sys.argv[1], json.loads(sys.argv[2]), sys.argv[3:]
json.dump({"steps": rc, "pending": pending, "skipped_code": 99,
           "all_passed": not pending and all(v == 0 for v in rc.values()),
           "note": "pending steps cannot report inside the archive they write; the verdict.json next to the reports "
                   "is final"}, open(f, "w"), indent=1)
print(json.dumps(rc, indent=1))
PY
}
if [ ! -f "$V70R/verdict.json" ] || [ ! -f "$V70R/registry29.json" ]; then
  echo "no finished v70 reports at $V70R"
  exit 2
fi
rm -f "${O:?}"/*.csv "${O:?}"/*.json "${O:?}"/*.md "${O:?}"/*.txt
rm -rf "${O:?}/figures"
case "$DEVICE" in cuda|cuda:*) XDEV=(--extra-device "$DEVICE") ;; *) XDEV=() ;; esac

step tests72 $COP_PYTEST -q -p no:cacheprovider tests/test_v71.py tests/test_v72.py --junitxml "$O/tests72.xml"
step export29 python scripts/export_registered_pairs.py configs/v66_wave29_registry.json "$V70R/registry29.json" \
    "$V70R/fork29_states.csv" "$V70R/fork29_audits.csv" "$V70R/view29_manifest.jsonl" "$O/registry29" \
    --coverage "$V70R/fork29_coverage.json" --exclude-states "$V70R/ref29_failed_states.txt"
step export30 python scripts/export_registered_pairs.py configs/v66_image_registry.json "$V70R/registry30.json" \
    "$V70R/image30_states.csv" "$V70R/image30_audits.csv" "$V70R/view30_manifest.jsonl" "$O/registry30" \
    --coverage "$V70R/image30_coverage.json" --exclude-states "$V70R/ref30_failed_states.txt"
step export31 python scripts/export_registered_pairs.py configs/v66_mechanism_registry.json "$V70R/registry31.json" \
    "$V70R/fork31_states.csv" "$V70R/fork31_audits.csv" "$V70R/wave31_full.jsonl" "$O/registry31" \
    --coverage "$V70R/fork31_coverage.json" --exclude-states "$V70R/ref29_failed_states.txt" --exclude-states "$V70R/ref31_failed_states.txt"
step sensitivity python scripts/float64_sensitivity.py "$O/float64_sensitivity.csv" \
    --pairs "$O/registry29_pairs.csv" configs/v66_wave29_registry.json \
    --pairs "$O/registry30_pairs.csv" configs/v66_image_registry.json \
    --pairs "$O/registry31_pairs.csv" configs/v66_mechanism_registry.json \
    --ref "$V70R/ref29_rows.csv" --ref "$V70R/ref30_rows.csv" --ref "$V70R/ref31_rows.csv"
FAILED=$(head -1 "$V70R/ref29_failed_states.txt" 2>/dev/null)
if [ "${DIAG:-1}" != 1 ]; then
  skip diagnosis "DIAG=${DIAG}"
elif [ -z "$FAILED" ]; then
  skip diagnosis "no failed reference state in ref29"
else
  step diagnosis python scripts/diagnose_estimate_failure.py "$V70RES/view29" "$V70R/view29_manifest.jsonl" \
      "$O/diagnosis.json" --f0 "${FAILED%%|*}" --state "${FAILED#*|}" --data-root "$COP_DATA_ROOT" "${XDEV[@]}"
fi
step figures python scripts/paper_figures.py "$O/figures" \
    --pairs "$O/registry29_pairs.csv" "$V70R/registry29.json" --pairs "$O/registry30_pairs.csv" "$V70R/registry30.json" \
    --pairs "$O/registry31_pairs.csv" "$V70R/registry31.json" \
    --mech-gradients "$V70R/mech31_gradients.csv" --mech-regrowth "$V70R/mech31_regrowth.csv"
step findings python scripts/final_findings.py "$V70R" "$O" "$O/FINAL_FINDINGS.md" \
    --exceptions configs/v72_declared_exceptions.json
RUNS=()
if [ "${CKPT:-1}" = 1 ]; then
  RUNS=(--runs wave29 "$V70RES/view29" "$V70R/view29_manifest.jsonl" --runs wave30 "$V70RES/view30"
        "$V70R/view30_manifest.jsonl" --runs wave31 "$V65/panel31" "$V70R/wave31_full.jsonl")
fi
MUT=()   # written after the manifest: declared, not listed
for f in "RELEASE_MANIFEST.json:the manifest itself" "release_manifest.txt:the manifest step's own log" \
         "verdict_steps.txt:written at packaging" "verdict.json:rewritten after every step" \
         "package.txt:packaging log" "package_final.txt:packaging log" "verify_release.txt:verification log" \
         "verify_final.txt:verification log"; do
  MUT+=(--exclude "$O" "${f%%:*}" "${f#*:}")
done
step release_manifest python scripts/release_manifest.py "$O/RELEASE_MANIFEST.json" --code "$COP_HOME" \
    --reports "$V70R" --reports "$O" "${MUT[@]}" "${RUNS[@]}" --verdict "$V70R/verdict.json" \
    --statement "v70 completed with two localized validation exceptions (fork31 storage certificate; one ref29 row over the first-order rounding-error estimate); not all checks passed."

verdict "$O/verdict.json" package verify_release package_final verify_final
REQ=(--require v72_reports/FINAL_FINDINGS.md --require v72_reports/float64_sensitivity.csv)
[ -f "$O/RELEASE_MANIFEST.json" ] && REQ+=(--require v72_reports/RELEASE_MANIFEST.json)
for w in 29 30 31; do [ -f "$O/registry${w}_pairs.csv" ] && REQ+=(--require "v72_reports/registry${w}_pairs.csv"); done
printf '%s\n' "${ORDER[@]}" > "$O/verdict_steps.txt"
step package python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" "$PFX" \
    --include v72_reports "${REQ[@]}"
if [ -f "$O/RELEASE_MANIFEST.json" ] && [ "${RC[package]}" = 0 ]; then
  step verify_release python scripts/release_manifest.py verify "$O/RELEASE_MANIFEST.json" --code "$COP_HOME" \
      --zip "$ZIP" "$PFX" "$O"
else
  skip verify_release "no manifest or no archive"
fi
verdict "$O/verdict.json" package_final verify_final
if [ "${RC[package]}" = 0 ]; then
  step package_final python scripts/package_reports.py "$COP_RESULTS" "$ZIP" "$O/verdict.json" "$PFX" \
      --include v72_reports "${REQ[@]}"
else
  skip package_final "packaging failed"
fi
if [ -f "$O/RELEASE_MANIFEST.json" ] && [ "${RC[package_final]}" = 0 ]; then
  step verify_final python scripts/release_manifest.py verify "$O/RELEASE_MANIFEST.json" --code "$COP_HOME" \
      --zip "$ZIP" "$PFX" "$O"
else
  skip verify_final "no manifest or no final archive"
fi
verdict "$O/verdict.json"
python -c "import json,sys; sys.exit(0 if json.load(open('$O/verdict.json'))['all_passed'] else 1)"
