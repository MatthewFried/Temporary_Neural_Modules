"""v34: does every analysis step that reported success have its evidence?  Used by the panel launcher.

  python scripts/check_evidence.py OUT_JSON SPEC [SPEC ...]
  SPEC = <step>:<exit code>:<output prefix>:<file suffix>,<file suffix>,...

For a step that exited 0, every <prefix>_<suffix> must exist and be non-empty (v41: a table written as the analyses'
empty sentinel, a file holding only `empty`, counts as missing), and <prefix>_coverage.json must say passed: true.
A step that failed needs nothing here (its failure is already in the verdict).  The launcher deletes each step's
old outputs before running it, so a file left from an earlier run cannot satisfy this.
Exit 1 on any missing evidence; the report goes to OUT_JSON."""
from __future__ import annotations

import json
import sys
from pathlib import Path


def main() -> int:
    out, specs = sys.argv[1], sys.argv[2:]
    rep, bad = {}, 0
    for sp in specs:
        step, rc, prefix, files = sp.split(":", 3)
        r = {"exit": int(rc), "missing": [], "coverage_passed": None}
        if int(rc) == 0:
            for suf in [f for f in files.split(",") if f]:
                p = Path(f"{prefix}_{suf}")
                if not p.is_file() or p.stat().st_size == 0:
                    r["missing"].append(p.name)
                elif p.stat().st_size < 64 and p.read_text(errors="replace").strip() == "empty":
                    r["missing"].append(f"{p.name} (an empty table)")       # v41: the analyses' empty sentinel
            cp = Path(f"{prefix}_coverage.json")
            try:
                r["coverage_passed"] = bool(json.loads(cp.read_text()).get("passed"))
            except (OSError, ValueError):
                r["coverage_passed"] = False
            r["ok"] = not r["missing"] and r["coverage_passed"]
        else:
            r["ok"] = None                     # the step's own failure is the verdict
        bad += r["ok"] is False
        rep[step] = r
    Path(out).write_text(json.dumps({"steps": rep, "passed": bad == 0}, indent=1))
    print(json.dumps(rep, indent=1))
    return 0 if bad == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
