"""v65: the image panel's data is in place: CIFAR-10 in the data root (downloaded once if missing; torchvision
checks the files) and the image shortcut task of wave 30 loads with its full training set and four input channels.

  python scripts/check_image_data.py DATA_ROOT

Exit 0 when it loads as wave 30 expects, 1 otherwise."""
from __future__ import annotations

import json
import sys


def main(argv=None) -> int:
    a = sys.argv[1:] if argv is None else list(argv)
    if len(a) != 1:
        print(__doc__)
        return 2
    from cop.data.registry import fetch_all, load_bundle
    from cop.orchestration.wave13 import V65_DRAWS, v65_image_cell
    print(json.dumps(fetch_all(a[0], ["cifar10"])))
    cell = v65_image_cell()
    b = load_bundle(cell.data(V65_DRAWS[0]), a[0])
    sizes = {k: len(v) for k, v in b.partitions().items()}
    print(json.dumps({"partitions": sizes, "input": b.input_spec, "layout": b.meta.get("feature_layout")}))
    ok = len(b.train) == int(cell._data["n_train"]) and b.input_spec["x"]["shape"] == [4, 32, 32] and \
        sizes.get("test") == 8000 and sizes.get("shift") == 8000
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
