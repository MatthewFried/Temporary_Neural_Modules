#!/usr/bin/env bash
# Shared settings for all launch scripts.  Override any of these in the environment.
set -euo pipefail
export COP_HOME="${COP_HOME:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
export COP_VENV="${COP_VENV:-$COP_HOME/.venv}"
export COP_RESULTS="${COP_RESULTS:-$HOME/cop_results_v5}"
export COP_DATA_ROOT="${COP_DATA_ROOT:-$HOME/cop_data}"
export DEVICE="${DEVICE:-cuda}"
export WORKERS="${WORKERS:-1}"          # start with 1 GPU worker; raise only after scripts/02 timing
export THREADS="${THREADS:-4}"          # CPU threads per worker (BLAS / torch intra-op)
export SCALE="${SCALE:-full}"           # full | pilot | smoke
export OMP_NUM_THREADS="$THREADS" MKL_NUM_THREADS="$THREADS" OPENBLAS_NUM_THREADS="$THREADS"
export PYTHONPATH="$COP_HOME${PYTHONPATH:+:$PYTHONPATH}"
if [ -f "$COP_VENV/bin/activate" ]; then source "$COP_VENV/bin/activate"; fi
cd "$COP_HOME"
mkdir -p "$COP_RESULTS" "$COP_HOME/manifests"
cop() { python -m cop.cli "$@"; }
run_wave() {   # run_wave <wave-spec> [extra run args...]
  local w="$1"; shift
  local m="$COP_HOME/manifests/wave${w//,/_}_${SCALE}.jsonl"
  cop generate-manifest --wave "$w" --scale "$SCALE" --results "$COP_RESULTS" --out "$m"
  cop validate-manifest --manifest "$m"
  local rc=0
  cop run --manifest "$m" --results "$COP_RESULTS" --device "$DEVICE" --data-root "$COP_DATA_ROOT" \
      --workers "$WORKERS" --threads "$THREADS" --resume "$@" || rc=$?
  cop status --manifest "$m" --results "$COP_RESULTS"
  if [ "$rc" -ne 0 ]; then
    echo "wave $w ended with failed / invalid / stale / interrupted jobs (exit $rc); inspect before continuing." >&2
    if [ "${ALLOW_FAILED_JOBS:-0}" != "1" ]; then exit "$rc"; fi
  fi
}
