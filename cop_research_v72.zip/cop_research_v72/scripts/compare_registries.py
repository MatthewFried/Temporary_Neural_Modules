"""v66 / v68: an earlier registry output against its re-reading.

  python scripts/compare_registries.py OLD_JSON NEW_JSON OUT_CSV

One row per hypothesis key in either, with the earlier and new status, reading, mean, interval (level, low, high),
draw and draw-seed counts, excluded runs and pair digest, and separate change flags:
  changed_status      the status differs (an earlier output without status counts as validated when it was read)
  changed_reading     the verdict word differs (replicated, contrary, inconclusive, nonzero ..., not read)
  changed_estimate    the mean differs by more than 1e-9, or is present in one only
  changed_interval    the interval level or either end differs by more than 1e-9
  changed_membership  the number of draws or draw-seed pairs, the excluded runs or the pair digest differ
  changed_key         the key is new or gone
`changed` is their OR.  The note for every changed row is written by hand from these rows.  A missing OLD_JSON gives
rows with empty earlier columns.  Exit 0 when written, 2 on wrong arguments."""
from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

WORDS = ("nonzero (positive)", "nonzero (negative)", "replicated", "contrary", "inconclusive", "not read")


def core(reading) -> str:
    r = str(reading or "")
    hits = [(r.find(w), w) for w in WORDS if w in r]
    if "not read" in r[:9]:
        return "not read"
    return max(hits)[1] if hits else r   # the last verdict word in the text (prefixes come first)


def _num(x):
    try:
        return None if x is None else float(x)
    except (TypeError, ValueError):
        return None


def _diff(a, b) -> bool:
    a, b = _num(a), _num(b)
    return (a is None) != (b is None) or (a is not None and abs(a - b) > 1e-9)


def main(argv=None) -> int:
    a = sys.argv[1:] if argv is None else list(argv)
    if len(a) != 3:
        print(__doc__)
        return 2
    try:
        old = {r["key"]: r for r in json.loads(Path(a[0]).read_text()).get("results", [])}
    except (OSError, ValueError):
        old = {}
    new = {r["key"]: r for r in json.loads(Path(a[1]).read_text()).get("results", [])}
    rows = []
    for k in list(old) + [k for k in new if k not in old]:
        o, n = old.get(k, {}), new.get(k, {})
        o_status = o.get("status") or ("validated" if o.get("found") else ("" if not o else "not read"))
        flags = {
            "changed_key": k not in old or k not in new,
            "changed_status": o_status != n.get("status", ""),
            "changed_reading": core(o.get("reading")) != core(n.get("reading")),
            "changed_estimate": _diff(o.get("mean_favourable"), n.get("mean_favourable")),
            "changed_interval": any(_diff(o.get(x), n.get(x)) for x in ("interval_level", "interval_low",
                                                                         "interval_high")),
            "changed_membership": (_diff(o.get("n_draws"), n.get("n_draws")) or
                                   _diff(o.get("n_draw_seed_pairs"), n.get("n_draw_seed_pairs")) or
                                   sorted(o.get("excluded") or []) != sorted(n.get("excluded") or []) or
                                   (o.get("pairs_digest") is not None and
                                    o.get("pairs_digest") != n.get("pairs_digest")))}
        rows.append({"key": k, "role": n.get("role", o.get("role")),
                     "old_status": o_status, "old_reading": o.get("reading", ""), "old_mean": o.get("mean_favourable"),
                     "old_level": o.get("interval_level"), "old_low": o.get("interval_low"),
                     "old_high": o.get("interval_high"), "old_n_draws": o.get("n_draws"),
                     "old_pairs": o.get("n_draw_seed_pairs"),
                     "new_status": n.get("status", ""), "new_reading": n.get("reading", ""),
                     "new_mean": n.get("mean_favourable"), "new_level": n.get("interval_level"),
                     "new_low": n.get("interval_low"), "new_high": n.get("interval_high"),
                     "new_n_draws": n.get("n_draws"), "new_pairs": n.get("n_draw_seed_pairs"),
                     "expected_pairs": n.get("expected_pairs"), "found_rows": n.get("found_rows"),
                     "unique_pairs": n.get("unique_pairs"), "finite_rows": n.get("finite_rows"),
                     "excluded_rows": n.get("excluded_rows"), "excluded": " ".join(n.get("excluded") or []),
                     "pairs_digest": n.get("pairs_digest"), **flags, "changed": any(flags.values())})
    with open(a[2], "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]) if rows else ["key"])
        w.writeheader()
        w.writerows(rows)
    print(f"{len(rows)} hypotheses, {sum(r['changed'] for r in rows)} changed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
