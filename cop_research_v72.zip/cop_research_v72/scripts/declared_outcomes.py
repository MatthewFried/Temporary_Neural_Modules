"""v36: after `cop run` exits 1 (some job failed or is invalid): pass only when every manifest job is complete or
ended invalid with a declared outcome of its design (audit_v5/tools/declared.py).  Anything else (failed,
pending, missing, an undeclared invalid job) fails.

  python scripts/declared_outcomes.py MANIFEST RESULTS OUT_JSON"""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "audit_v5/tools"))
from declared import declared_invalid  # noqa: E402


def main() -> int:
    man, res, out = sys.argv[1], Path(sys.argv[2]), sys.argv[3]
    declared, problems, n = [], [], 0
    for line in open(man):
        if not line.strip():
            continue
        e = json.loads(line)
        n += 1
        d = res / "runs" / e["run_id"]
        st = json.load(open(d / "status.json")) if (d / "status.json").exists() else {"status": "missing"}
        if st.get("status") == "complete":
            continue
        why = declared_invalid(d, e.get("cfg"))
        if why:
            declared.append({"run_id": e["run_id"], "reason": why})
        else:
            problems.append({"run_id": e["run_id"], "status": st.get("status"), "reason": str(st.get("reason"))[:300]})
    rep = {"jobs": n, "declared_outcomes": declared, "problems": problems, "passed": not problems}
    Path(out).write_text(json.dumps(rep, indent=1))
    print(json.dumps({"jobs": n, "declared": len(declared), "problems": len(problems)}), problems[:3])
    return 0 if not problems else 1


if __name__ == "__main__":
    sys.exit(main())
