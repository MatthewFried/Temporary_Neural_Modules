"""v71: a bounded look at the one reference row that exceeded the first-order rounding-error estimate.

  python scripts/diagnose_estimate_failure.py RESULTS MANIFEST OUT_JSON --f0 F0 --state PARENT/FORK/STATE
         [--data-root R] [--extra-device cuda]

Loads the state's saved network (no training) and its test set, and records for the example and logit with the largest
|z32 - z64| / estimate on the CPU (the analysis's evaluation batch):
  the float64 reference logits, the CPU and GPU float32 logits, the same example evaluated alone in float32 on the CPU
  (a batch of one: other summation blocking), the estimate per logit, the reference's top-two margin and the
  observed/estimate ratios;
  for every node of the implementation's graph (its own forward with return_nodes, float32 against float64, on the
  batch that holds the example): how many units change sign (an activation pattern change, which the
  first-order estimate does not cover), how many lie within their own float32 error of zero, and the largest
  float32 error relative to the unit's float64 value.
It records whether the excess depends on the evaluation batch and whether an activation sign changes; it does not
establish which caused the excess.  It changes no record.
Exit 0."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "audit_v5" / "tools"))
import torch  # noqa: E402


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("results")
    ap.add_argument("manifest")
    ap.add_argument("out")
    ap.add_argument("--f0", required=True)
    ap.add_argument("--state", required=True)
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--extra-device", default=None)
    a = ap.parse_args(argv)
    import audit_common as AC
    import fork_continuation as FC
    import reference_impl as R
    import selective_reversal as SR
    from cop.graph.graph import GraphNet
    from cop.train.trainer import predict
    FC.CE.numerics_policy(torch.device("cpu"))
    runs = Path(a.results) / "runs"
    mcfg = {json.loads(ln)["run_id"]: json.loads(ln)["cfg"] for ln in open(a.manifest) if ln.strip()}
    parent, fork, state = a.state.split("/")
    J = FC.fork_jobs(mcfg)[a.f0][parent]
    rid = J["forks"][fork][state]
    ep = json.loads((runs / rid / "endpoint.json").read_text())
    ck = SR.ckp(runs / rid, ep["checkpoint"])
    tcfg = AC.job_config(runs, J["traj"], mcfg[J["traj"]])
    b = SR.load_bundle(tcfg["data"], a.data_root, device="cpu")
    test = b.partitions()["test"]
    batch = int((tcfg.get("train") or {}).get("eval_batch", 4096))
    md = ck["model"]
    ref = R.RefNet.from_model_dict(md)
    x64 = test.X["x"].double()
    z64 = R.predictions(ref, x64, 1024)
    E = R.rounding_bounds(ref, x64, 512).clamp(min=1e-300)
    g32 = GraphNet.from_checkpoint(md, "cpu").eval()
    with torch.no_grad():
        z32 = predict(g32, test, batch).double()
    ratio = (z32 - z64).abs() / E
    i, c = divmod(int(ratio.argmax()), ratio.shape[1])
    rec = {"f0": a.f0, "state": a.state, "run_id": rid, "checkpoint": ep["checkpoint"], "n": int(z64.shape[0]),
           "eval_batch": batch, "example": i, "logit": c, "label": int(test.y[i]),
           "z64": z64[i].tolist(), "z32_cpu": z32[i].tolist(), "estimate": E[i].tolist(),
           "ratio_cpu": ratio[i].tolist(), "abs_diff_cpu": (z32[i] - z64[i]).abs().tolist(),
           "rows_over_estimate_cpu": int((ratio > 1).any(dim=1).sum())}
    top = z64[i].topk(2).values
    rec["margin64"] = float(top[0] - top[1])
    rec["decision_64_32"] = [int(z64[i].argmax()), int(z32[i].argmax())]
    with torch.no_grad():
        z1 = predict(g32, test.index(torch.tensor([i])), 1).double()[0]
    rec["z32_cpu_alone"] = z1.tolist()
    rec["ratio_cpu_alone"] = ((z1 - z64[i]).abs() / E[i]).tolist()
    if a.extra_device:
        gx = GraphNet.from_checkpoint(md, "cpu").to(a.extra_device).eval()
        FC.CE.numerics_policy(torch.device(a.extra_device))
        with torch.no_grad():
            zx = predict(gx, test.to(a.extra_device), batch).double().cpu()
        rec["z32_extra"] = zx[i].tolist()
        rec["ratio_extra"] = ((zx[i] - z64[i]).abs() / E[i]).tolist()
    # activation pattern: hooks on every module, float32 against float64, on the batch that holds example i
    s0 = (i // batch) * batch
    sl = {k: v[s0:s0 + batch] for k, v in test.X.items()}
    j = i - s0
    acts = {}
    g64 = GraphNet.from_checkpoint(md, "cpu").double().eval()
    for g, tag, dt in ((g32, "f32", torch.float32), (g64, "f64", torch.float64)):
        nodes = [n for n, nd in g.nodes.items() if nd.op not in ("input",)]
        with torch.no_grad():
            _, vals = g({k: (v.to(dt) if v.is_floating_point() else v) for k, v in sl.items()}, return_nodes=nodes)
        for n, v in vals.items():
            if torch.is_tensor(v) and v.is_floating_point() and v.shape[0] == len(next(iter(sl.values()))):
                acts.setdefault(n, {"op": g.nodes[n].op})[tag] = v[j].detach().double().clone()
    layers = []
    for name, d in acts.items():
        if "f32" not in d or "f64" not in d or d["op"] in ("act", "pool", "maxpool"):
            continue                                  # pre-activations and sums only (a ReLU output's sign is fixed)
        y32, y64 = d["f32"].reshape(-1), d["f64"].reshape(-1)
        err = (y32 - y64).abs()
        layers.append({"node": name, "op": d["op"], "units": int(y64.numel()),
                       "sign_changes": int(((y32 > 0) != (y64 > 0)).sum()),
                       "within_own_error_of_zero": int((y64.abs() <= err).sum()),
                       "min_abs_value64": float(y64.abs().min()),
                       "max_rel_error": float((err / y64.abs().clamp(min=1e-30)).max()),
                       "max_abs_error": float(err.max())})
    rec["layers"] = layers
    rec["sign_changes_total"] = sum(L["sign_changes"] for L in layers)
    Path(a.out).write_text(json.dumps(rec, indent=1))
    print(json.dumps({k: rec[k] for k in ("example", "logit", "ratio_cpu", "rows_over_estimate_cpu", "margin64",
                                          "decision_64_32", "sign_changes_total") if k in rec} |
                     {"ratio_extra": rec.get("ratio_extra"), "ratio_cpu_alone": rec.get("ratio_cpu_alone")}))
    return 0


if __name__ == "__main__":
    sys.exit(main())
