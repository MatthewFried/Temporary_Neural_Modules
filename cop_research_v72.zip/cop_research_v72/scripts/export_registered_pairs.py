"""v71: the registered evidence, one row per hypothesis, data draw and optimizer seed, and a check that it reproduces the
registry.

  python scripts/export_registered_pairs.py REGISTRY_CONFIG REGISTRY_JSON STATES_CSV AUDITS_CSV MANIFEST OUT_PREFIX
         --coverage COVERAGE_JSON [--exclude-states FILE ...] [--label NAME]

For every hypothesis of REGISTRY_CONFIG and every (draw, seed) of its contract: the f0 (from MANIFEST), the operand
states and their values in STATES_CSV (the registry's own rules, replication_registry.operands), the contrast, its
favourable orientation, whether the pair is eligible and, if not, why.  Excluded pairs stay as rows.
v72: every operand must have a passing validation record of its kind (a missing record excludes the pair):
  a fork continuation (a parent at a fork point)   a row in AUDITS_CSV with audit_passed True
  f0                                                the analysis analysed it (COVERAGE analysed_f0 = expected_f0)
                                                    and it is not in COVERAGE failed
  a matched compact (compact_2U, compact_4U)        (parent or its hold, label) in COVERAGE compact_controls
  a reset-matched compact (compact_reset)           (parent or its hold, fork) in COVERAGE compact_reset_controls
  a trajectory end (<arm>/end/trajectory_end)       the arm in COVERAGE design (arms or parents)
and none may be excluded by the reference (--exclude-states).
Then, per hypothesis, the draw means of the eligible pairs are summarised exactly as the registry does (seeds averaged
within a draw; Student t over draws; the primary level from the number of primaries) and compared with REGISTRY_JSON:
mean, 95% interval, the hypothesis's interval, n pairs, n draws and draws favourable must agree to 1e-12.
Writes OUT_PREFIX_pairs.csv and OUT_PREFIX_check.csv.  Exit 0 when every hypothesis reproduces, 1 otherwise."""
from __future__ import annotations

import csv
import json
import math
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import replication_registry as RR  # noqa: E402

TOL = 1e-12


def main(argv=None) -> int:
    a = sys.argv[1:] if argv is None else list(argv)
    excl, label, pos, i, cov_p = [], None, [], 0, None
    while i < len(a):
        if a[i] == "--exclude-states" and i + 1 < len(a):
            excl.append(a[i + 1])
            i += 2
        elif a[i] == "--coverage" and i + 1 < len(a):
            cov_p = a[i + 1]
            i += 2
        elif a[i] == "--label" and i + 1 < len(a):
            label = a[i + 1]
            i += 2
        else:
            pos.append(a[i])
            i += 1
    if len(pos) != 6 or cov_p is None:
        print(__doc__)
        return 2
    cfg_p, res_p, st_p, au_p, man_p, out = pos
    reg = json.loads(Path(cfg_p).read_text())
    res = {r["key"]: r for r in json.loads(Path(res_p).read_text())["results"]}
    S = {(r["f0"], r["parent"], r["fork"], r["state"]): r for r in csv.DictReader(open(st_p))}
    audit_ok = {(r["f0"], f"{r['parent']}/{r['fork']}/{r['state']}"): str(r["audit_passed"]) == "True"
                for r in csv.DictReader(open(au_p))}
    cov = json.loads(Path(cov_p).read_text())
    failed_f0 = {(x.get("f0") if isinstance(x, dict) else str(x)) for x in cov.get("failed") or []}
    f0_ok = cov.get("analysed_f0") is not None and cov.get("analysed_f0") == cov.get("expected_f0")
    compacts = {tuple(x) for x in cov.get("compact_controls") or []}
    compact_resets = {tuple(x) for x in cov.get("compact_reset_controls") or []}
    design = cov.get("design") or {}
    arms = set(design.get("arms") or []) | set(design.get("parents") or [])

    def validation(f0, key):
        """None when the operand has a passing validation record of its kind, else the reason."""
        p_, f_, s_ = key
        hold = p_.split("_")[0]
        if key == ("f0", "f0", "f0"):
            if not f0_ok:
                return "f0: the analysis did not analyse every expected f0"
            return "f0: failed in the analysis" if f0 in failed_f0 else None
        if s_ in ("compact_2U", "compact_4U") and f_ == "compact":
            return None if ((p_, s_) in compacts or (hold, s_) in compacts) else f"{'/'.join(key)}: no compact record"
        if s_ == "compact_reset":
            return None if ((p_, f_) in compact_resets or (hold, f_) in compact_resets) else \
                f"{'/'.join(key)}: no reset-matched compact record"
        if f_ == "end" and s_ == "trajectory_end":
            return None if p_ in arms and f0 not in failed_f0 else f"{'/'.join(key)}: arm not in the analysed design"
        ok_ = audit_ok.get((f0, "/".join(key)))
        if ok_ is None:
            return f"{'/'.join(key)}: no fork audit"
        return None if ok_ else f"{'/'.join(key)}: audit failed"
    ref_bad = set()
    for f_ in excl:
        for ln in open(f_):
            if ln.strip():
                f0_, _, k_ = ln.strip().partition("|")
                ref_bad.add((f0_, k_))
    ident = RR.f0_identity(man_p)
    by_pair = {v: k for k, v in ident.items()}
    con = reg.get("contract") or {}
    grid = [(str(d), str(o)) for d in con.get("data_draws") or [] for o in con.get("optimizer_seeds") or []]
    prim = [h for h in reg["hypotheses"] if h["role"] == "primary"]
    level_p = 1 - 0.05 / max(1, len(prim))
    label = label or Path(res_p).stem
    rows, checks, bad = [], [], 0
    for h in reg["hypotheses"]:
        per = defaultdict(lambda: defaultdict(list))
        n_keep, problems = 0, []
        for d, o in grid:
            f0 = by_pair.get((d, o))
            row = {"registry": label, "key": h["key"], "role": h["role"], "comparison": h["comparison"],
                   "metric": h["metric"], "favourable": h["favourable"], "data_draw": d, "optimizer_seed": o,
                   "f0": f0}
            if f0 is None:
                row.update({"eligible": False, "exclusion": "no f0 for this draw and seed in the manifest"})
                rows.append(row)
                problems.append(f"no f0 for {d}/{o}")
                continue
            keys, why = RR.operands(h, f0, S)
            vals = []
            if not why:
                for j, k_ in enumerate(keys):
                    v, w_ = RR.state_value(S, f0, k_, h["metric"])
                    row[f"operand{j + 1}"] = "/".join(k_)
                    row[f"operand{j + 1}_value"] = v
                    if w_:
                        why = w_
                        break
                    vals.append(v)
            if why:
                row.update({"eligible": False, "exclusion": why})
                rows.append(row)
                problems.append(why)
                continue
            value = RR.combine(h, vals)
            fav = -value if h["favourable"] == "second - first" else value
            reasons = [w_ for w_ in (validation(f0, k_) for k_ in keys) if w_]
            reasons += [f"{'/'.join(k_)}: reference" for k_ in keys if (f0, "/".join(k_)) in ref_bad]
            row.update({"value": value, "favourable_value": fav, "eligible": not reasons,
                        "exclusion": "; ".join(reasons)})
            rows.append(row)
            if not reasons:
                per[d][o].append(fav)
                n_keep += 1
        dm = [sum(sum(x) / len(x) for x in seeds.values()) / len(seeds) for _, seeds in sorted(per.items())]
        r_ = res.get(h["key"], {})
        ck = {"registry": label, "key": h["key"], "role": h["role"], "status": r_.get("status"),
              "n_pairs": n_keep, "registry_n_pairs": r_.get("n_draw_seed_pairs")}
        if dm and not problems:
            s95 = RR.summarise(dm, 0.95)
            sl = RR.summarise(dm, level_p if h["role"] == "primary" else 0.95)
            mine = {"mean_favourable": s95["mean"], "ci95_low": s95["low"], "ci95_high": s95["high"],
                    "interval_low": sl["low"], "interval_high": sl["high"]}
            diffs = {}
            for k_, v in mine.items():
                rv = r_.get(k_)
                ck[k_] = v
                ck["registry_" + k_] = rv
                diffs[k_] = abs(v - rv) if (v is not None and rv is not None) else (0.0 if v == rv else math.inf)
            ck["interval_level"] = level_p if h["role"] == "primary" else 0.95
            ck["n_draws"] = len(dm)
            ck["draws_favourable"] = f"{sum(x > 0 for x in dm)}/{len(dm)}"
            ok = (max(diffs.values()) <= TOL and n_keep == r_.get("n_draw_seed_pairs") and
                  ck["draws_favourable"] == r_.get("draws_favourable") and len(dm) == r_.get("n_draws"))
            ck["max_abs_diff"] = max(diffs.values())
        else:
            ok = False
            ck["problem"] = "; ".join(sorted(set(problems))) or "no eligible pairs"
        ck["reproduces_registry"] = ok
        bad += not ok
        checks.append(ck)
    ocols = ["registry", "key", "role", "comparison", "metric", "favourable", "data_draw", "optimizer_seed", "f0"]
    for j in range(1, 5):
        ocols += [f"operand{j}", f"operand{j}_value"]
    ocols += ["value", "favourable_value", "eligible", "exclusion"]
    with open(f"{out}_pairs.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=ocols, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)
    ccols = ["registry", "key", "role", "status", "reproduces_registry", "max_abs_diff", "n_pairs", "registry_n_pairs",
             "n_draws", "draws_favourable", "interval_level", "mean_favourable", "registry_mean_favourable",
             "ci95_low", "registry_ci95_low", "ci95_high", "registry_ci95_high", "interval_low",
             "registry_interval_low", "interval_high", "registry_interval_high", "problem"]
    with open(f"{out}_check.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=ccols, extrasaction="ignore")
        w.writeheader()
        w.writerows(checks)
    print(json.dumps({"registry": label, "hypotheses": len(checks), "pairs": len(rows),
                      "excluded_pairs": sum(1 for r in rows if not r["eligible"]),
                      "not_reproduced": [c["key"] for c in checks if not c["reproduces_registry"]]}))
    return 0 if bad == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
