"""v71 / v72: FINAL_FINDINGS.md from the frozen v70 reports and the close-out exports.  Every number is read from a
file and its source (file and row key) is printed beside it; the prose around the numbers is fixed, and every
statement about checks is derived from an explicit check (v72).

  python scripts/final_findings.py V70_REPORTS CLOSEOUT_DIR OUT_MD --exceptions DECLARED_EXCEPTIONS_JSON

V70_REPORTS: registry29/30/31.json and .csv, ref29/30/31_rows.csv and _coverage.json, fork29/fork31/image30_audits.csv,
retrain29/30/31.json, mech31_coverage.json, mech31_gradients.csv, cpu_tests.xml, cuda_tests.xml, verdict.json (the local,
final one; else the archive's, one level up).  CLOSEOUT_DIR: registry29/30/31_check.csv (export_registered_pairs),
float64_sensitivity.csv, and diagnosis.json if it was run.
Release checks (v72), each recorded in the document: the per-pair export reproduces every registry; the registries'
recomputation from the states tables found no mismatch and covered every row; every registry status is validated or
conditional, and every conditional exclusion refers to a declared exception; float64 sensitivity found no operand
mismatch; every float64 function, parameter, eligibility and table certificate passed; the failed reference rows and
failed fork audits are exactly the declared exceptions (and a failed reference row failed only the certificates its
declaration allows); every retrained run reproduced; the mechanism diagnostic analysed every expected f0; no test
failed; the verdict's nonzero steps are the declared ones.  The declared exceptions are kept, not repaired.
When a check fails, or an input is missing, the document is written with a NOT RELEASE-READY heading listing the
failures, and the exit code is 1.  Exit 0 only for a release-ready document."""
from __future__ import annotations

import csv
import json
import statistics
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

DOMAIN = {"registry29": "synthetic (MLP, wave 29)", "registry30": "image (CNN, wave 30)",
          "registry31": "mechanism (MLP, wave 31)"}


def pp(x):
    return "n/a" if x is None else f"{100 * x:+.2f}"


def lev(x):
    return f"{round(100 * x, 2):g}%"


def suite(p):
    t = ET.parse(p).getroot()
    s = t if t.tag == "testsuite" else t.find("testsuite")
    return {k: int(s.get(k, 0)) for k in ("tests", "skipped", "failures", "errors")}


def main(argv=None) -> int:
    a = sys.argv[1:] if argv is None else list(argv)
    if len(a) != 5 or a[3] != "--exceptions":
        print(__doc__)
        return 2
    V, W, out = Path(a[0]), Path(a[1]), Path(a[2])
    try:
        declared = json.loads(Path(a[4]).read_text())
        reg_csv = {r: list(csv.DictReader(open(V / f"{r}.csv"))) for r in DOMAIN}
        audits_all = {an: list(csv.DictReader(open(V / f"{an}_audits.csv"))) for an in ("fork29", "image30", "fork31")}
        refcov = {r: json.loads((V / f"{r}_coverage.json").read_text()) for r in ("ref29", "ref30", "ref31")}
        regs = {r: json.loads((V / f"{r}.json").read_text()) for r in DOMAIN}
        checks = {r: list(csv.DictReader(open(W / f"{r}_check.csv"))) for r in DOMAIN}
        sens = list(csv.DictReader(open(W / "float64_sensitivity.csv")))
        refs = {r: list(csv.DictReader(open(V / f"{r}_rows.csv"))) for r in ("ref29", "ref30", "ref31")}
        aud = [r for v in audits_all.values() for r in v if r["audit_passed"] != "True"]
        rt = {w: json.loads((V / f"retrain{w}.json").read_text()) for w in ("29", "30", "31")}
        mcov = json.loads((V / "mech31_coverage.json").read_text())
        grads = list(csv.DictReader(open(V / "mech31_gradients.csv")))
        # the local verdict next to the reports is final (written after packaging); the archive's copy one level up
        # lists package_final as pending
        vp = V / "verdict.json" if (V / "verdict.json").exists() else V.parent / "verdict.json"
        verdict = json.loads(vp.read_text())
        cpu, cuda = suite(V / "cpu_tests.xml"), suite(V / "cuda_tests.xml")
    except (OSError, ValueError, KeyError) as ex:
        out.write_text(f"# NOT RELEASE-READY\n\nA required input is missing or unreadable: {ex}\n")
        print(f"missing or unreadable input: {ex}")
        return 1
    diag = json.loads((W / "diagnosis.json").read_text()) if (W / "diagnosis.json").exists() else None
    # ---------------------------------------------------------------- v72: explicit release checks
    chk = []

    def check(name, ok, detail):
        chk.append((name, bool(ok), detail))
    for r, d in regs.items():
        c_ = checks[r]
        check(f"export reproduces {r}", len(c_) == len(d["results"]) and c_ and
              all(x["reproduces_registry"] == "True" for x in c_),
              f"{sum(x['reproduces_registry'] == 'True' for x in c_)} of {len(d['results'])} hypotheses reproduce "
              f"(`{r}_check.csv`)")
        mism = sum(int(x.get("recomputed_mismatches") or 0) for x in reg_csv[r])
        unrec = sum(x.get("recomputed_rows") != x.get("found_rows") or x.get("recomputed_rows") in (None, "")
                    for x in reg_csv[r])
        check(f"{r} recomputed from the states table", mism == 0 and unrec == 0 and reg_csv[r],
              f"{mism} mismatches, {unrec} hypotheses not fully recomputed (`{r}.csv`)")
    dec_audit = {(x["f0"], x["key"]) for x in declared.get("audit_failures") or []}
    dec_ref = {(x["reference"], x["f0"], x["key"], x["measure"]): set(x.get("allowed_failed_certificates") or [])
               for x in declared.get("reference_rows") or []}
    dec_states = {f"{f0}:{k}" for f0, k in dec_audit} | {f"{f0}:{k}" for _, f0, k, _ in dec_ref}
    bad_status, bad_excl = [], []
    for r, d in regs.items():
        for h in d["results"]:
            if h["status"] not in ("validated", "conditional"):
                bad_status.append(f"{r}:{h['key']} {h['status']}")
            for e in h.get("excluded") or []:
                if not any(e.startswith(ds) for ds in dec_states):
                    bad_excl.append(f"{r}:{h['key']} {e}")
    check("registry statuses", not bad_status, "every status validated or conditional" if not bad_status
          else "; ".join(bad_status))
    check("conditional exclusions are declared exceptions", not bad_excl,
          "every exclusion refers to a declared exception" if not bad_excl else "; ".join(bad_excl[:5]))
    cov_s = [x for x in sens if x["covered"] == "True"]
    om = sum(int(x.get("float32_operand_mismatches") or 0) for x in cov_s)
    check("float64 sensitivity consistent", cov_s and om == 0,
          f"{len(cov_s)} hypotheses covered, {om} float32 operand mismatches (`float64_sensitivity.csv`)")
    allrows = [(k, x) for k, v in refs.items() for x in v]
    f64 = [x.get("function64_ok") for _, x in allrows]
    check("float64 implementation agreement", f64 and all(v_ == "True" for v_ in f64),
          f"{sum(v_ == 'True' for v_ in f64)} of {len(f64)} reference rows (`ref*_rows.csv:function64_ok`)")
    cert = {c_: [x.get(c_) for _, x in allrows if x.get(c_) not in (None, "")]
            for c_ in ("params_ok", "eligibility_ok", "table_ok")}
    check("parameter, eligibility and table certificates", all(all(v_ == "True" for v_ in vs) for vs in cert.values()),
          ", ".join(f"{c_}: {sum(v_ == 'True' for v_ in vs)} of {len(vs)} applicable rows" for c_, vs in cert.items()))
    failed_ref = {(k, x["f0"], f"{x['parent']}/{x['fork']}/{x['state']}", x["measure"]): x for k, x in allrows
                  if x.get("passed") == "False"}
    extra_cert = [f"{k_}: {c_}" for k_, x in failed_ref.items() if k_ in dec_ref for c_ in
                  ("function64_ok", "deployed_ok", "deployed_extra_ok", "params_ok", "eligibility_ok", "table_ok")
                  if x.get(c_) == "False" and c_ not in dec_ref[k_]]
    check("failed reference rows are the declared ones", set(failed_ref) == set(dec_ref) and not extra_cert,
          f"failed {sorted(failed_ref)}; declared {sorted(dec_ref)}" + (f"; undeclared certificates {extra_cert}"
                                                                       if extra_cert else ""))
    failed_aud = {(x["f0"], f"{x['parent']}/{x['fork']}/{x['state']}") for v in audits_all.values() for x in v
                  if x.get("audit_passed") != "True"}
    check("failed fork audits are the declared ones", failed_aud == dec_audit,
          f"failed {sorted(failed_aud)}; declared {sorted(dec_audit)}")
    check("retrained runs reproduce", all(d_.get("reproduced") and d_.get("n_jobs") for d_ in rt.values()),
          f"{sum(d_['n_jobs'] for d_ in rt.values())} runs, {sum(d_['n_checkpoints_compared'] for d_ in rt.values())}"
          " checkpoints (`retrain*.json`)")
    check("mechanism diagnostic complete", mcov.get("analysed_f0") == mcov.get("expected_f0") and mcov.get("passed"),
          f"{mcov.get('analysed_f0')} of {mcov.get('expected_f0')} f0, passed {mcov.get('passed')}")
    check("tests", cpu["tests"] > 0 and cuda["tests"] > 0 and not (cpu["failures"] or cpu["errors"] or
                                                                 cuda["failures"] or cuda["errors"]),
          f"CPU {cpu}, CUDA {cuda}")
    v_steps = verdict.get("steps") or {}
    nz = {k: v for k, v in v_steps.items() if v != 0}
    check("nonzero steps are the declared ones", nz == (declared.get("allowed_nonzero_steps") or {}),
          f"nonzero {nz}; declared {declared.get('allowed_nonzero_steps')}")
    failing = [c_ for c_ in chk if not c_[1]]
    L = (["# NOT RELEASE-READY", "", "These release checks failed; the document below is not a release document:", ""]
         + [f"- {n}: {d_}" for n, _, d_ in failing] + [""] if failing else [])
    L += ["# CoP: final findings (v70 evidence, v72 close-out)", "",
         "Numbers are test-error differences in percentage points, oriented so that a positive value favours the "
         "hypothesis as named (the registry's favourable orientation). One data draw is the unit; the two optimizer "
         "seeds of a draw are averaged first. Intervals are Student t over the 12 draws, at the registry's level: "
         "primary hypotheses at the Bonferroni level of their registry (98.75% for four primaries, 99% for five, "
         "97.5% for two), secondary hypotheses at 95%. Sources: `<registry>.json` result `key`; the per-pair rows "
         "are in `<registry>_pairs.csv` (close-out reports).", "",
         "**Raw extraction** (`extraction`) places the state's first layer, weights and bias, in f0 unchanged. "
         "**Normalised extraction** (`state_at_f0_block_row_norms_f0_bias`) places the state's first-layer weights in "
         "f0 rescaled, per unit and input block, to f0's norms, with f0's first-layer bias; the layout-free variant "
         "(`state_at_f0_block_norms_f0_bias`) uses one scale per input block. Only the normalised measures restore "
         "f0's norms and bias. Both measure the learned first-layer component, not the native accuracy of the trained "
         "network.", ""]

    def table(rows):
        out_ = ["| registry | hypothesis | role | estimate | interval | level | draws favourable | status | source |",
                "|---|---|---|---|---|---|---|---|---|"]
        for reg, h in rows:
            out_.append(f"| {reg} | {h['key']} | {h['role']} | {pp(h.get('mean_favourable'))} | "
                        f"[{pp(h.get('interval_low'))}, {pp(h.get('interval_high'))}] | {lev(h.get('interval_level', 0.95))}"
                        f" | {h.get('draws_favourable')} | {h['status']} | `{reg}.json:{h['key']}` |")
        return out_
    sup, other = [], []
    for reg, d in regs.items():
        for h in d["results"]:
            r_ = h.get("reading", "")
            (sup if ("replicated" in r_ or "nonzero" in r_) else other).append((reg, h))
    L += ["## (a) Supported findings", "",
          "Hypotheses whose interval excludes zero in the favourable direction (replicated) or, for two-sided "
          "mechanism hypotheses, excludes zero (nonzero). Conditional rows rest on 23 of 24 pairs (section c).", ""]
    L += table(sup) + [""]
    L += ["In words, within the tested settings:",
          "- Synthetic: routing during the early continuation lowers the extracted component's error relative to "
          "ordinary continuation; after the late fork, the folded continuation keeps a component advantage over f0, "
          "and over the matched compact continuation (primaries), and over the reset-matched compact continuation "
          "(secondary, 95%).",
          "- Mechanism: swapping function-preserving branches at the early fork changes the extracted component more "
          "under routing than under ordinary gradients (the swap interaction); the swap under routing alone is "
          "nonzero, under ordinary gradients unresolved.",
          "- Image: routing during the early continuation raises the native error of the continued network "
          "(the hypothesis that it worsens the complete network replicates there).", ""]
    L += ["## (b) Contrary and inconclusive findings", "",
          "Contrary: the interval excludes zero against the hypothesis. Inconclusive: it includes zero. Inconclusive "
          "is not evidence of no effect.", ""]
    L += table(other) + [""]
    L += ["In words: in the image setting the synthetic component result reverses (routing raises the extracted "
          "component's error; the folded continuation is worse than f0). Architecture and data change together "
          "between the settings, so these experiments do not identify which change causes the reversal. In the "
          "synthetic setting, the claim that routing worsens the complete network is inconclusive. The full-shift "
          "interaction is inconclusive at its primary level; its unadjusted secondary readings do not promote it.", ""]
    # exceptions
    L += ["## (c) Validation exceptions (kept, not repaired)", ""]
    for r in aud:
        L += [f"1. **Fork audit failure: storage certificate** (`*_audits.csv`, f0 `{r['f0']}`, draw {r['data_draw']}, seed "
              f"{r['optimizer_seed']}, `{r['parent']}/{r['fork']}/{r['state']}`). The saved redistributed start "
              f"differs from the pre-edit network in float64 by {float(r['outcome_redistribution_storage64']):.6g} "
              f"against the declared 1e-5 threshold (condition number "
              f"{float(r['outcome_redistribution_cond']):.6g}; no decision changes). The threshold is not raised. The "
              f"run reproduces on retraining, which does not cancel the failure. " +
              (lambda hit: f"Registered hypotheses that read it (conditional): {hit}." if hit else
               "No registered hypothesis reads this state.")(
                  [f"{reg}:{h['key']}" for reg, d in regs.items() for h in d["results"]
                   if any(f"{r['parent']}/{r['fork']}/{r['state']}" in e and r["f0"] in e
                          for e in h.get("excluded") or [])])]
    bad = [(k, x) for k, rows in refs.items() for x in rows if x.get("passed") == "False"]
    for k, x in bad:
        L += [f"1. **First-order rounding-estimate exceedance** (`{k}_rows.csv`, f0 `{x['f0']}`, "
              f"`{x['parent']}/{x['fork']}/{x['state']}`, measure {x['measure']}). On the CPU, "
              f"{x['deployed_violations']} of {x['n']} examples exceed the estimate (worst ratio "
              f"{float(x['deployed_worst']):.4g}); on the GPU the worst ratio is "
              f"{float(x.get('deployed_extra_worst') or 'nan'):.3g}. Float64 implementation and reference agree; "
              f"errors: reference {x['exact_wrong']}, CPU {x['deployed_wrong']}, GPU "
              f"{x.get('deployed_extra_wrong')}; decided-example disagreements {x['disagree_decided']}. The state is "
              f"excluded from the hypotheses that read it."]
    if diag:
        L += [f"   Diagnosis (`diagnosis.json`, no training): example {diag['example']}, logit {diag['logit']}; "
              f"reference margin {diag['margin64']:.4g}; ratio on the CPU {max(diag['ratio_cpu']):.4g}, the same "
              f"example alone {max(diag['ratio_cpu_alone']):.4g}, on the GPU "
              f"{max(diag['ratio_extra']) if diag.get('ratio_extra') else 'not run'}; float32 pre-activations whose "
              f"sign differs from float64 on the way: {diag['sign_changes_total']}. This records a dependence on the "
              "evaluation batch and an activation sign change; it does not establish which caused the excess."]
    cond = [(reg, h) for reg, d in regs.items() for h in d["results"] if h["status"] == "conditional"]
    L += ["", "Conditional hypotheses (the exclusion is kept; restoring them would be a labelled sensitivity "
          "analysis): " + ", ".join(f"`{reg}.json:{h['key']}` ({h.get('n_draw_seed_pairs')} of 24 pairs)"
                                     for reg, h in cond) + ". No primary hypothesis is affected.", ""]
    # numerical assumptions and checks
    L += ["## (d) Numerical assumptions and checks", "",
          "- **Float64 agreement.** In every one of "
          f"{sum(len(v) for v in refs.values())} reference rows the implementation evaluated in float64 agrees with "
          "the independent reference (raw torch, separate code) to 1e-9 (1 + |z|) per logit "
          f"(`ref*_rows.csv:function64_ok`: {sum(x.get('function64_ok') == 'True' for v in refs.values() for x in v)}"
          " true). Parameter and table checks: all applicable rows pass.",
          "- **The rounding estimate is first order, not a bound.** `reference_impl.RefNet.rounding_bound` (name "
          "kept) carries Higham-style local rounding errors (gamma_n per sum) to the logits through the network's "
          "Jacobian at the activation pattern of its own evaluation, in the dtype it was computed in ("
          + ", ".join(f"{k}: {refcov[k].get('bound_dtype')}" for k in refcov) + "). It neglects second-order terms, "
          "ReLU units and max-pool winners that differ between that evaluation and the float32 one, and transform "
          "convolution algorithms (Winograd, FFT); the factor 1.01 is not a proof. It is an empirical "
          "consistency check; v69's fixed 1e-4 (1 + |z|) tolerance, which ignored conditioning, is reported in the "
          "same rows (`fixed1e4_*`). Neither is an arbiter of implementation correctness.",
          "- **Effect of evaluation rounding on the results.** Across all reference rows the float32 and float64 "
          "error counts differ by at most "
          + str(max(abs(int(x['exact_wrong']) - int(x['deployed_wrong'])) for v in refs.values() for x in v
                    if x.get('exact_wrong') not in (None, ''))) +
          " example(s). Recomputing the registered contrasts from the reference's float64 error counts "
          f"(`float64_sensitivity.csv`): {sum(r['covered'] == 'True' for r in sens)} hypotheses fully covered, "
          f"including {sum(r['covered'] == 'True' and r['role'] == 'primary' for r in sens)} primaries; readings "
          f"changed: {sum(r.get('reading_changes') == 'True' for r in sens)}; largest change of a mean: "
          f"{max(abs(float(r['mean_change'])) for r in sens if r['covered'] == 'True'):.2g} (as a fraction). "
          "Hypotheses with compact or late-head operands are not covered (the reference did not evaluate those "
          "runs) and no float64 number is claimed for them.",
          "- **Where the estimate is large.** On the most ill-conditioned states (wave 31 shift and swap "
          "continuations especially) the estimate approaches or exceeds the logits' size and many examples are "
          "undecided, so the decision check says little there; the error-count comparison above is the evidence.",
          ""]
    rows_ok = all(c["reproduces_registry"] == "True" for v in checks.values() for c in v)
    L += ["## Validation record", "",
          f"- Tests: CPU {cpu['tests']} collected, {cpu['tests'] - cpu['skipped'] - cpu['failures'] - cpu['errors']}"
          f" passed, {cpu['skipped']} skipped (CUDA-only); CUDA {cuda['tests']} collected, "
          f"{cuda['tests'] - cuda['skipped'] - cuda['failures'] - cuda['errors']} passed, {cuda['skipped']} skipped "
          "(`cpu_tests.xml`, `cuda_tests.xml`; the named optimizer and rounding-estimate GPU cases are required).",
          f"- Reference: every f0 of each wave ({', '.join(f'{k}: {len(v)} rows' for k, v in refs.items())}); "
          f"{sum(x.get('passed') == 'True' for v in refs.values() for x in v)} of "
          f"{sum(len(v) for v in refs.values())} pass every row criterion. Rows are measurements, not replications.",
          f"- Retrained from scratch and compared value by value: "
          f"{sum(d['n_jobs'] for d in rt.values())} runs, {sum(d['n_checkpoints_compared'] for d in rt.values())} "
          f"checkpoints, all identical: {all(d['reproduced'] for d in rt.values())} (`retrain*.json`). This is "
          "repeatability; agreement with the definitions is the reference's.",
          f"- Mechanism diagnostic: {mcov.get('analysed_f0')} of {mcov.get('expected_f0')} f0, "
          f"{mcov.get('gradient_rows')} first-update rows, {mcov.get('regrowth_rows')} regrowth rows "
          "(`mech31_coverage.json`).",
          f"- Registries: every value recomputed from the states tables, "
          f"{sum(int(x.get('recomputed_mismatches') or 0) for v in reg_csv.values() for x in v)} mismatches "
          f"(`registry*.csv`); the per-pair export reproduces every registry mean and interval to 1e-12: {rows_ok} "
          "(`registry*_check.csv`).", ""]
    G = [r for r in grads if r["parent"] == "A_routed_affine" and r["fork"] == "snap_1000" and r["edit"] == "swap"]
    prec = "float64" if any(r["precision"] == "float64" for r in G) else "float32"
    G = [r for r in G if r["precision"] == prec]
    def vals(m, k):
        return [float(r[k]) for r in G if r["mode"] == m and r[k] not in ("", None)]
    med = {m: {k: statistics.median(vals(m, k)) for k in ("raw_grad_rel_change", "raw_grad_cos", "disp_trainable_cos")}
           for m in ("ordinary", "routed")}
    mean = {m: {k: statistics.fmean(vals(m, k)) for k in ("raw_grad_rel_change", "raw_grad_cos", "disp_trainable_cos")}
            for m in ("ordinary", "routed")}
    L += ["## Mechanism diagnostics (descriptive)", "",
          f"First update after the swap, early fork, parent A ({prec}; `mech31_gradients.csv`, median over "
          f"{len({r['f0'] for r in G})} f0 and the prescribed batches): first-layer gradient relative change "
          f"{med['ordinary']['raw_grad_rel_change']:.3g} (ordinary) and {med['routed']['raw_grad_rel_change']:.3g} "
          f"(routed); gradient cosine {med['ordinary']['raw_grad_cos']:.3g} and {med['routed']['raw_grad_cos']:.3g}; "
          f"update cosine {med['ordinary']['disp_trainable_cos']:.3g} and {med['routed']['disp_trainable_cos']:.3g} "
          f"(routed means: relative change {mean['routed']['raw_grad_rel_change']:.3g}, gradient cosine "
          f"{mean['routed']['raw_grad_cos']:.3g}, update cosine {mean['routed']['disp_trainable_cos']:.3g}; the routed "
          "cosines are bimodal, some near -1). "
          "These describe the learning step; they are not outcome tests. Regrowth after a full shift: see figure S1 "
          "(medians and per-f0 curves); regrowth shows the branches are used again, not that they are necessary.", ""]
    n_exc = len(dec_audit) + len(dec_ref)
    L += ["## Release checks", ""] + [f"- {'pass' if ok_ else 'FAIL'}: {n}: {d_}" for n, ok_, d_ in chk] + [""]
    L += ["## Final status", "",
          (f"The v70 run completed with {n_exc} localized validation exceptions, declared in "
           f"`v72_declared_exceptions.json` and kept as recorded; not every check passed. " if not failing else
           "NOT RELEASE-READY: see the failed release checks at the top. ") +
          f"Steps not 0 in the final local verdict (`verdict.json`): {nz}. The archive's own verdict lists "
          "`package_final` as pending because a step cannot report inside the archive it writes; a successful "
          "packaging step means the archive was written, not that the science passed.", ""]
    out.write_text("\n".join(L))
    print(json.dumps({"supported": len(sup), "other": len(other), "declared_exceptions": n_exc,
                      "release_ready": not failing, "failed_checks": [n for n, _, _ in failing]}))
    return 1 if failing else 0


if __name__ == "__main__":
    sys.exit(main())
