"""v71: the registered contrasts recomputed from the reference's float64 error counts.

  python scripts/float64_sensitivity.py OUT_CSV --pairs PAIRS_CSV REGISTRY_CONFIG [--pairs ... CONFIG ...]
         --ref REF_ROWS_CSV [--ref ...]

For every hypothesis whose operands the reference evaluated for EVERY eligible pair (registered_pairs: eligible rows),
each operand's value is replaced by the reference's exact error rate, exact_wrong / n, from the reference row with the
same f0, parent, fork, state and measure (the metric without _test_err); the contrast, the favourable orientation, the
draw-level aggregation and the interval level are the registry's.  The float32 value it replaces is also checked
against the reference row (the registered operand value times n must be the reference's deployed wrong count).  Hypotheses with an operand
the reference did not evaluate (compact controls, the late-head arm) are listed as not covered, with the missing
operand; no float64 number is reported for them.
Exit 0; 1 (v72) when a registered float32 operand disagrees with the reference's deployed count (inconsistent
evidence).  A float64 value that moves a mean or changes a reading is reported (mean_change, reading_changes), not
treated as a failure."""
from __future__ import annotations

import csv
import json
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import replication_registry as RR  # noqa: E402


def reading(sl, two_sided):
    if sl["low"] is not None and sl["low"] > 0:
        return "nonzero (positive)" if two_sided else "replicated"
    if sl["high"] is not None and sl["high"] < 0:
        return "nonzero (negative)" if two_sided else "contrary"
    return "inconclusive"


def main(argv=None) -> int:
    a = sys.argv[1:] if argv is None else list(argv)
    if not a or a[0].startswith("--"):
        print(__doc__)
        return 2
    out, pairs, refs, i = a[0], [], [], 1
    while i < len(a):
        if a[i] == "--pairs" and i + 2 < len(a):
            pairs.append((a[i + 1], a[i + 2]))
            i += 3
        elif a[i] == "--ref" and i + 1 < len(a):
            refs.append(a[i + 1])
            i += 2
        else:
            print(__doc__)
            return 2
    ref = {}
    for f_ in refs:
        for r in csv.DictReader(open(f_)):
            if r.get("exact_wrong") not in (None, ""):
                ref[(r["f0"], r["parent"], r["fork"], r["state"], r["measure"])] = r
    res = []
    for pf, cfg in pairs:
        reg = json.loads(Path(cfg).read_text())
        prim = [h for h in reg["hypotheses"] if h["role"] == "primary"]
        level_p = 1 - 0.05 / max(1, len(prim))
        rows = [r for r in csv.DictReader(open(pf)) if r["eligible"] == "True"]
        for h in reg["hypotheses"]:
            mine = [r for r in rows if r["key"] == h["key"]]
            meas = h["metric"][:-len("_test_err")] if h["metric"].endswith("_test_err") else h["metric"]
            p32, p64 = defaultdict(lambda: defaultdict(list)), defaultdict(lambda: defaultdict(list))
            missing, f32_mismatch = [], 0
            for r in mine:
                ops = [r[f"operand{j}"] for j in range(1, 5) if r.get(f"operand{j}")]
                v64, v32 = [], []
                for j, op in enumerate(ops):
                    rr = ref.get((r["f0"], *op.split("/"), meas))
                    if rr is None and op == "f0/f0/f0":
                        # f0's first layer placed in f0 is f0 itself: the states table gives f0 its native error for
                        # every first-layer measure, and the reference evaluates f0 natively
                        rr = ref.get((r["f0"], "f0", "f0", "f0", "native"))
                    if rr is None:
                        missing.append(op)
                        break
                    n = int(rr["n"])
                    v64.append(int(rr["exact_wrong"]) / n)
                    f32_mismatch += round(float(r[f"operand{j + 1}_value"]) * n) != int(rr["deployed_wrong"])
                if len(v64) != len(ops):
                    continue
                c64 = RR.combine(h, v64)
                fav = -c64 if h["favourable"] == "second - first" else c64
                p64[r["data_draw"]][r["optimizer_seed"]].append(fav)
                p32[r["data_draw"]][r["optimizer_seed"]].append(float(r["favourable_value"]))
            out_r = {"registry": Path(pf).name.replace("_pairs.csv", ""), "key": h["key"], "role": h["role"],
                     "metric": h["metric"], "eligible_pairs": len(mine)}
            if missing or not mine:
                out_r.update({"covered": False, "missing_operand": sorted(set(o.split("/", 2)[-1] for o in missing))[:4]
                              or "no eligible pairs"})
                res.append(out_r)
                continue
            level = level_p if h["role"] == "primary" else 0.95
            two = h["favourable"] == "two-sided"
            for tag, P in (("float32", p32), ("float64", p64)):
                dm = [sum(sum(x) / len(x) for x in s.values()) / len(s) for _, s in sorted(P.items())]
                sl = RR.summarise(dm, level)
                out_r.update({f"{tag}_mean": sl["mean"], f"{tag}_low": sl["low"], f"{tag}_high": sl["high"],
                              f"{tag}_draws_favourable": f"{sum(x > 0 for x in dm)}/{len(dm)}",
                              f"{tag}_reading": reading(sl, two)})
            out_r.update({"covered": True, "interval_level": level, "float32_operand_mismatches": f32_mismatch,
                          "mean_change": out_r["float64_mean"] - out_r["float32_mean"],
                          "reading_changes": out_r["float64_reading"] != out_r["float32_reading"]})
            res.append(out_r)
    cols = ["registry", "key", "role", "metric", "covered", "missing_operand", "eligible_pairs", "interval_level",
            "float32_mean", "float32_low", "float32_high", "float32_draws_favourable", "float32_reading",
            "float64_mean", "float64_low", "float64_high", "float64_draws_favourable", "float64_reading",
            "mean_change", "reading_changes", "float32_operand_mismatches"]
    with open(out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        w.writerows(res)
    cov = [r for r in res if r["covered"]]
    print(json.dumps({"hypotheses": len(res), "covered": len(cov),
                      "covered_primaries": [f"{r['registry']}:{r['key']}" for r in cov if r["role"] == "primary"],
                      "reading_changes": [r["key"] for r in cov if r["reading_changes"]],
                      "max_abs_mean_change": max((abs(r["mean_change"]) for r in cov), default=None),
                      "float32_operand_mismatches": sum(r["float32_operand_mismatches"] for r in cov)}))
    return 1 if any(r["float32_operand_mismatches"] for r in cov) else 0


if __name__ == "__main__":
    sys.exit(main())
