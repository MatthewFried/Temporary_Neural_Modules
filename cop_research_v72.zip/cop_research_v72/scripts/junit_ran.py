#!/usr/bin/env python3
"""v51: a pytest junit report shows tests that actually RAN and passed.  pytest exits 0 when every selected test
is skipped, so a skipped GPU test would otherwise count as GPU validation.

usage: junit_ran.py REPORT.xml [MIN_TESTS] [--require NAME_PREFIX:COUNT ...]     exit 0 iff tests >= MIN_TESTS
(default 1), no test was skipped, failed or errored, and (v69) at least COUNT test cases named NAME_PREFIX... ran
and passed."""
import json
import sys
import xml.etree.ElementTree as ET


def counts(path) -> dict:
    root = ET.parse(path).getroot()
    suites = [root] if root.tag == "testsuite" else list(root.iter("testsuite"))
    return {k: sum(int(s.get(k, 0) or 0) for s in suites) for k in ("tests", "skipped", "failures", "errors")}


def named(path, prefix: str) -> int:
    """v69: test cases whose name starts with prefix and that ran and passed (no skipped, failure or error child)."""
    root = ET.parse(path).getroot()
    n = 0
    for tc in root.iter("testcase"):
        if str(tc.get("name", "")).startswith(prefix) and \
                not any(ch.tag in ("skipped", "failure", "error") for ch in tc):
            n += 1
    return n


def main(argv) -> int:
    req = []
    args = list(argv)
    while "--require" in args:                                 # v69: --require NAME_PREFIX:COUNT
        i = args.index("--require")
        pre, _, cnt = args[i + 1].rpartition(":")
        req.append((pre, int(cnt)))
        del args[i:i + 2]
    try:
        c = counts(args[1])
    except Exception as ex:                                    # a missing or unreadable report is not a pass
        print(f"junit report unreadable: {ex}")
        return 1
    need = int(args[2]) if len(args) > 2 else 1
    ok = c["tests"] >= need and c["skipped"] == 0 and c["failures"] == 0 and c["errors"] == 0
    got = {p: named(args[1], p) for p, _ in req}
    ok = ok and all(got[p] >= n_ for p, n_ in req)
    print(json.dumps({**c, "min_tests": need, "required": {p: [got[p], n_] for p, n_ in req}, "ran_and_passed": ok}))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
