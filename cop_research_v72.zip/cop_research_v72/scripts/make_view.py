"""v66: a read-only view of one or more finished panels, for an analysis that needs runs of several panels.

  python scripts/make_view.py VIEW_DIR OUT_MANIFEST OUT_JSON --source PANEL MANIFEST [--data NAME] [--source ...]

For every --source, the manifest's entries (only those whose data name is NAME when --data follows it) are taken in
order; VIEW_DIR/runs/<run id> becomes a symbolic link to PANEL/runs/<run id>.  A run id present in an earlier source
keeps that source's link (shared parents: the first panel's original is read, not a copy); the two configurations
must be identical, otherwise the view is refused.  OUT_MANIFEST is the union of the entries (first source's line
for a shared id).  Nothing is copied and no source is written.  A job without a run folder in its source is listed
in OUT_JSON (the analysis reports it); an existing VIEW_DIR is rebuilt from scratch (links only).
Exit 0 when written, 1 on conflicting configurations or a non-link in VIEW_DIR, 2 on wrong arguments."""
from __future__ import annotations

import json
import os
import shutil
import sys
from pathlib import Path


def parse(argv):
    if len(argv) < 6:
        return None
    view, man_out, rec_out = argv[:3]
    srcs, i = [], 3
    while i < len(argv):
        if argv[i] != "--source" or i + 2 >= len(argv):
            return None
        s = {"panel": argv[i + 1], "manifest": argv[i + 2], "data": None}
        i += 3
        if i < len(argv) and argv[i] == "--data":
            if i + 1 >= len(argv):
                return None
            s["data"] = argv[i + 1]
            i += 2
        srcs.append(s)
    return view, man_out, rec_out, srcs


MARK = ".cop_view"


def view_problems(view: Path) -> list:
    """what in an existing view is not a link the view made (never deleted by this tool)."""
    if not view.exists():
        return []
    if not view.is_dir() or view.is_symlink():
        return [f"{view} is not a directory"]
    items = list(view.iterdir())
    if not items:
        return []
    out = []
    if not (view / MARK).is_file():
        out.append(f"{view} has no view marker ({MARK})")
    for q in items:
        if q.name == MARK:
            continue
        if q.name != "runs" or not q.is_dir() or q.is_symlink():
            out.append(f"{q} is not part of a view")
            continue
        out += [f"{r} is not a link" for r in q.iterdir() if not r.is_symlink()]
    return out


def main(argv=None) -> int:
    import tempfile
    p = parse(sys.argv[1:] if argv is None else list(argv))
    if p is None or not p[3]:
        print(__doc__)
        return 2
    if Path(p[0]).is_symlink():                  # v69: checked before resolving, so a link is never followed
        print(f"refused: the view path {p[0]} is a symbolic link", file=sys.stderr)
        return 1
    view, man_out, rec_out, srcs = Path(p[0]).resolve(), Path(p[1]), Path(p[2]), p[3]
    for s_ in srcs:
        sp = Path(s_["panel"]).resolve()
        if view == sp or view in sp.parents or sp in view.parents:
            print(f"refused: the view {view} and the source {sp} overlap", file=sys.stderr)
            return 1
    bad = view_problems(view)
    if bad:
        print("refused: " + "; ".join(bad[:5]), file=sys.stderr)
        return 1
    lines, cfgs, rec, links = [], {}, {"sources": [], "links": 0, "shared": 0, "missing": []}, []
    for s in srcs:
        n_s = 0
        for ln in open(s["manifest"]):
            if not ln.strip():
                continue
            e = json.loads(ln)
            if s["data"] and ((e["cfg"].get("data") or {}).get("name") != s["data"]):
                continue
            rid = e["run_id"]
            if rid in cfgs:
                if json.dumps(cfgs[rid], sort_keys=True) != json.dumps(e["cfg"], sort_keys=True):
                    print(f"refused: {rid} has different configurations in two sources", file=sys.stderr)
                    return 1
                rec["shared"] += 1
                continue
            cfgs[rid] = e["cfg"]
            lines.append(ln.rstrip("\n"))
            n_s += 1
            src = Path(s["panel"]).resolve() / "runs" / rid
            if src.is_dir():
                links.append((rid, src))
            else:
                rec["missing"].append({"run_id": rid, "panel": s["panel"]})
        rec["sources"].append({**s, "entries_taken": n_s})
    view.parent.mkdir(parents=True, exist_ok=True)
    tmp = Path(tempfile.mkdtemp(prefix=view.name + ".building-", dir=view.parent))
    (tmp / "runs").mkdir()
    (tmp / MARK).write_text(json.dumps({"tool": "make_view", "sources": [s["panel"] for s in srcs]}))
    for rid, src in links:
        os.symlink(src, tmp / "runs" / rid, target_is_directory=True)
    rec["links"] = len(links)
    if view.exists():
        old = Path(tempfile.mkdtemp(prefix=view.name + ".old-", dir=view.parent))
        old.rmdir()
        os.rename(view, old)
        os.rename(tmp, view)
        if not view_problems(old):           # links and the marker only: removing them touches no source
            shutil.rmtree(old)
    else:
        os.rename(tmp, view)
    man_out.parent.mkdir(parents=True, exist_ok=True)
    man_out.write_text("\n".join(lines) + "\n")
    rec["entries"] = len(lines)
    rec_out.write_text(json.dumps(rec, indent=1))
    print(json.dumps({k: rec[k] for k in ("entries", "links", "shared")} | {"missing": len(rec["missing"])}))
    return 0


if __name__ == "__main__":
    sys.exit(main())
