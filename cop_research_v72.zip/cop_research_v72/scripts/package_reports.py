"""v20: write the report archive of a launcher run, then verify it.

  python scripts/package_reports.py RESULTS OUT.zip VERDICT.json PREFIX --include SUB [--include SUB ...]
                                    [--require RELPATH ...]

Every file under RESULTS/SUB (no checkpoints; v37: a file of 8 MB or more only when it is a --require member, the
others are listed with their sizes in PREFIX/skipped_large_files.json) goes into OUT.zip under PREFIX/, plus
VERDICT.json as
PREFIX/verdict.json.  The archive is written to a temporary name, re-opened, CRC-checked (testzip), checked
for every --require member (paths relative to RESULTS) and for the verdict member equal to VERDICT.json, and
only then renamed to OUT.zip.  An archive of the same name from an earlier attempt is deleted first, so it can
never stand in for this attempt.  Exit 0 only if all of that succeeded."""
from __future__ import annotations

import argparse
import json
import os
import sys
import zipfile
from pathlib import Path


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("results")
    ap.add_argument("out")
    ap.add_argument("verdict")
    ap.add_argument("prefix")
    ap.add_argument("--include", action="append", default=[])
    ap.add_argument("--require", action="append", default=[])
    a = ap.parse_args(argv)
    res, out, prefix = Path(a.results), Path(a.out), a.prefix
    verdict = json.loads(Path(a.verdict).read_text())
    if out.is_file() or out.is_symlink():
        out.unlink()                                   # a previous attempt's archive is never evidence
    if out.exists():
        print(f"error: {out} exists and is not a file", file=sys.stderr)
        return 3
    tmp = out.with_name(out.name + ".partial")
    if tmp.exists():
        tmp.unlink()
    n = 0
    required = set(a.require)
    skipped = []
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED, allowZip64=True) as z:
        for sub in a.include:
            base = res / sub
            if not base.exists():
                print(f"warning: {base} is missing", file=sys.stderr)
                continue
            for f in sorted(base.rglob("*")):
                if not f.is_file() or f.suffix == ".pt" or f.name == "verdict.json":
                    continue
                rel = f.relative_to(res).as_posix()
                if f.stat().st_size >= 8e6 and rel not in required:
                    skipped.append({"file": rel, "bytes": f.stat().st_size})
                    continue
                z.write(f, f"{prefix}/{rel}")
                n += 1
        if skipped:
            z.writestr(f"{prefix}/skipped_large_files.json", json.dumps(skipped, indent=1))
        z.writestr(f"{prefix}/verdict.json", json.dumps(verdict, indent=1))
    problems = []
    try:
        with zipfile.ZipFile(tmp) as z:
            bad = z.testzip()
            if bad is not None:
                problems.append(f"CRC error in {bad}")
            names = set(z.namelist())
            for r in a.require:
                if f"{prefix}/{r}" not in names:
                    problems.append(f"required member {r} is missing")
            if json.loads(z.read(f"{prefix}/verdict.json")) != verdict:
                problems.append("archived verdict differs from the verdict file")
    except (zipfile.BadZipFile, OSError, KeyError, ValueError) as ex:
        problems.append(f"archive cannot be read: {ex}")
    if problems:
        for p in problems:
            print("error:", p, file=sys.stderr)
        tmp.unlink(missing_ok=True)
        return 2
    os.replace(tmp, out)
    print(f"wrote {out} ({n} report files, {out.stat().st_size // 2 ** 10} KiB), verified"
          + (f"; {len(skipped)} large non-required files listed in skipped_large_files.json" if skipped else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())
