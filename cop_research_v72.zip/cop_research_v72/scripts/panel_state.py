"""v46: the state of an existing results folder against a manifest, so a launcher can analyse an already trained
panel read-only instead of training it again.

  python scripts/panel_state.py MANIFEST RESULTS_PANEL [--audited AUDITS_JSON]

Prints one JSON line and exits:
  0  every manifest job is complete (the panel can be analysed read-only)
  3  some manifest jobs exist but not every one is complete (a run may still be in progress: do not use it)
  4  no manifest job exists there
  6  every job is complete but some were produced by code of other semantics (semantic code hash)
A run id is the hash of the resolved config and the semantics version, so a complete panel written by code with the
same semantics and configs is the panel this manifest describes.  v59 (--audited): a complete run produced by the
earlier semantics an audit (configs/reuse_audits.json) names for the current code, of a kind in the audit's scope,
counts as these semantics for READ-ONLY analysis (exit 0, the count reported); nothing is written to the panel."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from cop.utils import semantic_code_hash  # noqa: E402
import reuse_audit as RA  # noqa: E402


def main(argv=None) -> int:
    argv = sys.argv[1:] if argv is None else list(argv)
    audits = []
    sem = semantic_code_hash()
    if "--audited" in argv:
        i = argv.index("--audited")
        audits = RA.load(argv[i + 1], sem)
        del argv[i:i + 2]
    man, res = argv[0], Path(argv[1])
    counts, n, other_sem, audited = {}, 0, [], {}
    for line in open(man):
        if not line.strip():
            continue
        e = json.loads(line)
        n += 1
        p = res / "runs" / e["run_id"] / "status.json"
        st = json.load(open(p)).get("status", "unknown") if p.exists() else "missing"
        counts[st] = counts.get(st, 0) + 1
        pv = res / "runs" / e["run_id"] / "provenance.json"
        if st != "complete":
            continue
        produced = json.load(open(pv)).get("semantic_hash") if pv.exists() else None
        if produced == sem:
            continue
        au = RA.covering(audits, produced, e["cfg"]) if produced else None
        if au is not None:
            audited[au["id"]] = audited.get(au["id"], 0) + 1
        else:
            other_sem.append(e["run_id"])
    print(json.dumps({"manifest_jobs": n, "by_status": counts, "panel": str(res), "semantic_hash": sem,
                      "complete_with_other_semantics": len(other_sem), "complete_under_audit": audited}))
    if n and counts.get("complete", 0) == n:
        return 6 if other_sem else 0
    if counts.get("missing", 0) == n:
        return 4
    return 3


if __name__ == "__main__":
    sys.exit(main())
