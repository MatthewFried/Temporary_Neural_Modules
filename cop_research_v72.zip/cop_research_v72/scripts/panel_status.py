"""v61 / v63: one record that keeps four things apart: whether the training panel is complete, whether every fork is a
valid instance of its intervention, whether probe transport is certified (float64, decisive; float32, reported),
and whether the analyses completed.  A successful evidence step does not override any of them.

  python scripts/panel_status.py OUT_JSON PANEL_STATE_TXT FORK_COVERAGE_JSON GEOMETRY_COVERAGE_JSON

PANEL_STATE_TXT is the output of scripts/panel_state.py (its last JSON line).  A missing input is reported as
missing.  v63: fork validity is "valid" only with complete audit coverage and no failure ("invalid" with a failure,
"incomplete" otherwise, "unknown" without coverage); transport is reported as valid among the eligible states (or
"no eligible state") and, apart, as complete across every planned affine state.  Exit 0 when the record was
written."""
from __future__ import annotations

import json
import sys
from pathlib import Path


def _last_json(p):
    try:
        for ln in reversed(Path(p).read_text().splitlines()):
            ln = ln.strip()
            if ln.startswith("{"):
                return json.loads(ln)
    except (OSError, ValueError):
        pass
    return None


def _json(p):
    try:
        return json.loads(Path(p).read_text())
    except (OSError, ValueError):
        return None


def main(argv=None) -> int:
    a = sys.argv[1:] if argv is None else list(argv)
    if len(a) != 4:
        print(__doc__)
        return 2
    out, ps, fc, gc = a
    st, fk, ge = _last_json(ps), _json(fc), _json(gc)
    rec = {"training": None, "fork_validity": None, "transport_validity": None, "analysis_completion": None}
    if st is not None:
        n = st.get("manifest_jobs")
        rec["training"] = {"complete": (st.get("by_status") or {}).get("complete") == n and bool(n),
                           "manifest_jobs": n, "by_status": st.get("by_status"),
                           "complete_with_other_semantics": st.get("complete_with_other_semantics"),
                           "complete_under_audit": st.get("complete_under_audit")}
    if fk is not None:
        exp, aud = fk.get("n_expected_forks"), fk.get("n_audited_forks")
        failed = fk.get("n_failed_forks", len(fk.get("audit_failures") or []))
        complete = bool(fk.get("audit_complete")) and bool(exp) and aud == exp
        # v63: every fork valid needs complete coverage AND no failure; incomplete evidence is not validity
        state = ("invalid" if failed else "valid" if complete else "incomplete")
        rec["fork_validity"] = {"state": state, "valid": True if state == "valid" else False if state == "invalid"
                                else None,
                                "expected_forks": exp, "audited_forks": aud, "passed_forks": fk.get("n_passed_forks"),
                                "failed_forks": failed, "audit_complete": complete,
                                "audit_failures": fk.get("audit_failures"),
                                "fold_float32_rule_v60_failures": fk.get("fold_float32_rule_v60_failures"),
                                "fold_precision": fk.get("fold_precision"),
                                "flagged_draws_excluded_in_sensitivity": fk.get(
                                    "flagged_draws_excluded_in_sensitivity")}
    else:
        rec["fork_validity"] = {"state": "unknown", "valid": None, "note": "no fork analysis coverage"}
    if ge is not None:
        c64, c32 = ge.get("transport_certificate") or {}, ge.get("transport_certificate_float32") or {}
        elig, chk, fail = c64.get("eligible") or 0, c64.get("checked") or 0, c64.get("failed") or 0
        # valid among the eligible states, and complete across every planned affine state: two different claims
        among = ("invalid" if fail else "valid" if elig and chk == elig else "no eligible state" if not elig
                 else "incomplete")
        rec["transport_validity"] = {
            "float64": {k: c64.get(k) for k in ("expected", "eligible", "checked", "passed", "failed", "skipped")},
            "float64_among_eligible": among,
            "float64_complete_across_planned": bool(c64.get("expected")) and c64.get("eligible") == c64.get("expected"),
            "float32_reported": {k: c32.get(k) for k in ("checked", "passed", "failed", "valid", "max_disagree_frac",
                                                          "max_abs_err_diff", "max_score_diff")},
            "precision": ge.get("precision"), "whitening_comparable": ge.get("whitening_comparable")}
    else:
        rec["transport_validity"] = {"float64_among_eligible": "unknown", "note": "no geometry coverage"}
    rec["analysis_completion"] = {"fork": None if fk is None else fk.get("analysis_complete"),
                                  "geometry": None if ge is None else ge.get("analysis_complete")}
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    Path(out).write_text(json.dumps(rec, indent=1, default=str))
    print(json.dumps({"training_complete": (rec["training"] or {}).get("complete"),
                      "forks": rec["fork_validity"].get("state"),
                      "transport_among_eligible": rec["transport_validity"].get("float64_among_eligible"),
                      "transport_complete": rec["transport_validity"].get("float64_complete_across_planned"),
                      **{f"analysis_{k}": v for k, v in rec["analysis_completion"].items()}}, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main())
