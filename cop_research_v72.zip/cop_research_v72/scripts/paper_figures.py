"""v71: paper figures from the registered evidence (no new computation of results).

  python scripts/paper_figures.py OUT_DIR --pairs PAIRS_CSV REGISTRY_JSON [--pairs ...] --mech-gradients CSV
         --mech-regrowth CSV

Every contrast is drawn in its raw orientation, first minus second test error in percentage points (negative: the first
named state errs less), with one point per data draw (seeds averaged, eligible pairs only, from registered_pairs) and
the registry's interval at the registry's level, re-oriented when the registry reads the contrast as second - first.
  fig1_component_effects   early routed minus ordinary continuation, synthetic and image: normalised extraction and
                           native error
  fig2_folding_controls    late folded continuation against f0, the matched compact and the reset-matched compact
  fig3_swap_mechanism      the early swap interaction and its two arms; the first update after the swap (gradient
                           relative change and cosine), routed and ordinary, one point per f0
  figS1_regrowth           branch output over input RMS after a full shift, routed and ordinary, per f0 and median
Writes PDF and PNG for each and captions.md.  The extraction panels use normalised extraction: the state's first-layer
weights placed in f0, rescaled per unit and input block to f0's norms, with f0's first-layer bias
(state_at_f0_block_row_norms_f0_bias); raw extraction (weights and bias unchanged) restores neither.  Neither is the
trained network's own accuracy."""
from __future__ import annotations

import csv
import json
import statistics
import sys
from collections import defaultdict
from pathlib import Path

BLUE, ORANGE, INK, MUTED, GRID = "#2a78d6", "#eb6834", "#1f1f1f", "#6b6b6b", "#e4e4e4"
EXTRACT_NOTE = ("Normalised extraction: the state's first-layer weights placed in f0, rescaled per unit and input block "
                "to f0's norms, with f0's first-layer bias (state_at_f0_block_row_norms_f0_bias). Unlike raw "
                "extraction (the state's first layer, weights and bias, placed in f0 unchanged), it restores f0's "
                "norms and bias. Neither is the native accuracy of the trained network.")


def load(pairs: list):
    P, R = defaultdict(list), {}
    for pf, rj in pairs:
        lab = Path(pf).name.replace("_pairs.csv", "")
        for r in csv.DictReader(open(pf)):
            if r["eligible"] == "True":
                P[(lab, r["key"])].append(r)
        for h in json.loads(Path(rj).read_text())["results"]:
            R[(lab, h["key"])] = h
    return P, R


def draws(rows):
    per = defaultdict(list)
    for r in rows:
        per[r["data_draw"]].append(float(r["value"]))
    return [100 * sum(v) / len(v) for _, v in sorted(per.items())]


def interval(h):
    lo, hi, m = h["interval_low"], h["interval_high"], h["mean_favourable"]
    if h["favourable"] == "second - first":
        lo, hi, m = -hi, -lo, -m
    return 100 * m, 100 * lo, 100 * hi, h["interval_level"]


def setup():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 9, "axes.edgecolor": MUTED, "axes.labelcolor": INK, "xtick.color": MUTED,
                         "ytick.color": MUTED, "axes.spines.top": False, "axes.spines.right": False,
                         "figure.facecolor": "white", "axes.facecolor": "white", "savefig.facecolor": "white",
                         "pdf.fonttype": 42})
    return plt


def dot_rows(ax, items, P, R, xlabel):
    """items: [(label, registry label, key, colour)] drawn top to bottom."""
    for y, (name, lab, key, col) in enumerate(reversed(items)):
        h = R[(lab, key)]
        d = draws(P[(lab, key)])
        m, lo, hi, lev = interval(h)
        jit = [y + 0.18 * ((i % 5) - 2) / 2 for i in range(len(d))]
        ax.scatter(d, jit, s=14, color=col, alpha=0.45, linewidths=0, zorder=2)
        ax.plot([lo, hi], [y, y], color=col, lw=2, solid_capstyle="round", zorder=3)
        ax.scatter([m], [y], s=40, color=col, edgecolors="white", linewidths=1.5, zorder=4)
        ax.text(1.05, y, f"{m:+.2f} [{lo:+.2f}, {hi:+.2f}] ({round(100 * lev, 2):g}%)", transform=ax.get_yaxis_transform(),
                ha="left", va="center", fontsize=7.5, color=INK)
    lo_, hi_ = ax.get_xlim()
    ax.set_xlim(lo_, hi_ + 0.06 * (hi_ - lo_))               # room between the last point and the printed estimate
    ax.set_yticks(range(len(items)))
    ax.set_yticklabels([i[0] for i in reversed(items)], color=INK)
    ax.axvline(0, color=MUTED, lw=0.8, zorder=1)
    ax.grid(axis="x", color=GRID, lw=0.6)
    ax.set_axisbelow(True)
    ax.set_xlabel(xlabel)


def save(fig, out, name):
    fig.savefig(out / f"{name}.pdf", bbox_inches="tight")
    fig.savefig(out / f"{name}.png", dpi=200, bbox_inches="tight")


def main(argv=None) -> int:
    a = sys.argv[1:] if argv is None else list(argv)
    if not a:
        print(__doc__)
        return 2
    out = Path(a[0])
    out.mkdir(parents=True, exist_ok=True)
    pairs, grads, regrow, i = [], None, None, 1
    while i < len(a):
        if a[i] == "--pairs":
            pairs.append((a[i + 1], a[i + 2]))
            i += 3
        elif a[i] == "--mech-gradients":
            grads = a[i + 1]
            i += 2
        elif a[i] == "--mech-regrowth":
            regrow = a[i + 1]
            i += 2
        else:
            print(__doc__)
            return 2
    P, R = load(pairs)
    plt = setup()
    cap = {}
    xl = "first minus second test error (percentage points; negative: first errs less)"

    fig, axs = plt.subplots(2, 1, figsize=(6.6, 3.4), sharex=False)
    dot_rows(axs[0], [("synthetic (MLP)", "registry29", "early_routing_improves_normalised_extraction", BLUE),
                      ("image (CNN)", "registry30", "early_routing_improves_normalised_extraction", ORANGE)],
             P, R, "")
    axs[0].set_title("Normalised first-layer extraction: routed minus ordinary continuation (early fork)",
                     fontsize=9, loc="left", color=INK)
    dot_rows(axs[1], [("synthetic (MLP)", "registry29", "early_routing_worsens_the_complete_network", BLUE),
                      ("image (CNN)", "registry30", "early_routing_worsens_the_complete_network", ORANGE)],
             P, R, xl)
    axs[1].set_title("Native error of the continued network: routed minus ordinary", fontsize=9, loc="left", color=INK)
    fig.tight_layout()
    save(fig, out, "fig1_component_effects")
    cap["fig1_component_effects"] = (
        "Early fork (snap_1000), parent A. Points: data draws (two optimizer seeds averaged); bar: the registry's "
        "interval (primary, Bonferroni level shown); dot: mean. Synthetic: routing lowers the extracted component's "
        "error, with no resolved change in native error. Image: routing raises both. " + EXTRACT_NOTE)

    fig, ax = plt.subplots(figsize=(6.6, 3.0))
    dot_rows(ax, [("synthetic: folded - f0", "registry29", "late_folding_retains_a_component_advantage", BLUE),
                  ("synthetic: fork - compact 2U", "registry29", "expansion_history_beats_compact_continuation", BLUE),
                  ("synthetic: fork - reset-matched compact", "registry29",
                   "expansion_history_beats_reset_matched_compact", BLUE),
                  ("image: folded - f0", "registry30", "late_folding_retains_a_component_advantage", ORANGE),
                  ("image: fork - compact 2U", "registry30", "expansion_history_beats_compact_continuation", ORANGE),
                  ("image: fork - reset-matched compact", "registry30", "expansion_history_beats_reset_matched_compact",
                   ORANGE)], P, R, xl)
    ax.set_title("Late fork (snap_2500): normalised extraction against f0 and compact controls", fontsize=9,
                 loc="left", color=INK)
    fig.tight_layout()
    save(fig, out, "fig2_folding_controls")
    cap["fig2_folding_controls"] = (
        "Late fork, parent A, folded continuation (the additions folded into the receiving layer, then trained). "
        "Compact 2U: a compact network continued for the same updates; reset-matched compact: the same with the "
        "optimizer reset at the fork. Primary rows at the Bonferroni level, the reset-matched rows at 95%. " +
        EXTRACT_NOTE)

    fig = plt.figure(figsize=(6.8, 3.6))
    ax = fig.add_axes([0.30, 0.56, 0.45, 0.36])
    dot_rows(ax, [("swap interaction", "registry31", "swap_changes_routed_learning", INK),
                  ("swap under routing", "registry31", "swap_under_routing", BLUE),
                  ("swap under ordinary", "registry31", "swap_under_ordinary_gradients", ORANGE)], P, R,
             "percentage points (normalised extraction)")
    ax.set_title("Early fork, A: (routed swap - routed) - (ordinary swap - ordinary)", fontsize=9, loc="left",
                 color=INK)
    cap_g = ""
    if grads:
        G = [r for r in csv.DictReader(open(grads)) if r["parent"] == "A_routed_affine" and r["fork"] == "snap_1000"
             and r["edit"] == "swap"]
        prec = "float64" if any(r["precision"] == "float64" for r in G) else "float32"
        G = [r for r in G if r["precision"] == prec]
        for k_, (col_name, title) in enumerate((("raw_grad_rel_change", "first-layer gradient: relative change"),
                                                ("raw_grad_cos", "first-layer gradient: cosine"))):
            axg = fig.add_axes([0.08 + 0.47 * k_, 0.10, 0.38, 0.28])
            for x, (mode, col) in enumerate((("ordinary", ORANGE), ("routed", BLUE))):
                v = [float(r[col_name]) for r in G if r["mode"] == mode and r[col_name] not in ("", None)]
                axg.scatter([x + 0.08 * ((i % 5) - 2) for i in range(len(v))], v, s=12, color=col, alpha=0.5,
                            linewidths=0)
                if v:
                    med = statistics.median(v)
                    axg.plot([x - 0.25, x + 0.25], [med, med], color=INK, lw=1.5)
                    axg.text(x + 0.3, med, f"{med:.3g}", fontsize=7, va="center", color=INK)
            axg.set_xticks([0, 1])
            axg.set_xticklabels(["ordinary", "routed"], color=INK)
            axg.set_xlim(-0.6, 1.9)
            axg.set_title(title, fontsize=8.5, loc="left", color=INK)
            axg.grid(axis="y", color=GRID, lw=0.6)
            axg.set_axisbelow(True)
        cap_g = (f" Lower panels: the first update after the swap ({prec}), one point per f0; line: median. Under "
                 "ordinary gradients the swap leaves the first-layer gradient unchanged; under routing it changes it.")
    save(fig, out, "fig3_swap_mechanism")
    cap["fig3_swap_mechanism"] = (
        "Upper: the swap of function-preserving branches at the early fork, parent A; interaction at its primary "
        "level, arms at 95%." + cap_g + " " + EXTRACT_NOTE)

    if regrow:
        G = [r for r in csv.DictReader(open(regrow)) if r["parent"] == "A_routed_affine" and r["fork"] == "snap_1000"
             and r["continuation"] in ("routed_shift100", "ordinary_shift100")]
        fig, ax = plt.subplots(figsize=(6.0, 3.0))
        for cont, col, name in (("ordinary_shift100", ORANGE, "ordinary"), ("routed_shift100", BLUE, "routed")):
            per = defaultdict(list)
            for r in G:
                if r["continuation"] == cont and r["net_over_input"] not in ("", None) and int(r["update"]) > 0:
                    per[r["f0"]].append((int(r["update"]), float(r["net_over_input"])))
            ups = sorted({u for v in per.values() for u, _ in v})
            for v in per.values():
                v.sort()
                ax.plot([u for u, _ in v], [y for _, y in v], color=col, lw=0.6, alpha=0.3)
            med = [statistics.median([y for vv in per.values() for u, y in vv if u == u0]) for u0 in ups]
            ax.plot(ups, med, color=col, lw=2, label=f"{name} (median)")
            if ups:
                ax.text(ups[-1], med[-1], f"  {name} {med[-1]:.3g}", fontsize=7.5, va="center", color=INK)
        ax.set_yscale("log")
        ax.set_xlabel("updates after the full shift")
        ax.set_ylabel("net branch output / input RMS")
        ax.legend(frameon=False, fontsize=8)
        ax.grid(color=GRID, lw=0.6)
        ax.set_axisbelow(True)
        ax.set_title("Regrowth of the zeroed branches (early fork, A)", fontsize=9, loc="left", color=INK)
        fig.tight_layout()
        save(fig, out, "figS1_regrowth")
        cap["figS1_regrowth"] = ("The branches are exactly zero at the shift (update 0, not drawn on the log scale). "
                                 "Thin lines: one f0 each; bold: median over f0 (log scale; the means are dominated by "
                                 "a few large values). Regrowth shows the branches are used again; it does not show "
                                 "that they are necessary.")
    (out / "captions.md").write_text("".join(f"**{k}.** {v}\n\n" for k, v in cap.items()))
    print(json.dumps({"figures": sorted(cap)}))
    return 0


if __name__ == "__main__":
    sys.exit(main())
