"""v66: the scientific prerequisites of a registry reading that did not pass.

  python scripts/prereq_status.py OUT_TXT LABEL=VERDICT_JSON:STEP[,STEP...] [...]

For every LABEL=VERDICT_JSON:STEPS, each named step whose exit code in the verdict's "steps" is not 0 (a skipped step,
code 99, included), or that the verdict does not hold, is written to OUT_TXT as "LABEL:STEP (code)", one per line; a
missing or unreadable verdict as "LABEL: verdict missing".  The launcher passes every line to the registry as
--prerequisite-failed, so its readings are labelled diagnostic.  Operational steps (runtime estimates, packaging) are
not named by the launcher.  Exit 0 when OUT_TXT was written, 2 on wrong arguments."""
from __future__ import annotations

import json
import sys
from pathlib import Path


def main(argv=None) -> int:
    a = sys.argv[1:] if argv is None else list(argv)
    if len(a) < 2 or any("=" not in x or ":" not in x.split("=", 1)[1] for x in a[1:]):
        print(__doc__)
        return 2
    out = []
    for spec in a[1:]:
        label, rest = spec.split("=", 1)
        path, steps = rest.rsplit(":", 1)
        try:
            st = json.loads(Path(path).read_text())["steps"]
        except (OSError, ValueError, KeyError, TypeError):
            out.append(f"{label}: verdict missing ({path})")
            continue
        for s in [x for x in steps.split(",") if x]:
            if s not in st:
                out.append(f"{label}:{s} (not in the verdict)")
            elif st[s] != 0:
                out.append(f"{label}:{s} ({st[s]})")
    Path(a[0]).write_text("".join(x + "\n" for x in out))
    print(f"{len(out)} failed prerequisites" + ("".join("\n  " + x for x in out)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
