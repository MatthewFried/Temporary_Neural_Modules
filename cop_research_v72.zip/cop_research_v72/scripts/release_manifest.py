"""v71 / v72: the release manifest: what the final results were computed from, identified by SHA-256 (identification
only; the evidence is the recomputation recorded elsewhere), and its verification after packaging.

  python scripts/release_manifest.py OUT_JSON --code DIR --reports DIR [--reports DIR ...]
         [--exclude DIR NAME REASON ...] [--runs NAME PANEL MANIFEST ...] [--verdict VERDICT_JSON] [--statement TEXT]
  python scripts/release_manifest.py verify MANIFEST_JSON [--code DIR] [--zip ZIP PREFIX REPORTS_DIR]

code      every file of the code folder (manifests/, __pycache__ and .pytest_cache left out)
reports   every file of each reports folder, except the files named by --exclude for that folder: files still being
          written when the manifest is made (the manifest itself, the manifest step's own log, the packaging and
          verification logs, verdict.json, verdict_steps.txt).  v72: each exclusion is recorded with its reason under
          "excluded_mutable", so an unlisted file is never mistaken for a missing or changed one
runs      for every run of MANIFEST, every file under PANEL/runs/<run_id> (a view's symlinks are followed and the real
          path recorded): checkpoints, endpoint, status
verdict   the final local verdict.json (step exit codes), copied in, with STATEMENT
Exit 0; 1 if a run of a manifest has no folder.

verify (v72): re-hashes every listed code file (in --code DIR) and report file on disk (not the runs: 21 GB, unchanged by the close-out),
and with --zip every file the archive delivers under PREFIX/<basename of REPORTS_DIR>/: a delivered file must be listed
with the same hash or be one of the declared exclusions; a listed file of REPORTS_DIR that the archive does not deliver
must appear in the archive's skipped_large_files.json (and was re-hashed on disk).  Exit 0 when everything matches,
1 otherwise."""
from __future__ import annotations

import hashlib
import json
import sys
import zipfile
from pathlib import Path

SKIP = {"__pycache__", ".pytest_cache", "manifests"}
ARCHIVE_OWN = {"verdict.json", "skipped_large_files.json"}       # written by the packager into the archive's root


def sha(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 23), b""):
            h.update(b)
    return h.hexdigest()


def files(root: Path):
    for p in sorted(root.rglob("*")):
        if p.is_file() and not (set(p.relative_to(root).parts) & SKIP):
            yield p


def make(a: list) -> int:
    out, code, reports, runs, verdict, statement, excl, i = a[0], None, [], [], None, None, {}, 1
    while i < len(a):
        if a[i] == "--code":
            code, i = a[i + 1], i + 2
        elif a[i] == "--reports":
            reports.append(a[i + 1])
            i += 2
        elif a[i] == "--exclude":
            excl.setdefault(str(Path(a[i + 1])), {})[a[i + 2]] = a[i + 3]
            i += 4
        elif a[i] == "--runs":
            runs.append(tuple(a[i + 1:i + 4]))
            i += 4
        elif a[i] == "--verdict":
            verdict, i = a[i + 1], i + 2
        elif a[i] == "--statement":
            statement, i = a[i + 1], i + 2
        else:
            print(__doc__)
            return 2
    rec, missing = {"purpose": "identification of the released code, reports and checkpoints (SHA-256)"}, []
    if code:
        rec["code"] = {str(p.relative_to(code)): sha(p) for p in files(Path(code))}
    rec["reports"], rec["excluded_mutable"] = {}, {}
    for r in reports:
        ex = excl.get(str(Path(r)), {})
        rec["reports"][r] = {str(p.relative_to(r)): {"sha256": sha(p), "bytes": p.stat().st_size}
                             for p in files(Path(r)) if str(p.relative_to(r)) not in ex}
        if ex:
            rec["excluded_mutable"][r] = ex
    rec["runs"] = {}
    for name, panel, man in runs:
        ids = [json.loads(ln)["run_id"] for ln in open(man) if ln.strip()]
        rr = {}
        for rid in ids:
            d = Path(panel) / "runs" / rid
            if not d.exists():
                missing.append(f"{name}:{rid}")
                continue
            real = d.resolve()
            rr[rid] = {"path": str(real), "files": {str(p.relative_to(real)): {"sha256": sha(p), "bytes": p.stat().st_size}
                                                     for p in files(real)}}
        rec["runs"][name] = {"panel": panel, "manifest": man, "manifest_sha256": sha(Path(man)), "n_runs": len(ids),
                             "runs": rr}
    if verdict:
        v = json.loads(Path(verdict).read_text())
        rec["final_verdict"] = {"file": verdict, "steps": v.get("steps"),
                                "not_zero": {k: x for k, x in (v.get("steps") or {}).items() if x != 0},
                                "pending": v.get("pending"), "statement": statement}
    rec["missing_runs"] = missing
    rec["counts"] = {"code_files": len(rec.get("code", {})),
                     "report_files": sum(len(x) for x in rec["reports"].values()),
                     "excluded_mutable_files": sum(len(x) for x in rec["excluded_mutable"].values()),
                     "runs": sum(len(x["runs"]) for x in rec["runs"].values()),
                     "run_files": sum(len(r["files"]) for x in rec["runs"].values() for r in x["runs"].values()),
                     "run_bytes": sum(f["bytes"] for x in rec["runs"].values() for r in x["runs"].values()
                                      for f in r["files"].values())}
    Path(out).write_text(json.dumps(rec, indent=1))
    print(json.dumps({**rec["counts"], "missing_runs": len(missing)}))
    return 1 if missing else 0


def verify(a: list) -> int:
    rec = json.loads(Path(a[0]).read_text())
    zp = a[a.index("--zip") + 1:a.index("--zip") + 4] if "--zip" in a else None
    bad, n_disk, n_zip = [], 0, 0
    if rec.get("code"):
        # the code folder is the one the manifest was made in: its path is not recorded, so --code DIR names it
        cdir = Path(a[a.index("--code") + 1]) if "--code" in a else None
        if cdir is not None:
            for rel, h in rec["code"].items():
                p = cdir / rel
                n_disk += 1
                if not p.is_file() or sha(p) != h:
                    bad.append(f"code {rel}: {'missing' if not p.is_file() else 'changed'}")
    for r, listed in rec["reports"].items():
        for rel, e in listed.items():
            p = Path(r) / rel
            n_disk += 1
            if not p.is_file() or sha(p) != e["sha256"]:
                bad.append(f"{r}/{rel}: {'missing' if not p.is_file() else 'changed on disk'}")
    if zp:
        zf, prefix, rdir = zipfile.ZipFile(zp[0]), zp[1], str(Path(zp[2]))
        listed = rec["reports"].get(rdir) or rec["reports"].get(zp[2]) or {}
        ex = rec["excluded_mutable"].get(rdir) or rec["excluded_mutable"].get(zp[2]) or {}
        sub = f"{prefix}/{Path(rdir).name}/"
        delivered = {}
        for n in zf.namelist():
            if n.startswith(sub) and not n.endswith("/"):
                delivered[n[len(sub):]] = n
            elif n.startswith(prefix + "/") and n[len(prefix) + 1:] not in ARCHIVE_OWN and not n.endswith("/"):
                bad.append(f"archive: {n} is outside {sub} and not the archive's own file")
        skipped = set()
        if f"{prefix}/skipped_large_files.json" in zf.namelist():
            skipped = {Path(x["file"]).name if "/" not in x["file"] else x["file"].split("/", 1)[1]
                       for x in json.loads(zf.read(f"{prefix}/skipped_large_files.json"))}
        for rel, n in delivered.items():
            n_zip += 1
            if rel in listed:
                if hashlib.sha256(zf.read(n)).hexdigest() != listed[rel]["sha256"]:
                    bad.append(f"archive {rel}: differs from the manifest")
            elif rel not in ex:
                bad.append(f"archive {rel}: delivered but neither listed nor a declared exclusion")
        for rel in listed:
            if rel not in delivered and rel not in skipped:
                bad.append(f"archive {rel}: listed but not delivered (and not in skipped_large_files.json)")
    print(json.dumps({"checked_on_disk": n_disk, "checked_in_archive": n_zip, "mismatches": len(bad),
                      "first": bad[:20]}))
    return 1 if bad else 0


def main(argv=None) -> int:
    a = sys.argv[1:] if argv is None else list(argv)
    if not a:
        print(__doc__)
        return 2
    if a[0] == "verify" and len(a) >= 2:
        return verify(a[1:])
    return make(a)


if __name__ == "__main__":
    sys.exit(main())
