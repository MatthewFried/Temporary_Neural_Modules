"""v63: read a replication registry off a fork analysis; v65: two-sided hypotheses; v66 / v68: bound to its evidence;
v70: every value recomputed from the states table.

  python scripts/replication_registry.py REGISTRY CONTRASTS_CSV OUT_PREFIX --coverage COVERAGE_JSON
         --manifest MANIFEST --audits AUDITS_CSV --states STATES_CSV [--exclude-states FILE ...]
         [--prerequisite-failed NAME ...]

The registry carries a CONTRACT: the analysis schemas it reads, the exact data draws and optimizer seeds, and the
design (parents, forks, continuations, arms) the analysis coverage must report.  Before anything is summarised:
  binding     the coverage's schema is one the contract names, its manifest digest is MANIFEST's, its design is the
              contract's, and (v68) CONTRASTS_CSV, AUDITS_CSV and STATES_CSV are byte for byte the tables the
              analysis wrote (the SHA-256 it recorded in the coverage, outputs_sha256); the audit table holds one row
              per fork (no duplicate key; as many as the coverage audited) and its failed runs are exactly the
              coverage's.  Otherwise nothing is read (status unbound)
  per hypothesis, the raw paired rows matching parent, fork, comparison, first, second and metric must come from
              ONE design id of the coverage, each from a manifest f0 whose data draw and optimizer seed are the
              row's, with exactly one finite row for every draw x seed of the contract and none outside it, and
              (v68) every state record a row depends on (its depends_on keys) must exist: a fork with an audit row,
              or a measured state (states are written only after their checkpoints passed check_ckpt).  Otherwise
              the hypothesis is not read (status incomplete, with the counts)
v70: every row's value is recomputed from the states table by rules written here from the comparisons' definitions
(first - second within a parent and fork; against f0, the fork start, the matched compact or the reset-matched
compact; arm against arm; the interactions (first - routed_reset) - (second - ordinary_reset)) and must equal the
contrasts table's value exactly (both are differences of the same stored floats); otherwise the hypothesis is
incomplete.  The summary is taken over the recomputed values.
Then the favourable value (first - second, its negative, or two-sided) is averaged over seeds within each
draw and summarised over draws (mean, 95% Student t interval, the Bonferroni interval for primaries).  Status:
  validated    complete rows, every dependency validated (forks: audit passed), the analysis complete, no
               prerequisite failed
  conditional  some rows depend on a fork whose audit failed, or (v69) on a state the independent reference did
               not certify (--exclude-states: lines f0|parent/fork/state written by reference_recompute): the
               summary is over the remaining draw-seed pairs, labelled conditional, never a validated reading
  diagnostic   the analysis did not complete, or a prerequisite (tests, CUDA tests, checks, reload, summary, reuse
               verification) failed: numbers are reported, readings are labelled diagnostic
Readings: replicated / contrary / inconclusive (one-sided), nonzero (positive) / nonzero (negative) / inconclusive
(two-sided); an interval containing zero is not evidence of no effect.  Writes OUT_PREFIX.json and OUT_PREFIX.csv.
Exit 0 when every hypothesis is validated, 3 when all were read but some are not validated, 1 when one is unbound or
incomplete, 2 on wrong arguments."""
from __future__ import annotations

import csv
import json
import math
import sys
from collections import defaultdict
from pathlib import Path


def t_cdf(t: float, df: int) -> float:
    """Student t distribution function (Simpson's rule on the density; |error| well below 1e-8 here)."""
    if t == 0:
        return 0.5
    c = math.exp(math.lgamma((df + 1) / 2) - math.lgamma(df / 2)) / math.sqrt(df * math.pi)
    f = lambda x: c * (1 + x * x / df) ** (-(df + 1) / 2)
    a, b, n = 0.0, abs(t), 4000
    h = (b - a) / n
    s = f(a) + f(b) + sum((4 if i % 2 else 2) * f(a + i * h) for i in range(1, n))
    half = s * h / 3
    return 0.5 + half if t > 0 else 0.5 - half


def t_quantile(p: float, df: int) -> float:
    lo, hi = 0.0, 1000.0
    for _ in range(200):
        mid = (lo + hi) / 2
        if t_cdf(mid, df) < p:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


def summarise(dm: list, level: float) -> dict:
    n = len(dm)
    mu = sum(dm) / n
    if n < 2:
        return {"n_draws": n, "mean": mu, "low": None, "high": None}
    sd = (sum((x - mu) ** 2 for x in dm) / (n - 1)) ** 0.5
    q = t_quantile(1 - (1 - level) / 2, n - 1)
    return {"n_draws": n, "mean": mu, "low": mu - q * sd / n ** 0.5, "high": mu + q * sd / n ** 0.5}


def sha256_file(p) -> str:
    import hashlib
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for blk in iter(lambda: f.read(1 << 20), b""):
            h.update(blk)
    return h.hexdigest()


def binding_problems(reg: dict, cov: dict, manifest: str, tables: dict, audits: list) -> list:
    c = reg.get("contract") or {}
    out = []
    if not c:
        out.append("the registry has no contract")
        return out
    if cov.get("analysis_schema") not in (c.get("analysis_schemas") or []):
        out.append(f"analysis schema {cov.get('analysis_schema')}, the contract reads {c.get('analysis_schemas')}")
    got = str(cov.get("manifest_sha256") or "")
    if len(got) < 16 or not sha256_file(manifest).startswith(got):    # the analyses record the first 16 hex digits
        out.append("the coverage was not computed from this manifest (SHA-256 differs)")
    for k, v in (c.get("design") or {}).items():
        got = (cov.get("design") or {}).get(k)
        if got is None or sorted(map(str, got)) != sorted(map(str, v)):
            out.append(f"design {k}: coverage {got}, contract {v}")
    rec = cov.get("outputs_sha256") or {}
    for name, path in tables.items():
        if rec.get(name) is None:
            out.append(f"the coverage records no digest of its {name}")
        elif sha256_file(path) != rec[name]:
            out.append(f"{name} is not the table the analysis wrote (SHA-256 differs)")
    keys = [(r.get("f0"), r.get("parent"), r.get("fork"), r.get("state")) for r in audits]
    if len(set(keys)) != len(keys):
        out.append("the audit table has duplicate fork keys")
    if any(str(r.get("audit_passed")) not in ("True", "False") for r in audits):
        out.append("the audit table has rows without a pass or fail")
    if cov.get("n_audited_forks") is None or len(audits) != int(cov["n_audited_forks"]):
        out.append(f"the audit table has {len(audits)} rows, the coverage audited {cov.get('n_audited_forks')}")
    failed_t = sorted(r.get("run_id") for r in audits if str(r.get("audit_passed")) != "True")
    failed_c = sorted(cov.get("audit_failure_run_ids") if cov.get("audit_failure_run_ids") is not None else
                      [x.get("run_id") for x in cov.get("audit_failures") or []])
    if failed_t != failed_c or len(failed_c) != len(cov.get("audit_failures") or []):
        out.append(f"the audit table's failed runs {failed_t[:3]} are not the coverage's {failed_c[:3]}")
    return out


# v70: every hypothesis value is recomputed here from the states table, by rules written from the comparisons'
# definitions (not by the analysis's code), and must equal the contrasts table's value exactly; the summary is then
# taken over the recomputed values.
PAIRED = {"routed_minus_ordinary", "ordinary_minus_frozen", "frozen_minus_folded", "carry_minus_reset",
          "swap_minus_routed", "swap_minus_ordinary", "shift50_minus_routed", "shift100_minus_routed",
          "shift100_minus_ordinary", "trajectory_end_minus_routed_carry"}
INTERACTION = {"swap_interaction", "shift100_interaction"}


def state_value(S: dict, f0: str, key: tuple, metric: str):
    r = S.get((f0, *key))
    if r is None:
        return None, f"no state {key[0]}/{key[1]}/{key[2]}"
    try:
        v = float(r.get(metric))
    except (TypeError, ValueError):
        return None, f"state {key[0]}/{key[1]}/{key[2]} has no {metric}"
    if not math.isfinite(v):
        return None, f"state {key[0]}/{key[1]}/{key[2]} has a non-finite {metric}"
    return v, None


def operands(h: dict, f0: str, S: dict):
    """(keys, None) for the operand states of hypothesis h at f0, in the order the value combines them, or
    (None, why).  The value is keys[0] - keys[1], or (k0 - k1) - (k2 - k3) for an interaction."""
    c, p, f, a, b = h["comparison"], h["parent"], h["fork"], h["first"], h["second"]
    hold = p.split("_")[0]

    def compact(lab, fork="compact"):
        for k_ in ((p, fork, lab), (hold, fork, lab)):
            if (f0, *k_) in S:
                return k_
        return (p, fork, lab)
    if c in PAIRED:
        return [(p, f, a), (p, f, b)], None
    if c == "minus_f0":
        return ([(p, f, a), ("f0", "f0", "f0")], None) if b == "f0" else (None, f"minus_f0 with second {b}")
    if c == "start_minus_f0":
        return [(p, f, "start"), ("f0", "f0", "f0")], None
    if c == "continuation_minus_start":
        return [(p, f, a), (p, f, "start")], None
    if c in ("fork_minus_compact_2U", "fork_minus_compact_4U", "minus_compact_2U", "minus_compact_4U"):
        lab = c.split("minus_")[1]
        return ([(p, f, a), compact(lab)], None) if b == lab else (None, f"{c} with second {b}")
    if c == "fork_minus_compact_reset":
        return [(p, f, a), compact("compact_reset", f)], None
    if c == "arm_minus_arm":
        return [(a, "end", f), (b, "end", f)], None
    if c in INTERACTION:
        return [(p, f, a), (p, f, "routed_reset"), (p, f, b), (p, f, "ordinary_reset")], None
    return None, f"no independent rule for the comparison {c}"


def combine(h: dict, vals: list) -> float:
    if h["comparison"] in INTERACTION:
        return (vals[0] - vals[1]) - (vals[2] - vals[3])
    return vals[0] - vals[1]


def recompute(h: dict, f0: str, S: dict):
    """(value, None) from the states table S {(f0, parent, fork, state): row}, or (None, why)."""
    keys, why = operands(h, f0, S)
    if why:
        return None, why
    vals = []
    for k_ in keys:
        v, why = state_value(S, f0, k_, h["metric"])
        if why:
            return None, why
        vals.append(v)
    return combine(h, vals), None


def f0_identity(manifest: str) -> dict:
    """f0 run id -> (data draw, optimizer seed), from the manifest."""
    out = {}
    for ln in open(manifest):
        if not ln.strip():
            continue
        e = json.loads(ln)
        c = e.get("cfg") or {}
        if c.get("kind") == "baseline":
            out[e["run_id"]] = (str((c.get("data") or {}).get("data_seed")), str((c.get("seeds") or {}).get("optimizer")))
    return out


def main(argv=None) -> int:
    a = sys.argv[1:] if argv is None else list(argv)
    opts = {"--coverage": None, "--manifest": None, "--audits": None, "--states": None}
    prereq = []
    excl_files = []
    pos = []
    i = 0
    while i < len(a):
        if a[i] in opts and i + 1 < len(a):
            opts[a[i]] = a[i + 1]
            i += 2
        elif a[i] == "--prerequisite-failed" and i + 1 < len(a):
            prereq.append(a[i + 1])
            i += 2
        elif a[i] == "--exclude-states" and i + 1 < len(a):
            excl_files.append(a[i + 1])
            i += 2
        else:
            pos.append(a[i])
            i += 1
    if len(pos) != 3 or not all(opts.values()):
        print(__doc__)
        return 2
    reg = json.loads(Path(pos[0]).read_text())
    cov = json.loads(Path(opts["--coverage"]).read_text())
    rows = list(csv.DictReader(open(pos[1])))
    con = reg.get("contract") or {}
    audits = list(csv.DictReader(open(opts["--audits"])))
    tables = {"contrasts.csv": pos[1], "audits.csv": opts["--audits"], "states.csv": opts["--states"]}
    unbound = binding_problems(reg, cov, opts["--manifest"], tables, audits)
    grid = {(str(d), str(o)) for d in con.get("data_draws") or [] for o in con.get("optimizer_seeds") or []}
    audit_ok = {(r["f0"], f"{r['parent']}/{r['fork']}/{r['state']}"): str(r["audit_passed"]) == "True" for r in audits}
    st_rows = list(csv.DictReader(open(opts["--states"])))
    measured = {(r["f0"], f"{r['parent']}/{r['fork']}/{r['state']}") for r in st_rows}
    S = {}
    st_dup = 0
    for r in st_rows:
        k_ = (r["f0"], r["parent"], r["fork"], r["state"])
        st_dup += k_ in S
        S[k_] = r
    ident = f0_identity(opts["--manifest"])
    ref_bad = set()
    for f_ in excl_files:
        for ln in open(f_):
            ln = ln.strip()
            if ln:
                f0_, _, key_ = ln.partition("|")
                ref_bad.add((f0_, key_))
    designs_cov = set(cov.get("design_ids") or [])
    diag = []
    # a fork whose audit failed is handled per row (conditional); the whole reading is diagnostic when the analysis
    # itself is incomplete or a prerequisite failed
    if not cov.get("analysis_complete", False):
        diag.append("the analysis did not complete")
    diag += [f"prerequisite failed: {p_}" for p_ in prereq]
    prim = [h for h in reg["hypotheses"] if h["role"] == "primary"]
    level_p = 1 - 0.05 / max(1, len(prim))
    out, worst = [], 0
    for h in reg["hypotheses"]:
        if h["favourable"] not in ("first - second", "second - first", "two-sided"):
            raise ValueError(f"{h['key']}: favourable must be first - second, second - first or two-sided")
        base = {**h, "expected_pairs": len(grid)}
        if unbound:
            out.append({**base, "status": "unbound", "reading": "not read: " + "; ".join(unbound)})
            worst = max(worst, 2)
            continue
        mine = [r for r in rows if (r["parent"], r["fork"], r["comparison"], r["first"], r["second"], r["metric"]) ==
                (h["parent"], h["fork"], h["comparison"], h["first"], h["second"], h["metric"])]
        keys = [(str(r["data_draw"]), str(r["optimizer_seed"])) for r in mine]
        cnt = defaultdict(int)
        for k_ in keys:
            cnt[k_] += 1
        vals = []
        for r in mine:
            try:
                vals.append(float(r["value"]))
            except (TypeError, ValueError):
                vals.append(math.nan)
        why = []
        designs = {r.get("design_id") for r in mine}
        if len(designs) > 1:
            why.append(f"rows from {len(designs)} designs")
        if any(not d_ or d_ not in designs_cov for d_ in designs):
            why.append("rows with a design id the analysis did not report")
        bad_id = [r.get("f0") for r in mine if not r.get("f0") or
                  ident.get(r["f0"]) != (str(r["data_draw"]), str(r["optimizer_seed"]))]
        if bad_id:
            why.append(f"{len(bad_id)} rows whose f0 is not the manifest's f0 of their draw and seed")
        no_rec = [r for r in mine if not r.get("depends_on") or
                  any((r["f0"], k_) not in audit_ok and (r["f0"], k_) not in measured
                      for k_ in r["depends_on"].split(";"))]
        if no_rec:
            why.append(f"{len(no_rec)} rows depend on a state without a validity record")
        miss = sorted(grid - set(cnt))
        dup = sorted(k_ for k_, n_ in cnt.items() if n_ > 1)
        extra = sorted(set(cnt) - grid)
        nonfin = sum(1 for v in vals if not math.isfinite(v))
        if miss:
            why.append(f"{len(miss)} draw-seed pairs missing (e.g. {miss[:3]})")
        if dup:
            why.append(f"{len(dup)} draw-seed pairs duplicated (e.g. {dup[:3]})")
        if extra:
            why.append(f"{len(extra)} draw-seed pairs outside the contract (e.g. {extra[:3]})")
        if nonfin:
            why.append(f"{nonfin} non-finite values")
        # v70: the same values recomputed from the states table, independently of the analysis's contrast code
        rec_vals, no_rule, mism = [], [], 0
        for r, v in zip(mine, vals):
            rv, why_ = recompute(h, r.get("f0"), S)
            if why_:
                no_rule.append(why_)
                rec_vals.append(math.nan)
                continue
            rec_vals.append(rv)
            mism += not (rv == v)
        if st_dup:
            why.append(f"the states table has {st_dup} duplicate rows")
        if no_rule:
            why.append(f"{len(no_rule)} rows not recomputable from the states table ({no_rule[0]})")
        if mism:
            why.append(f"{mism} rows whose contrasts value differs from the states table's")
        counts = {"found_rows": len(mine), "unique_pairs": len(cnt), "finite_rows": len(vals) - nonfin,
                  "designs": len(designs), "recomputed_rows": len(rec_vals) - len(no_rule),
                  "recomputed_mismatches": mism}
        if why or not grid:
            out.append({**base, **counts, "status": "incomplete",
                        "reading": "not read: " + ("; ".join(why) or "the contract has no draws or seeds")})
            worst = max(worst, 2)
            continue
        keep, dropped, excluded = [], 0, []
        for r, v in zip(mine, rec_vals):          # v70: the values recomputed from the states table
            bad = [k_ for k_ in r["depends_on"].split(";") if audit_ok.get((r["f0"], k_)) is False]
            bad += [f"{k_} (reference)" for k_ in r["depends_on"].split(";") if (r["f0"], k_) in ref_bad]
            if bad:
                dropped += 1
                excluded += [f"{r['f0']}:{k_}" for k_ in bad]
                continue
            keep.append((r, v))
        import hashlib
        pairs_digest = hashlib.sha256("\n".join(sorted(f"{r['f0']}|{r['data_draw']}|{r['optimizer_seed']}"
                                                        for r, _ in keep)).encode()).hexdigest()[:16]
        per = defaultdict(lambda: defaultdict(list))
        for r, v in keep:
            per[str(r["data_draw"])][str(r["optimizer_seed"])].append(-v if h["favourable"] == "second - first" else v)
        dm = [sum(sum(x) / len(x) for x in seeds.values()) / len(seeds) for _, seeds in sorted(per.items())]
        status = "conditional" if dropped else ("diagnostic" if diag else "validated")
        if not dm:
            out.append({**base, **counts, "status": "conditional", "excluded_rows": dropped,
                        "excluded": sorted(set(excluded)),
                        "reading": "not read: every row depends on a run whose audit failed"})
            worst = max(worst, 1)
            continue
        s95 = summarise(dm, 0.95)
        level = level_p if h["role"] == "primary" else 0.95
        sl = summarise(dm, level)
        if h["favourable"] == "two-sided":
            reading = ("nonzero (positive)" if sl["low"] is not None and sl["low"] > 0 else
                       "nonzero (negative)" if sl["high"] is not None and sl["high"] < 0 else "inconclusive")
        else:
            reading = ("replicated" if sl["low"] is not None and sl["low"] > 0 else
                       "contrary" if sl["high"] is not None and sl["high"] < 0 else "inconclusive")
        if h["role"] != "primary":
            reading = f"secondary: {reading} at 95%"
        if status == "conditional":
            reading = (f"conditional ({len(keep)} of {len(mine)} draw-seed pairs; the rest depend on runs whose "
                       f"audit or reference certificate failed{'; ' + '; '.join(diag) if diag else ''}): {reading}; not a validated result")
        elif status == "diagnostic":
            reading = f"diagnostic ({'; '.join(diag)}): {reading}; not a validated result"
        if status != "validated":
            worst = max(worst, 1)
        out.append({**base, **counts, "status": status, "excluded_rows": dropped, "found": True,
                    "excluded": sorted(set(excluded)), "pairs_digest": pairs_digest,
                    "n_draws": s95["n_draws"], "n_draw_seed_pairs": len(keep), "mean_favourable": s95["mean"],
                    "ci95_low": s95["low"], "ci95_high": s95["high"], "interval_level": level,
                    "interval_low": sl["low"], "interval_high": sl["high"],
                    "draws_favourable": f"{sum(x > 0 for x in dm)}/{len(dm)}", "reading": reading})
    rec = {"registry": pos[0], "registry_sha256": sha256_file(pos[0]), "contrasts_sha256": sha256_file(pos[1]),
           "coverage": opts["--coverage"], "coverage_sha256": sha256_file(opts["--coverage"]),
           "coverage_schema": cov.get("analysis_schema"), "coverage_passed": cov.get("passed"),
           "manifest": opts["--manifest"], "manifest_sha256": sha256_file(opts["--manifest"]),
           "audits": opts["--audits"], "audits_sha256": sha256_file(opts["--audits"]),
           "states": opts["--states"], "states_sha256": sha256_file(opts["--states"]),
           "prerequisites_failed": prereq, "unbound": unbound,
           "reference_exclusions": {"files": excl_files, "states": sorted(f"{a_}|{b_}" for a_, b_ in ref_bad)},
           "status_note": reg.get("status_note"), "multiplicity": reg.get("multiplicity"),
           "reading_rules": reg.get("reading"), "contract": con, "results": out,
           "all_validated": worst == 0 and all(r["status"] == "validated" for r in out)}
    Path(pos[2] + ".json").write_text(json.dumps(rec, indent=1))
    keys = ["key", "role", "status", "parent", "fork", "metric", "reads", "expected_pairs", "found_rows",
            "unique_pairs", "finite_rows", "recomputed_rows", "recomputed_mismatches", "excluded_rows", "pairs_digest", "n_draws", "n_draw_seed_pairs", "mean_favourable",
            "ci95_low", "ci95_high", "interval_level", "interval_low", "interval_high", "draws_favourable", "reading"]
    with open(pos[2] + ".csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys, extrasaction="ignore")
        w.writeheader()
        for r in out:
            w.writerow(r)
    print(json.dumps([{k: r.get(k) for k in ("key", "status", "mean_favourable", "interval_low", "interval_high",
                                              "reading")} for r in out]))
    return 0 if rec["all_validated"] else (1 if worst >= 2 else 3)


if __name__ == "__main__":
    sys.exit(main())
