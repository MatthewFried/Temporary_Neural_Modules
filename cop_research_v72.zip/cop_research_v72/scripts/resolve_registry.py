"""Write registry_resolved.json: the specification registry with implementation
locations, manifest blocks and job counts per work package, and acceptance-test
outcomes from a pytest junit file.  Usage:
    python scripts/resolve_registry.py --junit results/tests/junit_X.xml --out registry_resolved.json
"""
import argparse
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
import sys
sys.path.insert(0, str(ROOT))
from cop.orchestration.manifest import generate, factorial_checks  # noqa: E402

IMPL = {}
for line in (ROOT / "COVERAGE.md").read_text().splitlines():
    m = re.match(r"\| (E\d|R\d|I\d|P\d) [^|]*\| (.*?) \| (.*?) \| (.*?) \|$", line)
    if m:
        IMPL[m.group(1)] = {"implementation": m.group(2), "blocks": m.group(3), "status": m.group(4)}

ap = argparse.ArgumentParser()
ap.add_argument("--junit")
ap.add_argument("--out", default=str(ROOT / "registry_resolved.json"))
ap.add_argument("--execution", default="not_run_at_full_scale; smoke-scale CPU checks only")
a = ap.parse_args()
reg = json.load(open(ROOT / "configs" / "registry_spec_v1.0.json"))
B = generate([0, 1, 2, 3, 4, 5], "full")
cov = B.coverage()
for wp in reg["work_packages"]:
    i = IMPL.get(wp["id"], {})
    wp["implementation_status"] = i.get("status", "missing")
    wp["implementation_location"] = i.get("implementation")
    wp["manifest_blocks"] = sorted(b for b, v in cov["blocks"].items() if wp["id"] in v["wp"])
    wp["n_jobs_full_scale"] = cov["jobs_per_work_package"].get(wp["id"], 0)
    wp["execution_status"] = a.execution
tests = {}
if a.junit and Path(a.junit).exists():
    for tc in ET.parse(a.junit).getroot().iter("testcase"):
        name = tc.get("name")
        st = "passed"
        if tc.find("failure") is not None or tc.find("error") is not None:
            st = "failed"
        elif tc.find("skipped") is not None:
            st = "skipped: " + (tc.find("skipped").get("message") or "")
        tests[name] = st
for t in reg["acceptance_tests"]:
    hits = {k: v for k, v in tests.items() if re.search(rf"(^|_){t['id']}(_|$)", k)}
    t["status"] = "not_run" if not hits else ("failed" if any(v == "failed" for v in hits.values()) else
                                              ("skipped" if all(v.startswith("skipped") for v in hits.values())
                                               else "passed"))
    t["tests"] = hits
    if t["id"] in ("T10", "T11") and not hits:
        t["status"] = "see tests/test_data.py"
reg["factorial_checks"] = factorial_checks(B)
reg["job_counts_full_scale"] = {"total": cov["n_entries"], "by_kind": cov["by_kind"]}
reg["resolved_by"] = "cop framework v1.0.0 (CODE_VERSION cop-1.0.0)"
json.dump(reg, open(a.out, "w"), indent=1)
print("wrote", a.out)
