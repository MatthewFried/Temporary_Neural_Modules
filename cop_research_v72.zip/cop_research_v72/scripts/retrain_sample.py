"""v70: retrain a few saved runs from scratch and compare them with the saved ones directly (no hashes).

  python scripts/retrain_sample.py select MANIFEST SUBMANIFEST --f0 RUN_ID --states PARENT/FORK/STATE[,...]
  python scripts/retrain_sample.py compare SUBMANIFEST PANEL SCRATCH OUT_JSON

select   the runs behind the named fork states of one f0 (each a dissipation run: its parent arm's trajectory at
         that fork point), with every ancestor (the trajectory, the baseline), in manifest order.  A state that is
         not in the manifest's design fails (exit 1).
compare  every job of SUBMANIFEST, retrained from scratch into SCRATCH (cop run), against the saved copy in PANEL:
         the same set of checkpoints (ckpt/*.pt) must exist, and each pair is compared value by value: every tensor
         element (torch.equal, with dtype and shape), every number, string and list, the model specification, the
         optimizer state by parameter name, the trainer state and random generator states, the lineage, extra and
         numerics records.  Excluded: the code hash in the lineage (an earlier code version may have written the saved
         copy) and wall-clock fields (WALL_CLOCK).  endpoint.json is compared the same way.  For a differing tensor the
         record holds the number of differing elements and the largest absolute difference.
         Exit 0 when every job reproduced, 1 otherwise.
Training is deterministic (cop.utils sets deterministic algorithms), so on the same machine and libraries a saved run
reproduces element for element."""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "audit_v5" / "tools"))
import torch  # noqa: E402

WALL_CLOCK = ("timing", "seconds", "train_seconds", "time", "wall_seconds", "elapsed")   # as reuse_reproduce.py
EXCLUDED = (("lineage", "code_hash"),)


def select(man: str, sub: str, f0: str, states: list) -> int:
    import fork_continuation as FC
    lines = [json.loads(ln) for ln in open(man) if ln.strip()]
    by = {e["run_id"]: e for e in lines}
    jobs = FC.fork_jobs({e["run_id"]: e["cfg"] for e in lines})
    if f0 not in jobs:
        print(json.dumps({"error": f"{f0} is not an f0 of the manifest's fork design"}))
        return 1
    want, missing = [], []
    for s in states:
        parent, fork, state = s.split("/")
        J = jobs[f0].get(parent)
        rid = None if J is None else (J["forks"].get(fork) or {}).get(state)
        if rid is None:
            missing.append(s)
        else:
            want.append(rid)
    if missing:
        print(json.dumps({"error": f"not in the design: {missing}"}))
        return 1
    pick, todo = set(), list(want)
    while todo:
        r = todo.pop()
        if r in pick:
            continue
        if r not in by:
            print(json.dumps({"error": f"ancestor {r} is not in the manifest"}))
            return 1
        pick.add(r)
        todo.extend((by[r]["cfg"].get("parents") or {}).values())
    out = [e for e in lines if e["run_id"] in pick]
    Path(sub).parent.mkdir(parents=True, exist_ok=True)
    Path(sub).write_text("".join(json.dumps(e) + "\n" for e in out))
    print(json.dumps({"f0": f0, "states": states, "selected": len(out),
                      "kinds": {k: sum(1 for e in out if e["cfg"]["kind"] == k) for k in
                                sorted({e["cfg"]["kind"] for e in out})}}))
    return 0


def diff(a, b, path=(), out=None, limit=50) -> list:
    """the places where a and b differ, value by value (tensors element by element)."""
    out = [] if out is None else out
    if len(out) >= limit:
        return out
    if path in EXCLUDED or (path and str(path[-1]) in WALL_CLOCK):
        return out
    where = "/".join(map(str, path)) or "."
    if torch.is_tensor(a) or torch.is_tensor(b):
        if not (torch.is_tensor(a) and torch.is_tensor(b)):
            out.append({"at": where, "what": "a tensor on one side only"})
        elif a.dtype != b.dtype or a.shape != b.shape:
            out.append({"at": where, "what": f"{a.dtype}{tuple(a.shape)} vs {b.dtype}{tuple(b.shape)}"})
        elif not torch.equal(a, b):
            if a.is_floating_point():
                d = (a.double() - b.double()).abs()
                ne = int((a != b).sum())
                out.append({"at": where, "what": "values", "differing": ne,
                            "max_abs_diff": float(torch.nan_to_num(d, nan=float("inf")).max())})
            else:
                out.append({"at": where, "what": "values", "differing": int((a != b).sum())})
        return out
    if isinstance(a, dict) and isinstance(b, dict):
        for k in sorted(set(a) | set(b), key=str):
            if k not in a or k not in b:
                if not (path + (str(k),) in EXCLUDED or str(k) in WALL_CLOCK):
                    out.append({"at": f"{where}/{k}", "what": "a key on one side only"})
                continue
            diff(a[k], b[k], path + (str(k),), out, limit)
        return out
    if isinstance(a, (list, tuple)) and isinstance(b, (list, tuple)):
        if len(a) != len(b):
            out.append({"at": where, "what": f"lengths {len(a)} vs {len(b)}"})
            return out
        for i, (x, y) in enumerate(zip(a, b)):
            diff(x, y, path + (i,), out, limit)
        return out
    if isinstance(a, float) and isinstance(b, float) and a != a and b != b:
        return out                                       # both NaN
    if type(a) is not type(b) and not (isinstance(a, (int, float)) and isinstance(b, (int, float))
                                       and not isinstance(a, bool) and not isinstance(b, bool)):
        out.append({"at": where, "what": f"types {type(a).__name__} vs {type(b).__name__}"})
    elif a != b:
        out.append({"at": where, "what": f"{str(a)[:60]} vs {str(b)[:60]}"})
    return out


def _load(p: Path):
    return torch.load(p, map_location="cpu", weights_only=False)


def compare(sub: str, panel: Path, scratch: Path, out: Path) -> int:
    rec = {"panel": str(panel), "scratch": str(scratch), "method": "value by value (torch.equal per tensor)",
           "excluded": ["/".join(x) for x in EXCLUDED] + [f"any key named {k}" for k in WALL_CLOCK], "jobs": {}}
    ok_all = True
    for ln in open(sub):
        if not ln.strip():
            continue
        rid = json.loads(ln)["run_id"]
        a, b = Path(panel) / "runs" / rid, Path(scratch) / "runs" / rid
        st = ((json.loads((b / "status.json").read_text()) if (b / "status.json").exists() else {}) or {}).get("status")
        ca = sorted(p.name for p in (a / "ckpt").glob("*.pt"))
        cb = sorted(p.name for p in (b / "ckpt").glob("*.pt"))
        j = {"retrained_status": st, "checkpoints_saved": len(ca), "checkpoints_retrained": len(cb),
             "only_saved": sorted(set(ca) - set(cb)), "only_retrained": sorted(set(cb) - set(ca)), "differing": {}}
        j["checkpoints_compared"] = len(set(ca) & set(cb))
        for name in sorted(set(ca) & set(cb)):
            d = diff(_load(a / "ckpt" / name), _load(b / "ckpt" / name))
            if d:
                j["differing"][name] = d
        ea = json.loads((a / "endpoint.json").read_text()) if (a / "endpoint.json").exists() else None
        eb = json.loads((b / "endpoint.json").read_text()) if (b / "endpoint.json").exists() else None
        de = diff(ea, eb)
        if de:
            j["differing"]["endpoint.json"] = de
        ok = st == "complete" and bool(ca) and ca == cb and not j["differing"]
        j["reproduced"] = ok
        ok_all &= ok
        rec["jobs"][rid] = j
    rec["n_jobs"] = len(rec["jobs"])
    rec["n_checkpoints_compared"] = sum(j_["checkpoints_compared"] for j_ in rec["jobs"].values())
    rec["reproduced"] = ok_all and rec["n_jobs"] > 0
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    Path(out).write_text(json.dumps(rec, indent=1))
    print(json.dumps({"n_jobs": rec["n_jobs"], "checkpoints": rec["n_checkpoints_compared"],
                      "reproduced": rec["reproduced"],
                      "not_reproduced": {r: {k: j_[k] for k in ("retrained_status", "only_saved", "only_retrained")} |
                                         {"differing": {c: d[:3] for c, d in j_["differing"].items()}}
                                         for r, j_ in rec["jobs"].items() if not j_["reproduced"]}}))
    return 0 if rec["reproduced"] else 1


def main(argv=None) -> int:
    a = sys.argv[1:] if argv is None else list(argv)
    if len(a) >= 4 and a[0] == "select":
        f0 = a[a.index("--f0") + 1] if "--f0" in a else None
        st = a[a.index("--states") + 1].split(",") if "--states" in a else []
        if not f0 or not st:
            print(__doc__)
            return 2
        return select(a[1], a[2], f0, st)
    if len(a) == 5 and a[0] == "compare":
        return compare(a[1], Path(a[2]), Path(a[3]), Path(a[4]))
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main())
