"""v59: audited cross-version reuse of finished runs (configs/reuse_audits.json).

An audit names ONE earlier semantic code hash (produced_by), ONE current hash (accepted_for), the job kinds it
covers (and dissipation methods it excludes), the reason the code those jobs execute is unchanged, and how each
reuse is verified.  Only audits whose accepted_for is the current code's hash are loaded: an audit of other code
is not this code's.  Nothing here changes a run's provenance."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

REQUIRED = ("id", "produced_by_semantic_hash", "accepted_for_semantic_hash", "scope", "reason", "verification")


class AuditError(ValueError):
    pass


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def load(path, sem: str) -> list:
    """the audits of `path` that accept runs for the current semantic hash `sem` (each checked for its fields)."""
    doc = json.loads(Path(path).read_text())
    out = []
    for a in doc.get("audits") or []:
        miss = [k for k in REQUIRED if not a.get(k)]
        if miss:
            raise AuditError(f"audit {a.get('id')}: missing {miss}")
        sc = a["scope"]
        if not isinstance(sc.get("kinds"), list) or not sc["kinds"]:
            raise AuditError(f"audit {a['id']}: its scope names no job kinds")
        if a["produced_by_semantic_hash"] == a["accepted_for_semantic_hash"]:
            raise AuditError(f"audit {a['id']}: produced_by equals accepted_for")
        if a["accepted_for_semantic_hash"] == sem:
            out.append({**a, "_file": str(path), "_file_sha256": sha256_file(Path(path))})
    if len({a["produced_by_semantic_hash"] for a in out}) != len(out):
        raise AuditError("two audits for the same produced_by hash")
    return out


def in_scope(audit: dict, cfg: dict) -> bool:
    sc = audit["scope"]
    if cfg.get("kind") not in sc["kinds"]:
        return False
    if cfg.get("kind") == "dissipation" and \
            (cfg.get("dissipation") or {}).get("method") in (sc.get("excluded_dissipation_methods") or []):
        return False
    return True


def covering(audits: list, produced_by: str, cfg: dict):
    """the audit that accepts a run produced by `produced_by` with configuration `cfg`, or None."""
    for a in audits:
        if a["produced_by_semantic_hash"] == produced_by and in_scope(a, cfg):
            return a
    return None


def tree_digest(d: Path) -> dict:
    """{relative path: sha256} of every file under d."""
    d = Path(d)
    return {str(p.relative_to(d)): sha256_file(p) for p in sorted(d.rglob("*")) if p.is_file()}


def digest_of(tree: dict) -> str:
    return hashlib.sha256(json.dumps(tree, sort_keys=True).encode()).hexdigest()
