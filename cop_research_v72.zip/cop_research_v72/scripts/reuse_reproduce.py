"""v59 / v60: the reproduction check of an audited cross-version reuse (configs/reuse_audits.json).

  python scripts/reuse_reproduce.py select MANIFEST PANEL SUBMANIFEST
  python scripts/reuse_reproduce.py compare SUBMANIFEST PANEL SCRATCH OUT_JSON

select   from the runs of PANEL that were copied under an audit (a reuse_accepted.jsonl record written by
         scripts/seed_panel.py --audited for the current code), a sample with every ancestor: the first audited
         baseline (by run id), its first audited trajectory and that trajectory's audited dissipation forks at its
         latest fork point; then, for every class of audited run the sample does not cover yet (kind, dissipation
         method, design arm), the first audited run of that class.  Written as a manifest (the original lines, in
         manifest order).  Exit 0; 5 only when PANEL holds no audited run at all (nothing to verify); 1 when an
         audited run's ancestor is not in the manifest (a coverage error).
compare  every job of SUBMANIFEST, retrained from scratch under the current code into SCRATCH (cop run), against
         the reused copy in PANEL, checkpoint by checkpoint (ckpt/*.pt; the same set must exist), section by section:
           model      the graph specification (nodes, operations, connections, merge coefficients, gates, outputs),
                      every tensor's value, dtype and shape, and the recorded dtypes
           optimizer  the optimizer state by parameter NAME (moments, step counters) and its hyperparameters
           trainer    the trainer's state (step counters, sampler position and permutation, batch-id hash, exposure
                      records) and the random generators' states
           lineage    run id, stage, parents, graph / parameter / configuration hashes, split hashes
           extra, numerics
         Excluded explicitly (incidental): the code hash in the lineage (the code differs by design: that is what the
         audit covers) and every wall-clock field (keys named in WALL_CLOCK: timing, seconds, ...).  endpoint.json's checkpoint hash must agree as well.
         Exit 0 when everything agrees, 1 otherwise; the record (which sections of which checkpoints differ) goes to
         OUT_JSON.
Training is deterministic here (cop.utils sets deterministic algorithms), so an audited reuse whose code argument
holds reproduces bit for bit on the same machine and libraries; a difference means the reuse is not verified."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import torch  # noqa: E402
from cop.utils import semantic_code_hash, stable_hash, tensor_hash  # noqa: E402


def _json(p: Path):
    try:
        return json.loads(Path(p).read_text())
    except (OSError, ValueError):
        return None


def audited(run_dir: Path, sem: str) -> bool:
    p = Path(run_dir) / "reuse_accepted.jsonl"
    if not p.exists():
        return False
    for ln in p.read_text().splitlines():
        if ln.strip():
            r = json.loads(ln)
            if r.get("accepted_for_semantic_hash") == sem and r.get("audit_id") and \
                    str(r.get("user", "")).startswith("seed_panel"):
                return True
    return False


def _klass(cfg: dict) -> tuple:
    return (cfg.get("kind"), (cfg.get("dissipation") or {}).get("method"), (cfg.get("design") or {}).get("arm"))


def _with_ancestors(rids, by: dict) -> set:
    out, todo = set(), list(rids)
    while todo:
        r = todo.pop()
        if r in out:
            continue
        if r not in by:
            raise KeyError(r)
        out.add(r)
        todo.extend((by[r]["cfg"].get("parents") or {}).values())
    return out


def select(man: str, panel: Path, sub: Path) -> int:
    sem = semantic_code_hash()
    lines = [json.loads(ln) for ln in open(man) if ln.strip()]
    by = {e["run_id"]: e for e in lines}
    au = sorted(rid for rid in by if audited(panel / "runs" / rid, sem))
    if not au:
        print(json.dumps({"audited_runs": 0, "selected": 0}))
        return 5
    core = []
    bases = [r for r in au if by[r]["cfg"]["kind"] == "baseline"]
    if bases:
        b = bases[0]
        core.append(b)
        trajs = [r for r in au if by[r]["cfg"]["kind"] == "trajectory"
                 and (by[r]["cfg"].get("parents") or {}).get("baseline") == b]
        if trajs:
            t = trajs[0]
            core.append(t)
            forks = [r for r in au if by[r]["cfg"]["kind"] == "dissipation"
                     and (by[r]["cfg"].get("parents") or {}).get("trajectory") == t]
            stages = sorted({(by[r]["cfg"].get("tags") or {}).get("parent_stage") or "" for r in forks},
                            key=lambda s_: int(s_.split("_")[1]) if s_.startswith("snap_") else -1)
            if stages:
                core += [r for r in forks if ((by[r]["cfg"].get("tags") or {}).get("parent_stage") or "")
                         == stages[-1]]
    covered = {_klass(by[r]["cfg"]) for r in core}
    for r in au:                                 # every class of audited run is represented
        k = _klass(by[r]["cfg"])
        if k not in covered:
            core.append(r)
            covered.add(k)
    try:
        pick = _with_ancestors(core, by)
    except KeyError as ex:
        print(json.dumps({"audited_runs": len(au), "selected": 0,
                          "coverage_error": f"an ancestor {ex} of an audited run is not in the manifest"}))
        return 1
    out = [e for e in lines if e["run_id"] in pick]
    sub.parent.mkdir(parents=True, exist_ok=True)
    sub.write_text("".join(json.dumps(e) + "\n" for e in out))
    print(json.dumps({"audited_runs": len(au), "selected": len(out),
                      "audited_classes": sorted(map(str, {_klass(by[r]["cfg"]) for r in au})),
                      "kinds": {k: sum(1 for e in out if e["cfg"]["kind"] == k) for k in
                                sorted({e["cfg"]["kind"] for e in out})}}))
    return 0


EXCLUDED = (("lineage", "code_hash"),)             # incidental: see the module description
WALL_CLOCK = ("timing", "seconds", "train_seconds", "time", "wall_seconds", "elapsed")   # any wall-clock field


def canon(o, path=()):
    """a JSON-able canonical form of a checkpoint part: tensors by dtype, shape and content hash; mappings sorted."""
    if path in EXCLUDED or (path and path[-1] in WALL_CLOCK):
        return "<excluded>"
    if torch.is_tensor(o):
        return {"dtype": str(o.dtype), "shape": list(o.shape), "hash": tensor_hash(o)}
    if isinstance(o, dict):
        return {str(k): canon(v, path + (str(k),)) for k, v in sorted(o.items(), key=lambda kv: str(kv[0]))}
    if isinstance(o, (list, tuple)):
        return [canon(v, path + ("[]",)) for v in o]
    if isinstance(o, float):
        return repr(o)
    if o is None or isinstance(o, (bool, int, str)):
        return o
    return repr(o)


def sections(ck: dict) -> dict:
    """{section: digest} of one checkpoint (see the module description); the optimizer state keyed by name."""
    out = {}
    m = ck.get("model") or {}
    out["model"] = stable_hash(canon({"spec": m.get("spec"), "state": m.get("state"), "dtypes": m.get("dtypes")}))
    tr = ck.get("trainer") or {}
    opt = tr.get("opt") or {}
    names = list(tr.get("opt_param_names") or [])
    st_ = opt.get("state") or {}
    by_name = {(names[int(i)] if int(i) < len(names) else f"#{i}"): v for i, v in st_.items()}
    out["optimizer"] = stable_hash(canon({"state": by_name, "param_groups": opt.get("param_groups"),
                                          "names": sorted(names)}))
    out["trainer"] = stable_hash(canon({k: v for k, v in tr.items() if k not in ("opt", "opt_param_names")},
                                       ("trainer",)))
    for k in ("lineage", "extra", "numerics"):
        out[k] = stable_hash(canon(ck.get(k), (k,)))
    return out


def checkpoint_sections(run_dir: Path) -> dict:
    out = {}
    for p in sorted((Path(run_dir) / "ckpt").glob("*.pt")):
        ck = torch.load(p, map_location="cpu", weights_only=False)
        if isinstance(ck, dict) and ck.get("model"):
            out[p.stem] = sections(ck)
    return out


def compare(sub: str, panel: Path, scratch: Path, out: Path) -> int:
    rec = {"semantic_hash": semantic_code_hash(), "panel": str(panel), "scratch": str(scratch),
           "excluded": ["/".join(x) for x in EXCLUDED] + [f"any key named {k}" for k in WALL_CLOCK], "jobs": {}}
    ok_all = True
    for ln in open(sub):
        if not ln.strip():
            continue
        rid = json.loads(ln)["run_id"]
        a, b = panel / "runs" / rid, scratch / "runs" / rid
        st = (_json(b / "status.json") or {}).get("status")
        ha, hb = checkpoint_sections(a), (checkpoint_sections(b) if st == "complete" else {})
        ea, eb = _json(a / "endpoint.json") or {}, _json(b / "endpoint.json") or {}
        diff = {k: sorted(s_ for s_ in set(ha.get(k) or {}) | set(hb.get(k) or {})
                          if (ha.get(k) or {}).get(s_) != (hb.get(k) or {}).get(s_)) or ["missing"]
                for k in sorted(set(ha) | set(hb)) if ha.get(k) != hb.get(k)}
        ep_ok = ea.get("checkpoint_param_hash") == eb.get("checkpoint_param_hash")
        ok = st == "complete" and bool(ha) and not diff and ep_ok
        ok_all &= ok
        rec["jobs"][rid] = {"retrained_status": st, "checkpoints": len(ha), "differing": diff,
                            "endpoint_hash_agrees": ep_ok, "reproduced": ok}
    rec["n_jobs"] = len(rec["jobs"])
    rec["reproduced"] = ok_all and rec["n_jobs"] > 0
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(rec, indent=1))
    print(json.dumps({"n_jobs": rec["n_jobs"], "reproduced": rec["reproduced"],
                      "not_reproduced": {r: j["differing"] for r, j in rec["jobs"].items() if not j["reproduced"]}}))
    return 0 if rec["reproduced"] else 1


def main(argv=None) -> int:
    a = sys.argv[1:] if argv is None else list(argv)
    if len(a) == 4 and a[0] == "select":
        return select(a[1], Path(a[2]), Path(a[3]))
    if len(a) == 5 and a[0] == "compare":
        return compare(a[1], Path(a[2]), Path(a[3]), Path(a[4]))
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main())
