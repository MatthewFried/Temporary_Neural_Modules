"""v70: take v69's analyses (fork29, image30, fork31, mech31) instead of recomputing them, only when nothing they
depend on changed.

  python scripts/reuse_v69.py V69_CODE V70_CODE V69_REPORTS OUT_DIR

Conditions, each checked directly:
  code       every file of the two code trees is byte for byte the same (filecmp, not a hash), apart from the files
             v70 changed on purpose (CHANGED: the reference, the registry, the new scripts, the launcher, tests and
             documentation); any other difference: nothing is reused
  finished   V69_REPORTS/verdict.json exists, its steps record the analysis (exit 0, or 1 for a strict analysis that
             completed with failed audits) and its view, and it is newer than every file taken (the run that wrote
             the files had finished)
  complete   the analysis coverage says analysis_complete
Per group (29: view29 + fork29; 30: view30 + image30; 31: fork31 + mech31 + the wave-31 manifest v69 used) the files
are copied into OUT_DIR unchanged, with v69's step logs as <step>_v69.txt.  Writes OUT_DIR/reused_groups.txt (one
group per line) and OUT_DIR/reuse_v69.json (what was taken, from where, and why a group was not).  Exit 0."""
from __future__ import annotations

import filecmp
import json
import shutil
import sys
from pathlib import Path

CHANGED = {"audit_v5/tools/reference_impl.py", "audit_v5/tools/reference_recompute.py",
           "scripts/replication_registry.py", "scripts/retrain_sample.py", "scripts/reuse_v69.py",
           "scripts/70_v70_reanalysis.sh"}
CHANGED_PREFIX = ("tests/", "manifests/", "PATCH_", "CHANGES_", "DEVIATIONS", "README")
SKIP_PARTS = {"__pycache__", ".pytest_cache", ".git"}
GROUPS = {"29": {"steps": {"view29": (0,), "fork29": (0, 1)}, "prefixes": ("fork29_",),
                 "files": ("view29.json", "view29_manifest.jsonl"), "coverage": ("fork29_coverage.json",)},
          "30": {"steps": {"view30": (0,), "image30": (0, 1)}, "prefixes": ("image30_",),
                 "files": ("view30.json", "view30_manifest.jsonl"), "coverage": ("image30_coverage.json",)},
          "31": {"steps": {"fork31": (0, 1), "mech31": (0, 1)}, "prefixes": ("fork31_", "mech31_"),
                 "files": ("wave31_full.jsonl",), "coverage": ("fork31_coverage.json",)}}


def tree(root: Path) -> set:
    return {str(p.relative_to(root)) for p in root.rglob("*")
            if p.is_file() and not (set(p.relative_to(root).parts) & SKIP_PARTS) and p.suffix != ".pyc"}


def code_differences(a: Path, b: Path) -> list:
    ta, tb = tree(a), tree(b)
    out = []
    for rel in sorted(ta | tb):
        if rel in CHANGED or rel.startswith(CHANGED_PREFIX):
            continue
        if rel not in ta or rel not in tb:
            out.append(f"{rel}: only in {'v70' if rel in tb else 'v69'}")
        elif not filecmp.cmp(a / rel, b / rel, shallow=False):
            out.append(f"{rel}: differs")
    return out


def main(argv=None) -> int:
    a = sys.argv[1:] if argv is None else list(argv)
    if len(a) != 4:
        print(__doc__)
        return 2
    c69, c70, rep, out = Path(a[0]), Path(a[1]), Path(a[2]), Path(a[3])
    out.mkdir(parents=True, exist_ok=True)
    rec = {"v69_code": str(c69), "v70_code": str(c70), "v69_reports": str(rep), "groups": {}}
    diffs = code_differences(c69, c70) if c69.is_dir() else [f"{c69}: no v69 code folder"]
    rec["code_differences"] = diffs
    vf = rep / "verdict.json"
    verdict = json.loads(vf.read_text()) if vf.exists() else None
    taken = []
    for g, spec in GROUPS.items():
        why = []
        if diffs:
            why.append(f"{len(diffs)} code files differ from v69 (e.g. {diffs[0]})")
        if verdict is None:
            why.append("v69 has no verdict.json (not run, or not finished)")
        else:
            st = verdict.get("steps") or {}
            for k, ok in spec["steps"].items():
                if st.get(k) not in ok:
                    why.append(f"v69's step {k} exited {st.get(k)}")
        files = [rep / f for f in spec["files"]]
        files += sorted(p for pre in spec["prefixes"] for p in rep.glob(f"{pre}*") if p.is_file())
        for f in spec["files"]:
            if not (rep / f).exists():
                why.append(f"no {f}")
        for cf in spec["coverage"]:
            p = rep / cf
            if not p.exists():
                why.append(f"no {cf}")
            elif not json.loads(p.read_text()).get("analysis_complete"):
                why.append(f"{cf}: the analysis did not complete")
        if verdict is not None and files and max(f.stat().st_mtime for f in files if f.exists()) > vf.stat().st_mtime:
            why.append("files newer than v69's verdict.json (v69 still running?)")
        if why:
            rec["groups"][g] = {"reused": False, "why": why}
            continue
        for f in files:
            shutil.copy2(f, out / f.name)
        for k in spec["steps"]:
            if (rep / f"{k}.txt").exists():
                shutil.copy2(rep / f"{k}.txt", out / f"{k}_v69.txt")
        rec["groups"][g] = {"reused": True, "files": [f.name for f in files],
                            "v69_exit": {k: (verdict.get("steps") or {}).get(k) for k in spec["steps"]}}
        taken.append(g)
    (out / "reused_groups.txt").write_text("".join(g + "\n" for g in taken))
    (out / "reuse_v69.json").write_text(json.dumps(rec, indent=1))
    print(json.dumps({"reused": taken, "not_reused": {g: r["why"] for g, r in rec["groups"].items()
                                                      if not r["reused"]}}))
    return 0


if __name__ == "__main__":
    sys.exit(main())
