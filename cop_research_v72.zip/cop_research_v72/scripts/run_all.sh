#!/usr/bin/env bash
# Master script: resumable chunks.  Re-running continues where it stopped.
#   MAX_JOBS=200 scripts/run_all.sh     # stop after 200 jobs per wave this session
source "$(dirname "$0")/common.sh"
EXTRA=()
if [ -n "${MAX_JOBS:-}" ]; then EXTRA+=(--max-jobs "$MAX_JOBS"); fi
if [ -n "${JOB_TIME_LIMIT:-}" ]; then EXTRA+=(--time-limit "$JOB_TIME_LIMIT"); fi
bash "$COP_HOME/scripts/01_cpu_exact_tests.sh"
bash "$COP_HOME/scripts/02_gpu_calibration.sh"
bash "$COP_HOME/scripts/10_wsl_gpu_pilot.sh"
if [ "${PILOT_REVIEWED:-0}" != "1" ]; then
  echo "Integration pilot done: review $COP_RESULTS/pilot/pilot_report.json (and send cop_wsl_pilot_v5.zip for review)."
  echo "Set PILOT_REVIEWED=1 to continue with the sweeps (waves 1-5)."
  exit 0
fi
for s in 03_wave1_sweeps 04_wave2_real_data 05_wave3_topology_history 06_wave4_deletion_repair 07_wave5_cop; do
  bash "$COP_HOME/scripts/$s.sh" "${EXTRA[@]}"
done
bash "$COP_HOME/scripts/09_summarize_package.sh"
