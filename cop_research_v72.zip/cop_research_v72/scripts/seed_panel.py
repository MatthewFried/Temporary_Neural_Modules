"""v57: copy finished runs of an earlier panel into a new panel's results folder, for the jobs the two manifests share.
v59: audited cross-version reuse (--audited configs/reuse_audits.json).

  python scripts/seed_panel.py MANIFEST SOURCE_PANEL DEST_PANEL OUT_JSON [--audited AUDITS_JSON]

A run id is the hash of the resolved configuration and the semantics version, and a run folder is self-contained
(config, checkpoints with their lineage, logs).  So when the new manifest holds a job with the same run id AND the
same full configuration as a finished run of SOURCE_PANEL, that run is the job, and it is copied instead of being
trained again.  For every manifest job:
  already there   DEST_PANEL already has a folder for it: left alone, never overwritten
  copied          SOURCE_PANEL has it complete and valid, its saved configuration is the manifest's (full
                  configuration hash, descriptive tags included, which the checkpoints' lineage records) and hashes to
                  its run id, and it was written by code of the current semantics, or (--audited) by the earlier
                  semantics an audit names for the current code, the job's kind in the audit's scope.  Copied to a
                  temporary name, checked file by file (SHA-256) against the source, and renamed.  An audited copy
                  gets one reuse_accepted.jsonl record (the audit, its reason, the verification) in the COPY; its
                  provenance is not touched, and the source is never written
  to train        anything else (not in the source, not complete, other semantics without a covering audit, another
                  configuration)
A missing source copies nothing.  The record (what was copied from where, under which audit, digests) goes to
OUT_JSON.  Exit 0 unless a copy fails (1) or the arguments are wrong (2)."""
from __future__ import annotations

import json
import os
import shutil
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from cop.config import run_id as make_run_id  # noqa: E402
from cop.utils import semantic_code_hash, stable_hash  # noqa: E402
import reuse_audit as RA  # noqa: E402


def _json(p: Path):
    try:
        return json.load(open(p))
    except (OSError, ValueError):
        return None


def usable(src: Path, cfg: dict, sem: str, audits=(), rid: str = "") -> tuple:
    """('', audit or None) when the source run is this job, finished; else (the reason it is not used, None)."""
    st = _json(src / "status.json") or {}
    if st.get("status") != "complete":
        return f"status {st.get('status', 'missing')}", None
    if st.get("validity", "valid") != "valid":
        return f"validity {st.get('validity')}", None
    saved = _json(src / "config.json")
    if saved is None or stable_hash(saved) != stable_hash(cfg):
        return "its saved configuration is not the manifest's", None
    if rid and make_run_id(saved) != rid:
        return "its saved configuration does not hash to its run id", None
    produced = (_json(src / "provenance.json") or {}).get("semantic_hash")
    if produced == sem:
        return "", None
    au = RA.covering(audits, produced, cfg) if produced else None
    if au is None:
        return "written by code of other semantics (no audit covers it)", None
    return "", au


def size_of(d: Path) -> int:
    return sum(f.stat().st_size for f in d.rglob("*") if f.is_file())


def main(argv=None) -> int:
    argv = sys.argv[1:] if argv is None else list(argv)
    audit_file = None
    if "--audited" in argv:
        i = argv.index("--audited")
        if i + 1 >= len(argv):
            print(__doc__)
            return 2
        audit_file = argv[i + 1]
        del argv[i:i + 2]
    if len(argv) != 4:
        print(__doc__)
        return 2
    man, src_root, dst_root, out = argv[0], Path(argv[1]), Path(argv[2]), Path(argv[3])
    if src_root.resolve() == dst_root.resolve():
        print("the source and the destination are the same folder")
        return 2
    sem = semantic_code_hash()
    try:
        audits = RA.load(audit_file, sem) if audit_file else []
    except (OSError, ValueError) as ex:
        print(f"the audit file cannot be used: {ex}")
        return 2
    rec = {"manifest": man, "source": str(src_root), "destination": str(dst_root), "semantic_hash": sem,
           "audit_file": audit_file, "audits_for_this_code": [a["id"] for a in audits],
           "time": time.time(), "copied": [], "copied_audited": {}, "already_there": [], "to_train": {},
           "bytes_copied": 0, "digests": {}}
    (dst_root / "runs").mkdir(parents=True, exist_ok=True)
    rc = 0
    for line in open(man):
        if not line.strip():
            continue
        e = json.loads(line)
        rid = e["run_id"]
        dst, src = dst_root / "runs" / rid, src_root / "runs" / rid
        if dst.exists():
            rec["already_there"].append(rid)
            continue
        why, au = ("not in the source", None) if not src.is_dir() else usable(src, e["cfg"], sem, audits, rid)
        if why:
            rec["to_train"][rid] = why
            continue
        tmp = dst_root / "runs" / f".seeding-{rid}"
        try:
            if tmp.exists():
                shutil.rmtree(tmp)
            want = RA.tree_digest(src)
            shutil.copytree(src, tmp)
            got = RA.tree_digest(tmp)
            if got != want:
                raise OSError("the copy differs from the source (SHA-256 of its files)")
            n = size_of(tmp)
            dig = RA.digest_of(got)
            if au is not None:
                prov = _json(tmp / "provenance.json") or {}
                entry = {"accepted_for_semantic_hash": sem, "produced_by_semantic_hash": prov.get("semantic_hash"),
                         "reason": au["reason"], "time": time.time(), "user": "seed_panel (audited)",
                         "audit_id": au["id"], "audit_file": au["_file"], "audit_file_sha256": au["_file_sha256"],
                         "audit_doc": au.get("audit_doc"), "source_run": str(src.resolve()),
                         "verification": {"status": "complete", "validity": "valid",
                                          "config_equals_manifest": True, "config_hashes_to_run_id": True,
                                          "kind": e["cfg"].get("kind"),
                                          "method": (e["cfg"].get("dissipation") or {}).get("method"),
                                          "files": len(got), "copy_identical_sha256": True,
                                          "tree_sha256": dig, "procedure": au["verification"]}}
                with open(tmp / "reuse_accepted.jsonl", "a") as f:
                    f.write(json.dumps(entry, sort_keys=True) + "\n")
            os.replace(tmp, dst)
        except OSError as ex:
            shutil.rmtree(tmp, ignore_errors=True)
            print(f"copy of {rid} failed: {ex}")
            rec["to_train"][rid] = f"copy failed: {ex}"
            rc = 1
            continue
        rec["copied"].append(rid)
        rec["digests"][rid] = dig
        if au is not None:
            rec["copied_audited"][rid] = au["id"]
        rec["bytes_copied"] += n
    rec["n_copied"], rec["n_copied_audited"], rec["n_already_there"], rec["n_to_train"] = (
        len(rec["copied"]), len(rec["copied_audited"]), len(rec["already_there"]), len(rec["to_train"]))
    reasons = {}
    for why in rec["to_train"].values():
        reasons[why] = reasons.get(why, 0) + 1
    rec["to_train_reasons"] = reasons
    out.parent.mkdir(parents=True, exist_ok=True)
    json.dump(rec, open(out, "w"), indent=1)
    print(json.dumps({k: rec[k] for k in ("source", "n_copied", "n_copied_audited", "n_already_there", "n_to_train",
                                           "bytes_copied", "to_train_reasons")}))
    return rc


if __name__ == "__main__":
    sys.exit(main())
