#!/usr/bin/env bash
# Create an ISOLATED venv for this project (does not touch ~/venv or other projects).
# PyTorch comes from the official wheel index.  Default CUDA 12.6 wheels work with any
# Windows NVIDIA driver that supports CUDA 12.x; with a driver that supports CUDA 13
# you may use TORCH_INDEX=cu130.  Do NOT install a Linux NVIDIA driver inside WSL.
set -euo pipefail
COP_HOME="${COP_HOME:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
COP_VENV="${COP_VENV:-$COP_HOME/.venv}"
TORCH_INDEX="${TORCH_INDEX:-cu126}"
TORCH_VERSION="${TORCH_VERSION:-2.14.1}"
TV_VERSION="${TV_VERSION:-0.29.1}"
PY="${PYTHON:-python3}"
if [[ "$COP_HOME" == /mnt/* ]]; then
  echo "WARNING: project is on the Windows-mounted filesystem ($COP_HOME); the Linux side (e.g. ~/cop_research_v12) is much faster." >&2
fi
$PY -m venv "$COP_VENV"
source "$COP_VENV/bin/activate"
python -m pip install --upgrade pip wheel
python -m pip install "torch==${TORCH_VERSION}" "torchvision==${TV_VERSION}" --index-url "https://download.pytorch.org/whl/${TORCH_INDEX}"
python -m pip install -r "$COP_HOME/requirements.txt"
python -m pip freeze > "$COP_HOME/requirements-lock.txt"
mkdir -p "${COP_RESULTS:-$HOME/cop_results_v5}"
cd "$COP_HOME"
PYTHONPATH="$COP_HOME" python -m cop.cli inspect-environment --out "${COP_RESULTS:-$HOME/cop_results_v5}/environment.json"
echo "venv ready at $COP_VENV ; environment report in ${COP_RESULTS:-$HOME/cop_results_v5}/environment.json"
