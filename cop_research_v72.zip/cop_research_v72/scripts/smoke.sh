#!/usr/bin/env bash
# Fresh-environment smoke test (T24): tiny CPU run of the whole pipeline in a temp results dir.
source "$(dirname "$0")/common.sh"
export COP_RESULTS="${COP_SMOKE_RESULTS:-/tmp/cop_smoke_results}"
rm -rf "$COP_RESULTS"; mkdir -p "$COP_RESULTS"
m="$COP_HOME/manifests/smoke.jsonl"
cop generate-manifest --wave 0 --scale smoke --out "$m"
cop validate-manifest --manifest "$m"
cop run --manifest "$m" --results "$COP_RESULTS" --device cpu --kinds finite
python - <<'PY'
from cop.config import resolve
from cop.orchestration.runner import run_job
import os
root=os.environ["COP_RESULTS"]
base=dict(data={"name":"teacher","n_train":512,"n_val":256,"n_test":512,"params":{"teacher_depth":1}},
          model={"family":"mlp","depth":3,"width":16}, train={"baseline_updates":60,"batch_size":64})
for topo in ["recursive_branch","cancel_pair"]:
    c=resolve({"kind":"trajectory", **base, "growth":{"topology":topo,"rounds":2,"updates_per_round":30}})
    print(topo, run_job(c, root, {"device":"cpu"}))
c=resolve({"kind":"cop","data":{"name":"compose","n_train":512,"n_val":256,"n_test":512},
           "model":{"family":"mlp","depth":6,"width":16},"train":{"baseline_updates":60,"batch_size":64},
           "cop":{"task_kind":"cycles","local_updates":20,"global_updates":40,"cycles":2},"peg":{"dim":4,"anneal_updates":10}})
print("cop cycles", run_job(c, root, {"device":"cpu"}))
PY
cop summarize --results "$COP_RESULTS" --manifest "$m"
