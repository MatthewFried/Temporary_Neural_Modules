"""v66: the per-run validity table of a fork analysis (fork_continuation.py or image_forks.py).

  python scripts/validity_table.py PREFIX        (reads PREFIX_audits.csv, PREFIX_states.csv; writes PREFIX_validity.csv)

One row per audited fork run (f0, parent, fork point, continuation) and per measured control state:
  audit_passed        every audit check of the run passed (failed_checks names the ones that did not)
  integrity           the edit's saved start (event_after_fold / event_after_redistribute) passed check_ckpt
                      (recomputed tensor hash, finite tensors, run, stage, configuration, data hashes); for every other
                      measured checkpoint check_ckpt runs inline and a failure fails the whole f0, so a listed row
                      passed it ("inline")
  algebra64           the edit rebuilt in float64 against the snapshot in float64 (relative logits)
  storage64           the SAVED float32 start evaluated in float64 against the snapshot in float64 (a certificate in
                      v66: above STORAGE_TOL fails the audit)
  forward32           the saved start against the snapshot in float32 on the analysis device (reported)
  recorded_device32   the same on the training device (with --recorded-device; reported)
  finite              every evaluation of a measured state is checked finite (finite_eval raises otherwise): "True"
  normalised_eligible each normalised metric's eligibility (norm attained within NORM_TOL, no unmatched zero row)
Exit 0 when the table was written, 2 on wrong arguments."""
from __future__ import annotations

import csv
import sys
from pathlib import Path

CHECKS = ("starts_from_snapshot", "updates", "stream_batches", "optimizer_policy", "mask_membership", "parameters",
          "fold_start", "fold_function", "redistribution", "redistribution_storage", "held_column", "lr_schedule",
          "stream_shared")


def main(argv=None) -> int:
    a = sys.argv[1:] if argv is None else list(argv)
    if len(a) != 1:
        print(__doc__)
        return 2
    pre = a[0]
    aud = list(csv.DictReader(open(f"{pre}_audits.csv")))
    st = list(csv.DictReader(open(f"{pre}_states.csv")))
    elig_cols = [k for k in (st[0] if st else {}) if k.endswith("_eligible")]
    sk = {(r["f0"], r["parent"], r["fork"], r["state"]): r for r in st}
    out = []
    seen = set()
    for r in aud:
        k = (r["f0"], r["parent"], r["fork"], r["state"])
        seen.add(k)
        integ = ""
        for col in ("fold_start_detail", "redistribution_detail"):
            d = r.get(col) or ""
            if d.startswith("integrity: run, stage"):
                integ = "True"
            elif d.startswith("integrity:"):
                integ = "False"
        if not integ:
            integ = "inline"
        kind = "redistribution" if r.get("outcome_redistribution_algebra64") else (
            "fold" if r.get("outcome_fold_algebra64") else "")
        g = (lambda n: r.get(f"outcome_{kind}_{n}", "")) if kind else (lambda n: "")
        srow = sk.get(k) or {}
        out.append({"f0": r["f0"], "data_draw": r["data_draw"], "optimizer_seed": r["optimizer_seed"],
                    "parent": r["parent"], "fork": r["fork"], "state": r["state"], "run_id": r["run_id"],
                    "audit_passed": r["audit_passed"],
                    "failed_checks": " ".join(c for c in CHECKS if r.get(c) == "False"),
                    "integrity": integ, "edit": kind, "algebra64": g("algebra64"), "storage64": g("storage64"),
                    "forward32": g("forward32"), "recorded_device32": g("recorded_device_forward32"),
                    "finite": "True" if srow else "not measured",
                    **{c: srow.get(c, "") for c in elig_cols}})
    for k, srow in sk.items():
        if k in seen or k[3] in ("f0",):
            continue
        out.append({"f0": srow["f0"], "data_draw": srow.get("data_draw", ""),
                    "optimizer_seed": srow.get("optimizer_seed", ""), "parent": k[1], "fork": k[2], "state": k[3],
                    "run_id": "", "audit_passed": "not a fork (checked inline)", "failed_checks": "",
                    "integrity": "inline", "edit": "", "algebra64": "", "storage64": "", "forward32": "",
                    "recorded_device32": "", "finite": "True", **{c: srow.get(c, "") for c in elig_cols}})
    keys = ["f0", "data_draw", "optimizer_seed", "parent", "fork", "state", "run_id", "audit_passed", "failed_checks",
            "integrity", "edit", "algebra64", "storage64", "forward32", "recorded_device32", "finite", *elig_cols]
    with open(f"{pre}_validity.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(out)
    bad = [r for r in out if r["audit_passed"] == "False" or r["integrity"] == "False"
           or any(r.get(c) == "False" for c in elig_cols)]
    print(f"{len(out)} rows, {len(bad)} with a failed audit, integrity or eligibility")
    return 0


if __name__ == "__main__":
    sys.exit(main())
