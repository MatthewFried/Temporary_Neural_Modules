import os
import sys
from pathlib import Path

import pytest
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
torch.set_num_threads(min(4, os.cpu_count() or 1))


@pytest.fixture
def results_dir(tmp_path):
    return tmp_path / "results"
