"""Job-level interrupted-versus-uninterrupted comparison.

For a job (with its prerequisite jobs), run it once uninterrupted in results
root A.  In root B, run the prerequisites, then run the job with the interrupt
flag raised at chosen points (the k-th poll of the job's loops, via the
utils.INTERRUPT countdown test hook), resuming with a new attempt each time
until it completes.  Compare:
  * every checkpoint present in both roots (model parameter hash), except
    transient partial / state files;
  * every *_result.json (timing fields removed);
  * metrics.jsonl values after de-duplication (latest attempt per key),
    timing / attempt fields removed;
  * the training-exposure counters in the summary.
Equality is bitwise on CPU (same process, same thread count).
"""
from __future__ import annotations

import json
import math
from pathlib import Path

import torch

from cop.config import run_id
from cop.orchestration.runner import run_job, status_of
from cop.utils import INTERRUPT, read_json, read_jsonl

TIMING = ("seconds", "elapsed", "time", "t", "train_seconds", "peak_memory_bytes", "attempt_id", "attempt",
          "code_hash", "environment_hash", "resolved_config_hash", "run_seconds")
TRANSIENT = ("partial", "state__", "diss_state", "diss_partial", "_grown", "progress_")


def _strip(o):
    if isinstance(o, dict):
        return {k: _strip(v) for k, v in o.items() if not any(k == t or k.endswith("_" + t) or k.startswith(t + "_")
                                                               for t in TIMING) and "second" not in k}
    if isinstance(o, list):
        return [_strip(v) for v in o]
    if isinstance(o, float) and math.isnan(o):
        return "nan"
    return o


def _metrics(run_dir: Path) -> dict:
    latest = {}
    for r in read_jsonl(run_dir / "metrics.jsonl"):
        key = (r["stage"], r["evaluation_partition"], r["metric_name"], json.dumps(r.get("atoms")), str(r.get("tag")))
        latest[key] = _strip({k: v for k, v in r.items() if k in ("metric_value", "training_updates", "examples_seen",
                                                                   "graph_hash")})
    return latest


def _ckpts(run_dir: Path) -> dict:
    out = {}
    for p in sorted((run_dir / "ckpt").glob("*.pt")):
        if any(t in p.name for t in TRANSIENT):
            continue
        ck = torch.load(p, map_location="cpu", weights_only=False)
        if isinstance(ck, dict) and "lineage" in ck:
            out[p.stem] = ck["lineage"]["param_hash"]
    return out


def _results(run_dir: Path) -> dict:
    files = sorted(run_dir.glob("*_result.json")) + [p for p in (run_dir / "endpoint.json",) if p.exists()]
    return {p.name: _strip(read_json(p)) for p in files}


def run_chain_of_jobs(cfgs: list[dict], root: Path, ex: dict) -> None:
    for c in cfgs:
        INTERRUPT["flag"] = False
        st = run_job(c, root, ex)
        if st != "complete":
            raise RuntimeError(f"prerequisite {c['kind']} ended {st}: {status_of(root, run_id(c))}")


def compare_interrupted(cfgs: list[dict], root: Path, fractions=(0.3, 0.7), ex=None) -> dict:
    """cfgs: prerequisites followed by the job under test (last)."""
    ex = ex or {"device": "cpu"}
    A, B = root / "A", root / "B"
    run_chain_of_jobs(cfgs[:-1], A, ex)
    job = cfgs[-1]
    INTERRUPT["flag"] = False
    p0 = INTERRUPT["polls"]
    assert run_job(job, A, ex) == "complete", status_of(A, run_id(job))
    n_polls = INTERRUPT["polls"] - p0
    run_chain_of_jobs(cfgs[:-1], B, ex)
    attempts, interrupted_at = [], []
    done = 0
    for f in fractions:
        k = max(1, int(round(f * n_polls)) - done)
        INTERRUPT["flag"] = False
        INTERRUPT["countdown"] = k
        before = INTERRUPT["polls"]
        st = run_job(job, B, ex)
        used = INTERRUPT["polls"] - before
        INTERRUPT["countdown"] = None
        attempts.append(st)
        if st == "pending":
            interrupted_at.append(done + k)
        done += used
        if st == "complete":
            break
    INTERRUPT["flag"] = False
    while attempts[-1] != "complete":
        attempts.append(run_job(job, B, ex))
        if len(attempts) > 10:
            break
    ra, rb = A / "runs" / run_id(job), B / "runs" / run_id(job)
    ca, cb = _ckpts(ra), _ckpts(rb)
    ma, mb = _metrics(ra), _metrics(rb)
    xa, xb = _results(ra), _results(rb)
    sa = read_json(ra / "summary.json")
    sb = read_json(rb / "summary.json")
    diff_ck = sorted(k for k in set(ca) | set(cb) if ca.get(k) != cb.get(k))
    diff_m = sorted(str(k) for k in set(ma) | set(mb) if ma.get(k) != mb.get(k))
    diff_x = sorted(k for k in set(xa) | set(xb) if xa.get(k) != xb.get(k))
    work_a = _strip(sa.get("work") or {})
    work_b = _strip(sb.get("work") or {})
    return {"kind": job["kind"], "task": (job.get("cop") or {}).get("task_kind") or (job.get("growth") or {}).get("topology"),
            "polls_uninterrupted": n_polls, "interrupted_at_polls": interrupted_at, "attempts": attempts,
            "n_checkpoints_compared": len(set(ca) & set(cb)), "checkpoints_differing": diff_ck,
            "n_metric_keys": len(ma), "metrics_differing": diff_m[:20], "n_metrics_differing": len(diff_m),
            "results_differing": diff_x, "work_equal": work_a == work_b,
            "equal": not diff_ck and not diff_m and not diff_x and work_a == work_b and len(interrupted_at) >= 1}
