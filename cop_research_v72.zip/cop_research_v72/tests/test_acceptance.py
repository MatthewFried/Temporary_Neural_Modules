"""Acceptance tests T01-T24 (spec section 16).

These are correctness gates with independent oracles (hand-computed numpy
forwards, least-squares refits, brute-force recomputation) wherever the
property allows.  Data-family checks for T10-T12 live in tests/test_data.py and
certificate checks for T07/T08 in tests/test_finite.py; this file adds the
graph/training-level parts and thin wrappers.
"""
from __future__ import annotations

import copy
import itertools
import json
import math
import subprocess
import sys
from pathlib import Path

import numpy as np
import pytest
import torch
import torch.nn.functional as F

from cop.config import resolve, run_id
from cop.data.registry import load_bundle
from cop.graph import edits as E
from cop.graph.accounting import count_params, count_macs, peg_messages, has_bypass
from cop.graph.builders import build_mlp, build_cnn, build_resnet, build_transformer, build_gru
from cop.graph.export import export_compact
from cop.graph.graph import GraphNet, InvalidDeletion
from cop.train import metrics as M
from cop.train.trainer import Trainer, Segment, task_loss, distill_loss
from cop.utils import torch_gen
from cop.experiments import control as CTRL

ROOT = Path(__file__).resolve().parents[1]
G = lambda k: torch_gen(0, "insertion", "test", k)


def tc(**kw):
    from cop.config import TRAIN_DEFAULTS
    t = dict(TRAIN_DEFAULTS)
    t.update(kw)
    return t


def vec_bundle(n=256, task="regression"):
    return load_bundle({"name": "teacher", "n_train": n, "n_val": 128, "n_test": 128,
                        "params": {"teacher_depth": 1, "task": task, "d_in": 8, "out_dim": 3}})


def family_model(fam):
    if fam == "mlp":
        return build_mlp(6, [8, 8, 8], 3, torch_gen(0, "init")), {"x": torch.randn(9, 6)}
    if fam == "cnn":
        return build_cnn(3, (8, 8), 4, torch_gen(0, "init"), 0.25), {"x": torch.randn(5, 3, 8, 8)}
    if fam == "resnet":
        return build_resnet(3, (8, 8), 4, torch_gen(0, "init"), 0.5), {"x": torch.randn(5, 3, 8, 8)}
    if fam == "transformer":
        return build_transformer(12, 16, 2, 2, 12, torch_gen(0, "init")), {"x": torch.randint(0, 12, (4, 7))}
    return build_gru(12, 16, 2, 12, torch_gen(0, "init")), {"x": torch.randint(0, 12, (4, 7))}


def dbl(X):
    return {k: (v.double() if v.is_floating_point() else v) for k, v in X.items()}


# ----------------------------------------------------------------------------- T01

@pytest.mark.parametrize("fam", ["mlp", "cnn", "resnet", "transformer", "gru"])
def test_T01_exact_insertions_all_constructions(fam):
    base, X = family_model(fam)
    base = base.double().eval()
    X = dbl(X)
    with torch.no_grad():
        y0 = base(X)
    n_checked = 0
    for name, fn in CTRL._constructions(base, G):
        g = base.clone(share_params=False).eval()
        try:
            ids = fn(g)
        except Exception as ex:  # inapplicable combination must say so explicitly
            assert "cut" in str(ex) or "segment" in str(ex) or "need" in str(ex), (name, ex)
            continue
        with torch.no_grad():
            y = g(X)
        err = (y - y0).abs().max().item() / (y0.abs().mean().item() + 1e-30)
        idents = {g.implants[i].identity for i in ids if i in g.implants}
        assert idents <= {"exact_identity", "output_preserving", "none"}, (name, idents)
        assert err < 1e-10, f"{fam}/{name}: rel err {err}"
        n_checked += 1
    assert n_checked >= 12


def test_T01_approximate_variants_are_labelled_and_detected():
    base, X = family_model("mlp")
    base = base.double().eval()
    X = dbl(X)
    y0 = base(X)
    g = base.clone(False)
    Gi, u, v = E.insert_cancel_pair(g, E.cut_at(g, "post_act", "middle"), G("n"), width=6, noise=1e-2)
    assert g.implants[v].identity == "approximate" and g.implants[Gi].identity == "approximate"
    assert (g(X) - y0).abs().max().item() > 0
    g = base.clone(False)
    Gi, T, Ti = E.insert_inverse_pair(g, E.cut_at(g, "post_act", "middle"), G("l"), tie="learned")
    assert g.implants[Gi].identity == "approximate"
    assert (g(X) - y0).abs().max().item() > 1e-6


def test_T01_relu_between_signed_activations_is_not_identity():
    """A bare ReLU inserted on signed activations changes the function, which is why
    no construction uses it as an 'identity'."""
    g = build_mlp(6, [8, 8], 3, torch_gen(0, "init"), act="tanh").double()
    X = {"x": torch.randn(20, 6, dtype=torch.float64)}
    y0 = g(X)
    c = E.cut_at(g, "post_act", 0)
    nid = g.add_node("act", [c.source], {"fn": "relu", "dim": g.node_dim(c.source)})
    g.replace_uses(c.source, nid, only=c.consumers)
    assert (g(X) - y0).abs().max().item() > 1e-6


# ----------------------------------------------------------------------------- T02

def _roles(g, iid):
    return {g.nodes[n].role: g.mods[g.nodes[n].pkey] for n in g.implants[iid].nodes if g.nodes[n].pkey}


def test_T02_gradients_reach_new_parameters():
    g, X = family_model("mlp")
    y = torch.randn(9, 3)
    i = E.insert_residual_zero(g, E.cut_at(g, "post_act", "middle"), G("a"), width=5)
    R = _roles(g, i)
    loss = F.mse_loss(g(X), y)
    loss.backward()
    assert R["A"].weight.grad.abs().max().item() == 0.0, "B=0 => dL/dA = 0 initially (correct, not dead)"
    assert R["B"].weight.grad.abs().max().item() > 0.0
    with torch.no_grad():
        R["B"].weight -= 0.5 * R["B"].weight.grad
    for p in g.parameters():
        p.grad = None
    F.mse_loss(g(X), y).backward()
    assert R["A"].weight.grad.abs().max().item() > 0.0, "after B moves, A receives gradient"
    # concat expansion: projection's new columns get gradient, A initially none
    g2, X2 = family_model("mlp")
    j = E.insert_concat_expand(g2, E.cut_at(g2, "post_act", "middle"), G("c"), width=4)
    R2 = _roles(g2, j)
    F.mse_loss(g2(X2), y).backward()
    d = g2.node_dim(g2.implants[j].entry)
    assert R2["P"].weight.grad[:, d:].abs().max().item() > 0
    assert R2["A"].weight.grad.abs().max().item() == 0.0
    # cancelling pair: both branches receive (opposite) gradients
    g3, X3 = family_model("mlp")
    Gc, u, v = E.insert_cancel_pair(g3, E.cut_at(g3, "post_act", "middle"), G("d"), width=4)
    F.mse_loss(g3(X3), y).backward()
    Bu, Bv = _roles(g3, u)["B"].weight.grad, _roles(g3, v)["B"].weight.grad
    assert Bu.abs().max() > 0 and torch.allclose(Bu, -Bv)


# ----------------------------------------------------------------------------- T03

def _train_steps(g, n=25, seed=0):
    torch.manual_seed(seed)
    X = {"x": torch.randn(64, 6, dtype=torch.float64)}
    y = torch.randn(64, 3, dtype=torch.float64)
    opt = torch.optim.AdamW([p for p in g.parameters() if p.requires_grad], lr=0.05)
    for _ in range(n):
        loss = F.mse_loss(g(X), y)
        opt.zero_grad()
        loss.backward()
        opt.step()
    return X


def test_T03_tied_stay_tied_untied_diverge():
    base, _ = family_model("mlp")
    base = base.double()
    # tied cancel pair: shared storage, cancels forever
    g = base.clone(False)
    Gt, u, v = E.insert_cancel_pair(g, E.cut_at(g, "post_act", "middle"), G("t"), width=5, tied=True)
    pu = [g.nodes[n].pkey for n in g.implants[u].nodes if g.nodes[n].pkey]
    pv = [g.nodes[n].pkey for n in g.implants[v].nodes if g.nodes[n].pkey]
    assert pu == pv
    X = _train_steps(g)
    assert (g(X) - E.delete(g, [Gt])(X)).abs().max().item() < 1e-12
    # untied: independent storage that diverges under training
    g = base.clone(False)
    Gu, u, v = E.insert_cancel_pair(g, E.cut_at(g, "post_act", "middle"), G("u"), width=5)
    mu = [g.mods[g.nodes[n].pkey] for n in g.implants[u].nodes if g.nodes[n].pkey]
    mv = [g.mods[g.nodes[n].pkey] for n in g.implants[v].nodes if g.nodes[n].pkey]
    for a, b in zip(mu, mv):
        assert a.weight.data_ptr() != b.weight.data_ptr()
    X = _train_steps(g)
    assert max((a.weight - b.weight).abs().max().item() for a, b in zip(mu, mv)) > 1e-4
    assert (g(X) - E.delete(g, [Gu])(X)).abs().max().item() > 1e-6
    # enforced inverse stays an exact inverse after training
    g = base.clone(False)
    Gi, T, Ti = E.insert_inverse_pair(g, E.cut_at(g, "post_act", "middle"), G("e"), kind="coupling", tie="enforced")
    X = _train_steps(g)
    assert (g(X) - E.delete(g, [Gi])(X)).abs().max().item() < 1e-10
    g = base.clone(False)
    Gl, T, Ti = E.insert_inverse_pair(g, E.cut_at(g, "post_act", "middle"), G("e2"), kind="linear", tie="enforced")
    X = _train_steps(g)
    assert (g(X) - E.delete(g, [Gl])(X)).abs().max().item() < 1e-9
    # tied duplicated branch shares storage with the backbone segment
    g = base.clone(False)
    seg = g.meta["segments"][1]["nodes"]
    Gd, o, c = E.insert_dup_branch(g, seg, G("dup"), tied=True)
    assert {g.nodes[n].pkey for n in g.implants[c].nodes if g.nodes[n].pkey} <= {g.nodes[n].pkey for n in seg}


# ----------------------------------------------------------------------------- T04

def test_T04_linear_chain_folds_to_independent_affine_map():
    g = build_mlp(5, [7, 6, 7], 4, torch_gen(1, "init"), act="identity").double()
    E.insert_linear_factor(g, E.cut_at(g, "post_act", 0), G("f1"), width=9)
    E.insert_residual_zero(g, E.cut_at(g, "post_act", 1), G("f2"), width=3, act="identity")
    with torch.no_grad():
        for p in g.parameters():
            p.add_(0.3 * torch.randn_like(p))
    X = torch.randn(200, 5, dtype=torch.float64)
    y = g(X).detach()
    # independent oracle: least-squares affine fit
    A = np.concatenate([X.numpy(), np.ones((200, 1))], 1)
    sol, *_ = np.linalg.lstsq(A, y.numpy(), rcond=None)
    h = E.fold_affine_chain(g, g.inputs["x"], g.output, share_params=False)
    lin = [n for n in h.nodes.values() if n.op == "linear"]
    assert len(lin) == 1
    W = h.mods[lin[0].pkey].weight.detach().numpy()
    b = h.mods[lin[0].pkey].bias.detach().numpy()
    assert np.abs(W - sol[:-1].T).max() < 1e-8 and np.abs(b - sol[-1]).max() < 1e-8
    assert (h(X) - y).abs().max().item() < 1e-10
    exp, rep = export_compact(h, {"x": X})
    assert rep["max_abs_err"] < 1e-10


# ----------------------------------------------------------------------------- T05

def _set(g, iid, role, W, b):
    m = [g.mods[g.nodes[n].pkey] for n in g.implants[iid].nodes if g.nodes[n].role == role][0]
    with torch.no_grad():
        m.weight.copy_(torch.tensor(W, dtype=torch.float64))
        m.bias.copy_(torch.tensor(b, dtype=torch.float64))


def test_T05_nested_deletions_match_hand_computation():
    g = build_mlp(2, [2], 1, torch_gen(0, "init")).double()
    lin0, head = [n for n in g.nodes.values() if n.op == "linear"]
    W0, b0 = np.array([[1.0, -2.0], [0.5, 1.5]]), np.array([0.1, -0.2])
    Wh, bh = np.array([[2.0, -1.0]]), np.array([0.3])
    with torch.no_grad():
        g.mods[lin0.pkey].weight.copy_(torch.tensor(W0))
        g.mods[lin0.pkey].bias.copy_(torch.tensor(b0))
        g.mods[head.pkey].weight.copy_(torch.tensor(Wh))
        g.mods[head.pkey].bias.copy_(torch.tensor(bh))
    I1 = E.insert_residual_zero(g, E.cut_at(g, "post_act", 0), G("1"), width=2)
    I2 = E.insert_residual_zero(g, E.implant_cut(g, I1, "hidden"), G("2"), width=1)
    I3 = E.insert_residual_zero(g, E.cut_at(g, "post_act", 0), G("3"), width=2)   # chained after I1 at same cut
    A1, c1, B1, d1 = [[1.0, 0.5], [-1.0, 2.0]], [0.0, 0.1], [[0.7, -0.3], [0.2, 0.9]], [0.05, -0.05]
    A2, c2, B2, d2 = [[1.0, -1.0]], [0.2], [[1.5], [-0.5]], [0.0, 0.1]
    A3, c3, B3, d3 = [[0.3, 0.3], [-0.6, 0.1]], [0.0, 0.0], [[1.0, 0.0], [0.4, -0.8]], [0.1, 0.0]
    _set(g, I1, "A", A1, c1); _set(g, I1, "B", B1, d1)
    _set(g, I2, "A", A2, c2); _set(g, I2, "B", B2, d2)
    _set(g, I3, "A", A3, c3); _set(g, I3, "B", B3, d3)
    assert g.implants[I2].parent == I1 and g.implants[I3].parent is None
    assert g.implants[I1].generation == 1 and g.implants[I2].generation == 2 and g.implants[I3].generation == 1
    relu = lambda z: np.maximum(z, 0)
    X = np.random.default_rng(0).normal(size=(11, 2))

    def oracle(x, on1=True, on2=True, on3=True):
        h = relu(x @ W0.T + b0)
        z = h
        if on1:
            s = relu(h @ np.array(A1).T + c1)
            if on2:
                s = s + relu(s @ np.array(A2).T + c2) @ np.array(B2).T + d2
            z = h + s @ np.array(B1).T + d1
        if on3:
            z = z + relu(z @ np.array(A3).T + c3) @ np.array(B3).T + d3
        return z @ Wh.T + bh

    Xt = torch.tensor(X)
    chk = lambda gg, **kw: np.abs(gg(Xt).detach().numpy() - oracle(X, **kw)).max()
    assert chk(g) < 1e-12
    assert chk(E.delete(g, [I1]), on1=False, on2=False) < 1e-12           # parent removes its descendant
    assert chk(E.delete(g, [I2]), on2=False) < 1e-12                       # descendant only
    assert chk(E.delete(g, [I3]), on3=False) < 1e-12                       # sibling in chain
    assert chk(E.delete(g, [I1, I3]), on1=False, on2=False, on3=False) < 1e-12   # generation 1 group
    assert E.canonical_atoms(g, [I1, I2]) == [I1]                          # nested bypass not double counted
    assert E.delete(g, [I1, I2]).instance_hash() == E.delete(g, [I1]).instance_hash()
    # branch deletion inside a sum group with known weights
    h = build_mlp(2, [2], 1, torch_gen(0, "init")).double()
    Gp = E.insert_group(h, E.cut_at(h, "post_act", 0), G("g"))
    b1 = E.add_branch(h, Gp, G("b1"), width=1)
    b2 = E.add_branch(h, Gp, G("b2"), width=1)
    for b, s in ((b1, 1.0), (b2, -2.0)):
        _set(h, b, "A", [[1.0, 1.0]], [0.5])          # positive on non-negative inputs: branch is active
        _set(h, b, "B", [[s], [s]], [0.0, 0.0])
    _, v = h(Xt, return_nodes=[h.implants[b1].exit, h.implants[b2].exit, h.implants[Gp].entry])
    full = h(Xt)
    hd = E.delete(h, [b1])
    _, v2 = hd(Xt, return_nodes=[hd.implants[b2].exit])
    assert torch.allclose(v2[hd.implants[b2].exit], v[h.implants[b2].exit])
    assert (hd(Xt) - full).abs().max() > 0


# ----------------------------------------------------------------------------- T06

class FakeCtx:
    def __init__(self, cfg):
        self.cfg = cfg
        self.metrics_rows = []

    def metric(self, *a, **k):
        self.metrics_rows.append((a, k))

    def save_json(self, *a, **k):
        pass


def test_T06_exhaustive_deletion_finds_cancelling_pair():
    b = vec_bundle()
    g = build_mlp(8, [16, 16], 3, torch_gen(0, "init"))
    Gc, u, v = E.insert_cancel_pair(g, E.cut_at(g, "post_act", 0), G("p"), width=6)
    cfg = resolve({"kind": "trajectory", "data": {"name": "teacher", "n_train": 256}, "deletion": {"family": "exhaustive"},
                   "criteria": {"nmse": [1e-10]}})
    from cop.experiments.deletion import evaluate_family
    res = evaluate_family(FakeCtx(cfg), g, b, "t", dcfg=cfg["deletion"])
    assert res["info"]["exhaustive"] and res["n_distinct_graphs"] == 3     # {u}, {v}, {u,v}=={G}
    assert res["L1_single_deletion_changes_function"][u] and res["L1_single_deletion_changes_function"][v]
    cert = [c for c in res["certificates"] if c["criterion"] == "expanded" and c["partition"] == "val"][0]
    best = set(E.canonical_atoms(g, cert["best_valid_deletion"]["atoms"]))
    assert best in ({Gc}, {u, v})
    valid_singles = [r for r in res["rows"] if r["atoms"] in ([u], [v]) and "metrics" in r and
                     r["metrics"]["val"]["drift_vs_current"]["nmse"] <= 1e-10]
    assert not valid_singles


# ----------------------------------------------------------------------------- T07 / T08

def test_T07_T08_finite_wrappers(tmp_path):
    from cop.finite import run_finite_job, verify_certificate
    s = run_finite_job({"kind": "message", "message": {"n_bits": 3, "k_bits": 2}}, tmp_path / "m")
    assert any(c["is_proof_status"] for c in s["certificates"]) and s["all_checks_ok"]
    s = run_finite_job({"kind": "rank", "rank": {"mode": "exact", "true_rank": 2, "bottleneck": 2}}, tmp_path / "r")
    assert any(c["status"] == "witness_found" for c in s["certificates"])
    s = run_finite_job({"kind": "boolean_class", "boolean_class": {"n_inputs": 3, "target": "parity",
                                                                    "hidden_widths": [2], "max_members": 1000}},
                       tmp_path / "b")
    for c in s["certificates"]:
        assert c["status"] in ("incomplete", "witness_found") and not (c["status"].startswith("certified"))


# ----------------------------------------------------------------------------- T09

def test_T09_stationary_controls():
    b = vec_bundle()
    g = build_mlp(8, [16, 16], 3, torch_gen(0, "init"))
    recs = CTRL.stationary_checks(g, b, "cpu")
    for r in recs:
        assert r["pass"], r
    assert [r for r in recs if r["variant"] == "sgd_plain"][0]["max_param_change"] == 0.0


# ----------------------------------------------------------------------------- T12 (graph level)

def test_T12_late_query_never_reaches_encoder():
    from cop.cop_pegs.pegs import insert_peg, query_isolation, bypass_report
    b = load_bundle({"name": "delayed_query", "n_train": 256, "n_val": 128, "n_test": 128, "params": {"n_bits": 8}})
    g = build_mlp(8, [16, 16, 16], 2, torch_gen(0, "init"), query={"dim": 8, "at_layer": 1})
    assert g.consumers(g.inputs["q"])[0][0] == g.meta["query_injection"]
    cut = E.cut_at(g, "post_act", 1)
    assert g.nodes[cut.consumers[0][0]].role == "query_inject"
    pid = insert_peg(g, cut, G("peg"), 4)
    assert not query_isolation(g)["query_reaches_encoder"]
    X = {k: v[:32] for k, v in b.train.X.items()}
    X2 = dict(X, q=X["q"][torch.randperm(32)])
    enc = g.implants[pid].meta["peg"]["enc"]
    _, a = g(X, return_nodes=[enc])
    _, a2 = g(X2, return_nodes=[enc])
    assert torch.equal(a[enc], a2[enc])
    g.gate_vals[g.implants[pid].meta["peg"]["alpha"]] = 0.0
    assert bypass_report(g)[pid]["has_bypass"] is False
    g.gate_vals[g.implants[pid].meta["peg"]["alpha"]] = 0.5
    assert bypass_report(g)[pid]["has_bypass"] is True


# ----------------------------------------------------------------------------- T13

def test_T13_freeze_policies_cover_parameters_and_bn_statistics():
    b = load_bundle({"name": "toy_images", "n_train": 128})
    for policy in ("original_frozen", "implants_frozen"):
        g = build_cnn(3, (16, 16), 4, torch_gen(0, "init"), 0.25)
        iid = E.insert_residual_zero(g, E.cut_at(g, "post_act", "middle"), G("i"), width=4)
        before = {k: v.clone() for k, v in g.state_dict().items()}
        tr = Trainer(g, b, tc(batch_size=32), {"minibatch": 0, "augmentation": 0}, "cpu")
        tr.configure(policy, iid)
        tr.run(Segment("s", 5))
        imp_pk = {g.nodes[n].pkey for n in g.implants[iid].nodes if g.nodes[n].pkey}
        for k, v in g.state_dict().items():
            pk = k.split(".")[1]
            changed = not torch.equal(v, before[k])
            frozen = (pk not in imp_pk) if policy == "original_frozen" else (pk in imp_pk)
            if frozen:
                assert not changed, f"{policy}: frozen {k} changed"
        if policy == "implants_frozen":
            assert any(not torch.equal(v, before[k]) for k, v in g.state_dict().items() if "running_mean" in k)


# ----------------------------------------------------------------------------- T14

def test_T14_repair_objectives_use_selected_target():
    b = vec_bundle()
    f0 = build_mlp(8, [16], 3, torch_gen(0, "init"))
    ft = build_mlp(8, [16], 3, torch_gen(1, "init"))
    for target, teacher in (("task", None), ("expanded", ft), ("original", f0)):
        model = ft.clone(share_params=False)
        tr = Trainer(model, b, tc(batch_size=64, lr=0.0), {"minibatch": 5, "augmentation": 5}, "cpu")
        tr.configure("none", None)
        gen = torch.Generator()
        gen.set_state(tr.gens["minibatch"].get_state())
        idx = torch.randperm(len(b.train), generator=gen)[:64]
        X, y = b.train.X["x"][idx], b.train.y[idx]
        with torch.no_grad():
            out = model({"x": X})
            want = task_loss(out, y, b.task) if target == "task" else distill_loss(out, teacher({"x": X}), b.task)
        got = tr.run(Segment("r", 1, target=target, teacher=teacher))["final_train_loss_avg"]
        assert abs(got - want.item()) < 1e-6, target
        if target == "expanded":
            assert got < 1e-12


# ----------------------------------------------------------------------------- T15

def test_T15_scheduled_removal_reaches_endpoint_and_export_removes():
    b = vec_bundle()
    g = build_mlp(8, [16, 16], 3, torch_gen(0, "init"))
    i1 = E.insert_residual_zero(g, E.cut_at(g, "post_act", 0), G("1"), width=4)
    i2 = E.insert_residual_zero(g, E.implant_cut(g, i1, "hidden"), G("2"), width=3)
    with torch.no_grad():
        for p in g.parameters():
            p.add_(0.1 * torch.randn_like(p))
    gid = E.add_gate(g, i1)
    tr = Trainer(g, b, tc(batch_size=32), {"minibatch": 0, "augmentation": 0}, "cpu")
    tr.configure("none", None)
    S = 10

    def sched(trn, step):
        trn.model.gate_vals[gid] = max(0.0, 1 - (step + 1) / S)
    tr.run(Segment("anneal", S, on_step=sched))
    assert g.gate_vals[gid] == 0.0
    X = {"x": b.val.X["x"][:64]}
    exp, rep = export_compact(g, X)
    gone = {i1, i2}
    assert not any(n.owner in gone for n in exp.nodes.values())
    assert rep["max_abs_err"] < 1e-6
    # effective accounting of the gated-off model already equals the physical export
    assert count_params(exp)["total"] == count_params(g)["total"]
    assert exp.n_params() < g.n_params()


# ----------------------------------------------------------------------------- T16

def test_T16_accounting_includes_everything():
    from cop.cop_pegs.pegs import insert_peg
    g = build_mlp(8, [16, 16], 3, torch_gen(0, "init"))
    p0, m0 = count_params(g)["total"], count_macs(g)["macs"]
    E.insert_residual_zero(g, E.cut_at(g, "post_act", 0), G("r"), width=5)
    assert count_params(g)["total"] - p0 == 16 * 5 + 5 + 5 * 16 + 16
    assert count_macs(g)["macs"] - m0 == 2 * 16 * 5
    # shared (tied) branch: parameters once, compute twice
    h = build_mlp(8, [16, 16], 3, torch_gen(0, "init"))
    Gp = E.insert_group(h, E.cut_at(h, "post_act", 0), G("g"))
    b1 = E.add_branch(h, Gp, G("b1"), width=4)
    p1, m1 = count_params(h)["total"], count_macs(h)["macs"]
    E.add_branch(h, Gp, G("b2"), width=4, tie_to=b1)
    assert count_params(h)["total"] == p1 and count_macs(h)["macs"] - m1 == 2 * 16 * 4
    # router parameters
    r = build_mlp(8, [16, 16], 3, torch_gen(0, "init"))
    p0 = count_params(r)["total"]
    Gr = E.insert_group(r, E.cut_at(r, "post_act", 0), G("rt"), merge="route")
    E.add_branch(r, Gr, G("rb1"), width=4)
    E.add_branch(r, Gr, G("rb2"), width=4)
    assert count_params(r)["total"] - p0 == 2 * (16 * 4 + 4 + 4 * 16 + 16) + (16 * 2 + 2)
    # CNN peg: positions x channels x bits; codebook parameters counted
    c = build_cnn(3, (16, 16), 4, torch_gen(0, "init"), 0.25)
    cut = E.cut_at(c, "post_act", 0)
    hw = c.nodes[cut.source].attrs["hw"]
    pc0 = count_params(c)["total"]
    pid = insert_peg(c, cut, G("p"), 3, mode="uniform", bits=4)
    assert peg_messages(c) == []          # alpha=1: the bypass carries everything, the peg transmits nothing
    c.gate_vals[c.implants[pid].meta["peg"]["alpha"]] = 0.0
    m = peg_messages(c)[0]
    assert m["bits_per_example"] == hw[0] * hw[1] * 3 * 4
    v = build_cnn(3, (16, 16), 4, torch_gen(0, "init"), 0.25)
    pv = insert_peg(v, E.cut_at(v, "post_act", 0), G("v"), 4, mode="vq", codebook_size=16)
    v.gate_vals[v.implants[pv].meta["peg"]["alpha"]] = 0.0
    assert peg_messages(v)[0]["bits_per_example"] == hw[0] * hw[1] * 4      # log2(16) bits per position
    q = [n for n in v.nodes.values() if n.op == "quant"][0]
    assert v.mods[q.pkey].codebook.numel() == 16 * 4
    assert count_params(v)["by_role"].get("peg_quant", 0) == 16 * 4
    # sequence: compute scales with tokens; one real coordinate is never one bit
    t = build_transformer(12, 16, 2, 2, 12, torch_gen(0, "init"))
    assert count_macs(t, T=10)["macs"] > count_macs(t, T=5)["macs"]
    pt = insert_peg(t, E.cut_at(t, "resid", 0), G("tp"), 4)
    t.gate_vals[t.implants[pt].meta["peg"]["alpha"]] = 0.0
    assert peg_messages(t, T=9)[0]["bits_per_example"] == 9 * 4 * 32


# ----------------------------------------------------------------------------- T17

def test_T17_heldout_assemblies_absent_from_training(results_dir):
    from cop.orchestration.runner import run_job
    cfg = resolve({"kind": "cop", "data": {"name": "compose", "n_train": 512, "n_val": 256, "n_test": 256},
                   "model": {"family": "mlp", "depth": 6, "width": 16},
                   "train": {"baseline_updates": 40, "batch_size": 64},
                   "cop": {"task_kind": "alternatives", "n_pearls": 4, "alt_training": "joint", "code_kind": "learned",
                           "alt_kinds": ["mlp_small", "linear"], "local_updates": 10, "global_updates": 30,
                           "heldout_assemblies": 0.3},
                   "peg": {"dim": 3, "anneal_updates": 10}})
    assert run_job(cfg, results_dir, {"device": "cpu"}) == "complete"
    d = results_dir / "runs" / run_id(cfg)
    asm = json.load(open(d / "assemblies.json"))
    res = json.load(open(d / "alternatives_result.json"))
    train = {tuple(a) for a in asm["train"]}
    held = {tuple(a) for a in asm["heldout"]}
    assert held and not (train & held)
    assert {tuple(a) for a in res["audit"]["training_assemblies_used"]} <= train
    assert asm["heldout_inputs"].startswith("test partition")


# ----------------------------------------------------------------------------- T18

def test_T18_metrics_match_independent_calculations():
    rng = np.random.default_rng(0)
    a, b = rng.normal(size=(50, 4)), rng.normal(size=(50, 4))
    d = M.drift(torch.tensor(a), torch.tensor(b), "classification")
    pa = np.exp(a) / np.exp(a).sum(1, keepdims=True)
    pb = np.exp(b) / np.exp(b).sum(1, keepdims=True)
    kl = (pa * (np.log(pa) - np.log(pb))).sum(1).mean()
    mm = (pa + pb) / 2
    js = 0.5 * ((pa * np.log(pa / mm)).sum(1) + (pb * np.log(pb / mm)).sum(1)).mean()
    assert abs(d["kl"] - kl) < 1e-10 and abs(d["js"] - js) < 1e-10
    assert abs(d["disagreement"] - (a.argmax(1) != b.argmax(1)).mean()) < 1e-12
    y = rng.integers(0, 4, 50)
    m = M.task_metrics(torch.tensor(a), torch.tensor(y), "classification")
    assert abs(m["acc"] - (a.argmax(1) == y).mean()) < 1e-12
    lse = np.log(np.exp(a).sum(1))
    assert abs(m["loss"] - (lse - a[np.arange(50), y]).mean()) < 1e-6
    # deletion sign and interaction convention on a cancelling pair
    bnd = vec_bundle()
    g = build_mlp(8, [16, 16], 3, torch_gen(0, "init"))
    Gc, u, v = E.insert_cancel_pair(g, E.cut_at(g, "post_act", 0), G("j"), width=6)
    cfg = resolve({"kind": "trajectory", "data": {"name": "teacher", "n_train": 256}})
    from cop.experiments.deletion import evaluate_family
    from cop.train.trainer import evaluate
    res = evaluate_family(FakeCtx(cfg), g, bnd, "t", dcfg=cfg["deletion"])
    R = lambda gg: M.headline(evaluate(gg, bnd, ["val"])[0]["val"], bnd.task)
    rf, ru, rv, ruv = R(g), R(E.delete(g, [u])), R(E.delete(g, [v])), R(E.delete(g, [u, v]))
    J = [x for x in res["interactions"] if {x["A"], x["B"]} == {u, v} and x["partition"] == "val"][0]["J"]
    assert abs(J - (ruv - ru - rv + rf)) < 1e-6
    assert abs(ruv - rf) < 1e-6 and abs(ru - rf) > 1e-4 and abs(rv - rf) > 1e-4   # singles change risk; pair cancels


# ----------------------------------------------------------------------------- T19

def _traj_cfg(**g):
    return resolve({"kind": "trajectory", "data": {"name": "teacher", "n_train": 256, "n_val": 128, "n_test": 128,
                                                    "params": {"teacher_depth": 1}},
                    "model": {"family": "mlp", "depth": 3, "width": 16},
                    "train": {"baseline_updates": 30, "batch_size": 32, "checkpoint_every": 7},
                    "growth": {"topology": "recursive_branch", "rounds": 3, "updates_per_round": 20, **g}})


def test_T19_interrupted_resume_equals_uninterrupted(tmp_path, monkeypatch):
    from cop.orchestration.runner import run_job
    import cop.train.trainer as T
    cfg = _traj_cfg()
    ra, rb = tmp_path / "a", tmp_path / "b"
    assert run_job(cfg, ra, {"device": "cpu"}) == "complete"
    calls = {"n": 0}

    def fake():
        calls["n"] += 1
        return calls["n"] == 47        # interrupt once, mid-round
    monkeypatch.setattr(T, "interrupted", fake)
    assert run_job(cfg, rb, {"device": "cpu"}) == "pending"
    monkeypatch.setattr(T, "interrupted", lambda: False)
    assert run_job(cfg, rb, {"device": "cpu"}) == "complete"
    rid = run_id(cfg)
    A = torch.load(ra / "runs" / rid / "ckpt" / "final.pt", weights_only=False)
    B = torch.load(rb / "runs" / rid / "ckpt" / "final.pt", weights_only=False)
    for k in A["model"]["state"]:
        assert torch.equal(A["model"]["state"][k], B["model"]["state"][k]), k
    assert A["trainer"]["state"]["global_step"] == B["trainer"]["state"]["global_step"]
    rows = lambda r: [json.loads(l) for l in open(r / "runs" / rid / "metrics.jsonl")]
    key = lambda x: (x["stage"], x["evaluation_partition"], x["metric_name"], json.dumps(x.get("atoms")))
    ka = sorted(key(x) for x in rows(ra) if x["stage"].startswith("round_"))
    kb = sorted(key(x) for x in rows(rb) if x["stage"].startswith("round_"))
    assert ka == kb, "no duplicated or missing round metrics after resume"


# ----------------------------------------------------------------------------- T20

def test_T20_paired_runs_share_batches_and_insertions_do_not_shift_streams():
    b = vec_bundle()
    f0 = build_mlp(8, [16, 16], 3, torch_gen(0, "init"))
    tr0 = Trainer(f0, b, tc(batch_size=32), {"minibatch": 1, "augmentation": 1}, "cpu")
    tr0.configure("none", None)
    tr0.run(Segment("baseline", 13))
    st = copy.deepcopy(tr0.state_dict())
    seqs = []
    for topo in ("layered", "parallel"):
        g = GraphNet.from_checkpoint(f0.checkpoint())
        tr = Trainer(g, b, tc(batch_size=32), {"minibatch": 99, "augmentation": 99}, "cpu")
        tr.load_state_dict(copy.deepcopy(st))
        before = tr.gens["minibatch"].get_state().clone()
        if topo == "layered":
            E.insert_residual_zero(g, E.cut_at(g, "post_act", 0), torch_gen(0, "insertion", "x"), width=4)
        else:
            Gp = E.insert_group(g, E.cut_at(g, "post_act", 0), torch_gen(0, "insertion", "y"))
            E.add_branch(g, Gp, torch_gen(0, "insertion", "z"), width=7)
        assert torch.equal(before, tr.gens["minibatch"].get_state())
        idx = []
        for _ in range(12):
            p = tr.next_batch()
            idx.append(p.X["x"][:, 0].clone())
        seqs.append(torch.stack(idx))
    assert torch.equal(seqs[0], seqs[1])


# ----------------------------------------------------------------------------- T21

def test_T21_selection_uses_validation_or_training_only(monkeypatch):
    import cop.experiments.repair as R
    b = vec_bundle()
    g = build_mlp(8, [16, 16], 3, torch_gen(0, "init"))
    Gc, u, v = E.insert_cancel_pair(g, E.cut_at(g, "post_act", 0), G("s"), width=6)
    seen = []
    orig = R.evaluate

    def spy(model, bundle, parts, *a, **k):
        seen.extend(parts)
        return orig(model, bundle, parts, *a, **k)
    monkeypatch.setattr(R, "evaluate", spy)
    R.select_deletion(g, b, "max_single", 512)
    assert set(seen) == {"val"}
    # training-only calibration subset for data-driven choices
    from cop.experiments.common import calib_partition
    p = calib_partition(b, 64)
    assert torch.equal(p.X["x"], b.train.X["x"][:64])


# ----------------------------------------------------------------------------- T22

def test_T22_cpu_gpu_equivalence_if_available():
    if not torch.cuda.is_available():
        pytest.skip("no CUDA here; the Wave-0 control job records cpu_vs_gpu_fp32 on the GPU machine")
    # v37: true fp32 on both devices (PyTorch allows TF32 convolutions on Ampere by default; the jobs turn it off
    # through utils' device setup, this test did not) and a fixed input (it was an unseeded randn)
    g, _ = family_model("resnet")
    g = g.eval()
    X = {"x": torch.randn(5, 3, 8, 8, generator=torch.Generator().manual_seed(0))}
    old = (torch.backends.cuda.matmul.allow_tf32, torch.backends.cudnn.allow_tf32)
    torch.backends.cuda.matmul.allow_tf32 = torch.backends.cudnn.allow_tf32 = False
    try:
        with torch.no_grad():
            yc = g(X)
            yg = g.to("cuda")({k: v.cuda() for k, v in X.items()}).cpu()
    finally:
        torch.backends.cuda.matmul.allow_tf32, torch.backends.cudnn.allow_tf32 = old
    assert (yc - yg).abs().max().item() < 1e-3


# ----------------------------------------------------------------------------- T23

def test_T23_manifest_coverage_reconciles(tmp_path):
    from cop.orchestration.manifest import generate
    from cop.analysis.summarize import summarize
    from cop.utils import atomic_write_json, semantic_code_hash
    sem = semantic_code_hash()
    B = generate([0], "smoke")
    ents = B.entries_list()
    mpath = tmp_path / "m.jsonl"
    with open(mpath, "w") as f:
        for e in ents:
            f.write(json.dumps(e) + "\n")
    res = tmp_path / "res"
    want = {}
    for i, e in enumerate(ents):
        st = ["complete", "failed", "unsupported", None][i % 4]
        if st is None:
            want["pending"] = want.get("pending", 0) + 1
            continue
        d = res / "runs" / e["run_id"]
        d.mkdir(parents=True)
        atomic_write_json(d / "config.json", e["cfg"])
        atomic_write_json(d / "status.json", {"status": st, "reason": "test"})
        if st in ("complete", "unsupported"):     # v2: finished runs carry the code that produced them
            atomic_write_json(d / "provenance.json", {"semantic_hash": sem})
        want[st] = want.get(st, 0) + 1
    out = summarize(str(res), [str(mpath)], str(tmp_path / "summ"))
    cov = json.load(open(tmp_path / "summ" / "coverage.json"))
    assert cov["totals"] == want
    assert len(cov["missing_or_incomplete"]) == len(ents) - want.get("complete", 0)
    # a finished run without a provenance record is stale, not complete
    first = next(e for i, e in enumerate(ents) if i % 4 == 0)
    (res / "runs" / first["run_id"] / "provenance.json").unlink()
    summarize(str(res), [str(mpath)], str(tmp_path / "summ2"))
    cov2 = json.load(open(tmp_path / "summ2" / "coverage.json"))
    assert cov2["totals"].get("stale") == 1 and cov2["totals"]["complete"] == want["complete"] - 1


# ----------------------------------------------------------------------------- T24

def test_T24_cli_smoke_from_fresh_process(tmp_path):
    env = {**__import__("os").environ, "PYTHONPATH": str(ROOT)}
    m = tmp_path / "w0.jsonl"
    r = subprocess.run([sys.executable, "-m", "cop.cli", "generate-manifest", "--wave", "0", "--scale", "smoke",
                        "--out", str(m)], cwd=ROOT, env=env, capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    r = subprocess.run([sys.executable, "-m", "cop.cli", "validate-manifest", "--manifest", str(m)], cwd=ROOT, env=env,
                       capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr
    r = subprocess.run([sys.executable, "-m", "cop.cli", "run", "--manifest", str(m), "--results", str(tmp_path / "res"),
                        "--kinds", "finite", "--device", "cpu"], cwd=ROOT, env=env, capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    r = subprocess.run([sys.executable, "-m", "cop.cli", "status", "--manifest", str(m), "--results",
                        str(tmp_path / "res")], cwd=ROOT, env=env, capture_output=True, text=True)
    assert "complete" in r.stdout
