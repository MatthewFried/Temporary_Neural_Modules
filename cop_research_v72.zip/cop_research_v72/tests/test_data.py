"""Data-family tests: shapes, T10 (disjoint/nested/train-only preprocessing),
T11 (train-only noise), T12 data level (delayed query), stream independence."""
import os
from pathlib import Path

import numpy as np
import pytest
import torch

from cop.data import DATASETS, load_bundle, resolve_data_cfg
from cop.data.augment import augment_batch
from cop.data.images import image_bundle_from_arrays
from cop.data.splits import codes_to_bits, finite_domain_split, row_codes
from cop.data.synthetic import teacher_forward
from cop.data.tabular import tabular_from_arrays

SYNTH = ["linear_rank", "teacher", "frequency", "compose", "flat", "easy_teacher", "parity", "multiplexer",
         "delayed_query", "shortcut", "digits", "seq_copy", "seq_select", "seq_compose"]


def L(name, **kw):
    cfg = {"name": name, "n_train": kw.pop("n_train", 256)}
    cfg.update(kw)
    return load_bundle(cfg)


def bits_code(x):
    b = (x > 0).long()
    return (b * (2 ** torch.arange(b.shape[1]))).sum(1)


# ---------------------------------------------------------------- shapes/dtypes
@pytest.mark.parametrize("name", SYNTH)
def test_shapes_and_dtypes(name):
    b = L(name)
    assert b.family == DATASETS[name][0]
    assert len(b.train) == 256
    for part in b.partitions().values():
        for k, spec in b.input_spec.items():
            assert k in part.X
            if b.layout != "seq":
                assert list(part.X[k].shape[1:]) == spec["shape"]
            assert part.X[k].dtype == (torch.long if spec["dtype"] == "long" else torch.float32)
        if b.task == "regression":
            assert part.y.dtype == torch.float32 and part.y.shape[1] == b.out_dim
        else:
            assert part.y.dtype == torch.long
            valid = part.y[part.y != -100]
            assert valid.min() >= 0 and valid.max() < b.out_dim
    assert b.train.y_clean is not None
    assert b.train_indices is not None and len(b.train_indices) == 256


def test_unknown_keys_fail_loudly():
    with pytest.raises(ValueError):
        resolve_data_cfg({"name": "teacher", "bogus": 1})
    with pytest.raises(ValueError):
        load_bundle({"name": "teacher", "params": {"bogus": 1}})
    with pytest.raises(ValueError):
        load_bundle({"name": "nope"})
    with pytest.raises(ValueError):
        load_bundle({"name": "teacher", "augment": "crop_flip"})
    with pytest.raises(ValueError):
        load_bundle({"name": "multiplexer", "n_train": 100000})


# ---------------------------------------------------------------- T10
@pytest.mark.parametrize("name,params", [("parity", {}), ("multiplexer", {}), ("delayed_query", {}),
                                         ("delayed_query", {"split_mode": "x_holdout"}),
                                         ("parity", {"k": 12, "n_irrelevant": 12})])
def test_T10_finite_partitions_disjoint(name, params):
    b = load_bundle({"name": name, "n_train": "full", "params": params})

    def codes(p):
        c = bits_code(p.X["x"])
        if "q" in p.X:
            n = p.X["q"].shape[1]
            if params.get("split_mode") == "x_holdout":
                return c
            c = c * n + p.X["q"].argmax(1)
        return c

    tr, va, te = codes(b.train), codes(b.val), codes(b.test)
    assert not torch.isin(tr, va).any() and not torch.isin(tr, te).any() and not torch.isin(va, te).any()
    if params.get("split_mode") != "x_holdout":
        assert len(torch.unique(tr)) == len(tr)   # drawn without replacement
    if "complete_domain" in b.extra:
        assert b.extra["complete_domain"].meta["complete_domain"] is True


@pytest.mark.parametrize("name", ["seq_copy", "seq_select", "seq_compose"])
def test_T10_sequence_disjoint(name):
    params = {"vocab": 4, "length": 5, "pool_size": 4096} if name != "seq_compose" else \
        {"vocab": 3, "n_ops": 2, "length": 6, "pool_size": 4096}
    b = load_bundle({"name": name, "n_train": 1024, "n_val": 128, "n_test": 128, "params": params})
    V = b.out_dim
    tr = row_codes(b.train.X["x"], V)
    held = torch.cat([row_codes(b.val.X["x"], V), row_codes(b.test.X["x"], V)])
    assert not torch.isin(tr, held).any()
    assert b.meta["pool_rows_removed_overlapping_val_test"] > 0   # small domain -> dedup was needed


@pytest.mark.parametrize("name", ["teacher", "shortcut", "parity", "seq_select", "digits", "compose"])
def test_T10_nested_subsets_and_fixed_eval(name):
    small, big = L(name, n_train=128), L(name, n_train=512)
    assert torch.equal(small.train_indices, big.train_indices[:128])
    if name != "digits":   # digits features are standardised with train-subset stats (tested below)
        for k in small.train.X:
            assert torch.equal(small.train.X[k], big.train.X[k][:128])
        assert small.val.hash() == big.val.hash() and small.test.hash() == big.test.hash()
    else:
        assert small.meta["split_index_hashes"] == big.meta["split_index_hashes"]
    assert torch.equal(small.train.y_clean, big.train.y_clean[:128])


def test_T10_balanced_subsets():
    b = L("digits", n_train=500)
    counts = torch.bincount(b.train.y, minlength=10)
    assert counts.max() - counts.min() <= 1


def _fake_tab(n=400, d=5, seed=0):
    r = np.random.default_rng(seed)
    X = r.normal(size=(n, d)) * np.arange(1, d + 1) + 3
    y = r.integers(0, 3, size=n)
    return X, y


def test_T10_tabular_preprocessing_train_only():
    X, y = _fake_tab()
    cfg = {"name": "fake", "n_train": 100, "data_seed": 0, "label_noise": 0.0, "target_noise": 0.0}
    b = tabular_from_arrays(cfg, "fake", X, y, "classification", 50, 80, 0, None, {})
    from cop.data.splits import stratified_split
    parts = stratified_split(y, {"val": 50, "test": 80, "pool": None}, 0, "fake")
    pool_raw = torch.from_numpy(X.astype(np.float32))[torch.from_numpy(parts["pool"])]
    raw_train = pool_raw[b.train_indices]
    np.testing.assert_allclose(b.preprocess["mean"], raw_train.double().mean(0).numpy(), rtol=1e-5, atol=1e-5)
    np.testing.assert_allclose(b.preprocess["std"], raw_train.double().std(0, unbiased=False).numpy(), rtol=1e-5)
    assert b.preprocess["fitted_on"] == "train_subset"
    # perturbing the TEST rows does not change stats; changing n_train does
    X2 = X.copy()
    X2[parts["test"]] += 100.0
    b2 = tabular_from_arrays(cfg, "fake", X2, y, "classification", 50, 80, 0, None, {})
    assert b2.preprocess["mean"] == b.preprocess["mean"]
    b3 = tabular_from_arrays(dict(cfg, n_train=200), "fake", X, y, "classification", 50, 80, 0, None, {})
    assert b3.preprocess["mean"] != b.preprocess["mean"]
    # disjoint index sets
    s = [set(parts[k].tolist()) for k in ("val", "test", "pool")]
    assert not (s[0] & s[1]) and not (s[0] & s[2]) and not (s[1] & s[2])


def test_T10_image_preprocessing_train_only():
    r = np.random.default_rng(0)
    trx = r.integers(0, 256, size=(300, 8, 8, 3), dtype=np.uint8)
    tr_y = np.repeat(np.arange(10), 30)
    tex = r.integers(0, 256, size=(50, 8, 8, 3), dtype=np.uint8)
    te_y = r.integers(0, 10, size=50)
    cfg = {"name": "fake_img", "n_train": 100, "data_seed": 0, "label_noise": 0.0, "target_noise": 0.0}
    b = image_bundle_from_arrays(cfg, "fake_img", trx, tr_y, tex, te_y, "crop_flip", 10, 40, 0, {})
    assert b.train.X["x"].shape == (100, 3, 8, 8) and b.test.X["x"].shape == (50, 3, 8, 8)
    from cop.data.splits import stratified_split
    parts = stratified_split(tr_y, {"val": 40, "pool": None}, 0, "fake_img")
    raw = torch.from_numpy(trx).permute(0, 3, 1, 2)[torch.from_numpy(parts["pool"])][b.train_indices]
    mean = (raw.double() / 255).mean(dim=(0, 2, 3))
    np.testing.assert_allclose(b.preprocess["mean"], mean.numpy(), rtol=1e-5)
    tex2 = tex.copy()
    tex2[:] = 0
    b2 = image_bundle_from_arrays(cfg, "fake_img", trx, tr_y, tex2, te_y, "crop_flip", 10, 40, 0, {})
    assert b2.preprocess["mean"] == b.preprocess["mean"]
    assert torch.bincount(b.train.y, minlength=10).tolist() == [10] * 10
    assert len(set(parts["val"].tolist()) & set(parts["pool"].tolist())) == 0


# ---------------------------------------------------------------- T11
def test_T11_label_noise_train_only():
    clean = L("shortcut", n_train=4096)
    noisy = L("shortcut", n_train=4096, label_noise=0.3)
    assert torch.equal(noisy.train.y_clean, clean.train.y)
    frac = (noisy.train.y != noisy.train.y_clean).float().mean().item()
    assert 0.25 < frac < 0.35
    for k in ("val", "test", "shift", "rare"):
        a, c = clean.partitions()[k], noisy.partitions()[k]
        assert torch.equal(a.y, c.y) and a.y_clean is None and c.y_clean is None
    # corruption is consistent across nested sizes
    small = L("shortcut", n_train=1024, label_noise=0.3)
    assert torch.equal(small.train.y, noisy.train.y[:1024])


def test_T11_target_noise_train_only():
    clean = L("teacher", n_train=2048)
    noisy = L("teacher", n_train=2048, target_noise=0.5)
    assert torch.equal(noisy.train.y_clean, clean.train.y)
    d = (noisy.train.y - noisy.train.y_clean).std().item()
    assert 0.45 < d < 0.55
    assert torch.equal(noisy.val.y, clean.val.y) and torch.equal(noisy.test.y, clean.test.y)


def test_T11_sequence_noise_only_target_positions():
    clean = L("seq_select", n_train=2048)
    noisy = L("seq_select", n_train=2048, label_noise=0.3)
    assert torch.equal((noisy.train.y == -100), (clean.train.y == -100))
    changed = noisy.train.y != noisy.train.y_clean
    assert changed.any()
    assert (noisy.train.y[changed] < noisy.meta["n_symbols"]).all()
    assert torch.equal(noisy.test.y, clean.test.y)


def test_noise_kind_mismatch_fails():
    with pytest.raises(ValueError):
        L("teacher", label_noise=0.1)
    with pytest.raises(ValueError):
        L("shortcut", target_noise=0.1)


# ---------------------------------------------------------------- T12 (data level)
@pytest.mark.parametrize("mode", ["pairs", "x_holdout"])
def test_T12_delayed_query_x_carries_no_query(mode):
    b = load_bundle({"name": "delayed_query", "n_train": 1024, "params": {"n_bits": 8, "split_mode": mode}})
    n = 8
    for p in b.partitions().values():
        x, q = p.X["x"], p.X["q"]
        assert set(torch.unique(x).tolist()) <= {-1.0, 1.0}
        assert torch.equal(q.sum(1), torch.ones(len(p)))
        qi = q.argmax(1)
        assert torch.equal(p.y, (x.gather(1, qi.unsqueeze(1)).squeeze(1) > 0).long())
    # x is a function of the x-code alone: rows sharing an x-code have identical x for different q
    cd = b.extra["complete_domain"]
    xc = bits_code(cd.X["x"])
    assert torch.equal(cd.X["x"], (2 * codes_to_bits(xc, n) - 1).float())
    sel = xc == xc[0]
    assert len(torch.unique(cd.X["q"][sel].argmax(1))) == n
    assert (cd.X["x"][sel] == cd.X["x"][0]).all()


# ---------------------------------------------------------------- stream independence
@pytest.mark.parametrize("name", ["teacher", "frequency", "compose", "parity", "shortcut", "linear_rank"])
def test_stream_independence(name):
    a = L(name)
    t = L(name, teacher_seed=1)
    d = L(name, data_seed=1)
    # Inputs of the fixed evaluation partitions never depend on teacher_seed.  (For
    # classification the class-balanced training-subset order depends on labels,
    # and the D05 shortcut feature is label-dependent by design, so we compare the
    # label-independent columns of the test inputs.)
    cols = slice(0, a.meta["feature_layout"]["shortcut"]) if name == "shortcut" else slice(None)
    for k in a.test.X:
        assert torch.equal(a.test.X[k][:, cols], t.test.X[k][:, cols])   # teacher seed does not move inputs
        assert not torch.equal(a.test.X[k], d.test.X[k])                # data seed does
    if a.task == "regression":
        assert torch.equal(a.train.X["x"], t.train.X["x"])
    assert not torch.equal(a.test.y, t.test.y)                  # target function changed
    if name == "teacher":
        for w1, w2 in zip(a.meta["teacher"]["weights"], d.meta["teacher"]["weights"]):
            assert torch.equal(w1, w2)                           # data seed does not move teacher


def test_teacher_forward_reproduces_targets():
    b = L("teacher")
    np.testing.assert_allclose(teacher_forward(b.meta["teacher"], b.test.X["x"]).numpy(), b.test.y.numpy(),
                               atol=1e-5)
    g = torch.Generator().manual_seed(0)
    f = b.fresh_sampler(64, g)
    np.testing.assert_allclose(teacher_forward(b.meta["teacher"], f.X["x"]).numpy(), f.y.numpy(), atol=1e-5)


def test_linear_rank_exact():
    b = L("linear_rank")
    M = torch.tensor(b.meta["M_effective"], dtype=torch.float64)
    np.testing.assert_allclose((b.test.X["x"].double() @ M.T).numpy(), b.test.y.numpy(), atol=1e-5)
    assert torch.linalg.matrix_rank(M).item() == b.meta["rank"]


def test_compose_intermediates():
    b = L("compose")
    assert b.train.aux["z"].shape == (256, 4) and b.train.aux["u"].shape == (256, 2)


# ---------------------------------------------------------------- D05 / D08 specifics
def test_shortcut_partitions():
    b = L("shortcut", n_train=4096)
    assert (b.extra["rare"].groups == 1).all() and len(b.extra["rare"]) == 5000
    sidx = b.meta["feature_layout"]["shortcut"]

    def corr(p):
        s = p.X["x"][:, sidx]
        yy = p.y.float() * 2 - 1
        return float(((s - s.mean()) * yy).mean())
    assert corr(b.train) > 0.5 and corr(b.extra["shift"]) < -0.5 and abs(corr(b.test)) < 0.1
    assert 0 < (b.test.groups == 1).float().mean() < 0.1


@pytest.mark.parametrize("name", ["seq_copy", "seq_select", "seq_compose"])
def test_extrap_longer(name):
    b = L(name)
    PAD = b.meta["specials"]["PAD"]
    tr_len = (b.train.X["x"] != PAD).sum(1).max()
    ex_len = (b.extra["extrap"].X["x"] != PAD).sum(1).min()
    assert ex_len > tr_len
    assert b.extra["extrap"].X["x"].shape[1] > b.train.X["x"].shape[1]


def test_seq_select_query_only_at_end():
    b = L("seq_select")
    V = b.meta["n_symbols"]
    x, y = b.train.X["x"], b.train.y
    is_q = x >= V + 3
    assert torch.equal(is_q.sum(1), torch.ones(len(x), dtype=torch.long))
    qpos = is_q.long().argmax(1)
    assert torch.equal((y != -100).long().argmax(1), qpos)
    p = x[torch.arange(len(x)), qpos] - (V + 3)
    assert torch.equal(y[torch.arange(len(x)), qpos], x.gather(1, p.unsqueeze(1)).squeeze(1))


def test_seq_compose_targets():
    b = L("seq_compose")
    perms = torch.tensor(b.meta["perms"])
    V = b.meta["n_symbols"]
    x, y = b.test.X["x"], b.test.y
    for i in range(20):
        s = int(x[i, 0])
        j = 1
        while j < x.shape[1] and x[i, j] >= V + 3:
            s = int(perms[x[i, j] - V - 3, s])
            j += 1
        assert int(y[i, j - 1]) == s


# ---------------------------------------------------------------- augmentation
def _ref_augment(x, oy, ox, flip, pv, pad=4):
    B, C, H, W = x.shape
    out = torch.empty_like(x)
    for b in range(B):
        P = pv.view(C, 1, 1).expand(C, H + 2 * pad, W + 2 * pad).clone()
        P[:, pad:pad + H, pad:pad + W] = x[b]
        o = P[:, oy[b]:oy[b] + H, ox[b]:ox[b] + W]
        out[b] = o.flip(2) if flip[b] else o
    return out


def test_augment_matches_reference_and_is_reproducible():
    x = torch.randn(16, 3, 8, 8)
    pv = torch.tensor([-1.0, -2.0, -3.0])
    g = torch.Generator().manual_seed(5)
    state = g.get_state()
    out = augment_batch(x, "crop_flip", g, pv)
    g2 = torch.Generator()
    g2.set_state(state)
    oy = torch.randint(0, 9, (16,), generator=g2)
    ox = torch.randint(0, 9, (16,), generator=g2)
    flip = torch.rand(16, generator=g2) < 0.5
    assert torch.equal(out, _ref_augment(x, oy, ox, flip, pv))
    g3 = torch.Generator()
    g3.set_state(state)
    assert torch.equal(out, augment_batch(x, "crop_flip", g3, pv))
    assert torch.equal(augment_batch(x, "none", g, pv), x)


def test_finite_domain_split_sampled_mode():
    pool, val, test, meta = finite_domain_split(2 ** 30, 5000, 1000, 1000, 0, "t")
    assert meta["mode"] == "sampled_unique_codes"
    allc = torch.cat([pool, val, test])
    assert len(torch.unique(allc)) == len(allc)


# ---------------------------------------------------------------- real datasets (only if present)
ROOT = os.environ.get("COP_DATA_ROOT")


@pytest.mark.skipif(not ROOT, reason="set COP_DATA_ROOT to a folder with downloaded datasets")
@pytest.mark.parametrize("name,n", [("covertype", 2000), ("california", 2000), ("fashion_mnist", 1000),
                                    ("cifar10", 1000), ("cifar100", 1000)])
def test_real_datasets(name, n):
    # only datasets already on disk (the test never triggers a download)
    present = {"covertype": "sklearn/covertype", "california": "sklearn/cal_housing_py3.pkz",
               "fashion_mnist": "torchvision/FashionMNIST", "cifar10": "torchvision/cifar-10-batches-py",
               "cifar100": "torchvision/cifar-100-python"}[name]
    if not (Path(ROOT) / present).exists():
        pytest.skip(f"{name} not downloaded under COP_DATA_ROOT")
    b = load_bundle({"name": name, "n_train": n}, root=ROOT)
    assert len(b.train) == n
    assert b.preprocess["fitted_on"] == "train_subset"
    full = load_bundle({"name": name, "n_train": "full"}, root=ROOT)
    assert torch.equal(b.train_indices, full.train_indices[:n])
