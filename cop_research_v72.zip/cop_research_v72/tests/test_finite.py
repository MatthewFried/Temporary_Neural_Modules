"""Acceptance tests T07 and T08 plus validation of the finite certificate machinery (R3, I5)."""
import copy
import itertools
import json
import random
import time
from fractions import Fraction

import numpy as np
import pytest

from cop.finite import run_finite_job, resolve_finite_config, boolean, rank, message, piecewise, transition
from cop.finite.certificate import make_certificate, finalize_certificate
from cop.finite.checker import verify_certificate


def _certs(tmp_path, cfg, sub="j"):
    s = run_finite_job(cfg, tmp_path / sub)
    out = []
    for c in s["certificates"]:
        out.append((json.load(open(c["path"])), c["independent_check"]))
    return out


# ---------------------------------------------------------------- validation of the Boolean checker
def test_xor_not_single_threshold_unit(tmp_path):
    (c, chk), = _certs(tmp_path, {"kind": "boolean_class", "boolean_class": {"target": "xor"}})
    assert c["status"] == "certified_no_member"
    assert c["coverage"]["examined"] == c["coverage"]["total"] == 27
    assert c["data"]["min_error_examined"] == 1
    assert chk["verdict"] == "verified"


def test_and_single_unit_and_xor_width2(tmp_path):
    (c, chk), = _certs(tmp_path, {"kind": "boolean_class", "boolean_class": {"target": "and"}}, "and")
    assert c["status"] == "witness_found" and c["witness"]["errors"] == 0 and chk["ok"]
    (c, chk), = _certs(tmp_path, {"kind": "boolean_class", "boolean_class": {"target": "xor", "hidden_widths": [2]}}, "x2")
    assert c["status"] == "witness_found" and chk["ok"]
    # independently evaluate the witness
    L = c["witness"]["layers"]
    for i in range(4):
        x = [(i >> j) & 1 for j in range(2)]
        h = [int(sum(w * xi for w, xi in zip(row, x)) + b > 0) for row, b in zip(L[0]["W"], L[0]["b"])]
        o = int(sum(w * hi for w, hi in zip(L[1]["W"][0], h)) + L[1]["b"][0] > 0)
        assert o == (x[0] ^ x[1])


def test_xor_min_error_with_tolerance(tmp_path):
    (c, chk), = _certs(tmp_path, {"kind": "boolean_class", "boolean_class": {"target": "xor", "tolerance_errors": 1}})
    assert c["status"] == "witness_found" and c["witness"]["errors"] == 1 and chk["ok"]


# ---------------------------------------------------------------- T07
def test_T07_rank_lower_bound_and_witness(tmp_path):
    M = [[1, 0, 0, 2], [0, 1, 0, 3], [0, 0, 1, 4], [1, 1, 1, 9]]  # rank 3 exactly
    assert rank.exact_rank(rank.to_fraction_matrix(M)[0]) == 3
    (c, chk), = _certs(tmp_path, {"kind": "rank", "rank": {"matrix": M, "bottleneck": 2}}, "r2")
    assert c["status"] == "certified_no_member" and c["data"]["rank"] == 3 and chk["verdict"] == "verified"
    (c, chk), = _certs(tmp_path, {"kind": "rank", "rank": {"matrix": M, "bottleneck": 3}}, "r3")
    assert c["status"] == "witness_found" and chk["verdict"] == "verified"
    A = [[Fraction(v) for v in r] for r in c["witness"]["A"]]
    B = [[Fraction(v) for v in r] for r in c["witness"]["B"]]
    assert rank.matmul(A, B) == [[Fraction(v) for v in r] for r in M]
    # approximate: Eckart-Young bound, exact interval mode and float margin mode, both checked
    s = np.linalg.svd(np.array(M, float), compute_uv=False)
    tail = float(np.sum(s[2:] ** 2))
    for emd, sub, want in ((8, "ae", "certified_lower_bound"), (0, "af", "numerical_bound")):
        (c, chk), = _certs(tmp_path, {"kind": "rank", "rank": {"matrix": M, "bottleneck": 2, "mode": "approx",
                                                               "tolerance": tail * 0.99, "exact_max_dim": emd}}, sub)
        assert c["status"] == want, c
        assert c["data"]["lower_bound"] <= tail + 1e-9
        assert chk["verdict"] == "verified", chk
    # a float-mode bound relabelled as a proof is rejected
    bad = copy.deepcopy(c)
    bad["status"] = "certified_lower_bound"
    assert verify_certificate(bad)["verdict"] == "rejected"
    # tolerance above the optimum: numerical witness (truncated SVD) accepted
    (c, chk), = _certs(tmp_path, {"kind": "rank", "rank": {"matrix": M, "bottleneck": 2, "mode": "approx",
                                                           "tolerance": tail * 1.01}}, "aw")
    assert c["status"] == "witness_found" and chk["ok"]


def test_T07_message_bound_and_witness(tmp_path):
    certs = _certs(tmp_path, {"kind": "message", "message": {"n_bits": 3, "k_bits": 2}}, "m32")
    enum, ana = certs
    assert enum[0]["status"] == "certified_no_member" and enum[0]["coverage"]["examined"] == 4 ** 8
    assert enum[0]["data"]["min_errors_exact"]
    assert enum[0]["data"]["min_errors_examined"] >= ana[0]["data"]["analytic_lower_bound"] >= 1
    assert ana[0]["status"] == "certified_lower_bound"
    assert enum[1]["verdict"] == "verified" and ana[1]["verdict"] == "verified"
    # compact witness: n = k, identity encoder
    enum, ana = _certs(tmp_path, {"kind": "message", "message": {"n_bits": 2, "k_bits": 2}}, "m22")
    assert enum[0]["status"] == "witness_found" and enum[0]["witness"]["errors"] == 0 and enum[1]["ok"]
    assert ana[0]["status"] == "no_certificate"


def test_message_exact_min_brute_force():
    # independent brute force for (n,k) = (2,1) and (3,1)
    for n, k in ((2, 1), (3, 1)):
        N, M = 2 ** n, 2 ** k
        xs = [[(i >> j) & 1 for j in range(n)] for i in range(N)]
        best = None
        for enc in itertools.product(range(M), repeat=N):
            e = 0
            for m in range(M):
                blk = [xs[i] for i in range(N) if enc[i] == m]
                for q in range(n):
                    o = sum(x[q] for x in blk)
                    e += min(o, len(blk) - o)
            best = e if best is None else min(best, e)
        r = message.enumerate_min_errors(n, k)
        assert r["complete"] and r["min_errors_examined"] == best
        assert message.analytic_lower_bound(n, k) <= best


# ---------------------------------------------------------------- T08
def test_T08_incomplete_enumeration_has_exact_coverage_and_no_proof(tmp_path):
    cfg = {"kind": "boolean_class", "boolean_class": {"target": "xor", "n_inputs": 3, "hidden_widths": [2],
                                                       "max_members": 1000}}
    (c, chk), = _certs(tmp_path, cfg, "inc")
    total = 3 ** ((3 + 1) * 2 + (2 + 1) * 1)
    assert c["coverage"]["total"] == total and c["coverage"]["examined"] == 1000
    assert c["coverage"]["complete"] is False
    assert c["status"] == "incomplete"
    assert chk["verdict"] == "verified"
    # tampering: claim a proof with the same incomplete coverage
    bad = copy.deepcopy(c)
    bad["status"] = "certified_no_member"
    v = verify_certificate(bad)
    assert not v["ok"] and v["verdict"] == "rejected"
    # tampering: also claim complete coverage while examined < total
    bad["coverage"]["complete"] = True
    v = verify_certificate(bad)
    assert not v["ok"] and v["verdict"] == "rejected"


def test_T08_timeout_never_proves():
    r = boolean.enumerate_class(2, [], [-1, 0, 1], boolean.named_target("xor", 2), deadline=time.time() - 1)
    assert r["status"] == "incomplete" and r["examined"] == 0 and r["timed_out"]
    r = message.enumerate_min_errors(3, 2, deadline=time.time() - 1)
    assert not r["complete"] and r["examined"] == 0


def test_T08_guard_downgrades_proof_without_coverage():
    c = make_certificate(ctype="boolean_class", status="certified_no_member", domain={}, cls={}, tolerance=0,
                         precision="exact", coverage={"method": "enumeration", "complete": False, "examined": 1,
                                                      "total": 2}, scope="test")
    assert c["status"] == "incomplete" and c["notes"]


def test_T08_message_incomplete_still_has_analytic_bound(tmp_path):
    enum, ana = _certs(tmp_path, {"kind": "message", "message": {"n_bits": 4, "k_bits": 2, "max_encoders": 5000}}, "m42")
    assert enum[0]["status"] == "incomplete" and enum[0]["coverage"]["examined"] == 5000
    assert ana[0]["status"] == "certified_lower_bound" and ana[1]["ok"]


# ---------------------------------------------------------------- piecewise
def test_piecewise_bound_and_exact_characterisation(tmp_path):
    # tent: slopes 0 | 1 | -1 | 0  -> 3 genuine knots, 4 pieces
    base = {"points": [0, 1, 2], "values": [0, 1, 0], "left_slope": 0, "right_slope": 0}
    for w, want in ((2, "certified_no_member"), (3, "witness_found"), (5, "witness_found")):
        (c, chk), = _certs(tmp_path, {"kind": "piecewise", "piecewise": {**base, "width": w}}, f"p{w}")
        assert c["status"] == want and chk["verdict"] == "verified", (w, c, chk)
    # w == r with no valid subset: slopes 1 | 2 | 4, changes 1, 2; need subset summing to -1: none
    (c, chk), = _certs(tmp_path, {"kind": "piecewise", "piecewise": {"points": [0, 1], "values": [0, 2],
                                                                     "left_slope": 1, "right_slope": 4, "width": 2}}, "ss")
    assert c["status"] == "certified_no_member" and c["data"]["rule"] == "exact_characterisation_subset_sum"
    assert chk["ok"]
    # affine target with width 1 is impossible, width 2 possible
    (c, chk), = _certs(tmp_path, {"kind": "piecewise", "piecewise": {"points": [0], "values": [1], "left_slope": 3,
                                                                     "right_slope": 3, "width": 1}}, "aff1")
    assert c["status"] == "certified_no_member" and chk["ok"]
    (c, chk), = _certs(tmp_path, {"kind": "piecewise", "piecewise": {"points": [0], "values": [1], "left_slope": 3,
                                                                     "right_slope": 3, "width": 2}}, "aff2")
    assert c["status"] == "witness_found" and chk["ok"]
    (c, chk), = _certs(tmp_path, {"kind": "piecewise", "piecewise": {**base, "width": 3, "tolerance": "1/10"}}, "apx")
    assert c["status"] == "unsupported"


def test_piecewise_random_agreement():
    rnd = random.Random(0)
    for _ in range(60):
        p = sorted(rnd.sample(range(-5, 6), rnd.randint(1, 4)))
        v = [rnd.randint(-3, 3) for _ in p]
        sL, sR = rnd.randint(-2, 2), rnd.randint(-2, 2)
        w = rnd.randint(0, 5)
        d = piecewise.piecewise_certificate_data(p, v, sL, sR, w)
        c = make_certificate(ctype="piecewise", status=d.pop("status"),
                             domain={"points": p, "values": v, "left_slope": sL, "right_slope": sR},
                             cls={"width": w}, tolerance=0, precision="exact", coverage={"method": "x", "complete": True},
                             scope="t", witness=d.pop("witness", None), data=d)
        assert verify_certificate(c)["ok"], (p, v, sL, sR, w, c)


# ---------------------------------------------------------------- checker agreement on random instances
def test_checker_agrees_on_random_boolean_instances():
    rnd = random.Random(1)
    for _ in range(20):
        n = rnd.choice([2, 3])
        widths = rnd.choice([[], [1]])
        tgt = [rnd.randint(0, 1) for _ in range(2 ** n)]
        r = boolean.enumerate_class(n, widths, [-1, 0, 1], tgt)
        c = make_certificate(ctype="boolean_class", status=r["status"],
                             domain={"n_inputs": n}, cls={"hidden_widths": widths, "weight_set": r["weight_set"],
                                                          "class_size": r["total"]},
                             tolerance={"max_error_count": 0}, precision="exact",
                             coverage={"method": "enumeration", "examined": r["examined"], "total": r["total"],
                                       "complete": r["complete"]}, scope="t", witness=r["witness"],
                             data={"target": tgt, "min_error_examined": r["min_error_examined"],
                                   "min_error_exact": r["min_error_exact"]})
        assert verify_certificate(c)["verdict"] == "verified"


def test_checker_rejects_false_witness_and_false_rank_claim(tmp_path):
    (c, _), = _certs(tmp_path, {"kind": "boolean_class", "boolean_class": {"target": "and"}}, "a")
    bad = copy.deepcopy(c)
    bad["witness"]["params"] = [0, 0, 0]
    assert verify_certificate(bad)["verdict"] == "rejected"
    (c, _), = _certs(tmp_path, {"kind": "rank", "rank": {"matrix": [[1, 0], [0, 1]], "bottleneck": 2}}, "r")
    bad = copy.deepcopy(c)
    bad["status"] = "certified_no_member"
    assert verify_certificate(bad)["verdict"] == "rejected"


# ---------------------------------------------------------------- transition systems (I5)
def test_permutation_chain_positive_control(tmp_path):
    start = [[1, 2, 0], [0, 2, 1], [2, 1, 0]]  # three non-identity modules
    (c, chk), = _certs(tmp_path, {"kind": "transition", "transition": {"system": "permutation_chain",
                                                                       "params": {"m": 3, "K": 3, "start": start}}}, "pc")
    d = c["data"]
    assert c["status"] == "complete_analysis" and d["n_states"] == 43
    assert d["return_label_counts"].get("return_impossible", 0) == 0
    init = d["initial"][0]
    assert init["return_label"] == "return_possible_zero_loss_path"
    assert init["p_hit_simple"] == "1" and init["entrenchment_inevitable"] is False
    assert init["expected_time_to_simple"] is not None
    assert chk["verdict"] == "verified", chk


def test_absorbing_toy_no_return_and_inevitability(tmp_path):
    (c, chk), = _certs(tmp_path, {"kind": "transition", "transition": {"system": "absorbing_toy"}}, "ab")
    d = c["data"]
    labels = dict(zip([json.dumps(s) for s in d["graph"]["states"]], d["graph"]["labels"]))
    assert labels['"c3"'] == labels['"c4"'] == "return_impossible"
    assert labels['"s5"'] == "return_possible_only_via_higher_loss"
    assert labels['"s1"'] == "return_possible_zero_loss_path"
    s1 = d["initial"][0]
    assert s1["p_hit_simple"] == "2/3" and s1["entrenchment_inevitable"] is True
    s5 = d["initial"][1]
    assert s5["expected_time_to_simple"] == "6"
    assert chk["verdict"] == "verified"
    # variant with a good closed class: bad state reachable but not inevitable
    (c, chk), = _certs(tmp_path, {"kind": "transition", "transition": {"system": "absorbing_toy",
                                                                       "params": {"with_good_closed_class": True}}}, "ab2")
    s1 = c["data"]["initial"][0]
    assert s1["bad_class_reachable"] is True and s1["entrenchment_inevitable"] is False and chk["ok"]


def test_transition_cap_gives_unsearched(tmp_path):
    (c, chk), = _certs(tmp_path, {"kind": "transition", "transition": {"system": "permutation_chain",
                                                                       "params": {"K": 4}, "state_cap": 20,
                                                                       "simple_threshold": None}}, "cap")
    assert c["status"] == "incomplete"
    d = c["data"]
    assert d["closed_classes"] is None
    assert set(d["return_label_counts"]) <= {"unsearched", "in_simple_set", "return_possible_witnessed_incomplete"}
    assert chk["verdict"] == "verified"
    bad = copy.deepcopy(c)
    bad["status"] = "complete_analysis"
    assert verify_certificate(bad)["verdict"] == "rejected"


def test_quantized_chain_dynamics_checked(tmp_path):
    for rule, K in (("neutral", 2), ("nonincreasing", 1), ("metropolis", 1)):
        (c, chk), = _certs(tmp_path, {"kind": "transition", "transition": {
            "system": "quantized_chain", "params": {"K": K, "rule": rule, "target": "xor",
                                                    "start": [[1, 1, 0, 0, 1, 0]]}}}, f"q{rule}")
        assert c["status"] == "complete_analysis" and chk["verdict"] == "verified", (rule, chk)


def test_transition_tampered_edge_rejected(tmp_path):
    (c, _), = _certs(tmp_path, {"kind": "transition", "transition": {"system": "permutation_chain"}}, "t")
    bad = copy.deepcopy(c)
    e = bad["data"]["graph"]["edges"]
    i, j, p = e[0]
    e[0] = [i, (j + 1) % len(bad["data"]["graph"]["states"]), p]
    assert verify_certificate(bad)["verdict"] == "rejected"


def test_config_rejects_unknown_keys():
    with pytest.raises(ValueError):
        resolve_finite_config({"kind": "rank", "rank": {"bogus": 1}})
    with pytest.raises(ValueError):
        resolve_finite_config({"kind": "rank", "colour": 1})
    with pytest.raises(ValueError):
        resolve_finite_config({"kind": "nope"})
