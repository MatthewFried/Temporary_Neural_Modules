"""Strengthening addendum (wave 7): calibrations of Section 7 run through the cop
code, and the regression tests of the extension's operators, controls and
endpoints.  Calibration tests are named S7x; extension tests Fxx / Cx / Mx."""
from __future__ import annotations

import copy
import hashlib
import itertools
import json
import sys
from fractions import Fraction
from pathlib import Path

import pytest
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from cop.graph import edits as E  # noqa: E402
from cop.graph.builders import build_mlp  # noqa: E402
from cop.train.trainer import LocalOpt  # noqa: E402
from cop.config import TRAIN_DEFAULTS  # noqa: E402
from cop.utils import torch_gen  # noqa: E402

FIX = Path(__file__).resolve().parent / "fixtures" / "strengthening"


def _sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


# =============================================================================
# S7  Section 7 calibrations
# =============================================================================

def test_S7_port_reproduces_the_supplied_results_bitwise(tmp_path, monkeypatch):
    from cop.calibration import boundary
    monkeypatch.setattr(sys, "argv", ["boundary", "--out", str(tmp_path)])
    boundary.main()
    for name in ("boundary_results.json", "scalar_trajectories.csv"):
        assert _sha(tmp_path / name) == _sha(FIX / name), name
    q = boundary.query_before_encoding()
    assert q["one_bit_errors"] == 0 and q["zero_bit_errors"] == 12


def _scalar_net(w0: float = 1.0):
    """y = w x (1-d, bias kept at exactly zero by symmetric data), float64."""
    g = build_mlp(1, [], 1, torch_gen(0, "init"), act="identity").to(torch.float64)
    head = g.output
    with torch.no_grad():
        g.mods[g.nodes[head].pkey].weight.fill_(w0)
        g.mods[g.nodes[head].pkey].bias.zero_()
    return g, head


def _sgd_step(g, eta: float):
    """One full-batch SGD step on L = E[(y - 2x)^2] / 2 with E[x^2] = 1 (x = +-1)."""
    x = torch.tensor([[1.0], [-1.0]], dtype=torch.float64)
    t = 2.0 * x
    tc = dict(TRAIN_DEFAULTS, optimizer="sgd", lr=eta, weight_decay=0.0)
    opt = LocalOpt(list(g.parameters()), tc, 1)
    loss = 0.5 * ((g({"x": x}) - t) ** 2).mean()
    opt.step(loss, 0)


def _effective_w(g) -> float:
    x = torch.tensor([[1.0]], dtype=torch.float64)
    return float(g({"x": x})[0, 0].detach())


@pytest.mark.parametrize("eta,direct_loss,expanded_loss", [(Fraction(1, 5), Fraction(8, 25), Fraction(98, 625)),
                                                           (Fraction(6, 5), Fraction(1, 50), Fraction(5041, 1250))])
def test_S71_factorised_scalar_one_step_through_the_graph(eta, direct_loss, expanded_loss):
    """7.1 through factorize_node, the shared optimizer path and the exact fold."""
    direct, head = _scalar_net()
    _sgd_step(direct, float(eta))
    w_d = _effective_w(direct)
    assert abs(w_d - float(1 + eta)) < 1e-12
    fac, head = _scalar_net()
    iid = E.factorize_node(fac, head, torch_gen(0, "insertion"), width=1)
    assert abs(_effective_w(fac) - 1.0) < 1e-15                        # exact insertion
    _sgd_step(fac, float(eta))
    folded = E.fold_implant(fac, iid, share_params=False)
    assert folded.n_params() == direct.n_params()                      # same exported architecture
    w_e = _effective_w(folded)
    assert abs(w_e - float((1 + eta) ** 2)) < 1e-12
    assert abs(0.5 * (w_d - 2) ** 2 - float(direct_loss)) < 1e-12
    assert abs(0.5 * (w_e - 2) ** 2 - float(expanded_loss)) < 1e-12


@pytest.mark.parametrize("c", [0.25, 0.5, 2.0, 4.0])
def test_S71_effective_update_formula_and_factor_balance(c):
    """w' = w - eta g (a^2 + b^2) + eta^2 g^2 w; the same function with balance c
    gives a different update (balance is an optimisation intervention, not a function change)."""
    eta = 0.05
    fac, head = _scalar_net()
    iid = E.factorize_node(fac, head, torch_gen(0, "insertion"), width=1, balance=c)
    assert abs(_effective_w(fac) - 1.0) < 1e-12
    W1 = fac.mods[next(n.pkey for n in fac.nodes.values() if n.owner == iid and n.role == "W1")].weight
    W2 = fac.mods[next(n.pkey for n in fac.nodes.values() if n.owner == iid and n.role == "W2")].weight
    a, b = float(W1.detach()), float(W2.detach())
    assert abs(abs(a) - c) < 1e-12 and abs(abs(b) - 1 / c) < 1e-12
    w = a * b
    g_ = w - 2.0
    _sgd_step(fac, eta)
    want = w - eta * g_ * (a * a + b * b) + eta * eta * g_ * g_ * w
    assert abs(_effective_w(fac) - want) < 1e-12
    if c != 1.0:
        assert abs(want - (1 + eta * 2.0) ** 2) > 1e-6 or abs(c - 1) < 1e-9   # differs from the balanced update


def test_S72_late_query_certificates_match_the_calibration(tmp_path):
    """7.2 with the existing delayed-query certificate (encoder sees x only) and
    the new query-before-encoding class; every certificate independently verified."""
    from cop.finite import run_finite_job
    from cop.finite import message
    ref = json.loads((FIX / "boundary_results.json").read_text())["late_query"]["curves"]
    got = {}
    for k in (0, 1, 2, 3):
        s = run_finite_job({"kind": "message", "message": {"n_bits": 3, "k_bits": k}}, tmp_path / f"a{k}")
        for cc in s["certificates"]:
            assert cc["independent_check"]["verdict"] == "verified", cc
        d = json.load(open(s["certificates"][0]["path"]))
        got[2 ** k] = d["data"]["min_errors_examined"]
    assert got == {r["code_count"]: r["min_errors"] for r in ref} == {1: 12, 2: 6, 4: 4, 8: 0}
    for k, want in ((0, 12), (1, 0), (2, 0)):
        s = run_finite_job({"kind": "message", "message": {"n_bits": 3, "k_bits": k, "query_timing": "before"}},
                           tmp_path / f"b{k}")
        cc = s["certificates"][0]
        assert cc["independent_check"]["verdict"] == "verified", cc
        assert json.load(open(cc["path"]))["data"]["min_errors_examined"] == want
    # task sufficiency vs retained information: keep only x0 (2 codes)
    X = message.domain_bits(3)
    labels = X[:, 0][None].astype("int64")
    assert int(message.encoder_errors(labels, X, 2)[0]) == 8           # 16 / 24 = 2/3 on a uniform later query


def _inverse_pair_identity_net(W):
    g = build_mlp(2, [], 2, torch_gen(0, "init"), act="identity").to(torch.float64)
    with torch.no_grad():
        m = g.mods[g.nodes[g.output].pkey]
        m.weight.copy_(torch.eye(2, dtype=torch.float64))
        m.bias.zero_()
    cut = E.cut_at(g, "input", 0)
    G, T, Ti = E.insert_inverse_pair(g, cut, torch_gen(0, "insertion"), kind="linear", tie="untied", W_init=W)
    return g, G, T, Ti


def test_S73_single_necessity_does_not_imply_group_necessity():
    """7.3: A = diag(2, 1/2) and its inverse; on {-1,0,1}^2 either single deletion
    costs per-coordinate MSE 5/12, the joint deletion costs 0; the deletion search
    (exhaustive and structured families) contains the zero-cost pair."""
    from cop.experiments.deletion import family
    from cop.config import DELETION_DEFAULTS
    W = torch.diag(torch.tensor([2.0, 0.5], dtype=torch.float64))
    g, G, T, Ti = _inverse_pair_identity_net(W)
    X = torch.tensor(list(itertools.product((-1.0, 0.0, 1.0), repeat=2)), dtype=torch.float64)
    base = g({"x": X})
    assert torch.allclose(base, X, atol=1e-15)
    assert abs(g.implants[G].meta["inverse"]["condition_number"] - 4.0) < 1e-12

    def cost(atoms):
        h = E.delete(g, atoms, share_params=False)
        return float(((h({"x": X}) - base) ** 2).mean())
    assert abs(cost([T]) - 5 / 12) < 1e-12 and abs(cost([Ti]) - 5 / 12) < 1e-12
    assert cost([T, Ti]) < 1e-24 and cost([G]) < 1e-24
    for fam_kind in ("exhaustive", "structured"):
        fam, _ = family(g, dict(DELETION_DEFAULTS, family=fam_kind), 0)
        zero = [S for _, S in fam if cost(list(S)) < 1e-24]
        assert any(set(S) == {T, Ti} or G in S for S in zero), (fam_kind, fam)
        assert all(cost([a]) > 0.4 for a in (T, Ti))


def test_S73_inverse_pair_condition_number_is_controlled():
    g = build_mlp(4, [8], 2, torch_gen(0, "init"))
    for kappa in (1.0, 10.0, 1000.0):
        h = g.clone(share_params=False)
        G, _, _ = E.insert_inverse_pair(h, E.cut_at(h, "post_act", 0), torch_gen(1, "insertion"), kind="linear",
                                        tie="untied", cond=kappa)
        assert abs(h.implants[G].meta["inverse"]["condition_number"] / kappa - 1) < 1e-9
        x = torch.randn(16, 4, generator=torch_gen(2, "data"))
        assert torch.allclose(h({"x": x}), g({"x": x}), atol=1e-4 * max(1.0, kappa ** 0.5))


def test_S74_equivalent_networks_with_incompatible_code_conventions():
    """7.4: old and new networks are both perfect; old encoder + new decoder gives 0%;
    a symbol alignment fitted on training pairs restores 100%."""
    from cop.cop_pegs.transplant import fit_alignment, Transplant
    perm = [(i + 1) % 8 for i in range(8)]
    inv = [perm.index(i) for i in range(8)]
    P, Pinv = torch.tensor(perm), torch.tensor(inv)

    class Enc(torch.nn.Module):
        def __init__(self, table):
            super().__init__()
            self.t = table

        def forward(self, x):
            return self.t[x][:, None].double()

    class Dec(torch.nn.Module):
        def __init__(self, table):
            super().__init__()
            self.t = table

        def forward(self, z):
            return self.t[z[:, 0].round().long()]
    x = torch.arange(8)
    old_enc, old_dec = Enc(torch.arange(8)), Dec(torch.arange(8))
    new_enc, new_dec = Enc(P), Dec(Pinv)
    acc = lambda f: float((f(x) == x).double().mean())
    assert acc(lambda v: old_dec(old_enc(v))) == 1.0 and acc(lambda v: new_dec(new_enc(v))) == 1.0
    assert acc(Transplant(old_enc, new_dec)) == 0.0
    al, info = fit_alignment("symbol", old_enc(x), new_enc(x))
    assert info["one_to_one"] and info["training_pair_agreement"] == 1.0
    assert acc(Transplant(old_enc, new_dec, al)) == 1.0
    # continuous convention: a rotation is recovered exactly by the affine alignment
    Z = torch.randn(64, 3, generator=torch_gen(0, "data", "z"), dtype=torch.float64)
    Q = torch.linalg.qr(torch.randn(3, 3, generator=torch_gen(1, "data", "q"), dtype=torch.float64))[0]
    alA, infoA = fit_alignment("affine", Z, Z @ Q.T + 0.5)
    assert infoA["train_nmse"] < 1e-12 and torch.allclose(alA(Z), Z @ Q.T + 0.5, atol=1e-8)


def test_S3_zero_output_insertion_keeps_a_live_gradient():
    """Section 3: a zero-output nonlinear insertion zeroes only the final projection;
    the output is unchanged and gradients reach both layers within two steps."""
    g = build_mlp(4, [8, 8], 2, torch_gen(0, "init"))
    x = torch.randn(32, 4, generator=torch_gen(1, "data"))
    y = torch.randn(32, 2, generator=torch_gen(2, "data", "y"))
    before = g({"x": x}).detach()
    iid = E.insert_residual_zero(g, E.cut_at(g, "post_act", 0), torch_gen(3, "insertion"), width=6)
    assert torch.equal(g({"x": x}).detach(), before)
    A = g.mods[next(n.pkey for n in g.nodes.values() if n.owner == iid and n.role == "A")]
    B = g.mods[next(n.pkey for n in g.nodes.values() if n.owner == iid and n.role == "B")]
    opt = LocalOpt(list(g.parameters()), dict(TRAIN_DEFAULTS, optimizer="sgd", lr=0.1), 2)
    grads = []
    for k in range(2):
        loss = F.mse_loss(g({"x": x}), y)
        opt.step(loss, k)
        grads.append((float(A.weight.grad.abs().sum()), float(B.weight.grad.abs().sum())))
    assert grads[0][1] > 0 and grads[0][0] == 0.0        # B live at step 0; A receives gradient once B moved
    assert grads[1][0] > 0 and grads[1][1] > 0
