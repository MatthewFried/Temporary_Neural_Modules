"""Regression tests for the v3 strengthening extension (variants F01-F10, controls
C0-C8, mechanisms A-H).  Unit tests use independent oracles (exact function
equality in fp64, closed-form counts); job tests run tiny configurations end to
end on CPU and check the recorded invariants (export architecture, compute
matching, accounting, resume equality)."""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import pytest
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests"))

import tiny_configs as T  # noqa: E402
from cop.config import resolve, run_id, ConfigError, TRAIN_DEFAULTS  # noqa: E402
from cop.data.registry import load_bundle  # noqa: E402
from cop.graph import edits as E  # noqa: E402
from cop.graph.accounting import architecture_hash, transfer_by_architecture, count_macs, count_params  # noqa: E402
from cop.graph.builders import build_mlp, build_cnn  # noqa: E402
from cop.graph.graph import InvalidDeletion  # noqa: E402
from cop.train.trainer import Trainer, Segment, schedule_phase, forward_macs  # noqa: E402
from cop.cop_pegs.transplant import fit_alignment  # noqa: E402
from cop.orchestration.runner import run_job, status_of  # noqa: E402
from cop.utils import torch_gen, read_json, read_jsonl  # noqa: E402

G = lambda k: torch_gen(0, "insertion", "v3test", k)


def tc(**kw):
    t = dict(TRAIN_DEFAULTS)
    t.update(kw)
    return t


def seeds():
    return {"minibatch": 0, "augmentation": 0, "fresh": 0, "dropout": 0, "optimizer": 0}


def vec_bundle(n=256, task="regression", name="teacher", params=None):
    p = params if params is not None else {"teacher_depth": 1, "task": task, "d_in": 8, "out_dim": 3}
    return load_bundle({"name": name, "n_train": n, "n_val": 128, "n_test": 128, "params": p})


def out64(g, X):
    g.double().eval()
    with torch.no_grad():
        return g({k: v.double() for k, v in X.items()})


# ----------------------------------------------------------------------------- architecture identity

def test_architecture_hash_ignores_node_ids_and_transfer_copies_the_function():
    g = build_mlp(6, [8, 8, 8], 3, torch_gen(0, "init")).double()
    h = build_mlp(6, [8, 8, 8], 3, torch_gen(1, "init")).double()
    X = {"x": torch.randn(11, 6, dtype=torch.float64)}
    assert architecture_hash(g) == architecture_hash(h)
    assert not torch.equal(out64(g, X), out64(h, X))
    pairs = transfer_by_architecture(g, h)
    assert torch.equal(out64(g, X), out64(h, X))
    assert len(pairs) == sum(1 for _ in g.parameters())
    # an implant changes the architecture; deleting it restores the hash although node ids moved on
    a = g.clone(share_params=False)
    iid = E.insert_residual_zero(a, E.cut_at(a, "post_act", 1), G("r"), width=4)
    assert architecture_hash(a) != architecture_hash(g)
    b = E.delete(a, [iid], share_params=False)
    assert architecture_hash(b) == architecture_hash(g)


def _first(g, op):
    return next(n for n in g.topo_order(g.live_nodes()) if g.nodes[n].op == op and g.nodes[n].owner is None)


def test_split_node_is_exact_and_folds_back_to_f0():
    g = build_mlp(6, [8, 8], 3, torch_gen(0, "init")).double()
    X = {"x": torch.randn(13, 6, dtype=torch.float64)}
    y0 = out64(g, X)
    a = g.clone(share_params=False)
    lin = [n for n in a.topo_order(a.live_nodes()) if a.nodes[n].op == "linear"][1]
    iid = E.split_node(a, lin, G("s"), split=0.3)
    assert architecture_hash(a) != architecture_hash(g)
    assert torch.allclose(out64(a, X), y0, atol=1e-12, rtol=0)
    b = E.delete(a, [iid], share_params=False)
    assert architecture_hash(b) == architecture_hash(g)
    assert set(b.live_nodes()) != set(g.live_nodes())        # the folded node is new: ids differ, hash does not
    assert torch.allclose(out64(b, X), y0, atol=1e-12, rtol=0)
    with pytest.raises(Exception):
        E.split_node(g.clone(share_params=False), lin, G("s"), split=1.0)


@pytest.mark.parametrize("balance", [1.0, 4.0])
def test_factorize_linear_and_conv_are_exact_and_fold_back(balance):
    g = build_mlp(6, [8, 8], 3, torch_gen(0, "init")).double()
    X = {"x": torch.randn(9, 6, dtype=torch.float64)}
    y0 = out64(g, X)
    a = g.clone(share_params=False)
    lin = [n for n in a.topo_order(a.live_nodes()) if a.nodes[n].op == "linear"][1]
    iid = E.factorize_node(a, lin, G("f"), balance=balance)
    assert torch.allclose(out64(a, X), y0, atol=1e-10, rtol=0)
    b = E.delete(a, [iid], share_params=False)
    assert architecture_hash(b) == architecture_hash(g)
    assert torch.allclose(out64(b, X), y0, atol=1e-10, rtol=0)
    c = build_cnn(3, (8, 8), 4, torch_gen(0, "init"), 0.25).double()
    Xc = {"x": torch.randn(4, 3, 8, 8, dtype=torch.float64)}
    yc = out64(c, Xc)
    a = c.clone(share_params=False)
    conv = [n for n in a.topo_order(a.live_nodes()) if a.nodes[n].op == "conv"][1]
    iid = E.factorize_node(a, conv, G("fc"), balance=balance)
    assert torch.allclose(out64(a, Xc), yc, atol=1e-9, rtol=0)
    b = E.delete(a, [iid], share_params=False)
    assert architecture_hash(b) == architecture_hash(c)
    assert torch.allclose(out64(b, Xc), yc, atol=1e-9, rtol=0)


def test_inverse_pair_condition_number_and_mixing_nonlinearity():
    g = build_mlp(6, [8, 8], 3, torch_gen(0, "init")).double()
    X = {"x": torch.randn(9, 6, dtype=torch.float64)}
    y0 = out64(g, X)
    a = g.clone(share_params=False)
    Gi, Ti, Ui = E.insert_inverse_pair(a, E.cut_at(a, "post_act", 0), G("i"), kind="linear", tie="untied", cond=100.0)
    a.double()
    cn = [a.implants[x].meta["inverse"]["condition_number"] for x in (Gi, Ti, Ui)
          if "condition_number" in a.implants[x].meta.get("inverse", {})]
    assert cn and abs(cn[0] / 100.0 - 1) < 1e-6
    assert torch.allclose(out64(a, X), y0, atol=1e-9, rtol=0)
    # act 'mix' with s = 0 is an affine (foldable) region; s > 0 is not
    for s, affine in ((0.0, True), (0.5, False)):
        m = g.clone(share_params=False)
        iid = E.insert_residual_zero(m, E.cut_at(m, "post_act", 0), G("m"), width=4, nonlinearity=s)
        assert torch.allclose(out64(m, X), y0, atol=1e-12, rtol=0)
        assert E.region_is_affine(m, m.region(iid)) is affine


def test_gating_stacked_series_implants_removes_both():
    """v3 fix: a gate on the lower of two stacked series implants moved the upper implant's entry
    to the gated value; before the fix, closing both gates bypassed to the UNGATED lower exit and
    left the lower implant alive in the export."""
    from cop.graph.export import export_compact
    g = build_mlp(6, [8, 8], 3, torch_gen(0, "init")).double()
    X = {"x": torch.randn(9, 6, dtype=torch.float64)}
    y0 = out64(g, X)
    a = g.clone(share_params=False)
    cut = E.cut_at(a, "post_act", 0)
    i1 = E.insert_residual_zero(a, cut, G("s1"), width=4)
    i2 = E.insert_residual_zero(a, E.Cut(source=a.implants[i1].exit), G("s2"), width=4)
    for iid in (i1, i2):                         # make both implants change the function
        for n in a.implants[iid].nodes:
            if a.nodes[n].role == "B":
                torch.nn.init.normal_(a.mods[a.nodes[n].pkey].weight, std=0.3)
    a.double()
    assert not torch.allclose(out64(a, X), y0)
    for order in ((i1, i2), (i2, i1)):
        h = a.clone(share_params=False)
        gids = [E.add_gate(h, t) for t in order]
        for gd in gids:
            h.gate_vals[gd] = 0.0
        assert torch.allclose(out64(h, X), y0, atol=1e-12, rtol=0)
        exp, _ = export_compact(h)
        assert not [t for t in (i1, i2) if t in exp.implants and exp.implants[t].nodes]
        assert architecture_hash(exp) == architecture_hash(g)


def test_conv_fold_survives_pruning_of_the_replaced_node():
    from cop.graph.graph import GraphNet
    c = build_cnn(3, (8, 8), 4, torch_gen(0, "init"), 0.25).double()
    Xc = {"x": torch.randn(4, 3, 8, 8, dtype=torch.float64)}
    yc = out64(c, Xc)
    a = c.clone(share_params=False)
    conv = [n for n in a.topo_order(a.live_nodes()) if a.nodes[n].op == "conv"][1]
    iid = E.factorize_node(a, conv, G("pc"))
    E.prune_dead(a)                               # drops the dead replaced conv node
    a = GraphNet.from_checkpoint(a.checkpoint(), "cpu")
    assert conv not in a.nodes
    b = E.fold_implant(a, iid, share_params=False)
    assert architecture_hash(b) == architecture_hash(c)
    assert torch.allclose(out64(b, Xc), yc, atol=1e-9, rtol=0)


def test_deletion_refuses_an_implant_whose_internal_value_is_read_outside():
    g = build_mlp(6, [8, 8], 3, torch_gen(0, "init")).double()
    iid = E.insert_residual_zero(g, E.cut_at(g, "post_act", 0), G("d"), width=4)
    imp = g.implants[iid]
    inner = next(n for n in imp.nodes if g.nodes[n].op == "linear" and g.node_dim(n) == g.node_dim(imp.exit))
    reader = g.add_node("add", [imp.exit, inner], {"coefs": [1.0, 1.0], "terms": ["a", "b"],
                                                   **E._dimattrs(g, imp.exit)})
    g.replace_uses(imp.exit, reader, exclude={reader, *imp.nodes})
    g._plan = None
    with pytest.raises(InvalidDeletion):
        E.delete(g, [iid])


# ----------------------------------------------------------------------------- trainer

def test_train_macs_are_three_forward_passes_per_example_per_update():
    b = vec_bundle()
    g = build_mlp(8, [16, 16], 3, torch_gen(0, "init"))
    tr = Trainer(g, b, tc(batch_size=16, lr=1e-3), seeds(), "cpu")
    tr.configure("none", None, reset_state=True)
    tr.run(Segment("a", 7))
    assert tr.state["train_macs"] == 7 * 3 * 16 * count_macs(g)["macs"]
    assert forward_macs(g, 1, {}) == count_macs(g)["macs"]


def test_freeze_schedule_phases():
    t = tc(freeze_schedule="alternate", freeze_period=3)
    assert [schedule_phase(t, k) for k in range(8)] == [0, 0, 0, 1, 1, 1, 0, 0]
    t = tc(freeze_schedule="release", release_after=4)
    assert [schedule_phase(t, k) for k in range(6)] == [0, 0, 0, 0, 1, 1]
    assert schedule_phase(tc(), 99) == 0


def test_divergence_stops_training_and_skips_later_segments():
    b = vec_bundle()
    g = build_mlp(8, [16, 16], 3, torch_gen(0, "init"))
    tr = Trainer(g, b, tc(batch_size=16, lr=1e8, optimizer="sgd", grad_clip=0.0), seeds(), "cpu")
    tr.configure("none", None, reset_state=True)
    tr.run(Segment("a", 50))
    assert tr.state["diverged"] and tr.state["diverged_at"] is not None
    r = tr.run(Segment("b", 10))
    assert r["updates"] == 0 and r["diverged"]


def test_group_balanced_sampler_equalises_groups():
    b = load_bundle({"name": "shortcut", "n_train": 2048, "n_val": 128, "n_test": 128})
    g = build_mlp(b.input_spec["x"]["shape"][0], [8], 2, torch_gen(0, "init"))
    tr = Trainer(g, b, tc(batch_size=256, sampler="group_balanced"), seeds(), "cpu")
    frac = torch.stack([tr.next_batch().groups.float().mean() for _ in range(40)]).mean()
    base = b.train.groups.float().mean()
    assert base < 0.15 and abs(float(frac) - 0.5) < 0.05


def test_value_patch_is_inert_unless_set():
    g = build_mlp(6, [8], 3, torch_gen(0, "init")).double()
    X = {"x": torch.randn(5, 6, dtype=torch.float64)}
    y0 = out64(g, X)
    nid = _first(g, "act")
    g.value_patch = {nid: lambda t: torch.zeros_like(t)}
    y1 = out64(g, X)
    g.value_patch = None
    assert torch.equal(out64(g, X), y0) and not torch.equal(y1, y0)


# ----------------------------------------------------------------------------- alignment (mechanism C)

def test_symbol_and_affine_alignment_recover_the_map():
    gen = torch.Generator().manual_seed(0)
    Z = torch.randn(400, 5, generator=gen, dtype=torch.float64)
    A = torch.randn(5, 5, generator=gen, dtype=torch.float64)
    c = torch.randn(5, generator=gen, dtype=torch.float64)
    al, info = fit_alignment("affine", Z, Z @ A.T + c)
    assert torch.allclose(al(Z), Z @ A.T + c, atol=1e-6)
    perm = torch.randperm(5, generator=gen)
    al, info = fit_alignment("symbol", Z, Z[:, perm])
    assert torch.allclose(al(Z), Z[:, perm], atol=1e-9)


# ----------------------------------------------------------------------------- data

def test_shortcut_counterfactuals_are_paired_single_feature_interventions():
    b = load_bundle({"name": "shortcut", "n_train": 256, "n_val": 128, "n_test": 300})
    lay = b.meta["feature_layout"]
    c0, c1 = lay["causal"]
    s = lay["shortcut"]
    base, cfc, cfs = b.extra["cf_base"], b.extra["cf_causal"], b.extra["cf_shortcut"]
    xb, xc, xs = base.X["x"], cfc.X["x"], cfs.X["x"]
    assert torch.equal(xb[:, s:], xc[:, s:]) and (cfc.y != base.y).all()
    assert torch.equal(xb[:, :s], xs[:, :s]) and torch.equal(xb[:, s + 1:], xs[:, s + 1:])
    assert torch.equal(cfs.y, base.y) and (torch.sign(xs[:, s]) != torch.sign(xb[:, s])).float().mean() > 0.9


@pytest.mark.parametrize("op", ["bit", "xor_next", "two_bits"])
def test_delayed_query_ops(op):
    n = 6
    b = load_bundle({"name": "delayed_query", "n_train": 256, "n_val": 64, "n_test": 64,
                     "params": {"n_bits": n, "query_op": op, "pool_size": 256}})
    P = b.train
    bits = ((P.X["x"] + 1) / 2).long()
    q = P.X["q"].argmax(1)
    x1 = bits.gather(1, q[:, None]).squeeze(1)
    x2 = bits.gather(1, ((q + 1) % n)[:, None]).squeeze(1)
    want = {"bit": x1, "xor_next": x1 ^ x2, "two_bits": 2 * x1 + x2}[op]
    assert torch.equal(P.y, want)


def test_later_query_dataset():
    b = load_bundle({"name": "later_query", "n_train": 256, "n_val": 64, "n_test": 64,
                     "params": {"n_bits": 10, "task_bits": 2, "pool_size": 512}})
    for P in (b.train, b.test):
        bits = P.aux["later"].long()
        assert torch.equal(bits, ((P.X["x"] + 1) / 2).long())
        assert torch.equal(P.y, (bits[:, 0] + bits[:, 1]) % 2)


# ----------------------------------------------------------------------------- config validation

@pytest.mark.parametrize("peg,cop", [
    ({"redundancy": 3, "dim": 4}, {}),                                  # does not divide dim
    ({"temp_target": "peg"}, {}),                                       # needs a temp channel
    ({"temp_channel": 4, "temp_target": "peg"}, {}),                    # equal to 'pegs' when every peg is bridged
    ({"route_dropout": 0.5}, {}),                                       # no blocks
    ({}, {"route_repair_updates": 5}),                                  # no blocks
    ({"redundancy": 2, "temp_channel": 4}, {}),                         # repetition pegs have no bridge
])
def test_peg_option_validation(peg, cop):
    with pytest.raises(ConfigError):
        T.cop(cop, peg)


# ----------------------------------------------------------------------------- job level

def _run(cfgs, d):
    st = [run_job(c, d, {"device": "cpu"}) for c in cfgs]
    assert st[-1] == "complete", status_of(d, run_id(cfgs[-1])).get("reason")
    return d / "runs" / run_id(cfgs[-1])


def _metric(rd, name):
    return [r["metric_value"] for r in read_jsonl(rd / "metrics.jsonl") if r["metric_name"] == name]


@pytest.mark.parametrize("growth", [
    {"topology": "layered", "rounds": 2, "contract_every": 1, "contract_updates": 6},
    {"topology": "layered", "rounds": 2, "contract_every": 1, "contract_updates": 6, "contract_method": "abrupt",
     "cycle_cut": "moving"},
    {"topology": "node_factorization", "rounds": 2, "contract_every": 1, "factor_balance": 2.0},
])
def test_grow_contract_cycles_return_to_the_f0_architecture(tmp_path, growth):
    rd = _run(T.traj(growth), tmp_path)
    eq = _metric(rd, "export_architecture_equals_f0")
    assert eq and all(bool(v) for v in eq)


def test_round_trip_cycle_without_training_is_exact(tmp_path):
    cfgs = T.traj({"topology": "node_factorization", "rounds": 2, "updates_per_round": 0, "contract_every": 1,
                   "contract_updates": 0})
    rd = _run(cfgs, tmp_path)
    assert all(bool(v) for v in _metric(rd, "export_architecture_equals_f0"))
    base = [r for r in read_jsonl(tmp_path / "runs" / run_id(cfgs[0]) / "metrics.jsonl")
            if r["metric_name"] == "mse" and r["evaluation_partition"] == "test"]
    fin = [r for r in read_jsonl(rd / "metrics.jsonl") if r["metric_name"] == "mse"
           and r["evaluation_partition"] == "test" and r["stage"] in ("export", "final")]
    assert base and fin and abs(fin[-1]["metric_value"] - base[-1]["metric_value"]) < 1e-5


@pytest.mark.parametrize("sec,traj", [
    ({"method": "fold"}, {"topology": "node_split", "rounds": 1}),
    ({"method": "stochastic_bypass", "bypass_keep": 0.5, "bypass_rescale": True}, {"topology": "recursive_branch"}),
    ({"method": "abrupt", "order": "newest_first"}, {"topology": "tree_depth2", "rounds": 3}),
])
def test_dissipation_exports_the_f0_architecture(tmp_path, sec, traj):
    p = T.traj(traj)
    cfgs = p + [T.child("dissipation", p[-1], {"dissipation": {"speed_updates": 6, "post_updates": 6,
                                                                "path_eval_points": 3, **sec}})]
    rd = _run(cfgs, tmp_path)
    r = read_json(rd / "dissipation_result.json")
    assert r["export_architecture_equals_f0"] is True


def test_compute_matched_continuation_matches_the_treated_chain(tmp_path):
    b = T.base()
    p = T.traj({"topology": "recursive_branch"})
    dis = p + [T.child("dissipation", p[-1], {"dissipation": {"method": "abrupt", "post_updates": 6}})]
    cont = resolve({"kind": "continue", "data": T.DATA, "model": T.MODEL, "train": T.TRAIN, "seeds": {"optimizer": 0},
                    "parents": {"baseline": run_id(b), "treated": run_id(dis[-1])},
                    "continue": {"budget": "parent_compute", "budget_parent": "treated"}})
    rd = _run(dis + [cont], tmp_path)
    bud = read_json(rd / "budget.json")
    target = bud["parent_chain_work"]["macs"]
    s = read_json(rd / "summary.json")
    used = sum(v["macs"] for v in s["work"].values())
    r = read_json(rd / "continue_result.json")
    # ceil(target / per-update MACs) updates: at least the target, less than one update over it
    assert used >= target and used - target < used / max(1, r["updates"])


def test_self_transplant_is_exact(tmp_path):
    b = T.base()
    tp = resolve({"kind": "transplant", "data": T.DATA, "model": T.MODEL, "train": T.TRAIN, "seeds": {"optimizer": 0},
                  "parents": {"upstream": run_id(b), "downstream": run_id(b)},
                  "transplant": {"upstream_stage": "baseline", "downstream_stage": "baseline", "align": "affine",
                                 "cut_where": "middle"}})
    rd = _run([b, tp], tmp_path)
    r = read_json(rd / "transplant_result.json")["rows"]
    for part in r["downstream"]:
        assert r["direct"][part] == r["downstream"][part]
        assert abs(r["aligned"][part]["mse"] - r["downstream"][part]["mse"]) < 1e-4


def _log_events(rd, ev):
    return [json.loads(l) for l in open(rd / "log.jsonl") if f'"{ev}"' in l]


def test_temporary_bridge_targets_and_retained_adapter(tmp_path):
    rd = _run(T.cop({}, {"temp_channel": 4, "temp_open_updates": 5, "temp_on": "middle", "temp_target": "peg"}),
              tmp_path / "peg")
    ev = _log_events(rd, "trainable_set")
    # dim 4 peg on width 16: encoder 16*4+4, decoder 4*16+16, bridge the same: 2 * 148
    assert [(e["segment"], e["n_trainable_params"]) for e in ev][0] == ("anneal_temp_channel", 296)
    assert ev[-1]["segment"] == "endpoint"
    rd = _run(T.cop({}, {"temp_channel": 4, "temp_on": "middle", "temp_target": "adapter"}), tmp_path / "ad")
    ex = read_json(rd / "cop_chain_result.json")["export"]
    (ad,) = ex["retained_adapters"].values()
    assert ad["params"] == 148 and ad["bits_per_example"] == 4 * 32
    assert ex["bits_per_example_with_adapters"] == ex["bits_per_example_total"] + 128
    assert sum(bool(v.get("has_bypass")) for v in ex["bypass"].values()) == 1


def test_repetition_peg_routes_and_removal(tmp_path):
    rd = _run(T.cop({"route_repair_updates": 6}, {"redundancy": 2, "mode": "uniform", "bits": 3}), tmp_path)
    r = read_json(rd / "cop_chain_result.json")
    assert r["export"]["bits_per_example_total"] == 3 * 4 * 3
    for pid, v in r["route_damage"].items():
        for row in v["rows"]:
            # identical routes (no erasure training): dropping one and re-averaging is lossless
            for p in v["base"]:
                assert abs(row["renorm"][p] - v["base"][p]) < 1e-5
    assert r["route_repair"]["bits_per_example_after"] == 18


def test_later_query_decoders(tmp_path):
    LQ = {"name": "later_query", "n_train": 256, "n_val": 128, "n_test": 128,
          "params": {"n_bits": 10, "pool_size": 512}}
    rd = _run(T.cop({}, {"mode": "uniform", "bits": 1, "dim": 2}, data=LQ), tmp_path)
    lq = read_json(rd / "cop_chain_result.json")["later_queries"]
    assert all(a == 1.0 for a in lq["input_reaccess"]["test"])          # bits are linear in the +-1 input
    for v in lq["pegs"].values():
        assert v["decoder"] == "majority table per message" and v["train_messages"] <= 4
        assert 0.0 <= v["test_unseen_message_frac"] <= 1.0


def test_resume_equality_bridge_and_route_erasure(tmp_path):
    from resume_harness import compare_interrupted
    TR = {**T.TRAIN, "checkpoint_every": 7}
    cfgs = T.cop({"route_blocks": 2}, {"temp_channel": 4, "temp_open_updates": 5, "temp_on": "middle",
                                       "temp_target": "peg", "route_dropout": 0.5, "mode": "uniform", "bits": 3},
                 train=TR)
    r = compare_interrupted(cfgs, tmp_path)
    assert r["equal"], r


@pytest.mark.parametrize("order", ["ancestor_first", "oldest_first"])
def test_removal_order_keeps_a_read_branch_until_its_reader_goes(tmp_path, order):
    """Mechanism D on a diamond: the bridge reads the branch's hidden layer, so the branch is
    removed in the bridge's phase (not before it), and the contraction completes."""
    p = T.traj({"topology": "diamond", "rounds": 2})
    cfgs = p + [T.child("dissipation", p[-1], {"dissipation": {"method": "abrupt", "order": order,
                                                                "speed_updates": 0, "post_updates": 4,
                                                                "path_eval_points": 2}})]
    rd = _run(cfgs, tmp_path)
    r = read_json(rd / "dissipation_result.json")
    assert r["export_architecture_equals_f0"] is True
    assert sum(len(ph) for ph in r["phases"]) == len({t for ph in r["phases"] for t in ph})


def test_snapshot_child_is_charged_the_trajectory_work_up_to_the_snapshot(tmp_path):
    """C1 / C2 budgets of a contraction that starts from snap_<u> of its trajectory count the
    trajectory's growth updates up to u (not the whole trajectory) plus the contraction's own."""
    tr = {**T.TRAIN, "snapshot_at": [7]}
    b = T.base(train=tr)
    p = T.traj({"topology": "layered", "rounds": 2}, train=tr)          # 2 x 15 growth updates
    dis = T.child("dissipation", p[-1], {"dissipation": {"method": "abrupt", "speed_updates": 0, "post_updates": 5,
                                                         "path_eval_points": 2}}, tags={"parent_stage": "snap_7"})
    cont = resolve({"kind": "continue", "data": T.DATA, "model": T.MODEL, "train": T.TRAIN, "seeds": {"optimizer": 0},
                    "parents": {"baseline": run_id(b), "treated": run_id(dis)},
                    "continue": {"budget": "parent_updates", "budget_parent": "treated"}})
    rd = _run(p + [dis, cont], tmp_path)
    assert read_json(rd / "budget.json")["parent_chain_work"]["updates"] == 7 + 5
    assert read_json(rd / "continue_result.json")["updates"] == 12


def test_calibration_access_needs_a_label_free_target():
    p = T.traj({"topology": "recursive_branch"})
    with pytest.raises(ConfigError):
        T.child("repair", p[-1], {"repair": {"region": "full", "data_access": "calibration", "target": "task"}})
    T.child("repair", p[-1], {"repair": {"region": "full", "data_access": "calibration", "target": "expanded"}})


def test_bn_recalibration_leaves_upstream_statistics_alone():
    from cop.experiments.transplant_job import recalibrate_bn
    c = build_cnn(3, (8, 8), 4, torch_gen(0, "init"), 0.25)
    bns = [n for n in c.topo_order(c.live_nodes()) if c.nodes[n].op == "bn"]
    assert len(bns) >= 2
    up, down = bns[0], set(bns[1:])
    before = {k: v.clone() for k, v in c.mods[c.nodes[up].pkey].state_dict().items()}
    X = {"x": torch.randn(64, 3, 8, 8)}
    n = recalibrate_bn(c, X, down, batch=16)
    assert n == len(down)
    after = c.mods[c.nodes[up].pkey].state_dict()
    assert all(torch.equal(before[k], after[k]) for k in before)
