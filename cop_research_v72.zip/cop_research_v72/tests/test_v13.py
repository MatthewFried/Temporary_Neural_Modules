"""v13 regressions for the v12 audit (CoP_v12_Audit_and_v13_Claude_Handoff).

A1 (identity gate) is in tests/test_v8_audit.py (section "v13: identity gate").  This file holds A2 (baseline
cost ledger) and the v13 additions that follow it."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests"))

import tiny_configs as T  # noqa: E402
from cop.config import resolve, run_id  # noqa: E402
from cop.experiments.continuation import baseline_cost, inline_f0_cost, run_work  # noqa: E402
from cop.orchestration.runner import run_job, status_of  # noqa: E402
from cop.utils import read_json  # noqa: E402

CUDA = pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA device required (run scripts/12 on the GPU)")


def _run(cfgs, d, device="cpu"):
    st = [run_job(c, d, {"device": device}) for c in cfgs]
    assert st[-1] == "complete", status_of(d, run_id(cfgs[-1])).get("reason")
    return d / "runs" / run_id(cfgs[-1])


def _ck_state(rd, stage="baseline"):
    return torch.load(rd / "ckpt" / f"{stage}.pt", map_location="cpu", weights_only=False)["trainer"]["state"]


# ----------------------------------------------------------------------------- A2: baseline cost

def test_trained_baseline_reports_its_checkpoint_work(tmp_path):
    """The audit's probe: a 5-update baseline whose checkpoint records positive MACs was reported as zero."""
    cfg = resolve({"kind": "baseline", "data": {"name": "teacher", "n_train": 64, "n_val": 32, "n_test": 32,
                                                 "params": {"teacher_depth": 1, "d_in": 4, "out_dim": 2,
                                                            "task": "regression"}},
                   "model": {"family": "mlp", "width": 8, "depth": 2},
                   "train": {"baseline_updates": 5, "batch_size": 16, "eval_every": 5}, "seeds": {"optimizer": 0}})
    rd = _run([cfg], tmp_path)
    st = _ck_state(rd)
    w = run_work(rd)
    assert st["global_step"] == 5 and st["train_macs"] > 0
    assert w["updates"] == 5 and w["macs"] == st["train_macs"] and w["macs_complete"]
    b = baseline_cost(rd)
    assert b["provenance"] == "ledger" and b["macs"] == st["train_macs"]


def test_zero_update_baseline_is_zero_and_complete(tmp_path):
    rd = _run([T.base(train={**T.TRAIN, "baseline_updates": 0})], tmp_path)
    w = run_work(rd)
    assert w["updates"] == 0 and w["macs"] == 0 and w["macs_complete"]


def test_resumed_baseline_counts_its_work_once(tmp_path):
    from resume_harness import compare_interrupted
    cfg = T.base()
    rep = compare_interrupted([cfg], tmp_path)
    assert rep["interrupted_at_polls"], rep
    wa, wb = run_work(tmp_path / "A" / "runs" / run_id(cfg)), run_work(tmp_path / "B" / "runs" / run_id(cfg))
    assert wa["updates"] == wb["updates"] == T.TRAIN["baseline_updates"]
    assert wa["macs"] == wb["macs"] > 0 and wa["examples"] == wb["examples"]


def test_historical_baseline_without_ledger_uses_checkpoint_counters_or_is_incomplete(tmp_path):
    rd = _run([T.base()], tmp_path)
    sm = read_json(rd / "summary.json")
    sm["work"] = {}                                           # what v12 and earlier wrote
    (rd / "summary.json").write_text(json.dumps(sm))
    b = baseline_cost(rd)
    st = _ck_state(rd)
    assert b["provenance"].startswith("checkpoint_counters") and b["macs"] == st["train_macs"] and b["macs_complete"]
    assert run_work(rd)["macs"] == st["train_macs"]
    (rd / "ckpt" / "baseline.pt").unlink()
    b = baseline_cost(rd)
    assert b["provenance"].startswith("missing") and b["macs_complete"] is False
    assert run_work(rd)["macs_complete"] is False


def test_inline_and_external_f0_costs(tmp_path):
    from cop.analysis.strengthening import f0_cost
    from cop.analysis.summarize import load_runs
    ext = T.traj({"topology": "layered", "rounds": 1}, with_fc=False)
    rd_ext = _run(ext, tmp_path / "ext")
    runs = load_runs(tmp_path / "ext")
    fc = f0_cost(runs, run_id(ext[-1]))
    assert fc["f0_run"] == run_id(ext[0]) and fc["provenance"] == "ledger"
    assert fc["updates"] == T.TRAIN["baseline_updates"] and inline_f0_cost(rd_ext) is None
    inl = dict(ext[-1])
    inl = resolve({k: v for k, v in inl.items() if k != "parents"} | {"parents": {}})
    rd_in = _run([inl], tmp_path / "inl")
    w = inline_f0_cost(rd_in)
    assert w["provenance"] == "inline baseline_ref counters" and w["updates"] == T.TRAIN["baseline_updates"]
    fc2 = f0_cost(load_runs(tmp_path / "inl"), run_id(inl))
    assert fc2["f0_run"] == f"inline:{run_id(inl)}" and fc2["macs"] == w["macs"] > 0
    # the trajectory's own (post-f0) work does not include the inline f0
    assert run_work(rd_in)["updates"] == run_work(rd_ext)["updates"]


def test_matched_endpoint_total_cost_counts_baseline_once_and_budget_is_unchanged(tmp_path):
    from cop.analysis.strengthening import endpoint_table, compact_gain
    from cop.analysis.summarize import load_runs
    from test_v4_audit import _with_design
    b, c = T.cop({}, {"dim": 4, "mode": "uniform", "bits": 2})
    c = _with_design(c)
    m1 = _with_design(resolve({"kind": "continue", "data": c["data"], "model": c["model"], "train": c["train"],
                               "seeds": {"optimizer": 0}, "parents": {"baseline": run_id(b), "treated": run_id(c)},
                               "continue": {"start": "treated", "start_stage": "export", "reinit": True,
                                            "budget": "parent_updates", "budget_parent": "treated",
                                            "budget_add_f0": True}}), "M1", panel="updates")
    for x in (b, c, m1):
        _run([x], tmp_path)
    rb = tmp_path / "runs" / run_id(b)
    f0_macs = _ck_state(rb)["train_macs"]
    # the budget allocation reads the baseline checkpoint itself (audit: allocation is a separate path)
    bj = read_json(tmp_path / "runs" / run_id(m1) / "budget.json")
    assert bj["parent_chain_work"]["f0_added"] == {"updates": T.TRAIN["baseline_updates"], "macs": f0_macs}
    E = endpoint_table(load_runs(tmp_path))
    q = [p for p in compact_gain(E, estimand="matched_endpoint")[1] if p["control_arm"] == "M1"][0]
    assert q["treated_baseline_macs"] == f0_macs and q["control_baseline_macs"] == 0
    assert q["treated_total_procedure_macs"] == q["treated_macs_incl_teacher"] + f0_macs
    assert q["treated_cost_matched"] == q["treated_total_procedure_macs"]
    assert q["control_total_procedure_macs"] == q["control_macs_incl_teacher"]
    assert q["total_procedure_complete"] in (True, False) and q["f0_cost_provenance"] == "ledger"


# ----------------------------------------------------------------------------- C2: validation selection

SEL_TRAIN = {**T.TRAIN, "select_candidates": 4}


def _sel_chain(tmp_path):
    p = T.traj({"topology": "layered", "rounds": 1}, train=SEL_TRAIN, with_fc=False)
    d = T.child("dissipation", p[-1], {"dissipation": {"method": "linear", "speed_updates": 6, "post_updates": 8}})
    c1 = resolve({"kind": "continue", "data": p[0]["data"], "model": p[0]["model"], "train": SEL_TRAIN,
                  "seeds": {"optimizer": 0}, "parents": {"baseline": run_id(p[0]), "treated": run_id(d)},
                  "continue": {"budget": "parent_updates", "budget_parent": "treated"}})
    for c in p + [d, c1]:
        _run([c], tmp_path)
    return p, d, c1


def test_selection_keeps_the_fixed_endpoint_and_selects_only_compact_states_by_validation(tmp_path):
    from cop.train.trainer import evaluate
    from cop.graph.graph import GraphNet
    from cop.data.registry import load_bundle
    p, d, c1 = _sel_chain(tmp_path)
    for cfg, fixed in ((p[0], "baseline"), (d, "export"), (c1, "final")):
        rd = tmp_path / "runs" / run_id(cfg)
        sel = read_json(rd / "selection.json")
        ep, eb = read_json(rd / "endpoint.json"), read_json(rd / "endpoint_best_val.json")
        assert ep["checkpoint"] == fixed and eb["checkpoint"] == "best_val"        # both records exist
        assert len(sel["candidates"]) == 4 and eb["n_candidates"] == 4
        best = min(sel["candidates"], key=lambda c: (c["risk"], c["global_step"]))
        assert sel["best"]["global_step"] == best["global_step"]
        # the selected checkpoint reproduces its recorded validation risk
        ck = torch.load(rd / "ckpt" / "best_val.pt", map_location="cpu", weights_only=False)
        g = GraphNet.from_checkpoint(ck["model"], "cpu")
        b = load_bundle(cfg["data"], device="cpu")
        r = evaluate(g, b, ["val"], 4096)[0]["val"]
        assert r["mse"] == pytest.approx(best["risk"], rel=1e-12)
        assert eb["architecture_hash"] == ep["architecture_hash"]
    # dissipation: every candidate comes after the physical removal (no expanded state is a candidate)
    rd = tmp_path / "runs" / run_id(d)
    removed_at = [q["update"] for q in read_json(rd / "dissipation_result.json")["path"]
                  if q["tag"].startswith("physically_removed")][-1]
    # the dissipation trainer counts its own updates from 0, the same index as the path
    assert all(c["global_step"] > removed_at for c in read_json(rd / "selection.json")["candidates"])


def test_selection_partition_must_be_validation():
    from cop.config import ConfigError
    for bad in ("test", "shift", "rare", "train"):
        with pytest.raises(ConfigError):
            T.base(train={**T.TRAIN, "select_candidates": 2, "select_partition": bad})


def test_selection_survives_interruption_identically(tmp_path):
    from resume_harness import compare_interrupted
    p = T.traj({"topology": "layered", "rounds": 1}, train=SEL_TRAIN, with_fc=False)
    c1 = resolve({"kind": "continue", "data": p[0]["data"], "model": p[0]["model"], "train": SEL_TRAIN,
                  "seeds": {"optimizer": 0}, "parents": {"baseline": run_id(p[0])},
                  "continue": {"budget": "fixed", "updates": 40}})
    rep = compare_interrupted([p[0], c1], tmp_path)
    assert rep["interrupted_at_polls"] and rep["equal"], rep
    a = read_json(tmp_path / "A" / "runs" / run_id(c1) / "selection.json")
    b = read_json(tmp_path / "B" / "runs" / run_id(c1) / "selection.json")
    assert a == b and a["best"] is not None
    ha = torch.load(tmp_path / "A" / "runs" / run_id(c1) / "ckpt" / "best_val.pt", weights_only=False)["lineage"]
    hb = torch.load(tmp_path / "B" / "runs" / run_id(c1) / "ckpt" / "best_val.pt", weights_only=False)["lineage"]
    assert ha["param_hash"] == hb["param_hash"]


def test_selected_gain_is_symmetric_about_f0_and_requires_equal_opportunities():
    from cop.analysis.strengthening import selected_gain
    base = {"eligible": True, "sel_available": True, "architecture_hash": "A", "sel_architecture_hash": "A",
            "design_contrast": "k", "f0_run": "f0", "f0_stage": "baseline", "replication": "r", "compact": True,
            "f0_architecture_hash": "A", "status": "complete", "validity": "valid", "data": "d", "model": "m",
            "data_identity": "d", "model_identity": "m", "task": "regression", "design_budget_panel": "updates",
            "f0_sel_val_risk": 0.5, "f0_sel_test_risk": 0.55, "sel_n_candidates": 4}
    t = dict(base, run_id="t", design_arm="treated", sel_val_risk=0.6, sel_test_risk=0.6, kind="dissipation")
    c = dict(base, run_id="c", design_arm="C1", sel_val_risk=0.4, sel_test_risk=0.45, kind="continue")
    for e in (t, c):
        e["test_risk"] = 9.9                                    # the fixed-budget value must not be used
    s, q = selected_gain([t, c], "test_risk", "fixed_architecture", f0_fallback=True)
    p1 = [x for x in q if x["control_arm"] == "C1"][0]
    assert p1["treated_selected_f0"] is True and p1["control_selected_f0"] is False
    assert p1["treated_risk"] == 0.55 and p1["control_risk"] == 0.45
    s, q = selected_gain([t, c], "test_risk", "fixed_architecture", f0_fallback=False)
    p2 = [x for x in q if x["control_arm"] == "C1"][0]
    assert p2["treated_risk"] == 0.6 and not p2["treated_selected_f0"]
    rej = []
    s, q = selected_gain([t, dict(c, sel_n_candidates=8)], "test_risk", "fixed_architecture", False, rej)
    assert not [x for x in q if x["control_arm"] == "C1"] and any("opportunities" in r["reason"] for r in rej)


# ----------------------------------------------------------------------------- D1: specialization partitions

SHORT = {"name": "shortcut", "n_train": 256, "n_val": 128, "n_test": 128, "params": {"rho_train": 0.9}}


def _bundle(data=SHORT):
    from cop.data.registry import load_bundle
    return load_bundle(data, device="cpu")


def test_spec_partitions_use_only_their_declared_information():
    from cop.experiments.trajectory import _spec_split, spec_access_record
    b = _bundle()
    tr = b.train
    assert tr.groups is not None
    g = _spec_split(tr, b, "group")
    assert torch.equal(g, tr.groups == 0)
    lab = _spec_split(tr, b, "observed_label")
    assert torch.equal(lab, tr.y < b.out_dim // 2)
    # observed_label never consults group ids: scrambling them changes nothing
    from cop.data.bundle import Partition
    scr = Partition(tr.X, tr.y, tr.y_clean, tr.groups.flip(0), dict(tr.aux), dict(tr.meta))
    assert torch.equal(_spec_split(scr, b, "observed_label"), lab)
    rg, rl = spec_access_record(b, "group"), spec_access_record(b, "observed_label")
    assert rg["uses_group_ids"] and not rg["uses_labels"] and not rg["group_ids_at_inference"]
    assert rl["uses_labels"] and not rl["uses_group_ids"]
    assert rg["branch_a"]["n"] + rg["branch_b"]["n"] == len(tr)
    assert rg["gradient_coverage"]["branch_a"] == pytest.approx(float((tr.groups == 0).float().mean()))


def _spec_traj(tmp_path, mode, rounds=1):
    data = dict(SHORT)
    p = T.traj({"topology": "specialized", "specialize": "class_halves", "spec_partition": mode, "rounds": rounds},
               data=data, with_fc=False)
    for c in p:
        _run([c], tmp_path)
    return p, tmp_path / "runs" / run_id(p[-1])


def test_random_matched_partition_matches_group_proportion_and_is_saved(tmp_path):
    p, rd = _spec_traj(tmp_path, "random_matched")
    b = _bundle()
    ind = torch.load(rd / "spec_partition.pt")
    assert int(ind.sum()) == int(round(float((b.train.groups == 0).float().mean()) * len(b.train)))
    acc = read_json(rd / "specialization_access.json")
    assert acc["uses_random_partition"] and not acc["uses_group_ids"] and not acc["uses_labels"]
    # the random partition is not the group partition
    assert not torch.equal(ind.bool(), b.train.groups == 0)


@pytest.mark.parametrize("mode", ["group", "observed_label", "random_matched"])
def test_group_metadata_cannot_change_predictions(tmp_path, mode):
    p, rd = _spec_traj(tmp_path, mode)
    gi = read_json(rd / "summary.json")["result"]["group_inference_check"]
    assert gi["predictions_identical_under_permuted_groups"] is True and gi["n"] == 128


def test_shortcut_has_separate_validation_environments_and_selection_may_use_them():
    b = _bundle()
    hs = b.hashes()
    for v in ("val_indep", "val_reversed", "val_rare"):
        assert v in b.extra and len(b.extra[v]) > 0
        assert hs.get(v) not in (hs.get("test"), hs.get("val"))
    assert bool((b.extra["val_rare"].groups == 1).all())
    resolve(T.base(data=SHORT, train={**T.TRAIN, "select_candidates": 2, "select_partition": "val_indep"}))


# ----------------------------------------------------------------------------- v13 manifests

def _w13(wave=13):
    from cop.orchestration.manifest import Builder, WAVES
    B = Builder("smoke")
    WAVES[wave](B)
    return B


def test_wave13_info_access_budget_and_shared_selected_f0():
    B = _w13()
    E = B.entries
    by_mode = defaultdict_list()
    for e in E.values():
        c = e["cfg"]
        assert "info_access" in e and "budget" in e
        if c["kind"] in ("continue", "dissipation", "repair", "baseline"):
            assert c["train"]["select_candidates"] == 8 and c["train"]["select_partition"] == "val"
        if c["kind"] == "trajectory":
            by_mode[(c["growth"]["topology"], c["growth"].get("spec_partition"), c["train"].get("sampler"))].append(e)
            assert c["tags"]["f0_stage"] == "best_val"
        if c["kind"] == "continue":
            assert c["continue"]["start_stage"] in ("best_val", "export")
    ia = {k: v[0]["info_access"] for k, v in by_mode.items()}
    assert ia[("specialized", "group", "uniform")]["group_ids_for_routing"]
    assert ia[("specialized", "group", "group_balanced")]["group_ids_for_sampling"]
    assert ia[("specialized", "observed_label", "uniform")]["labels_for_routing"]
    assert ia[("specialized", "random_matched", "uniform")]["random_partition_for_routing"]
    assert not any(x["group_ids_for_routing"] for k, x in ia.items() if k[0] == "parallel")
    assert not any(x["group_ids_at_inference"] for x in ia.values())
    # paired arms of one contrast share one baseline checkpoint
    by_c = defaultdict_list()
    for e in E.values():
        d = e["cfg"].get("design") or {}
        if d.get("contrast"):
            by_c[d["contrast"]].append(e)

    def base_of(e):
        par = e["cfg"].get("parents") or {}
        if "baseline" in par:
            return par["baseline"]
        return base_of(E[par["trajectory"]])
    for k, es in by_c.items():
        assert len({base_of(e) for e in es}) == 1, k
    # removal protocols are budget matched (removal + repair = the treated total) except the declared short one
    for e in E.values():
        c = e["cfg"]
        if c["kind"] == "dissipation" and c["design"]["family"] == "X4r":
            dc, arm = c["dissipation"], c["design"]["arm"]
            if arm in ("treated", "treated_lr0.3", "removal_abrupt_repair", "removal_slow_repair_short"):
                tot = dc["speed_updates"] + dc["post_updates"]
                ref = [x for x in E.values() if x["cfg"]["kind"] == "dissipation" and
                       x["cfg"]["design"]["contrast"] == c["design"]["contrast"] and x["cfg"]["design"]["arm"] == "treated"]
                r = ref[0]["cfg"]["dissipation"]
                assert tot == r["speed_updates"] + r["post_updates"]


def test_wave14_separates_optimizer_seeds_from_data_draws():
    from cop.orchestration.wave13 import confirmation_reps
    reps = confirmation_reps()
    draws = {d for d, _ in reps}
    assert len(draws) >= 5 and 0 not in draws
    assert any(o != 0 for _, o in reps)
    for d in {d for d, o in reps if o != 0}:
        assert (d, 0) in reps                    # crossed: the same draw under several optimizer seeds
    B = _w13(14)
    seen = {(e["cfg"]["data"]["data_seed"], e["cfg"]["seeds"]["optimizer"]) for e in B.entries.values()
            if e["cfg"]["kind"] == "baseline"}
    assert seen == set(reps)


def defaultdict_list():
    from collections import defaultdict
    return defaultdict(list)


# ----------------------------------------------------------------------------- D2/D3: MAC matching, decoder refit

DQ3 = {"name": "delayed_query", "n_train": "full", "params": {"n_bits": 3, "split_mode": "complete"}}
DQ_MODEL = {"family": "mlp", "width": 16, "depth": 3, "query_at_layer": 1}
FINC = {"task_kind": "chain", "n_pearls": 2, "global_updates": 30, "decoder_refit_updates": 10}
FINP = {"dim": 2, "mode": "uniform", "bits": 1}


def test_finite_code_mac_matching_reaches_the_reference_and_decoder_refit_keeps_the_code(tmp_path):
    # selection on (as in the manifests): its evaluation work must not enter the MAC match
    b, ref = T.cop(FINC, {**FINP, "temp_channel": 4, "temp_open_updates": 5}, data=DQ3, model=DQ_MODEL,
                   train={**T.TRAIN, "select_candidates": 3})
    _run([b, ref], tmp_path)
    m = resolve({**ref, "peg": {**ref["peg"], "temp_channel": 0, "temp_open_updates": 0},
                 "cop": {**ref["cop"], "global_match_macs_of": "mac_reference"},
                 "parents": {**ref["parents"], "mac_reference": run_id(ref)}})
    rd = _run([m], tmp_path)
    res = read_json(rd / "cop_chain_result.json")
    mm = res["mac_matching"]
    assert mm["planned_global_updates"] != mm["declared_global_updates"]
    # one update of granularity: within one update's MACs of the reference
    assert abs(mm["achieved_macs_before_export"] - mm["reference_macs"]) <= mm["macs_per_update"]
    dr = res["decoder_refit"]
    fi = res["finite_interface"]
    assert dr["code_unchanged"] and dr["updates"] == 10
    assert dr["before"]["e_oracle"] == dr["after"]["e_oracle"] == fi["e_oracle"]       # frozen code: oracle fixed
    assert dr["before"]["e_model"] == fi["e_model"] and dr["after"]["e_model"] >= dr["after"]["e_oracle"]
    w = read_json(rd / "summary.json")["work"]
    assert w["diagnostic:decoder_refit"]["updates"] == 10                              # charged as diagnostic work
    assert any(k.startswith("search:") for k in w) and run_work(rd)["macs"] == mm["achieved_macs_before_export"]


def test_removal_mac_matching_reaches_the_reference(tmp_path):
    p = T.traj({"topology": "layered", "rounds": 1}, with_fc=False)
    ref = T.child("dissipation", p[-1], {"dissipation": {"method": "linear", "speed_updates": 6, "post_updates": 10}})
    for c in p + [ref]:
        _run([c], tmp_path)
    m = resolve({**ref, "dissipation": {**ref["dissipation"], "method": "abrupt", "speed_updates": 0, "post_updates": 1,
                                        "post_match_macs_of": "mac_reference"},
                 "parents": {**ref["parents"], "mac_reference": run_id(ref)}})
    rd = _run([m], tmp_path)
    mm = read_json(rd / "summary.json")["result"]["mac_matching"]
    w = run_work(rd)
    assert abs(w["macs"] - mm["reference_macs"]) <= mm["macs_per_update"], (w, mm)


# ----------------------------------------------------------------------------- D4: locality controls

def test_locality_positive_controls_hold(tmp_path):
    cfgs = T.cop({"task_kind": "locality", "n_pearls": 3, "global_updates": 20, "local_updates": 5,
                  "locality_repair_updates": 5, "locality_eval_points": 2, "locality_interface": "finite_learned",
                  "locality_controls": True}, {"dim": 2, "mode": "uniform", "bits": 1})
    res = read_json(_run(cfgs, tmp_path) / "locality_result.json")
    for s in res["snapshots"]:
        c = s["controls"]
        ex = c["exact_local_replacement"]
        assert ex["matches_reference"] and ex["certificate"]["applicable"] and ex["certificate"]["all_equal"]
        fc = c["frozen_code_lookup"]
        assert fc["applicable"] and fc["n_codes"] == 4 and fc["matches_reference"]
        # the lookup acts on the network WITH the fitted replacement, whose own risk differs from the reference
        assert fc["replacement_risk_without_lookup"]["val"] != s["reference"]["val"]
        cm = c["representation_match_scope1"]
        assert cm["updates"] == 5 and set(cm["success"]) == set(s["tolerances"])
        assert "censored" in s["censoring_note"]


# ----------------------------------------------------------------------------- M_E: controls get later queries

def test_matched_direct_controls_record_later_query_retention(tmp_path):
    LQ = {"name": "later_query", "n_train": 32, "n_val": 16, "n_test": 16, "params": {"n_bits": 6, "task_bits": 1}}
    b, t = T.cop({"task_kind": "chain", "n_pearls": 3}, {"dim": 4, "mode": "uniform", "bits": 2}, data=LQ)
    _run([b, t], tmp_path)
    m = resolve({"kind": "continue", "data": LQ, "model": t["model"], "train": t["train"], "seeds": {"optimizer": 0},
                 "parents": {"baseline": run_id(b), "treated": run_id(t)},
                 "continue": {"start": "treated", "start_stage": "export", "reinit": True, "budget": "parent_updates",
                              "budget_parent": "treated", "budget_add_f0": True}})
    rd = _run([m], tmp_path)
    tr = read_json(tmp_path / "runs" / run_id(t) / "cop_chain_result.json")["later_queries"]
    cr = read_json(rd / "summary.json")["result"]
    lq = cr["later_queries"]
    assert lq["queries"] == tr["queries"] and set(lq["pegs"]) == set(tr["pegs"])    # same queries, same pegs
    assert lq["chance"] == tr["chance"]                                              # same evaluation rows
    au = cr["reinit"]
    assert au["unchanged_after_reset"] == [] and au["quantizers_at_start"]      # every trained tensor was reset


# ----------------------------------------------------------------------------- Phase 0.2: numeric validity

def test_numeric_validity_separates_sources_descendants_and_multi_model_jobs(tmp_path):
    from cop.analysis.summarize import numeric_validity
    from cop.utils import atomic_write_json
    runs = {}
    for rid, par, kind, valid in (("a", {}, "baseline", True), ("b", {"baseline": "a"}, "trajectory", False),
                                  ("c", {"trajectory": "b"}, "dissipation", True), ("d", {"baseline": "a"}, "cop", True)):
        d = tmp_path / "runs" / rid
        d.mkdir(parents=True)
        atomic_write_json(d / "endpoint.json", {"numerically_valid": valid, "numerical_reasons": None if valid else ["x"]})
        cfg = {"kind": kind, "parents": par}
        if rid == "d":
            cfg["cop"] = {"task_kind": "locality"}
        runs[rid] = {"dir": d, "cfg": cfg}
    nv = numeric_validity(tmp_path, runs)
    assert set(nv["own_endpoint_numerically_invalid"]["runs"]) == {"b"}
    assert nv["descendants_of_numerically_invalid_sources"]["runs"] == {"c": "b"}
    assert nv["multi_model_jobs_without_single_endpoint"]["runs"] == ["d"]


def test_cop_chain_selects_only_exported_endpoint_states_with_equal_opportunities(tmp_path):
    from cop.graph.graph import GraphNet
    from cop.graph.accounting import architecture_hash
    b, c = T.cop({"task_kind": "chain", "n_pearls": 3}, train={**T.TRAIN, "select_candidates": 4})
    rd = _run([b, c], tmp_path)
    sel = read_json(rd / "selection.json")
    ep, eb = read_json(rd / "endpoint.json"), read_json(rd / "endpoint_best_val.json")
    assert sel["phase"] == "chain_endpoint" and len(sel["candidates"]) == 4 and eb["n_candidates"] == 4
    assert ep["checkpoint"] == "export" and eb["architecture_hash"] == ep["architecture_hash"]
    gx = GraphNet.from_checkpoint(torch.load(rd / "ckpt" / "best_val.pt", weights_only=False)["model"], "cpu")
    assert not any(n.op == "gate_mix" for n in gx.nodes.values())            # an exported (compact) state
    assert sel["candidates"][-1]["global_step"] == read_json(rd / "summary.json")["work"]["chain_train:cop"]["updates"]


# ----------------------------------------------------------------------------- CUDA (run on the GPU machine)

@CUDA
def test_cuda_v13_jobs(tmp_path):
    """The v13 paths on the GPU: baseline ledger, selection (baseline, dissipation, chain), random-matched
    specialization with the inference check, MAC-matched removal and the finite-code decoder refit."""
    b = T.base(train={**T.TRAIN, "select_candidates": 3})
    rd = _run([b], tmp_path, "cuda")
    st = _ck_state(rd)
    assert run_work(rd)["macs"] == st["train_macs"] > 0 and baseline_cost(rd)["provenance"] == "ledger"
    assert read_json(rd / "endpoint_best_val.json")["n_candidates"] == 3
    p, srd = None, None
    p = T.traj({"topology": "specialized", "specialize": "class_halves", "spec_partition": "random_matched",
                "rounds": 1}, data=SHORT, with_fc=False)
    for c in p:
        _run([c], tmp_path, "cuda")
    srd = tmp_path / "runs" / run_id(p[-1])
    gi = read_json(srd / "summary.json")["result"]["group_inference_check"]
    assert gi["predictions_identical_under_permuted_groups"]
    ref = T.child("dissipation", p[-1], {"dissipation": {"method": "linear", "speed_updates": 4, "post_updates": 6}})
    _run([ref], tmp_path, "cuda")
    m = resolve({**ref, "dissipation": {**ref["dissipation"], "method": "abrupt", "speed_updates": 0,
                                        "post_updates": 1, "post_match_macs_of": "mac_reference"},
                 "parents": {**ref["parents"], "mac_reference": run_id(ref)}})
    mrd = _run([m], tmp_path, "cuda")
    mm = read_json(mrd / "summary.json")["result"]["mac_matching"]
    assert abs(run_work(mrd)["macs"] - mm["reference_macs"]) <= mm["macs_per_update"]
    fb, fc = T.cop(FINC, FINP, data=DQ3, model=DQ_MODEL, train={**T.TRAIN, "select_candidates": 3})
    frd = _run([fb, fc], tmp_path, "cuda")
    res = read_json(frd / "cop_chain_result.json")
    assert res["decoder_refit"]["code_unchanged"]
    assert read_json(frd / "selection.json")["phase"] == "chain_endpoint"


# ----------------------------------------------------------------------------- review fixes

def test_selection_evaluations_are_charged_as_search_work_not_training(tmp_path):
    from cop.experiments.continuation import search_work
    p, d, c1 = _sel_chain(tmp_path)
    for cfg in (p[0], d, c1):
        rd = tmp_path / "runs" / run_id(cfg)
        sel = read_json(rd / "selection.json")
        sw = search_work(rd)
        assert sw["macs"] == sum(c["eval_macs"] for c in sel["candidates"]) > 0
        assert sw["forward_examples"] == sum(c["eval_examples"] for c in sel["candidates"])
        w = read_json(rd / "summary.json")["work"]
        assert run_work(rd)["macs"] == sum(v["macs"] for k, v in w.items()
                                           if not k.startswith(("search:", "diagnostic:"))) or cfg is p[0]


def test_fixed_c0_is_the_f0_state_the_chain_started_from(tmp_path):
    from cop.analysis.strengthening import endpoint_table
    from cop.analysis.summarize import load_runs
    b = T.base(train={**T.TRAIN, "select_candidates": 4})
    t = resolve({"kind": "trajectory", "data": b["data"], "model": b["model"], "train": b["train"],
                 "growth": {"topology": "layered", "rounds": 1, "updates_per_round": 15, "width": 8},
                 "seeds": {"optimizer": 0}, "parents": {"baseline": run_id(b)}, "tags": {"f0_stage": "best_val"},
                 "design": {"family": "X", "variant": "v", "arm": "treated", "contrast": "k"}})
    d = T.child("dissipation", t, {"dissipation": {"method": "linear", "speed_updates": 4, "post_updates": 6},
                                   "design": {"family": "X", "variant": "v", "arm": "treated", "contrast": "k"}})
    for c in (b, t, d):
        _run([c], tmp_path)
    E = {e["run_id"]: e for e in endpoint_table(load_runs(tmp_path))}
    e = E[run_id(d)]
    assert e["f0_stage"] == "best_val"
    assert e["f0_test_risk"] == pytest.approx(e["f0_sel_test_risk"])     # C0 = the selected f0, not the final one


def test_from_scratch_history_is_not_charged_baseline_cost():
    from cop.analysis.strengthening import _from_scratch_history
    runs = {"b": {"cfg": {"kind": "baseline", "parents": {}}},
            "t": {"cfg": {"kind": "trajectory", "growth": {"schedule": "from_scratch"}, "parents": {"baseline": "b"}}},
            "u": {"cfg": {"kind": "trajectory", "growth": {"schedule": "incremental"}, "parents": {"baseline": "b"}}},
            "d": {"cfg": {"kind": "dissipation", "parents": {"trajectory": "t"}}},
            "c": {"cfg": {"kind": "continue", "continue": {"start": "baseline"}, "parents": {"baseline": "b", "treated": "d"}}}}
    assert _from_scratch_history(runs, "t") and _from_scratch_history(runs, "d")
    assert not _from_scratch_history(runs, "u") and not _from_scratch_history(runs, "c")


def test_identity_gate_a_real_change_is_never_reported_as_low_scale():
    from cop.experiments import common as Cm
    from cop.graph.builders import build_mlp
    from cop.utils import torch_gen
    g = build_mlp(8, [16, 16], 3, torch_gen(0, "init"))
    X = {"cal": {"x": torch.randn(64, 8, generator=torch.Generator().manual_seed(0))}, "tiny": {"x": torch.zeros(4, 8)}}
    z = g.clone(share_params=False)
    head = [n for n in z.topo_order() if z.nodes[n].role == "head"][0]
    with torch.no_grad():
        z.mods[z.nodes[head].pkey].weight.zero_()
        z.mods[z.nodes[head].pkey].bias.zero_()                              # pre outputs exactly zero
    moved = z.clone(share_params=False)
    with torch.no_grad():
        moved.mods[moved.nodes[head].pkey].bias.fill_(5.0)                   # post outputs 5: a real change
    chk = Cm.identity_check(z, moved, {"cal": X["cal"]}, torch.float32, {"criteria": {
        "identity_rel_tol_fp64": 1e-10, "identity_rel_tol_fp32": 1e-5}})
    assert chk["verdict"] == "changed"
    h = g.clone(share_params=False)
    with torch.no_grad():
        next(p for n, p in h.named_parameters() if n.endswith("weight")).add_(1e-2)
    zs = {"cal": X["cal"], "tiny": {"x": torch.zeros(4, 8)}}
    g2, h2 = g.clone(share_params=False), h.clone(share_params=False)
    for m in (g2, h2):                                                       # a near-zero-output set alongside
        hd = [n for n in m.topo_order() if m.nodes[n].role == "head"][0]
        with torch.no_grad():
            m.mods[m.nodes[hd].pkey].bias.zero_()
    chk = Cm.identity_check(g2, h2, zs, torch.float32, {"criteria": {
        "identity_rel_tol_fp64": 1e-10, "identity_rel_tol_fp32": 1e-5}})
    assert chk["sets"]["cal"]["verdict"] == "changed" and chk["verdict"] == "changed"


def test_every_wave13_contrast_has_one_f0_state():
    from cop.analysis.strengthening import _f0_run, _f0_stage
    from collections import defaultdict
    for w in (13, 14):
        B = _w13(w)
        runs = {rid: {"cfg": e["cfg"]} for rid, e in B.entries.items()}
        by = defaultdict(set)
        for rid, e in B.entries.items():
            d = e["cfg"].get("design") or {}
            if d.get("contrast"):
                rk = (e["cfg"]["data"]["data_seed"], e["cfg"]["seeds"]["optimizer"])
                by[(d["contrast"], rk)].add((_f0_run(runs, rid), _f0_stage(runs, rid)))
        bad = {k: v for k, v in by.items() if len(v) != 1}
        assert not bad, list(bad.items())[:3]
