"""v15 regressions for the v14 review (CoP_v15_review_and_Claude_instructions): pairing by replication, the
removal-path export, draw-level summaries, finite-peg recipes, partition dynamics, the frozen-weight sweep and the
separate locality outcomes.  The launcher tests are in tests/test_v15_launcher.py."""
from __future__ import annotations

import itertools
import sys
from pathlib import Path

import pytest
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests"))

import tiny_configs as T  # noqa: E402
from cop.config import resolve, run_id  # noqa: E402
from cop.orchestration.runner import run_job, status_of  # noqa: E402
from cop.utils import read_json  # noqa: E402


def _run(cfgs, d, device="cpu"):
    st = [run_job(c, d, {"device": device}) for c in cfgs]
    assert st[-1] == "complete", status_of(d, run_id(cfgs[-1])).get("reason")
    return d / "runs" / run_id(cfgs[-1])


# ----------------------------------------------------------------------------- P0.1 pairing by replication

def _lq_row(seed, arm, acc=0.7, opt=0, arch="A"):
    return dict(family="M_Er", contrast="cell", arm=arm, replication=f"data{seed}_teacher{seed}_opt{opt}",
                f0_run=f"f0_{seed}", f0_stage="best_val", endpoint_policy="fixed", architecture_hash=arch,
                run_id=f"{arm}_{seed}_{opt}", test_risk=0.1, test_err=0.0, readout_I1_test_acc=acc,
                data_draw=seed, optimizer_seed=opt)


def test_later_query_pairs_stay_within_their_replication_under_every_ordering():
    from cop.analysis.v13_tables import later_query_retention
    rows = [_lq_row(101, "treated"), _lq_row(101, "M1"), _lq_row(102, "treated"), _lq_row(102, "M1")]
    for perm in itertools.permutations(rows):
        out = later_query_retention(list(perm))
        assert len(out) == 2
        for r in out:
            assert r["treated_run"].split("_")[1] == r["control_run"].split("_")[1]


def test_later_query_missing_or_duplicate_arms_never_cross_replications():
    from cop.analysis.v13_tables import later_query_retention
    rej = []
    out = later_query_retention([_lq_row(101, "treated"), _lq_row(102, "M1")], rej)
    assert out == [] and any("missing treated" in r["reason"] for r in rej)
    rej = []
    out = later_query_retention([_lq_row(101, "treated"), _lq_row(101, "M1"), _lq_row(101, "M1", acc=0.5)], rej)
    assert out == [] and any("2 rows" in r["reason"] for r in rej)
    rej = []
    out = later_query_retention([_lq_row(101, "treated"), _lq_row(101, "M1", arch="B")], rej)
    assert out == [] and any("architecture" in r["reason"] for r in rej)
    out = later_query_retention([_lq_row(101, "treated"), _lq_row(101, "treated_lr0.3")])
    assert out[0]["comparison"] == "treatment_variant"


def _entry(rid, arm, rep, risk, val, contrast="k", arch="A", panel="updates"):
    return {"run_id": rid, "design_contrast": contrast, "design_arm": arm, "replication": rep, "f0_run": "f0",
            "f0_stage": "best_val", "design_budget_panel": panel, "architecture_hash": arch, "status": "complete",
            "validity": "valid", "eligible": True, "test_risk": risk, "val_risk": val, "design_family": "F",
            "design_variant": "v", "total_procedure_macs": 100, "baseline_macs": 40, "compact": True,
            "f0_architecture_hash": "A", "kind": "cop", "data": "d", "model": "m", "data_identity": "d",
            "model_identity": "m", "task": "regression"}


def test_tuned_pairs_are_per_replication_and_duplicates_are_rejected():
    from cop.analysis.v13_tables import tuned_gain
    E = []
    for rep in ("data101_teacher101_opt0", "data102_teacher102_opt0"):
        E += [_entry(f"t_{rep}", "treated", rep, 0.3, 0.30), _entry(f"t3_{rep}", "treated_lr0.3", rep, 0.2, 0.25),
              _entry(f"m_{rep}", "M1", rep, 0.5, 0.5), _entry(f"m3_{rep}", "M1_lr0.3", rep, 0.4, 0.45)]
    for perm in (E, E[::-1]):
        s, p = tuned_gain(list(perm))
        assert len(p) == 2 and all(q["treated_arm_selected"] == "treated_lr0.3" for q in p)
        assert all(q["treated_run"].split("_", 1)[1] == q["control_run"].split("_", 1)[1] for q in p)
        # the whole tuning procedure: both candidates' own work and the shared baseline once
        assert all(q["treated_tuning_procedure_macs"] == 40 + 60 + 60 for q in p)
        assert s[0]["n_draws"] == 2 and s[0]["primary_G_mean"] == pytest.approx(0.2)
    rej = []
    s, p = tuned_gain(E + [_entry("dup", "M1", "data101_teacher101_opt0", 0.9, 0.1)], rejected=rej)
    assert len(p) == 1 and any("duplicate" in r["reason"] for r in rej)


def test_draw_level_summary_weights_each_draw_once():
    from cop.analysis.strengthening import draw_level
    reps = [("data101_teacher101_opt0", 1.0), ("data101_teacher101_opt1", 3.0), ("data101_teacher101_opt2", 5.0),
            ("data102_teacher102_opt0", -1.0), ("data103_teacher103_opt0", 2.0)]
    d = draw_level(reps)
    assert d["n_draws"] == 3 and d["n_draws_primary"] == 3
    assert d["primary_G_mean"] == pytest.approx((1.0 - 1.0 + 2.0) / 3)
    assert d["pooled_draw_G_mean"] == pytest.approx((3.0 - 1.0 + 2.0) / 3)     # draw 101 weighted once
    assert d["n_crossed_draws"] == 1 and d["within_draw_sd_over_optimizer_seeds"] == pytest.approx(2.0)


def test_compact_gain_summary_reports_draw_level_fields_and_two_replications_stay_two():
    from cop.analysis.strengthening import compact_gain
    E = []
    for i, rep in enumerate(("data101_teacher101_opt0", "data102_teacher102_opt0", "data103_teacher103_opt0")):
        # every replication has its own f0 run (as in a real manifest)
        E += [dict(_entry(f"t_{rep}", "treated", rep, 0.3, 0.3), kind="dissipation", f0_run=f"f0_{i}"),
              dict(_entry(f"c_{rep}", "C1", rep, 0.5, 0.5), kind="continue", f0_run=f"f0_{i}")]
    # a control whose f0 differs from its treated arm's never pairs
    E.append(dict(_entry("c_x", "C1", "data104_teacher104_opt0", 0.1, 0.1), kind="continue", f0_run="f0_a"))
    E.append(dict(_entry("t_x", "treated", "data104_teacher104_opt0", 0.3, 0.3), kind="dissipation", f0_run="f0_b"))
    import random
    rnd = random.Random(0)
    for _ in range(30):
        perm = E[:]
        rnd.shuffle(perm)
        s, p = compact_gain(perm, "test_risk", "fixed_architecture")
        rows = [x for x in s if x["control_arm"] == "C1"]
        assert len(rows) == 1                                   # one summary pools the replications
        row = rows[0]
        assert row["n_pairs"] == 3 and row["n_draws"] == 3 and row["primary_G_mean"] == pytest.approx(0.2)
        assert all(q["treated_run"][2:] == q["control_run"][2:] for q in p if q["control_arm"] == "C1")


# ----------------------------------------------------------------------------- P0.3 removal path export

def test_removal_export_keeps_start_and_immediate_cut_apart(tmp_path, monkeypatch):
    import json
    from cop.analysis import v13_tables as tables
    run = tmp_path / "run"
    run.mkdir()
    (run / "dissipation_result.json").write_text(json.dumps({"path": [
        {"update": 0, "tag": "start", "val_risk": .2},
        {"update": 0, "tag": "after_abrupt_delete_0", "val_risk": .8},
        {"update": 10, "tag": "recover_0", "val_risk": .5}]}))
    metrics = [dict(stage=st, atoms=None, evaluation_partition="test", metric_name="loss", metric_value=v)
               for st, v in [("path_start", .3), ("path_after_abrupt_delete_0", .9)]]
    monkeypatch.setattr(tables, "_rows", lambda r: metrics)
    out = tables.removal_path_table({"r": dict(cfg={"kind": "dissipation", "design": {},
                                                    "dissipation": {"method": "abrupt", "speed_updates": 0,
                                                                    "post_updates": 100}},
                                               dir=run, status={"status": "complete"})})
    assert [r["full_test_risk"] for r in out] == [.3, .9, None]
    assert [r["full_eval_source"] for r in out] == ["path_start", "path_after_abrupt_delete_0", "missing"]
    assert "sampled" in out[0]["peak_kind"]


def test_new_runs_record_logit_norm_and_drift_at_key_events_and_a_frozen_sweep(tmp_path):
    from cop.analysis.strengthening import _rows
    from cop.analysis.summarize import load_runs
    from cop.analysis.v13_tables import removal_path_table, frozen_sweep_table
    p = T.traj({"topology": "layered", "rounds": 1}, with_fc=False)
    d = T.child("dissipation", p[-1], {"dissipation": {"method": "abrupt", "speed_updates": 0, "post_updates": 6,
                                                       "path_full_eval": True}})
    for c in p + [d]:
        _run([c], tmp_path)
    runs = load_runs(tmp_path)
    rows = [r for r in removal_path_table(runs) if r["run_id"] == run_id(d)]
    st, cut = rows[0], rows[1]
    assert st["tag"] == "start" and cut["tag"] == "after_abrupt_delete_0" and st["update"] == cut["update"] == 0
    assert st["full_test_risk"] is not None and cut["full_test_risk"] is not None
    assert st["logit_norm_mean"] is not None and st["prediction_drift_rms_from_start"] == 0.0
    assert cut["prediction_drift_rms_from_start"] is not None
    fs = read_json(tmp_path / "runs" / run_id(d) / "dissipation_result.json")["frozen_weight_sweep"]
    assert fs["intact"]["test"]["risk"] == pytest.approx(st["full_test_risk"])
    assert fs["gate_scale"]["1.0" if "1.0" in fs["gate_scale"] else "0.75"]
    assert fs["joint_deletion"]["test"]["risk"] == pytest.approx(cut["full_test_risk"])
    assert {r["condition"] for r in frozen_sweep_table(runs)} >= {"intact", "gate_0.0", "delete_all"}


# ----------------------------------------------------------------------------- P1.5 finite-peg recipes

FQ_DATA = {"name": "delayed_query", "n_train": 256, "n_val": 64, "n_test": 64, "params": {"n_bits": 6}}
FQ_MODEL = {"family": "mlp", "width": 16, "depth": 3, "query_at_layer": 1}


def _fq_chain(train_over=None):
    b, c = T.cop({"task_kind": "chain", "n_pearls": 2, "global_updates": 20}, {"dim": 2, "mode": "uniform", "bits": 1},
                 data=FQ_DATA, model=FQ_MODEL)
    m = resolve({"kind": "continue", "data": FQ_DATA, "model": FQ_MODEL, "train": {**T.TRAIN, **(train_over or {})},
                 "seeds": {"optimizer": 0}, "parents": {"baseline": run_id(b), "treated": run_id(c)},
                 "continue": {"start": "treated", "start_stage": "export", "reinit": True, "budget": "fixed",
                              "updates": 24}})
    return [b, c, m]


def test_ema_range_moves_in_training_only_and_resumes_identically(tmp_path):
    from cop.graph.graph import GraphNet
    from resume_harness import compare_interrupted
    cfgs = _fq_chain({"quant_range": "ema", "quant_range_momentum": 0.5})
    rd = _run(cfgs, tmp_path / "one")
    res = read_json(rd / "continue_result.json")
    q0, q1 = res["reinit"]["quantizers_at_start"][0], res["reinit"]["quantizers_at_end"][0]
    assert q0["range_lo"] != q1["range_lo"]                          # the range followed the activations
    assert res["quant_recipe"]["recipe"] == "ema"
    assert "coordinate_entropy_bits" in q1 and "code_change_fraction_from_start" in q1
    # evaluation does not move the range
    ck = torch.load(rd / "ckpt" / "final.pt", weights_only=False)
    g = GraphNet.from_checkpoint(ck["model"], "cpu")
    from cop.data.registry import load_bundle
    from cop.train.trainer import evaluate
    q = [g.mods[g.nodes[n].pkey] for n in g.topo_order() if g.nodes[n].op == "quant"][0]
    lo = q.lo.clone()
    evaluate(g, load_bundle(FQ_DATA, device="cpu"), ["val"], 64)
    assert torch.equal(lo, q.lo)
    rep = compare_interrupted(cfgs, tmp_path / "resume")
    assert rep["interrupted_at_polls"] and rep["equal"], rep


def test_warmup_is_continuous_then_calibrated_once_and_resumes_identically(tmp_path):
    from resume_harness import compare_interrupted
    cfgs = _fq_chain({"quant_warmup_updates": 8})
    rd = _run(cfgs, tmp_path / "one")
    res = read_json(rd / "continue_result.json")
    ev = res["reinit"]["quant_recipe"]["warmup_calibrated_at"]
    assert len(ev) == 1 and ev[0]["event"] == "warmup_end_calibration"
    assert res["quant_recipe"]["warmup_updates"] == 8
    rep = compare_interrupted(cfgs, tmp_path / "resume")
    assert rep["interrupted_at_polls"] and rep["equal"], rep


def test_warmup_passthrough_only_in_training_mode():
    from cop.graph.ops import Quantizer
    q = Quantizer(2, "uniform", 1)
    q.lo.fill_(-1.0)
    q.hi.fill_(1.0)
    z = torch.tensor([[0.3, -0.2]])
    q.passthrough = True
    q.train()
    assert torch.equal(q(z), z)
    q.eval()
    assert not torch.equal(q(z), z)


# ----------------------------------------------------------------------------- Family 2 partitions

SHORT = {"name": "shortcut", "n_train": 256, "n_val": 128, "n_test": 128, "params": {"rho_train": 0.9}}


def test_redrawn_and_all_example_partitions(tmp_path):
    from cop.data.registry import load_bundle
    from cop.experiments.trajectory import _spec_split
    b = load_bundle(SHORT, device="cpu")
    a1 = _spec_split(b.train, b, "redrawn_random", redraw=(0, 1, 0.5))
    a1b = _spec_split(b.train, b, "redrawn_random", redraw=(0, 1, 0.5))
    a2 = _spec_split(b.train, b, "redrawn_random", redraw=(0, 2, 0.5))
    assert torch.equal(a1, a1b) and not torch.equal(a1, a2)            # deterministic per step, redrawn per step
    assert bool(_spec_split(b.train, b, "all_examples").all())
    for mode, extra in (("redrawn_random", {"spec_random_fraction": 0.5}), ("all_examples", {})):
        p = T.traj({"topology": "specialized", "specialize": "class_halves", "spec_partition": mode, "rounds": 1,
                    **extra}, data=SHORT, with_fc=False)
        rd = _run(p, tmp_path / mode)
        res = read_json(rd / "summary.json")["result"]
        ex = res["spec_exposure"]
        assert ex["examples"] > 0 and ex["batches"] > 0
        if mode == "all_examples":
            assert ex["branch_a"] == ex["branch_b"] == ex["examples"]
        else:
            assert 0.3 < ex["branch_a"] / ex["examples"] < 0.7 and ex["branch_a"] + ex["branch_b"] == ex["examples"]
        assert res["group_inference_check"]["predictions_identical_under_permuted_groups"]


def test_group_balanced_exposure_differs_from_nominal_proportions(tmp_path):
    p = T.traj({"topology": "specialized", "specialize": "class_halves", "spec_partition": "group", "rounds": 1},
               data=SHORT, train={**T.TRAIN, "sampler": "group_balanced"}, with_fc=False)
    rd = _run(p, tmp_path)
    nominal = read_json(rd / "specialization_access.json")["branch_a_fraction"]
    ex = read_json(rd / "summary.json")["result"]["spec_exposure"]
    assert nominal > 0.8 and abs(ex["branch_a"] / ex["examples"] - 0.5) < 0.2


# ----------------------------------------------------------------------------- P1.7 locality outcomes

def test_locality_reports_task_function_and_code_outcomes_separately(tmp_path):
    from cop.analysis.summarize import load_runs
    from cop.analysis.v13_tables import locality_controls_table, locality_performance_matched
    rows_all = []
    for arm, peg in (("finite_learned", {"dim": 2, "mode": "uniform", "bits": 1}), ("none", {"mode": "none"})):
        cfgs = T.cop({"task_kind": "locality", "n_pearls": 3, "global_updates": 20, "local_updates": 5,
                      "locality_repair_updates": 6, "locality_eval_points": 3, "locality_interface": arm,
                      "locality_controls": True}, peg)
        _run(cfgs, tmp_path)
    runs = load_runs(tmp_path)
    L = locality_controls_table(runs)
    fin = [r for r in L if r["interface"] == "finite_learned"]
    assert fin and all(r["code_agreement_scope1"] is not None and 0.0 <= r["code_agreement_scope1"] <= 1.0
                       for r in fin)
    assert all(r["function_disagreement_scope1"] is not None for r in L)
    assert all(r["reference_val_risk"] is not None for r in L)
    assert all(r["task_scope1_sustained"] in (True, False) for r in L)
    assert all(r["task_scope1_sustained"] is False or r["task_scope1_success_at_end"] for r in L)
    assert all(r["representation_match_code_agreement"] is not None for r in fin)
    pm = locality_performance_matched(L)
    assert pm and all("reference_risk_gap" in r for r in pm)


# ----------------------------------------------------------------------------- review of the v15 patch

def test_finite_recipe_panel_compares_like_recipes_with_equal_opportunities():
    from cop.analysis.v13_tables import finite_recipe_gain
    rep = "data0_teacher0_opt0"
    E = []
    for side, rec, risks in (("treated", "fixed", (0.5, 0.4, 0.45)), ("treated", "ema", (0.6, 0.35, 0.5)),
                             ("M1", "fixed", (1.0, 0.9, 0.95)), ("M1", "ema", (0.7, 0.6, 0.65)),
                             ("M1", "warmup", (0.55, 0.5, 0.52))):
        for f, rk in zip(("1.0", "0.3", "0.1"), risks):
            if side == "treated":
                arm = "treated" + ("" if rec == "fixed" else "_ema") + ("" if f == "1.0" else f"_lr{f}")
            else:
                arm = f"M1_{rec}" + ("" if f == "1.0" else f"_lr{f}")
            E.append(dict(_entry(arm, arm, rep, rk, rk, contrast="FQr|c|bits4"), design_family="FQr"))
    tuned, matched = finite_recipe_gain(E)
    by = {t["recipe"]: t for t in tuned}
    assert set(by) == {"fixed", "ema"}                                    # warm-up never enters a best-of selection
    assert by["fixed"]["treated_lr_selected"] == "0.3" and by["fixed"]["G"] == pytest.approx(0.9 - 0.4)
    assert by["ema"]["treated_run"] == "treated_ema_lr0.3" and by["ema"]["scratch_run"] == "M1_ema_lr0.3"
    wu = [m for m in matched if m["recipe"] == "warmup"]
    assert len(wu) == 3 and all(m["comparison"] == "capacity_relaxation_control" for m in wu)
    assert all(m["treated_run"].startswith("treated") and "_ema" not in m["treated_run"] for m in wu)
    # unequal learning-rate sets are rejected
    rej = []
    tuned, _ = finite_recipe_gain([e for e in E if e["run_id"] != "M1_ema_lr0.1"], rejected=rej)
    assert {t["recipe"] for t in tuned} == {"fixed"} and any("unequal" in r["reason"] for r in rej)


def test_locality_performance_matching_stays_within_a_replication():
    from cop.analysis.v13_tables import locality_performance_matched
    base = {"replace_width": 4, "repair_updates": 10, "tolerance": 0.01, "task_smallest_successful_scope": 1,
            "checkpoint": 0}
    rows = [dict(base, run_id="p101", interface="finite_learned", replication="r101", f0_run="f101",
                 reference_val_risk=0.30),
            dict(base, run_id="n101", interface="none", replication="r101", f0_run="f101", reference_val_risk=0.10),
            dict(base, run_id="n104", interface="none", replication="r104", f0_run="f104", reference_val_risk=0.30)]
    pm = locality_performance_matched(rows)
    assert len(pm) == 1 and pm[0]["nopeg_run"] == "n101"


def test_ema_range_is_frozen_in_restricted_segments():
    from cop.graph.builders import build_mlp
    from cop.graph import edits as E
    from cop.train.trainer import Trainer, Segment
    from cop.data.registry import load_bundle
    from cop.utils import torch_gen
    from cop.config import resolve
    b = load_bundle(T.DATA, device="cpu")
    cfg = resolve(T.base(train={**T.TRAIN, "quant_range": "ema", "quant_range_momentum": 0.0}))
    g = T  # noqa: F841
    from cop.cop_pegs.pegs import insert_peg
    net = build_mlp(b.d_in if hasattr(b, "d_in") else b.train.X["x"].shape[1], [8, 8], b.out_dim, torch_gen(0, "init"))
    pid = insert_peg(net, E.cut_at(net, "post_act", 0), torch_gen(0, "peg"), 2, "uniform", 2)
    q = net.mods[net.nodes[net.implants[pid].meta["peg"]["quant"]].pkey]
    q.lo.fill_(-0.01)
    q.hi.fill_(0.01)
    tr = Trainer(net, b, cfg["train"], {"minibatch": 0, "augmentation": 0, "init": 0}, "cpu")
    tr.configure("none", None, reset_state=True)
    lo0 = q.lo.clone()
    tr.run(Segment("restricted", 3, trainable={net.nodes[n].pkey for n in net.live_nodes()
                                               if net.nodes[n].pkey is not None and net.nodes[n].op == "linear"}))
    assert torch.equal(q.lo, lo0)                                        # held fixed in a restricted segment
    tr.run(Segment("free", 3))
    assert not torch.equal(q.lo, lo0)                                    # follows the activations otherwise
