"""v15: the confirmation launcher (scripts/16) propagates every stage failure and guards the frozen protocol.

The real script runs in a mock COP_HOME: `cop` is a shell stub, the audit tools are stubs whose exit codes are
injected, and the real Python (with the real cop package on PYTHONPATH) computes fingerprints and verdicts.
No training runs."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]

COMMON = r'''set -euo pipefail
export COP_HOME="$MOCK_HOME"
export COP_DATA_ROOT="$MOCK_HOME"
export WORKERS=1 THREADS=1 DEVICE=cpu
export PYTHONPATH="$REAL_ROOT"
cd "$COP_HOME"
mkdir -p "$COP_RESULTS" "$COP_HOME/manifests"
cop() {
  echo "cop $*" >> "$MOCK_HOME/events.txt"
  case "$1" in
    run)
      if [ "${MOCK_RUN_RC:-0}" = 0 ]; then
        python -c "
import json, sys, pathlib
for l in open(sys.argv[1]):
    r = json.loads(l)['run_id']
    d = pathlib.Path(sys.argv[2]) / 'runs' / r
    d.mkdir(parents=True, exist_ok=True)
    (d / 'status.json').write_text(json.dumps({'status': 'complete'}))
    (d / 'endpoint.json').write_text('{}')
" "$3" "$5"
      fi
      return "${MOCK_RUN_RC:-0}" ;;
    summarize) [ "$2" = "--strict" ] || { echo "summary without --strict" >&2; return 9; }; mkdir -p "$8"; return "${MOCK_SUM_RC:-0}" ;;
    *) return 0 ;;
  esac
}
'''

STUB = "import os, sys\nsys.exit(int(os.environ.get('{var}', '0')))\n"
RELOAD_STUB = """import json, os, sys
from pathlib import Path
res, out = Path(sys.argv[1]), sys.argv[2]
n = sum(1 for d in (res / "runs").glob("*") if (d / "endpoint.json").exists()) if (res / "runs").exists() else 0
n -= int(os.environ.get("MOCK_RELOAD_SHORT", "0"))
json.dump({"summary": {"n_checked": n, "n_excluded": 0}}, open(out, "w"))
sys.exit(int(os.environ.get("MOCK_RELOAD_RC", "0")))
"""


def _home(tmp: Path) -> dict:
    home = tmp / "home"
    (home / "scripts").mkdir(parents=True)
    shutil.copy2(ROOT / "scripts/16_v13_confirmation.sh", home / "scripts/16_v13_confirmation.sh")
    (home / "scripts/common.sh").write_text(COMMON)
    p = home / "audit_v8/tools/check_results.py"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(STUB.replace("{var}", "MOCK_CHECK_RC"))
    p = home / "audit_v5/tools/fresh_reload.py"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(RELOAD_STUB)
    (home / "audit_v5/tools/runtime_v13.py").write_text(
        "import json, sys\nout = sys.argv[sys.argv.index('--out') + 1]\n"
        "json.dump({'wall_hours': 1.0, 'serial_hours': 1.0}, open(out, 'w'))\n")
    (home / "manifests").mkdir()
    (home / "manifests/wave14_full.jsonl").write_text(
        "\n".join(json.dumps({"run_id": f"job{i}"}) for i in range(3)) + "\n")
    res = tmp / "results"
    (res / "v13_reports").mkdir(parents=True)
    (res / "v13_reports/rates_repilot.json").write_text("{}")
    zipdir = tmp / "zips"
    zipdir.mkdir()
    env = dict(os.environ, MOCK_HOME=str(home), REAL_ROOT=str(ROOT), COP_RESULTS=str(res), ZIP_DIR=str(zipdir),
               SCALE="full", HOME=str(tmp), CONFIRM="1", RATES=str(res / "v13_reports/rates_repilot.json"))
    return {"home": home, "res": res, "zip": zipdir, "env": env}


def _sh(h, *args, **env):
    e = dict(h["env"], **{k: str(v) for k, v in env.items()})
    return subprocess.run(["bash", str(h["home"] / "scripts/16_v13_confirmation.sh"), *args], env=e,
                          capture_output=True, text=True, cwd=h["home"])


@pytest.fixture
def frozen(tmp_path):
    h = _home(tmp_path)
    r = _sh(h, "freeze")
    assert r.returncode == 0, r.stdout + r.stderr
    assert (h["res"] / "confirmation_full/PROTOCOL_FROZEN.json").exists()
    return h


def _verdict(h):
    return json.loads((h["res"] / "confirmation_full/verdict.json").read_text())


def test_successful_run_exits_zero_and_packages(frozen):
    r = _sh(frozen, "run")
    assert r.returncode == 0, r.stdout + r.stderr
    v = _verdict(frozen)
    assert v["all_passed"] and set(v["stages"]) >= {"run", "completion", "checks", "reload", "summary", "package"}
    assert (frozen["zip"] / "cop_v13_confirmation_full_reports.zip").exists()


@pytest.mark.parametrize("var,stage", [("MOCK_RUN_RC", "run"), ("MOCK_CHECK_RC", "checks"),
                                       ("MOCK_RELOAD_RC", "reload"), ("MOCK_SUM_RC", "summary")])
def test_a_failed_stage_fails_the_launcher_but_the_rest_still_runs(frozen, var, stage):
    r = _sh(frozen, "run", **{var: 7})
    assert r.returncode != 0
    v = _verdict(frozen)
    assert v["stages"][stage] == 7 and not v["all_passed"]
    if stage == "run":
        assert v["stages"]["completion"] != 0                          # nothing completed
    assert "package" in v["stages"]                                    # diagnostics still collected


def test_a_packaging_failure_fails_the_launcher(frozen):
    (frozen["zip"] / "cop_v13_confirmation_full_reports.zip").mkdir()     # the zip path is a directory
    r = _sh(frozen, "run")
    assert r.returncode != 0 and _verdict(frozen)["stages"]["package"] != 0


def test_a_protocol_change_after_the_freeze_is_refused_or_recorded(frozen):
    (frozen["home"] / "audit_v8/tools/check_results.py").write_text(STUB.replace("{var}", "MOCK_CHECK_RC") + "# edit\n")
    r = _sh(frozen, "run")
    assert r.returncode != 0 and "protocol_hash" in (r.stdout + r.stderr)
    assert not (frozen["res"] / "confirmation_full/verdict.json").exists()
    r = _sh(frozen, "run", PROTOCOL_AMENDMENT="checker message wording")
    assert r.returncode == 0, r.stdout + r.stderr
    am = json.loads((frozen["res"] / "confirmation_full/PROTOCOL_AMENDMENTS.json").read_text())
    assert am[-1]["reason"] == "checker message wording" and am[-1]["frozen_protocol_hash"] != am[-1]["current_protocol_hash"]


def test_a_manifest_change_after_the_freeze_is_refused(frozen):
    with open(frozen["res"] / "confirmation_full/manifest_frozen.jsonl", "a") as f:
        f.write(json.dumps({"run_id": "extra"}) + "\n")
    r = _sh(frozen, "run", PROTOCOL_AMENDMENT="anything")
    assert r.returncode != 0 and "manifest" in (r.stdout + r.stderr)


def test_a_second_freeze_needs_a_recorded_reason(frozen):
    r = _sh(frozen, "freeze")
    assert r.returncode != 0 and "already frozen" in (r.stdout + r.stderr)
    r = _sh(frozen, "freeze", REFREEZE_REASON="added a cell")
    assert r.returncode == 0, r.stdout + r.stderr
    am = json.loads((frozen["res"] / "confirmation_full/PROTOCOL_AMENDMENTS.json").read_text())
    assert am[-1]["event"] == "re-freeze" and am[-1]["reason"] == "added a cell"


def test_incomplete_reload_coverage_fails_the_launcher(frozen):
    r = _sh(frozen, "run", MOCK_RELOAD_SHORT=1)
    assert r.returncode != 0 and _verdict(frozen)["stages"]["reload_coverage"] != 0
    assert (frozen["res"] / "confirmation_full/stage_reload.log").exists()
