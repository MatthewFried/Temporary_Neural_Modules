"""v16: tests added in the multi-pass review of v15 (no training except where a graph is built by hand)."""
from __future__ import annotations

import random
import sys
from pathlib import Path

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import tiny_configs as T  # noqa: E402

REPS = ("data101_teacher101_opt0", "data102_teacher102_opt0")


def _sel_entry(rid, arm, rep, f0, sel_risk, kind):
    # the fixed-endpoint test_risk is deliberately different from the selected one: the analysis must read sel_*
    return {"run_id": rid, "design_contrast": "k", "design_arm": arm, "replication": rep, "f0_run": f0,
            "f0_stage": "best_val", "design_budget_panel": "updates", "architecture_hash": "A",
            "f0_architecture_hash": "A", "status": "complete", "validity": "valid", "eligible": True,
            "kind": kind, "compact": True, "data": "d", "model": "m", "data_identity": "d", "model_identity": "m",
            "design_family": "F", "design_variant": "v", "task": "regression",
            "test_risk": 99.0, "val_risk": 99.0, "total_procedure_macs": 100, "baseline_macs": 40,
            "sel_available": True, "sel_architecture_hash": "A", "sel_partition": "val", "sel_n_candidates": 4,
            "sel_test_risk": sel_risk, "sel_val_risk": sel_risk, "f0_sel_test_risk": 1.0, "f0_sel_val_risk": 1.0}


def test_selected_gain_pools_two_replications_with_distinct_f0_and_reads_selected_values():
    from cop.analysis.strengthening import selected_gain
    E = []
    for i, rep in enumerate(REPS):
        E += [_sel_entry(f"t_{rep}", "treated", rep, f"f0_{i}", 0.2 + 0.1 * i, "dissipation"),
              _sel_entry(f"c_{rep}", "C1", rep, f"f0_{i}", 0.5 + 0.1 * i, "continue")]
    rnd = random.Random(1)
    for _ in range(20):
        perm = E[:]
        rnd.shuffle(perm)
        s, p = selected_gain(perm, "test_risk", "fixed_architecture", f0_fallback=False)
        rows = [x for x in s if x["control_arm"] == "C1"]
        assert len(rows) == 1 and rows[0]["n_pairs"] == 2 and rows[0]["n_draws"] == 2
        assert rows[0]["primary_G_mean"] == pytest.approx(0.3)            # selected values, not test_risk = 99
        ps = [q for q in p if q["control_arm"] == "C1"]
        assert all(q["treated_run"][2:] == q["control_run"][2:] for q in ps)


def test_selected_gain_rejects_unequal_selection_opportunities():
    from cop.analysis.strengthening import selected_gain
    rep = REPS[0]
    E = [_sel_entry("t", "treated", rep, "f0", 0.2, "dissipation"),
         dict(_sel_entry("c", "C1", rep, "f0", 0.5, "continue"), sel_n_candidates=9)]
    rej = []
    s, p = selected_gain(E, "test_risk", "fixed_architecture", f0_fallback=False, rejected=rej)
    assert not [q for q in p if q["control_arm"] == "C1"]
    assert any("unequal selection opportunities" in r["reason"] for r in rej)


def _fq(rep, f0, shift):
    from test_v15 import _entry
    E = []
    for side, rec, risks in (("treated", "fixed", (0.5, 0.4)), ("M1", "fixed", (1.0, 0.9)),
                             ("treated", "ema", (0.6, 0.35)), ("M1", "ema", (0.7, 0.6)),
                             ("M1", "warmup", (0.55, 0.5))):
        for f, rk in zip(("1.0", "0.3"), risks):
            if side == "treated":
                arm = "treated" + ("" if rec == "fixed" else "_ema") + ("" if f == "1.0" else f"_lr{f}")
            else:
                arm = f"M1_{rec}" + ("" if f == "1.0" else f"_lr{f}")
            E.append(dict(_entry(f"{arm}@{rep}", arm, rep, rk + shift, rk + shift, contrast="FQr|c|bits4"),
                          design_family="FQr", f0_run=f0))
    return E


def test_finite_recipe_gain_two_replications_under_permutations_and_pooled_summary():
    from cop.analysis.v13_tables import finite_recipe_gain, draw_summary
    E = _fq(REPS[0], "f0_a", 0.0) + _fq(REPS[1], "f0_b", 0.1)
    rnd = random.Random(2)
    for _ in range(20):
        perm = E[:]
        rnd.shuffle(perm)
        tuned, matched = finite_recipe_gain(perm)
        assert len(tuned) == 4                                            # 2 recipes x 2 replications
        for t in tuned:                                                   # never across replications
            assert t["treated_run"].split("@")[1] == t["scratch_run"].split("@")[1] == t["replication"]
        s = draw_summary(tuned, ("contrast", "recipe"), {"G": lambda r: r.get("G")})
        by = {r["recipe"]: r for r in s}
        assert by["fixed"]["n_replications"] == 2 and by["fixed"]["G_n_draws"] == 2
        assert by["fixed"]["G_primary_G_mean"] == pytest.approx(0.5)       # shift cancels inside a replication
        ms = draw_summary(matched, ("contrast", "recipe", "lr_factor", "comparison"), {"G": lambda r: r.get("G")})
        assert {(r["recipe"], r["lr_factor"]) for r in ms} == {(a, b) for a in ("fixed", "ema", "warmup")
                                                               for b in ("1.0", "0.3")}


def test_draw_summary_rejects_a_replication_twice_in_one_group_and_keeps_f0_stages_apart():
    from cop.analysis.v13_tables import draw_summary
    rows = [{"contrast": "k", "f0": "f@best_val", "replication": REPS[0], "G": 1.0},
            {"contrast": "k", "f0": "f@final", "replication": REPS[0], "G": 3.0}]
    s = draw_summary(rows, ("contrast",), {"G": lambda r: r["G"]})
    assert len(s) == 2 and {r["f0_stage"] for r in s} == {"best_val", "final"}
    rej = []
    s = draw_summary(rows + [dict(rows[0], G=2.0)], ("contrast",), {"G": lambda r: r["G"]}, rej)
    assert len(s) == 1 and s[0]["f0_stage"] == "final" and "twice" in rej[0]["reason"]


def test_later_query_summary_pools_retention_over_replications():
    from cop.analysis.v13_tables import later_query_summary
    LQ = [{"contrast": "M", "f0": "f@best_val", "replication": rep, "endpoint_policy": "fixed", "control_arm": "M1",
           "comparison": "control", "treated_test_err": 0.1, "control_test_err": 0.3 + i,
           "treated_test_risk": None, "control_test_risk": None,
           "treated_readout_p1_mid_acc": 0.9, "control_readout_p1_mid_acc": 0.6} for i, rep in enumerate(REPS)]
    s = later_query_summary(LQ)
    assert len(s) == 1 and s[0]["n_replications"] == 2
    assert s[0]["test_err_G_primary_G_mean"] == pytest.approx(0.7)
    assert s[0]["readout_p1_mid_acc_retained_primary_G_mean"] == pytest.approx(0.3)
    assert s[0]["test_risk_G_n_draws"] == 0


def test_frozen_sweep_deletes_a_branch_alone_inside_a_group():
    from cop.data.registry import load_bundle
    from cop.experiments.dissipation import frozen_weight_sweep
    from cop.graph import edits as E
    from cop.graph.builders import build_mlp
    from cop.utils import torch_gen
    b = load_bundle(T.DATA, device="cpu")
    net = build_mlp(b.train.X["x"].shape[1], [8, 8], b.out_dim, torch_gen(0, "init"))
    G = E.insert_group(net, E.cut_at(net, "post_act", 0), torch_gen(0, "insertion", "g"), slot="spec/G", rnd=1)
    ba = E.add_branch(net, G, torch_gen(0, "insertion", "a"), width=4, slot="spec/r1/a")
    bb = E.add_branch(net, G, torch_gen(0, "insertion", "b"), width=4, slot="spec/r1/b")
    gen = torch.Generator().manual_seed(3)
    for bid in (ba, bb):                         # branches start at zero output: give them a real contribution
        n = next(n for n in net.nodes if net.nodes[n].owner == bid and net.nodes[n].role == "B")
        for p_ in net.mods[net.nodes[n].pkey].parameters():
            with torch.no_grad():
                p_.copy_(torch.randn(p_.shape, generator=gen, dtype=p_.dtype))
    net._plan = None
    fs = frozen_weight_sweep(net, [G], b, 512)
    assert fs["targets"] == [G] and set(fs["all_implants"]) >= {G, ba, bb}
    assert fs["parents"][ba] == G and fs["kinds"][ba] == "branch" and fs["slots"][bb] == "spec/r1/b"
    risk = lambda sc: sc["test"]["risk"]
    assert "error" not in fs["single_deletion"][ba] and "error" not in fs["single_deletion"][bb]
    # deleting one branch differs from the intact model and from deleting the whole group
    assert risk(fs["single_deletion"][ba]) != pytest.approx(risk(fs["intact"]))
    assert risk(fs["single_deletion"][ba]) != pytest.approx(risk(fs["joint_deletion"]))
    assert risk(fs["single_deletion"][G]) == pytest.approx(risk(fs["joint_deletion"]))


def test_frozen_sweep_table_labels_branch_rows():
    import json
    from cop.analysis.v13_tables import frozen_sweep_table
    import tempfile
    d = Path(tempfile.mkdtemp())
    sc = {"test": {"risk": 0.5}}
    (d / "dissipation_result.json").write_text(json.dumps({"frozen_weight_sweep": {
        "targets": ["I1"], "all_implants": ["I1", "I2"], "parents": {"I2": "I1"}, "kinds": {"I1": "series",
        "I2": "branch"}, "slots": {"I1": "spec/G", "I2": "spec/r1/a"}, "intact": sc, "gate_scale": {"0.0": sc},
        "single_deletion": {"I1": sc, "I2": sc}, "joint_deletion": sc}}))
    rows = frozen_sweep_table({"r": {"dir": d, "cfg": {"kind": "dissipation", "design": {}}}})
    br = next(r for r in rows if r["condition"] == "delete_I2")
    assert br["implant_kind"] == "branch" and br["implant_parent"] == "I1" and br["is_removal_target"] is False
    assert next(r for r in rows if r["condition"] == "delete_I1")["is_removal_target"] is True


def test_strict_summary_fails_on_a_table_level_analysis_error(monkeypatch, tmp_path):
    import argparse
    from cop import cli
    from cop.analysis import summarize as S
    assert cli.summary_errors({"strengthening": {"v13_tables_error": "KeyError: x"}}) == ["v13 tables: KeyError: x"]
    assert cli.summary_errors({"strengthening": None, "figure_errors": {"f": "e"}}) == []
    monkeypatch.setattr(S, "summarize", lambda *a, **k: {"strengthening": {"error": "ValueError: y"}})
    a = argparse.Namespace(results=str(tmp_path), manifest=[], out=None, historical=False, strict=True)
    with pytest.raises(SystemExit) as ex:
        cli.cmd_summarize(a)
    assert ex.value.code == 3
    cli.cmd_summarize(argparse.Namespace(**{**vars(a), "strict": False}))   # recorded, not raised


def test_later_query_readout_retention_pools_only_like_decoder_classes():
    from cop.analysis.v13_tables import later_query_retention, later_query_summary
    rows = []
    for i, rep in enumerate(REPS):
        for arm, dec, acc in (("treated", "majority table per message", 0.9),
                              ("M1", "majority table per message" if i == 0 else "least squares", 0.6)):
            rows.append({"family": "M_Er", "contrast": "M", "arm": arm, "replication": rep, "f0_run": f"f{i}",
                         "f0_stage": "best_val", "endpoint_policy": "fixed", "architecture_hash": "A",
                         "run_id": f"{arm}{i}", "test_err": 0.1, "test_risk": 0.1,
                         "readout_p1_decoder": dec, "readout_p1_test_acc": acc, "readout_p1_fit_examples": 256})
    LQ = later_query_retention(rows)
    assert [r["same_decoder_class"] for r in sorted(LQ, key=lambda r: r["replication"])] == [True, False]
    assert all(r["treated_readout_p1_fit_examples"] == 256 for r in LQ)
    s = later_query_summary(LQ)
    assert s[0]["readout_p1_test_acc_retained_n_draws"] == 1 and s[0]["test_err_G_n_draws"] == 2
