"""v17: tests for the changes after the wave-15 review."""
from __future__ import annotations

import json
import random
import sys
from pathlib import Path

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import tiny_configs as T  # noqa: E402
from cop.config import resolve, run_id, seed_of  # noqa: E402
from cop.utils import read_json  # noqa: E402


# ----------------------------------------------------------------------------- straight-through margin

def _q(bits=1):
    from cop.graph.ops import Quantizer
    q = Quantizer(1, "uniform", bits)
    q.lo.fill_(0.25)
    q.hi.fill_(0.75)
    return q


def test_ste_margin_keeps_the_gradient_of_edge_values_and_never_changes_the_forward():
    q = _q()
    lo, hi = float(q.lo), float(q.hi)
    # one rounding step outside each edge, and genuinely far outside
    z0 = torch.tensor([[torch.nextafter(torch.tensor(lo), torch.tensor(-1.0)).item()],
                       [torch.nextafter(torch.tensor(hi), torch.tensor(2.0)).item()], [5.0], [0.5]],
                      requires_grad=True)
    q.train()
    y_strict = q(z0)
    y_strict.sum().backward()
    g_strict = z0.grad.clone().flatten().tolist()
    assert g_strict == [0.0, 0.0, 0.0, 1.0]                   # the v13-v16 rule: edge values lose their gradient
    z0.grad = None
    q.ste_margin = 1e-3
    y_m = q(z0)
    y_m.sum().backward()
    assert z0.grad.flatten().tolist() == [1.0, 1.0, 0.0, 1.0]  # edge values keep it; far outside still clipped
    assert torch.equal(y_m.detach(), y_strict.detach())       # forward value (the message) unchanged
    q.eval()
    assert torch.equal(q(z0).detach(), y_strict.detach())


def test_trainer_sets_the_margin_for_training_only_and_resets_it():
    from cop.graph.builders import build_mlp
    from cop.graph import edits as E
    from cop.cop_pegs.pegs import insert_peg
    from cop.data.registry import load_bundle
    from cop.train.trainer import Trainer, Segment
    from cop.utils import torch_gen
    b = load_bundle(T.DATA, device="cpu")
    cfg = resolve(T.base(train={**T.TRAIN, "quant_ste_margin": 1e-3}))
    net = build_mlp(b.train.X["x"].shape[1], [8, 8], b.out_dim, torch_gen(0, "init"))
    pid = insert_peg(net, E.cut_at(net, "post_act", 0), torch_gen(0, "peg"), 2, "uniform", 2)
    q = net.mods[net.nodes[net.implants[pid].meta["peg"]["quant"]].pkey]
    tr = Trainer(net, b, cfg["train"], {"minibatch": 0, "augmentation": 0, "init": 0}, "cpu")
    tr.configure("none", None, reset_state=True)
    seen = []
    tr.run(Segment("s", 3, on_step=lambda trn, k: seen.append(getattr(q, "ste_margin", None))))
    assert seen == [1e-3] * 3 and q.ste_margin == 0.0


def test_margin_config_is_validated():
    from cop.config import ConfigError
    with pytest.raises(ConfigError):
        resolve(T.base(train={**T.TRAIN, "quant_ste_margin": 0.7}))
    assert resolve(T.base())["train"]["quant_ste_margin"] == 0.0


# ----------------------------------------------------------------------------- recipe panel with budget panels

def _fq_entry(arm, rep, risk, panel):
    from test_v15 import _entry
    return dict(_entry(f"{arm}@{rep}", arm, rep, risk, risk, contrast="FQr|c|bits4", panel=panel),
                design_family="FQr", f0_run=f"f0{rep[-1]}")


def test_arm_parser_knows_margin_recipes_and_budget_panels():
    from cop.analysis.v13_tables import _parse_fq_arm
    assert _parse_fq_arm("treated_ema_m_lr0.3") == ("treated", "ema_m", "0.3", "-")
    assert _parse_fq_arm("treated_m") == ("treated", "fixed_m", "1.0", "-")
    assert _parse_fq_arm("M2_ema_m") == ("scratch", "ema_m", "1.0", "compute")
    assert _parse_fq_arm("M1_fixed_lr0.3") == ("scratch", "fixed", "0.3", "updates")
    assert _parse_fq_arm("M1_warmup") == ("scratch", "warmup", "1.0", "updates")
    assert _parse_fq_arm("C1") is None


def test_finite_recipe_gain_compares_within_recipe_and_budget_panel():
    from cop.analysis.v13_tables import finite_recipe_gain
    E = []
    for rep in ("data101_teacher101_opt0", "data102_teacher102_opt0"):
        for arm, risk, panel in (("treated_ema_m", .60, "updates"), ("treated_ema_m_lr0.3", .55, "updates"),
                                 ("M1_ema_m", .70, "updates"), ("M1_ema_m_lr0.3", .72, "updates"),
                                 ("M2_ema_m", .58, "compute"), ("M2_ema_m_lr0.3", .65, "compute"),
                                 ("M1_warmup", .80, "updates"), ("treated", .62, "updates")):
            E.append(_fq_entry(arm, rep, risk, panel))
    rnd = random.Random(3)
    for _ in range(10):
        perm = E[:]
        rnd.shuffle(perm)
        tuned, matched = finite_recipe_gain(perm)
        by = {(t["recipe"], t["scratch_panel"], t["replication"]): t for t in tuned}
        t = by[("ema_m", "updates", "data101_teacher101_opt0")]
        assert t["treated_lr_selected"] == "0.3" and t["G"] == pytest.approx(.70 - .55)
        t = by[("ema_m", "compute", "data102_teacher102_opt0")]
        assert t["scratch_lr_selected"] == "1.0" and t["G"] == pytest.approx(.58 - .55)
        assert not any(k[0] == "warmup" for k in by)
        wu = [m for m in matched if m["recipe"] == "warmup"]
        assert wu and all(m["comparison"] == "capacity_relaxation_control" and m["scratch_panel"] == "updates"
                          for m in wu)


def test_wave16_panel_arms_budgets_and_margins():
    from cop.orchestration.manifest import generate
    B = generate([16], "smoke")
    cfgs = [e["cfg"] for e in B.entries.values() if (e["cfg"].get("design") or {}).get("family") == "FQr"]
    arms = {(c["design"]["contrast"], c["design"]["arm"]) for c in cfgs}
    assert ("FQr|teacher3_n2048_d6|bits1", "treated_ema_m_lr0.3") in arms
    assert ("FQr|teacher3_n2048_d6|bits1", "M2_fixed_m") in arms
    assert not any(a.startswith("M2_warmup") for _, a in arms)
    assert not any(a.endswith("_lr0.1") for _, a in arms)
    for c in cfgs:
        a = c["design"]["arm"]
        if a.startswith("M2_"):
            assert c["continue"]["budget"] == "parent_compute" and c["continue"]["budget_add_f0"]
            assert c["design"]["budget_panel"] == "compute"
        if a.startswith("M1_"):
            assert c["continue"]["budget"] == "parent_updates"
        margin = c["train"]["quant_ste_margin"]
        assert (margin > 0) == ("_m" in a.replace("M1_", "").replace("M2_", "")), a


# ----------------------------------------------------------------------------- partition seeds

def test_partition_seed_defaults_to_insertion_and_marks_the_replication():
    from cop.analysis.strengthening import _rk, draw_level
    c = resolve(T.base())
    c["seeds"]["insertion"] = 7
    assert seed_of(c, "partition") == 7
    c["seeds"]["partition"] = 2
    assert seed_of(c, "partition") == 2 and _rk(c).endswith("_part2")
    d = draw_level([("data101_teacher101_opt0", 1.0), ("data101_teacher101_opt0_part1", 3.0),
                    ("data102_teacher102_opt0", 2.0)])
    assert d["n_draws"] == 2 and d["primary_G_mean"] == pytest.approx(1.5)     # default partition only
    assert d["pooled_draw_G_mean"] == pytest.approx((2.0 + 2.0) / 2)           # draw 101 weighted once


def test_confirmation_partition_block_crosses_partition_seeds_and_pairs_c1_within_them():
    from cop.orchestration.manifest import generate
    from cop.analysis.strengthening import _rk
    B = generate([14], "smoke")
    ents = list(B.entries.values())
    p2 = [e["cfg"] for e in ents if (e["cfg"].get("design") or {}).get("family") == "P2"]
    fixed = [c for c in p2 if c["design"]["variant"] == "fixed_random_matched" and c["data"]["data_seed"] == 101]
    tr = sorted(_rk(c) for c in fixed if c["design"]["arm"] == "treated")
    c1 = sorted(_rk(c) for c in fixed if c["design"]["arm"] == "C1")
    assert tr == c1 == sorted(["data101_teacher101_opt0", "data101_teacher101_opt0_part1",
                               "data101_teacher101_opt0_part2"])
    tg = [c for c in p2 if c["design"]["variant"] == "true_group" and c["data"]["data_seed"] == 101]
    assert len([c for c in tg if c["design"]["arm"] == "treated"]) == 1
    assert {c["data"]["data_seed"] for c in p2} == {101, 102, 103, 104, 105}


def test_partition_seed_changes_the_fixed_split(tmp_path):
    from test_v15 import _run
    SH = {"name": "shortcut", "n_train": 256, "n_val": 64, "n_test": 64, "params": {"rho_train": 0.9}}
    inds = []
    for ps in (None, 5):
        p = T.traj({"topology": "specialized", "specialize": "class_halves", "spec_partition": "random_matched",
                    "rounds": 1, "updates_per_round": 4}, data=SH, with_fc=False)
        if ps is not None:
            p[-1] = resolve({**p[-1], "seeds": {**p[-1]["seeds"], "partition": ps}})
        _run(p, tmp_path)
        inds.append(torch.load(tmp_path / "runs" / run_id(p[-1]) / "spec_partition.pt", weights_only=False))
    assert inds[0].sum() == inds[1].sum() and not torch.equal(inds[0], inds[1])


# ----------------------------------------------------------------------------- locality reporting

def test_performance_matching_needs_an_explicit_tolerance():
    from cop.analysis.v13_tables import locality_performance_matched
    base = {"replace_width": 4, "repair_updates": 10, "tolerance": 0.01, "task_smallest_successful_scope": 1,
            "checkpoint": 0, "replication": "r", "f0_run": "f"}
    rows = [dict(base, run_id="p", interface="finite_learned", reference_val_risk=0.37),
            dict(base, run_id="n", interface="none", reference_val_risk=0.46),
            dict(base, run_id="p2", interface="continuous", reference_val_risk=0.455)]
    pm = {r["pegged_run"]: r for r in locality_performance_matched(rows)}
    assert pm["p"]["performance_matched"] is False and pm["p"]["nopeg_run"] == "n"
    assert pm["p2"]["performance_matched"] is True


def test_locality_outcome_summary_counts_found_then_lost():
    from cop.analysis.v13_tables import locality_outcome_summary
    base = {"interface": "finite_learned", "replace_width": 16, "repair_updates": 4000, "tolerance": 1e-4,
            "checkpoint": 2, "function_disagreement_scope1": 0.1, "code_agreement_scope1": 0.2,
            "reference_val_risk": 0.37}
    rows = [dict(base, task_scope1_first_passage_update=1000, task_scope1_success_at_end=False,
                 task_scope1_sustained=False, censored=True),
            dict(base, task_scope1_first_passage_update=500, task_scope1_success_at_end=True,
                 task_scope1_sustained=True, censored=False),
            dict(base, task_scope1_first_passage_update=None, task_scope1_success_at_end=False,
                 task_scope1_sustained=False, censored=True)]
    s = locality_outcome_summary(rows)
    assert len(s) == 1
    r = s[0]
    assert (r["n_replications"], r["scope1_first_passage"], r["scope1_success_at_end"], r["scope1_sustained"],
            r["scope1_found_then_lost"], r["censored_any_scope"]) == (3, 2, 1, 1, 1, 2)


# ----------------------------------------------------------------------------- selected-checkpoint diagnostics

def test_treated_chain_records_selected_checkpoint_diagnostics_and_labelled_readouts(tmp_path):
    from test_v15 import _run
    LQ = {"name": "later_query", "n_train": 256, "n_val": 64, "n_test": 64, "params": {"n_bits": 10, "task_bits": 1}}
    from cop.analysis.summarize import load_runs
    from cop.analysis.strengthening import endpoint_table
    from cop.analysis.v13_tables import history_ingredients_table
    tr = {**T.TRAIN, "select_candidates": 3}
    b, c = T.cop({"task_kind": "chain", "n_pearls": 2, "global_updates": 20}, {"dim": 2, "mode": "uniform", "bits": 1},
                 data=LQ, model={"family": "mlp", "width": 16, "depth": 4}, train=tr)
    c = resolve({**c, "design": {"family": "FQr", "variant": "v", "arm": "treated", "contrast": "FQr|x|v",
                                 "budget_panel": "updates"}})
    _run([b, c], tmp_path)
    j = read_json(tmp_path / "runs" / run_id(c) / "cop_chain_result.json")
    assert j["later_queries"]["checkpoint"] == "final"
    assert j["quantizers_at_selected"] and j["gradients_at_selected"]["grad_norm_by_module"]
    assert j["gradients_at_export"]["grad_norm_by_module"]
    ls = j["later_queries_selected"]
    assert ls["checkpoint"] == "best_val"
    runs = load_runs(tmp_path)
    row = next(r for r in history_ingredients_table(runs, endpoint_table(runs)) if r["run_id"] == run_id(c))
    assert row["readout_checkpoint"] == "final"
    assert row["quant_selected_distinct_messages"] is not None and row["grad_norm_max_at_selected"] is not None
    assert row.get("sel_readout_checkpoint") == "best_val" or row.get("sel_readout_unavailable")


def test_audits_split_edge_clipping_and_use_the_jobs_gradient_rule():
    from cop.graph.builders import build_mlp
    from cop.graph import edits as E
    from cop.cop_pegs.pegs import insert_peg
    from cop.data.registry import load_bundle
    from cop.experiments.continuation import quantizer_audit, gradient_audit
    from cop.utils import torch_gen
    b = load_bundle(T.DATA, device="cpu")
    net = build_mlp(b.train.X["x"].shape[1], [8, 8], b.out_dim, torch_gen(0, "init"))
    pid = insert_peg(net, E.cut_at(net, "post_act", 0), torch_gen(0, "peg"), 1, "uniform", 1)
    nid = net.implants[pid].meta["peg"]["quant"]
    q = net.mods[net.nodes[nid].pkey]
    # put the range strictly inside the data by a hair at both ends: every input at the extremes is 'edge'-clipped
    _, v = net({k: x[:512] for k, x in b.train.X.items()}, return_nodes=[net.nodes[nid].inputs[0]])
    z = v[net.nodes[nid].inputs[0]].reshape(-1)
    q.lo.fill_(float(z.min()))
    q.hi.fill_(float(z.max()))
    span = float(z.max() - z.min())
    q.lo += span * 1e-6
    q.hi -= span * 1e-6
    rec = next(r for r in quantizer_audit(net, b) if r["node"] == nid)
    assert rec["clip_fraction"] > 0 and rec["clip_fraction_edge"] == pytest.approx(rec["clip_fraction"])
    assert rec["clip_fraction_far"] == 0.0
    g0, g1 = gradient_audit(net, b, ste_margin=0.0), gradient_audit(net, b, ste_margin=1e-3)
    assert g1["ste_margin"] == 1e-3 and getattr(q, "ste_margin", 0.0) == 0.0     # the model itself is untouched
    up = [k for k in g0["grad_norm_by_module"] if k in g1["grad_norm_by_module"]]
    assert sum(g1["grad_norm_by_module"][k] for k in up) >= sum(g0["grad_norm_by_module"][k] for k in up)


def test_selected_recipe_panel_reads_selected_values_and_checks_opportunities():
    from cop.analysis.v13_tables import finite_recipe_gain_selected
    E = []
    for arm, fixed_r, sel_r in (("treated_ema", .70, .68), ("treated_ema_lr0.3", .69, .68),
                                ("M1_ema", .83, .71), ("M1_ema_lr0.3", .85, .85)):
        e = _fq_entry(arm, "data101_teacher101_opt0", fixed_r, "updates")
        e.update(sel_available=True, sel_architecture_hash="A", sel_test_risk=sel_r, sel_val_risk=sel_r,
                 sel_n_candidates=8)
        E.append(e)
    tuned, _ = finite_recipe_gain_selected(E)
    t = tuned[0]
    assert t["recipe"] == "ema" and t["scratch_run"].startswith("M1_ema@") and t["G"] == pytest.approx(.71 - .68)
    rej = []
    E[2]["sel_n_candidates"] = 5
    tuned, _ = finite_recipe_gain_selected(E, rejected=rej)
    assert not tuned and any("selection opportunities" in r["reason"] for r in rej)
