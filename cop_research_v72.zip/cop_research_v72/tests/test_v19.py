"""v19: branch reassignment schedules, membership-resolved deletion damage, hybrid (swap) start states."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import tiny_configs as T  # noqa: E402
from cop.config import resolve, run_id, ConfigError  # noqa: E402
from cop.utils import read_json  # noqa: E402

SH = {"name": "shortcut", "n_train": 256, "n_val": 64, "n_test": 64, "params": {"rho_train": 0.9}}


def _traj(part="random_matched", reassign=None, snapshot_at=None, rounds=2, upr=6):
    g = {"topology": "specialized", "specialize": "class_halves", "spec_partition": part, "rounds": rounds,
         "updates_per_round": upr}
    if reassign:
        g["spec_reassign"] = reassign
    tr = {**T.TRAIN, **({"snapshot_at": snapshot_at} if snapshot_at else {})}
    return T.traj(g, data=SH, train=tr, with_fc=False)


def _run(cfgs, d):
    from test_v15 import _run as r
    return r(cfgs, d)


# ----------------------------------------------------------------------------- reassignment

def test_reassignment_config_needs_a_fixed_random_split():
    with pytest.raises(ConfigError):
        _traj(part="redrawn_random", reassign={"mode": "abrupt", "start": 2, "fraction": 1.0})
    with pytest.raises(ConfigError):
        _traj(reassign={"mode": "periodic", "start": 0, "period": 0, "fraction": 0.5})


def test_abrupt_exchange_moves_the_smaller_side_and_keeps_counts(tmp_path):
    p = _traj(reassign={"mode": "abrupt", "start": 3, "fraction": 1.0})
    rd = _run(p, tmp_path)
    i0 = torch.load(rd / "spec_partition.pt", weights_only=False)
    i1 = torch.load(rd / "spec_partition_final.pt", weights_only=False)
    assert int(i0.sum()) == int(i1.sum())
    nb = int((i0 == 0).sum())
    assert int(((i0 == 0) & (i1 == 0)).sum()) == 0                 # every old branch-b example moved
    assert int((i0 != i1).sum()) == 2 * min(nb, int(i0.sum()))
    res = read_json(rd / "summary.json")["result"]
    ev = res["spec_reassign"]["events"][0]
    assert ev["kind"] == "exchange" and ev["examples_moved"] == 2 * nb
    assert ev["moved_fraction_of_training_set"] == pytest.approx(2 * nb / 256)
    assert res["spec_reassign"]["ever_moved_fraction"] == pytest.approx(2 * nb / 256)


@pytest.mark.parametrize("mode", ["periodic", "periodic_redraw", "ramp"])
def test_scheduled_reassignment_is_deterministic_and_resumes_identically(tmp_path, mode):
    from resume_harness import compare_interrupted
    p = _traj(reassign={"mode": mode, "start": 1, "period": 2, "fraction": 0.5})
    r = compare_interrupted(p, tmp_path / "resume")
    assert r["interrupted_at_polls"] and r["equal"], r
    tmp_path = tmp_path / "resume"
    a = torch.load(tmp_path / "A" / "runs" / run_id(p[-1]) / "spec_partition_final.pt", weights_only=False)
    b = torch.load(tmp_path / "B" / "runs" / run_id(p[-1]) / "spec_partition_final.pt", weights_only=False)
    i0 = torch.load(tmp_path / "A" / "runs" / run_id(p[-1]) / "spec_partition.pt", weights_only=False)
    assert torch.equal(a, b) and int(a.sum()) == int(i0.sum()) and not torch.equal(a, i0)


def test_swapping_two_branches_and_their_masks_is_a_renaming():
    """The 'swap identities and assignments together' control: exchanging two equal branches' parameters (and,
    in training, their masks) leaves the function unchanged; the substantive intervention swaps assignments only."""
    from cop.graph.builders import build_mlp
    from cop.graph import edits as E
    from cop.utils import torch_gen
    from cop.data.registry import load_bundle
    b = load_bundle(T.DATA, device="cpu")
    net = build_mlp(b.train.X["x"].shape[1], [8, 8], b.out_dim, torch_gen(0, "init"))
    G = E.insert_group(net, E.cut_at(net, "post_act", 0), torch_gen(0, "insertion", "g"), slot="spec/G", rnd=1)
    ba = E.add_branch(net, G, torch_gen(0, "insertion", "a"), width=4, slot="spec/r1/a", specialize_mask="spec_a")
    bb = E.add_branch(net, G, torch_gen(0, "insertion", "b"), width=4, slot="spec/r1/b", specialize_mask="spec_b")
    gen = torch.Generator().manual_seed(1)
    with torch.no_grad():
        for p_ in net.parameters():
            p_.add_(0.1 * torch.randn(p_.shape, generator=gen))
    X = {k: v[:64] for k, v in b.train.X.items()}
    y0 = net(X).detach().clone()
    mods = lambda bid: sorted({net.nodes[n].pkey for n in net.implants[bid].nodes if net.nodes[n].pkey},
                              key=lambda k: net.nodes[[n for n in net.implants[bid].nodes
                                                       if net.nodes[n].pkey == k][0]].role)
    with torch.no_grad():
        for ka, kb in zip(mods(ba), mods(bb)):
            sa = {k: v.clone() for k, v in net.mods[ka].state_dict().items()}
            net.mods[ka].load_state_dict(net.mods[kb].state_dict())
            net.mods[kb].load_state_dict(sa)
    net._plan = None
    assert torch.allclose(net(X), y0, atol=1e-6, rtol=0)


# ----------------------------------------------------------------------------- membership damage, hybrids

def _diss(traj_cfg, extra=None, hybrid=None, donor=None, stage=None):
    d = {"method": "abrupt", "speed_updates": 0, "post_updates": 4, "path_full_eval": True}
    if hybrid:
        d["hybrid"] = hybrid
    parents = {"trajectory": run_id(traj_cfg)}
    if donor is not None:
        parents["donor"] = run_id(donor)
    cfg = {"kind": "dissipation", "data": traj_cfg["data"], "model": traj_cfg["model"], "train": traj_cfg["train"],
           "growth": traj_cfg["growth"], "seeds": traj_cfg["seeds"], "parents": parents, "dissipation": d,
           **({"tags": {"parent_stage": stage}} if stage else {}), **(extra or {})}
    return resolve(cfg)


def test_frozen_sweep_splits_branch_deletion_damage_by_membership(tmp_path):
    p = _traj()
    d = _diss(p[-1])
    rd = _run(p + [d], tmp_path)
    fs = read_json(rd / "dissipation_result.json")["frozen_weight_sweep"]
    dm = fs["damage_by_membership"]
    assert dm and all(v["own_n"] + v["other_n"] == 256 for v in dm.values())
    assert {v["side"] for v in dm.values()} == {"a", "b"}
    assert all("own_err_increase" in v and "other_loss_increase" in v for v in dm.values())


def test_redrawn_partition_has_no_membership_damage(tmp_path):
    p = _traj(part="redrawn_random")
    rd = _run(p + [_diss(p[-1])], tmp_path)
    assert "damage_by_membership" not in read_json(rd / "dissipation_result.json")["frozen_weight_sweep"]


def test_fixed_and_redrawn_lineages_share_their_insertion_state(tmp_path):
    from cop.graph.graph import GraphNet
    pa, pb = _traj(), _traj(part="redrawn_random")
    _run(pa, tmp_path)
    _run(pb[-1:], tmp_path)
    ga = torch.load(tmp_path / "runs" / run_id(pa[-1]) / "ckpt" / "post_insert_r1.pt", weights_only=False)
    gb = torch.load(tmp_path / "runs" / run_id(pb[-1]) / "ckpt" / "post_insert_r1.pt", weights_only=False)
    A, B = GraphNet.from_checkpoint(ga["model"]), GraphNet.from_checkpoint(gb["model"])
    sa, sb = A.state_dict(), B.state_dict()
    assert sa.keys() == sb.keys() and all(torch.equal(sa[k], sb[k]) for k in sa)


def test_hybrid_copies_exactly_the_selected_implants(tmp_path):
    from cop.graph.graph import GraphNet
    from cop.experiments.dissipation import make_hybrid
    pa, pb = _traj(), _traj(part="redrawn_random")
    _run(pa, tmp_path)
    _run(pb[-1:], tmp_path)
    load = lambda c, st: GraphNet.from_checkpoint(torch.load(tmp_path / "runs" / run_id(c) / "ckpt" / f"{st}.pt",
                                                             weights_only=False)["model"])
    R, D = load(pa[-1], "final"), load(pb[-1], "final")
    R0 = load(pa[-1], "final")
    info = make_hybrid(R, D, ["spec/r1/a"])
    assert info["slots"] == ["spec/r1/a"] and info["values_copied"] > 0
    chosen = set(info["modules"])
    sR, sD, s0 = R.state_dict(), D.state_dict(), R0.state_dict()
    for k in sR:
        if any(k.startswith(f"mods.{m}.") for m in chosen):
            assert torch.equal(sR[k], sD[k]), k
        else:
            assert torch.equal(sR[k], s0[k]), k
    with pytest.raises(Exception):
        make_hybrid(load(pa[-1], "final"), D, ["no/such/slot"])


def test_hybrid_dissipation_records_the_swap_and_self_swap_is_identity(tmp_path):
    pa, pb = _traj(), _traj(part="redrawn_random")
    plain = _diss(pa[-1])
    self_swap = _diss(pa[-1], hybrid={"donor_role": "donor", "donor_stage": "final", "slots": ["all"]}, donor=pa[-1])
    cross = _diss(pa[-1], hybrid={"donor_role": "donor", "donor_stage": "final", "slots": ["all"]}, donor=pb[-1])
    _run(pa + [plain], tmp_path)
    _run(pb[-1:], tmp_path)
    r_self = read_json(_run([self_swap], tmp_path) / "dissipation_result.json")
    r_x = read_json(_run([cross], tmp_path) / "dissipation_result.json")
    r_0 = read_json(tmp_path / "runs" / run_id(plain) / "dissipation_result.json")
    assert r_self["hybrid"]["receiver_minus_donor_rel_l2"] == 0.0
    assert r_self["frozen_weight_sweep"]["intact"] == r_0["frozen_weight_sweep"]["intact"]
    assert r_x["hybrid"]["receiver_minus_donor_rel_l2"] > 0
    assert r_x["frozen_weight_sweep"]["intact"] != r_0["frozen_weight_sweep"]["intact"]


def test_ancestral_hybrid_from_an_earlier_snapshot(tmp_path):
    p = _traj(snapshot_at=[9])
    young_into_old = _diss(p[-1], hybrid={"donor_role": "donor", "donor_stage": "post_insert_r2", "slots": ["all"]},
                           donor=p[-1])
    old_into_young = _diss(p[-1], hybrid={"donor_role": "donor", "donor_stage": "final", "slots": ["all"]},
                           donor=p[-1], stage="post_insert_r2")
    mid = _diss(p[-1], stage="snap_9")
    _run(p, tmp_path)
    for c in (young_into_old, old_into_young, mid):
        r = read_json(_run([c], tmp_path) / "dissipation_result.json")
        assert r["frozen_weight_sweep"]["intact"]


def test_hybrid_config_validation():
    p = _traj()
    with pytest.raises(ConfigError):
        _diss(p[-1], hybrid={"donor_role": "donor", "donor_stage": "final", "slots": ["all"]})   # no donor parent
    with pytest.raises(ConfigError):
        _diss(p[-1], hybrid={"donor_role": "donor", "donor_stage": "final", "slots": []}, donor=p[-1])


# ----------------------------------------------------------------------------- interface recoding

def test_relabels_are_bijections_and_gf2_inverse_is_exact():
    from cop.cop_pegs.recode import Relabel, gf2_inverse
    g = torch.Generator().manual_seed(0)
    for kind in ("identity", "bitperm", "bitperm_symmetric", "xor_chain", "gf2_random", "codeword_perm"):
        r = Relabel(kind, 6, g)
        N = 64
        assert torch.equal(torch.sort(r.fwd).values, torch.arange(N)) and torch.equal(r.inv[r.fwd], torch.arange(N))
    A = torch.tensor([[1, 1, 0], [0, 1, 1], [0, 0, 1]], dtype=torch.uint8)
    Ai = gf2_inverse(A)
    assert torch.equal((A.long() @ Ai.long()) % 2, torch.eye(3, dtype=torch.long))
    assert gf2_inverse(torch.tensor([[1, 1], [1, 1]], dtype=torch.uint8)) is None


def test_xor_chain_turns_a_copied_bit_into_a_parity():
    """(a, b) -> (a, a xor b): no information lost, but reading b now needs two bits."""
    from cop.cop_pegs.recode import Relabel, index_to_bits
    r = Relabel("xor_chain", 2, None)
    b = index_to_bits(r.fwd, 2)
    src = index_to_bits(torch.arange(4), 2)
    assert torch.equal(b[:, 0], src[:, 0]) and torch.equal(b[:, 1], src[:, 0] ^ src[:, 1])


LQ = {"name": "later_query", "n_train": 256, "n_val": 64, "n_test": 64, "params": {"n_bits": 10, "task_bits": 1}}
LQM = {"family": "mlp", "width": 16, "depth": 4}


def _chain():
    return T.cop({"task_kind": "chain", "n_pearls": 3, "global_updates": 20}, {"dim": 2, "mode": "uniform", "bits": 2},
                 data=LQ, model=LQM)


def test_recode_job_exact_control_relabelled_fits_and_compensation(tmp_path):
    b, c = _chain()
    r = resolve({"kind": "cop", "data": LQ, "model": LQM, "train": T.TRAIN, "peg": c["peg"],
                 "cop": {**c["cop"], "task_kind": "recode", "recode_updates": 60, "recode_eval_every": 20,
                         "recode_relabels": ["identity", "xor_chain", "codeword_perm"], "recode_relabel_seeds": 1,
                         "recode_classes": ["linear", "mlp16"], "recode_fit_seeds": 1, "recode_regimes": ["observed"]},
                 "seeds": c["seeds"], "parents": {"baseline": run_id(b), "chain": run_id(c)},
                 "design": {"family": "RC", "variant": "v", "arm": "recode_treated", "contrast": "RC|c|v"}})
    rd = _run([b, c, r], tmp_path)
    j = read_json(rd / "recode_result.json")
    assert j["pearls"], j
    pe = j["pearls"][0]
    assert all(v == 1.0 for v in pe["map_agreement"].values()) and j["checks"]["passed"]
    rows = [x for x in j["rows"] if "class" in x]
    kinds = {(x["relabel"], x["side"], x["class"]) for x in rows}
    assert ("identity", "none", "linear") in kinds and ("codeword_perm", "both", "mlp16") in kinds
    for x in rows:
        assert x["status"] in ("exact", "censored")
        assert 0.0 <= x["final_exact_weighted"] <= 1.0 and x["censored"] == (x["first_exact_update"] is None)
        if x["relabel"] == "codeword_perm" and x["side"] in ("out", "both"):
            assert x["compensation_spec_bits_out"] == (1 << pe["out_bits"]) * pe["out_bits"]
            assert x["compensation_table_bits_out"] == 2 * (1 << pe["out_bits"]) * pe["out_bits"]
        if x["relabel"] == "identity":
            assert x["compensation_spec_bits_in"] == x["compensation_spec_bits_out"] == 0
    import csv
    from cop.analysis.summarize import summarize
    from cop import cli
    res = summarize(tmp_path, [], tmp_path / "summary")
    assert not cli.summary_errors(res), cli.summary_errors(res)
    rc = list(csv.DictReader(open(tmp_path / "summary" / "strengthening" / "s19_recode.csv")))
    assert len(rc) == len(rows) and {x["history"] for x in rc} == {"treated"}


def test_recode_reads_a_scratch_trained_endpoint_too(tmp_path):
    b, c = T.cop({"task_kind": "chain", "n_pearls": 3, "global_updates": 20}, {"dim": 2, "mode": "uniform", "bits": 2},
                 data=LQ, model=LQM)
    m = resolve({"kind": "continue", "data": LQ, "model": LQM, "train": {**T.TRAIN, "quant_range": "ema"},
                 "seeds": {"optimizer": 0}, "parents": {"baseline": run_id(b), "treated": run_id(c)},
                 "continue": {"start": "treated", "start_stage": "export", "reinit": True, "budget": "parent_compute",
                              "budget_parent": "treated", "budget_add_f0": True}})
    r = resolve({"kind": "cop", "data": LQ, "model": LQM, "train": T.TRAIN, "peg": c["peg"],
                 "cop": {**c["cop"], "task_kind": "recode", "recode_updates": 40, "recode_eval_every": 20,
                         "recode_relabels": ["identity", "gf2_random"], "recode_relabel_seeds": 1,
                         "recode_sides": ["out"], "recode_classes": ["mlp16"], "recode_fit_seeds": 1,
                         "recode_regimes": ["observed"]},
                 "seeds": c["seeds"], "parents": {"baseline": run_id(b), "chain": run_id(m)}})
    rd = _run([b, c, m, r], tmp_path)
    j = read_json(rd / "recode_result.json")
    assert j["checks"]["passed"] and len([x for x in j["rows"] if "class" in x]) == 2


def test_wave17_panel_structure():
    from cop.orchestration.manifest import generate
    B = generate([17], "smoke")
    ents = [e["cfg"] for e in B.entries.values()]
    hy = [c for c in ents if c["kind"] == "dissipation" and c["dissipation"]["hybrid"]["donor_role"]]
    # cross-lineage swaps: receiver and donor are different trajectories of the same f0 and insertion seed
    for c in hy:
        rt, dn = c["parents"]["trajectory"], c["parents"]["donor"]
        tr, dc = B.entries[rt]["cfg"], B.entries[dn]["cfg"]
        assert tr["parents"]["baseline"] == dc["parents"]["baseline"]
        assert tr["seeds"]["insertion"] == dc["seeds"]["insertion"]
        assert {k: v for k, v in tr["growth"].items() if k != "spec_partition"} == \
               {k: v for k, v in dc["growth"].items() if k != "spec_partition"}
    assert len({c["design"]["arm"] for c in hy if c["design"]["arm"].startswith("swap_")}) == 9
    ra = [c for c in ents if c["kind"] == "trajectory" and c["growth"]["spec_reassign"]["mode"] != "none"]
    assert {c["growth"]["spec_reassign"]["mode"] for c in ra} == {"abrupt", "abrupt_redraw", "periodic", "ramp",
                                                                  "periodic_redraw"}
    rc = [c for c in ents if c["kind"] == "cop" and c["cop"]["task_kind"] == "recode"]
    assert {c["design"]["arm"] for c in rc} == {"recode_treated", "recode_abrupt_calibrated_interfaces",
                                                "recode_M2_ema", "recode_M2_fixed"}
    assert {c["data"]["data_seed"] for c in ents if c["kind"] != "baseline"} == {0, 201, 202}


def test_swap_and_reassignment_tables_through_the_summary(tmp_path):
    import csv
    from cop.analysis.summarize import summarize
    from cop import cli
    pa, pb = _traj(), _traj(part="redrawn_random")
    D = lambda arm, contrast, fam="SW": {"family": fam, "variant": "v", "arm": arm, "contrast": contrast,
                                         "budget_panel": "updates"}
    plain = _diss(pa[-1], extra={"design": D("treated", "SW|c|fixed")})
    cross = _diss(pa[-1], hybrid={"donor_role": "donor", "donor_stage": "final", "slots": ["spec/r1/a"]},
                  donor=pb[-1], extra={"design": D("swap_r1a", "SW|c|fixed")})
    ra = _traj(reassign={"mode": "abrupt", "start": 3, "fraction": 1.0})
    ra_d = _diss(ra[-1], extra={"design": D("treated", "RA|c|x", "RA")})
    _run(pa + [plain], tmp_path)
    _run(pb[-1:] + [cross], tmp_path)
    _run(ra[-1:] + [ra_d], tmp_path)
    res = summarize(tmp_path, [], tmp_path / "summary")
    assert not cli.summary_errors(res), cli.summary_errors(res)
    st = tmp_path / "summary" / "strengthening"
    sw = list(csv.DictReader(open(st / "s19_swaps.csv")))
    assert {r["arm"] for r in sw} == {"treated", "swap_r1a"}
    x = next(r for r in sw if r["arm"] == "swap_r1a")
    assert x["swapped_slots"] == "spec/r1/a" and x["frozen_intact_test_err"] != "" and x["repaired_test_err"] != ""
    rr = list(csv.DictReader(open(st / "s19_reassignment.csv")))
    assert rr and rr[0]["reassign_mode"] == "abrupt" and rr[0]["end_assignment_mean_own_err_increase"] != ""


def test_ramp_moves_a_cumulative_share_of_the_original_smaller_side(tmp_path):
    p = _traj(reassign={"mode": "ramp", "start": 0, "period": 2, "fraction": 0.5})
    rd = _run(p, tmp_path)
    i0 = torch.load(rd / "spec_partition.pt", weights_only=False)
    i1 = torch.load(rd / "spec_partition_final.pt", weights_only=False)
    n_small = min(int(i0.sum()), int((i0 == 0).sum()))
    moved_b = int(((i0 == 0) & (i1 == 1)).sum())
    assert moved_b == round(0.5 * n_small) and int(i1.sum()) == int(i0.sum())


def test_swapped_branches_use_the_donor_lineage_split(tmp_path):
    import csv
    pa, pb = _traj(), _traj(part="redrawn_random")
    H = {"donor_role": "donor", "donor_stage": "final", "slots": ["spec/r1/a"]}
    D = lambda arm: {"family": "SW", "variant": "v", "arm": arm, "contrast": "SW|c|x", "budget_panel": "updates"}
    fixed_gets_redrawn = _diss(pa[-1], hybrid=H, donor=pb[-1], extra={"design": D("swap_into_fixed")})
    redrawn_gets_fixed = _diss(pb[-1], hybrid=H, donor=pa[-1], extra={"design": D("swap_into_redrawn")})
    plain = _diss(pa[-1], extra={"design": D("treated")})
    _run(pa + [plain], tmp_path)
    _run(pb[-1:], tmp_path)
    j1 = read_json(_run([fixed_gets_redrawn], tmp_path) / "dissipation_result.json")
    j2 = read_json(_run([redrawn_gets_fixed], tmp_path) / "dissipation_result.json")
    sw1 = j1["hybrid"]["implants"][0]
    d1 = j1["frozen_weight_sweep"]["damage_by_membership"]
    assert "not_applicable" in d1[sw1] and all("own_err_increase" in v for t, v in d1.items() if t != sw1)
    d2 = j2["frozen_weight_sweep"]["damage_by_membership"]
    sw2 = j2["hybrid"]["implants"][0]
    assert d2[sw2]["split_source"].startswith("donor") and "own_err_increase" in d2[sw2]
    assert all("not_applicable" in v for t, v in d2.items() if t != sw2)     # the redrawn receiver's own branches
    from cop.analysis.summarize import summarize
    summarize(tmp_path, [], tmp_path / "summary")
    rows = list(csv.DictReader(open(tmp_path / "summary" / "strengthening" / "s15_frozen_weight_sweep.csv")))
    assert all(r["hybrid_donor_stage"] == "" for r in rows if r["arm"] == "treated")
    assert all(r["hybrid_donor_stage"] == "final" for r in rows if r["arm"].startswith("swap_"))


# ----------------------------------------------------------------------------- v20: stage and donor accounting

def test_stage_and_donor_accounting(tmp_path):
    from cop.experiments.continuation import chain_work_dir, chain_work_parts, stage_work
    pa, pb = _traj(), _traj(part="redrawn_random")              # 6 updates per round, 2 rounds: 12
    young = _diss(pa[-1], stage="post_insert_r2")                 # 4 repair updates
    cross = _diss(pa[-1], hybrid={"donor_role": "donor", "donor_stage": "final", "slots": ["all"]}, donor=pb[-1])
    self_swap = _diss(pa[-1], hybrid={"donor_role": "donor", "donor_stage": "final", "slots": ["all"]}, donor=pa[-1])
    early_into_late = _diss(pa[-1], hybrid={"donor_role": "donor", "donor_stage": "post_insert_r2", "slots": ["all"]},
                            donor=pa[-1])
    late_into_early = _diss(pa[-1], hybrid={"donor_role": "donor", "donor_stage": "final", "slots": ["all"]},
                            donor=pa[-1], stage="post_insert_r2")
    _run(pa, tmp_path)
    _run(pb[-1:], tmp_path)
    for c in (young, cross, self_swap, early_into_late, late_into_early):
        _run([c], tmp_path)
    R = tmp_path / "runs"
    assert stage_work(R / run_id(pa[-1]), "post_insert_r2")["updates"] == 6
    assert chain_work_dir(R / run_id(young))["updates"] == 10                 # 6 + 4, not 12 + 4
    p = chain_work_parts(R / run_id(cross))
    assert (p["own"]["updates"], p["source_lineage"]["updates"], p["donor_incremental"]["updates"],
            p["total"]["updates"]) == (4, 12, 12, 28)
    assert chain_work_dir(R / run_id(self_swap))["updates"] == 16             # the source once
    assert chain_work_dir(R / run_id(early_into_late))["updates"] == 16
    assert chain_work_dir(R / run_id(late_into_early))["updates"] == 16       # the trajectory through its end
    assert chain_work_parts(R / run_id(late_into_early))["donor_incremental"]["updates"] == 6
    w = chain_work_dir(R / run_id(cross))
    assert w["accounting_complete"] and w["examples"] == 28 * T.TRAIN["batch_size"]
    missing = stage_work(R / run_id(pa[-1]), "no_such_stage")
    assert missing["accounting_complete"] is False and missing["updates"] == 0
