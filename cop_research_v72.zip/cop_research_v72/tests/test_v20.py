"""v20: tests for the fixes of the v19 review (recoding validity, numerics, persistence / resume / reload,
accounting is in test_v19, masks and controls, launcher)."""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path
from unittest.mock import patch

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import tiny_configs as T  # noqa: E402
from cop.config import resolve, run_id, ConfigError  # noqa: E402
from cop.utils import read_json  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
LQ = {"name": "later_query", "n_train": 256, "n_val": 64, "n_test": 64, "params": {"n_bits": 10, "task_bits": 1}}
LQM = {"family": "mlp", "width": 16, "depth": 4}


def _run(cfgs, d, device="cpu"):
    from cop.orchestration.runner import run_job, status_of
    st = [run_job(c, d, {"device": device}) for c in cfgs]
    return st, status_of(d, run_id(cfgs[-1]))


def _recode(**over):
    b, c = T.cop({"task_kind": "chain", "n_pearls": 3, "global_updates": 20}, {"dim": 2, "mode": "uniform", "bits": 2},
                 data=LQ, model=LQM)
    rc = {"task_kind": "recode", "recode_updates": 30, "recode_eval_every": 10,
          "recode_relabels": ["identity", "bitperm", "bitperm_symmetric", "xor_chain"], "recode_relabel_seeds": 1,
          "recode_classes": ["linear", "mlp8"], "recode_fit_seeds": 1, "recode_sides": ["out", "both"],
          "recode_regimes": ["observed", "full_alphabet"], **over}
    r = resolve({"kind": "cop", "data": LQ, "model": LQM, "train": T.TRAIN, "peg": c["peg"],
                 "cop": {**c["cop"], **rc}, "seeds": c["seeds"], "parents": {"baseline": run_id(b), "chain": run_id(c)},
                 "design": {"family": "RC", "variant": "v", "arm": "recode_treated", "contrast": "RC|c|v"}})
    return [b, c, r]


# ----------------------------------------------------------------------------- 1. validity checks

def test_equal_risk_but_different_predictions_fails_the_function_check():
    from cop.cop_pegs.recode import compare_predictions
    a = torch.tensor([-2., -1., 1., 2.])[:, None]
    assert float((a ** 2).mean()) == float(((-a) ** 2).mean())           # same MSE against zero targets
    c = compare_predictions(-a, a, "regression", 1e-5)
    assert not c["passed"] and c["max_abs_diff"] == 4.0
    assert compare_predictions(a.clone(), a, "regression", 1e-5)["passed"]


def test_recode_job_passes_its_controls_and_the_checker(tmp_path):
    cfgs = _recode()
    st, s = _run(cfgs, tmp_path)
    assert st[-1] == "complete", s
    rd = tmp_path / "runs" / run_id(cfgs[-1])
    j = read_json(rd / "recode_result.json")
    ch = j["checks"]
    assert ch["passed"] and ch["lp_controls"]["passed"] and ch["symmetry_control"]["passed"]
    assert ch["symmetry_control"]["n"] > 0
    pc = ch["pearls"]["1"]
    assert pc["map_matches_network_codes"] and pc["exact_table_reproduces_predictions"]
    assert all(x["identity_holds"] and x["splice_reproduces"] for x in pc["transformed_identities"].values())
    fits = [r for r in j["rows"] if "class" in r]
    assert len(fits) == j["n_planned_fits"] == read_json(rd / "recode_plan.json")["n_fits"]
    lin = [r for r in fits if r["class"] == "linear"]
    assert lin and all("lp_all_bits_separable" in r for r in lin)
    m = tmp_path / "m.jsonl"
    m.write_text("\n".join(json.dumps({"run_id": run_id(c), "cfg": c}) for c in cfgs) + "\n")
    r = subprocess.run([sys.executable, str(ROOT / "audit_v8/tools/check_results.py"), str(tmp_path),
                        str(tmp_path / "chk.json"), "--manifest", str(m), "--recode"], capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr
    rep = read_json(tmp_path / "chk.json")
    assert rep["recode"]["passed"] == rep["recode"]["complete_checked"] == 1


def test_a_corrupted_exact_splice_makes_the_run_invalid_and_fails_the_checker(tmp_path):
    from cop.cop_pegs import recode
    cfgs = _recode()
    _run(cfgs[:2], tmp_path)
    orig = recode.splice

    def broken(*a, **k):
        g = orig(*a, **k)
        g.register_forward_hook(lambda mod, inp, out: out + 10.0)
        return g
    with patch.object(recode, "splice", broken):
        st, s = _run(cfgs[-1:], tmp_path)
    assert s.get("status") == "invalid", s
    rd = tmp_path / "runs" / run_id(cfgs[-1])
    ch = read_json(rd / "recode_checks.json")
    assert not ch["passed"] and not ch["pearls"]["1"]["exact_table_reproduces_predictions"]
    assert not (rd / "recode_plan.json").exists()                         # nothing was fitted
    m = tmp_path / "m.jsonl"
    m.write_text("\n".join(json.dumps({"run_id": run_id(c), "cfg": c}) for c in cfgs) + "\n")
    r = subprocess.run([sys.executable, str(ROOT / "audit_v8/tools/check_results.py"), str(tmp_path),
                        str(tmp_path / "chk.json"), "--manifest", str(m)], capture_output=True, text=True)
    assert r.returncode != 0


def test_recode_config_rejects_empty_or_invalid_panels():
    for over in ({"recode_relabels": []}, {"recode_classes": ["mlp0"]}, {"recode_fit_seeds": 0},
                 {"recode_lr": float("nan")}, {"recode_regimes": ["everything"]}, {"recode_max_bits": 20},
                 {"recode_relabels": ["bitperm_symmetric"]}):
        with pytest.raises(ConfigError):
            _recode(**over)


# ----------------------------------------------------------------------------- 2. numerical guards

def test_non_finite_inputs_are_rejected_and_unstable_fits_are_numerical_failures():
    from cop.cop_pegs.recode import fit_replacement, make_replacement
    g = torch.Generator().manual_seed(0)
    with pytest.raises(ValueError):
        fit_replacement("linear", torch.full((2, 2), float("nan")), torch.zeros(2, 2), torch.ones(2), 2, .01, 1, g, "cpu")
    with pytest.raises(ValueError):
        fit_replacement("linear", torch.zeros(0, 2), torch.zeros(0, 2), torch.ones(0), 2, .01, 1, g, "cpu")
    with pytest.raises(ValueError):
        fit_replacement("linear", torch.zeros(2, 2), torch.full((2, 2), 0.5), torch.ones(2), 2, .01, 1, g, "cpu")
    m = make_replacement("linear", 2, 2, g)
    with torch.no_grad():
        m.weight.fill_(float("inf"))
    f = fit_replacement("linear", torch.ones(2, 2), torch.zeros(2, 2), torch.ones(2), 5, .01, 1, None, "cpu", init=m)
    assert f["status"] == "numerical_failure" and f["first_exact_update"] is None and f["final_exact_unweighted"] is None
    m = make_replacement("linear", 2, 2, g)
    # deliberately unstable: a step size that overflows float64 (the fits run in float64 from v20.1)
    f = fit_replacement("linear", torch.ones(2, 2), torch.zeros(2, 2), torch.ones(2), 3, 1e308, 1, None, "cpu", init=m)
    assert f["status"] == "numerical_failure" and f["failure"]["cause"] and f["final_exact_unweighted"] is None
    ok = fit_replacement("linear", torch.tensor([[0., 1.], [1., 0.]]), torch.tensor([[0., 1.], [1., 0.]]),
                         torch.ones(2), 200, .05, 10, g, "cpu")
    assert ok["status"] == "exact" and ok["final_exact_unweighted"] == 1.0


def test_lp_separability_controls():
    from cop.cop_pegs.recode import lp_controls, lp_separable, index_to_bits
    assert lp_controls()["passed"]
    X = index_to_bits(torch.arange(8), 3)
    assert lp_separable(X, X[:, 0] & X[:, 1]) and not lp_separable(X, X[:, 0] ^ X[:, 1] ^ X[:, 2])


def test_symmetric_permutation_reproduces_the_trajectory():
    from cop.cop_pegs.recode import fit_replacement, make_replacement, permute_model
    g = torch.Generator().manual_seed(1)
    X = (torch.rand(40, 5, generator=g) < 0.5).to(torch.uint8)
    Y = (torch.rand(40, 4, generator=g) < 0.5).to(torch.uint8)
    w = torch.rand(40, generator=g) + 0.1
    pi, po = torch.tensor([3, 0, 4, 1, 2]), torch.tensor([2, 3, 0, 1])
    for cls in ("linear", "mlp8"):
        m0 = make_replacement(cls, 5, 4, torch.Generator().manual_seed(2))
        a = fit_replacement(cls, X, Y, w, 50, .05, 5, None, "cpu", init=permute_model(m0, None, None))
        b = fit_replacement(cls, X[:, pi], Y[:, po], w, 50, .05, 5, None, "cpu", init=permute_model(m0, pi, po))
        la, lb = [c["loss"] for c in a["curve"]], [c["loss"] for c in b["curve"]]
        assert max(abs(x - y) for x, y in zip(la, lb)) < 1e-5


# ----------------------------------------------------------------------------- 3. persistence, resume, reload

def test_recode_resumes_inside_and_between_fits_identically(tmp_path):
    from resume_harness import compare_interrupted
    rep = compare_interrupted(_recode(recode_updates=40), tmp_path / "resume", fractions=(0.2, 0.55, 0.8))
    assert rep["interrupted_at_polls"] and rep["equal"], rep


def test_fresh_reload_checks_every_fit_and_fails_on_an_altered_artifact(tmp_path):
    cfgs = _recode()
    st, s = _run(cfgs, tmp_path)
    assert st[-1] == "complete", s
    r = subprocess.run([sys.executable, str(ROOT / "audit_v5/tools/fresh_reload.py"), str(tmp_path),
                        str(tmp_path / "rl.json"), "--device", "cpu"], capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr
    sm = read_json(tmp_path / "rl.json")["summary"]
    assert sm["recode_fits_checked"] + sm["recode_fits_skipped_numerical_failure"] == sm["recode_fits_expected"] > 0
    rd = tmp_path / "runs" / run_id(cfgs[-1])
    f = sorted((rd / "recode" / "fits").glob("*.pt"))[0]
    a = torch.load(f, weights_only=False)
    a["state_dict"] = {k: v + 1.0 for k, v in a["state_dict"].items()}
    torch.save(a, f)
    r = subprocess.run([sys.executable, str(ROOT / "audit_v5/tools/fresh_reload.py"), str(tmp_path),
                        str(tmp_path / "rl2.json"), "--device", "cpu"], capture_output=True, text=True)
    assert r.returncode != 0
    f.unlink()
    from cop.cop_pegs.recode import verify_recode_result
    assert not verify_recode_result(rd)["passed"]


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA device required (run scripts/19 on the GPU)")
def test_recode_cuda_job_passes_its_controls_and_reloads(tmp_path):
    cfgs = _recode()
    st, s = _run(cfgs, tmp_path, device="cuda")
    assert st[-1] == "complete", s
    j = read_json(tmp_path / "runs" / run_id(cfgs[-1]) / "recode_result.json")
    assert j["checks"]["passed"]
    r = subprocess.run([sys.executable, str(ROOT / "audit_v5/tools/fresh_reload.py"), str(tmp_path),
                        str(tmp_path / "rl.json"), "--device", "cuda"], capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr


# ----------------------------------------------------------------------------- 5. removal masks and policies

def _spec_traj(part="random_matched", **kw):
    from test_v19 import _traj
    return _traj(part=part, **kw)


def _lin_diss(traj_cfg, **over):
    from test_v19 import _diss
    d = _diss(traj_cfg)
    dd = {**d["dissipation"], "method": "linear", "speed_updates": 3, "post_updates": 3, **over}
    return resolve({**{k: v for k, v in d.items() if k != "dissipation"}, "dissipation": dd})


def _branch_params(g, side):
    return [p for t, imp in g.implants.items() if imp.slot.endswith(f"/{side}") and "spec/" in imp.slot
            for n in imp.nodes if g.nodes[n].pkey for p in g.mods[g.nodes[n].pkey].parameters()]


def test_masks_present_suppress_and_absent_release_branch_gradients(tmp_path):
    import torch.nn.functional as F
    from cop.graph.graph import GraphNet
    from cop.data.registry import load_bundle
    from cop.experiments.trajectory import spec_masks
    p = _spec_traj()
    rd = _run(p, tmp_path)[1] and tmp_path / "runs" / run_id(p[-1])
    g = GraphNet.from_checkpoint(torch.load(rd / "ckpt" / "final.pt", weights_only=False)["model"]).double()
    b = load_bundle(p[-1]["data"], device="cpu")
    b.train.aux["_spec_random"] = torch.load(rd / "spec_partition_final.pt", weights_only=False).long()
    batch = b.train.index(torch.arange(64))
    X = {k: v.double() for k, v in batch.X.items()}
    ctx = spec_masks(b, mode="random_matched")(batch)
    a = ctx["grad_masks"]["spec_a"].bool()
    assert 0 < int(a.sum()) < 64

    def grads(loss, side):
        g.zero_grad()
        loss.backward()
        return [q.grad.clone() for q in _branch_params(g, side)]
    ce = lambda out: F.cross_entropy(out, batch.y.long(), reduction="none")
    masked_a = grads(ce(g(X, dict(ctx))).mean(), "a")
    ref_a = grads(ce(g(X))[a].sum() / 64, "a")                # only branch-a examples, same normaliser
    assert all(torch.allclose(x, y, atol=1e-12) for x, y in zip(masked_a, ref_a))
    masked_b = grads(ce(g(X, dict(ctx))).mean(), "b")
    ref_b = grads(ce(g(X))[~a].sum() / 64, "b")
    assert all(torch.allclose(x, y, atol=1e-12) for x, y in zip(masked_b, ref_b))
    released = grads(ce(g(X)).mean(), "a")                    # no masks: every example reaches the branch
    assert any(not torch.allclose(x, y, atol=1e-9) for x, y in zip(released, masked_a))


def test_removal_policies_are_recorded_and_retained_masks_change_training(tmp_path):
    from test_v19 import _diss
    p = _spec_traj()
    rel = _lin_diss(p[-1])
    ret = _lin_diss(p[-1], removal_masks="retained")
    hold = _lin_diss(p[-1], gate_schedule="hold")
    _run(p + [rel], tmp_path)
    out = {}
    for nm, c in (("rel", rel), ("ret", ret), ("hold", hold)):
        _run([c], tmp_path)
        out[nm] = read_json(tmp_path / "runs" / run_id(c) / "dissipation_result.json")
    assert out["rel"]["removal_policy"]["masks"] == "released"
    assert out["ret"]["removal_policy"]["masks"] == "retained" and "membership" in out["ret"]["removal_policy"]
    assert out["hold"]["removal_policy"]["gate_schedule"] == "hold"
    assert all(o["removal_policy"]["optimizer"] == "reset_each_phase" for o in out.values())
    for o in out.values():
        assert [pt["tag"] for pt in o["path"]].count("end_transition_0") == 1
    tags = lambda o: [pt for pt in o["path"] if pt["tag"] == "end_transition_0"][0]["val_risk"]
    assert tags(out["rel"]) != tags(out["ret"]) or out["rel"]["final_risk"] != out["ret"]["final_risk"]
    assert tags(out["rel"]) != tags(out["hold"])
    with pytest.raises(ConfigError):
        _lin_diss(p[-1], removal_masks="retained", method="abrupt")
    with pytest.raises(ConfigError):
        _lin_diss(p[-1], gate_schedule="hold", method="abrupt")
    with pytest.raises(ConfigError):
        d = _diss(p[-1], hybrid={"donor_role": "donor", "donor_stage": "final", "slots": ["all"]}, donor=p[-1])
        resolve({**d, "dissipation": {**d["dissipation"], "method": "linear", "removal_masks": "retained"}})
    pr = _spec_traj(part="redrawn_random")
    _run(pr[-1:], tmp_path)
    st, s = _run([_lin_diss(pr[-1], removal_masks="retained")], tmp_path)
    assert s.get("status") == "unsupported", s


def test_swapping_branch_weights_and_masks_is_a_renaming_through_an_optimizer_update():
    import copy
    import torch.nn.functional as F
    from cop.graph.builders import build_mlp
    from cop.graph import edits as E
    from cop.utils import torch_gen
    from cop.data.registry import load_bundle
    b = load_bundle(T.DATA, device="cpu")
    net = build_mlp(b.train.X["x"].shape[1], [8, 8], b.out_dim, torch_gen(0, "init"))
    G = E.insert_group(net, E.cut_at(net, "post_act", 0), torch_gen(0, "insertion", "g"), slot="spec/G", rnd=1)
    ba = E.add_branch(net, G, torch_gen(0, "insertion", "a"), width=4, slot="spec/r1/a", specialize_mask="spec_a")
    bb = E.add_branch(net, G, torch_gen(0, "insertion", "b"), width=4, slot="spec/r1/b", specialize_mask="spec_b")
    net = net.double()
    gen = torch.Generator().manual_seed(1)
    with torch.no_grad():
        for p_ in net.parameters():
            p_.add_(0.1 * torch.randn(p_.shape, generator=gen, dtype=p_.dtype))
    X = {k: v[:64].double() for k, v in b.train.X.items()}
    y = b.train.y[:64]
    ma = (torch.arange(64) % 3 == 0).double()
    mb = 1 - ma

    def loss(out):
        if b.task == "classification":
            return F.cross_entropy(out, y.long())
        return F.mse_loss(out, y.double().view_as(out))

    def step(m, opt, ctx):
        opt.zero_grad()
        loss(m(X, dict(ctx))).backward()
        opt.step()
    role = lambda bid: {net.nodes[n].role: net.nodes[n].pkey for n in net.implants[bid].nodes if net.nodes[n].pkey}
    ra, rb = role(ba), role(bb)
    swap = {**{ra[r]: rb[r] for r in ra}, **{rb[r]: ra[r] for r in rb}}
    rename = lambda name: ".".join([name.split(".")[0], swap.get(name.split(".")[1], name.split(".")[1])]
                                   + name.split(".")[2:])
    for permute_state in (True, False):
        A = copy.deepcopy(net)
        oA = torch.optim.Adam(A.parameters(), lr=1e-2)
        step(A, oA, {"grad_masks": {"spec_a": ma, "spec_b": mb}})          # A has optimizer state now
        B = copy.deepcopy(A)
        with torch.no_grad():
            sA = dict(A.named_parameters())
            for nm, q in B.named_parameters():
                q.copy_(sA[rename(nm)])
        B._plan = None
        oB = torch.optim.Adam(B.parameters(), lr=1e-2)
        if permute_state:
            pB = dict(B.named_parameters())
            for nm, q in A.named_parameters():
                oB.state[pB[rename(nm)]] = {k: (v.clone() if torch.is_tensor(v) else v)
                                            for k, v in oA.state[q].items()}
        else:
            oA = torch.optim.Adam(A.parameters(), lr=1e-2)                   # both reset
        step(A, oA, {"grad_masks": {"spec_a": ma, "spec_b": mb}})
        step(B, oB, {"grad_masks": {"spec_a": mb, "spec_b": ma}})            # masks swapped with the weights
        assert torch.allclose(A(X), B(X), atol=1e-10, rtol=0)
        sA, sB = dict(A.named_parameters()), dict(B.named_parameters())
        assert all(torch.allclose(sB[nm], sA[rename(nm)], atol=1e-12) for nm in sB)
        # swapping assignments only (weights stay) is an intervention: the function changes
        C = copy.deepcopy(A)
        oC = torch.optim.Adam(C.parameters(), lr=1e-2)
        oA2 = torch.optim.Adam(A.parameters(), lr=1e-2)
        step(A, oA2, {"grad_masks": {"spec_a": ma, "spec_b": mb}})
        step(C, oC, {"grad_masks": {"spec_a": mb, "spec_b": ma}})
        assert not torch.allclose(A(X), C(X), atol=1e-8)


# ----------------------------------------------------------------------------- 7. swaps: scan, alignment, ages, repair

def test_swap_scan_enumerates_every_subset_and_self_scan_is_the_receiver(tmp_path):
    pa, pb = _spec_traj(), _spec_traj(part="redrawn_random")
    _run(pa, tmp_path)
    _run(pb[-1:], tmp_path)

    def scan(donor):
        from test_v19 import _diss
        d = _diss(pa[-1], donor=donor)
        d = resolve({**d, "dissipation": {**d["dissipation"],
                                          "swap_scan": {"donor_role": "donor", "donor_stage": "final"}}})
        _run([d], tmp_path)
        return read_json(tmp_path / "runs" / run_id(d) / "dissipation_result.json")
    j = scan(pa[-1])
    sc = j["swap_scan"]
    assert sc["players"] == ["spec/r1/a", "spec/r1/b", "spec/r2/a", "spec/r2/b"]
    assert len(sc["subsets"]) == 16 and len({tuple(x["subset"]) for x in sc["subsets"]}) == 16
    nat = sc["native"]["receiver"]
    for x in sc["subsets"]:
        assert x["raw"]["val"] == nat["val"] and x["raw"]["function"]["val_rms_diff_from_receiver"] == 0.0
        if x["subset"]:
            assert abs(x["aligned"]["val"]["risk"] - nat["val"]["risk"]) < 1e-5
            assert all(v["train_rel_residual_aligned"] == 0.0 and v["kept_identity"]
                       for v in x["aligned"]["adapter"]["branches"].values())
    assert j["branch_ages"]["ages"] == {"spec/r1/a": 12, "spec/r1/b": 12, "spec/r2/a": 6, "spec/r2/b": 6}
    jx = scan(pb[-1])
    full = next(x for x in jx["swap_scan"]["subsets"] if x["n_players"] == 4)
    assert full["raw"]["function"]["val_rms_diff_from_receiver"] > 0
    for v in full["aligned"]["adapter"]["branches"].values():
        assert v["train_rel_residual_aligned"] <= v["train_rel_residual_raw"] + 1e-9
        assert v["params"] > 0


def test_branch_ages_at_the_round_two_insertion(tmp_path):
    from test_v19 import _diss
    p = _spec_traj()
    d = _diss(p[-1], stage="post_insert_r2")
    _run(p + [d], tmp_path)
    j = read_json(tmp_path / "runs" / run_id(d) / "dissipation_result.json")
    assert j["branch_ages"]["ages"] == {"spec/r1/a": 6, "spec/r1/b": 6, "spec/r2/a": 0, "spec/r2/b": 0}


def test_repair_curve_targets_validation_crossings_and_censoring():
    from cop.analysis.v13_tables import repair_curve
    path = [{"update": 0, "tag": "start", "val_risk": 0.1, "test_risk": 0.1, "val_rms_drift_from_receiver": 0.0},
            {"update": 5, "tag": "physically_removed_0", "val_risk": 0.5, "test_risk": 0.6,
             "val_rms_drift_from_receiver": 3.0},
            {"update": 10, "tag": "post_0", "val_risk": 0.2, "test_risk": 0.25, "val_rms_drift_from_receiver": 1.0},
            {"update": 15, "tag": "exported", "val_risk": 0.19, "test_risk": 0.22, "val_rms_drift_from_receiver": 0.5}]
    j = {"path": path, "recovery_reference": {"f0_val_risk": 0.2, "receiver_val_risk": 0.1,
                                              "receiver_val_out_rms": 10.0}}
    r = repair_curve(j)
    assert r["recovery_f0_first_update"] == 10 and r["recovery_f0_test_risk_at_first"] == 0.25
    assert r["recovery_f0_final_success"] and not r["recovery_f0_censored"]
    assert r["recovery_receiver_first_update"] is None and r["recovery_receiver_censored"]   # start does not count
    assert r["recovery_imitation_first_update"] == 10                                        # 1.0 <= 0.1 x 10
    ab = [{"update": 0, "tag": "start", "val_risk": 0.1}, {"update": 0, "tag": "after_abrupt_delete_0", "val_risk": 0.3},
          {"update": 4, "tag": "recover_0", "val_risk": 0.2}, {"update": 8, "tag": "exported", "val_risk": 0.2}]
    r = repair_curve({"path": ab, "recovery_reference": {"f0_val_risk": 0.2}})
    assert r["recovery_f0_first_update"] == 4 and r["path_points_compact"] == 3


def test_wave17_swap_block_uses_four_explicit_players_and_matched_controls():
    from cop.orchestration.manifest import generate
    from cop.orchestration.wave13 import SWAP_PLAYERS
    B = generate([17], "smoke")
    ents = [e["cfg"] for e in B.entries.values()]
    hy = [c for c in ents if c["kind"] == "dissipation" and c["dissipation"]["hybrid"]["donor_role"]]
    assert all("all" not in c["dissipation"]["hybrid"]["slots"] for c in hy)
    assert any(sorted(c["dissipation"]["hybrid"]["slots"]) == sorted(SWAP_PLAYERS) for c in hy)
    scans = [c for c in ents if c["kind"] == "dissipation" and c["dissipation"]["swap_scan"]["donor_role"]]
    assert scans and all(c["parents"]["scan_donor"] != c["parents"]["trajectory"] for c in scans)
    arms = {c["design"]["arm"] for c in ents if (c.get("design") or {}).get("family") == "SW"}
    assert {"C1_lr0.3", "C1_cosine", "C7_opt", "crossing_hold_released", "crossing_anneal_retained",
            "crossing_hold_retained"} <= arms
    cr = [c for c in ents if (c.get("design") or {}).get("arm", "").startswith("crossing_")]
    assert {(c["dissipation"]["gate_schedule"], c["dissipation"]["removal_masks"]) for c in cr} == \
        {("hold", "released"), ("anneal", "retained"), ("hold", "retained")}
    tr = next(c for c in ents if (c.get("design") or {}).get("family") == "SW" and c["design"]["arm"] == "treated"
              and c["kind"] == "dissipation")
    assert all(c["dissipation"]["speed_updates"] == tr["dissipation"]["speed_updates"] and
               c["dissipation"]["post_updates"] == tr["dissipation"]["post_updates"] for c in cr)


# ----------------------------------------------------------------------------- 6 / 9. recode design and budgets

def test_wave17_recode_strata_are_matched_and_budgets_scale():
    from cop.orchestration.manifest import generate
    import importlib.util
    grids = {}
    for scale in ("smoke", "full"):
        B = generate([17], scale)
        ents = {k: e["cfg"] for k, e in B.entries.items()}
        rc = [c for c in ents.values() if c["kind"] == "cop" and c["cop"]["task_kind"] == "recode"]
        for c in rc:
            src = ents[c["parents"]["chain"]]
            rec = c["design"]["variant"].rsplit("_", 1)[-1]
            assert rec in ("fixed", "ema")
            assert src["train"]["quant_range"] == ("ema" if rec == "ema" else c["train"]["quant_range"])
            assert c["train"]["quant_range"] == src["train"]["quant_range"]
        by = {}
        for c in rc:
            by.setdefault((c["design"]["contrast"], c["data"]["data_seed"]), set()).add(c["design"]["arm"])
        assert all(v == {"recode_treated", "recode_abrupt_calibrated_interfaces",
                         f"recode_M2_{k[0].rsplit('_', 1)[-1]}"} for k, v in by.items())
        grids[scale] = rc[0]["cop"]
    assert grids["smoke"]["recode_updates"] < grids["full"]["recode_updates"]
    assert set(grids["smoke"]["recode_relabels"]) == set(grids["full"]["recode_relabels"])
    assert set(grids["smoke"]["recode_regimes"]) == {"observed", "full_alphabet"}
    spec = importlib.util.spec_from_file_location("rt", ROOT / "audit_v5/tools/runtime_v13.py")
    src_txt = (ROOT / "audit_v5/tools/runtime_v13.py").read_text().split("\nap = argparse")[0]
    ns = {"__file__": str(ROOT / "audit_v5/tools/runtime_v13.py")}
    exec(compile(src_txt, "runtime_v13", "exec"), ns)
    from cop.cop_pegs.recode import plan_fits
    n = ns["recode_fit_counts"](grids["full"])
    assert n["fits"] == len(plan_fits(grids["full"], [1, 2])) == 2 * 2 * 28 * 3 * 2
    assert ns["recode_work"](grids["full"]) > 100 * ns["recode_work"](grids["smoke"])
    c = rc[0]
    assert ns["strata"](c)[0][0] == "cop:recode"


def test_symmetry_holds_over_a_production_length_fit_in_float64():
    """v20.1 regression: the v20 panel's symmetry control failed on every job because float32 rounding (changed
    by the permutation's summation order) was amplified by Adam over 1000 updates; fits now run in float64."""
    from cop.cop_pegs.recode import fit_replacement, make_replacement, permute_model
    g = torch.Generator().manual_seed(0)
    X = torch.unique((torch.rand(400, 8, generator=g) < 0.5).to(torch.uint8), dim=0)[:120]
    Y = (torch.rand(len(X), 8, generator=g) < 0.5).to(torch.uint8)
    w = torch.rand(len(X), generator=g) + 0.1
    pi, po = torch.randperm(8, generator=g), torch.randperm(8, generator=g)
    m0 = make_replacement("mlp64", 8, 8, torch.Generator().manual_seed(2))
    a = fit_replacement("mlp64", X, Y, w, 1000, 1e-2, 25, None, "cpu", init=permute_model(m0, None, None))
    b = fit_replacement("mlp64", X[:, pi], Y[:, po], w, 1000, 1e-2, 25, None, "cpu", init=permute_model(m0, pi, po))
    assert next(a["module"].parameters()).dtype == torch.float64
    la, lb = [c["loss"] for c in a["curve"]], [c["loss"] for c in b["curve"]]
    assert max(abs(x - y) for x, y in zip(la, lb)) / max(lb) < 1e-10
    assert a["first_exact_update"] == b["first_exact_update"]
