"""v22: exposure-matched persistence (cyclic_blocks), rebuilt start states (untouched f0 backbone, fresh
implants), dense early repair evaluation, the disjoint-player dependence game, the parameter-level recode
symmetry check, and the v22 panel structure."""
from __future__ import annotations

import json
import sys
from pathlib import Path
from unittest.mock import patch

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
from cop.config import resolve, run_id, ConfigError  # noqa: E402
from cop.utils import read_json  # noqa: E402


def _traj(part="cyclic_blocks", period=4, **g):
    from test_v19 import _traj as t
    p = t(part="random_matched" if part == "cyclic_blocks" else part)
    c = dict(p[-1])
    c["growth"] = {**c["growth"], "spec_partition": part}
    gr = {**c["growth"], **({"spec_block_period": period, "spec_random_fraction": 0.75} if part == "cyclic_blocks"
                            else {}), **g}
    return p[:-1] + [resolve({**c, "growth": gr})]


def _run(cfgs, d):
    from test_v15 import _run as r
    return r(cfgs, d)


def _run_st(cfgs, d):
    from test_v20 import _run as r
    return r(cfgs, d)


def _diss(traj_cfg, design=None, **over):
    from test_v19 import _diss as dd
    d = dd(traj_cfg)
    return resolve({**{k: v for k, v in d.items() if k not in ("dissipation", "design")},
                    "dissipation": {**d["dissipation"], **over}, **({"design": design} if design else {})})


# ----------------------------------------------------------------------------- persistence

def test_cyclic_membership_gives_equal_exposure_and_a_matched_split_every_update():
    from cop.experiments.trajectory import cyclic_membership, cyclic_phases, cyclic_a_len
    n, T = 1000, 20
    aL = cyclic_a_len(0.95, T)
    assert aL == 19
    ph = cyclic_phases(n, T, seed=3)
    tot = torch.zeros(n, dtype=torch.long)
    for t in range(7, 7 + 5 * T):
        m = cyclic_membership(ph, t, T, aL)
        assert abs(int(m.sum()) - 950) <= 1                 # every update: a 95 / 5 split
        tot += m.long()
    assert torch.all(tot == 5 * aL)                          # every example: exactly 95 % of the updates in a
    # the stay lengths: each example is in a for aL consecutive updates of every cycle
    seq = torch.stack([cyclic_membership(ph, t, T, aL) for t in range(2 * T)])
    i = 0
    runs = [len(s) for s in "".join("a" if x else "b" for x in seq[:, i].tolist()).split("b") if s]
    assert max(runs) >= aL - 1


def test_cyclic_config_validation():
    with pytest.raises(ConfigError):
        _traj(period=1)
    with pytest.raises(ConfigError):
        _traj(part="random_matched", spec_block_period=10)


def test_cyclic_trajectory_records_exposure_and_resumes_identically(tmp_path):
    p = _traj(period=4)
    rd = _run(p, tmp_path)
    j = read_json(rd / "summary.json")["result"]
    cy = j["spec_cyclic"]
    assert cy["period"] == 4 and cy["updates_in_a_per_cycle"] == 3
    assert cy["per_example_share_a_min"] == cy["per_example_share_a_max"] == 0.75     # 12 updates = 3 cycles
    assert (rd / "spec_phase.pt").exists() and (rd / "spec_partition_final.pt").exists()
    acc = read_json(rd / "specialization_access.json")
    assert acc["spec_partition"] == "cyclic_blocks" and "cyclic" in acc["membership"]
    from resume_harness import compare_interrupted
    rep = compare_interrupted(p, tmp_path / "resume", fractions=(0.3, 0.7))
    assert rep["interrupted_at_polls"] and rep["equal"], rep


def test_cyclic_removal_has_end_assignment_membership_and_refuses_retained_masks(tmp_path):
    p = _traj(period=4)
    d = _diss(p[-1])
    rd = _run(p + [d], tmp_path)
    fs = read_json(rd / "dissipation_result.json")["frozen_weight_sweep"]
    assert fs["damage_by_membership"] and all("own_err_increase" in v for v in fs["damage_by_membership"].values())
    lin = _diss(p[-1], method="linear", speed_updates=2, post_updates=2, removal_masks="retained")
    st, s = _run_st([lin], tmp_path)
    assert s.get("status") == "unsupported", s


# ----------------------------------------------------------------------------- rebuilt start states

def test_pristine_rebuild_equals_f0_and_charges_no_trained_model(tmp_path):
    from cop.experiments.continuation import chain_work_parts
    from test_v19 import _traj as t
    p = t()
    pristine = _diss(p[-1], method="linear", speed_updates=2, post_updates=4, early_eval=[1, 2, 3],
                     rebuild={"backbone": "f0", "implants": "fresh"})
    _run(p + [pristine], tmp_path)
    rd = tmp_path / "runs" / run_id(pristine)
    j = read_json(rd / "dissipation_result.json")
    assert j["rebuild"]["max_abs_diff_from_f0_val"] <= 1e-5
    assert j["rebuild"]["implant_tensors_reset_to_insertion"] > 0 and j["rebuild"]["backbone_tensors_from_f0"] > 0
    assert all(v == 0 for v in j["branch_ages"]["ages"].values())
    intact = j["frozen_weight_sweep"]["intact"]["val"]["risk"]
    assert abs(intact - j["recovery_reference"]["f0_val_risk"]) < 1e-6
    parts = chain_work_parts(rd)
    assert parts["source_lineage"]["updates"] == 0           # f0 + insertion draws: no trained model consumed
    rem = [pt["update"] for pt in j["path"] if pt["tag"].startswith("physically_removed")][-1]
    post = sorted(pt["update"] - rem for pt in j["path"] if pt["tag"] == "post_0")
    assert {1, 2, 3} <= set(post)                             # dense early repair points


def test_trained_backbone_fresh_branches_and_f0_with_trained_branches(tmp_path):
    from cop.graph.graph import GraphNet
    from test_v19 import _traj as t
    p = t()
    a = _diss(p[-1], rebuild={"backbone": "receiver", "implants": "fresh"})
    b = _diss(p[-1], rebuild={"backbone": "f0", "implants": "receiver"})
    plain = _diss(p[-1])
    _run(p + [plain], tmp_path)
    ja = read_json(_run([a], tmp_path) and tmp_path / "runs" / run_id(a) / "dissipation_result.json")
    jb = read_json(_run([b], tmp_path) and tmp_path / "runs" / run_id(b) / "dissipation_result.json")
    j0 = read_json(tmp_path / "runs" / run_id(plain) / "dissipation_result.json")
    # fresh branches output zero: the trained backbone with fresh branches computes the trained backbone with the
    # additions deleted
    assert abs(ja["frozen_weight_sweep"]["intact"]["val"]["risk"] -
               j0["frozen_weight_sweep"]["joint_deletion"]["val"]["risk"]) < 1e-6
    assert jb["rebuild"]["backbone"] == "f0" and jb["frozen_weight_sweep"]["intact"] != j0["frozen_weight_sweep"]["intact"]
    with pytest.raises(ConfigError):
        _diss(p[-1], rebuild={"backbone": "nothing", "implants": "fresh"})


# ----------------------------------------------------------------------------- analysis

def test_disjoint_game_drops_ancestor_descendant_pairs():
    from cop.analysis.dependence_game import game_from_deletions
    # atoms: G (parent of a, b), a, b; deleting G deletes a and b
    d = {frozenset(): 0.0, frozenset("a"): 1.0, frozenset("b"): 2.0, frozenset("ab"): 3.5, frozenset("G"): 3.5,
         frozenset("Ga"): 3.5, frozenset("Gb"): 3.5, frozenset("Gab"): 3.5}
    rows = []
    for S, v in d.items():
        if not S:
            continue
        r = {"atoms": sorted(S), "metrics": {"val": {"delta_risk": v}}}
        if "G" in S and len(S) > 1:
            r["canonical"] = ["G"]
        rows.append(r)
    dele = {"info": {"atoms": ["G", "a", "b"], "exhaustive": True}, "rows": rows,
            "base": {"val": {"loss": 0.0}}, "partitions": ["val"]}
    g = game_from_deletions(dele, "val")
    assert g["hierarchical"] and min(g["pair_at_empty"].values()) < 0      # the hierarchy artefact
    dj = g["disjoint_game"]
    assert dj["players"] == ["a", "b"] and dj["pair_at_empty"] == {"a,b": 0.5}
    assert dj["ancestors_excluded"] == ["G"]


def test_v22_tables_through_the_summary(tmp_path):
    import csv
    from cop.analysis.summarize import summarize
    from cop import cli
    from test_v19 import _traj as t
    D = lambda fam, var, arm: {"family": fam, "variant": var, "arm": arm, "contrast": f"{fam}|c",
                               "budget_panel": "updates"}
    pc = _traj(period=4)
    pf = t()
    lin = dict(method="linear", speed_updates=2, post_updates=4, early_eval=[1, 2])
    pe_c = _diss(pc[-1], **lin, design=D("PE", "cyclic_T4", "treated"))
    pe_f = _diss(pf[-1], **lin, design=D("PE", "fixed", "treated"))
    bb = _diss(pf[-1], **lin, rebuild={"backbone": "f0", "implants": "fresh"},
               design=D("BB", "pristine", "f0_backbone_fresh_implants"))
    _run(pc + [pe_c], tmp_path)
    _run(pf[-1:] + [pe_f, bb], tmp_path)
    res = summarize(tmp_path, [], tmp_path / "summary")
    assert not cli.summary_errors(res), cli.summary_errors(res)
    st = tmp_path / "summary" / "strengthening"
    pe = list(csv.DictReader(open(st / "s22_persistence.csv")))
    assert {r["variant"] for r in pe} == {"cyclic_T4", "fixed"}
    c = next(r for r in pe if r["variant"] == "cyclic_T4")
    assert c["period"] == "4" and c["cyclic_per_example_share_a_min"] == "0.75" and c["post_removal_val_risk_at_1"] != ""
    b = list(csv.DictReader(open(st / "s22_backbone.csv")))
    assert len(b) == 1 and b[0]["plain_run"] == run_id(pe_f) and b[0]["backbone"] == "f0"


def test_wave18_panel_structure():
    from cop.orchestration.manifest import generate
    B = generate([18], "full")
    ents = {k: e["cfg"] for k, e in B.entries.items()}
    tr = [c for c in ents.values() if c["kind"] == "trajectory"]
    assert {c["data"]["data_seed"] for c in tr} == {0, 201, 202, 203, 204, 205}
    qa = [c for c in tr if c["growth"]["spec_partition"] == "matched_quota"]
    assert {(c["growth"]["spec_quota"]["fraction"], c["growth"]["spec_quota"]["b_run"]) for c in qa} == \
        {(0.95, 0), (0.95, 1), (0.5, 0), (0.5, 8), (0.5, 1)}
    assert not [c for c in tr if c["growth"]["spec_partition"] == "cyclic_blocks"]   # v23: dropped from the panel
    # every PE removal shares one protocol
    pe = [c for c in ents.values() if c["kind"] == "dissipation" and c["design"]["family"] == "PE"]
    assert len({json.dumps({k: c["dissipation"][k] for k in ("method", "speed_updates", "post_updates",
                                                               "early_eval")}) for c in pe}) == 1
    bb = [c for c in ents.values() if c["kind"] == "dissipation" and c["design"]["family"] == "BB"]
    assert {c["design"]["arm"] for c in bb} == {"f0_backbone_fresh_implants", "f0_backbone_trained_branches",
                                                "trained_backbone_fresh_branches"}
    assert sum(c["design"]["arm"] == "f0_backbone_fresh_implants" for c in bb) == 6     # once per draw


# ----------------------------------------------------------------------------- recode symmetry (parameters)

def test_a_wrong_permutation_in_the_symmetric_control_makes_the_job_invalid(tmp_path):
    from cop.cop_pegs import recode
    from test_v20 import _recode
    cfgs = _recode(recode_updates=20, recode_relabels=["identity", "bitperm_symmetric"])
    _run_st(cfgs[:2], tmp_path)
    orig = recode.permute_model

    def wrong(m, pin, pout):
        return orig(m, None if pin is None else pin.roll(1), None if pout is None else pout.roll(1))
    with patch.object(recode, "permute_model", wrong):
        st, s = _run_st(cfgs[-1:], tmp_path)
    assert s.get("status") == "invalid" and "symmetry" in s.get("reason", ""), s


def test_symmetric_fits_have_permuted_parameters(tmp_path):
    from test_v20 import _recode
    cfgs = _recode(recode_updates=40, recode_relabels=["identity", "bitperm_symmetric"])
    st, s = _run_st(cfgs, tmp_path)
    assert st[-1] == "complete", s
    ch = read_json(tmp_path / "runs" / run_id(cfgs[-1]) / "recode_checks.json")["symmetry_control"]
    assert ch["passed"] and ch["rows"] and all(r["param_relative"] is not None and r["param_relative"] < 1e-10
                                               for r in ch["rows"])
    assert all(r["same_first_exact_update"] for r in ch["rows"])


# ----------------------------------------------------------------------------- example-tied dropout comparator

def _etd_cfgs(**over):
    import tiny_configs as T
    from test_v19 import SH
    b = T.base(data=SH)
    c = resolve({"kind": "continue", "data": SH, "model": T.MODEL, "train": T.TRAIN, "seeds": {"optimizer": 0},
                 "parents": {"baseline": run_id(b)},
                 "continue": {"start": "baseline", "start_stage": "baseline", "budget": "fixed",
                              "arm": "example_tied_dropout", "segments": [8, 6], **over}})
    return [b, c]


def test_example_tied_dropout_masks_and_drop_are_exact():
    import tiny_configs as T
    from test_v19 import SH
    from cop.data.registry import load_bundle
    from cop.graph.builders import build_mlp
    from cop.utils import torch_gen
    from cop.experiments.continuation import _ExampleTiedDropout
    b = load_bundle(SH, device="cpu")
    net = build_mlp(b.train.X["x"].shape[1], [16, 16], b.out_dim, torch_gen(0, "init")).double()
    n = len(b.train)
    b.train.aux["_index"] = torch.arange(n)
    etd = _ExampleTiedDropout(net, n, 0.4, 0.2, seed=3)
    assert len(etd.layers) == 2
    for nid in etd.layers:
        g, k = int(etd.gen_mask[nid].sum()), etd.n_mem_active[nid]
        assert g == round(0.4 * 16) and k == max(1, round(0.2 * (16 - g)))
        assert torch.all(etd.mem_assign[nid].sum(1) == k)                       # k memorization units per example
        assert not (etd.mem_assign[nid] & etd.gen_mask[nid][None, :]).any()     # drawn from the pool only
    batch = b.train.index(torch.arange(32))
    X = {k_: v.double() for k_, v in batch.X.items()}
    ctx = etd.batch_ctx(batch)
    _, v = net(X, dict(ctx), return_nodes=etd.layers)
    for nid in etd.layers:
        active = etd.gen_mask[nid][None, :] | etd.mem_assign[nid][torch.arange(32)]
        assert torch.all(v[nid][~active] == 0)
    etd.set_mode(net, "etd")
    net.eval()
    o_eval = net(X).detach()
    _, v = net(X, return_nodes=etd.layers)
    assert all(torch.all(v[nid][:, ~etd.gen_mask[nid]] == 0) for nid in etd.layers)
    etd.set_mode(net, "off")
    etd.drop(net)
    assert torch.allclose(net(X), o_eval, atol=1e-12)                          # dropped = test-time rule


def test_example_tied_dropout_job_records_native_and_repairs(tmp_path):
    cfgs = _etd_cfgs()
    rd = _run(cfgs, tmp_path)
    j = read_json(rd / "continue_result.json")
    et = j["example_tied_dropout"]
    assert et["p_gen"] == 0.4 and et["native"]["memorization_units_dropped"] > 0
    assert et["native"]["max_abs_diff_masked_vs_dropped"] <= 1e-5 and et["native"]["at_update"] == 8
    assert j["updates"] == 14 and (rd / "ckpt" / "etd_native.pt").exists()
    with pytest.raises(ConfigError):
        _etd_cfgs(segments=[14])


def test_example_tied_dropout_resumes_identically(tmp_path):
    from resume_harness import compare_interrupted
    rep = compare_interrupted(_etd_cfgs(), tmp_path / "resume", fractions=(0.3, 0.6, 0.9))
    assert rep["interrupted_at_polls"] and rep["equal"], rep


# ----------------------------------------------------------------------------- realised exposure, imitation

def test_realised_exposure_per_example_and_decision_imitation(tmp_path):
    from test_v19 import _traj as t
    p = t()
    d = _diss(p[-1], method="linear", speed_updates=2, post_updates=4)
    rd_t = _run(p, tmp_path)
    pe = read_json(rd_t / "summary.json")["result"]["spec_exposure_per_example"]
    assert pe["examples_seen"] > 0 and pe["share_a_quantiles"]["p05"] in (0.0, 1.0)   # fixed split: 0 or 1
    assert (rd_t / "spec_exposure_per_example.pt").exists()
    _run([d], tmp_path)
    j = read_json(tmp_path / "runs" / run_id(d) / "dissipation_result.json")
    assert all("val_flip_rate_from_receiver" in pt and "val_tv_from_receiver" in pt for pt in j["path"])
    from cop.analysis.v13_tables import repair_curve
    rc = repair_curve(j)
    assert "recovery_decision_imitation_censored" in rc and "final_val_flip_rate_from_receiver" in rc


def test_wave18_controls_seeds_and_comparator():
    from cop.orchestration.manifest import generate
    from cop.orchestration.wave13 import V22_PARTITION_SEEDS
    B = generate([18], "full")
    ents = {k: e["cfg"] for k, e in B.entries.items()}
    cont = [c for c in ents.values() if c["kind"] == "continue"]
    by = {}
    for c in cont:
        by.setdefault(c["design"]["arm"], []).append(c)
    assert len(by["C2"]) == 6 and all(c["continue"]["budget"] == "parent_compute" for c in by["C2"])
    U = next(c for c in ents.values() if c["kind"] == "trajectory")["growth"]["updates_per_round"]
    for c in by["ETD_from_f0"]:
        assert c["continue"]["arm"] == "example_tied_dropout" and c["continue"]["segments"][0] == 2 * U
    for c in by["ETD_scratch"]:
        assert c["continue"]["reinit"] and c["continue"]["segments"][0] == c["train"]["baseline_updates"] + 2 * U
    tr = [c for c in ents.values() if c["kind"] == "trajectory" and c["seeds"].get("partition") is not None]
    assert {c["seeds"]["partition"] for c in tr} == set(V22_PARTITION_SEEDS)
    assert {c["growth"]["spec_partition"] for c in tr} == {"random_matched", "redrawn_random"}
    assert len([c for c in by["C1"] if c["seeds"].get("partition") is not None]) == 6 * len(V22_PARTITION_SEEDS)
