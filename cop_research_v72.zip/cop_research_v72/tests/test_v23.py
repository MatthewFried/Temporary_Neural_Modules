"""v23: fixes from the static review of v22.  Matched exposure on the actual sampled stream (matched_quota),
ETD selection inside its repair phase, ETD accounting, ETD native / selected endpoint reload, the pristine
rebuild certificate, recode symmetry coverage, gradient and Adam covariance under a bit permutation, and the
recode audit's negative cases."""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
from cop.config import resolve, run_id, ConfigError  # noqa: E402
from cop.utils import read_json  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


def _run(cfgs, d):
    from test_v15 import _run as r
    return r(cfgs, d)


def _run_st(cfgs, d):
    from test_v20 import _run as r
    return r(cfgs, d)


# ----------------------------------------------------------------------------- A. matched exposure

def _stream(N, B, U, seed=0):
    """an epoch-wise without-replacement stream like the trainer's (B need not divide N)."""
    g = torch.Generator().manual_seed(seed)
    out, perm, pos = [], None, 0
    for _ in range(U):
        if perm is None or pos + B > N:
            perm, pos = torch.randperm(N, generator=g), 0
        out.append(perm[pos:pos + B])
        pos += B
    return torch.stack(out)


def _runs_of_b(seq):
    r, prev = 0, True
    for x in seq:
        if not x and prev:
            r += 1
        prev = x
    return r


@pytest.mark.parametrize("frac", [0.95, 0.5])
def test_quota_schedules_have_identical_integer_quotas_and_the_declared_runs(frac):
    from cop.experiments.trajectory import quota_schedule
    N, B, U = 50, 7, 103                         # B does not divide N; uneven appearances
    idx = _stream(N, B, U)
    scheds = {br: quota_schedule(idx, N, frac, br, seed=3, window=1) for br in (0, 1, 3)}
    flat = idx.flatten()
    for br, sch in scheds.items():
        a = sch["assign"].flatten()
        for i in range(N):
            pos = (flat == i).nonzero().flatten()          # time order
            n = len(pos)
            q = int(torch.floor(torch.tensor(frac * n + 0.5)))
            assert int(a[pos].sum()) == q == int(sch["quota_a"][i]) and int(sch["appearances"][i]) == n
            nb = n - q
            if nb and q:
                m = 1 if br == 0 else min(-(-nb // br), q)
                assert _runs_of_b(a[pos].tolist()) == m           # b-runs never cut by the window edges
    q0 = scheds[0]["quota_a"]
    assert all(torch.equal(s_["quota_a"], q0) for s_ in scheds.values())
    if frac == 0.5:              # at 95 / 5 most examples have a single b-appearance: the orders can coincide
        assert not torch.equal(scheds[0]["assign"], scheds[1]["assign"])  # same quotas, different order


def _quota_traj(b_run, frac=0.5, upr=40, batch=30):
    from test_v19 import _traj as t
    p = t(part="random_matched", upr=upr)
    c = dict(p[-1])
    c["growth"] = {**c["growth"], "spec_partition": "matched_quota", "spec_quota": {"fraction": frac, "b_run": b_run}}
    c["train"] = {**c["train"], "batch_size": batch}
    b = dict(p[0])
    b["train"] = {**b["train"], "batch_size": batch}
    b = resolve(b)
    c["parents"] = {**c["parents"], "baseline": run_id(b)}
    return [b, resolve(c)]


def test_matched_quota_trajectories_share_stream_and_quotas_per_round_and_branch(tmp_path):
    pa, pb = _quota_traj(0), _quota_traj(1)
    rd_a = _run(pa, tmp_path)
    rd_b = _run(pb[-1:], tmp_path)
    ja = read_json(rd_a / "summary.json")["result"]
    jb = read_json(rd_b / "summary.json")["result"]
    assert set(ja["spec_quota"]) == {"0", "1"}                              # both growth rounds
    for w in ("0", "1"):
        assert ja["spec_quota"][w]["stream_hash"] == jb["spec_quota"][w]["stream_hash"]
        assert ja["spec_quota"][w]["quota_hash"] == jb["spec_quota"][w]["quota_hash"]
    ea = torch.load(rd_a / "spec_exposure_per_example.pt", weights_only=False)
    eb = torch.load(rd_b / "spec_exposure_per_example.pt", weights_only=False)
    for w in ("0", "1"):                                                    # realised = quota, per round
        assert torch.equal(ea[w]["a"], eb[w]["a"]) and torch.equal(ea[w]["n"], eb[w]["n"])
        qa = torch.load(rd_a / f"spec_quota_w{w}.pt", weights_only=False)
        assert torch.equal(ea[w]["a"].long(), qa["quota_a"])
    br = ja["spec_exposure_per_example"]["by_physical_branch"]
    assert br["spec/r1"]["rounds"] == [1, 2] and br["spec/r2"]["rounds"] == [2]
    assert br["spec/r2"]["born_job_update"] == 40


def test_matched_quota_resumes_identically(tmp_path):
    from resume_harness import compare_interrupted
    rep = compare_interrupted(_quota_traj(1), tmp_path / "resume", fractions=(0.2, 0.5, 0.8))
    assert rep["interrupted_at_polls"] and rep["equal"], rep


def test_matched_quota_config():
    with pytest.raises(ConfigError):
        p = _quota_traj(0)
        c = dict(p[-1])
        c["growth"] = {**c["growth"], "spec_quota": {"fraction": 1.0, "b_run": 0}}
        resolve(c)
    with pytest.raises(ConfigError):
        p = _quota_traj(0)
        c = dict(p[-1])
        c["train"] = {**c["train"], "sampler": "group_balanced"}
        resolve(c)


def test_a_stream_mismatch_makes_the_job_invalid(tmp_path):
    from cop.experiments import trajectory as TJ
    p = _quota_traj(1)
    _run(p[:1], tmp_path)
    orig = TJ.replay_minibatch_indices

    def wrong(trn, n):
        return orig(trn, n).roll(1, 0)
    from unittest.mock import patch
    with patch.object(TJ, "replay_minibatch_indices", wrong):
        st, s = _run_st(p[-1:], tmp_path)
    assert s.get("status") == "invalid" and "stream" in s.get("reason", ""), s


# ----------------------------------------------------------------------------- B. ETD selection

def test_etd_selection_points_are_all_in_the_repair_phase_at_full_layout():
    from cop.experiments.continuation import etd_selection_points
    for segs in ([4000, 3000], [8000, 3000]):
        pts = sorted(etd_selection_points(segs, 8))
        assert len(pts) == 8 and pts[-1] == sum(segs) and pts[0] > segs[0]
        assert [p - segs[0] for p in pts] == [375, 750, 1125, 1500, 1875, 2250, 2625, 3000]


def _etd(tmp_path_unused=None, **over):
    import tiny_configs as T
    from test_v19 import SH
    tr = {**T.TRAIN, "select_candidates": 4}
    b = resolve({"kind": "baseline", "data": SH, "model": T.MODEL, "train": tr, "seeds": {"optimizer": 0}})
    c = resolve({"kind": "continue", "data": SH, "model": T.MODEL, "train": tr, "seeds": {"optimizer": 0},
                 "parents": {"baseline": run_id(b)},
                 "continue": {"start": "baseline", "start_stage": "baseline", "budget": "fixed",
                              "arm": "example_tied_dropout", "segments": [8, 8], "repair_early_eval": [1, 2, 4],
                              **over}})
    return [b, c]


def test_etd_job_selects_only_in_repair_and_records_the_dense_path(tmp_path):
    cfgs = _etd()
    rd = _run(cfgs, tmp_path)
    sel = read_json(rd / "selection.json")
    assert sorted(c["seg_step"] for c in sel["candidates"]) == [10, 12, 14, 16]   # repair phase only
    ep = read_json(rd / "endpoint_best_val.json")
    assert ep["n_candidates"] == 4
    et = read_json(rd / "continue_result.json")["example_tied_dropout"]
    offs = [p["offset_from_drop"] for p in et["repair_path"]]
    assert offs == [0, 1, 2, 4, 8] and "val_flip_rate_from_native_at_drop" in et["repair_path"][1]
    assert et["repair_path"][0]["val_flip_rate_from_native_at_drop"] == 0.0
    assert (rd / "endpoint_etd_native.json").exists() and (rd / "preds" / "endpoint_etd_native__test.pt").exists()
    assert et["phase_updates"] == {"dropout_phase": 8, "removal_transition": 0, "post_removal_repair": 8}


def test_fresh_reload_checks_selected_and_native_endpoints_and_detects_corruption(tmp_path):
    cfgs = _etd()
    rd = _run(cfgs, tmp_path)
    tool = str(ROOT / "audit_v5/tools/fresh_reload.py")
    r = subprocess.run([sys.executable, tool, str(tmp_path), str(tmp_path / "rl.json"), "--device", "cpu"],
                       capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr
    cov = read_json(tmp_path / "rl.json")["summary"]["endpoint_records"]
    assert cov["endpoint_best_val"]["checked"] >= 1 and cov["endpoint_etd_native"]["checked"] == 1
    for ck in ("etd_native", "best_val"):
        p = rd / "ckpt" / f"{ck}.pt"
        keep = p.read_bytes()
        a = torch.load(p, weights_only=False)
        a["model"]["state"] = {k: (v + 1.0 if v.is_floating_point() else v) for k, v in a["model"]["state"].items()}
        torch.save(a, p)
        r = subprocess.run([sys.executable, tool, str(tmp_path), str(tmp_path / f"rl_{ck}.json"), "--device", "cpu"],
                           capture_output=True, text=True)
        assert r.returncode != 0, ck
        p.write_bytes(keep)


# ----------------------------------------------------------------------------- C. ETD accounting

def test_etd_scratch_is_not_charged_f0_and_from_f0_is(tmp_path):
    import csv
    from cop.analysis.summarize import summarize
    D = lambda arm: {"family": "PE", "variant": "etd", "arm": arm, "contrast": "PE|c", "budget_panel": "updates"}
    b, f0c = _etd()
    scratch = resolve({**{k: v for k, v in f0c.items() if k not in ("continue", "design")},
                       "continue": {**f0c["continue"], "reinit": True, "inherit_state": False}, "design": D("ETD_scratch")})
    from_f0 = resolve({**{k: v for k, v in f0c.items() if k != "design"}, "design": D("ETD_from_f0")})
    _run([b, from_f0], tmp_path)
    _run([scratch], tmp_path)
    summarize(tmp_path, [], tmp_path / "summary")
    rows = {r["run_id"]: r for r in csv.DictReader(open(tmp_path / "summary" / "strengthening" / "s_endpoints.csv"))}
    rs, rf = rows[run_id(scratch)], rows[run_id(from_f0)]
    assert rs["consumes_trained_f0"] == "False" and float(rs["baseline_macs"]) == 0
    assert rf["consumes_trained_f0"] == "True" and float(rf["baseline_macs"]) > 0


# ----------------------------------------------------------------------------- H. pristine certificate

def test_pristine_certificate_passes_on_an_insertion_state_and_rejects_a_non_neutral_branch(tmp_path):
    from cop.graph.graph import GraphNet
    from cop.data.registry import load_bundle
    from cop.experiments.dissipation import pristine_certificate, _branch_out_linear
    from cop.experiments.context import Unsupported
    from test_v19 import _traj as t, SH
    p = t()
    rd = _run(p, tmp_path)
    load = lambda nm: GraphNet.from_checkpoint(torch.load(rd / "ckpt" / f"{nm}.pt", weights_only=False)["model"])
    g, f0 = load("post_insert_r1"), load("baseline_ref")
    b = load_bundle(SH, device="cpu")
    cert = pristine_certificate(g, f0, b, 256)
    assert cert["passed"] and cert["zero_branch_terms"] == 2 and cert["backbone_tensors_equal_f0"]
    t0 = next(t_ for t_, imp in g.implants.items() if imp.kind == "branch" and imp.nodes)
    with torch.no_grad():
        g.mods[g.nodes[_branch_out_linear(g, t0)].pkey].weight[0, 0] = 1e-3
    with pytest.raises(Unsupported):
        pristine_certificate(g, f0, b, 256)


# ----------------------------------------------------------------------------- F. covariance and symmetry

@pytest.mark.parametrize("cls", ["linear", "mlp8"])
def test_gradients_and_adam_moments_are_covariant_under_a_bit_permutation(cls):
    import copy
    import torch.nn.functional as F
    from cop.cop_pegs.recode import make_replacement, permute_model
    g = torch.Generator().manual_seed(0)
    X = (torch.rand(40, 5, generator=g) < 0.5).double()
    Y = (torch.rand(40, 4, generator=g) < 0.5).double()
    pi, po = torch.tensor([3, 0, 4, 1, 2]), torch.tensor([2, 3, 0, 1])
    m0 = make_replacement(cls, 5, 4, torch.Generator().manual_seed(2)).double()
    m1 = permute_model(m0, pi, po)
    o0, o1 = torch.optim.Adam(m0.parameters(), lr=1e-2), torch.optim.Adam(m1.parameters(), lr=1e-2)

    def mapped(m_src, tensors):
        """the permutation applied to per-parameter tensors (gradients / moments) of m_src"""
        h = copy.deepcopy(m_src)
        with torch.no_grad():
            for p_, t_ in zip(h.parameters(), tensors):
                p_.copy_(t_)
        return [p_.detach() for p_ in permute_model(h, pi, po).parameters()]

    for step in range(3):
        for m_, o_, x_, y_ in ((m0, o0, X, Y), (m1, o1, X[:, pi], Y[:, po])):
            o_.zero_grad()
            F.binary_cross_entropy_with_logits(m_(x_), y_).backward()
        g0 = mapped(m0, [p_.grad for p_ in m0.parameters()])
        assert all(torch.allclose(a, p_.grad, atol=1e-14) for a, p_ in zip(g0, m1.parameters()))
        o0.step()
        o1.step()
        for key in ("exp_avg", "exp_avg_sq"):
            s0 = mapped(m0, [o0.state[p_][key] for p_ in m0.parameters()])
            assert all(torch.allclose(a, o1.state[p_][key], atol=1e-14) for a, p_ in zip(s0, m1.parameters()))
        assert all(float(o0.state[a]["step"]) == float(o1.state[b]["step"]) for a, b in
                   zip(m0.parameters(), m1.parameters()))
        if step == 1:                                   # resume both optimizers from saved state
            sd0, sd1 = copy.deepcopy(o0.state_dict()), copy.deepcopy(o1.state_dict())
            o0, o1 = torch.optim.Adam(m0.parameters(), lr=1e-2), torch.optim.Adam(m1.parameters(), lr=1e-2)
            o0.load_state_dict(sd0)
            o1.load_state_dict(sd1)
    p0 = mapped(m0, [p_.detach() for p_ in m0.parameters()])
    assert all(torch.allclose(a, p_, atol=1e-14) for a, p_ in zip(p0, m1.parameters()))


def test_symmetry_summary_counts_every_expected_pair(tmp_path):
    from test_v20 import _recode
    cfgs = _recode(recode_updates=20, recode_relabels=["identity", "bitperm_symmetric"])
    st, s = _run_st(cfgs, tmp_path)
    assert st[-1] == "complete", s
    sc = read_json(tmp_path / "runs" / run_id(cfgs[-1]) / "recode_checks.json")["symmetry_control"]
    assert sc["n_expected"] == sc["n_checked"] > 0 and sc["n_unavailable"] == 0 and sc["complete"]
    assert all(r["verdict"] in ("passed", "inconclusive_tiny_margin") for r in sc["rows"])


# ----------------------------------------------------------------------------- F4. recode audit

def _audit(tmp_path, cfgs, extra_ids=()):
    m = tmp_path / "m.jsonl"
    m.write_text("\n".join(json.dumps({"run_id": run_id(c), "cfg": c}) for c in cfgs) + "\n" +
                 "".join(json.dumps({"run_id": x, "cfg": cfgs[-1]}) + "\n" for x in extra_ids))
    r = subprocess.run([sys.executable, str(ROOT / "audit_v5/tools/recode_audit.py"), str(tmp_path),
                        str(tmp_path / "audit.json"), "--manifest", str(m)], capture_output=True, text=True)
    return r.returncode, read_json(tmp_path / "audit.json")


def test_recode_audit_passes_a_good_job_and_catches_each_defect(tmp_path):
    from test_v20 import _recode
    cfgs = _recode(recode_updates=20)
    st, s = _run_st(cfgs, tmp_path)
    assert st[-1] == "complete", s
    rc, rep = _audit(tmp_path, cfgs)
    assert rc == 0, rep["summary"]
    assert rep["summary"]["fits_planned"] == rep["summary"]["fits_with_valid_artifacts"] > 0
    rd = tmp_path / "runs" / run_id(cfgs[-1])
    # a job missing from the results
    rc, rep = _audit(tmp_path, cfgs, extra_ids=["cop-doesnotexist000000"])
    assert rc != 0 and rep["summary"]["missing_jobs"] == ["cop-doesnotexist000000"]
    # failed LP controls / empty symmetry rows / duplicate records, one at a time
    for mutate in ("lp", "sym", "dup"):
        chp, rsp = rd / "recode_checks.json", rd / "recode_result.json"
        ch0, rs0 = chp.read_text(), rsp.read_text()
        ch, rs = json.loads(ch0), json.loads(rs0)
        if mutate == "lp":
            ch["lp_controls"]["passed"] = False
        elif mutate == "sym":
            ch["symmetry_control"]["rows"] = []
        else:
            fits = [r for r in rs["rows"] if "class" in r]
            rs["rows"].append(fits[0])
        chp.write_text(json.dumps(ch))
        rsp.write_text(json.dumps(rs))
        rc, rep = _audit(tmp_path, cfgs)
        assert rc != 0 and rep["jobs"][0]["problems"], mutate
        chp.write_text(ch0)
        rsp.write_text(rs0)
    # a corrupt artifact: a per-fit problem, the report still finishes
    from cop.cop_pegs.recode import _fit_path
    plan = read_json(rd / "recode_plan.json")
    fp = _fit_path(rd, plan["fits"][0])
    fp.write_bytes(b"not a checkpoint")
    rc, rep = _audit(tmp_path, cfgs)
    assert rc != 0 and any("unreadable" in p for p in rep["jobs"][0]["problems"])
    assert rep["summary"]["fits_with_valid_artifacts"] == rep["summary"]["fits_planned"] - 1
