"""v25: forward-masked routing, repair scope, the phase-matched compact control (segment_reset), the per-stratum
sink profile, integer exactness of recoding fits (and the re-scoring of older records), recorded-device reloads,
the v25 tables, and the wave-19 panel structure."""
from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import tiny_configs as T  # noqa: E402
from cop.config import resolve, run_id, ConfigError  # noqa: E402
from cop.utils import read_json  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


def _run(cfgs, d):
    from test_v15 import _run as r
    return r(cfgs, d)


def _traj(**kw):
    from test_v19 import _traj as t
    return t(**kw)


def _diss(traj_cfg, **over):
    from test_v19 import _diss as d_
    d = d_(traj_cfg)
    return resolve({**{k: v for k, v in d.items() if k != "dissipation"}, "dissipation": {**d["dissipation"], **over}})


# ----------------------------------------------------------------------------- forward-masked routing

def test_forward_route_zeroes_unassigned_outputs_and_gradient_route_keeps_values():
    from cop.graph.ops import _f_mask_grad
    node = SimpleNamespace(attrs={"mask_key": "spec_a"})
    m = torch.tensor([1., 0., 1., 0.])
    for fwd in (False, True):
        x = torch.randn(4, 3, dtype=torch.float64, requires_grad=True)
        ctx = {"grad_masks": {"spec_a": m}, **({"mask_forward": True} if fwd else {})}
        y = _f_mask_grad(node, [x], None, None, ctx)
        if fwd:
            assert torch.equal(y[1], torch.zeros(3, dtype=torch.float64)) and torch.equal(y[0], x[0])
        else:
            assert torch.equal(y, x)                        # the forward value is unchanged
        y.sum().backward()
        assert torch.equal(x.grad, m[:, None].expand(4, 3).double())   # gradient only from assigned examples
    assert torch.equal(_f_mask_grad(node, [x], None, None, None), x)  # evaluation: no ctx, no mask


def test_spec_masks_flag_the_forward_route_and_the_config_validates_it():
    from cop.data.registry import load_bundle
    from cop.experiments.trajectory import spec_masks
    from test_v19 import SH
    b = load_bundle(SH, device="cpu")
    batch = b.train.index(torch.arange(16))
    assert "mask_forward" not in spec_masks(b, mode="redrawn_random")(batch)
    assert spec_masks(b, mode="redrawn_random", forward=True)(batch)["mask_forward"] is True
    p = _traj()
    c = dict(p[-1])
    c["growth"] = {**c["growth"], "spec_mask_route": "sideways"}
    with pytest.raises(ConfigError):
        resolve(c)


def test_forward_route_trajectory_differs_from_gradient_route_and_records_it(tmp_path):
    p = _traj()
    pf = list(p[:-1]) + [resolve({**p[-1], "growth": {**p[-1]["growth"], "spec_mask_route": "forward"}})]
    rg, rf = _run(p, tmp_path), _run(pf[-1:], tmp_path)
    acc = read_json(rf / "specialization_access.json")
    assert acc["mask_route"] == "forward" and "forward route" in acc["gradient_coverage"]["note"]
    sg = torch.load(rg / "ckpt" / "final.pt", weights_only=False)["model"]["state"]
    sf = torch.load(rf / "ckpt" / "final.pt", weights_only=False)["model"]["state"]
    assert any(not torch.equal(sg[k], sf[k]) for k in sg if sg[k].is_floating_point())


# ----------------------------------------------------------------------------- repair scope

def _tensors(ck):
    return [v for v in torch.load(ck, weights_only=False)["model"]["state"].values() if v.is_floating_point()]


@pytest.mark.parametrize("scope,n_changed", [("readout", 2), ("top2", 4)])
def test_repair_scope_trains_only_the_last_layers_after_an_abrupt_deletion(tmp_path, scope, n_changed):
    p = _traj()
    d = _diss(p[-1], repair_scope=scope)
    rd = _run(p + [d], tmp_path)
    start = _tensors(tmp_path / "runs" / run_id(p[-1]) / "ckpt" / "final.pt")
    end = _tensors(rd / "ckpt" / "export.pt")
    # every compact tensor outside the scope is a backbone tensor of the trained state, unchanged (weight + bias
    # per linear layer in the scope changed)
    unchanged = sum(any(e.shape == s.shape and torch.equal(e, s) for s in start) for e in end)
    assert unchanged == len(end) - n_changed
    j = read_json(rd / "dissipation_result.json")
    assert j["repair_scope"]["scope"] == scope and j["repair_scope"]["trainable_params"] < \
        j["repair_scope"]["compact_params"]


def test_full_scope_changes_the_backbone_and_scope_config_is_validated(tmp_path):
    p = _traj()
    rd = _run(p + [_diss(p[-1])], tmp_path)
    start = _tensors(tmp_path / "runs" / run_id(p[-1]) / "ckpt" / "final.pt")
    end = _tensors(rd / "ckpt" / "export.pt")
    assert sum(any(e.shape == s.shape and torch.equal(e, s) for s in start) for e in end) == 0
    with pytest.raises(ConfigError):
        _diss(p[-1], repair_scope="bottom")
    with pytest.raises(ConfigError):
        _diss(p[-1], repair_scope="readout", method="fold")


def test_scope_pkeys_follow_topological_order(tmp_path):
    from cop.graph.graph import GraphNet
    from cop.experiments.dissipation import scope_pkeys
    p = _traj()
    rd = _run(p[:1], tmp_path)
    g = GraphNet.from_checkpoint(torch.load(rd / "ckpt" / "baseline.pt", weights_only=False)["model"])
    order = []
    for n in g.topo_order(g.live_nodes()):
        pk = g.nodes[n].pkey
        if pk is not None and pk not in order and any(True for _ in g.mods[pk].parameters()):
            order.append(pk)
    assert len(order) >= 3
    assert scope_pkeys(g, "full") is None
    assert scope_pkeys(g, "readout") == {order[-1]}
    assert scope_pkeys(g, "top2") == set(order[-2:])


# ----------------------------------------------------------------------------- sink profile

def test_sink_profile_has_the_strata_and_conditions(tmp_path):
    p = _traj()
    rd = _run(p + [_diss(p[-1])], tmp_path)
    sp = read_json(rd / "dissipation_result.json")["sink_profile"]
    jd = sp["joint_deletion"]
    assert jd["all"]["n"] == 256
    assert {"branch_a_examples", "branch_b_examples", "shortcut_conflict", "shortcut_agree", "f0_hardest_quarter"} \
        <= set(jd)
    assert jd["branch_a_examples"]["n"] + jd["branch_b_examples"]["n"] == 256
    assert sp["intact"]["all"]["loss_increase"] == 0.0
    assert sp["single_deletion"] and set(sp["slots"]) == set(sp["single_deletion"])
    assert "err" in sp["f0"]["all"]


def test_sink_profile_has_no_membership_strata_for_a_redrawn_split(tmp_path):
    p = _traj(part="redrawn_random")
    rd = _run(p + [_diss(p[-1])], tmp_path)
    jd = read_json(rd / "dissipation_result.json")["sink_profile"]["joint_deletion"]
    assert "branch_a_examples" not in jd and "all" in jd


# ----------------------------------------------------------------------------- segment_reset (C1_phase)

def _cont(seg, arm="plain", reset=None):
    from test_v19 import SH
    b = resolve({"kind": "baseline", "data": SH, "model": T.MODEL, "train": T.TRAIN, "seeds": {"optimizer": 0}})
    cc = {"start": "baseline", "start_stage": "baseline", "budget": "fixed", "arm": arm, "segments": seg}
    if reset is not None:
        cc["segment_reset"] = reset
    c = resolve({"kind": "continue", "data": SH, "model": T.MODEL, "train": T.TRAIN, "seeds": {"optimizer": 0},
                 "parents": {"baseline": run_id(b)}, "continue": cc})
    return [b, c]


def _final_state(rd):
    return torch.load(rd / "ckpt" / "final.pt", weights_only=False)["model"]["state"]


def test_segment_reset_all_true_equals_opt_reset_and_all_false_equals_one_segment(tmp_path):
    def same(a, b):
        return all(torch.equal(a[k], b[k]) for k in a)
    r_t = _run(_cont([5, 5], reset=[True, True]), tmp_path)
    r_o = _run(_cont([5, 5], arm="opt_reset")[1:], tmp_path)
    assert same(_final_state(r_t), _final_state(r_o))
    r_f = _run(_cont([5, 5], reset=[False, False])[1:], tmp_path)
    r_1 = _run(_cont([10])[1:], tmp_path)
    assert same(_final_state(r_f), _final_state(r_1))
    r_m = _run(_cont([5, 5], reset=[False, True])[1:], tmp_path)
    assert not same(_final_state(r_m), _final_state(r_f))
    assert read_json(r_m / "continue_result.json")["segment_reset"] == [False, True]


def test_segment_reset_config():
    with pytest.raises(ConfigError):
        _cont([5, 5], reset=[True])
    with pytest.raises(ConfigError):
        _cont([5, 5], arm="opt_reset", reset=[True, True])


# ----------------------------------------------------------------------------- integer exactness

def test_curve_exact_uses_integer_counts_and_rounds_old_fractions():
    from cop.cop_pegs.recode import curve_exact
    assert curve_exact({"n_wrong": 0, "exact_unweighted": 0.5})          # the count decides
    assert not curve_exact({"n_wrong": 1, "exact_unweighted": 1.0})
    assert curve_exact({"exact_unweighted": 0.9999999999999999}, 1000)    # pre-v25 record: rounded to a count
    assert not curve_exact({"exact_unweighted": 0.999}, 1000)
    assert not curve_exact({"exact_unweighted": 1 - 1 / 5000}, 5000)


def test_integer_exactness_reclassifies_a_float_censored_record():
    from cop.analysis.v13_tables import integer_exactness
    x = {"status": "censored", "support_size": 1000,
         "curve": [{"update": 0, "exact_unweighted": 0.5}, {"update": 25, "exact_unweighted": 0.9999999999999999}]}
    r = integer_exactness(x)
    assert r["status_integer"] == "exact" and r["status_corrected"] and r["first_exact_update_integer"] == 25
    assert r["sustained_exact_from_integer"] == 25 and r["final_exact_integer"]
    x2 = {"status": "numerical_failure", "curve": []}
    assert integer_exactness(x2) == {"status_integer": "numerical_failure", "status_corrected": False}


def test_fit_replacement_records_the_integer_count():
    from cop.cop_pegs.recode import fit_replacement, index_to_bits
    X = index_to_bits(torch.arange(8), 3).double()
    Y = X.clone()
    w = torch.ones(8)
    f = fit_replacement("linear", X, Y, w, updates=300, lr=0.1, every=50, gen=torch.Generator().manual_seed(0),
                        device="cpu")
    assert all("n_wrong" in c and c["n_support"] == 8 for c in f["curve"])
    assert (f["status"] == "exact") == any(c["n_wrong"] == 0 for c in f["curve"])
    assert f["status"] == "exact"


# ----------------------------------------------------------------------------- tables

def test_dependence_benefit_table_scopes():
    from cop.analysis.v13_tables import dependence_benefit_table
    rows = []
    for rep, ds in (("r0", 0), ("r1", 1)):
        for v, (fr, rp) in {"fixed": (0.4, 0.18), "redrawn": (0.2, 0.22), "q": (0.3, 0.2)}.items():
            for ps in range(3):
                rows.append({"variant": v, "replication": f"{rep}_p{ps}", "data_draw": ds, "optimizer_seed": 0,
                             "frozen_removed_test_err": fr + 0.01 * ps, "repaired_test_err": rp - 0.001 * ps})
    out = dependence_benefit_table(rows, "t")
    across = [r for r in out if r["scope"] == "across_arms_within_replication"]
    assert len(across) == 6 and all(r["pearson_r"] < -0.9 for r in across)
    within = [r for r in out if r["scope"].startswith("within_arm_within_draw")]
    assert len(within) == 6 and all(r["n"] == 3 and r["pearson_r"] == pytest.approx(-1.0) for r in within)
    # rebuilt or scope-restricted removals are excluded
    rows.append({**rows[0], "repair_scope": "readout"})
    assert len(dependence_benefit_table(rows, "t")) == len(out)


# ----------------------------------------------------------------------------- wave 19

def test_wave19_panel_structure():
    import json
    from cop.orchestration.manifest import generate
    B = generate([19], "full")
    ents = {k: e["cfg"] for k, e in B.entries.items()}
    blocks = {}
    for e in B.entries.values():
        blocks.setdefault(e["blocks"][0], []).append(e["cfg"])
    assert set(blocks) >= {"V25_core", "V25_scope", "V25_optseed", "V25_noise", "V25_width", "V25_task2"}
    assert len(ents) == 330
    tr = [c for c in ents.values() if c["kind"] == "trajectory"]
    fw = [c for c in tr if c["growth"]["spec_mask_route"] == "forward"]
    assert {c["growth"]["spec_partition"] for c in fw} == {"random_matched", "redrawn_random"}
    assert {c["data"]["label_noise"] for c in tr} == {0.0, 0.1, 0.3}
    assert {c["growth"]["width"] for c in tr} == {8, 32, 128}
    ct = [c for c in tr if c["data"]["name"] == "covertype"]
    assert ct and all(c["growth"].get("spec_random_fraction") in (0.95, None) for c in ct)
    assert all(c["growth"]["spec_random_fraction"] == 0.95 for c in ct if c["growth"]["spec_partition"] != "matched_quota")
    assert {c["seeds"]["optimizer"] for c in tr} == {0, 1}
    # one removal protocol per cell for the plain removals; abrupt removals carry the same total repair budget
    for cell in ("shortcut", "covertype"):
        di = [c for c in ents.values() if c["kind"] == "dissipation" and c["data"]["name"] == cell]
        lin = [c["dissipation"] for c in di if c["dissipation"]["method"] == "linear"]
        abr = [c["dissipation"] for c in di if c["dissipation"]["method"] == "abrupt"]
        assert len({json.dumps([d["speed_updates"], d["post_updates"]]) for d in lin}) == 1
        assert {d["post_updates"] for d in abr} == {lin[0]["speed_updates"] + lin[0]["post_updates"]}
        assert {d["repair_scope"] for d in abr} <= {"readout", "top2", "full"}
        assert all(d["repair_scope"] == "full" for d in lin)
    # C1_phase: the treated history's phases with resets where the history resets, same total as C1's budget
    for c in ents.values():
        if (c.get("design") or {}).get("arm") == "C1_phase":
            U = next(t for t in tr if t["data"] == c["data"])["growth"]["updates_per_round"]
            seg = c["continue"]["segments"]
            assert seg[:2] == [U, U] and c["continue"]["segment_reset"] == [False, False, True, True]
            assert seg[2] == max(1, round(0.1 * U)) and sum(seg) == 2 * U + round(1.5 * U)
    # pristine rebuilds exist for every scope on the shortcut cell
    pr = [c for c in ents.values() if c["kind"] == "dissipation" and c["design"]["variant"] == "pristine"]
    assert {c["dissipation"]["repair_scope"] for c in pr} == {"readout", "top2", "full"}
    assert all(c["dissipation"]["rebuild"] == {"backbone": "f0", "implants": "fresh"} for c in pr)
