"""v26: the parameter-only mask route, limited repair data, the contraction variants and the wave-20 panel."""
from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
from cop.config import resolve, run_id, ConfigError  # noqa: E402
from cop.utils import read_json  # noqa: E402


def _run(cfgs, d):
    from test_v15 import _run as r
    return r(cfgs, d)


def _traj(**kw):
    from test_v19 import _traj as t
    return t(**kw)


def _diss(traj_cfg, **over):
    from test_v19 import _diss as d_
    d = d_(traj_cfg)
    return resolve({**{k: v for k, v in d.items() if k != "dissipation"}, "dissipation": {**d["dissipation"], **over}})


# ----------------------------------------------------------------------------- parameter route

def test_parameter_route_masks_weight_gradients_but_not_input_gradients():
    from cop.graph.ops import _f_linear, _f_mask_grad
    torch.manual_seed(0)
    g = SimpleNamespace(implants={"i1": SimpleNamespace(meta={"specialization": {"mask_key": "spec_a"}}),
                                  "i2": SimpleNamespace(meta={})})
    node = SimpleNamespace(owner="i1", attrs={"layout": "vec"})
    mod = torch.nn.Linear(3, 2).double()
    m = torch.tensor([1., 0., 1., 0.], dtype=torch.float64)
    x = torch.randn(4, 3, dtype=torch.float64, requires_grad=True)
    ctx = {"grad_masks": {"spec_a": m}, "mask_param_only": True}
    y = _f_linear(node, [x], mod, g, ctx)
    assert torch.allclose(y, mod(x), atol=1e-15, rtol=0)                  # same forward value
    y.sum().backward()
    ones = torch.ones(4, 2, dtype=torch.float64)
    assert torch.allclose(x.grad, ones @ mod.weight.detach(), atol=1e-14)  # every example reaches the input
    assert torch.allclose(mod.weight.grad, (m[:, None] * ones).T @ x.detach(), atol=1e-14)  # assigned rows only
    assert torch.allclose(mod.bias.grad, (m[:, None] * ones).sum(0), atol=1e-14)
    # a node outside a specialised branch, and the mask node itself, are untouched under the parameter route
    other = SimpleNamespace(owner="i2", attrs={"layout": "vec"})
    x2 = torch.randn(4, 3, dtype=torch.float64)
    assert torch.equal(_f_linear(other, [x2], mod, g, ctx), mod(x2))
    xm = torch.randn(4, 3, dtype=torch.float64, requires_grad=True)
    _f_mask_grad(SimpleNamespace(attrs={"mask_key": "spec_a"}), [xm], None, g, ctx).sum().backward()
    assert torch.equal(xm.grad, torch.ones_like(xm))


def test_parameter_route_trajectory_records_and_differs_from_the_gradient_route(tmp_path):
    p = _traj()
    pp = list(p[:-1]) + [resolve({**p[-1], "growth": {**p[-1]["growth"], "spec_mask_route": "parameter"}})]
    rg, rp = _run(p, tmp_path), _run(pp[-1:], tmp_path)
    acc = read_json(rp / "specialization_access.json")
    assert acc["mask_route"] == "parameter" and "parameter route" in acc["gradient_coverage"]["note"]
    sg = torch.load(rg / "ckpt" / "final.pt", weights_only=False)["model"]["state"]
    sp = torch.load(rp / "ckpt" / "final.pt", weights_only=False)["model"]["state"]
    assert any(not torch.equal(sg[k], sp[k]) for k in sg if sg[k].is_floating_point())
    with pytest.raises(ConfigError):
        resolve({**p[-1], "growth": {**p[-1]["growth"], "spec_mask_route": "parameter",
                                     "spec_partition": "all_examples"}})


# ----------------------------------------------------------------------------- limited repair data

def test_repair_subset_is_recorded_and_changes_the_repair(tmp_path):
    p = _traj()
    full = _diss(p[-1])
    sub = _diss(p[-1], repair_subset=32)
    _run(p + [full], tmp_path)
    rs = _run([sub], tmp_path)
    j = read_json(rs / "dissipation_result.json")
    assert j["repair_subset"]["n"] == 32 and j["repair_subset"]["of"] == 256
    a = torch.load(tmp_path / "runs" / run_id(full) / "ckpt" / "export.pt", weights_only=False)["model"]["state"]
    b = torch.load(rs / "ckpt" / "export.pt", weights_only=False)["model"]["state"]
    assert any(not torch.equal(a[k], b[k]) for k in a if a[k].is_floating_point())
    with pytest.raises(ConfigError):
        _diss(p[-1], repair_subset=-1)


def test_repair_subset_draws_only_subset_examples(tmp_path, monkeypatch):
    """every repair batch's examples are in the declared subset (the trainer's sampled indices are captured)."""
    from cop.train import trainer as TR
    seen = []
    orig = TR.Trainer.next_batch

    def spy(self):
        b = orig(self)
        seen.append((len(self.bundle.train), b))
        return b
    monkeypatch.setattr(TR.Trainer, "next_batch", spy)
    p = _traj()
    _run(p, tmp_path)
    seen.clear()
    _run([_diss(p[-1], repair_subset=32)], tmp_path)
    sizes = {n for n, _ in seen}
    assert sizes == {32}                       # abrupt removal: every update is a repair update


# ----------------------------------------------------------------------------- wave 20

def test_wave20_panel_structure():
    from cop.orchestration.manifest import generate
    B = generate([20], "full")
    ents = {k: e["cfg"] for k, e in B.entries.items()}
    assert len(ents) == 504
    blocks = {}
    for e in B.entries.values():
        blocks.setdefault(e["blocks"][0], []).append(e["cfg"])
    assert {"V26_route", "V26_contraction", "V26_repair_data", "V25_core", "V25_task2"} <= set(blocks)
    assert all(c["wave"] == 20 for c in ents.values() if c["kind"] != "baseline")
    tr = [c for c in ents.values() if c["kind"] == "trajectory"]
    routes = {(c["growth"]["spec_partition"], c["growth"]["spec_mask_route"]) for c in tr}
    assert {("random_matched", "parameter"), ("redrawn_random", "parameter"), ("matched_quota", "parameter"),
            ("matched_quota", "forward"), ("all_examples", "gradient")} <= routes
    U = next(c for c in tr if c["data"]["name"] == "shortcut")["growth"]["updates_per_round"]
    con = [c for c in blocks["V26_contraction"]]
    arms = {c["design"]["arm"] for c in con}
    assert arms == {"linear_imitate", "bypass", "linear_warmup"}
    for c in con:
        if c["design"]["arm"] == "linear_warmup":
            assert c["train"]["warmup"] == max(1, U // 20)
        elif c["design"]["arm"] == "linear_imitate":
            assert c["dissipation"]["target"] == "expanded" and c["train"]["warmup"] == 0
        else:
            assert c["dissipation"]["method"] == "stochastic_bypass" and c["dissipation"]["bypass_keep"] == 0.5
    rd = blocks["V26_repair_data"]
    assert {c["dissipation"]["repair_subset"] for c in rd} == {256, 1024}
    assert all(c["dissipation"]["method"] == "abrupt" for c in rd)
    assert {c["data"]["data_seed"] for c in rd} == {0, 203, 204}


# ----------------------------------------------------------------------------- selective reversal tool

def test_selective_reversal_full_reversal_is_f0_and_no_reversal_is_the_deleted_state(tmp_path):
    """v34: rewritten for the current tool's outputs (_codes.csv; the v27 _rows.csv grid is gone since v29)."""
    import csv
    import subprocess
    p = _traj()
    d = _diss(p[-1], method="linear", speed_updates=3, post_updates=3, save_path_checkpoints=True)
    d = resolve({**d, "design": {"family": "X25", "variant": "fixed", "arm": "treated", "contrast": "X25|c"}})
    _run(p + [d], tmp_path)
    tool = str(Path(__file__).resolve().parents[1] / "audit_v5/tools/selective_reversal.py")
    r = subprocess.run([sys.executable, tool, str(tmp_path), str(tmp_path / "sr"), "--codes", "auto"],
                       capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr
    rows = list(csv.DictReader(open(tmp_path / "sr_codes.csv")))
    assert {x["state"] for x in rows} == {"abrupt", "after_transition", "repaired"}
    k = len(rows[0]["code"].split("-"))
    for stn in ("abrupt", "after_transition", "repaired"):
        rs = {x["code"]: x for x in rows if x["state"] == stn}
        full, none = rs["-".join(["1"] * k)], rs["-".join(["0"] * k)]
        assert full["test_err"] == full["f0_test_err"] and full["function"] == "layer_transplant"
        assert none["function"] in ("branch_deleted", "native")
    checks = list(csv.DictReader(open(tmp_path / "sr_checks.csv")))
    assert checks and all(c["full_restore_identity"] == "True" and c["zero_code_identity"] == "True" for c in checks)
