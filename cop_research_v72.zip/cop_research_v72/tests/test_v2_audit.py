"""Regression tests derived from the independent v1 audit (one section per
finding).  Each test asserts the INTENDED behaviour; the original probes in
the audit bundle reported `defect_confirmed=true` against v1."""
from __future__ import annotations

import copy
import json
import math
import subprocess
import sys
import time
from collections import Counter
from fractions import Fraction
from pathlib import Path
from types import SimpleNamespace

import pytest
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).parent))

import tiny_configs as T  # noqa: E402
from cop.config import resolve, run_id, condition_id, replication_key, GROWTH_DEFAULTS, ConfigError  # noqa: E402
from cop.graph import edits as E  # noqa: E402
from cop.graph.builders import build_mlp  # noqa: E402
from cop.graph.graph import GraphNet  # noqa: E402
from cop.orchestration.runner import run_job, status_of, effective_status  # noqa: E402
from cop.utils import torch_gen, read_json, read_jsonl, INTERRUPT, semantic_code_hash, atomic_write_json  # noqa: E402

EX = {"device": "cpu"}


def run_all(cfgs, root):
    out = []
    for c in cfgs:
        INTERRUPT["flag"] = False
        out.append(run_job(c, root, EX))
    return out


def rdir(root, cfg):
    return Path(root) / "runs" / run_id(cfg)


# =============================================================================
# F1  transition certificates are independently checkable
# =============================================================================

def _transition_cert(system="absorbing_toy", params=None, **kw):
    from cop.finite import _transition, FINITE_DEFAULTS
    args = copy.deepcopy(FINITE_DEFAULTS["transition"])
    args.update(system=system, params=params or {}, **kw)
    return _transition(args, time.time() + 120)[0]


@pytest.mark.parametrize("system,params", [("absorbing_toy", {}), ("absorbing_toy", {"with_good_closed_class": True}),
                                           ("permutation_chain", {}), ("quantized_chain", {"K": 1, "rule": "metropolis"})])
def test_F1_genuine_transition_certificates_verify(system, params):
    from cop.finite.checker import verify_certificate
    v = verify_certificate(_transition_cert(system, params))
    assert v["ok"] and v["verdict"] == "verified", v
    assert v["checks"]["hitting_probabilities"] in ("exact", "numerical")


def test_F1_forged_complexity_map_with_true_spec_is_rejected():
    """The audit's forgery: graph annotations from a WRONG complexity map, true
    spec restored in all three spec fields, inevitability flipped to true."""
    from cop.finite import _transition, FINITE_DEFAULTS
    from cop.finite.checker import verify_certificate
    cert = _transition_cert("absorbing_toy", {"with_good_closed_class": True})
    spec = copy.deepcopy(cert["data"]["system"])
    bad = copy.deepcopy(spec)
    bad["complexity"] = {k: 2 for k in spec["complexity"]}
    ta = copy.deepcopy(FINITE_DEFAULTS["transition"])
    ta.update(system="table", params={k: v for k, v in bad.items() if k != "kind"})
    forged = _transition(ta, time.time() + 60)[0]
    for dest, key in [(forged["data"], "system"), (forged["class"], "system"), (forged, "edit_rules")]:
        dest[key] = copy.deepcopy(spec)
    assert [x["entrenchment_inevitable"] for x in forged["data"]["initial"]] != \
        [x["entrenchment_inevitable"] for x in cert["data"]["initial"]]
    v = verify_certificate(forged)
    assert not v["ok"] and v["verdict"] == "rejected", v
    fixture = Path(__file__).parent / "fixtures" / "tampered_transition_certificate_v1_audit.json"
    if fixture.exists():
        assert verify_certificate(str(fixture))["verdict"] == "rejected"


def _corruptions(cert):
    """(name, mutate(c)) pairs, each corrupting ONE claimed field."""
    i0 = 0
    out = [
        ("negative_time_where_p1", None),
        ("flip_inevitability", lambda c: c["data"]["initial"][i0].__setitem__(
            "entrenchment_inevitable", not c["data"]["initial"][i0]["entrenchment_inevitable"])),
        ("flip_bad_reachable", lambda c: c["data"]["initial"][i0].__setitem__(
            "bad_class_reachable", not c["data"]["initial"][i0]["bad_class_reachable"])),
        ("flip_p_hit_one", lambda c: c["data"]["initial"][i0].__setitem__(
            "p_hit_simple_is_one_graph_exact", not c["data"]["initial"][i0]["p_hit_simple_is_one_graph_exact"])),
        ("wrong_p_hit", lambda c: c["data"]["initial"][i0].__setitem__("p_hit_simple", "1/7")),
        ("wrong_label", lambda c: c["data"]["initial"][i0].__setitem__("return_label", "return_impossible")),
        ("wrong_threshold", lambda c: c["data"].__setitem__("simple_threshold", c["data"]["simple_threshold"] + 1)),
        ("wrong_n_states", lambda c: c["data"].__setitem__("n_states", c["data"]["n_states"] + 1)),
        ("wrong_label_counts", lambda c: c["data"]["return_label_counts"].__setitem__("in_simple_set", 99)),
        ("drop_closed_class", lambda c: c["data"]["closed_classes"].pop()),
        ("closed_class_contents", lambda c: c["data"]["closed_classes"][0]["members"].append(
            (c["data"]["closed_classes"][0]["members"][0] + 1) % c["data"]["n_states"])),
        ("closed_class_label", lambda c: c["data"]["closed_classes"][0].__setitem__(
            "contains_simple", not c["data"]["closed_classes"][0]["contains_simple"])),
        ("graph_complexity", lambda c: c["data"]["graph"]["complexity"].__setitem__(
            0, c["data"]["graph"]["complexity"][0] + 5)),
        ("graph_loss", lambda c: c["data"]["graph"]["loss"].__setitem__(0, "17")),
        ("graph_edge_prob", lambda c: c["data"]["graph"]["edges"][0].__setitem__(2, "1/9")),
        ("graph_label", lambda c: c["data"]["graph"]["labels"].__setitem__(0, "return_impossible")),
        ("spec_mismatch_class", lambda c: c["class"]["system"].__setitem__("initial", ["s0"])),
        ("spec_mismatch_edit_rules", lambda c: c.__setitem__("edit_rules", {"kind": "table"})),
        ("claim_complete_when_incomplete", lambda c: c["coverage"].__setitem__("complete", False)),
        ("initial_state_swapped", lambda c: c["data"]["initial"].reverse()),
    ]
    return out


def test_F1_every_field_corruption_is_rejected():
    from cop.finite.checker import verify_certificate
    base = _transition_cert("absorbing_toy")
    assert verify_certificate(base)["verdict"] == "verified"
    for name, fn in _corruptions(base):
        c = copy.deepcopy(base)
        if name == "negative_time_where_p1":
            idx = next((k for k, r in enumerate(c["data"]["initial"]) if r["expected_time_to_simple"] not in (None, 0)),
                       None)
            if idx is None:
                continue
            c["data"]["initial"][idx]["expected_time_to_simple"] = "-999"
        else:
            try:
                fn(c)
            except (IndexError, KeyError):
                continue
        if c == base:
            continue
        v = verify_certificate(c)
        assert not v["ok"] and v["verdict"] == "rejected", (name, v)


def test_F1_unexported_graph_checks_aggregates_and_threshold_override():
    from cop.finite.checker import verify_certificate
    c = _transition_cert("permutation_chain", {}, export_graph_max_states=3)
    assert c["data"]["graph"] is None
    v = verify_certificate(c)
    assert v["verdict"] == "verified", v
    c2 = copy.deepcopy(c)
    c2["data"]["closed_classes"][0]["size"] += 1
    assert verify_certificate(c2)["verdict"] == "rejected"
    # threshold given by the job config is recorded and re-applied
    c3 = _transition_cert("permutation_chain", {}, simple_threshold=2)
    assert c3["class"]["simple_threshold_override"] == 2 and verify_certificate(c3)["verdict"] == "verified"
    c4 = copy.deepcopy(c3)
    c4["class"]["simple_threshold_override"] = 1
    assert verify_certificate(c4)["verdict"] == "rejected"


def test_F1_incomplete_analysis_and_too_large_space_never_verify_as_proof():
    from cop.finite.checker import verify_certificate
    c = _transition_cert("permutation_chain", {}, state_cap=5)
    assert c["status"] == "incomplete" and verify_certificate(c)["verdict"] == "verified"
    bad = copy.deepcopy(c)
    bad["status"] = "complete_analysis"
    assert verify_certificate(bad)["verdict"] == "rejected"
    bad2 = copy.deepcopy(c)
    bad2["data"]["graph"]["labels"][-1] = "return_impossible"
    assert verify_certificate(bad2)["verdict"] == "rejected"


def _fix_incomplete_aggregates(c):
    """Make every aggregate of an incomplete certificate consistent with its
    (possibly forged) graph, so only the substantive checks can catch a forgery."""
    d, g = c["data"], c["data"]["graph"]
    n = len(g["states"])
    d["n_states"] = c["domain"]["n_states"] = c["coverage"]["examined"] = n
    d["state_cap"] = c["domain"]["state_cap"] = c["class"]["state_cap"] = n
    d["n_edges"] = len(g["edges"])
    d["n_simple"] = sum(1 for x in g["labels"] if x == "in_simple_set")
    d["return_label_counts"] = dict(Counter(g["labels"]))
    for r, j in zip(d["initial"], g["initial"]):
        r["return_label"] = g["labels"][j]


def test_F1_incomplete_certificates_check_the_explored_subgraph():
    """Review finding R1: an incomplete certificate must not 'verify' a
    fabricated return path, unreachable states, or forged reports."""
    from cop.finite.checker import verify_certificate as V
    base = _transition_cert("permutation_chain", {}, state_cap=5, simple_threshold=1)
    assert base["status"] == "incomplete" and V(base)["verdict"] == "verified", V(base)
    g0 = base["data"]["graph"]
    n0 = len(g0["states"])
    assert "unsearched" in g0["labels"]

    # (a) fabricated unreachable simple state (the identity chain) with edges from unexpanded states
    c = copy.deepcopy(base)
    g = c["data"]["graph"]
    g["states"].append([[0, 1, 2]]); g["complexity"].append(1); g["loss"].append("3")
    g["expanded"].append(False); g["labels"].append("in_simple_set")
    g["expanded"] = [False] * len(g["states"])
    g["edges"] = [[i, n0, "1"] for i in range(n0)]
    g["labels"] = ["in_simple_set" if g["complexity"][i] <= 1 else "return_possible_witnessed_incomplete"
                   for i in range(len(g["states"]))]
    _fix_incomplete_aggregates(c)
    v = V(c)
    assert v["verdict"] == "rejected", v

    # (b) an exported state with no exported path from the initial states
    c = copy.deepcopy(base)
    g = c["data"]["graph"]
    g["states"].append([[0, 1, 2]]); g["complexity"].append(1); g["loss"].append("3")
    g["expanded"].append(False); g["labels"].append("in_simple_set")
    _fix_incomplete_aggregates(c)
    v = V(c)
    assert v["verdict"] == "rejected" and "not reachable" in v["reasons"][0], v

    # (c) a 'witnessed' label on a state that has no exported path to S*
    c = copy.deepcopy(base)
    j = c["data"]["graph"]["labels"].index("unsearched")
    c["data"]["graph"]["labels"][j] = "return_possible_witnessed_incomplete"
    _fix_incomplete_aggregates(c)
    assert V(c)["verdict"] == "rejected"

    # (d) each aggregate / report field forged alone
    muts = [
        lambda c: c["data"]["initial"][0].__setitem__("complexity", 7),
        lambda c: c["data"]["initial"][0].__setitem__("loss", "5"),
        lambda c: c["data"]["initial"][0].__setitem__("state", [[0, 1, 2]]),
        lambda c: c["data"]["initial"][0].__setitem__("return_label", "return_possible_witnessed_incomplete"),
        lambda c: c["data"].__setitem__("n_states", 999),
        lambda c: c["data"].__setitem__("simple_threshold", 42),
        lambda c: c["data"].__setitem__("n_simple", 99),
        lambda c: c["data"].__setitem__("n_edges", -1),
        lambda c: c["data"].__setitem__("return_label_counts", {"bogus": 1}),
        lambda c: c["data"]["graph"]["edges"].append(list(c["data"]["graph"]["edges"][0])),
        lambda c: c["data"]["graph"].__setitem__("expanded", [True] * n0),
        lambda c: c["data"].__setitem__("incomplete_reason", "deadline"),
        lambda c: c["data"].__setitem__("hitting_arithmetic", "float64"),
    ]
    for k, m in enumerate(muts):
        c = copy.deepcopy(base)
        m(c)
        assert V(c)["verdict"] == "rejected", (k, V(c))


def test_F1_incomplete_table_search_with_zero_probability_moves_verifies():
    """Review finding R11: explicit p = 0 transitions are not exported edges and
    must not make a genuine incomplete certificate fail."""
    from cop.finite.checker import verify_certificate as V
    t = {"a": [["1/2", "b", "x"], ["1/2", "c", "y"], ["0", "d", "z"]], "b": [["1", "a", "x"]],
         "c": [["1/2", "d", "x"], ["1/2", "c", "y"]], "d": [["1", "d", "x"]]}
    params = {"transitions": t, "complexity": {"a": 1, "b": 2, "c": 2, "d": 3},
              "loss": {"a": 0, "b": 0, "c": 1, "d": 1}, "initial": ["a"], "simple_threshold": 1}
    full = _transition_cert("table", params)
    assert full["status"] == "complete_analysis" and V(full)["verdict"] == "verified", V(full)
    inc = _transition_cert("table", params, state_cap=3)
    assert inc["status"] == "incomplete", inc["status"]
    assert V(inc)["verdict"] == "verified", V(inc)


def test_F1_long_time_flags_and_duplicated_fields_are_checked():
    """Review finding R2: the long-time threshold is the configured one, the flag
    is required, and duplicated domain / coverage / precision fields must agree."""
    from cop.finite.checker import verify_certificate as V
    b = _transition_cert("absorbing_toy")
    assert V(b)["verdict"] == "verified"
    assert any("long_expected_time" in r for r in b["data"]["initial"])
    assert b["class"]["long_time_threshold"] == 1000.0 and b["class"]["state_cap"] == 200_000

    def flip(c):
        for r in c["data"]["initial"]:
            if "long_expected_time" in r:
                r["long_expected_time"] = not r["long_expected_time"]
    muts = {
        "drop_threshold_and_flip": lambda c: (c["data"].pop("long_time_threshold"), flip(c)),
        "threshold_in_data_only": lambda c: (c["data"].__setitem__("long_time_threshold", 0.5), flip(c)),
        "drop_flag": lambda c: [r.pop("long_expected_time", None) for r in c["data"]["initial"]],
        "flag_on_infinite_time": lambda c: [r.setdefault("long_expected_time", False) for r in c["data"]["initial"]],
        "domain_n_states": lambda c: c["domain"].__setitem__("n_states", 3),
        "domain_state_cap": lambda c: c["domain"].__setitem__("state_cap", 7),
        "data_state_cap": lambda c: c["data"].__setitem__("state_cap", 1),
        "class_state_cap": lambda c: c["class"].__setitem__("state_cap", 9),
        "precision": lambda c: c.__setitem__("precision", "exact_rational graph; hitting=float64; time=float64"),
        "coverage_reason": lambda c: c["coverage"].__setitem__("incomplete_reason", "state_cap"),
        "coverage_examined": lambda c: c["coverage"].__setitem__("examined", 1),
    }
    for name, m in muts.items():
        c = copy.deepcopy(b)
        m(c)
        assert c != b, name
        assert V(c)["verdict"] == "rejected", (name, V(c))


def test_F1_certificate_class_must_match_the_job_configuration(tmp_path, monkeypatch):
    """A self-consistent certificate for a different threshold than the job
    configured is rejected by the job, not only by field checks."""
    import cop.finite as F
    real = F._transition

    def other_threshold(c, deadline):
        c2 = dict(c, long_time_threshold=0.5)
        return real(c2, deadline)
    monkeypatch.setattr(F, "_transition", other_threshold)
    s = F.run_finite_job({"kind": "transition", "transition": {"system": "absorbing_toy"}}, tmp_path / "f")
    v = s["certificates"][0]["independent_check"]
    assert v["verdict"] == "rejected" and "configuration" in v["reasons"][0], v


def test_F1_numerical_hitting_check_is_sparse_and_exact_on_a_large_system():
    """Review finding R5: the float64 checker path must not build a dense matrix."""
    from cop.finite.checker import _solve_hitting
    n = 30_000
    succ = [{max(v - 1, 0): Fraction(1, 2), min(v + 1, n - 1): Fraction(1, 2)} for v in range(n)]
    U = list(range(1, n - 1))
    known = {0: 1, n - 1: 0}
    x = _solve_hitting(U, succ, known, 0, False)
    # gambler's ruin: P(hit 0 from v) = 1 - v / (n - 1)
    for v in (1, 1234, n - 2):
        assert abs(x[v] - (1 - v / (n - 1))) < 1e-8


def test_F1_other_certificate_types_reject_tampering(tmp_path):
    from cop.finite import run_finite_job
    from cop.finite.checker import verify_certificate
    cases = {
        "bool": ({"kind": "boolean_class", "boolean_class": {"target": "xor", "hidden_widths": [2]}},
                 [lambda c: c["witness"].__setitem__("errors", c["witness"]["errors"] + 1),
                  lambda c: c["data"].__setitem__("min_error_examined", 3),
                  lambda c: c["witness"]["params"].__setitem__(0, 7),
                  lambda c: c.__setitem__("status", "certified_no_member")]),
        "bool_none": ({"kind": "boolean_class", "boolean_class": {"target": "xor", "hidden_widths": []}},
                      [lambda c: c["data"].__setitem__("min_error_examined", 0),
                       lambda c: c["class"].__setitem__("weight_set", [-1, 1])]),
        "rank": ({"kind": "rank", "rank": {"mode": "exact", "true_rank": 3, "bottleneck": 2}},
                 [lambda c: c["data"].__setitem__("rank", 2), lambda c: c["class"]["A_shape"].__setitem__(1, 3)]),
        "rank_wit": ({"kind": "rank", "rank": {"mode": "exact", "true_rank": 2, "bottleneck": 2}},
                     [lambda c: c["witness"]["A"][0].__setitem__(0, "12345")]),
        "approx": ({"kind": "rank", "rank": {"mode": "approx", "true_rank": 4, "bottleneck": 2}},
                   [lambda c: c["data"].__setitem__("lower_bound", 1e9),
                    lambda c: c["data"]["singular_values_float64"].__setitem__(0, 0.5)]),
        "message": ({"kind": "message", "message": {"n_bits": 3, "k_bits": 2}},
                    [lambda c: c["data"].__setitem__("min_errors_examined", 0),
                     lambda c: c["data"].__setitem__("analytic_lower_bound", 99)]),
        "piecewise": ({"kind": "piecewise", "piecewise": {"width": 1}},
                      [lambda c: c["data"].__setitem__("n_pieces", 2),
                       lambda c: c["domain"]["values"].__setitem__(1, "0")]),
    }
    for name, (cfg, muts) in cases.items():
        s = run_finite_job(cfg, tmp_path / name)
        for cc in s["certificates"]:
            assert cc["independent_check"]["verdict"] == "verified", (name, cc)
        cert = json.load(open(s["certificates"][0]["path"]))
        for k, m in enumerate(muts):
            c = copy.deepcopy(cert)
            try:
                m(c)
            except (KeyError, IndexError, TypeError):
                continue
            v = verify_certificate(c)
            assert v["verdict"] == "rejected", (name, k, v)


def test_F1_finite_job_status_reflects_checker(tmp_path, monkeypatch):
    """A rejected certificate makes the JOB invalid (not merely 'complete')."""
    import cop.finite as F
    cfg = resolve({"kind": "finite", "finite": {"kind": "transition", "transition": {"system": "absorbing_toy"}}})
    assert run_job(cfg, tmp_path, EX) == "complete"
    assert status_of(tmp_path, run_id(cfg)).get("validity") == "valid"
    real = F.verify_certificate

    def lying_checker(c):
        return {"ok": False, "verdict": "rejected", "reasons": ["test"], "checks": {}}
    monkeypatch.setattr(F, "verify_certificate", lying_checker)
    cfg2 = resolve({"kind": "finite", "finite": {"kind": "transition", "transition": {"system": "permutation_chain"}}})
    assert run_job(cfg2, tmp_path, EX) == "invalid"
    monkeypatch.setattr(F, "verify_certificate", real)


# =============================================================================
# F2  analysis cells keep every manipulated condition apart
# =============================================================================

def test_F2_condition_identity_separates_settings_and_pools_seeds():
    t1 = T.traj({"topology": "layered"})[-1]
    variants = {
        "omega": dict(t1, data={**t1["data"], "params": {**t1["data"]["params"], "teacher_depth": 2}}),
        "width": dict(t1, model={**t1["model"], "width": 32}),
        "depth": dict(t1, model={**t1["model"], "depth": 5}),
        "opt_state": dict(t1, train={**t1["train"], "opt_state_on_edit": "reset"}),
        "penalty": dict(t1, growth={**t1["growth"], "replacement_pressure": 1e-2}),
        "cut_subset": dict(t1, growth={**t1["growth"], "cut_subset": "skip"}),
        "channels": dict(t1, growth={**t1["growth"], "channels": 4}),
    }
    for k, v in variants.items():
        assert condition_id(v) != condition_id(t1), k
    rep = dict(t1, seeds={**t1["seeds"], "optimizer": 7, "insertion": 3},
               data={**t1["data"], "data_seed": 5, "teacher_seed": 5}, parents={"baseline": "x"})
    assert condition_id(rep) == condition_id(t1)
    assert replication_key(rep) != replication_key(t1)


def test_F2_real_manifest_frequency_omegas_are_separate_contrasts():
    from cop.analysis.summarize import trajectory_table, paired_contrasts_report
    from cop.orchestration.manifest import Builder, wave1
    B = Builder("smoke")
    wave1(B)
    ents = list(B.entries.values())
    chosen = [e for e in ents if e["cfg"]["kind"] == "trajectory" and e["cfg"]["data"]["name"] == "frequency"
              and e["cfg"]["growth"]["topology"] == "layered"]
    by_n = {}
    for e in chosen:
        by_n.setdefault(e["cfg"]["data"]["n_train"], []).append(e)
    sel = next(v for v in by_n.values() if len({x["cfg"]["data"]["params"]["omega"] for x in v}) >= 2)
    sel = [next(x for x in sel if x["cfg"]["data"]["params"]["omega"] == w) for w in (1.0, 4.0)]
    ids = {e["run_id"] for e in sel} | {e["cfg"]["parents"]["continued"] for e in sel}
    runs = {rid: {"cfg": B.entries[rid]["cfg"], "status": {"status": "complete", "validity": "valid"}} for rid in ids}
    table = trajectory_table({rid: {**r, "status": {"status": "pending"}} for rid, r in runs.items()})
    for row in table:
        row["status"], row["validity"] = "complete", "valid"
        row["test_mse"] = 1.0 if row["topology"] == "layered" else 0.0
    rep = paired_contrasts_report(table, n_boot=20, runs=runs)
    assert len(rep["contrasts"]) == 2 and all(c["n_pairs"] == 1 for c in rep["contrasts"])
    assert not rep["errors"]["pairing_mismatch"] and not rep["errors"]["duplicate_replication"]


def test_F2_mismatched_continued_baseline_and_duplicates_are_reported():
    from cop.analysis.summarize import trajectory_table, paired_contrasts_report
    b, fc, t = T.traj({"topology": "layered"})
    fc_bad = resolve({**{k: v for k, v in fc.items() if k not in ("data",)},
                      "data": {**fc["data"], "n_train": 128}})
    t_bad = dict(t, parents={**t["parents"], "continued": run_id(fc_bad)})
    runs = {run_id(c): {"cfg": c, "status": {"status": "complete", "validity": "valid"}} for c in (fc, t, fc_bad, t_bad)}
    table = trajectory_table({k: {**v, "status": {"status": "pending"}} for k, v in runs.items()})
    for row in table:
        row["status"], row["validity"] = "complete", "valid"
        row["test_mse"] = 0.5
    rep = paired_contrasts_report(table, n_boot=10, runs=runs)
    assert len(rep["errors"]["pairing_mismatch"]) == 1 and rep["errors"]["pairing_mismatch"][0]["fields"] == ["data"]
    assert len(rep["contrasts"]) == 1
    # an invalid / unverified run is never pooled
    table[0]["validity"] = "unverified"
    rep2 = paired_contrasts_report(table, n_boot=10, runs=runs)
    assert rep2["errors"]["excluded_validity"]


def test_F2_full_manifests_have_no_same_seed_condition_collisions():
    """Re-run of the audit's manifest check with the NEW cell definition:
    two trajectories with the same condition id and replication key would be
    the same run; there must be none."""
    from cop.orchestration.manifest import generate
    B = generate([1, 2, 3, 5], "smoke")
    seen = {}
    for e in B.entries.values():
        if e["cfg"]["kind"] not in ("trajectory", "cop"):
            continue
        key = (condition_id(e["cfg"]), json.dumps(replication_key(e["cfg"]), sort_keys=True))
        assert key not in seen or seen[key] == e["run_id"], (seen.get(key), e["run_id"])
        seen[key] = e["run_id"]


# =============================================================================
# F3  matched CoP controls are built from the actual endpoint
# =============================================================================

@pytest.mark.parametrize("cop_kw", [
    {"cycles": 3, "n_pearls": 4, "cycle_pegs": "fixed"},                       # partial history (audit case)
    {"cycles": 5, "n_pearls": 3, "cycle_pegs": "fixed"},                       # revisits a replaced pearl
    {"cycles": 2, "n_pearls": 3, "cycle_pegs": "relearned"},                   # narrowed pegs
    {"cycles": 2, "n_pearls": 3, "cycle_pegs": "none"},                        # no pegs
    {"cycles": 3, "n_pearls": 3, "cycle_pegs": "fixed", "cycle_order": "center_out"},
    {"cycles": 3, "n_pearls": 3, "cycle_pegs": "fixed", "cycle_order": "leaf_inward"},
    {"cycles": 3, "n_pearls": 3, "cycle_pegs": "fixed", "cycle_order": "output_to_input"},
])
def test_F3_matched_controls_equal_parent_endpoint(tmp_path, cop_kw):
    cyc = T.cop({"task_kind": "cycles", **cop_kw})
    assert run_all(cyc, tmp_path) == ["complete", "complete"]
    par = read_json(rdir(tmp_path, cyc[-1]) / "cycles_result.json")
    for bl in ("direct_small", "distill"):
        ctl = T.cop({"task_kind": "baseline", "baseline": bl, **cop_kw}, parents={"cycles": run_id(cyc[-1])})
        assert run_all(ctl, tmp_path)[-1] == "complete", status_of(tmp_path, run_id(ctl[-1]))
        res = read_json(rdir(tmp_path, ctl[-1]) / "baseline_result.json")
        assert res["export"]["params"] == par["export"]["params"]
        assert res["export_structural_hash"] == par["export_structural_hash"]
        assert res["control"]["architecture_equal_to_parent_endpoint"]
        assert not res["control"].get("tensors_equal_to_parent_after_reinit")
        n = par["work_total"]["updates"] + (ctl[-1]["train"]["baseline_updates"] if bl == "direct_small" else 0)
        assert res["exposure_updates"] == n
        # review finding R6: quantisers re-fitted on the control's own training activations, K-1 times
        K = ctl[-1]["cop"]["cycles"]
        assert len(res["control"]["quantizer_recalibration_at_updates"]) == K - 1


def test_F3_sequence_route_skips_embedding_and_control_matches(tmp_path):
    data = {"name": "seq_select", "n_train": 128, "n_val": 64, "n_test": 64}
    model = {"family": "transformer", "depth": 4, "width": 16, "heads": 2}
    kw = {"cycles": 2, "n_pearls": 3, "cycle_pegs": "fixed"}
    cyc = T.cop({"task_kind": "cycles", **kw}, data=data, model=model)
    assert run_all(cyc, tmp_path)[-1] == "complete", status_of(tmp_path, run_id(cyc[-1]))
    par = read_json(rdir(tmp_path, cyc[-1]) / "cycles_result.json")
    assert 0 not in par["route"]
    ctl = T.cop({"task_kind": "baseline", "baseline": "direct_small", **kw}, data=data, model=model,
                parents={"cycles": run_id(cyc[-1])})
    assert run_all(ctl, tmp_path)[-1] == "complete"
    assert read_json(rdir(tmp_path, ctl[-1]) / "baseline_result.json")["export"]["params"] == par["export"]["params"]


def test_F3_direct_small_without_cycles_parent_is_rejected():
    with pytest.raises(ConfigError):
        T.cop({"task_kind": "baseline", "baseline": "direct_small"})


# =============================================================================
# F4 / F5  finite interfaces and table symbols
# =============================================================================

def _two_peg_graph(mode="uniform", bits=2, k=2):
    from cop.cop_pegs.pegs import insert_peg
    from cop.graph.export import export_compact
    g = build_mlp(4, [4, 4, 4, 4], 2, torch_gen(0, "init"))
    for i in (0, 2):
        iid = insert_peg(g, E.cut_at(g, "post_act", i), torch_gen(i, "init"), k=k, mode=mode, bits=bits,
                         codebook_size=8)
        g.gate_vals[g.implants[iid].meta["peg"]["alpha"]] = 0.0
    return export_compact(g, fold_linear=False)[0]


@pytest.mark.parametrize("mode", ["uniform", "vq"])
def test_F4_replacement_outputs_keep_the_finite_alphabet(mode):
    from cop.cop_pegs.alternatives import Assembly, code_nodes, quantizer_of
    g = _two_peg_graph(mode)
    codes = code_nodes(g)
    m = torch.nn.Linear(2, 2)
    with torch.no_grad():
        m.weight.zero_()
        m.bias.fill_(0.123)
    a = Assembly(g, codes, [1], {1: m})                     # default contract: enforced
    _, cs = a({"x": torch.randn(16, 4)}, return_codes=True)
    q = quantizer_of(g, codes[1])
    assert q.offalphabet_distance(cs[1]) < 1e-3
    relaxed = Assembly(g, codes, [1], {1: m}, enforce=False)
    _, cs2 = relaxed({"x": torch.randn(16, 4)}, return_codes=True)
    assert q.offalphabet_distance(cs2[1]) > 1e-2           # the separately named relaxed condition
    # straight-through: gradients reach the replacement through the quantiser
    x = torch.randn(32, 4)
    m2 = torch.nn.Linear(2, 2)
    y = Assembly(g, codes, [1], {1: m2})(x).sum()
    y.backward()
    assert m2.weight.grad is not None


def test_F4_image_codes_are_quantised_per_channel():
    """New defect found while fixing F4: image codes (B, k, H, W) were
    quantised along the WIDTH axis; per-channel ranges must apply."""
    from cop.graph.ops import Quantizer, FORWARD
    q = Quantizer(3, "uniform", bits=2)
    q.lo.copy_(torch.tensor([0.0, -10.0, 5.0]))
    q.hi.copy_(torch.tensor([1.0, 10.0, 6.0]))
    z = torch.stack([torch.full((2, 5), 0.4), torch.full((2, 5), 9.0), torch.full((2, 5), 5.6)])[None]  # (1,3,2,5)
    node = SimpleNamespace(attrs={"layout": "img"}, id="n")
    out = FORWARD["quant"](node, [z], q, SimpleNamespace(layout="img"), None)
    ref = q(z.movedim(1, -1)).movedim(-1, 1)
    assert torch.equal(out, ref)
    assert torch.allclose(out[0, 1], torch.full((2, 5), 10.0)) and torch.allclose(out[0, 0], torch.full((2, 5), 1 / 3))


@pytest.mark.parametrize("mode,k,bits,cs,nm", [("uniform", 2, 2, 0, 1), ("uniform", 3, 1, 0, 1),
                                               ("vq", 2, 0, 8, 1), ("multi", 4, 0, 4, 2)])
def test_F5_table_rows_are_one_to_one_with_messages(mode, k, bits, cs, nm):
    from cop.graph.ops import Quantizer, TableModule
    import itertools
    q = Quantizer(k, mode, bits=bits or 8, codebook_size=cs or 16, n_messages=nm)
    if mode == "uniform":
        q.lo.copy_(torch.linspace(-5, -3, k))
        q.hi.copy_(torch.linspace(5, 9, k))
        L = 2 ** bits
        grid = [torch.linspace(float(q.lo[j]), float(q.hi[j]), L) for j in range(k)]
        msgs = torch.tensor(list(itertools.product(*[g.tolist() for g in grid])))
    else:
        q.calibrate(torch.randn(500, k), gen=torch.Generator().manual_seed(0))
        if mode == "vq":
            msgs = q.codebook.detach().clone()
        else:
            parts = [q.codebook[m].detach() for m in range(nm)]
            msgs = torch.stack([torch.cat(c) for c in itertools.product(*[list(p) for p in parts])])
    msgs = q(msgs)                                 # exact representable messages
    t = TableModule.from_quantizer(q, 3)
    rows = t.index(msgs)
    assert len(set(rows.tolist())) == len(msgs) == t.n_rows
    t2 = TableModule(t.k, t.levels, 3, t.mode, t.n_messages)
    with pytest.raises(RuntimeError):
        t2.index(msgs)                             # no silent [-1, 1] default
    t2.load_state_dict(t.state_dict())
    assert torch.equal(t2.index(msgs), rows)       # the symbol map is part of the saved module


# =============================================================================
# F6  random cut selection is uniform
# =============================================================================

@pytest.mark.parametrize("cands", [4, 2])
def test_F6_random_policy_is_uniform_over_cutpoints(cands):
    from cop.experiments.trajectory import Trajectory
    t = Trajectory.__new__(Trajectory)
    t.g = dict(GROWTH_DEFAULTS, policy="random", policy_candidates=cands)
    g = build_mlp(4, [4, 4, 4, 4], 2, torch_gen(0, "init"))
    picks = Counter()
    for seed in range(800):
        t.cfg = {"seeds": {"policy": seed}}
        info = t.choose_cut(g, 1)
        assert info["chosen"] in info["candidates"] and len(info["candidates"]) == cands
        picks[info["chosen"]] += 1
    assert set(picks) == {0, 1, 2, 3}
    assert min(picks.values()) > 800 / 4 * 0.75 and max(picks.values()) < 800 / 4 * 1.25


# =============================================================================
# F7  linear inverse restoration objective
# =============================================================================

def test_F7_linear_inverse_penalty_zero_at_exact_pair_and_descends():
    from cop.experiments.dissipation import inverse_pairs, inverse_restore_penalty
    for seed in range(4):
        g = build_mlp(6, [6, 6, 6], 2, torch_gen(seed, "init"))
        G, Ti, Tinv = E.insert_inverse_pair(g, E.cut_at(g, "post_act", 1), torch_gen(seed + 9, "insertion"),
                                            kind="linear", tie="untied")
        pr = inverse_pairs(g, [G])
        assert pr[0]["kind"] == "linear" and not pr[0]["exact_by_construction"]
        A, B = g.mods[pr[0]["W"][0]], g.mods[pr[0]["Winv"][0]]
        with torch.no_grad():
            A.bias.normal_()
            B.bias.copy_(-(B.weight @ A.bias))     # exact affine inverse incl. bias
        loss = inverse_restore_penalty(g, pr)
        assert float(loss) < 1e-9
        loss.backward()
        assert max(float(A.weight.grad.abs().max()), float(B.weight.grad.abs().max())) < 1e-6
        with torch.no_grad():
            A.weight.add_(0.1 * torch.randn_like(A.weight))
        for p in (A.weight, A.bias, B.weight, B.bias):
            p.grad = None
        l0 = inverse_restore_penalty(g, pr)
        l0.backward()
        with torch.no_grad():
            for p in (A.weight, A.bias, B.weight, B.bias):
                p.sub_(1e-3 * p.grad)
        assert float(inverse_restore_penalty(g, pr)) < float(l0)
    g = build_mlp(6, [6, 6, 6], 2, torch_gen(0, "init"))
    G, _, _ = E.insert_inverse_pair(g, E.cut_at(g, "post_act", 1), torch_gen(1, "insertion"), kind="linear",
                                    tie="enforced")
    pr = inverse_pairs(g, [G])
    assert pr[0]["exact_by_construction"] and float(inverse_restore_penalty(g, pr)) == 0.0


# =============================================================================
# F8  validity gates
# =============================================================================

def test_F8_failed_exact_insertion_quarantines_the_run(tmp_path, monkeypatch):
    from cop.experiments.growth import Grower
    cfgs = T.traj({"topology": "layered"})
    run_all(cfgs[:-1], tmp_path)
    orig = Grower.round

    def corrupt(self, g, r, R):
        ids = orig(self, g, r, R)
        with torch.no_grad():
            g.mods[g.nodes[g.output].pkey].bias.add_(1.0)
        return ids
    monkeypatch.setattr(Grower, "round", corrupt)
    assert run_job(cfgs[-1], tmp_path, EX) == "invalid"
    d = rdir(tmp_path, cfgs[-1])
    assert not (d / "ckpt" / "final.pt").exists() and (d / "invalid.json").exists()
    assert read_json(d / "invalid.json")["diagnostics"]["stage"] == "insert_r1"
    monkeypatch.setattr(Grower, "round", orig)
    child = T.child("repair", cfgs[-1], {"repair": {"region": "full"}})
    from cop.orchestration.runner import run_manifest
    m = tmp_path / "m.jsonl"
    m.write_text("\n".join(json.dumps({"run_id": run_id(c), "cfg": c, "deps": [run_id(cfgs[-1])] if c is child else [],
                                       "blocks": ["t"]}) for c in [cfgs[-1], child]))
    run_manifest(m, tmp_path, EX, log=lambda *a: None)
    assert status_of(tmp_path, run_id(child))["status"] == "skipped_with_reason"


def test_F8_declared_approximate_insertion_is_labelled_not_failed(tmp_path):
    cfgs = T.traj({"topology": "cancel_pair", "symmetry_noise": 1e-2})
    assert run_all(cfgs, tmp_path)[-1] == "complete"
    labels = [r["metric_value"] for r in read_jsonl(rdir(tmp_path, cfgs[-1]) / "metrics.jsonl")
              if r["metric_name"] == "insertion_label"]
    assert labels and set(labels) <= {"L0_approximate", "exact"} and "L0_approximate" in labels


def test_F8_route_growth_next_to_trained_experts_is_exact(tmp_path):
    """Found by the new gate: a zero expert next to TRAINED experts changes the
    output through the router softmax.  v2 splits an expert exactly."""
    cfgs = T.traj({"topology": "parallel", "merge": "route", "rounds": 3})
    assert run_all(cfgs, tmp_path)[-1] == "complete", status_of(tmp_path, run_id(cfgs[-1]))
    labels = [r["metric_value"] for r in read_jsonl(rdir(tmp_path, cfgs[-1]) / "metrics.jsonl")
              if r["metric_name"] == "insertion_label"]
    assert labels == ["exact"] * 3


def test_F8_failed_control_fails_job_and_cli_exit_code(tmp_path, monkeypatch):
    import cop.experiments.control as CT
    cfg = resolve({"kind": "control", "data": T.DATA, "model": T.MODEL, "control": {"device": "cpu",
                                                                                   "checks": ["stationary"]}})
    real = CT.stationary_checks
    monkeypatch.setattr(CT, "stationary_checks", lambda *a, **k: [{"check": "stationary", "pass": False}])
    assert run_job(cfg, tmp_path, EX) == "invalid"
    monkeypatch.setattr(CT, "stationary_checks", real)
    m = tmp_path / "m.jsonl"
    m.write_text(json.dumps({"run_id": run_id(cfg), "cfg": cfg, "deps": [], "blocks": ["W0"]}) + "\n")
    r = subprocess.run([sys.executable, "-m", "cop.cli", "gate", "--manifest", str(m), "--results", str(tmp_path)],
                       cwd=ROOT, capture_output=True, text=True)
    assert r.returncode == 1


# =============================================================================
# F9 / F10  local optimizer policy; saved replacement models
# =============================================================================

def test_F9_local_loops_use_the_configured_optimizer(tmp_path, monkeypatch):
    made = []
    real_sgd, real_adamw = torch.optim.SGD, torch.optim.AdamW

    def sgd(*a, **k):
        o = real_sgd(*a, **k)
        made.append(("SGD", o.defaults["momentum"], o.defaults["weight_decay"]))
        return o

    def adamw(*a, **k):
        o = real_adamw(*a, **k)
        made.append(("AdamW", None, o.defaults["weight_decay"]))
        return o
    monkeypatch.setattr(torch.optim, "SGD", sgd)
    monkeypatch.setattr(torch.optim, "AdamW", adamw)
    tr = {**T.TRAIN, "optimizer": "sgd", "momentum": 0.9, "weight_decay": 0.0, "lr": 0.01}
    for task in ({"task_kind": "alternatives", "alt_kinds": ["linear", "sparse"]}, {"task_kind": "split"},
                 {"task_kind": "cycles", "cycles": 2, "n_pearls": 3},
                 {"task_kind": "baseline", "baseline": "replace_no_expand"},
                 {"task_kind": "baseline", "baseline": "shared_fold"}):
        made.clear()
        cfgs = T.cop(task, train=tr)
        assert run_all(cfgs, tmp_path)[-1] == "complete", (task, status_of(tmp_path, run_id(cfgs[-1])))
        assert made and all(m == ("SGD", 0.9, 0.0) for m in made), (task, made)
        d = rdir(tmp_path, cfgs[-1])
        res = next(read_json(p) for p in d.glob("*_result.json"))
        assert res["local_train_policy"]["optimizer"] == "sgd"


def test_F10_p3_p4_artifacts_reload_in_a_fresh_process(tmp_path):
    jobs = [T.cop({"task_kind": "alternatives", "alt_training": "independent", "code_kind": "aligned",
                   "alt_kinds": ["mlp_small", "linear", "sparse"]}),
            T.cop({"task_kind": "alternatives", "alt_kinds": ["mlp_small", "table"]},
                  peg={"mode": "uniform", "bits": 2, "dim": 2}),
            T.cop({"task_kind": "split", "split_into": 2}, peg={"mode": "uniform", "bits": 3})]
    for cfgs in jobs:
        assert run_all(cfgs, tmp_path)[-1] == "complete"
        d = rdir(tmp_path, cfgs[-1])
        r = subprocess.run([sys.executable, "-m", "cop.cli", "verify-reload", "--run-dir", str(d)],
                           cwd=ROOT, capture_output=True, text=True)      # a fresh interpreter process
        assert r.returncode == 0, r.stdout + r.stderr
        out = json.loads(r.stdout)
        assert out["ok"] and out["all_bitwise_equal"] and out["reference_matches"]


def test_F10_usage_counts_cover_the_whole_run(tmp_path):
    cfgs = T.cop({"task_kind": "alternatives", "alt_training": "joint", "code_kind": "task_only",
                  "alt_kinds": ["mlp_small", "linear"], "global_updates": 40})
    assert run_all(cfgs, tmp_path)[-1] == "complete"
    res = read_json(rdir(tmp_path, cfgs[-1]) / "alternatives_result.json")
    assert sum(res["audit"]["training_assembly_usage"].values()) == 40
    assert not set(res["audit"]["training_assembly_usage"]) & {"|".join(a) for a in
                                                               read_json(rdir(tmp_path, cfgs[-1]) /
                                                                         "assemblies.json")["heldout"]}


# =============================================================================
# F11  job-level resume (interrupted == uninterrupted)
# =============================================================================

def _resume_cases():
    from resume_harness import compare_interrupted  # noqa: F401
    TR = {**T.TRAIN, "checkpoint_every": 7}
    p = T.traj({"topology": "recursive_branch"}, train=TR)
    cy = T.cop({"task_kind": "cycles", "cycle_pegs": "relearned", "cycles": 3, "n_pearls": 3}, train=TR)
    return {
        "baseline": [T.base(train=TR)],
        "trajectory": p,
        "trajectory_mutation": T.traj({"topology": "layered", "driver": "neutral_mutation", "driver_strength": 1e-3},
                                      train=TR),
        "trajectory_from_scratch": T.traj({"topology": "tree_depth2", "schedule": "from_scratch"}, train=TR),
        "repair": p + [T.child("repair", p[-1], {"repair": {"region": "incident_adapters", "budget_multiplier": 0.3,
                                                            "eval_points": 2}})],
        "dissipation_linear": p + [T.child("dissipation", p[-1], {"dissipation": {
            "method": "linear", "speed_updates": 10, "post_updates": 10, "path_eval_points": 4}})],
        "dissipation_peg_replacement": p + [T.child("dissipation", p[-1], {"dissipation": {
            "method": "peg_replacement", "speed_updates": 10, "post_updates": 10}})],
        "cop_chain": T.cop({"task_kind": "chain", "n_pearls": 3}, train=TR),
        "cop_alternatives_joint": T.cop({"task_kind": "alternatives", "alt_training": "joint", "code_kind": "learned",
                                         "alt_kinds": ["mlp_small", "linear"]}, train=TR),
        "cop_alternatives_local": T.cop({"task_kind": "alternatives", "alt_kinds": ["mlp_small", "sparse"]}, train=TR),
        "cop_split": T.cop({"task_kind": "split", "split_into": 2}, train=TR),
        "cop_cycles": cy,
        "cop_matched_direct_small": cy + [T.cop({"task_kind": "baseline", "baseline": "direct_small",
                                                 "cycle_pegs": "relearned", "cycles": 3, "n_pearls": 3}, train=TR,
                                                parents={"cycles": run_id(cy[-1])})[-1]],
    }


@pytest.mark.parametrize("name", list(_resume_cases()))
def test_F11_interrupted_job_equals_uninterrupted(tmp_path, name):
    from resume_harness import compare_interrupted
    r = compare_interrupted(_resume_cases()[name], tmp_path)
    assert len(r["interrupted_at_polls"]) >= 1 and r["attempts"][-1] == "complete", r
    assert r["equal"], r


def _late_resume_cases():
    TR = {**T.TRAIN, "checkpoint_every": 7}
    return {
        # review finding R3: interrupted inside the peg-edit training, after the chain's 'final' checkpoint
        "cop_chain_peg_edit": T.cop({"task_kind": "chain", "n_pearls": 3, "peg_edit": "split"}, train=TR),
        # review finding R9: known-module pretraining in round 1, interrupted in round 2
        "trajectory_known_pretrained": T.traj({"topology": "known_module", "known_module": "pretrained",
                                               "pretrain_updates": 20}, train=TR),
    }


@pytest.mark.parametrize("name", list(_late_resume_cases()))
def test_F11_late_interruption_keeps_work_and_counters(tmp_path, name):
    from resume_harness import compare_interrupted
    cfgs = _late_resume_cases()[name]
    r = compare_interrupted(cfgs, tmp_path, fractions=(0.9,))
    assert len(r["interrupted_at_polls"]) >= 1 and r["attempts"][-1] == "complete", r
    assert r["equal"], r
    s = read_json(rdir(tmp_path / "B", cfgs[-1]) / "summary.json")
    phases = set(s["work"])
    want = {"chain_train:cop", "chain_train:cop_edit"} if name.startswith("cop") else {"known_pretrain",
                                                                                      "growth_train"}
    assert want <= phases, phases


# =============================================================================
# F12  repair extension and counters; F15 tolerance units
# =============================================================================

def _hand_made_parent(root, inverse=False):
    """The audit's hand-made parent (insertion without growth training), but
    with a provenance record so the v2 parent checks accept it."""
    from cop.experiments.context import RunContext
    from cop.experiments import common as C
    cfg = resolve({"kind": "trajectory", "data": T.DATA, "model": {"family": "mlp", "widths": [4, 4, 4, 4]},
                   "train": {"baseline_updates": 0, "batch_size": 8, "checkpoint_every": 1},
                   "growth": {"topology": "inverse_pair" if inverse else "layered", "rounds": 1,
                              "updates_per_round": 3, "evaluate_deletions": False, "crossover": False,
                              "probes": False}})
    p = RunContext(cfg, root, {"device": "cpu"}, "test", "test-code", "test-env")
    b = C.setup_data(p)
    f0 = C.new_model(cfg, b, "cpu")
    ft = f0.clone(share_params=False)
    cut = E.cut_at(ft, "post_act", 1)
    if inverse:
        E.insert_inverse_pair(ft, cut, torch_gen(4, "init"), kind="linear", tie="untied")
    else:
        E.insert_residual_zero(ft, cut, torch_gen(4, "init"), width=4)
    p.save_ckpt("baseline_ref", f0)
    p.save_ckpt("final", ft)
    atomic_write_json(p.dir / "status.json", {"status": "complete"})
    atomic_write_json(p.dir / "provenance.json", {"semantic_hash": semantic_code_hash()})
    return cfg


def test_F12_zero_step_success_does_not_extend_and_counters_are_reported(tmp_path):
    pcfg = _hand_made_parent(tmp_path)
    cfg = resolve({"kind": "repair", "data": pcfg["data"], "model": pcfg["model"], "train": pcfg["train"],
                   "growth": pcfg["growth"], "parents": {"trajectory": run_id(pcfg)},
                   "repair": {"deletion": "all", "extend_if_inconclusive": True, "eval_points": 3}})
    assert run_job(cfg, tmp_path, EX) == "complete"
    res = read_json(rdir(tmp_path, cfg) / "repair_result.json")
    assert 0 in res["reach"]["task"].values()
    assert res["extended"] is False and res["updates_done"] == res["budget"] == 3
    rows = [r for r in read_jsonl(rdir(tmp_path, cfg) / "metrics.jsonl") if r["stage"] == "repair@3"]
    assert rows and all(r["training_updates"] == 3 and r["examples_seen"] == 24 for r in rows)


def test_F12_repair_resume_continues_the_update_sequence(tmp_path):
    from resume_harness import compare_interrupted
    p = T.traj({"topology": "layered"}, train={**T.TRAIN, "checkpoint_every": 3})
    cfgs = p + [T.child("repair", p[-1], {"repair": {"region": "full", "budget_multiplier": 1.0, "eval_points": 3}})]
    r = compare_interrupted(cfgs, tmp_path, fractions=(0.2, 0.5, 0.8))
    assert r["equal"] and len(r["interrupted_at_polls"]) == 3, r


def test_F7_inverse_restore_job_on_exact_parent_starts_at_zero_penalty(tmp_path):
    from cop.experiments.dissipation import inverse_pairs, inverse_restore_penalty
    pcfg = _hand_made_parent(tmp_path, inverse=True)
    ck = torch.load(Path(tmp_path) / "runs" / run_id(pcfg) / "ckpt" / "final.pt", weights_only=False)
    g = GraphNet.from_checkpoint(ck["model"])
    G = next(k for k, v in g.implants.items() if v.construction == "inverse_pair")
    assert float(inverse_restore_penalty(g, inverse_pairs(g, [G]))) < 1e-9
    cfg = resolve({"kind": "dissipation", "data": pcfg["data"], "model": pcfg["model"], "train": pcfg["train"],
                   "growth": pcfg["growth"], "parents": {"trajectory": run_id(pcfg)},
                   "dissipation": {"method": "inverse_restore", "speed_updates": 4, "post_updates": 4}})
    assert run_job(cfg, tmp_path, EX) == "complete", status_of(tmp_path, run_id(cfg))


def test_F12_extension_rule_and_counters(tmp_path):
    from cop.experiments.repair import extension_needed
    crit = {"nmse": [1e-4, 1e-2], "acc_drop_pp": [0.5, 1.0], "js": [1e-3, 1e-2]}
    rc = {"extend_if_inconclusive": True, "target": "task", "extend_on": "target"}
    reach = {"task": {"0.0001": None, "0.01": 0}, "expanded": {"0.0001": None, "0.01": None},
             "original": {"0.0001": None, "0.01": None}}
    assert extension_needed(reach, crit, "regression", rc) is False          # hit at update 0 counts
    assert extension_needed(reach, crit, "regression", {**rc, "target": "expanded"}) is True
    assert extension_needed(reach, crit, "regression", {**rc, "extend_on": "both", "target": "expanded"}) is True
    p = T.traj({"topology": "layered"})
    run_all(p, tmp_path)
    rp = T.child("repair", p[-1], {"repair": {"region": "full", "budget_multiplier": 0.5, "eval_points": 2}})
    assert run_job(rp, tmp_path, EX) == "complete"
    rows = [r for r in read_jsonl(rdir(tmp_path, rp) / "metrics.jsonl") if r["stage"].startswith("repair@")]
    last = max(rows, key=lambda r: int(r["stage"].split("@")[1]))
    assert last["training_updates"] == int(last["stage"].split("@")[1]) and last["examples_seen"] > 0


def test_F15_regression_tolerances_are_scale_invariant():
    from cop.experiments.repair import reach_table
    from cop.experiments.deletion import _preserves
    crit = {"nmse": [0.05], "acc_drop_pp": [1.0], "js": [0.01]}
    outs = []
    for scale in (1.0, 10.0):
        curve = [{"update": 1, "val.nmse_increase_vs_ft": 0.01, "val.mse_increase_vs_ft": 0.01 * scale ** 2,
                  "val.dist_expanded": 0.01, "val.dist_original": 0.01}]
        outs.append(reach_table(curve, crit, "regression")["task"])
        assert _preserves("regression", {"mse": 1.0 * scale ** 2}, {"mse": 1.01 * scale ** 2}, None, "task", 0.05,
                          target_scale=scale)
    assert outs[0] == outs[1] == {"0.05": 1}


# =============================================================================
# F13  checkpoint dtypes
# =============================================================================

def test_F13_fp64_checkpoint_round_trip_preserves_dtype_and_values():
    from cop.cop_pegs.pegs import insert_peg
    g = build_mlp(4, [4, 4, 4, 4], 2, torch_gen(0, "init")).double()
    insert_peg(g, E.cut_at(g, "post_act", 1), torch_gen(1, "init"), k=2, mode="uniform", bits=2)
    with torch.no_grad():
        next(g.parameters()).view(-1)[0] = 1.0000000001
    h = GraphNet.from_checkpoint(g.checkpoint())
    for (n1, a), (n2, b) in zip(g.state_dict().items(), h.state_dict().items()):
        assert n1 == n2 and a.dtype == b.dtype and torch.equal(a, b), n1
    q = next(m for m in h.mods.values() if type(m).__name__ == "Quantizer")
    assert q.calibrated.dtype == torch.bool
    y = h({"x": torch.ones(2, 4, dtype=torch.float64)})
    assert y.dtype == torch.float64


def test_F13_fp64_trajectory_resume(tmp_path):
    from resume_harness import compare_interrupted
    tr = {**T.TRAIN, "precision": "fp64", "checkpoint_every": 5}
    r = compare_interrupted(T.traj({"topology": "layered"}, train=tr), tmp_path)
    assert r["equal"], r


# =============================================================================
# F14  clean labels never steer ordinary training
# =============================================================================

def test_F14_specialization_uses_observed_labels():
    from cop.experiments.trajectory import spec_masks
    b = SimpleNamespace(groups=None, y=torch.tensor([0, 0, 3, 3]), y_clean=torch.tensor([0, 1, 2, 3]),
                        X={"x": torch.zeros(4, 2)})
    fn = spec_masks(SimpleNamespace(task="classification", out_dim=4))
    m1 = fn(b)["grad_masks"]["spec_a"].tolist()
    b.y_clean = 3 - b.y_clean
    assert fn(b)["grad_masks"]["spec_a"].tolist() == m1 == [1.0, 1.0, 0.0, 0.0]
    oracle = spec_masks(SimpleNamespace(task="classification", out_dim=4), oracle_clean=True)
    assert oracle(b)["grad_masks"]["spec_a"].tolist() != m1


# =============================================================================
# F16  instance hash binds weights to positions
# =============================================================================

def test_F16_instance_hash_binds_parameters_to_nodes():
    g = build_mlp(2, [2], 2, torch_gen(0, "init"), act="identity")
    lin = [n for n in g.nodes.values() if n.op == "linear"]
    with torch.no_grad():
        a, b = [g.mods[n.pkey] for n in lin]
        a.weight.copy_(torch.tensor([[1., 2.], [0., 1.]]))
        a.bias.zero_()
        b.weight.copy_(torch.tensor([[2., 0.], [1., 1.]]))
        b.bias.zero_()
    h = g.clone(share_params=True)
    x, y = [h.nodes[n.id] for n in lin]
    x.pkey, y.pkey = y.pkey, x.pkey
    assert not torch.equal(g({"x": torch.ones(1, 2)}), h({"x": torch.ones(1, 2)}))
    assert g.instance_hash() != h.instance_hash()
    # shared vs independent equal copies: same computation -> same hash; changed weights -> different
    k = g.clone(share_params=False)
    assert k.instance_hash() == g.instance_hash()
    with torch.no_grad():
        k.mods[lin[0].pkey].weight.add_(1e-3)
    assert k.instance_hash() != g.instance_hash()
    # gate values and fold results are bound too
    g2 = build_mlp(4, [8, 8], 2, torch_gen(1, "init"))
    iid = E.insert_linear_factor(g2, E.cut_at(g2, "post_act", 0), torch_gen(2, "init"), width=10)
    f1 = E.fold_implant(g2, iid)
    with torch.no_grad():
        next(iter(g2.mods[g2.nodes[g2.implants[iid].nodes[0]].pkey].parameters())).add_(0.5)
    f2 = E.fold_implant(g2, iid)
    assert f1.structural_hash() == f2.structural_hash() and f1.instance_hash() != f2.instance_hash()


def test_F16_cancel_pair_dedupe_still_merges_identical_graphs():
    """Deleting {u, v} and deleting the whole group give the same computation."""
    g = build_mlp(8, [16, 16], 3, torch_gen(0, "init"))
    G, u, v = E.insert_cancel_pair(g, E.cut_at(g, "post_act", 0), torch_gen(1, "insertion"), width=6)
    assert E.delete(g, [u, v]).instance_hash() == E.delete(g, [G]).instance_hash()
    assert E.delete(g, [u]).instance_hash() != E.delete(g, [v]).instance_hash()


# =============================================================================
# F17  provenance before reuse
# =============================================================================

def test_F17_stale_runs_and_parents_are_not_reused(tmp_path):
    cfgs = T.traj({"topology": "layered"})
    assert run_all(cfgs, tmp_path) == ["complete"] * 3
    d = rdir(tmp_path, cfgs[0])
    prov = read_json(d / "provenance.json")
    atomic_write_json(d / "provenance.json", {**prov, "semantic_hash": "0000000000000000"})
    sem = semantic_code_hash()
    assert effective_status(tmp_path, run_id(cfgs[0]), sem) == "stale"
    assert run_job(cfgs[0], tmp_path, EX) == "stale"
    child = T.child("repair", cfgs[-1], {"repair": {"region": "full", "budget_multiplier": 0.2}})
    d_traj = rdir(tmp_path, cfgs[-1])
    pt = read_json(d_traj / "provenance.json")
    atomic_write_json(d_traj / "provenance.json", {**pt, "semantic_hash": "1111111111111111"})
    assert run_job(child, tmp_path, EX) == "failed"
    assert "stale parent" in status_of(tmp_path, run_id(child))["reason"]
    r = subprocess.run([sys.executable, "-m", "cop.cli", "accept-stale", "--run-id", run_id(cfgs[-1]), "--reason",
                        "test: only analysis code changed", "--results", str(tmp_path)], cwd=ROOT,
                       capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    assert effective_status(tmp_path, run_id(cfgs[-1]), sem) == "complete"
    INTERRUPT["flag"] = False
    assert run_job(child, tmp_path, EX) == "complete"
    # --rerun-stale archives and recomputes
    assert run_job(cfgs[0], tmp_path, EX, rerun_stale=True) == "complete"
    assert any((tmp_path / "runs_archive").glob(run_id(cfgs[0]) + "__stale_*"))


def test_F17_analysis_never_pools_stale_runs(tmp_path):
    """Review finding R4: the analysis uses the effective status (semantic hash)."""
    from cop.analysis.summarize import load_runs, trajectory_table, paired_contrasts_report, summarize
    cfgs = T.traj({"topology": "layered"})
    assert run_all(cfgs, tmp_path) == ["complete"] * 3
    runs = load_runs(tmp_path)
    assert len(paired_contrasts_report(trajectory_table(runs), runs=runs)["contrasts"]) == 1
    for c in cfgs:
        d = rdir(tmp_path, c)
        atomic_write_json(d / "provenance.json", {**read_json(d / "provenance.json"), "semantic_hash": "OLD"})
    runs = load_runs(tmp_path)
    tab = trajectory_table(runs)
    assert {r["status"] for r in tab} == {"stale"}
    rep = paired_contrasts_report(tab, runs=runs)
    assert rep["contrasts"] == [] and rep["errors"]["excluded_stale"]
    s = summarize(str(tmp_path), [], str(tmp_path / "summary"))
    q = read_json(tmp_path / "summary" / "validity_quarantine.json")
    assert {x["run_id"] for x in q} >= {run_id(c) for c in cfgs}
    assert s["n_paired_contrasts"] == 0


def test_F17_unverified_parent_makes_children_unverified(tmp_path):
    """Review finding R10: validity propagates down the lineage."""
    cfgs = T.traj({"topology": "layered"})
    assert run_all(cfgs, tmp_path) == ["complete"] * 3
    d = rdir(tmp_path, cfgs[-1])
    st = read_json(d / "status.json")
    atomic_write_json(d / "status.json", {**st, "validity": "unverified", "validity_reasons": ["test"]})
    child = T.child("repair", cfgs[-1], {"repair": {"region": "full", "budget_multiplier": 0.2}})
    assert run_job(child, tmp_path, EX) == "complete"
    cs = status_of(tmp_path, run_id(child))
    assert cs["validity"] == "unverified" and any("is unverified" in r for r in cs["validity_reasons"])


def test_F17_condition_id_ignores_io_settings_only():
    a = T.base()
    b = T.base(train={**T.TRAIN, "checkpoint_every": 3})
    c = T.base(train={**T.TRAIN, "eval_every": 3})
    assert run_id(a) != run_id(b) and condition_id(a) == condition_id(b)
    assert condition_id(a) != condition_id(c)


def test_F17_provenance_records_numerics(tmp_path):
    cfg = T.base()
    assert run_job(cfg, tmp_path, EX) == "complete"
    num = read_json(rdir(tmp_path, cfg) / "provenance.json")["numerics"]
    assert num["allow_tf32"] is False and num["deterministic"] is True and num["device"] == "cpu"


def test_F4_interface_gradient_is_unclipped_and_value_exact():
    """Review finding R7: a saturated output still receives gradient; the value is
    exactly the quantiser's code."""
    from cop.graph.ops import Quantizer
    from cop.cop_pegs.alternatives import Interface
    q = Quantizer(2, "uniform", bits=2)
    q.calibrate(torch.tensor([[-1.0, -1.0], [1.0, 1.0]]))
    itf = Interface(q)
    z = torch.tensor([[3.0, 0.2]], requires_grad=True)
    y = itf(z)
    assert torch.equal(y.detach(), q(z.detach()))
    ((y - torch.tensor([[-0.5, 0.2]])) ** 2).sum().backward()
    assert z.grad[0, 0] > 0          # pushes the saturated coordinate down towards the range
    big = torch.tensor([[1e8, -1e8]])
    assert torch.equal(itf(big), q(big))


def test_F10_alternatives_refuse_pearls_with_late_inputs(tmp_path):
    """Review finding R8: code-only alternatives are never compared against a
    pearl that also reads a late input.  The MLP builder places every peg before
    the query, so real P3/P4 references pass; a span that contains the query
    concatenation is refused."""
    from cop.cop_pegs.alternatives import require_code_only_pearls, code_nodes
    from cop.experiments.context import Unsupported
    data = {"name": "delayed_query", "n_train": 256, "n_val": 128, "n_test": 128,
            "params": {"n_bits": 8, "pool_size": 2048}}
    model = {"family": "mlp", "width": 16, "depth": 6, "query_at_layer": 3}
    cfgs = T.cop({"task_kind": "alternatives", "n_pearls": 4, "alt_kinds": ["mlp_small"]}, data=data, model=model)
    assert run_all(cfgs, tmp_path) == ["complete", "complete"]
    ck = torch.load(rdir(tmp_path, cfgs[-1]) / "ckpt" / "reference_exported.pt", weights_only=False)
    ref = GraphNet.from_checkpoint(ck["model"], "cpu")
    codes = code_nodes(ref)
    require_code_only_pearls(ref, codes)
    with pytest.raises(Unsupported, match="late inputs"):
        require_code_only_pearls(ref, codes + [ref.output])


def test_F17_cop_rejects_non_fp32():
    with pytest.raises(ConfigError):
        T.cop({"task_kind": "chain"}, train={**T.TRAIN, "precision": "fp64"})


# =============================================================================
# F18  statistics definitions
# =============================================================================

def test_F18_sequence_accuracy_interval_is_clustered_by_sequence():
    from cop.train import metrics as M
    torch.manual_seed(0)
    y = torch.randint(0, 3, (50, 20))
    # all-or-nothing sequences: tokens within a sequence are perfectly dependent
    ok = torch.rand(50) < 0.5
    out = torch.full((50, 20, 3), -5.0)
    out.scatter_(2, torch.where(ok[:, None], y, (y + 1) % 3)[..., None], 5.0)
    m = M.task_metrics(out, y, "seq_classification")
    lo, hi = m["acc_ci95_cluster"]
    naive = M.wilson(int(m["acc"] * 1000), 1000)
    assert (hi - lo) > 2.5 * (naive[1] - naive[0])          # far wider than the token-iid interval


def test_F18_paired_delta_uses_correctness_differences():
    from cop.train import metrics as M
    y = torch.tensor([0, 1, 2, 0])
    ref = torch.nn.functional.one_hot(torch.tensor([1, 2, 0, 1]), 3).float()        # all wrong
    out = torch.nn.functional.one_hot(torch.tensor([2, 0, 1, 2]), 3).float()        # all wrong, all different
    d = M.paired_delta(out, ref, y, "classification")
    assert d["correct"]["mean"] == 0.0 and d["correct"]["se"] == 0.0               # disagreement is not a delta


def test_F18_calibration_does_not_time_cache_hits(tmp_path):
    from cop.orchestration.calibrate import _time_job
    cfg = T.base()
    e = {"run_id": run_id(cfg), "cfg": cfg}
    r1 = _time_job(e, tmp_path, EX)
    r2 = _time_job(e, tmp_path, EX)
    assert r1["timing_source"].startswith("wall clock") and r2["timing_source"].startswith("stored")
    assert r2["seconds"] == read_json(rdir(tmp_path, cfg) / "summary.json")["elapsed_seconds"]


def test_v2_manifests_resolve_and_wave4_transition_params_exist():
    """A v1 manifest bug found during the fixes: wave-4 quantized_chain entries
    passed 'acceptance' (unknown); they now pass 'rule'."""
    from cop.orchestration.manifest import generate
    from cop.finite.transition import build_system
    B = generate([4], "smoke")
    for e in B.entries.values():
        if e["cfg"]["kind"] == "finite" and e["cfg"]["finite"]["kind"] == "transition":
            t = e["cfg"]["finite"]["transition"]
            build_system(t["system"], dict(t["params"]))


def test_F9_local_opt_follows_the_train_schedule():
    from cop.train.trainer import LocalOpt, lr_at
    from cop.config import TRAIN_DEFAULTS
    tc = dict(TRAIN_DEFAULTS, optimizer="sgd", lr=0.1, lr_schedule="cosine", warmup=3, grad_clip=0.5)
    p = torch.nn.Parameter(torch.ones(3))
    lo = LocalOpt([p], tc, 20)
    seen = []
    for k in range(20):
        loss = (p * 10).sum()
        lo.step(loss, k)
        seen.append(lo.opt.param_groups[0]["lr"])
        assert float(p.grad.norm()) <= 10 * 3 ** 0.5        # gradient computed before clipping
    assert seen == [lr_at(k, 20, 0.1, "cosine", 3) for k in range(20)]
    assert type(lo.opt).__name__ == "SGD" and lo.resolved()["grad_clip"] == 0.5


def test_F12_censored_repair_extends_and_resumes_inside_the_extension(tmp_path):
    from resume_harness import compare_interrupted
    p = T.traj({"topology": "layered"}, train={**T.TRAIN, "checkpoint_every": 2})
    rp = T.child("repair", p[-1], {"repair": {"region": "incident_adapters", "budget_multiplier": 0.2,
                                              "eval_points": 2, "extension_factor": 3.0}})
    rp = resolve({**rp, "criteria": {**rp["criteria"], "nmse": [-10.0]}})      # unreachable: censored, extended
    r = compare_interrupted(p + [rp], tmp_path, fractions=(0.5, 0.9))
    assert r["equal"], r
    res = read_json(tmp_path / "A" / "runs" / run_id(rp) / "repair_result.json")
    assert res["extended"] and res["reach"]["task"]["-10.0"] is None
    assert res["updates_done"] == round(res["budget"] * 3.0)


def test_F12_region_none_evaluates_the_deletion_only(tmp_path):
    p = T.traj({"topology": "layered"})
    run_all(p, tmp_path)
    rp = T.child("repair", p[-1], {"repair": {"region": "none"}})
    assert run_job(rp, tmp_path, EX) == "complete"
    res = read_json(rdir(tmp_path, rp) / "repair_result.json")
    assert res["updates_done"] == 0 and not res["extended"] and [r["update"] for r in res["curve"]] == [0]
