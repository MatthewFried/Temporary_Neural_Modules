"""v29 / v30 (the stronger v31 versions of the removed tests are in test_v31.py): first-layer-only repair (with the other layers kept or reset to f0) and compact control, the keep
forks (additions retained, trained or frozen), the boundary data variants, the wave-21 panel, and the
layer-transplant tool (declared codes, trace, update decomposition, intervention checks)."""
from __future__ import annotations

import csv
import subprocess
import sys
from pathlib import Path

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import tiny_configs as T  # noqa: E402
from cop.config import resolve, run_id, ConfigError  # noqa: E402
from cop.utils import read_json  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


def _run(cfgs, d):
    from test_v15 import _run as r
    return r(cfgs, d)


def _traj(**kw):
    from test_v19 import _traj as t
    return t(**kw)


def _diss(traj_cfg, **over):
    from test_v19 import _diss as d_
    d = d_(traj_cfg)
    return resolve({**{k: v for k, v in d.items() if k != "dissipation"}, "dissipation": {**d["dissipation"], **over}})


def _tensors(path):
    return [v for v in torch.load(path, weights_only=False)["model"]["state"].values() if v.is_floating_point()]


def _c1_first():
    from test_v19 import SH
    b = resolve({"kind": "baseline", "data": SH, "model": T.MODEL, "train": T.TRAIN, "seeds": {"optimizer": 0}})
    c = resolve({"kind": "continue", "data": SH, "model": T.MODEL, "train": T.TRAIN, "seeds": {"optimizer": 0},
                 "parents": {"baseline": run_id(b)},
                 "continue": {"start": "baseline", "start_stage": "baseline", "budget": "fixed", "updates": 6,
                              "trainable_scope": "first"}})
    return [b, c]


def test_expanded_continuation_keeps_the_branches(tmp_path):
    p = _traj()
    c = resolve({"kind": "continue", "data": p[-1]["data"], "model": p[-1]["model"], "train": p[-1]["train"],
                 "seeds": p[-1]["seeds"], "parents": {"baseline": run_id(p[0]), "treated": run_id(p[-1])},
                 "continue": {"start": "treated", "start_stage": "final", "budget": "fixed", "segments": [4],
                              "segment_reset": [True]}})
    rd = _run(p + [c], tmp_path)
    from cop.graph.graph import GraphNet
    g = GraphNet.from_checkpoint(torch.load(rd / "ckpt" / "final.pt", weights_only=False)["model"])
    assert any(imp.nodes for imp in g.implants.values())


def json_params(c):
    p = c["data"].get("params") or {}
    if p.get("input_rotation"):
        return ("rotated",)
    if p.get("rule") == "product":
        return ("product",)
    return ("noshortcut",) if p.get("rho_train") == 0.5 else ("other",)


