"""v31: name-based checks of restricted repair (abrupt and gradual), C1_first, keep / keep_frozen and the
phase-matched forks; resume around the restoration; the boundary data generators; the transplant analysis's
strict coverage, audits, decomposition identities, aggregation and failure cases; the wave-21 panel."""
from __future__ import annotations

import csv
import json
import subprocess
import sys
from pathlib import Path

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import tiny_configs as T  # noqa: E402
from cop.config import resolve, run_id, ConfigError  # noqa: E402
from cop.utils import read_json  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
TOOL = str(ROOT / "audit_v5/tools/selective_reversal.py")


def _run(cfgs, d):
    from test_v15 import _run as r
    return r(cfgs, d)


def _traj(data=None, **kw):
    from test_v19 import _traj as t
    p = t(**kw)
    if data is not None:
        p = [resolve({**c, "data": data}) if c.get("data") else c for c in p]
        p = [p[0]] + [resolve({**p[1], "parents": {"baseline": run_id(p[0])}})]
    return p


def _diss(traj_cfg, **over):
    from test_v19 import _diss as d_
    d = d_(traj_cfg)
    return resolve({**{k: v for k, v in d.items() if k != "dissipation"}, "dissipation": {**d["dissipation"], **over}})


def _lin(traj_cfg, **over):
    return _diss(traj_cfg, method="linear", speed_updates=3, post_updates=3, save_path_checkpoints=True,
                 early_eval=[1, 2], **over)


def _state(path):
    return torch.load(path, weights_only=False)["model"]["state"]


def _first_pkey(path):
    from cop.graph.graph import GraphNet
    from cop.experiments.dissipation import scope_pkeys
    g = GraphNet.from_checkpoint(torch.load(path, weights_only=False)["model"])
    return next(iter(scope_pkeys(g, "first")))


def _by_name(a: dict, b: dict, prefix: str):
    """(names equal, names changed) among floating tensors present in both, split by the module prefix."""
    same, changed = [], []
    for k in a:
        if k in b and a[k].is_floating_point() and k.startswith(prefix):
            (same if torch.equal(a[k], b[k]) else changed).append(k)
    return same, changed


# ----------------------------------------------------------------------------- restricted repair

@pytest.mark.parametrize("gradual", [False, True])
def test_first_layer_repair_changes_exactly_the_first_layer(tmp_path, gradual):
    p = _traj()
    d = (_lin if gradual else _diss)(p[-1], repair_scope="first")
    rd = _run(p + [d], tmp_path)
    # the state at the start of the repair: the deletion event checkpoint (post-transition for the gradual path)
    start = _state(rd / "ckpt" / "event_deleted_0.pt")
    end = _state(rd / "ckpt" / "export.pt")
    first = _first_pkey(rd / "ckpt" / "export.pt")
    s_first, c_first = _by_name(end, start, f"mods.{first}.")
    assert c_first and not s_first                                    # the first layer learned
    others = [k for k in end if k.startswith("mods.") and not k.startswith(f"mods.{first}.")
              and end[k].is_floating_point()]
    assert others and all(torch.equal(end[k], start[k]) for k in others)   # nothing else moved in the repair
    if gradual:
        # the transition trained every layer: the repair's starting backbone is not the trajectory's end state
        traj_end = _state(tmp_path / "runs" / run_id(p[-1]) / "ckpt" / "final.pt")
        assert any(not torch.equal(start[k], traj_end[k]) for k in others if k in traj_end)
    ph = read_json(rd / "dissipation_result.json")["schedule_audit"]["phases"]
    rep = [x for x in ph if x["phase"].startswith(("post_", "recover_"))]
    assert rep and all(x["trainable"] == [first] for x in rep)


def test_restored_repair_starts_from_f0_downstream_on_the_gradual_path(tmp_path):
    p = _traj()
    d = _lin(p[-1], repair_scope="first", restore_before_repair="all_but_first")
    rd = _run(p + [d], tmp_path)
    f0 = _state(tmp_path / "runs" / run_id(p[-1]) / "ckpt" / "baseline_ref.pt")
    before = _state(rd / "ckpt" / "event_restore_before.pt")
    after = _state(rd / "ckpt" / "event_restore_after.pt")
    end = _state(rd / "ckpt" / "export.pt")
    first = _first_pkey(rd / "ckpt" / "export.pt")
    others = [k for k in end if k.startswith("mods.") and not k.startswith(f"mods.{first}.") and end[k].is_floating_point()]
    assert all(torch.equal(after[k], f0[k]) and torch.equal(end[k], f0[k]) for k in others)
    assert all(torch.equal(after[k], before[k]) for k in after if k.startswith(f"mods.{first}."))
    assert any(not torch.equal(before[k], f0[k]) for k in others)     # the restoration changed something
    ev = read_json(rd / "dissipation_result.json")["schedule_audit"]["events"]
    kinds = [e["event"] for e in ev]
    i_b, i_a = kinds.index("restore_before"), kinds.index("restore_after")
    assert i_b < i_a and ev[i_b]["update"] == ev[i_a]["update"]       # the same update, two distinct events


def test_resume_around_the_restoration_is_identical(tmp_path):
    from resume_harness import compare_interrupted
    p = _traj()
    d = _lin(p[-1], repair_scope="first", restore_before_repair="all_but_first")
    rep = compare_interrupted(p + [d], tmp_path / "resume", fractions=(0.45, 0.55, 0.65, 0.9))
    assert rep["interrupted_at_polls"] and rep["equal"], rep


def test_c1_first_changes_only_the_first_layer_by_name(tmp_path):
    from test_v19 import SH
    b = resolve({"kind": "baseline", "data": SH, "model": T.MODEL, "train": T.TRAIN, "seeds": {"optimizer": 0}})
    c = resolve({"kind": "continue", "data": SH, "model": T.MODEL, "train": T.TRAIN, "seeds": {"optimizer": 0},
                 "parents": {"baseline": run_id(b)},
                 "continue": {"start": "baseline", "start_stage": "baseline", "budget": "fixed", "updates": 6,
                              "trainable_scope": "first"}})
    rd = _run([b, c], tmp_path)
    start = _state(tmp_path / "runs" / run_id(b) / "ckpt" / "baseline.pt")
    end = _state(rd / "ckpt" / "final.pt")
    first = _first_pkey(rd / "ckpt" / "final.pt")
    _, changed = _by_name(end, start, f"mods.{first}.")
    assert changed
    assert all(torch.equal(end[k], start[k]) for k in end if end[k].is_floating_point()
               and not k.startswith(f"mods.{first}."))
    with pytest.raises(ConfigError):
        resolve({**c, "continue": {**c["continue"], "arm": "opt_reset"}})


# ----------------------------------------------------------------------------- keep forks and phase matching

def test_keep_learns_the_backbone_and_frozen_keeps_the_additions(tmp_path):
    from cop.graph.graph import GraphNet
    p = _traj()
    kt, kf = _diss(p[-1], method="keep", post_updates=4), _diss(p[-1], method="keep", post_updates=4,
                                                               keep_frozen_implants=True)
    _run(p + [kt], tmp_path)
    _run([kf], tmp_path)
    start = _state(tmp_path / "runs" / run_id(p[-1]) / "ckpt" / "final.pt")
    for cfg_, frozen in ((kt, False), (kf, True)):
        ck = torch.load(tmp_path / "runs" / run_id(cfg_) / "ckpt" / "export.pt", weights_only=False)["model"]
        g = GraphNet.from_checkpoint(ck)
        imp_p = {g.nodes[n].pkey for imp in g.implants.values() for n in imp.nodes if g.nodes[n].pkey}
        bb_p = {g.nodes[n].pkey for n in g.live_nodes() if g.nodes[n].pkey and g.nodes[n].owner is None}
        st = ck["state"]
        mk = [k for k in st if k.startswith("mods.") and st[k].is_floating_point() and k in start]
        imp_same = [torch.equal(st[k], start[k]) for k in mk if k.split(".")[1] in imp_p]
        bb_same = [torch.equal(st[k], start[k]) for k in mk if k.split(".")[1] in bb_p]
        assert imp_same and bb_same and not all(bb_same)                 # the backbone learned in both
        assert all(imp_same) if frozen else not all(imp_same)


def test_phase_matched_forks_share_parent_stream_and_reset_times_with_the_linear_removal(tmp_path):
    p = _traj()
    g = 3
    lin = _lin(p[-1])
    forks = [_diss(p[-1], method="keep", post_updates=6, split_updates=g, save_path_checkpoints=True),
             _diss(p[-1], method="keep", post_updates=6, split_updates=g, keep_frozen_implants=True),
             _diss(p[-1], method="abrupt", post_updates=6, split_updates=g)]
    _run(p + [lin], tmp_path)
    for f in forks:
        _run([f], tmp_path)
    audits = [read_json(tmp_path / "runs" / run_id(c) / "dissipation_result.json")["schedule_audit"]
              for c in [lin] + forks]
    assert len({a["parent_state_hash"] for a in audits}) == 1
    assert len({a["batch_id_hash"] for a in audits}) == 1                 # the same ordered minibatch ids
    for a in audits:
        resets = [e["update"] for e in a["events"] if e["event"] == "optimizer_reset"]
        assert resets == [0, g] and a["updates_total"] == 6
        assert len({(x["lr"], x["lr_schedule"], x["warmup"]) for x in a["phases"]}) == 1
    with pytest.raises(ConfigError):
        _diss(p[-1], method="linear", split_updates=2)


# ----------------------------------------------------------------------------- boundary data

def test_product_rule_and_rotation_follow_their_definitions():
    from cop.data.registry import load_bundle
    from cop.utils import torch_gen
    from test_v19 import SH
    pr = load_bundle({**SH, "params": {**SH["params"], "rule": "product"}}, device="cpu")
    gt = torch_gen(int(SH.get("teacher_seed", 0)), "teacher", "shortcut", "rules")
    wm, wr = torch.randn(8, generator=gt), torch.randn(8, generator=gt)
    gp = torch_gen(int(SH.get("teacher_seed", 0)), "teacher", "shortcut", "rules_product")
    vm, vr = torch.randn(8, generator=gp), torch.randn(8, generator=gp)
    for part in (pr.test, pr.extra["cf_base"], pr.extra["cf_causal"], pr.extra["cf_shortcut"]):
        c, grp = part.X["x"][:, :8], part.groups
        y = torch.where(grp == 1, (c @ wr) * (c @ vr) > 0, (c @ wm) * (c @ vm) > 0).long()
        assert torch.equal(y, part.y)
    cb, cc, csh = pr.extra["cf_base"], pr.extra["cf_causal"], pr.extra["cf_shortcut"]
    assert bool((cb.y != cc.y).all()) and torch.equal(cb.X["x"][:, 8], cc.X["x"][:, 8])
    assert torch.equal(cb.y, csh.y) and torch.equal(cb.X["x"][:, :8], csh.X["x"][:, :8])
    print("product-rule train positive share", float(pr.train.y.float().mean()))
    base = load_bundle(SH, device="cpu")
    rot = load_bundle({**SH, "params": {**SH["params"], "input_rotation": 1}}, device="cpu")
    Q = torch.tensor(rot.meta["feature_layout"]["input_rotation"], dtype=torch.float64)
    assert torch.allclose(Q @ Q.T, torch.eye(Q.shape[0], dtype=torch.float64), atol=1e-6)
    assert torch.allclose(rot.train.X["x"].double(), base.train.X["x"].double() @ Q, atol=1e-5)
    assert torch.equal(rot.train.y, base.train.y)


# ----------------------------------------------------------------------------- transplant analysis

def _manifest(tmp_path, cfgs):
    m = tmp_path / "m.jsonl"
    with open(m, "w") as f:
        for c in cfgs:
            f.write(json.dumps({"run_id": run_id(c), "cfg": c}) + "\n")
    return m


def _x25(c, arm="treated", variant="fixed"):
    return resolve({**c, "design": {"family": "X25", "variant": variant, "arm": arm, "contrast": "X25|c"}})


def _tool(tmp_path, man, prefix, *extra, device="cpu"):
    return subprocess.run([sys.executable, TOOL, str(tmp_path), str(tmp_path / prefix), "--manifest", str(man),
                           "--strict", "--device", device, *extra], capture_output=True, text=True)


def _setup(tmp_path, data=None):
    p = _traj(data=data)
    d = _x25(_lin(p[-1]))
    k = _x25(_diss(p[-1], method="keep", post_updates=6, split_updates=3, save_path_checkpoints=True,
                   early_eval=[1, 2]), arm="keep_pm")
    c1 = resolve({"kind": "continue", "data": p[0]["data"], "model": p[0]["model"], "train": p[0]["train"],
                  "seeds": p[0]["seeds"], "parents": {"baseline": run_id(p[0]), "treated": run_id(d)},
                  "continue": {"start": "baseline", "start_stage": "baseline", "budget": "parent_updates"},
                  "design": {"family": "X25", "variant": "compact", "arm": "C1", "contrast": "X25|c"}})
    _run(p + [d], tmp_path)
    _run([k], tmp_path)
    _run([c1], tmp_path)
    return p, d, k, _manifest(tmp_path, [d, k, c1])


def test_strict_analysis_passes_with_all_audits(tmp_path):
    p, d, k, man = _setup(tmp_path)
    r = _tool(tmp_path, man, "a", "--trace", "--decompose")
    assert r.returncode == 0, r.stdout + r.stderr
    cov = read_json(tmp_path / "a_coverage.json")
    assert cov["passed"] and cov["expected"] == 3 and cov["analysed"] == 3 and cov["contrast_partners_missing"] == 0
    checks = list(csv.DictReader(open(tmp_path / "a_checks.csv")))
    assert all(c["zero_code_identity"] == "True" and c["full_restore_identity"] == "True" for c in checks)
    kept = [c for c in checks if c["state"] == "kept_end"]
    assert kept and kept[0]["native_reload_pass"] == "True" and kept[0]["compaction"] == "branches deleted"
    codes = list(csv.DictReader(open(tmp_path / "a_codes.csv")))
    assert {c["function"] for c in codes if c["state"] == "kept_end"} >= {"branch_deleted", "layer_transplant"}
    de = list(csv.DictReader(open(tmp_path / "a_decomposition.csv")))
    assert len([x for x in de if x["run_id"] == run_id(d) and x["state"] == "repaired"]) == 16
    tr = list(csv.DictReader(open(tmp_path / "a_trace.csv")))
    assert any(x["checkpoint"].startswith("event_") for x in tr) and all(x["checkpoint_file"] for x in tr)
    # the shared trajectory history appears once, not once per fork
    tj = [x for x in tr if x["source"] == "trajectory"]
    assert len({(x["checkpoint"], x["code"]) for x in tj}) == len(tj)


def test_rotated_decomposition_identities(tmp_path):
    from test_v19 import SH
    _, d, _, man = _setup(tmp_path, data={**SH, "params": {**SH["params"], "input_rotation": 1}})
    r = _tool(tmp_path, man, "r", "--decompose", "--codes", "0-0-0-0-0,1-1-1-1-1,0-1-1-1-1")
    assert r.returncode == 0, r.stdout + r.stderr
    ck = [c for c in csv.DictReader(open(tmp_path / "r_checks.csv")) if c.get("decomposition_identities")]
    assert ck and all(float(c["rotation_round_trip_residual"]) < 1e-5 for c in ck)


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA device required")
def test_rotated_decomposition_on_cuda(tmp_path):
    from test_v19 import SH
    _, d, _, man = _setup(tmp_path, data={**SH, "params": {**SH["params"], "input_rotation": 1}})
    r = _tool(tmp_path, man, "rc", "--decompose", "--codes", "0-1-1-1-1", device="cuda")
    assert r.returncode == 0, r.stdout + r.stderr


def test_strict_analysis_fails_on_missing_checkpoint_corrupt_predictions_and_bad_codes(tmp_path):
    p, d, k, man = _setup(tmp_path)
    (tmp_path / "s_codes.csv").write_text("stale,rows\n1,2\n")              # a stale table from an earlier run
    rd = tmp_path / "runs" / run_id(d)
    ev = read_json(rd / "dissipation_result.json")["schedule_audit"]["events"]
    victim = rd / "ckpt" / f"{next(e['checkpoint'] for e in ev if e.get('checkpoint'))}.pt"
    keep = victim.read_bytes()
    victim.unlink()
    r = _tool(tmp_path, man, "s", "--trace")
    assert r.returncode != 0
    cov = read_json(tmp_path / "s_coverage.json")
    assert not cov["passed"] and cov["n_failed"] == 1 and "missing" in cov["failed"][0]["reason"]
    rows = list(csv.DictReader(open(tmp_path / "s_codes.csv")))
    assert all(x["run_id"] != run_id(d) for x in rows) and "stale" not in open(tmp_path / "s_codes.csv").read()
    assert any(x["run_id"] == run_id(d) for x in csv.DictReader(open(tmp_path / "s_diagnostic_partial.csv")))
    victim.write_bytes(keep)
    pp = rd / "preds" / "endpoint__test.pt"
    good = pp.read_bytes()
    t = torch.load(pp, weights_only=False)
    torch.save(t + 1.0, pp)
    r = _tool(tmp_path, man, "c")
    assert r.returncode != 0 and "reproduce" in read_json(tmp_path / "c_coverage.json")["failed"][0]["reason"]
    pp.write_bytes(good)
    r = _tool(tmp_path, man, "b", "--codes", "0-1-2")
    assert r.returncode != 0
    (rd / "status.json").write_text(json.dumps({"status": "failed"}))
    r = _tool(tmp_path, man, "f")
    assert r.returncode != 0 and read_json(tmp_path / "f_coverage.json")["n_failed"] >= 1


def test_levels_count_unique_data_draws():
    sys.path.insert(0, str(ROOT / "audit_v5/tools"))
    import importlib
    sr = importlib.import_module("selective_reversal")
    rows = []
    for ds in (301, 302, 303, 304, 305, 306):
        for os_ in (0, 1):
            for ps in (None, 1):
                rows.append({"cell": "c", "variant": "fixed", "arm": "treated", "removal_variant": "full",
                             "state": "repaired", "code": "0-1", "draw_set": "confirmation", "data_draw": ds,
                             "optimizer_seed": os_, "test_err": 0.2, "f0_test_err": 0.22 + 0.001 * ds % 3})
    sets, draws, summ = sr.levels(rows, "code")
    assert len(sets) == 12 and len(draws) == 6
    assert summ[0]["n_unique_data_draws"] == 6 and summ[0]["settings_per_draw"] == "2" and summ[0]["n_runs"] == 24


def test_draw_role_is_shared_and_declared_roles_win():
    from cop.analysis.v13_tables import draw_role
    assert draw_role({"data": {"data_seed": 0}, "seeds": {"optimizer": 0}}) == "discovery"
    assert draw_role({"data": {"data_seed": 203}, "seeds": {"optimizer": 0}}) == "fresh"
    assert draw_role({"data": {"data_seed": 301}, "seeds": {"optimizer": 0}}) == "other"
    assert draw_role({"data": {"data_seed": 301}, "design": {"role": "confirmation"}}) == "confirmation"


# ----------------------------------------------------------------------------- wave 21

def test_wave21_v31_structure():
    from cop.orchestration.manifest import generate
    B = generate([21], "full")
    ents = {k: e["cfg"] for k, e in B.entries.items()}
    assert len(ents) == 402                 # v34: + 12 f0 + fresh rebuilds; v36: + 6 loss-matched
    blocks = {}
    for e in B.entries.values():
        blocks.setdefault(e["blocks"][0], []).append(e["cfg"])
    rep = blocks["V30_replication"]
    assert {(c["data"]["data_seed"], c["seeds"]["optimizer"]) for c in rep if c["kind"] == "trajectory"} == \
        {(d, o) for d in range(301, 307) for o in (0, 1)}
    assert all(c["design"]["role"] == "confirmation" for c in rep if c.get("design", {}).get("family"))
    assert all(c["design"]["role"] == "exploratory" for b_ in ("V30_forks", "V31_forks_phase_matched",
                                                                "V30_restricted", "V30_cut", "V30_boundary")
               for c in blocks[b_] if c.get("design", {}).get("family"))
    U = next(c for c in ents.values() if c["kind"] == "trajectory")["growth"]["updates_per_round"]
    g, R = max(1, round(0.1 * U)), round(1.5 * U)
    pm = blocks["V31_forks_phase_matched"]
    assert {c["design"]["arm"] for c in pm} == {"abrupt_pm", "keep_pm", "keep_frozen_pm"}
    assert all(c["dissipation"]["split_updates"] == g and c["dissipation"]["post_updates"] == R for c in pm)
    win = [c for c in blocks["V30_restricted"] if c.get("design", {}).get("arm") == "C1_first_window"]
    assert win and all(c["continue"]["updates"] == R - g and c["continue"]["trainable_scope"] == "first" for c in win)
    ph = [c for c in rep if c.get("design", {}).get("arm") == "C1_phase"]
    assert all(c["continue"]["save_eval_checkpoints"] and 2 * U + g in c["continue"]["eval_at"] for c in ph)
