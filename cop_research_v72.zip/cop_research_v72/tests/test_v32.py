"""v32: coupling-time holds with frozen additions, the matched-damage control, and the cross-recipient first-layer
transplant (interface algebra, strict coverage)."""
from __future__ import annotations

import csv
import json
import subprocess
import sys
from pathlib import Path

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "audit_v5/tools"))
import tiny_configs as T  # noqa: E402
from cop.config import resolve, run_id, ConfigError  # noqa: E402
from cop.utils import read_json  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


def _run(cfgs, d):
    from test_v15 import _run as r
    return r(cfgs, d)


def _traj(**kw):
    from test_v19 import _traj as t
    return t(**kw)


def _diss(traj_cfg, **over):
    from test_v19 import _diss as d_
    d = d_(traj_cfg)
    return resolve({**{k: v for k, v in d.items() if k != "dissipation"}, "dissipation": {**d["dissipation"], **over}})


def _state(p):
    return torch.load(p, weights_only=False)["model"]["state"]


def test_frozen_hold_keeps_the_additions_unchanged_while_the_backbone_learns(tmp_path):
    from cop.graph.graph import GraphNet
    p = _traj()
    d = _diss(p[-1], method="linear", gate_schedule="hold", speed_updates=3, post_updates=3,
              save_path_checkpoints=True, keep_frozen_implants=True)
    rd = _run(p + [d], tmp_path)
    start = _state(tmp_path / "runs" / run_id(p[-1]) / "ckpt" / "final.pt")
    end_hold = torch.load(rd / "ckpt" / "path_u3.pt", weights_only=False)["model"]
    g = GraphNet.from_checkpoint(end_hold)
    imp_p = {g.nodes[n].pkey for imp in g.implants.values() for n in imp.nodes if g.nodes[n].pkey}
    bb_p = {g.nodes[n].pkey for n in g.live_nodes() if g.nodes[n].pkey and g.nodes[n].owner is None}
    st = end_hold["state"]
    mk = [k for k in st if k.startswith("mods.") and k in start and st[k].is_floating_point()]
    assert all(torch.equal(st[k], start[k]) for k in mk if k.split(".")[1] in imp_p)
    assert any(not torch.equal(st[k], start[k]) for k in mk if k.split(".")[1] in bb_p)
    with pytest.raises(ConfigError):
        _diss(p[-1], method="abrupt", keep_frozen_implants=True)


def test_matched_damage_control_reaches_the_deletion_damage(tmp_path):
    p = _traj()
    d = _diss(p[-1])
    c = resolve({"kind": "continue", "data": p[0]["data"], "model": p[0]["model"], "train": p[0]["train"],
                 "seeds": p[0]["seeds"], "parents": {"baseline": run_id(p[0]), "treated": run_id(d)},
                 "continue": {"start": "baseline", "start_stage": "baseline", "budget": "fixed", "segments": [4, 4],
                              "segment_reset": [False, True], "perturb_match": "parent_frozen_deletion",
                              "perturb_segment": 1, "perturb_match_tol": 0.5}})
    from cop.orchestration.runner import run_job, status_of
    _run(p + [d], tmp_path)
    st = run_job(c, tmp_path, {"device": "cpu"})
    rd = tmp_path / "runs" / run_id(c)
    pm = read_json(rd / "perturb_match.json")
    target = read_json(tmp_path / "runs" / run_id(d) / "dissipation_result.json")["frozen_weight_sweep"][
        "joint_deletion"]["val"]["err"]
    assert pm["target_val_err"] == target and pm["estimand"] == "absolute"
    if st == "complete":       # v34: the closer bracket end, within tolerance (else the job is invalid, recorded)
        assert abs(pm["achieved_val_err"] - target) <= pm["tolerance"] and pm["relative_scale"] >= 0
        assert read_json(rd / "continue_result.json")["perturb_match"]["achieved_val_err"] == pm["achieved_val_err"]
    else:
        assert st == "invalid" and pm.get("failure"), status_of(tmp_path, run_id(c))
    with pytest.raises(ConfigError):
        resolve({**c, "continue": {**c["continue"], "segments": [8], "segment_reset": [False]}})


def test_permutation_interface_recovers_a_permuted_copy_exactly(tmp_path):
    import cross_transplant as CT
    import selective_reversal as SR
    from cop.graph.graph import GraphNet
    from cop.data.registry import load_bundle
    from cop.train.trainer import predict
    p = _traj()
    rd = _run(p[:1], tmp_path)
    ck = torch.load(rd / "ckpt" / "baseline.pt", weights_only=False)["model"]
    rec = GraphNet.from_checkpoint(ck).eval()
    b = load_bundle(p[0]["data"], device="cpu")
    L = SR.backbone_layers(rec)
    _, act, _ = CT.first_block(rec, L)
    Hr = CT.hidden(rec, act, b.train.X)
    sd = {k: v.clone() for k, v in rec.state_dict().items()}
    perm = torch.randperm(sd[f"mods.{L[0]}.weight"].shape[0], generator=torch.Generator().manual_seed(0))
    sd_d = dict(sd)
    sd_d[f"mods.{L[0]}.weight"] = sd[f"mods.{L[0]}.weight"][perm]
    sd_d[f"mods.{L[0]}.bias"] = sd[f"mods.{L[0]}.bias"][perm]
    probe = GraphNet.from_checkpoint(ck).eval()
    probe.load_state_dict(sd_d)
    Hd = CT.hidden(probe, act, b.train.X)
    assert torch.allclose(Hd, Hr[:, perm])
    for itf in ("permutation", "affine"):
        A, c, n_par, r2 = CT.fit_interface(itf, Hd, Hr)
        sd2 = dict(sd_d)
        W2, b2 = sd[f"mods.{L[1]}.weight"].double(), sd[f"mods.{L[1]}.bias"].double()
        sd2[f"mods.{L[1]}.weight"] = (W2 @ A.T).float()
        sd2[f"mods.{L[1]}.bias"] = (b2 + W2 @ c).float()
        probe.load_state_dict(sd2)
        probe._plan = None
        assert r2 > 1 - 1e-6
        assert torch.allclose(predict(probe, b.test, 256), predict(rec, b.test, 256), atol=1e-4)


def test_cross_transplant_strict_run(tmp_path):
    from test_v19 import SH
    p = _traj()
    d = resolve({**_diss(p[-1], method="linear", speed_updates=3, post_updates=3, save_path_checkpoints=True),
                 "design": {"family": "X25", "variant": "fixed", "arm": "treated", "contrast": "X25|c"}})
    b1 = resolve({**p[0], "seeds": {**p[0]["seeds"], "optimizer": 1}})
    _run(p + [d], tmp_path)
    _run([b1], tmp_path)
    man = tmp_path / "m.jsonl"
    with open(man, "w") as f:
        for c in (p[0], b1, d):
            f.write(json.dumps({"run_id": run_id(c), "cfg": c}) + "\n")
    r = subprocess.run([sys.executable, str(ROOT / "audit_v5/tools/cross_transplant.py"), str(tmp_path),
                        str(tmp_path / "x"), "--manifest", str(man), "--strict"], capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr
    rows = list(csv.DictReader(open(tmp_path / "x_rows.csv")))
    assert {x["donor"] for x in rows} == {"repaired", "abrupt", "donor_f0", "random_layer"}
    assert {x["interface"] for x in rows} == {"identity", "permutation", "affine"}
    assert all(x["recipient_run"] == run_id(b1) for x in rows)
    for dn in ("repaired", "donor_f0", "random_layer"):
        r2 = {x["interface"]: float(x["interface_train_r2"]) for x in rows if x["donor"] == dn}
        assert r2["affine"] >= max(r2["identity"], r2["permutation"]) - 1e-6
    cov = read_json(tmp_path / "x_coverage.json")
    assert cov["passed"] and cov["analysed"] == 1
