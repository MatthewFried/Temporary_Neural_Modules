"""v33: age snapshots on the replication trajectories and the portability-by-age analysis."""
from __future__ import annotations

import csv
import json
import subprocess
import sys
from pathlib import Path

import torch  # noqa: F401

sys.path.insert(0, str(Path(__file__).resolve().parent))
from cop.config import resolve, run_id  # noqa: E402
from cop.utils import read_json  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


def _run(cfgs, d):
    from test_v15 import _run as r
    return r(cfgs, d)


# v34: the strict portability-by-age run moved to tests/test_v34.py (the panel's seed pattern: insertion and
# partition change with the optimizer seed; the pairing policy now requires it)


def test_wave21_replication_trajectories_save_age_snapshots():
    from cop.orchestration.manifest import generate
    from cop.orchestration.wave13 import v33_snapshots
    B = generate([21], "full")
    rep = [e["cfg"] for e in B.entries.values() if e["blocks"][0] == "V30_replication" and e["cfg"]["kind"] == "trajectory"]
    U = rep[0]["growth"]["updates_per_round"]
    assert all(c["train"]["snapshot_at"] == v33_snapshots(U) for c in rep)
    assert U not in v33_snapshots(U) and all(0 < u < 2 * U for u in v33_snapshots(U))
