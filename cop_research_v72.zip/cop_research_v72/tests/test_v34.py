"""v34 (review of v33): the portability-by-age analysis (A inventory, B pairing, C integrity, D recipient baselines,
E alignment status and saved maps, F cohorts and event order), G snapshot neutrality and resume, H the v32 control
corrections (matched perturbation, explicit segment_reset, phase-matched C1_disturbed, the f0 + fresh corner,
strict selective reversal, promised cross-transplant recipients).  The launcher (I) is in test_v34_launcher.py."""
from __future__ import annotations

import csv
import json
import shutil
import subprocess
import sys
from pathlib import Path

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "audit_v5/tools"))
import tiny_configs as T  # noqa: E402
from cop.config import resolve, run_id  # noqa: E402
from cop.utils import read_json, stable_hash, tensor_hash  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
AGE = str(ROOT / "audit_v5/tools/portability_age.py")
SRT = str(ROOT / "audit_v5/tools/selective_reversal.py")
CTT = str(ROOT / "audit_v5/tools/cross_transplant.py")


def _run(cfgs, d):
    from test_v15 import _run as r
    return r(cfgs, d)


def _manifest(path: Path, cfgs) -> Path:
    with open(path, "w") as f:
        for c in cfgs:
            f.write(json.dumps({"run_id": run_id(c), "cfg": c}) + "\n")
    return path


def _pair(snaps=(3, 9)):
    """the panel's seed pattern: the partner changes optimizer AND insertion (init, minibatch and partition follow);
    U = 6, two rounds.  -> (host [baseline, trajectory], partner [baseline, trajectory], host's C1_phase)."""
    from test_v19 import _traj
    h = _traj(snapshot_at=list(snaps))
    b1 = resolve({**h[0], "seeds": {**h[0]["seeds"], "optimizer": 1}})
    t1 = resolve({**h[1], "seeds": {**h[1]["seeds"], "optimizer": 1, "insertion": 1},
                  "parents": {"baseline": run_id(b1)}})
    c1p = resolve({"kind": "continue", "data": h[0]["data"], "model": h[0]["model"], "train": h[0]["train"],
                   "seeds": h[0]["seeds"], "parents": {"baseline": run_id(h[0])},
                   "continue": {"start": "baseline", "start_stage": "baseline", "budget": "fixed", "segments": [6, 6],
                                "segment_reset": [False, False], "eval_at": [3, 6, 9, 12],
                                "save_eval_checkpoints": True},
                   "design": {"family": "X25", "variant": "compact", "arm": "C1_phase", "contrast": "X25|c"}})
    return h, [b1, t1], c1p


@pytest.fixture(scope="module")
def age_root(tmp_path_factory):
    d = tmp_path_factory.mktemp("age")
    h, p, c1p = _pair()
    _run(h, d)
    _run(p, d)
    _run([c1p], d)
    _manifest(d / "m.jsonl", [h[0], h[1], p[0], p[1], c1p])
    return d, h, p, c1p


def _copy(root: Path, tmp: Path) -> Path:
    dst = tmp / "res"
    shutil.copytree(root, dst)
    return dst


def _age(res: Path, prefix: str, *extra, man: Path | None = None):
    return subprocess.run([sys.executable, AGE, str(res), str(res / prefix), "--manifest", str(man or res / "m.jsonl"),
                           "--strict", *extra], capture_output=True, text=True)


def _rows(p):
    return list(csv.DictReader(open(p)))


# ----------------------------------------------------------------------------- A / D / E / F: the complete design

def test_age_strict_run_complete(age_root, tmp_path):
    root, h, p, _ = age_root
    res = _copy(root, tmp_path)
    r = _age(res, "a")
    assert r.returncode == 0, r.stdout + r.stderr
    cov = read_json(res / "a_coverage.json")
    assert cov["passed"] and cov["analysed_directions"] == 2 == cov["expected_directions"]
    assert cov["expected_units"] == cov["analysed_units"] > 0 and not cov["missing_units"]
    rows = _rows(res / "a_rows.csv")
    # F: stages in event order, round_1 and post_insert_r2 distinct at the same clock
    order = sorted({(int(x["event_order"]), x["stage"], x["trajectory_updates"]) for x in rows if x["stage"] != "none"})
    assert [o[1] for o in order] == ["post_insert_r1", "snap_3", "round_1", "post_insert_r2", "snap_9", "final"]
    assert order[2][2] == order[3][2] == "6"
    r2 = [x for x in rows if x["stage"] == "post_insert_r2" and x["measure"] == "branches_raw"]
    assert {x["subset"] for x in r2} == {"all", "r1", "r2"}
    assert all(x["age_r1"] == "6" and x["age_r2"] == "0" for x in r2)
    s9 = [x for x in rows if x["stage"] == "snap_9" and x["measure"] == "branches_aligned" and x["subset"] == "r2"]
    assert s9 and all(x["subset_ages"] == "spec/r2/a:3+spec/r2/b:3" for x in s9)
    assert not [x for x in rows if x["stage"] in ("snap_3", "round_1") and x["subset"] in ("r1", "r2")]
    # the time-matched compact reference exists only for the host whose f0 has a C1_phase
    comp = [x for x in rows if x["measure"].startswith("compact_")]
    assert {x["run_id"] for x in comp} == {run_id(h[1])}
    assert {x["stage"] for x in comp} == {"snap_3", "round_1", "post_insert_r2", "snap_9", "final"}
    # D: every transfer row carries its RECIPIENT's f0, and the gain is against it
    own_f0 = {x["run_id"]: x["ref_f0_test_err"] for x in rows if x["measure"] == "host_intact"}
    for x in rows:
        if x["measure"] in ("first_layer_into_partner_f0", "branches_raw", "branches_aligned",
                            "compact_first_layer_into_partner_f0") or x["measure"].endswith("_layer_into_partner_f0"):
            assert x["ref_f0_test_err"] == own_f0[x["recipient_run"]]
            assert float(x["gain_vs_f0_test_err"]) == pytest.approx(float(x["ref_f0_test_err"]) - float(x["test_err"]))
        if x["measure"] in ("branches_raw", "branches_aligned"):
            assert "ref_intact_test_err" in x and "ref_without_test_err" in x
        if x["measure"] == "first_layer_into_partner_f0":
            assert x["ref_donor_f0_ctrl_test_err"] and x["ref_random_ctrl_test_err"]
    # E: statuses recorded, maps saved and refolded bitwise from fresh checkpoints, insertion checks
    ch = _rows(res / "a_checks.csv")
    names = {c["check"].split(":")[0] for c in ch}
    assert {"map_reconstruction", "insertion_preserves_function", "age_zero_backbone_equals_f0",
            "self_branch_copy_reproduces_partner"} <= names
    assert all(c["passed"] == "True" for c in ch if c.get("required") != "False")
    assert len(list((res / "a_maps").glob("*.pt"))) == 2
    al = [x for x in rows if x["measure"] == "branches_aligned"]
    assert all(int(x["adapter_n_unsupported"]) == 0 and int(x["adapter_n_numerical_failure"]) == 0 for x in al)
    # B: the seeds of both sides are recorded
    hr = [x for x in rows if x["run_id"] == run_id(h[1])]
    assert {x["host_insertion_seed"] for x in hr} == {"0"} and {x["recipient_insertion_seed"] for x in hr} == {"1"}
    # summaries are per stage (never merged across stages) and over unique data draws
    summ = _rows(res / "a_summary.csv")
    assert all(x["n_unique_data_draws"] == "1" for x in summ)
    assert len({(x["stage"], x["measure"], x["subset"], x["interface"]) for x in summ}) == len(summ)


@pytest.mark.parametrize("case", ["one_partner", "both_partners", "all_intermediate", "final"])
def test_age_strict_fails_on_any_missing_scheduled_checkpoint(age_root, tmp_path, case):
    root, h, p, _ = age_root
    res = _copy(root, tmp_path)
    hd, pd = res / "runs" / run_id(h[1]) / "ckpt", res / "runs" / run_id(p[1]) / "ckpt"
    if case == "one_partner":
        (pd / "snap_9.pt").unlink()
    elif case == "both_partners":
        (pd / "snap_9.pt").unlink()
        (hd / "snap_9.pt").unlink()
    elif case == "all_intermediate":
        for dd in (hd, pd):
            for f in dd.glob("snap_*.pt"):
                f.unlink()
    else:
        (hd / "final.pt").unlink()
    r = _age(res, "m")
    assert r.returncode != 0
    cov = read_json(res / "m_coverage.json")
    assert not cov["passed"] and cov["n_failed"] >= 1
    assert any("missing" in f["reason"] for f in cov["failed"])


def test_age_rejects_a_manifest_with_duplicated_run_ids(age_root, tmp_path):
    res = _copy(age_root[0], tmp_path)
    lines = (res / "m.jsonl").read_text().splitlines()
    (res / "dup.jsonl").write_text("\n".join(lines + lines[-1:]) + "\n")
    r = _age(res, "d", man=res / "dup.jsonl")
    assert r.returncode != 0 and "duplicated" in json.dumps(read_json(res / "d_coverage.json")["failed"])


# ----------------------------------------------------------------------------- C: integrity

def _tamper_weights(path: Path, nan: bool = False, rehash: bool = False):
    ck = torch.load(path, weights_only=False)
    k = next(k for k, v in ck["model"]["state"].items() if v.is_floating_point() and v.numel() > 1)
    if nan:
        ck["model"]["state"][k] = ck["model"]["state"][k].clone().fill_(float("nan"))
    else:
        ck["model"]["state"][k] = ck["model"]["state"][k] + 1e-3
    if rehash:
        ck["lineage"]["param_hash"] = stable_hash({kk: tensor_hash(v) for kk, v in ck["model"]["state"].items()})
    torch.save(ck, path)


@pytest.mark.parametrize("case,needle", [("weights", "parameter hash"), ("stage", "stage"), ("source", "belongs to"),
                                         ("data", "logged"), ("nan", "non-finite")])
def test_age_strict_rejects_corrupt_checkpoints_and_data(age_root, tmp_path, case, needle):
    root, h, p, _ = age_root
    res = _copy(root, tmp_path)
    hd, pd = res / "runs" / run_id(h[1]), res / "runs" / run_id(p[1])
    if case == "weights":
        _tamper_weights(hd / "ckpt" / "snap_3.pt")
    elif case == "stage":
        shutil.copy2(hd / "ckpt" / "snap_3.pt", hd / "ckpt" / "snap_9.pt")
    elif case == "source":
        shutil.copy2(pd / "ckpt" / "snap_3.pt", hd / "ckpt" / "snap_3.pt")
    elif case == "data":
        out = []
        for line in (hd / "log.jsonl").read_text().splitlines():
            r = json.loads(line)
            if r.get("event") == "data" and r.get("split_hashes"):
                r["split_hashes"]["train"] = "0" * 16
            out.append(json.dumps(r))
        (hd / "log.jsonl").write_text("\n".join(out) + "\n")
    else:
        _tamper_weights(hd / "ckpt" / "snap_9.pt", nan=True, rehash=True)
    r = _age(res, "c")
    assert r.returncode != 0
    cov = read_json(res / "c_coverage.json")
    assert not cov["passed"] and any(needle in f["reason"] for f in cov["failed"]), cov["failed"]
    # nothing of the failed direction is committed
    rows = _rows(res / "c_rows.csv") if (res / "c_rows.csv").read_text().strip() != "empty" else []
    assert all(x["run_id"] != run_id(h[1]) for x in rows)


# ----------------------------------------------------------------------------- B: pairing

def test_pairing_follows_the_declared_policy_on_the_real_panel_and_rejects_others():
    import portability_age as PA
    from cop.orchestration.manifest import generate
    from cop.orchestration.wave13 import v33_snapshots
    B = generate([21], "full")
    mcfg = {k: e["cfg"] for k, e in B.entries.items()}
    dirs, fails = PA.pairs_from(mcfg)
    assert not fails and len(dirs) == 24                          # 6 draws x fixed / redrawn x 2 directions
    for a, b in dirs:
        sa, sb = PA.streams(mcfg[a]), PA.streams(mcfg[b])
        assert all(sa[s] != sb[s] for s in PA.MUST_DIFFER)
        assert mcfg[a]["data"] == mcfg[b]["data"] and mcfg[a]["growth"] == mcfg[b]["growth"]
    st = PA.expected_stages(mcfg[dirs[0][0]])
    U = mcfg[dirs[0][0]]["growth"]["updates_per_round"]
    assert len(st) == len(v33_snapshots(U)) + 4
    cp = PA.compact_partner(mcfg, mcfg[dirs[0][0]])
    assert cp is not None and all(s["u"] in cp[2] for s in st if s["u"] > 0)   # time-matched compact states
    # rejected: equal insertion seeds, a changed learning rate (no partner), three members
    a, b = dirs[0]
    bad = dict(mcfg)
    bad[b] = {**mcfg[b], "seeds": {**mcfg[b]["seeds"], "insertion": mcfg[a]["seeds"]["insertion"]}}
    _, f = PA.pairs_from({a: mcfg[a], b: bad[b]})
    assert f and all("streams" in x["reason"] for x in f)
    lr = {**mcfg[b], "train": {**mcfg[b]["train"], "lr": mcfg[b]["train"]["lr"] * 2}}
    _, f = PA.pairs_from({a: mcfg[a], b: lr})
    assert len(f) == 2 and all("exactly two" in x["reason"] for x in f)
    third = {**mcfg[b], "seeds": {**mcfg[b]["seeds"], "optimizer": 7, "insertion": 7},
             "parents": {"baseline": "base-other"}}
    _, f = PA.pairs_from({a: mcfg[a], b: mcfg[b], "traj-third": third})
    assert len(f) == 3


def test_age_plan_counts_on_the_real_panel():
    import portability_age as PA
    from cop.orchestration.manifest import generate
    mcfg = {k: e["cfg"] for k, e in generate([21], "full").entries.items()}
    dirs, _ = PA.pairs_from(mcfg)
    st = PA.expected_stages(mcfg[dirs[0][0]])
    cp = PA.compact_partner(mcfg, mcfg[dirs[0][0]])
    units = PA.plan_units(st, cp[2])
    n_two = sum(len(s["cohorts"]) == 1 for s in st)
    n_four = len(st) - n_two
    # controls 9; per stage: native 2, self 1, first layer 4, compact 5 (u > 0); branches 2 (two players) or 6
    assert len(units) == 9 + len(st) * 7 + 5 * (len(st) - 1) + 2 * n_two + 6 * n_four
    assert len(set(units)) == len(units)


# ----------------------------------------------------------------------------- D: arithmetic

def test_recipient_baselines_are_used_per_direction_before_averaging():
    import portability_age as PA
    # donor f0 .20, recipient f0 .30, transfer .25: the recipient improved by .05 (v33 reported -.05)
    a = PA.with_refs({"data_draw": 1, "run_id": "A", "recipient_run": "B", "measure": "m", "test_err": 0.25},
                     {"f0": {"test_err": 0.30}})
    b = PA.with_refs({"data_draw": 1, "run_id": "B", "recipient_run": "A", "measure": "m", "test_err": 0.28},
                     {"f0": {"test_err": 0.20}})
    assert a["gain_vs_f0_test_err"] == pytest.approx(0.05) and b["gain_vs_f0_test_err"] == pytest.approx(-0.08)
    c = PA.with_refs({"data_draw": 2, "run_id": "C", "recipient_run": "D", "measure": "m", "test_err": 0.10},
                     {"f0": {"test_err": 0.12}})
    by_draw, summ = PA.draw_levels([a, b, c], ("measure",))
    d1 = next(x for x in by_draw if x["data_draw"] == 1)
    assert d1["n_rows"] == 2 and d1["gain_vs_f0_test_err"] == pytest.approx(-0.015)
    s = summ[0]
    assert s["n_unique_data_draws"] == 2 and s["mean_gain_vs_f0_test_err"] == pytest.approx((-0.015 + 0.02) / 2)
    assert s["gain_vs_f0_test_err_draws_positive"] == "1/2" and s["gain_vs_f0_test_err_ci95_low"] is not None


# ----------------------------------------------------------------------------- E: alignment statuses

def _branch_lin(g, slot):
    from cop.experiments.dissipation import _branch_out_linear
    t = next(t for t, imp in g.implants.items() if imp.slot == slot)
    return _branch_out_linear(g, t)


def test_alignment_statuses_representability_and_saved_maps(age_root):
    from cop.data.registry import load_bundle
    from cop.experiments.dissipation import align_swapped, apply_saved_alignment, node_values, swap_players
    from cop.graph.graph import GraphNet
    from cop.train.trainer import predict
    root, h, _, _ = age_root
    ck = torch.load(root / "runs" / run_id(h[1]) / "ckpt" / "final.pt", weights_only=False)
    b = load_bundle(h[1]["data"], device="cpu")
    R = GraphNet.from_checkpoint(ck["model"]).eval()
    s1, s2 = [x for x in swap_players(R) if "/r1/" in x]          # one group: the same backbone input
    pk = lambda g, sl: g.nodes[_branch_lin(g, sl)].pkey

    # self: every branch keeps the identity
    Hs = R.clone(share_params=False)
    out = align_swapped(Hs, R, swap_players(R), b, 256)
    assert out["ok"] and out["status_counts"]["identity_fallback"] == len(swap_players(R))
    # fitted, with the map saved and refolded exactly
    H = R.clone(share_params=False)
    R2 = R.clone(share_params=False)
    with torch.no_grad():
        R2.mods[pk(R2, s1)].bias.add_(1.0)                          # the receiver's term = H's + 1
    H0 = H.clone(share_params=False)
    mp = {}
    out = align_swapped(H, R2, [s1], b, 256, maps=mp)
    assert out["ok"] and out["branches"][s1]["status"] == "fitted" and mp[s1] is not None
    lin = _branch_lin(H, s1)
    assert torch.allclose(node_values(H, b.train, [lin], 256)[lin], node_values(R2, b.train, [lin], 256)[lin],
                          atol=1e-4)
    apply_saved_alignment(H0, mp)
    assert torch.equal(predict(H0, b.test, 256), predict(H, b.test, 256))
    # unsupported (no bias for the offset) beside a fitted branch: the unsupported branch is left untouched
    H = R.clone(share_params=False)
    R3 = R.clone(share_params=False)
    with torch.no_grad():
        R3.mods[pk(R3, s1)].bias.add_(1.0)
        R3.mods[pk(R3, s2)].bias.add_(1.0)
    H.mods[pk(H, s1)].register_parameter("bias", None)
    w_before = H.mods[pk(H, s1)].weight.detach().clone()
    out = align_swapped(H, R3, [s1, s2], b, 256)
    assert out["branches"][s1]["status"] == "unsupported" and out["branches"][s2]["status"] == "fitted"
    assert not out["ok"] and out["status_counts"]["unsupported"] == 1 and out["status_counts"]["fitted"] == 1
    assert torch.equal(H.mods[pk(H, s1)].weight, w_before)
    # numerical failure: non-finite branch terms
    H = R.clone(share_params=False)
    with torch.no_grad():
        H.mods[pk(H, s1)].weight.fill_(float("nan"))
    out = align_swapped(H, R, [s1], b, 256)
    assert out["branches"][s1]["status"] == "numerical_failure" and not out["ok"]


# ----------------------------------------------------------------------------- G: snapshot neutrality

def _same(a, b) -> bool:
    if isinstance(a, torch.Tensor):
        return isinstance(b, torch.Tensor) and torch.equal(a, b)
    if isinstance(a, dict):
        return isinstance(b, dict) and a.keys() == b.keys() and all(_same(a[k], b[k]) for k in a)
    if isinstance(a, (list, tuple)):
        return isinstance(b, (list, tuple)) and len(a) == len(b) and all(_same(x, y) for x, y in zip(a, b))
    return a == b


def test_snapshots_do_not_change_training_and_resume_reproduces_them(tmp_path):
    from test_v19 import _traj
    from resume_harness import compare_interrupted
    p = _traj(snapshot_at=[3, 9])
    q = resolve({**p[1], "train": {**p[1]["train"], "snapshot_at": []}})
    _run(p, tmp_path)
    _run([q], tmp_path)
    rp, rq = tmp_path / "runs" / run_id(p[1]) / "ckpt", tmp_path / "runs" / run_id(q) / "ckpt"
    assert (rp / "snap_3.pt").exists() and (rp / "snap_9.pt").exists() and not list(rq.glob("snap_*.pt"))
    for st in ("round_1", "post_insert_r2", "final"):
        a, b = torch.load(rp / f"{st}.pt", weights_only=False), torch.load(rq / f"{st}.pt", weights_only=False)
        assert a["lineage"]["param_hash"] == b["lineage"]["param_hash"], st
        assert _same(a["trainer"]["opt"], b["trainer"]["opt"]) and _same(a["trainer"]["gens"], b["trainer"]["gens"])
        for k in ("global_step", "examples", "perm", "pos"):
            assert _same(a["trainer"]["state"].get(k), b["trainer"]["state"].get(k)), (st, k)
    rep = compare_interrupted(p, tmp_path / "resume", fractions=(0.2, 0.45, 0.55, 0.8))
    assert rep["interrupted_at_polls"] and rep["equal"], rep


# ----------------------------------------------------------------------------- H: v32 corrections

class _Ctx:
    def __init__(self, fws):
        self.fws, self.saved = fws, {}

    def parent_json(self, role, name):
        return {"frozen_weight_sweep": self.fws}

    def save_json(self, name, obj):
        self.saved[name] = obj


def _perturb_setup(tmp_path):
    from test_v19 import SH
    from cop.data.registry import load_bundle
    from cop.graph.graph import GraphNet
    b = resolve({"kind": "baseline", "data": SH, "model": T.MODEL, "train": T.TRAIN, "seeds": {"optimizer": 0}})
    rd = _run([b], tmp_path)
    m = GraphNet.from_checkpoint(torch.load(rd / "ckpt" / "baseline.pt", weights_only=False)["model"])
    return b, m, load_bundle(SH, device="cpu")


def _val_err(m, bundle, cfg):
    from cop.train.trainer import evaluate
    r, _ = evaluate(m, bundle, ["val"], cfg["train"]["eval_batch"])
    return 1.0 - float(r["val"]["acc"])


def test_matched_perturbation_estimands_tolerance_and_invalid_targets(tmp_path):
    from cop.experiments.context import ScientificInvalid
    from cop.experiments.continuation import _perturb_matched
    cfg, m, bundle = _perturb_setup(tmp_path)
    e0 = _val_err(m, bundle, cfg)
    p0 = [p.detach().clone() for p in m.parameters()]
    cc = {"budget_parent": "treated", "perturb_match": "parent_frozen_deletion", "perturb_estimand": "absolute",
          "perturb_match_tol": 0.5}
    for fws, why in (({"intact": {"val": {"err": 0.0}}, "joint_deletion": {"val": {"err": 1.5}}}, "unreachable"),
                     ({"intact": {"val": {"err": 0.0}}, "joint_deletion": {"val": {"err": 0.0}}}, "not above")):
        ctx = _Ctx(fws)
        with pytest.raises(ScientificInvalid):
            _perturb_matched(ctx, cfg, cc, m, bundle)
        assert why in ctx.saved["perturb_match.json"]["failure"]
        assert all(torch.equal(a, b_) for a, b_ in zip(m.parameters(), p0))       # weights restored
    assert e0 < 0.4
    inc = 0.5 * (0.5 - e0)                       # halfway to chance: reachable by a large random perturbation
    target = e0 + inc
    ctx = _Ctx({"intact": {"val": {"err": 0.0}}, "joint_deletion": {"val": {"err": target}}})
    rec = _perturb_matched(ctx, cfg, cc, m, bundle)
    assert rec["target_val_err"] == target and abs(rec["achieved_val_err"] - target) <= rec["tolerance"]
    assert _val_err(m, bundle, cfg) == pytest.approx(rec["achieved_val_err"])       # the model is left at the scale
    with torch.no_grad():
        for p, v in zip(m.parameters(), p0):
            p.copy_(v)
    ctx = _Ctx({"intact": {"val": {"err": 0.1}}, "joint_deletion": {"val": {"err": 0.1 + inc}}})
    rec = _perturb_matched(ctx, cfg, {**cc, "perturb_estimand": "increment", "perturb_match_tol": 1e-9}, m, bundle)
    assert rec["target_val_err"] == pytest.approx(e0 + inc) and rec["estimand"] == "increment"
    assert rec["tolerance"] == pytest.approx(1.0 / len(bundle.val))      # never below one validation example
    assert abs(rec["achieved_val_err"] - rec["target_val_err"]) <= rec["tolerance"]


def test_declared_segment_reset_overrides_the_global_optimizer_setting(tmp_path):
    from test_v19 import SH
    b = resolve({"kind": "baseline", "data": SH, "model": T.MODEL, "train": T.TRAIN, "seeds": {"optimizer": 0}})

    def cont(reset, glob):
        return resolve({"kind": "continue", "data": SH, "model": T.MODEL,
                        "train": {**T.TRAIN, "opt_state_on_edit": glob}, "seeds": {"optimizer": 0},
                        "parents": {"baseline": run_id(b)},
                        "continue": {"start": "baseline", "start_stage": "baseline", "budget": "fixed",
                                     "segments": [5, 5], "segment_reset": reset}})
    _run([b], tmp_path)
    fin = {}
    for reset in ([False, False], [True, True]):
        for glob in ("preserve", "reset"):
            rd = _run([cont(reset, glob)], tmp_path)
            fin[(tuple(reset), glob)] = torch.load(rd / "ckpt" / "final.pt", weights_only=False)["model"]["state"]
    same = lambda x, y: all(torch.equal(x[k], y[k]) for k in x)
    assert same(fin[((False, False), "preserve")], fin[((False, False), "reset")])    # False carries the state
    assert same(fin[((True, True), "preserve")], fin[((True, True), "reset")])
    assert not same(fin[((False, False), "reset")], fin[((True, True), "reset")])


def test_wave21_v34_controls():
    from cop.orchestration.manifest import generate
    from cop.orchestration.wave13 import v33_snapshots
    B = generate([21], "full")
    ents = [e["cfg"] for e in B.entries.values()]
    assert len(ents) == 402
    U = next(c for c in ents if c["kind"] == "trajectory")["growth"]["updates_per_round"]
    g, R = max(1, round(0.1 * U)), round(1.5 * U)
    dist = [c for c in ents if c["kind"] == "continue" and c["design"]["arm"] == "C1_disturbed"]
    assert len(dist) == 6 and all(c["continue"]["segments"] == [U, U, g, R - g] and
                                  c["continue"]["segment_reset"] == [False, False, True, True] and
                                  c["continue"]["perturb_segment"] == 2 for c in dist)
    assert all(c["continue"]["perturb_match_metric"] == "val_err" for c in dist)
    loss = [c for c in ents if c["kind"] == "continue" and c["design"]["arm"] == "C1_disturbed_loss"]
    assert len(loss) == 6 and all(c["continue"]["perturb_match_metric"] == "val_risk" and
                                  c["continue"]["segments"] == [U, U, g, R - g] for c in loss)
    apm = [c for c in ents if c["kind"] == "dissipation" and c["design"]["arm"] == "abrupt_pm"]
    assert apm and all(c["dissipation"]["split_updates"] == g and c["dissipation"]["post_updates"] == R for c in apm)
    f0f = [c for c in ents if c["kind"] == "dissipation" and c["design"]["arm"] == "linear_f0_fresh"]
    assert len(f0f) == 12 and all(c["dissipation"]["rebuild"] == {"backbone": "f0", "implants": "fresh"} and
                                  c["dissipation"]["method"] == "linear" for c in f0f)
    ph = [c for c in ents if c["kind"] == "continue" and c["design"]["arm"] == "C1_phase"
          and c["block"] == "V30_replication"]
    assert len(ph) == 12 and all(set(v33_snapshots(U)) <= set(c["continue"]["eval_at"]) for c in ph)


def test_expected_schedule_matches_the_dissipation_ledger_rules():
    import selective_reversal as SR
    lin = {"dissipation": {"method": "linear", "speed_updates": 3, "post_updates": 5, "order": "joint"}}
    ph, ev = SR.expected_schedule(lin)
    assert ph == [("anneal_0", 0, 3), ("post_0", 3, 5)]
    assert ev == [("optimizer_reset", None, "anneal_0"), ("physical_deletion", "event_deleted_0", None),
                  ("optimizer_reset", None, "post_0")]
    ph, ev = SR.expected_schedule({"dissipation": {"method": "abrupt", "post_updates": 5, "split_updates": 2,
                                                   "restore_before_repair": "all_but_first"}})
    assert ph == [("recover_0", 0, 2), ("recover_0b", 2, 3)]
    assert [e[0] for e in ev] == ["physical_deletion", "optimizer_reset", "restore_before", "restore_after",
                                  "optimizer_reset"]
    ph, _ = SR.expected_schedule({"dissipation": {"method": "keep", "post_updates": 6, "split_updates": 3}})
    assert ph == [("keep_0", 0, 3), ("keep_1", 3, 3)]
    with pytest.raises(SR.Fail):
        SR.expected_schedule({"dissipation": {"method": "linear", "speed_updates": 1, "post_updates": 1,
                                              "order": "ancestor_first"}})


def test_selective_reversal_strict_requires_provenance_ledger_and_no_prefix(tmp_path):
    from test_v31 import _setup, _tool
    p, d, k, man = _setup(tmp_path)
    r = subprocess.run([sys.executable, SRT, str(tmp_path), str(tmp_path / "l"), "--manifest", str(man), "--strict",
                        "--limit", "1"], capture_output=True, text=True)
    assert r.returncode != 0 and "--limit" in r.stderr
    rd = tmp_path / "runs" / run_id(d)
    j = read_json(rd / "dissipation_result.json")
    good = json.dumps(j)
    j["schedule_audit"]["events"] = j["schedule_audit"]["events"][1:]           # a ledger that lost an event
    (rd / "dissipation_result.json").write_text(json.dumps(j))
    r = _tool(tmp_path, man, "t", "--trace")
    assert r.returncode != 0
    assert "logged events" in json.dumps(read_json(tmp_path / "t_coverage.json")["failed"])
    (rd / "dissipation_result.json").write_text(good)
    log = (rd / "log.jsonl").read_text().splitlines()
    (rd / "log.jsonl").write_text("\n".join(x for x in log if '"event": "data"' not in x) + "\n")
    r = _tool(tmp_path, man, "pv")
    assert r.returncode != 0
    assert any(f["run_id"] == run_id(d) and "split hashes" in f["reason"]
               for f in read_json(tmp_path / "pv_coverage.json")["failed"])


def test_cross_transplant_promised_recipient_must_exist(tmp_path):
    from test_v32 import _traj, _diss
    p = _traj()
    d = resolve({**_diss(p[-1], method="linear", speed_updates=3, post_updates=3, save_path_checkpoints=True),
                 "design": {"family": "X25", "variant": "fixed", "arm": "treated", "contrast": "X25|c"}})
    b1 = resolve({**p[0], "seeds": {**p[0]["seeds"], "optimizer": 1}})
    _run(p + [d], tmp_path)
    _run([b1], tmp_path)
    run = lambda man, pre: subprocess.run([sys.executable, CTT, str(tmp_path), str(tmp_path / pre), "--manifest",
                                           str(man), "--strict"], capture_output=True, text=True)
    man = _manifest(tmp_path / "m.jsonl", [p[0], b1, d])
    assert run(man, "ok").returncode == 0
    shutil.rmtree(tmp_path / "runs" / run_id(b1))                     # promised, then missing: a failure
    r = run(man, "gone")
    cov = read_json(tmp_path / "gone_coverage.json")
    assert r.returncode != 0 and cov["n_failed"] == 1 and cov["n_excluded"] == 0
    man2 = _manifest(tmp_path / "m2.jsonl", [p[0], d])                 # never promised: an exclusion
    r = run(man2, "none")
    cov = read_json(tmp_path / "none_coverage.json")
    assert cov["n_failed"] == 0 and cov["n_excluded"] == 1
