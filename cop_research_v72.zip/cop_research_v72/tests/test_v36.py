"""v36: the loss-matched disturbance control, the declared outcomes of a matched perturbation, and how the result
check and the strict analyses list them (exclusions with their reason, never silent, never a pass for anything
else).  The launcher's handling is in test_v36_launcher.py."""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "audit_v5/tools"))
from cop.config import resolve, run_id  # noqa: E402
from cop.utils import read_json  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


def _run(cfgs, d):
    from test_v15 import _run as r
    return r(cfgs, d)


def test_loss_matching_reaches_a_target_the_error_cannot(tmp_path):
    from cop.experiments.context import ScientificInvalid
    from cop.experiments.continuation import _perturb_matched
    from cop.train import metrics as M
    from cop.train.trainer import evaluate
    from test_v34 import _Ctx, _perturb_setup
    cfg, m, bundle = _perturb_setup(tmp_path)
    p0 = [p.detach().clone() for p in m.parameters()]
    r, _ = evaluate(m, bundle, ["val"], cfg["train"]["eval_batch"])
    risk0 = float(M.headline(r["val"], bundle.task))
    # an error target above any reachable error (1.5) next to a risk target three times the unperturbed risk
    fws = {"intact": {"val": {"err": 0.0, "risk": risk0}}, "joint_deletion": {"val": {"err": 1.5, "risk": 3 * risk0}}}
    cc = {"budget_parent": "treated", "perturb_match": "parent_frozen_deletion", "perturb_estimand": "absolute",
          "perturb_match_tol": 0.005}
    ctx = _Ctx(fws)
    with pytest.raises(ScientificInvalid):
        _perturb_matched(ctx, cfg, {**cc, "perturb_match_metric": "val_err"}, m, bundle)
    assert ctx.saved["perturb_match.json"]["failure"].startswith("the target is not reached by scale 64")
    assert all(torch.equal(a, b) for a, b in zip(m.parameters(), p0))
    ctx = _Ctx(fws)
    rec = _perturb_matched(ctx, cfg, {**cc, "perturb_match_metric": "val_risk"}, m, bundle)
    assert rec["metric"] == "val_risk" and rec["target_val_risk"] == pytest.approx(3 * risk0)
    assert abs(rec["achieved_value"] - rec["target_value"]) <= rec["tolerance"] == 0.005
    assert set(rec["achieved"]) == {"val_err", "val_risk"}            # both are recorded at the chosen scale


def _fake_invalid(d: Path, failure: str, perturb: bool = True):
    d.mkdir(parents=True, exist_ok=True)
    (d / "status.json").write_text(json.dumps({"status": "invalid", "reason": "x"}))
    (d / "config.json").write_text(json.dumps({"kind": "continue", "continue": {
        "perturb_match": "parent_frozen_deletion" if perturb else "none"}}))
    (d / "perturb_match.json").write_text(json.dumps({"failure": failure, "metric": "val_err"}))


def test_declared_outcomes_are_only_the_matched_perturbations_own(tmp_path):
    from declared import declared_invalid
    _fake_invalid(tmp_path / "a", "the target is not reached by scale 64 (unreachable)")
    _fake_invalid(tmp_path / "b", "the export changed the function")
    _fake_invalid(tmp_path / "c", "the target is not reached by scale 64 (unreachable)", perturb=False)
    assert declared_invalid(tmp_path / "a") and "unreachable" in declared_invalid(tmp_path / "a")
    assert declared_invalid(tmp_path / "b") is None and declared_invalid(tmp_path / "c") is None
    (tmp_path / "a" / "status.json").write_text(json.dumps({"status": "failed"}))
    assert declared_invalid(tmp_path / "a") is None                   # only an invalid status can be declared


def test_declared_outcomes_script(tmp_path):
    res = tmp_path / "res"
    _fake_invalid(res / "runs" / "j1", "the achieved value is not within tolerance of the target")
    (res / "runs" / "j2").mkdir(parents=True)
    (res / "runs" / "j2" / "status.json").write_text(json.dumps({"status": "complete"}))
    man = tmp_path / "m.jsonl"
    man.write_text('{"run_id": "j1"}\n{"run_id": "j2"}\n')
    tool = [sys.executable, str(ROOT / "scripts/declared_outcomes.py"), str(man), str(res), str(tmp_path / "o.json")]
    assert subprocess.run(tool, capture_output=True).returncode == 0
    assert len(read_json(tmp_path / "o.json")["declared_outcomes"]) == 1
    man.write_text('{"run_id": "j1"}\n{"run_id": "j2"}\n{"run_id": "j3"}\n')   # j3 never ran
    assert subprocess.run(tool, capture_output=True).returncode == 1
    assert read_json(tmp_path / "o.json")["problems"][0]["status"] == "missing"


def test_strict_analyses_and_result_check_list_a_declared_control_as_excluded(tmp_path):
    from test_v31 import _setup, _tool, _manifest
    p, d, k, _ = _setup(tmp_path)
    dist = resolve({"kind": "continue", "data": p[0]["data"], "model": p[0]["model"], "train": p[0]["train"],
                    "seeds": p[0]["seeds"], "parents": {"baseline": run_id(p[0]), "treated": run_id(d)},
                    "continue": {"start": "baseline", "start_stage": "baseline", "budget": "fixed",
                                 "segments": [4, 4], "segment_reset": [False, True],
                                 "perturb_match": "parent_frozen_deletion", "perturb_segment": 1},
                    "design": {"family": "X25", "variant": "compact", "arm": "C1_disturbed", "contrast": "X25|c"}})
    from cop.orchestration.runner import run_job
    run_job(dist, tmp_path, {"device": "cpu"})
    rd = tmp_path / "runs" / run_id(dist)
    # force the declared outcome (whatever the tiny job did): invalid, with the matched perturbation's own reason
    (rd / "status.json").write_text(json.dumps({"status": "invalid", "reason": "perturb_match: unreachable"}))
    pm = read_json(rd / "perturb_match.json") if (rd / "perturb_match.json").exists() else {}
    pm["failure"] = "the target is not reached by scale 64 (unreachable)"
    (rd / "perturb_match.json").write_text(json.dumps(pm))
    c1 = next(json.loads(l)["cfg"] for l in open(tmp_path / "m.jsonl") if json.loads(l)["cfg"]["kind"] == "continue")
    man = _manifest(tmp_path, [d, k, c1, dist])
    r = _tool(tmp_path, man, "x")
    assert r.returncode == 0, r.stdout + r.stderr
    cov = read_json(tmp_path / "x_coverage.json")
    assert cov["passed"] and [e["run_id"] for e in cov["excluded"]] == [run_id(dist)]
    assert "declared outcome" in cov["excluded"][0]["reason"]
    chk = subprocess.run([sys.executable, str(ROOT / "audit_v8/tools/check_results.py"), str(tmp_path),
                          str(tmp_path / "chk.json"), "--manifest", str(man)], capture_output=True, text=True)
    rep = read_json(tmp_path / "chk.json")
    assert chk.returncode == 0, rep
    # any other reason is a failure
    pm["failure"] = "something else"
    (rd / "perturb_match.json").write_text(json.dumps(pm))
    r = _tool(tmp_path, man, "y")
    assert r.returncode != 0 and not read_json(tmp_path / "y_coverage.json")["passed"]
    chk = subprocess.run([sys.executable, str(ROOT / "audit_v8/tools/check_results.py"), str(tmp_path),
                          str(tmp_path / "chk2.json"), "--manifest", str(man)], capture_output=True, text=True)
    assert chk.returncode != 0
