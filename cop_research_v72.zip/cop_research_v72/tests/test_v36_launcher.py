"""v20 (review item 10) ... v34: the panel launcher (scripts/36) fails when any stage fails, packaging and report
export included, never reuses an earlier archive, and does not start the panel after a failed prerequisite unless
DIAGNOSTIC_OVERRIDE=1.  v34: each analysis (reversal, cross, age) has its own exit-code / no-output / coverage
controls; an analysis that fails still leaves a diagnostic archive; one that claims success without its tables or
a passing coverage report fails the evidence step (and the launcher); a file left by an earlier run never counts.

The real script runs in a mock COP_HOME: `cop` is a shell function, the tests and audit tools are stubs whose
exit codes are injected, and the real packager (scripts/package_reports.py) writes and verifies the archive.
No training runs."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import zipfile
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]

COMMON = r'''set -euo pipefail
export COP_HOME="$MOCK_HOME"
export COP_DATA_ROOT="$MOCK_HOME"
export WORKERS=1 THREADS=1 DEVICE=cpu
cd "$COP_HOME"
mkdir -p "$COP_RESULTS" "$COP_HOME/manifests"
cop() {
  echo "cop $*" >> "$MOCK_HOME/events.txt"
  case "$1" in
    generate-manifest) [ "${MOCK_MANIFEST_RC:-0}" = 0 ] && echo '{"run_id": "job0"}' > "$7"; return "${MOCK_MANIFEST_RC:-0}" ;;
    validate-manifest) return "${MOCK_VALIDATE_RC:-0}" ;;
    inspect-environment) return "${MOCK_ENV_RC:-0}" ;;
    run)
      if [ -n "${MOCK_RUN_DECLARED:-}" ]; then        # v36: the runner leaves one invalid job and exits 1
        d="$5/runs/job0"; mkdir -p "$d"
        echo '{"status": "invalid"}' > "$d/status.json"
        echo '{"kind": "continue", "continue": {"perturb_match": "parent_frozen_deletion"}}' > "$d/config.json"
        echo "{\"failure\": \"$MOCK_RUN_DECLARED\", \"metric\": \"val_err\"}" > "$d/perturb_match.json"
        return 1
      fi
      return "${MOCK_RUN_RC:-0}" ;;
    status) return "${MOCK_STATUS_RC:-0}" ;;
    summarize) [ "$2" = "--strict" ] || return 9; mkdir -p "$8"; echo x > "$8/s.csv"; return "${MOCK_SUM_RC:-0}" ;;
    *) return 0 ;;
  esac
}
'''

TOOL = """import json, os, sys
var = {var!r}
out = sys.argv[{arg}] if len(sys.argv) > {arg} else None
rc = int(os.environ.get(var, "0"))
if out and rc == 0:
    json.dump({{"ok": True}}, open(out, "w"))
sys.exit(rc)
"""
ANALYSIS = r"""import json, os, sys
prefix = sys.argv[2]
tag = {tag!r}
rc = int(os.environ.get(f"MOCK_{{tag}}_RC", "0"))
assert "--manifest" in sys.argv and "--strict" in sys.argv and "--grid" not in sys.argv
if tag == "AGE":
    assert "--maps-dir" in sys.argv
if os.environ.get(f"MOCK_{{tag}}_NOFILES", "0") != "1":
    passed = rc == 0 and os.environ.get(f"MOCK_{{tag}}_COVFAIL", "0") != "1"
    json.dump({{"expected": 1, "analysed": 1, "n_failed": 0, "passed": passed}}, open(prefix + "_coverage.json", "w"))
    for t in ("codes_summary", "codes_by_draw", "contrasts", "checks", "decomposition_summary", "trace", "rows",
              "by_draw", "summary"):
        open(prefix + "_" + t + ".csv", "w").write("cell,code\nc,0-1\n")
sys.exit(rc)
"""
TOOLS = {"REVERSAL": ("selective_reversal.py", "reversal21", "layer_transplant21"),
         "CROSS": ("cross_transplant.py", "cross21", "cross_transplant21"),
         "AGE": ("portability_age.py", "age21", "portability_age21")}
PYTEST = """#!/usr/bin/env bash
echo "3 passed"
exit "${MOCK_TEST_RC:-0}"
"""


def _home(tmp: Path) -> dict:
    home = tmp / "home"
    (home / "scripts").mkdir(parents=True)
    shutil.copy2(ROOT / "scripts/36_v36_panel.sh", home / "scripts/36_v36_panel.sh")
    shutil.copy2(ROOT / "scripts/package_reports.py", home / "scripts/package_reports.py")
    shutil.copy2(ROOT / "scripts/check_evidence.py", home / "scripts/check_evidence.py")
    shutil.copy2(ROOT / "scripts/declared_outcomes.py", home / "scripts/declared_outcomes.py")
    (home / "audit_v5/tools").mkdir(parents=True, exist_ok=True)
    shutil.copy2(ROOT / "audit_v5/tools/declared.py", home / "audit_v5/tools/declared.py")
    (home / "scripts/common.sh").write_text(COMMON)
    for rel, var, arg in (("audit_v8/tools/check_results.py", "MOCK_CHECK_RC", 2),
                          ("audit_v5/tools/fresh_reload.py", "MOCK_RELOAD_RC", 2),
                          ("audit_v5/tools/runtime_v13.py", "MOCK_RATES_RC", 4),
                          ("audit_v5/tools/fetch_data.py", "MOCK_DATA_RC", 99),
                          ):
        p = home / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(TOOL.format(var=var, arg=arg))
    # v31 / v34: each analysis mock writes real-shaped outputs (coverage report and tables) unless told not to,
    # under its own controls MOCK_<TAG>_RC / _NOFILES / _COVFAIL
    for tag, (tool, _, _) in TOOLS.items():
        (home / "audit_v5/tools" / tool).write_text(ANALYSIS.format(tag=tag))
    pt = home / "fake_pytest.sh"
    pt.write_text(PYTEST)
    pt.chmod(0o755)
    res = tmp / "results"
    zipdir = tmp / "zips"
    zipdir.mkdir()
    base = {k: v for k, v in os.environ.items() if k not in ("DIAGNOSTIC_OVERRIDE", "COP_PYTEST")}
    env = dict(base, MOCK_HOME=str(home), COP_RESULTS=str(res), ZIP_DIR=str(zipdir), SCALE="full",
               HOME=str(tmp), COP_PYTEST=str(pt))
    return {"home": home, "res": res, "zip": zipdir / "cop_v36_panel_reports.zip", "env": env}


def _sh(h, **env):
    e = dict(h["env"], **{k: str(v) for k, v in env.items()})
    return subprocess.run(["bash", str(h["home"] / "scripts/36_v36_panel.sh")], env=e,
                          capture_output=True, text=True, cwd=h["home"])


def _verdict(h):
    return json.loads((h["res"] / "v36_reports/verdict.json").read_text())


def _events(h):
    p = h["home"] / "events.txt"
    return p.read_text() if p.exists() else ""


@pytest.fixture
def h(tmp_path):
    return _home(tmp_path)


def test_success_exits_zero_and_the_archive_carries_the_final_verdict(h):
    r = _sh(h)
    assert r.returncode == 0, r.stdout + r.stderr
    v = _verdict(h)
    assert v["all_passed"] and not v["pending"]
    assert {"environment", "cpu_tests", "cuda_skips", "manifest21", "validate21", "run21", "status21", "checks21",
            "reload21", "summary21", "rates21", "reversal21", "cross21", "age21", "evidence21", "manifest_copy",
            "package", "package_final"} <= set(v["steps"])
    with zipfile.ZipFile(h["zip"]) as z:
        assert z.testzip() is None
        av = json.loads(z.read("cop_v36_panel_reports/verdict.json"))
        names = z.namelist()
    assert av["steps"]["package"] == 0 and av["pending"] == ["package_final"] and av["completed_steps_passed"]
    assert "cop_v36_panel_reports/v36_reports/checks21.json" in names
    assert "cop_v36_panel_reports/panel21/summary/s.csv" in names
    for _, (_, _, prefix) in TOOLS.items():
        assert f"cop_v36_panel_reports/v36_reports/{prefix}_coverage.json" in names
    assert "cop_v36_panel_reports/v36_reports/evidence21.json" in names


@pytest.mark.parametrize("tag", list(TOOLS))
def test_an_analysis_claiming_success_without_outputs_fails_evidence_but_is_archived(h, tag):
    _, stage, prefix = TOOLS[tag]
    r = _sh(h, **{f"MOCK_{tag}_NOFILES": 1})
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"][stage] == 0 and v["steps"]["evidence21"] != 0 and not v["all_passed"]
    assert v["steps"]["package"] == 0 and h["zip"].exists()           # a diagnostic archive is still written
    ev = json.loads((h["res"] / "v36_reports/evidence21.json").read_text())
    assert ev["steps"][stage]["ok"] is False
    assert all(ev["steps"][s_]["ok"] for t_, (_, s_, _) in TOOLS.items() if t_ != tag)


@pytest.mark.parametrize("tag", list(TOOLS))
def test_an_analysis_crash_without_outputs_fails_and_is_archived(h, tag):
    _, stage, _ = TOOLS[tag]
    r = _sh(h, **{f"MOCK_{tag}_NOFILES": 1, f"MOCK_{tag}_RC": 3})
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"][stage] == 3 and v["steps"]["evidence21"] == 0 and not v["all_passed"]
    assert v["steps"]["package"] == 0 and h["zip"].exists()
    others = [s_ for t_, (_, s_, _) in TOOLS.items() if t_ != tag]
    assert all(v["steps"][s_] == 0 for s_ in others)                  # the controls are independent


@pytest.mark.parametrize("tag", list(TOOLS))
def test_an_analysis_with_failed_coverage_fails(h, tag):
    _, stage, _ = TOOLS[tag]
    r = _sh(h, **{f"MOCK_{tag}_COVFAIL": 1})                           # exit 0 but coverage not passed
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"][stage] == 0 and v["steps"]["evidence21"] != 0 and h["zip"].exists()
    r = _sh(h, **{f"MOCK_{tag}_COVFAIL": 1, f"MOCK_{tag}_RC": 1})      # and the honest version
    v = _verdict(h)
    assert r.returncode != 0 and v["steps"][stage] == 1 and h["zip"].exists()


@pytest.mark.parametrize("tag", list(TOOLS))
def test_files_from_an_earlier_run_never_satisfy_the_evidence(h, tag):
    _, stage, prefix = TOOLS[tag]
    assert _sh(h).returncode == 0
    assert (h["res"] / "v36_reports" / f"{prefix}_coverage.json").exists()
    r = _sh(h, **{f"MOCK_{tag}_NOFILES": 1})                           # a second run that writes nothing
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"]["evidence21"] != 0
    assert not (h["res"] / "v36_reports" / f"{prefix}_coverage.json").exists()


@pytest.mark.parametrize("var,stage", [("MOCK_RUN_RC", "run21"), ("MOCK_CHECK_RC", "checks21"),
                                       ("MOCK_REVERSAL_RC", "reversal21"), ("MOCK_CROSS_RC", "cross21"),
                                       ("MOCK_AGE_RC", "age21"),
                                       ("MOCK_RELOAD_RC", "reload21"), ("MOCK_SUM_RC", "summary21"),
                                       ("MOCK_STATUS_RC", "status21"), ("MOCK_RATES_RC", "rates21")])
def test_a_failed_stage_fails_the_launcher_and_diagnostics_are_still_packaged(h, var, stage):
    r = _sh(h, **{var: 7})
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"][stage] == 7 and not v["all_passed"]
    assert v["steps"]["package"] == 0 and h["zip"].exists()            # the reports can still be read


def test_a_report_export_failure_fails_the_launcher(h):
    r = _sh(h, MOCK_MANIFEST_RC=1)                                     # no manifest: its copy into the reports fails
    assert r.returncode != 0 and _verdict(h)["steps"]["manifest_copy"] != 0


@pytest.mark.parametrize("var,stage", [("MOCK_TEST_RC", "cpu_tests"), ("MOCK_VALIDATE_RC", "validate21"),
                                       ("MOCK_MANIFEST_RC", "manifest21"), ("MOCK_ENV_RC", "environment")])
def test_a_failed_prerequisite_skips_the_panel_unless_overridden(h, var, stage):
    r = _sh(h, **{var: 3})
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"][stage] == 3 and v["steps"]["run21"] == 99 and "cop run" not in _events(h)
    r = _sh(h, **{var: 3}, DIAGNOSTIC_OVERRIDE=1)
    assert r.returncode != 0 and "cop run" in _events(h) and _verdict(h)["steps"]["run21"] == 0


def test_a_packaging_failure_fails_the_launcher_and_an_old_archive_is_not_evidence(h):
    r = _sh(h)
    assert r.returncode == 0 and h["zip"].exists()
    shutil.copy2(h["zip"], h["zip"].with_name("old.zip"))
    # the packager fails
    stub = h["home"] / "scripts/package_reports.py"
    stub.write_text("import sys\nsys.exit(37)\n")
    r = _sh(h)
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"]["package"] == 37 and v["steps"]["package_final"] == 99 and not v["all_passed"]
    assert not h["zip"].exists()                                       # the earlier archive was removed


def test_the_zip_path_being_a_directory_fails_packaging(h):
    h["zip"].mkdir()
    r = _sh(h)
    assert r.returncode != 0 and _verdict(h)["steps"]["package"] != 0


def test_packager_verifies_required_members_and_replaces_a_stale_archive(tmp_path):
    import sys
    res = tmp_path / "res"
    (res / "rep").mkdir(parents=True)
    (res / "rep" / "a.txt").write_text("a")
    vf = tmp_path / "v.json"
    vf.write_text(json.dumps({"steps": {"x": 0}}))
    out = tmp_path / "o.zip"
    out.write_text("stale, not a zip")
    run = lambda *extra: subprocess.run([sys.executable, str(ROOT / "scripts/package_reports.py"), str(res), str(out),
                                         str(vf), "P", "--include", "rep", *extra], capture_output=True, text=True)
    r = run("--require", "rep/missing.txt")
    assert r.returncode == 2 and not out.exists()
    r = run("--require", "rep/a.txt")
    assert r.returncode == 0
    with zipfile.ZipFile(out) as z:
        assert set(z.namelist()) == {"P/rep/a.txt", "P/verdict.json"}


def test_a_declared_invalid_job_passes_the_panel_step_and_is_reported(h):
    r = _sh(h, MOCK_RUN_DECLARED="the target is not reached by scale 64 (unreachable)")
    assert r.returncode == 0, r.stdout + r.stderr
    v = _verdict(h)
    assert v["steps"]["run21"] == 0 and v["all_passed"]
    rep = json.loads((h["res"] / "v36_reports/declared21.json").read_text())
    assert rep["passed"] and len(rep["declared_outcomes"]) == 1 and not rep["problems"]
    with zipfile.ZipFile(h["zip"]) as z:
        assert "cop_v36_panel_reports/v36_reports/declared21.json" in z.namelist()


def test_an_undeclared_invalid_job_fails_the_panel_step(h):
    r = _sh(h, MOCK_RUN_DECLARED="something else went wrong")
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"]["run21"] == 1 and not v["all_passed"]
    rep = json.loads((h["res"] / "v36_reports/declared21.json").read_text())
    assert not rep["passed"] and rep["problems"][0]["run_id"] == "job0"


def test_packager_archives_a_large_required_member_and_lists_skipped_large_files(tmp_path):
    import sys
    res = tmp_path / "res"
    (res / "rep").mkdir(parents=True)
    big = "x" * int(9e6)
    (res / "rep" / "big_required.csv").write_text(big)
    (res / "rep" / "big_other.csv").write_text(big)
    vf = tmp_path / "v.json"
    vf.write_text(json.dumps({"steps": {"x": 0}}))
    out = tmp_path / "o.zip"
    r = subprocess.run([sys.executable, str(ROOT / "scripts/package_reports.py"), str(res), str(out), str(vf), "P",
                        "--include", "rep", "--require", "rep/big_required.csv"], capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    with zipfile.ZipFile(out) as z:
        names = set(z.namelist())
        assert "P/rep/big_required.csv" in names and "P/rep/big_other.csv" not in names
        assert json.loads(z.read("P/skipped_large_files.json"))[0]["file"] == "rep/big_other.csv"
