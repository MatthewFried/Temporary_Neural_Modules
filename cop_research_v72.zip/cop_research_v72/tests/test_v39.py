"""v39: the keep fork with retained gradient masks and with the parent's optimizer state; the cross of the causal
and shortcut first-layer changes between the trajectory's end and the endpoint; the rescaling controls; wave 22."""
from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "audit_v5/tools"))
from cop.config import ConfigError, resolve, run_id  # noqa: E402
from cop.utils import read_json  # noqa: E402


def _run(cfgs, d):
    from test_v15 import _run as r
    return r(cfgs, d)


def _keep(traj_cfg, **over):
    from test_v31 import _diss, _x25
    return _x25(_diss(traj_cfg, method="keep", post_updates=6, save_path_checkpoints=True, early_eval=[1, 2], **over),
                arm="keep")


def _state(rd: Path, ck: str):
    return torch.load(rd / "ckpt" / f"{ck}.pt", weights_only=False)["model"]["state"]


def test_keep_fork_masks_and_optimizer_carry(tmp_path):
    import selective_reversal as SR
    from test_v31 import _traj
    p = _traj()
    cfgs = {(m, o): _keep(p[-1], removal_masks=m, optimizer_policy=o)
            for m in ("released", "retained") for o in ("reset_each_phase", "carry_from_parent")}
    _run(p, tmp_path)
    res = {}
    for k, c in cfgs.items():
        _run([c], tmp_path)
        rd = tmp_path / "runs" / run_id(c)
        j = read_json(rd / "dissipation_result.json")
        res[k] = (rd, j)
        ph = j["schedule_audit"]["phases"]
        assert [x["phase"] for x in ph] == ["keep_0"]
        assert ph[0]["grad_masks"] == k[0]                                          # the masks reach the phase
        assert ph[0]["optimizer"] == ("carried from the parent" if k[1] == "carry_from_parent" else
                                      "fresh at phase start")
        assert j["removal_policy"]["masks"] == k[0] and j["removal_policy"]["optimizer"] == k[1]
        ev = [(e["event"], e.get("checkpoint"), e.get("phase")) for e in j["schedule_audit"]["events"]]
        assert ev == SR.expected_schedule(c)[1]                                    # the config-derived ledger
        if k[1] == "carry_from_parent":
            car = [e for e in j["schedule_audit"]["events"] if e["event"] == "optimizer_carried"][0]
            from cop.graph.graph import GraphNet
            g = GraphNet.from_checkpoint(torch.load(tmp_path / "runs" / run_id(p[-1]) / "ckpt" / "final.pt",
                                                    weights_only=False)["model"])
            assert car["tensors"] == sum(1 for q in g.parameters())                # every tensor carried
    ends = {k: _state(rd, "path_u6") for k, (rd, _) in res.items()}
    differ = lambda a, b: any(not torch.equal(a[n], b[n]) for n in a)
    assert differ(ends[("released", "reset_each_phase")], ends[("retained", "reset_each_phase")])   # masks matter
    assert differ(ends[("released", "reset_each_phase")], ends[("released", "carry_from_parent")])  # Adam state too
    assert differ(ends[("retained", "carry_from_parent")], ends[("retained", "reset_each_phase")])


def test_keep_fork_carry_resumes_identically(tmp_path):
    from resume_harness import compare_interrupted
    from test_v31 import _traj
    p = _traj()
    rep = compare_interrupted(p + [_keep(p[-1], removal_masks="retained", optimizer_policy="carry_from_parent")],
                              tmp_path, fractions=(0.85, 0.95))
    assert rep["interrupted_at_polls"] and rep["equal"], rep


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA device required")
def test_cuda_keep_fork_carry_with_masks_runs_and_resumes(tmp_path):
    """the carried AdamW state on the GPU (its 'step' stays on the CPU, as torch.optim places it), with retained
    masks: the job completes and an interrupted run equals an uninterrupted one."""
    from resume_harness import compare_interrupted
    from test_v31 import _traj
    p = _traj()
    k = _keep(p[-1], removal_masks="retained", optimizer_policy="carry_from_parent")
    rep = compare_interrupted(p + [k], tmp_path, fractions=(0.85, 0.95), ex={"device": "cuda"})
    assert rep["interrupted_at_polls"] and rep["equal"], rep


def test_keep_fork_config_rules():
    from test_v31 import _traj
    p = _traj()
    with pytest.raises(ConfigError):
        _keep(p[-1], optimizer_policy="carry_from_parent", split_updates=3)
    with pytest.raises(ConfigError):
        _keep(p[-1], optimizer_policy="carry_from_parent", rebuild={"backbone": "f0", "implants": "fresh"})
    from test_v31 import _diss
    with pytest.raises(ConfigError):
        _diss(p[-1], method="linear", speed_updates=3, post_updates=3, optimizer_policy="carry_from_parent")
    with pytest.raises(ConfigError):
        _diss(p[-1], method="abrupt", post_updates=3, removal_masks="retained")
    with pytest.raises(ConfigError):
        _diss(p[-1], method="keep", post_updates=3, gate_schedule="hold")
    _keep(p[-1], removal_masks="retained")                                          # allowed since v39


def test_cross_and_scale_controls(tmp_path):
    from test_v31 import _setup, _tool
    p, d, k, man = _setup(tmp_path)
    r = _tool(tmp_path, man, "x", "--decompose", "--cross", "--scale-controls")
    assert r.returncode == 0, r.stdout + r.stderr
    rows = list(csv.DictReader(open(tmp_path / "x_cross.csv")))
    dec = list(csv.DictReader(open(tmp_path / "x_decomposition.csv")))
    # v41: the decomposition's arithmetic, so the crossings that are decomposition subsets reproduce them exactly
    # (the predictions are compared bitwise inside the tool; every metric is then identical)
    for rid, endpoint in ((run_id(d), "repaired"), (run_id(k), "kept_end")):
        rr = [x for x in rows if x["run_id"] == rid and x["state"] == endpoint]
        assert len(rr) == 8 and len({x["combination"] for x in rr}) == 8
        dd = {x["update_groups"]: x for x in dec if x["run_id"] == rid and x["state"] == endpoint}
        aa = next(x for x in rr if x["combination"] == "causal@after+shortcut@after+noise_bias@after")
        assert aa["decomposition_identity"] == "bitwise"
        assert aa["test_err"] == dd["shortcut+causal+noise+bias"]["test_err"]
        aa0 = next(x for x in rr if x["combination"] == "causal@after+shortcut@after+noise_bias@f0")
        assert aa0["decomposition_identity"] == "bitwise" and aa0["test_err"] == dd["shortcut+causal"]["test_err"]
    # 'before' is the trajectory's end: for the full removal it is the 'abrupt' state of the decomposition
    rr = [x for x in rows if x["run_id"] == run_id(d)]
    bb = next(x for x in rr if x["combination"] == "causal@before+shortcut@before+noise_bias@f0")
    ab = {x["update_groups"]: x for x in dec if x["run_id"] == run_id(d) and x["state"] == "abrupt"}
    assert bb["decomposition_identity"] in ("bitwise", "within 1e-5, same decisions")
    assert bb["test_err"] == ab["shortcut+causal"]["test_err"]
    con = list(csv.DictReader(open(tmp_path / "x_cross_contrasts.csv")))
    assert {c["contrast"] for c in con} >= {"interaction", "shortcut_after_vs_before | causal before"}
    sc = list(csv.DictReader(open(tmp_path / "x_scale.csv")))
    ctrls = {x["control"] for x in sc}
    assert ctrls == {"causal_transplant", "f0_causal_global_norm_matched", "f0_causal_row_norm_matched",
                     "transplant_directions_f0_row_norms", "f0_causal_scale_selected",
                     "f0_causal_shortcut_scale_selected", "f0_causal_row_ls_fit", "f0_causal_activation_fit",
                     "f0_causal_row_ls_fit_nonneg", "f0_causal_activation_fit_nonneg",
                     "f0_causal_plus_residual", "f0_causal_dir_at_norm_of_plus_residual",
                     "f0_causal_plus_residual_at_f0_norm"}
    for x in sc:
        if x["control"] == "causal_transplant":
            dd = {y["update_groups"]: y for y in dec if y["run_id"] == x["run_id"] and y["state"] == x["state"]}
            assert x["test_err"] == dd["causal"]["test_err"]
        if x["control"].endswith("_selected"):
            assert x["selected_on"] == "val_indep" and float(x["alpha_causal"]) > 0
    assert (tmp_path / "x_cross_summary.csv").exists() and (tmp_path / "x_scale_summary.csv").exists()


def test_wave22_structure():
    from cop.orchestration.manifest import generate
    m = generate([22], "full")
    ents = [e["cfg"] for e in m.entries.values()]
    assert len(ents) == 144
    assert {e["wave"] for e in m.entries.values()} == {c["wave"] for c in ents} == {22}     # v41: was 21
    draws = {c["data"]["data_seed"] for c in ents if c.get("data")}
    assert draws == set(range(307, 313))
    w21 = {c["data"]["data_seed"] for c in (e["cfg"] for e in generate([21], "full").entries.values()) if c.get("data")}
    assert not draws & w21
    keep = [c for c in ents if c["kind"] == "dissipation" and c["dissipation"]["method"] == "keep"]
    cells = {(c["design"]["variant"], c["dissipation"]["removal_masks"], c["dissipation"]["optimizer_policy"])
             for c in keep}
    assert cells == {("fixed", m, o) for m in ("retained", "released") for o in ("carry_from_parent", "reset_each_phase")} \
        | {("redrawn", "released", o) for o in ("carry_from_parent", "reset_each_phase")}
    trajs = {c["parents"]["trajectory"] for c in keep}
    assert len(trajs) == 24                                 # each from its own trajectory's identical end state
