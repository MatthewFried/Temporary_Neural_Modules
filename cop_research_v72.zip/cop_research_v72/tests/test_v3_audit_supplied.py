"""Acceptance gates supplied with the v3 independent audit (test_independent_regressions.py),
kept verbatim except two documented adapters:
  1. SRC defaults to this repository when COP_SOURCE_ROOT is unset;
  2. the pruning gate passes the optimizer to the pruner (pr(trn) with trn.opt): v4 enforces
     pruning through the job's own trainer (moment reset at pruning and regrowth, and a post-step
     mask), so the pruner needs to see the optimizer whose moments could reactivate the rows.
     The tested invariant (pruned rows stay zero through a zero-gradient optimizer step with
     inherited Adam moments, before evaluation / checkpointing) is unchanged.
CUDA tests are skipped without a CUDA device; skipped is not validated (scripts/12 runs them).
"""
import os, sys
from pathlib import Path
from types import SimpleNamespace
import pytest
import torch
SRC=Path(os.environ.get('COP_SOURCE_ROOT') or Path(__file__).resolve().parents[1]).resolve()
sys.path[:0]=[str(SRC),str(SRC/'tests')]
torch.set_num_threads(1)
from cop.analysis.strengthening import compact_gain, endpoint_table
from cop.analysis.summarize import load_runs
from cop.graph.builders import build_mlp
from cop.graph.accounting import architecture_hash
from cop.config import resolve, run_id, TRAIN_DEFAULTS
from cop.utils import torch_gen, read_json
from cop.data.registry import load_bundle
from cop.train.trainer import Trainer, Segment
from cop.orchestration.runner import run_job
import tiny_configs as T

def rows():
    base=dict(kind='dissipation',status='complete',validity='valid',compact=True,
              replication='data0_teacher0_opt0',design_contrast='audit',design_budget_panel='updates')
    return [dict(base,run_id='t',test_risk=.2,design_arm='treated'),
            dict(base,run_id='c',test_risk=.5,design_arm='C1')]

def test_noncompact_cannot_enter_fixed_architecture_gain():
    a=rows();a[0]['compact']=False
    try: _,pairs=compact_gain(a)
    except ValueError: return
    assert not pairs, 'noncompact endpoint accepted as fixed-architecture compact gain'

def test_duplicate_pairs_must_be_rejected():
    a=rows();a.append(dict(a[1],run_id='second_c',test_risk=2.))
    with pytest.raises(ValueError): compact_gain(a)

def test_parameter_sharing_changes_architecture_identity():
    g=build_mlp(8,[8,8,8],3,torch_gen(0,'init'));h=g.clone(share_params=False)
    hidden=[n for n in h.topo_order() if h.nodes[n].op=='linear' and n!=h.output]
    old=h.nodes[hidden[1]].pkey;h.nodes[hidden[1]].pkey=h.nodes[hidden[0]].pkey
    del h.mods[old];h._plan=None
    assert architecture_hash(g)!=architecture_hash(h)

def test_final_step_nonfinite_parameters_mark_divergence():
    bundle=load_bundle(T.DATA);g=build_mlp(8,[4],3,torch_gen(0,'init'))
    tc=dict(TRAIN_DEFAULTS,batch_size=32,optimizer='sgd',lr=1e38,grad_clip=0.)
    tr=Trainer(g,bundle,tc,{'minibatch':0,'augmentation':0},'cpu');tr.configure('none',None)
    tr.run(Segment('overflow',1,target='custom',target_fn=lambda out,batch,X:out.sum()*1e10))
    assert all(bool(torch.isfinite(p).all()) for p in g.parameters()) or tr.state['diverged']

def test_diverged_repair_not_reported_as_successful_endpoint(tmp_path):
    cfgs=T.traj({'topology':'layered','rounds':1,'updates_per_round':5})
    c=T.child('repair',cfgs[-1],{'repair':{'region':'full','deletion':'all','budget_multiplier':4.,
                                        'eval_points':2,'extension_factor':1.}})
    c=resolve({**c,'train':{**c['train'],'optimizer':'sgd','lr':1e38,'grad_clip':0.},
               'design':{'family':'audit','variant':'divergence','arm':'treated','contrast':'audit_divergence'}})
    for cfg in cfgs+[c]: run_job(cfg,tmp_path,{'device':'cpu'})
    r=read_json(tmp_path/'runs'/run_id(c)/'repair_result.json')
    assert r['diverged'], 'the adversarial setup must actually cause divergence'
    e=endpoint_table(load_runs(tmp_path));mine=next(x for x in e if x['run_id']==run_id(c))
    assert not compact_gain([mine])[1], 'stale pre-repair metrics entered gain table for a diverged run'

CUDA=pytest.mark.skipif(not torch.cuda.is_available(),reason='CUDA device required; CPU suite cannot validate this path')

def test_pruned_channels_stay_zero_for_evaluation_with_optimizer_momentum():
    from cop.experiments.continuation import _PruneRegrow
    g=build_mlp(8,[8,8],3,torch_gen(0,'init'))
    opt=torch.optim.AdamW(g.parameters(),lr=.01,weight_decay=0.)
    for p in g.parameters():p.grad=torch.ones_like(p)
    opt.step();opt.zero_grad(set_to_none=True)
    pr=_PruneRegrow(g,.25,4,2,0);pr(SimpleNamespace(model=g,opt=opt),0)   # adapter 2
    for p in g.parameters():p.grad=torch.zeros_like(p)
    opt.step();g.eval()
    assert all(torch.count_nonzero(g.mods[g.nodes[n].pkey].weight[idx])==0 for n,idx in pr.masks.items()), \
        'pruned weights reactivate before evaluation/checkpointing; pruning needs a persistent mask'

@CUDA
def test_cuda_affine_alignment():
    from cop.cop_pegs.transplant import fit_affine_alignment
    x=torch.randn(40,4,device='cuda');y=x@torch.randn(4,4,device='cuda')+1
    m,info=fit_affine_alignment(x,y)
    assert torch.allclose(m.cuda()(x),y,atol=1e-4,rtol=1e-4)

@CUDA
def test_cuda_symbol_alignment():
    from cop.cop_pegs.transplant import fit_symbol_alignment
    x=torch.tensor([[0.],[1.],[0.],[1.]],device='cuda');y=1-x
    m,_=fit_symbol_alignment(x,y)
    assert torch.equal(m.cuda()(x),y)

@CUDA
def test_cuda_prune_regrow():
    from cop.experiments.continuation import _PruneRegrow
    g=build_mlp(8,[8,8],3,torch_gen(0,'init')).cuda()
    p=_PruneRegrow(g,.25,4,1,0);tr=SimpleNamespace(model=g)
    p(tr,0);p(tr,1)
    assert p.events[-1]['event']=='regrow'

@CUDA
def test_cuda_later_query_mixed_seen_unseen_codes(monkeypatch):
    from cop.cop_pegs import chain
    from cop.graph.ops import Quantizer
    bundle=load_bundle({'name':'later_query','n_train':32,'n_val':16,'n_test':16,
                        'params':{'n_bits':8,'pool_size':256}}).to('cuda')
    q=Quantizer(1,mode='uniform',bits=1).cuda()
    g=SimpleNamespace(layout='vec',implants={'P':SimpleNamespace(meta={'peg':{'quant':'q','enc':'enc'}})},
                      nodes={'q':SimpleNamespace(pkey='pk')},mods={'pk':q},structural_hash=lambda:'audit')
    def vals(g,part,nodes,batch):
        z=torch.full((len(part),1),-1.,device='cuda')
        if part is not bundle.train:z[len(part)//2:]=1
        return {n:z for n in nodes}
    monkeypatch.setattr(chain,'_node_values',vals)
    ctx=SimpleNamespace(cfg={'train':{'eval_batch':64}},metric=lambda *a,**kw:None)
    result=chain.later_queries(ctx,g,bundle,['P'])
    assert result['pegs']['P']['test_unseen_message_frac']==.5
