"""v41 (the v40 review): the wave-22 label; the carried optimizer state against torch's own load_state_dict and a
one-step reference (and a wrong mapping that must fail); gradient routing of the retained masks by the parent's
split (a reversed split must fail) and the route flags; the four keep forks' audit (same start, stream, updates and
lr; the parent's named optimizer state or none; the parent's split); the component trace, the continuation
factorial, the exact identities of the cross and rescaling rows with the decomposition (also with rotated inputs);
the per-job inventories (a dropped row fails the job); cross exclusions; the preflight; the evidence sentinel."""
from __future__ import annotations

import csv
import json
import os
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest
import torch
import torch.nn.functional as F

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "audit_v5/tools"))
from cop.config import resolve, run_id  # noqa: E402
from cop.utils import read_json, tensor_hash  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
TOOL = str(ROOT / "audit_v5/tools/selective_reversal.py")
SETTINGS = [("released", "reset_each_phase", "keep"), ("released", "carry_from_parent", "keep_released_carry"),
            ("retained", "reset_each_phase", "keep_masks_reset"), ("retained", "carry_from_parent", "keep_masks_carry")]


def _run(cfgs, d):
    from test_v15 import _run as r
    return r(cfgs, d)


def _rows(path):
    return list(csv.DictReader(open(path)))


# ----------------------------------------------------------------------------- wave label

def test_wave22_entries_and_configs_are_labelled_22():
    from cop.orchestration.manifest import generate
    m = generate([22], "full")
    assert len(m.entries) == 144
    assert {e["wave"] for e in m.entries.values()} == {22}
    assert {e["cfg"]["wave"] for e in m.entries.values()} == {22}
    assert {e["cfg"]["wave"] for e in generate([21], "full").entries.values()} == {21}


# ----------------------------------------------------------------------------- the carried optimizer state

def _adam_case(seed=0):
    torch.manual_seed(seed)
    P = [torch.nn.Parameter(torch.randn(4, 4)), torch.nn.Parameter(torch.randn(4)),
         torch.nn.Parameter(torch.randn(4, 4)), torch.nn.Parameter(torch.randn(4))]
    names = ["a.weight", "a.bias", "b.weight", "b.bias"]
    hp = dict(lr=1e-2, betas=(0.9, 0.99), eps=1e-8, weight_decay=0.01)
    opt = torch.optim.AdamW(P, **hp)
    for _ in range(3):
        for p in P:
            p.grad = torch.randn_like(p)
        opt.step()
    return P, names, hp, opt.state_dict()


def _fresh(P, hp):
    Q = [torch.nn.Parameter(p.detach().clone()) for p in P]
    return Q, torch.optim.AdamW(Q, **hp)


def _step(params, opt, grads):
    for p, g in zip(params, grads):
        p.grad = g.clone()
    opt.step()


def test_carried_state_equals_torchs_own_load_and_a_one_step_reference():
    from cop.experiments.dissipation import opt_state_digest, parent_opt_digest
    from cop.experiments.repair import _carry_parent_opt
    P, names, hp, sd = _adam_case()
    ck = {"trainer": {"opt_param_names": names, "opt": sd}}
    ctx = SimpleNamespace(parent_ckpt=lambda role, stage: ck)
    Q, oq = _fresh(P, hp)
    assert opt_state_digest(oq, names)["tensors_with_state"] == 0           # a reset optimizer holds no moments
    assert _carry_parent_opt(ctx, "final", SimpleNamespace(opt=oq, opt_param_names=names)) == 4
    R, orf = _fresh(P, hp)
    orf.load_state_dict(sd)                                                 # torch's own restoration
    for q, r in zip(Q, R):
        a, b = oq.state[q], orf.state[r]
        assert set(a) == set(b) == {"step", "exp_avg", "exp_avg_sq"}
        for k in a:
            assert a[k].dtype == b[k].dtype and a[k].device == b[k].device and torch.equal(a[k], b[k])
    assert opt_state_digest(oq, names)["digest"] == parent_opt_digest(ck, names)["digest"]
    assert opt_state_digest(oq, names)["step_min"] == opt_state_digest(oq, names)["step_max"] == 3.0
    g = [torch.randn_like(p) for p in P]
    _step(Q, oq, g)
    _step(R, orf, g)
    assert all(torch.equal(q, r) for q, r in zip(Q, R))                     # one update equals the reference
    assert all(torch.equal(oq.state[q][k], orf.state[r][k]) for q, r in zip(Q, R) for k in oq.state[q])
    # a wrong mapping (the two same-shaped layers' names swapped) carries every tensor but is not the reference
    W, ow = _fresh(P, hp)
    swapped = ["b.weight", "b.bias", "a.weight", "a.bias"]
    assert _carry_parent_opt(ctx, "final", SimpleNamespace(opt=ow, opt_param_names=swapped)) == 4
    R2, or2 = _fresh(P, hp)
    or2.load_state_dict(sd)
    _step(W, ow, g)
    _step(R2, or2, g)
    assert not all(torch.equal(w, r) for w, r in zip(W, R2))


# ----------------------------------------------------------------------------- gradient routing

def _branch_params(g):
    out = {}
    for iid, imp in g.implants.items():
        key = ((imp.meta or {}).get("specialization") or {}).get("mask_key")
        if key and imp.nodes:
            pk = {g.nodes[n].pkey for n in imp.nodes if g.nodes[n].pkey is not None}
            out.setdefault(key, []).extend(p for k in sorted(pk) for p in g.mods[k].parameters())
    return out


def _grads(g, X, y, ctx, weights=None):
    g.zero_grad(set_to_none=True)
    out = g(X, ctx)
    li = F.cross_entropy(out, y, reduction="none")
    (li.mean() if weights is None else (li * weights).sum() / len(y)).backward()
    return {k: [p.grad.detach().clone() if p.grad is not None else torch.zeros_like(p) for p in ps]
            for k, ps in _branch_params(g).items()}


def test_retained_masks_route_each_branchs_gradient_by_the_parents_split(tmp_path):
    from cop.data.registry import load_bundle
    from cop.experiments.dissipation import retained_mask_ctx
    from cop.graph.graph import GraphNet
    from test_v31 import _traj
    p = _traj()
    _run(p, tmp_path)
    td = tmp_path / "runs" / run_id(p[-1])
    g = GraphNet.from_checkpoint(torch.load(td / "ckpt" / "final.pt", weights_only=False)["model"], "cpu").eval()
    assert set(_branch_params(g)) == {"spec_a", "spec_b"}
    b = load_bundle(p[-1]["data"], device="cpu")
    mem = torch.load(td / "spec_partition.pt", weights_only=False).bool()
    gc = p[-1]["growth"]
    fn = retained_mask_ctx(b, mem, gc)
    batch = b.train.index(torch.arange(min(64, len(b.train))))
    ctx = fn(batch)
    a = mem[:len(batch)]
    assert torch.equal(ctx["grad_masks"]["spec_a"].bool(), a) and torch.equal(ctx["grad_masks"]["spec_b"].bool(), ~a)
    assert 0 < int(a.sum()) < len(a) and "mask_forward" not in ctx and "mask_param_only" not in ctx
    got = _grads(g, batch.X, batch.y, ctx)
    # reference: no masks, each branch's gradient from its own examples' losses only
    ref_a = _grads(g, batch.X, batch.y, {}, weights=a.float())["spec_a"]
    ref_b = _grads(g, batch.X, batch.y, {}, weights=(~a).float())["spec_b"]
    close = lambda u, v: all(torch.allclose(x, y_, rtol=1e-5, atol=1e-7) for x, y_ in zip(u, v))
    assert any(float(x.abs().max()) > 0 for x in ref_a) and any(float(x.abs().max()) > 0 for x in ref_b)
    assert close(got["spec_a"], ref_a) and close(got["spec_b"], ref_b)
    # the reversed split routes the other way and must not match
    rev = retained_mask_ctx(b, ~mem, gc)(b.train.index(torch.arange(len(batch))))
    bad = _grads(g, batch.X, batch.y, rev)
    assert not close(bad["spec_a"], ref_a) and not close(bad["spec_b"], ref_b)
    # the parent's mask route is kept
    assert retained_mask_ctx(b, mem, {**gc, "spec_mask_route": "forward"})(batch).get("mask_forward") is True
    assert retained_mask_ctx(b, mem, {**gc, "spec_mask_route": "parameter"})(batch).get("mask_param_only") is True


# ----------------------------------------------------------------------------- the four forks and the analysis

def _forks(tmp_path, data=None, extra_forks=()):
    from test_v31 import _diss, _lin, _traj, _x25
    p = _traj(data=data)
    d = _x25(_lin(p[-1]))
    forks = {}
    for m, o, arm in SETTINGS:
        forks[(m, o)] = _x25(_diss(p[-1], method="keep", post_updates=6, save_path_checkpoints=True,
                                   early_eval=[1, 2], removal_masks=m, optimizer_policy=o), arm=arm)
    c1 = resolve({"kind": "continue", "data": p[0]["data"], "model": p[0]["model"], "train": p[0]["train"],
                  "seeds": p[0]["seeds"], "parents": {"baseline": run_id(p[0]), "treated": run_id(d)},
                  "continue": {"start": "baseline", "start_stage": "baseline", "budget": "parent_updates"},
                  "design": {"family": "X25", "variant": "compact", "arm": "C1", "contrast": "X25|c"}})
    _run(p + [d], tmp_path)
    for c in list(forks.values()) + list(extra_forks) + [c1]:
        _run([c], tmp_path)
    from test_v31 import _manifest
    return p, d, forks, c1, _manifest(tmp_path, [d, *forks.values(), *extra_forks, c1])


def _tool(tmp_path, man, prefix, *extra, env=None):
    return subprocess.run([sys.executable, TOOL, str(tmp_path), str(tmp_path / prefix), "--manifest", str(man),
                           "--strict", "--device", "cpu", *extra], capture_output=True, text=True,
                          env=dict(os.environ, **(env or {})))


ALL = ("--trace", "--decompose", "--cross", "--scale-controls", "--displacement")


def test_four_forks_audit_factorial_trace_and_exact_identities(tmp_path):
    import selective_reversal as SR
    from cop.experiments.dissipation import parent_opt_digest
    p, d, forks, c1, man = _forks(tmp_path)
    r = _tool(tmp_path, man, "a", *ALL)
    assert r.returncode == 0, r.stdout + r.stderr
    cov = read_json(tmp_path / "a_coverage.json")
    assert cov["passed"] and not cov["fork_equality_failures"] and not cov["factorial_partners_missing"]
    assert cov["factorial_design"] == {"fixed": sorted([m, o] for m, o, _ in SETTINGS)}
    # ---- the fork audit: one parent, one start state, one stream; the parent's named optimizer state or none
    td = tmp_path / "runs" / run_id(p[-1])
    pck = torch.load(td / "ckpt" / "final.pt", weights_only=False)
    want = parent_opt_digest(pck, list(pck["trainer"]["opt_param_names"]))
    fa = {(x["fork_masks"], x["fork_optimizer"]): x for x in _rows(tmp_path / "a_fork_audit.csv")}
    assert set(fa) == set(forks)
    for f in ("parent_state_hash", "batch_id_hash_end", "batches_drawn_end", "updates", "lr"):
        assert len({x[f] for x in fa.values()}) == 1 and fa[("released", "reset_each_phase")][f]
    for (m, o), x in fa.items():
        if o == "carry_from_parent":
            assert x["opt_start_digest"] == want["digest"] and int(x["opt_start_tensors_with_state"]) > 0
        else:
            assert int(x["opt_start_tensors_with_state"]) == 0
        if m == "retained":
            mem = torch.load(td / "spec_partition.pt", weights_only=False).bool()
            assert x["membership_hash"] == tensor_hash(mem.cpu())
            ph = read_json(tmp_path / "runs" / run_id(forks[(m, o)]) / "dissipation_result.json")
            el = ph["schedule_audit"]["phases"][0]["eligibility"]
            assert el["a_matches_split"] is True and el["b_is_complement"] is True and el["examples_seen"] > 0
        else:
            assert not x["membership_hash"]
    # ---- the factorial: every effect, every measure, at the endpoint and along the traced updates
    fb = _rows(tmp_path / "a_continuation_factorial_by_setting.csv")
    effects = {"reset_vs_carry | masks released", "reset_vs_carry | masks retained",
               "release_vs_retain | optimizer reset", "release_vs_retain | optimizer carried", "interaction"}
    assert {x["effect"] for x in fb} == effects
    assert {x["measure"] for x in fb} == {"native", "branch_deleted", "first_layer", "causal", "shortcut",
                                          "shortcut+causal"}
    assert {x["update"] for x in fb if x["measure"] == "causal"} == {"endpoint", "13", "14", "18"}
    nat = {(x["fork_masks"], x["fork_optimizer"]): float(x["test_err"]) for x in _rows(tmp_path / "a_native.csv")
           if x["removal_variant"].startswith("keep")}
    e = lambda m, o: nat[(m, o)]
    got = {x["effect"]: float(x["test_err_difference"]) for x in fb if x["measure"] == "native"}
    rvc = lambda m: e(m, "carry_from_parent") - e(m, "reset_each_phase")
    assert got["reset_vs_carry | masks released"] == pytest.approx(rvc("released"), abs=1e-12)
    assert got["release_vs_retain | optimizer reset"] == pytest.approx(
        e("retained", "reset_each_phase") - e("released", "reset_each_phase"), abs=1e-12)
    assert got["interaction"] == pytest.approx(rvc("released") - rvc("retained"), abs=1e-12)
    assert _rows(tmp_path / "a_continuation_factorial_summary.csv")
    # v42: every fork's displacement from the shared parent state, from its first update on
    dsp = _rows(tmp_path / "a_displacement.csv")
    for c in forks.values():
        own = {x["checkpoint"]: x for x in dsp if x["run_id"] == run_id(c)}
        assert {"removal_u1", "removal_u2", "removal_u6", "endpoint"} <= set(own)
        assert float(own["removal_u1"]["net_backbone_l2"]) > 0 and own["removal_u1"]["updates_since_reference"] == "1"
    # ---- the component trace: five subsets per traced checkpoint; 'none' is f0
    dt = _rows(tmp_path / "a_decomposition_trace.csv")
    ck = {(x["run_id"], x["checkpoint"]) for x in dt}
    assert len(dt) == 5 * len(ck) and {x["update_groups"] for x in dt} == {
        "none", "causal", "shortcut", "shortcut+causal", "shortcut+causal+noise+bias"}
    assert all(x["test_err"] == x["f0_test_err"] for x in dt if x["update_groups"] == "none")
    assert any(x["checkpoint"] == "traj_final" for x in dt) and any(x["checkpoint"] == "removal_u3" for x in dt)
    assert any(x["checkpoint"] == "removal_u6" and x["run_id"] == run_id(forks[("released", "reset_each_phase")])
               for x in dt)
    # ---- exact identities: the cross and the rescaling rows against the decomposition
    dec = {(x["run_id"], x["state"], x["update_groups"]): x for x in _rows(tmp_path / "a_decomposition.csv")}
    cross = _rows(tmp_path / "a_cross.csv")
    assert len(cross) == 8 * 5                                          # 5 removal endpoints
    for x in cross:
        ref = {"causal@after+shortcut@after+noise_bias@f0": "shortcut+causal",
               "causal@after+shortcut@after+noise_bias@after": "shortcut+causal+noise+bias"}.get(x["combination"])
        if ref:
            assert x["decomposition_identity"] == "bitwise"
            assert x["test_err"] == dec[(x["run_id"], x["state"], ref)]["test_err"]
        if x["combination"] == "causal@before+shortcut@before+noise_bias@f0" and x["run_id"] == run_id(d):
            assert x["decomposition_identity"] in ("bitwise", "within 1e-5, same decisions")
            assert x["test_err"] == dec[(run_id(d), "abrupt", "shortcut+causal")]["test_err"]
    sc = _rows(tmp_path / "a_scale.csv")
    assert len(sc) == SR.N_SCALE_CONTROLS * (3 + 4 + 1)                 # every state of every job (v45: 13)
    for x in sc:
        if x["control"] == "causal_transplant":
            assert x["test_err"] == dec[(x["run_id"], x["state"], "causal")]["test_err"]
        if x["control"].endswith("_selected"):
            assert x["selected_on"] in ("val_indep", "val") and x["alpha_causal_at_grid_edge"] in ("True", "False")
    con = _rows(tmp_path / "a_scale_contrasts.csv")
    assert {x["control"] for x in con} == {"f0_causal_global_norm_matched", "f0_causal_row_norm_matched",
                                           "transplant_directions_f0_row_norms", "f0_causal_scale_selected",
                                           "f0_causal_shortcut_scale_selected", "f0_causal_row_ls_fit",
                                           "f0_causal_activation_fit", "f0_causal_row_ls_fit_nonneg",
                                           "f0_causal_activation_fit_nonneg", "f0_causal_plus_residual",
                                           "f0_causal_dir_at_norm_of_plus_residual", "f0_causal_plus_residual_at_f0_norm"}
    assert "scale_grid_edge_hits" in cov and "scale_zero_norm_rows" in cov
    dcon = _rows(tmp_path / "a_decomposition_contrasts.csv")
    assert dcon and not any(x["partner_missing"] == "True" for x in dcon if x["contrast"].startswith("vs C1"))
    assert _rows(tmp_path / "a_cross_contrasts_by_draw.csv")
    inv = cov["inventory"]
    assert inv["decomposition"] == 16 * 8 and inv["scale"] == SR.N_SCALE_CONTROLS * 8 \
        and inv["cross"] == 40 and inv["native"] == 6
    # ---- a fork whose stream differs from its siblings' fails the audit
    rd = tmp_path / "runs" / run_id(forks[("retained", "carry_from_parent")])
    j0 = (rd / "dissipation_result.json").read_text()
    j = json.loads(j0)
    j["schedule_audit"]["phases"][0]["batch_id_hash_end"] = "tampered"
    (rd / "dissipation_result.json").write_text(json.dumps(j))
    r = _tool(tmp_path, man, "b", "--decompose")
    cov = read_json(tmp_path / "b_coverage.json")
    assert r.returncode != 0 and not cov["passed"]
    assert [x["field"] for x in cov["fork_equality_failures"]] == ["batch_id_hash_end"]
    (rd / "dissipation_result.json").write_text(j0)


def test_factorial_flags_missing_and_duplicate_partners():
    import selective_reversal as SR
    base = {"source": "removal", "cell": "c", "variant": "fixed", "parent": "t", "data_draw": 1, "optimizer_seed": 0,
            "partition_seed": None, "draw_set": "x", "state": "kept_end", "measure": "native_endpoint"}
    rows = [{**base, "removal_variant": rv, "fork_masks": m, "fork_optimizer": o, "test_err": 0.1 * i}
            for i, (rv, (m, o)) in enumerate(SR.KEEP_FORKS.items())]
    design = {"fixed": set(SR.KEEP_FORKS.values())}
    bs, _, sm, miss, dup = SR.continuation_factorial({"native": rows}, design)
    assert not miss and not dup and len(bs) == 5
    e = {(r["fork_masks"], r["fork_optimizer"]): r["test_err"] for r in rows}
    inter = next(x for x in bs if x["effect"] == "interaction")["test_err_difference"]
    assert inter == pytest.approx((e[("released", "carry_from_parent")] - e[("released", "reset_each_phase")]) -
                                  (e[("retained", "carry_from_parent")] - e[("retained", "reset_each_phase")]))
    bs, _, _, miss, _ = SR.continuation_factorial({"native": rows[:3]}, design)
    assert miss and miss[0]["missing_settings"] and not any(x["effect"] == "interaction" for x in bs)
    _, _, _, _, dup = SR.continuation_factorial({"native": rows + rows[:1]}, design)
    assert dup


@pytest.mark.parametrize("table", ["decomposition", "decomposition_trace", "cross", "scale", "native", "codes"])
def test_a_dropped_row_fails_the_job(tmp_path, table):
    from test_v31 import _setup
    p, d, k, man = _setup(tmp_path)
    r = _tool(tmp_path, man, "x", *ALL, env={"COP_TEST_DROP": table})
    cov = read_json(tmp_path / "x_coverage.json")
    assert r.returncode != 0 and not cov["passed"]
    failed = {f["run_id"] for f in cov["failed"]}
    assert failed >= {run_id(d), run_id(k)}                            # every job that has rows of the table
    assert all(f["reason"].startswith(f"inventory: {table} has") for f in cov["failed"])
    part = _rows(tmp_path / "x_diagnostic_partial.csv")
    assert {x["run_id"] for x in part} >= failed and all(x["failure"].startswith("inventory") for x in part)
    codes = (tmp_path / "x_codes.csv").read_text()
    assert run_id(d) not in codes and run_id(k) not in codes          # nothing of a failed job is committed


def test_a_start_other_than_the_trajectory_end_is_an_explicit_cross_exclusion(tmp_path):
    from test_v31 import _diss, _manifest, _traj, _x25
    p = _traj()
    k2 = _x25(resolve({**_diss(p[-1], method="keep", post_updates=4), "tags": {"parent_stage": "post_insert_r2"}}),
              arm="keep_early")
    _run(p + [k2], tmp_path)
    man = _manifest(tmp_path, [k2])
    r = _tool(tmp_path, man, "e", "--decompose", "--cross")
    cov = read_json(tmp_path / "e_coverage.json")
    assert cov["n_failed"] == 0 and cov["analysed"] == 1, cov["failed"]
    assert cov["cross_excluded"] == [{"run_id": run_id(k2), "reason": "the job starts from the trajectory's "
                                                                     "post_insert_r2, not its final checkpoint"}]
    assert (tmp_path / "e_cross.csv").read_text().strip() == "empty"
    assert r.returncode == (0 if cov["passed"] else 1)


def test_rotated_inputs_cross_and_scale_identities(tmp_path):
    from test_v19 import SH
    from test_v31 import _setup
    _, d, _, man = _setup(tmp_path, data={**SH, "params": {**SH["params"], "input_rotation": 1}})
    r = _tool(tmp_path, man, "r", "--decompose", "--cross", "--scale-controls", "--codes", "0-0-0-0-0,0-1-1-1-1")
    assert r.returncode == 0, r.stdout + r.stderr
    dec = {(x["run_id"], x["state"], x["update_groups"]): x["test_err"] for x in _rows(tmp_path / "r_decomposition.csv")}
    for x in _rows(tmp_path / "r_scale.csv"):
        if x["control"] == "causal_transplant":
            assert x["test_err"] == dec[(x["run_id"], x["state"], "causal")]
    assert all(x["decomposition_identity"] in ("", "bitwise", "within 1e-5, same decisions")
               for x in _rows(tmp_path / "r_cross.csv"))


def test_preflight_checks_without_evaluating(tmp_path):
    from test_v31 import _setup
    p, d, k, man = _setup(tmp_path)
    r = _tool(tmp_path, man, "pf", "--trace", "--decompose", "--preflight")
    assert r.returncode == 0, r.stdout + r.stderr
    assert read_json(tmp_path / "pf_coverage.json")["passed"]
    assert not (tmp_path / "pf_codes.csv").exists()                     # nothing evaluated, no tables
    victim = tmp_path / "runs" / run_id(d) / "ckpt" / "path_u6.pt"      # the repair phase's last path checkpoint
    assert victim.exists()
    victim.unlink()
    r = _tool(tmp_path, man, "pf2", "--trace", "--decompose", "--preflight")
    cov = read_json(tmp_path / "pf2_coverage.json")
    assert r.returncode != 0 and not cov["passed"] and "path_u6" in cov["failed"][0]["reason"]


def test_the_evidence_check_treats_an_empty_table_as_missing(tmp_path):
    pre = tmp_path / "x"
    (tmp_path / "x_coverage.json").write_text(json.dumps({"passed": True}))
    (tmp_path / "x_a.csv").write_text("cell\nc\n")
    (tmp_path / "x_b.csv").write_text("empty\n")
    tool = [sys.executable, str(ROOT / "scripts/check_evidence.py"), str(tmp_path / "ev.json")]
    assert subprocess.run(tool + [f"s:0:{pre}:a.csv"], capture_output=True).returncode == 0
    r = subprocess.run(tool + [f"s:0:{pre}:a.csv,b.csv"], capture_output=True)
    assert r.returncode == 1
    assert read_json(tmp_path / "ev.json")["steps"]["s"]["missing"] == ["x_b.csv (an empty table)"]
