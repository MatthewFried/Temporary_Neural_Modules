"""v42: train.freeze_inputs=shortcut (the first layer's shortcut column held at its start values: exact, also through
momentum, across segments, in children that keep it, under resume; config rules); the analysis' lineage check of
the frozen column; the displacement table; the fitted rescalings, their agreement with the causal transplant and
the extended grid; the generalized C1 and variant-pair contrasts; wave 23."""
from __future__ import annotations

import csv
import json
import os
import subprocess
import sys
from pathlib import Path

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "audit_v5/tools"))
from cop.config import ConfigError, resolve, run_id  # noqa: E402
from cop.utils import read_json  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
TOOL = str(ROOT / "audit_v5/tools/selective_reversal.py")
FZ = {"freeze_inputs": "shortcut"}


def _run(cfgs, d):
    from test_v15 import _run as r
    return r(cfgs, d)


def _rows(path):
    return list(csv.DictReader(open(path)))


def _frozen_traj():
    from test_v31 import _traj
    p = _traj()
    t = resolve({**p[-1], "train": {**p[-1]["train"], **FZ}})
    return p[0], t


def _w1(rd: Path, ck: str):
    from cop.graph.graph import GraphNet
    import selective_reversal as SR
    m = torch.load(rd / "ckpt" / f"{ck}.pt", weights_only=False)["model"]
    g = GraphNet.from_checkpoint(m)
    return m["state"][f"mods.{SR.backbone_layers(g)[0]}.weight"]


def _sc(p0) -> int:
    from cop.data.registry import load_bundle
    return int(load_bundle(p0["data"], device="cpu").meta["feature_layout"]["shortcut"])


def _c1(p0, treated, variant="compact", train=None):
    return resolve({"kind": "continue", "data": p0["data"], "model": p0["model"], "train": train or p0["train"],
                    "seeds": p0["seeds"], "parents": {"baseline": run_id(p0), "treated": run_id(treated)},
                    "continue": {"start": "baseline", "start_stage": "baseline", "budget": "parent_updates"},
                    "design": {"family": "X25", "variant": variant, "arm": "C1", "contrast": "X25|c"}})


# ----------------------------------------------------------------------------- the freeze in training

def test_the_frozen_column_stays_exactly_at_f0_and_nothing_else_does(tmp_path):
    from test_v31 import _diss, _lin, _x25
    p0, t = _frozen_traj()
    _run([p0, t], tmp_path)
    td = tmp_path / "runs" / run_id(t)
    sc = _sc(p0)
    W0, W1 = _w1(td, "baseline_ref"), _w1(td, "final")
    assert torch.equal(W1[:, sc], W0[:, sc])                                 # exact at the trajectory's end
    others = [j for j in range(W0.shape[1]) if j != sc]
    assert not torch.equal(W1[:, others], W0[:, others])                     # the rest of the layer trains
    for ck in ("post_insert_r2",):
        assert torch.equal(_w1(td, ck)[:, sc], W0[:, sc])                    # across the round boundary too
    rec = torch.load(td / "ckpt" / "final.pt", weights_only=False)["trainer"]["state"]["input_freeze_record"]
    assert rec and all(r["columns"] == [sc] for r in rec)
    # children: the freeze kept (still exact) and lifted (moves)
    kept = _x25(_lin(t), arm="treated_frozen", variant="fixed_scfrozen")
    lifted = _x25(resolve({**_lin(t), "train": {**t["train"], "freeze_inputs": "none"}}), variant="fixed_scfrozen")
    keep = _x25(resolve({**_diss(t, method="keep", post_updates=6, save_path_checkpoints=True, early_eval=[1, 2]),
                         "train": {**t["train"], "freeze_inputs": "none"}}), arm="keep", variant="fixed_scfrozen")
    for c in (kept, lifted, keep):
        _run([c], tmp_path)
    end = lambda c: read_json(tmp_path / "runs" / run_id(c) / "endpoint.json")["checkpoint"]
    assert torch.equal(_w1(tmp_path / "runs" / run_id(kept), end(kept))[:, sc], W0[:, sc])
    assert not torch.equal(_w1(tmp_path / "runs" / run_id(lifted), end(lifted))[:, sc], W0[:, sc])
    assert not torch.equal(_w1(tmp_path / "runs" / run_id(keep), end(keep))[:, sc], W0[:, sc])


def test_a_frozen_compact_continuation_with_carried_momentum_stays_exact(tmp_path):
    """C1 from f0 carries nothing that could move the column: no gradient, and the restore after every update."""
    from test_v31 import _lin, _traj, _x25
    p = _traj()
    d = _x25(_lin(p[-1]))
    c = _c1(p[0], d, "compact_scfrozen", {**p[0]["train"], **FZ})
    _run(p + [d, c], tmp_path)
    sc = _sc(p[0])
    rd = tmp_path / "runs" / run_id(c)
    W0 = _w1(tmp_path / "runs" / run_id(p[0]), "baseline")
    W1 = _w1(rd, read_json(rd / "endpoint.json")["checkpoint"])
    assert torch.equal(W1[:, sc], W0[:, sc]) and not torch.equal(W1, W0)


def test_a_frozen_trajectory_resumes_identically(tmp_path):
    from resume_harness import compare_interrupted
    p0, t = _frozen_traj()
    rep = compare_interrupted([p0, t], tmp_path, fractions=(0.4, 0.8))
    assert rep["interrupted_at_polls"] and rep["equal"], rep


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA device required")
def test_cuda_frozen_trajectory_is_exact_and_resumes(tmp_path):
    """the GPU path (the column index and the held values on the device): exact at the end, and an interrupted run
    equals an uninterrupted one."""
    from resume_harness import compare_interrupted
    from cop.orchestration.runner import run_job
    p0, t = _frozen_traj()
    for c in (p0, t):
        run_job(c, tmp_path / "a", {"device": "cuda"})
    td = tmp_path / "a" / "runs" / run_id(t)
    sc = _sc(p0)
    assert torch.equal(_w1(td, "final")[:, sc], _w1(td, "baseline_ref")[:, sc])
    rep = compare_interrupted([p0, t], tmp_path / "b", fractions=(0.4, 0.8), ex={"device": "cuda"})
    assert rep["interrupted_at_polls"] and rep["equal"], rep


def test_freeze_config_rules():
    from test_v19 import SH
    from test_v31 import _traj
    p = _traj()
    with pytest.raises(ConfigError):                                         # not for f0 itself
        resolve({**p[0], "train": {**p[0]["train"], **FZ}})
    rot = _traj(data={**SH, "params": {**SH["params"], "input_rotation": 1}})
    with pytest.raises(ConfigError):                                         # rotated inputs: not one column
        resolve({**rot[-1], "train": {**rot[-1]["train"], **FZ}})
    with pytest.raises(ConfigError):
        resolve({**p[-1], "train": {**p[-1]["train"], **FZ, "freeze": "original_frozen"}})
    with pytest.raises(ConfigError):
        resolve({**p[-1], "train": {**p[-1]["train"], "freeze_inputs": "causal"}})


# ----------------------------------------------------------------------------- the analysis

def _tool(tmp_path, man, prefix, *extra, env=None):
    return subprocess.run([sys.executable, TOOL, str(tmp_path), str(tmp_path / prefix), "--manifest", str(man),
                           "--strict", "--device", "cpu", *extra], capture_output=True, text=True,
                          env=dict(os.environ, **(env or {})))


def _panel(tmp_path):
    """a miniature wave 23: the unfrozen and the frozen fixed trajectory, their removals and keep forks, C1 in both
    variants and C1_phase."""
    from test_v31 import _diss, _lin, _manifest, _traj, _x25
    p = _traj()
    t = resolve({**p[-1], "train": {**p[-1]["train"], **FZ}})
    lift = {**p[-1]["train"], "freeze_inputs": "none"}
    kp = dict(method="keep", post_updates=6, save_path_checkpoints=True, early_eval=[1, 2])
    d_u = _x25(_lin(p[-1]))
    k_u = _x25(_diss(p[-1], **kp), arm="keep")
    d_l = _x25(resolve({**_lin(t), "train": lift}), variant="fixed_scfrozen")
    d_k = _x25(_lin(t), arm="treated_frozen", variant="fixed_scfrozen")
    k_l = _x25(resolve({**_diss(t, **kp), "train": lift}), arm="keep", variant="fixed_scfrozen")
    c1 = _c1(p[0], d_u)
    c1f = _c1(p[0], d_u, "compact_scfrozen", {**p[0]["train"], **FZ})
    c1p = resolve({**_c1(p[0], d_u), "continue": {"start": "baseline", "start_stage": "baseline", "budget": "fixed",
                                                  "segments": [6, 6, 3, 3],
                                                  "segment_reset": [False, False, True, True]},
                   "design": {"family": "X25", "variant": "compact", "arm": "C1_phase", "contrast": "X25|c"}})
    jobs = [d_u, k_u, d_l, d_k, k_l, c1, c1f, c1p]
    _run(p + [t], tmp_path)
    for c in jobs:
        _run([c], tmp_path)
    return p, t, dict(d_u=d_u, k_u=k_u, d_l=d_l, d_k=d_k, k_l=k_l, c1=c1, c1f=c1f, c1p=c1p), \
        _manifest(tmp_path, jobs)


def test_wave23_analysis_end_to_end(tmp_path):
    p, t, J, man = _panel(tmp_path)
    r = _tool(tmp_path, man, "a", "--trace", "--decompose", "--cross", "--scale-controls", "--displacement")
    assert r.returncode == 0, r.stdout + r.stderr
    cov = read_json(tmp_path / "a_coverage.json")
    assert cov["passed"] and cov["analysed"] == 8 and cov["decomposition_contrast_partners_missing"] == 0
    # ---- the frozen lineage: the shortcut column change is exactly zero, everywhere it must be
    dec = _rows(tmp_path / "a_decomposition.csv")
    frozen = {run_id(J["d_k"]), run_id(J["c1f"])}
    for x in dec:
        if x["run_id"] in frozen or (x["run_id"] in {run_id(J["d_l"]), run_id(J["k_l"])} and x["state"] == "abrupt"):
            assert float(x["shortcut_column_change_max_abs"]) == 0.0, x
    assert any(float(x["shortcut_column_change_max_abs"]) > 0 for x in dec if x["run_id"] == run_id(J["d_l"])
               and x["state"] == "repaired")
    # the frozen trajectory's own trace rows (shortcut-only subset = f0 exactly)
    dt = _rows(tmp_path / "a_decomposition_trace.csv")
    tr_f = [x for x in dt if x["run_id"] == run_id(t)]
    assert tr_f and all(float(x["shortcut_column_change_max_abs"]) == 0.0 for x in tr_f)
    assert all(x["test_err"] == x["f0_test_err"] for x in tr_f if x["update_groups"] == "shortcut")
    # ---- displacement: every own trace checkpoint and the endpoint
    dsp = _rows(tmp_path / "a_displacement.csv")
    assert {x["run_id"] for x in dsp} == {run_id(c) for c in J.values()}
    assert all(any(x["checkpoint"] == "endpoint" for x in dsp if x["run_id"] == run_id(c)) for c in J.values())
    k1 = next(x for x in dsp if x["run_id"] == run_id(J["k_u"]) and x["checkpoint"] == "removal_u1")
    assert k1["updates_since_reference"] == "1" and float(k1["net_backbone_l2"]) > 0
    assert float(k1["net_additions_l2"]) > 0 and k1["additions_status"] == "measured"
    # recompute one row by hand: the keep fork's endpoint against the trajectory end
    import selective_reversal as SR
    from cop.graph.graph import GraphNet
    rd = tmp_path / "runs" / run_id(J["k_u"])
    s1 = torch.load(rd / "ckpt" / f"{read_json(rd / 'endpoint.json')['checkpoint']}.pt", weights_only=False)["model"]
    s0 = torch.load(tmp_path / "runs" / run_id(p[-1]) / "ckpt" / "final.pt", weights_only=False)["model"]
    L = SR.backbone_layers(GraphNet.from_checkpoint(s0))
    ks = [k for k in s0["state"] if k.startswith("mods.") and k.split(".")[1] in L]
    want = sum(float(((s1["state"][k].double() - s0["state"][k].double()) ** 2).sum()) for k in ks) ** 0.5
    got = next(float(x["net_backbone_l2"]) for x in dsp if x["run_id"] == run_id(J["k_u"]) and x["checkpoint"] == "endpoint")
    assert got == pytest.approx(want, rel=1e-12)
    fr = [x for x in dsp if x["run_id"] == run_id(J["d_k"])]
    assert all(float(x["net_first_layer_shortcut_l2"]) == 0.0 for x in fr)    # the frozen column never moves
    assert _rows(tmp_path / "a_displacement_summary.csv")
    # ---- the fitted rescalings, the agreement columns and the extended grid
    sc = _rows(tmp_path / "a_scale.csv")
    assert {x["control"] for x in sc} >= {"f0_causal_row_ls_fit", "f0_causal_activation_fit"}
    assert len(sc) == SR.N_SCALE_CONTROLS * sum(1 for x in _rows(tmp_path / "a_checks.csv"))
    for x in sc:
        if x["control"] == "causal_transplant":
            assert float(x["decision_disagreement_vs_transplant"]) == 0.0 and float(x["tv_vs_transplant"]) == 0.0
        assert 0.0 <= float(x["decision_disagreement_vs_transplant"]) <= 1.0
    sel = [x for x in sc if x["control"] == "f0_causal_scale_selected"]
    assert sel and all(x["grid"].split()[-1] == "16.0" for x in sel)
    # ---- the contrasts: C1 per variant, the variant pairs
    con = _rows(tmp_path / "a_decomposition_contrasts.csv")
    labels = {x["contrast"] for x in con}
    assert {"vs C1 (compact), same components", "vs C1 (compact_scfrozen), same components",
            "fixed_vs_fixed_scfrozen", "compact_vs_compact_scfrozen"} <= labels
    pairs = [x for x in con if x["contrast"] == "fixed_vs_fixed_scfrozen"]
    assert {x["arm"] for x in pairs} == {"treated", "keep"}                    # treated_frozen has no partner
    assert all(x["partner_missing"] == "False" for x in pairs)
    nc = _rows(tmp_path / "a_native_contrasts.csv")
    assert {x["contrast"] for x in nc} >= {"fixed_vs_fixed_scfrozen", "compact_vs_compact_scfrozen"}


def test_a_moved_frozen_column_fails_the_job(tmp_path):
    """the lineage check is real: a job that claims the freeze (config and manifest) but whose shortcut column
    moved fails on the lineage check; an edited checkpoint fails on its parameter hash."""
    from test_v31 import _lin, _manifest, _x25
    p0, t = _frozen_traj()
    d_l = _x25(resolve({**_lin(t), "train": {**t["train"], "freeze_inputs": "none"}}), variant="fixed_scfrozen")
    d_k = _x25(_lin(t), arm="treated_frozen", variant="fixed_scfrozen")
    _run([p0, t, d_l, d_k], tmp_path)
    rd = tmp_path / "runs" / run_id(d_l)
    cfg = json.loads((rd / "config.json").read_text())
    cfg["train"]["freeze_inputs"] = "shortcut"
    (rd / "config.json").write_text(json.dumps(cfg))
    m = tmp_path / "m.jsonl"
    m.write_text(json.dumps({"run_id": run_id(d_l), "cfg": cfg}) + "\n")
    # v43: the checkpoints carry their owner's config hash, so the claim alone fails the integrity check ...
    r = _tool(tmp_path, m, "m0", "--decompose")
    cov = read_json(tmp_path / "m0_coverage.json")
    assert r.returncode != 0 and "config hash differs" in cov["failed"][0]["reason"]
    # ... and with the hashes rewritten to match the claim, the lineage check catches the moved column
    from cop.utils import stable_hash
    for f in (rd / "ckpt").glob("*.pt"):
        o = torch.load(f, weights_only=False)
        o["lineage"]["cfg_hash"] = stable_hash(cfg)
        torch.save(o, f)
    r = _tool(tmp_path, m, "m", "--decompose")
    cov = read_json(tmp_path / "m_coverage.json")
    assert r.returncode != 0 and cov["n_failed"] == 1
    assert "the shortcut column moved" in cov["failed"][0]["reason"]
    rd = tmp_path / "runs" / run_id(d_k)
    ck = read_json(rd / "endpoint.json")["checkpoint"]
    obj = torch.load(rd / "ckpt" / f"{ck}.pt", weights_only=False)
    import selective_reversal as SR
    from cop.graph.graph import GraphNet
    w = f"mods.{SR.backbone_layers(GraphNet.from_checkpoint(obj['model']))[0]}.weight"
    obj["model"]["state"][w][:, _sc(p0)] += 1e-3
    torch.save(obj, rd / "ckpt" / f"{ck}.pt")
    r = _tool(tmp_path, _manifest(tmp_path, [d_k]), "n", "--decompose")
    cov = read_json(tmp_path / "n_coverage.json")
    assert r.returncode != 0 and "parameter hash" in cov["failed"][0]["reason"]


def test_variant_pairs_unit():
    import selective_reversal as SR
    base = {"cell": "c", "removal_variant": "full", "state": "repaired", "update_groups": "causal",
            "optimizer_seed": 0, "draw_set": "x"}
    rows = [{**base, "variant": v, "arm": "treated", "data_draw": d, "test_err": e}
            for v, d, e in (("fixed", 1, 0.10), ("fixed_scfrozen", 1, 0.13), ("fixed", 2, 0.20),
                            ("fixed_scfrozen", 2, 0.21), ("fixed", 3, 0.30))]
    pr, sm, cnt = SR.variant_pairs(rows, "update_groups")
    assert cnt == {"missing": 1, "noncomparable": 0, "duplicates": 0} and len(pr) == 2
    got = {x["data_draw"]: x["value"] for x in pr if x["value"] is not None}
    assert got[1] == pytest.approx(0.03) and got[2] == pytest.approx(0.01)
    assert sm[0]["contrast"] == "fixed_vs_fixed_scfrozen" and sm[0]["n_unique_data_draws"] == 2
    _, miss, dup = SR.paired_vs(rows + [rows[1]], ("cell", "data_draw"), "variant", "fixed_scfrozen", "v", "r")
    assert miss == 1 and dup == 1                                           # one unpaired, one duplicated reference


# ----------------------------------------------------------------------------- wave 23

def test_wave23_structure():
    from collections import Counter
    from cop.orchestration.manifest import generate
    import selective_reversal as SR
    m = generate([23], "full")
    ents = [e["cfg"] for e in m.entries.values()]
    assert len(ents) == 168 and {e["wave"] for e in m.entries.values()} == {c["wave"] for c in ents} == {23}
    draws = {c["data"]["data_seed"] for c in ents if c.get("data")}
    assert draws == set(range(313, 319))
    earlier = set()
    for w in (21, 22):
        earlier |= {c["data"]["data_seed"] for c in (e["cfg"] for e in generate([w], "full").entries.values())
                    if c.get("data")}
    assert not draws & earlier
    cells = Counter(((c.get("design") or {}).get("variant"), (c.get("design") or {}).get("arm"),
                     c["train"]["freeze_inputs"]) for c in ents if c["kind"] in ("dissipation", "continue"))
    assert cells == {("fixed", "treated", "none"): 12, ("fixed", "keep", "none"): 12,
                     ("fixed_scfrozen", "treated", "none"): 12, ("fixed_scfrozen", "keep", "none"): 12,
                     ("fixed_scfrozen", "treated_frozen", "shortcut"): 12, ("compact", "C1", "none"): 12,
                     ("compact_scfrozen", "C1", "shortcut"): 12, ("compact", "C1_phase", "none"): 12,
                     ("compact", "C1_reset", "none"): 12, ("compact_scfrozen", "C1_phase", "shortcut"): 12,
                     ("compact_scfrozen_lift", "C1_phase", "shortcut"): 12}
    trajs = [c for c in ents if c["kind"] == "trajectory"]
    assert Counter(c["train"]["freeze_inputs"] for c in trajs) == {"none": 12, "shortcut": 12}
    by = {run_id(c): c for c in trajs}
    for c in ents:
        if c["kind"] == "dissipation":
            pt = by[c["parents"]["trajectory"]]
            frozen_parent = pt["train"]["freeze_inputs"] == "shortcut"
            assert frozen_parent == c["design"]["variant"].endswith("_scfrozen")
            assert 2048 in c["dissipation"]["early_eval"]
    assert sum(1 for c in ents if SR.eligible(c)) == 132
    assert all(c["data"]["params"]["input_rotation"] == 0 for c in ents if c.get("data"))
