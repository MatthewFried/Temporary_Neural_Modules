"""v43 (the v42 review): one C1-matching path with the reference variant explicit (two C1 variants with different
errors, either input order); strict pair coverage (missing either side, a whole arm, duplicates; noncomparable
partners reported); the wave-23 contrast registry; the compact controls' freeze schedule (continue.freeze_segments),
their fork audit at 2U and a segmented replay equal to one segment; update norms (path length) and net movement from
the job start and from 2U; the rescaling fits analytically and their summaries; preflight integrity of intermediate
checkpoints; the trajectory rows' own metadata; wave 23."""
from __future__ import annotations

import csv
import json
import os
import subprocess
import sys
from pathlib import Path

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "audit_v5/tools"))
from cop.config import ConfigError, resolve, run_id  # noqa: E402
from cop.utils import read_json  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
TOOL = str(ROOT / "audit_v5/tools/selective_reversal.py")
LOG = {"log_update_norms": True}
FZ = {"freeze_inputs": "shortcut", **LOG}
EA = [3, 6, 12, 13, 14, 15, 18]              # the miniature's clock: U = 6, 2U = 12, g = 3, R = 6


def _run(cfgs, d):
    from test_v15 import _run as r
    return r(cfgs, d)


def _rows(path):
    t = Path(path).read_text()
    return [] if t.strip() == "empty" else list(csv.DictReader(open(path)))


def _tool(tmp_path, man, prefix, *extra, env=None):
    return subprocess.run([sys.executable, TOOL, str(tmp_path), str(tmp_path / prefix), "--manifest", str(man),
                           "--strict", "--device", "cpu", *extra], capture_output=True, text=True,
                          env=dict(os.environ, **(env or {})))


def _compact(p0, treated, variant, arm, segs, resets, train=None, fsg=None):
    cc = {"start": "baseline", "start_stage": "baseline", "budget": "fixed", "segments": segs,
          "segment_reset": resets, "eval_at": EA, "save_eval_checkpoints": True, "fork_audit": True}
    if fsg:
        cc["freeze_segments"] = fsg
    return resolve({"kind": "continue", "data": p0["data"], "model": p0["model"],
                    "train": {**p0["train"], **(train or LOG)}, "seeds": p0["seeds"],
                    "parents": {"baseline": run_id(p0), "treated": run_id(treated)}, "continue": cc,
                    "design": {"family": "X25", "variant": variant, "arm": arm, "contrast": "X25|c"}})


def _sc(p0) -> int:
    from cop.data.registry import load_bundle
    return int(load_bundle(p0["data"], device="cpu").meta["feature_layout"]["shortcut"])


def _w1(rd: Path, ck: str):
    from cop.graph.graph import GraphNet
    import selective_reversal as SR
    m = torch.load(rd / "ckpt" / f"{ck}.pt", weights_only=False)["model"]
    return m["state"][f"mods.{SR.backbone_layers(GraphNet.from_checkpoint(m))[0]}.weight"]


def _panel(tmp_path, run=True):
    """a miniature wave 23 with every arm: both fixed trajectories (update norms logged), their removals and keep
    forks, and the six compact controls with their 2U boundary and fork audit."""
    from test_v31 import _diss, _lin, _manifest, _traj, _x25
    p = _traj()
    tu = resolve({**p[-1], "train": {**p[-1]["train"], **LOG}})
    tf = resolve({**p[-1], "train": {**p[-1]["train"], **FZ}})
    lift = lambda t: {**t["train"], "freeze_inputs": "none"}
    kp = dict(method="keep", post_updates=6, save_path_checkpoints=True, early_eval=[1, 2])
    J = {"d_u": _x25(_lin(tu)), "k_u": _x25(_diss(tu, **kp), arm="keep"),
         "d_l": _x25(resolve({**_lin(tf), "train": lift(tf)}), variant="fixed_scfrozen"),
         "d_k": _x25(_lin(tf), arm="treated_frozen", variant="fixed_scfrozen"),
         "k_l": _x25(resolve({**_diss(tf, **kp), "train": lift(tf)}), arm="keep", variant="fixed_scfrozen")}
    p0 = p[0]
    J.update({"c1": _compact(p0, J["d_u"], "compact", "C1", [12, 6], [False, False]),
              "c1r": _compact(p0, J["d_u"], "compact", "C1_reset", [12, 6], [False, True]),
              "c1p": _compact(p0, J["d_u"], "compact", "C1_phase", [6, 6, 3, 3], [False, False, True, True]),
              "f1": _compact(p0, J["d_u"], "compact_scfrozen", "C1", [12, 6], [False, False], FZ),
              "f1p": _compact(p0, J["d_u"], "compact_scfrozen", "C1_phase", [6, 6, 3, 3],
                              [False, False, True, True], FZ),
              "f1l": _compact(p0, J["d_u"], "compact_scfrozen_lift", "C1_phase", [6, 6, 3, 3],
                              [False, False, True, True], FZ, [True, True, False, False])})
    if run:
        _run([p0, tu, tf], tmp_path)
        for c in J.values():
            _run([c], tmp_path)
    return p0, tu, tf, J, _manifest(tmp_path, [p0, tu, tf, *J.values()])


ALL = ("--trace", "--decompose", "--cross", "--scale-controls", "--displacement", "--contrasts", "wave23")


def test_miniature_wave23_end_to_end(tmp_path):
    import selective_reversal as SR
    p0, tu, tf, J, man = _panel(tmp_path)
    r = _tool(tmp_path, man, "a", *ALL)
    assert r.returncode == 0, r.stdout + r.stderr
    cov = read_json(tmp_path / "a_coverage.json")
    assert cov["passed"] and cov["analysed"] == 11 and cov["registry"]["fork_u"] == 12
    assert not cov["registry"]["problems"] and not cov["compact_fork_equality_failures"]
    assert cov["options"]["contrasts"] == "wave23" and cov["analysis_schema"] == SR.ANALYSIS_SCHEMA
    # ---- the registry: every declared contrast, value = err(B) - err(A), from the named rows
    reg = _rows(tmp_path / "a_registry_by_setting.csv")
    assert {x["contrast"] for x in reg} == {c[0] for c in SR.REGISTRIES["wave23"]}
    dec = {(x["run_id"], x["state"], x["update_groups"]): float(x["test_err"])
           for x in _rows(tmp_path / "a_decomposition.csv")}
    x = next(x for x in reg if x["contrast"] == "release_vs_remain_frozen" and x["measure"] == "causal")
    assert x["a_run_id"] == run_id(J["d_l"]) and x["b_run_id"] == run_id(J["d_k"])
    assert float(x["value"]) == pytest.approx(dec[(run_id(J["d_k"]), "repaired", "causal")] -
                                              dec[(run_id(J["d_l"]), "repaired", "causal")], abs=1e-15)
    t2 = [x for x in reg if x["contrast"] == "frozen_trajectory_vs_frozen_compact_at_2U"]
    assert {x["a_run_id"] for x in t2} == {run_id(tf)} and {x["b_run_id"] for x in t2} == {run_id(J["f1"])}
    w = [x for x in reg if x["contrast"] == "repair_change_frozen_kept"]
    assert w and all(x["a_run_id"] == x["b_run_id"] == run_id(J["d_k"]) for x in w)
    assert _rows(tmp_path / "a_registry_summary.csv") and _rows(tmp_path / "a_registry_by_draw.csv")
    # ---- the frozen trajectory's own trace rows say it was frozen, whichever child claimed them
    dt = [x for x in _rows(tmp_path / "a_decomposition_trace.csv") if x["run_id"] == run_id(tf)]
    assert dt and {x["freeze_inputs"] for x in dt} == {"shortcut"} and {x["variant"] for x in dt} == {"fixed_scfrozen"}
    lf = [x for x in _rows(tmp_path / "a_decomposition_trace.csv") if x["run_id"] == run_id(J["f1l"])]
    assert all(float(x["shortcut_column_change_max_abs"]) == 0.0 for x in lf if int(x["updates_since_f0"]) <= 12)
    assert any(float(x["shortcut_column_change_max_abs"]) > 0.0 for x in lf if int(x["updates_since_f0"]) > 12)
    # ---- C1 contrasts per reference variant, in every table
    con = _rows(tmp_path / "a_contrasts.csv")
    tr = [x for x in con if x["run_ids"] == run_id(J["d_u"]) and x["state"] == "repaired"]
    assert {x["reference_variant"] for x in tr} == {"compact", "compact_scfrozen"}
    nc = {x["contrast"] for x in _rows(tmp_path / "a_native_contrasts.csv")}
    assert {"vs C1 (compact)", "vs C1 (compact_scfrozen)", "fixed_vs_fixed_scfrozen",
            "compact_vs_compact_scfrozen"} <= nc
    assert _rows(tmp_path / "a_native_contrasts_by_setting.csv") and _rows(tmp_path / "a_native_contrasts_by_draw.csv")
    # ---- the compact fork audit: one prefix, equal at 2U, the same minibatches to the end
    fa = _rows(tmp_path / "a_compact_fork_audit.csv")
    at2 = [x for x in fa if x["record"] == "segment_start" and x["update"] == "12" and x["prefix_frozen"] == "False"]
    assert {x["run_id"] for x in at2} == {run_id(J[k]) for k in ("c1", "c1r", "c1p")}
    for f in ("model_param_hash", "opt_digest", "sampler", "rng_hash", "batch_id_hash"):
        assert len({x[f] for x in at2}) == 1, f
    after = {x["run_id"]: int(x["opt_tensors_with_state_after_configure"]) for x in at2}
    assert after[run_id(J["c1r"])] == 0 and after[run_id(J["c1p"])] == 0 and after[run_id(J["c1"])] > 0
    ends = [x for x in fa if x["record"] == "end"]
    assert len({x["batch_id_hash"] for x in ends}) == 1 and {x["update"] for x in ends} == {"18"}
    # ---- net movement and path length: the path is never shorter than the net movement
    dsp = _rows(tmp_path / "a_displacement.csv")
    pl = [x for x in dsp if x.get("path_backbone")]
    assert pl and all(float(x["path_backbone"]) >= float(x["net_backbone_l2"]) * (1 - 1e-9) for x in pl)
    assert all(float(x["path_first_layer_shortcut"]) == 0.0 for x in pl if x["run_id"] == run_id(J["d_k"]))
    own2 = [x for x in dsp if x["run_id"] == run_id(J["c1r"]) and x["reference_checkpoint"] == "own at_12"]
    assert own2 and all(int(x["updates_since_reference"]) > 0 for x in own2 if x["checkpoint"] != "endpoint")
    e1 = next(x for x in own2 if x["checkpoint"] == "endpoint")
    assert e1["updates_since_reference"] == "6" and e1["path_updates"] == "6"
    end_u = next(x for x in dsp if x["run_id"] == run_id(J["d_u"]) and x["checkpoint"] == "endpoint")
    assert end_u["updates_since_reference"] == "6" and end_u["additions_status"] == "deleted or not applicable"
    assert end_u["net_additions_l2"] == ""
    # ---- the rescaling: ten controls, the agreement and fit metrics summarised, the per-unit scales kept
    sc = _rows(tmp_path / "a_scale.csv")
    assert len(sc) == SR.N_SCALE_CONTROLS * len(_rows(tmp_path / "a_checks.csv"))
    for x in sc:
        if x["control"].endswith("_nonneg"):
            assert float(x["scale_min"]) >= 0 and x["signed"] == "False"
        if x["control"].endswith("_selected"):
            assert x["oracle_tuning"] == "True" and x["selected_on"] in ("val_indep", "val")
    ms = _rows(tmp_path / "a_scale_metrics_summary.csv")
    assert {x["metric"] for x in ms} >= {"decision_disagreement_vs_transplant", "tv_vs_transplant", "drive_r2_fit",
                                         "drive_r2_heldout", "n_negative_scales"}
    sv = _rows(tmp_path / "a_scale_vectors.csv")
    assert {x["control"] for x in sv} == {"f0_causal_row_ls_fit", "f0_causal_row_ls_fit_nonneg",
                                          "f0_causal_activation_fit", "f0_causal_activation_fit_nonneg"}
    u = cov["scale_grid_edges_unique"]
    assert u["grids"] == 1 and u["grid_causal"] == [0.5, 16.0]
    # ---- a fork whose RNG differs at 2U fails the compact audit
    rd = tmp_path / "runs" / run_id(J["c1r"])
    j0 = (rd / "continue_result.json").read_text()
    j = json.loads(j0)
    next(s for s in j["fork_audit"]["starts"] if s["update"] == 12)["rng_hash"] = "tampered"
    (rd / "continue_result.json").write_text(json.dumps(j))
    r = _tool(tmp_path, man, "b", "--decompose")
    cov = read_json(tmp_path / "b_coverage.json")
    assert r.returncode != 0 and [f["field"] for f in cov["compact_fork_equality_failures"]] == ["rng_hash"]
    (rd / "continue_result.json").write_text(j0)
    # ---- the preflight loads and checks every intermediate checkpoint: a corrupted one fails it
    victim = tmp_path / "runs" / run_id(J["k_u"]) / "ckpt" / "path_u2.pt"
    o = torch.load(victim, weights_only=False)
    k_ = next(k for k, v in o["model"]["state"].items() if v.is_floating_point())
    o["model"]["state"][k_] = o["model"]["state"][k_] + 1e-3
    torch.save(o, victim)
    r = _tool(tmp_path, man, "pf", *ALL[:5], "--preflight")
    cov = read_json(tmp_path / "pf_coverage.json")
    assert r.returncode != 0 and any("path_u2" in f["reason"] or "parameter hash" in f["reason"]
                                     for f in cov["failed"])


def test_a_segmented_compact_replay_equals_one_segment_and_the_audit_changes_nothing(tmp_path):
    """C1 with a declared boundary (no reset) and the fork audit trains exactly as C1 in one segment."""
    from test_v31 import _lin, _traj, _x25
    p = _traj()
    d = _x25(_lin(p[-1]))
    one = resolve({"kind": "continue", "data": p[0]["data"], "model": p[0]["model"], "train": p[0]["train"],
                   "seeds": p[0]["seeds"], "parents": {"baseline": run_id(p[0]), "treated": run_id(d)},
                   "continue": {"start": "baseline", "start_stage": "baseline", "budget": "fixed", "updates": 18},
                   "design": {"family": "X25", "variant": "compact", "arm": "C1", "contrast": "X25|c"}})
    two = _compact(p[0], d, "compact", "C1", [12, 6], [False, False], train={})
    _run(p + [d, one, two], tmp_path)
    ph = lambda c: torch.load(tmp_path / "runs" / run_id(c) / "ckpt" / "final.pt",
                              weights_only=False)["lineage"]["param_hash"]
    assert ph(one) == ph(two)


def test_the_compact_freeze_schedule_holds_then_releases_and_resumes(tmp_path):
    from resume_harness import compare_interrupted
    from test_v31 import _lin, _traj, _x25
    p = _traj()
    d = _x25(_lin(p[-1]))
    f1l = _compact(p[0], d, "compact_scfrozen_lift", "C1_phase", [6, 6, 3, 3], [False, False, True, True], FZ,
                   [True, True, False, False])
    _run(p + [d, f1l], tmp_path)
    rd = tmp_path / "runs" / run_id(f1l)
    sc = _sc(p[0])
    W0 = _w1(tmp_path / "runs" / run_id(p[0]), "baseline")
    assert torch.equal(_w1(rd, "at_12")[:, sc], W0[:, sc])                  # held through the frozen prefix
    assert not torch.equal(_w1(rd, "final")[:, sc], W0[:, sc])              # released after 2U
    cr = read_json(rd / "continue_result.json")
    assert cr["freeze_segments"] == [True, True, False, False]
    st = torch.load(rd / "ckpt" / "final.pt", weights_only=False)["trainer"]["state"]
    assert st["update_norms"]["n_updates"] == 18 and st["update_norms"]["path"]["backbone"] > 0
    assert len(st["input_freeze_record"]) == 2                              # the two frozen segments
    rep = compare_interrupted(p + [d, f1l], tmp_path / "r", fractions=(0.3, 0.7))
    assert rep["interrupted_at_polls"] and rep["equal"], rep


def test_freeze_schedule_config_rules():
    from test_v31 import _lin, _traj, _x25
    p = _traj()
    d = _x25(_lin(p[-1]))
    with pytest.raises(ConfigError):                                         # not a frozen prefix
        _compact(p[0], d, "x", "C1_phase", [6, 6, 3, 3], [False] * 4, FZ, [True, False, True, False])
    with pytest.raises(ConfigError):                                         # names no group to hold
        _compact(p[0], d, "x", "C1_phase", [6, 6, 3, 3], [False] * 4, LOG, [True, True, False, False])
    with pytest.raises(ConfigError):
        _compact(p[0], d, "x", "C1_phase", [6, 6, 3, 3], [False] * 4, FZ, [True, False])
    with pytest.raises(ConfigError):
        resolve({**p[-1], "train": {**p[-1]["train"], "log_update_norms": "yes"}})


# ----------------------------------------------------------------------------- matching and coverage (units)

def _set_rows(order):
    base = {"cell": "c", "removal_variant": "full", "code": "0-1", "draw_set": "x", "data_draw": 1, "optimizer_seed": 0}
    rows = [{**base, "variant": "fixed", "arm": "treated", "state": "repaired", "test_err": 0.20, "run_ids": "t"},
            {**base, "variant": "compact", "arm": "C1", "state": "C1_final", "removal_variant": "control",
             "test_err": 0.25, "run_ids": "a"},
            {**base, "variant": "compact_scfrozen", "arm": "C1", "state": "C1_final", "removal_variant": "control",
             "test_err": 0.31, "run_ids": "b"}]
    return rows if order else rows[::-1]


DJ = {("fixed", "treated", "full", "c", 1, 0), ("compact", "C1", "control", "c", 1, 0),
      ("compact_scfrozen", "C1", "control", "c", 1, 0)}


def test_c1_reference_identity_is_explicit_in_either_order():
    import selective_reversal as SR
    res = []
    for order in (True, False):
        pr, cnt = SR.c1_contrasts(_set_rows(order), "code", DJ, "c1_err", "gain")
        assert cnt == {"missing": 0, "duplicates": 0, "noncomparable": 0}
        res.append(sorted((x["reference_variant"], round(x["gain"], 12), x["reference_run_ids"]) for x in pr))
    assert res[0] == res[1] == [("compact", 0.05, "a"), ("compact_scfrozen", 0.11, "b")]
    rows = _set_rows(True)
    _, cnt = SR.c1_contrasts(rows + [dict(rows[1], test_err=0.9)], "code", DJ, "c1_err", "gain")
    assert cnt["duplicates"] == 1                                            # never overwritten, always counted
    pr, _ = SR.c1_contrasts(rows + [dict(rows[1], test_err=0.9)], "code", DJ, "c1_err", "gain")
    assert next(x for x in pr if x["reference_variant"] == "compact")["gain"] == pytest.approx(0.05)
    _, cnt = SR.c1_contrasts([r for r in rows if r["variant"] != "compact_scfrozen"], "code", DJ, "c1_err", "gain")
    assert cnt["missing"] == 1                                               # the design holds it: missing
    dj = {k for k in DJ if k[0] != "compact_scfrozen"}
    _, cnt = SR.c1_contrasts(rows[:2], "code", dj, "c1_err", "gain")
    assert cnt == {"missing": 0, "duplicates": 0, "noncomparable": 0}


def test_variant_pairs_require_what_the_design_holds():
    import selective_reversal as SR
    base = {"cell": "c", "removal_variant": "full", "state": "repaired", "update_groups": "causal",
            "optimizer_seed": 0, "draw_set": "x", "arm": "treated"}
    rows = [{**base, "variant": v, "data_draw": d, "test_err": e}
            for v, d, e in (("fixed", 1, 0.1), ("fixed_scfrozen", 1, 0.2), ("fixed", 2, 0.3), ("fixed_scfrozen", 2, 0.4))]
    dj = {(v, "treated", "full", "c", d, 0) for v in ("fixed", "fixed_scfrozen") for d in (1, 2)}
    _, _, cnt = SR.variant_pairs(rows, "update_groups", dj)
    assert cnt == {"missing": 0, "noncomparable": 0, "duplicates": 0}
    for drop in (1, 2):                                                      # either side of a required pair
        _, _, cnt = SR.variant_pairs([r for i, r in enumerate(rows) if i != drop], "update_groups", dj)
        assert cnt["missing"] == 1
    _, _, cnt = SR.variant_pairs([r for r in rows if r["variant"] == "fixed"], "update_groups", dj)
    assert cnt["missing"] == 2                                               # a whole arm absent from the results
    _, _, cnt = SR.variant_pairs(rows + [rows[0]], "update_groups", dj)
    assert cnt["duplicates"] == 1
    dj2 = {k for k in dj if not (k[0] == "fixed_scfrozen" and k[4] == 2)}
    _, _, cnt = SR.variant_pairs(rows[:3], "update_groups", dj2)
    assert cnt == {"missing": 0, "noncomparable": 1, "duplicates": 0}        # the design never held that partner


def test_registry_missing_pairs_and_absent_arms_fail():
    import selective_reversal as SR
    reg = SR.REGISTRIES["wave23"]
    out = {"native": [], "decomposition": [], "decomposition_trace": []}
    _, _, _, prob = SR.registry_contrasts("wave23", out, set(), 12)
    assert len(prob) == len(reg) and all(p["problem"] == "a side has no job in the manifest" for p in prob)
    dj = {("fixed_scfrozen", "treated", "full", "c", 1, 0), ("fixed_scfrozen", "treated_frozen", "full", "c", 1, 0)}
    mk = lambda arm, msr, e, rid: {"variant": "fixed_scfrozen", "arm": arm, "state": "repaired", "update_groups": msr,
                                   "cell": "c", "data_draw": 1, "optimizer_seed": 0, "test_err": e, "run_id": rid}
    out["decomposition"] = [mk("treated", m, 0.2, "A") for m in SR.COMPONENTS] + \
                           [mk("treated_frozen", m, 0.3, "B") for m in SR.COMPONENTS]
    out["native"] = [{**mk("treated", None, 0.1, "A"), "measure": "native_endpoint"},
                     {**mk("treated_frozen", None, 0.15, "B"), "measure": "native_endpoint"}]
    rows, _, _, prob = SR.registry_contrasts("wave23", out, dj, 12)
    rel = [x for x in rows if x["contrast"] == "release_vs_remain_frozen"]
    assert len(rel) == 5 and all(x["value"] == pytest.approx(0.1 if x["measure"] != "native" else 0.05) for x in rel)
    assert not [p for p in prob if p["contrast"] == "release_vs_remain_frozen"]
    out["native"] = out["native"][:1]                                        # one side of one pair lost
    _, _, _, prob = SR.registry_contrasts("wave23", out, dj, 12)
    assert [p for p in prob if p["contrast"] == "release_vs_remain_frozen"] == [
        {"contrast": "release_vs_remain_frozen", "problem": "missing", "key": ["c", "1", "0", "native"], "side": "B"}]


# ----------------------------------------------------------------------------- the rescaling fits (analytic)

def test_scale_fits_analytic():
    import selective_reversal as SR
    torch.manual_seed(0)
    C0 = torch.randn(4, 3, dtype=torch.float64)
    s_true = torch.tensor([2.0, 0.5, -1.0, 3.0], dtype=torch.float64)
    C1 = C0 * s_true.unsqueeze(1)
    s, deg = SR.fit_row_scales(C0, C1)
    assert torch.allclose(s, s_true) and not deg.any()                       # exact, signed
    s_nn, _ = SR.fit_row_scales(C0, C1, nonneg=True)
    assert torch.allclose(s_nn, s_true.clamp_min(0))                         # the constrained 1-D optimum
    Z = C0.clone()
    Z[1] = 0.0
    s, deg = SR.fit_row_scales(Z, C1)
    assert deg.tolist() == [False, True, False, False] and s[1] == 1.0       # a zero row: flagged, no change
    # an orthogonal residual: the fit keeps the projection, the residual lowers R^2 by a known amount
    U = torch.eye(3, dtype=torch.float64).repeat(4, 1)
    v = torch.tensor([1.0, 0.0, 0.0], dtype=torch.float64)
    w = torch.tensor([0.0, 1.0, 0.0], dtype=torch.float64)
    c0, c1 = v.unsqueeze(0), (2 * v + w).unsqueeze(0)
    s, _ = SR.fit_row_scales(c0, c1)
    assert float(s[0]) == pytest.approx(2.0)
    s_d, _ = SR.fit_drive_scales(U, c0, c1)
    assert float(s_d[0]) == pytest.approx(2.0)
    a_ = (U @ c1.T)[:, 0]
    sst = float(((a_ - a_.mean()) ** 2).sum())
    r2, dg = SR.drive_r2(U, c0, c1, s_d)
    assert not dg and r2 == pytest.approx(1.0 - 4.0 / sst)                   # residual = w on its 4 rows
    r2, dg = SR.drive_r2(U, c0, 3.0 * c0, torch.tensor([3.0], dtype=torch.float64))
    assert r2 == pytest.approx(1.0)
    r2, dg = SR.drive_r2(U[:1], c0, c0, torch.tensor([1.0], dtype=torch.float64))
    assert r2 is None and dg                                                 # a constant target is degenerate
    # similar accuracy, different predictions
    q0 = torch.tensor([[2.0, 0.0], [0.0, 2.0], [2.0, 0.0], [0.0, 2.0]])
    q1 = torch.tensor([[0.0, 2.0], [2.0, 0.0], [2.0, 0.0], [0.0, 2.0]])
    ag = SR.agreement(q0, q1)
    assert ag["decision_disagreement_vs_transplant"] == 0.5
    p0_, p1_ = q0.double().softmax(-1), q1.double().softmax(-1)
    assert ag["tv_vs_transplant"] == pytest.approx(float(0.5 * (p0_ - p1_).abs().sum(-1).mean()))


# ----------------------------------------------------------------------------- wave 23

def test_wave23_v43_structure():
    from collections import Counter
    from cop.orchestration.manifest import generate
    from cop.orchestration.wave13 import info_access
    m = generate([23], "full")
    ents = [e["cfg"] for e in m.entries.values()]
    assert len(ents) == 168
    comp = [c for c in ents if c["kind"] == "continue"]
    assert all(c["continue"]["fork_audit"] and c["train"]["log_update_norms"] for c in comp)
    assert Counter((c["design"]["variant"], c["design"]["arm"], tuple(c["continue"]["segments"]),
                    tuple(c["continue"]["segment_reset"]), tuple(c["continue"]["freeze_segments"])) for c in comp) == {
        ("compact", "C1", (4000, 3000), (False, False), ()): 12,
        ("compact", "C1_reset", (4000, 3000), (False, True), ()): 12,
        ("compact", "C1_phase", (2000, 2000, 200, 2800), (False, False, True, True), ()): 12,
        ("compact_scfrozen", "C1", (4000, 3000), (False, False), ()): 12,
        ("compact_scfrozen", "C1_phase", (2000, 2000, 200, 2800), (False, False, True, True), ()): 12,
        ("compact_scfrozen_lift", "C1_phase", (2000, 2000, 200, 2800), (False, False, True, True),
         (True, True, False, False)): 12}
    assert all(c["train"]["log_update_norms"] for c in ents if c["kind"] != "baseline")
    # every compact control has the same updates as its expanded lineage (2U + R)
    assert {sum(c["continue"]["segments"]) for c in comp} == {7000}
    assert all(info_access(c)["privileged_feature_layout"] for c in ents if c["train"]["freeze_inputs"] != "none")
    assert all(info_access(c)["privileged_feature_layout"] is None for c in ents
               if c["train"]["freeze_inputs"] == "none")


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA device required")
def test_cuda_compact_freeze_schedule_fork_audit_and_update_norms(tmp_path):
    """the GPU path of the v43 training additions: the freeze schedule, the fork audit (RNG and optimizer digests
    of device tensors) and the update norms; an interrupted run equals an uninterrupted one."""
    from resume_harness import compare_interrupted
    from test_v31 import _lin, _traj, _x25
    p = _traj()
    d = _x25(_lin(p[-1]))
    f1l = _compact(p[0], d, "compact_scfrozen_lift", "C1_phase", [6, 6, 3, 3], [False, False, True, True], FZ,
                   [True, True, False, False])
    rep = compare_interrupted(p + [d, f1l], tmp_path, fractions=(0.3, 0.7), ex={"device": "cuda"})
    assert rep["interrupted_at_polls"] and rep["equal"], rep
