"""v44: the downstream-frozen expansion (train.freeze_backbone=downstream: the additions and the first layer train,
backbone layers 2..K held at their start values; its frozen-prefix schedule on the compact controls) and the
analyses: every keep / restore code (--codes all, at 2U too), the codes with the additions present, the scaling +
residual split of the learned causal block, the downstream lineage check and the wave-24 registry with the
extraction rule (cross_measure); wave 24."""
from __future__ import annotations

import csv
import os
import subprocess
import sys
from pathlib import Path

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "audit_v5/tools"))
from cop.config import ConfigError, resolve, run_id  # noqa: E402
from cop.utils import read_json  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
TOOL = str(ROOT / "audit_v5/tools/selective_reversal.py")
LOG = {"log_update_norms": True}
DS = {"freeze_backbone": "downstream", **LOG}
EA = [3, 6, 12, 13, 14, 15, 18]              # the miniature's clock: U = 6, 2U = 12, g = 3, R = 6
ALL = ("--codes", "all", "--trace", "--trace-codes", "auto", "--codes-at-2u", "--implant-codes", "--decompose",
       "--cross", "--scale-controls", "--displacement", "--contrasts", "wave24")


def _run(cfgs, d):
    from test_v15 import _run as r
    return r(cfgs, d)


def _rows(path):
    t = Path(path).read_text()
    return [] if t.strip() == "empty" else list(csv.DictReader(open(path)))


def _tool(tmp_path, man, prefix, *extra, env=None):
    return subprocess.run([sys.executable, TOOL, str(tmp_path), str(tmp_path / prefix), "--manifest", str(man),
                           "--strict", "--device", "cpu", *extra], capture_output=True, text=True,
                          env=dict(os.environ, **(env or {})))


def _compact(p0, treated, variant, arm, segs, resets, train=None, fsg=None):
    cc = {"start": "baseline", "start_stage": "baseline", "budget": "fixed", "segments": segs,
          "segment_reset": resets, "eval_at": EA, "save_eval_checkpoints": True, "fork_audit": True}
    if fsg:
        cc["freeze_segments"] = fsg
    return resolve({"kind": "continue", "data": p0["data"], "model": p0["model"],
                    "train": {**p0["train"], **(train or LOG)}, "seeds": p0["seeds"],
                    "parents": {"baseline": run_id(p0), "treated": run_id(treated)}, "continue": cc,
                    "design": {"family": "X25", "variant": variant, "arm": arm, "contrast": "X25|c"}})


def _state(rd: Path, ck: str):
    return torch.load(rd / "ckpt" / f"{ck}.pt", weights_only=False)["model"]["state"]


def _layers(p0_dir: Path):
    from cop.graph.graph import GraphNet
    import selective_reversal as SR
    return SR.backbone_layers(GraphNet.from_checkpoint(torch.load(p0_dir / "ckpt" / "baseline.pt",
                                                                  weights_only=False)["model"]))


def _same_layers(sd, f0, layers) -> bool:
    return all(torch.equal(sd[k], f0[k]) for k in f0 if k.startswith("mods.") and k.split(".")[1] in layers)


def _panel(tmp_path, run=True):
    """a miniature wave 24: the ordinary and the downstream-frozen trajectory, their removals and keep forks (the
    hold lifted), the three compact controls and the two downstream-frozen-then-released compact controls."""
    from test_v31 import _diss, _lin, _manifest, _traj, _x25
    p = _traj()
    tu = resolve({**p[-1], "train": {**p[-1]["train"], **LOG}})
    td = resolve({**p[-1], "train": {**p[-1]["train"], **DS}})
    lift = lambda c: resolve({**c, "train": {**c["train"], "freeze_backbone": "none"}})
    kp = dict(method="keep", post_updates=6, save_path_checkpoints=True, early_eval=[1, 2])
    J = {"d_u": _x25(_lin(tu)), "k_u": _x25(_diss(tu, **kp), arm="keep"),
         "d_d": _x25(lift(_lin(td)), variant="fixed_dsfrozen"),
         "k_d": _x25(lift(_diss(td, **kp)), arm="keep", variant="fixed_dsfrozen")}
    p0 = p[0]
    J.update({"c1": _compact(p0, J["d_u"], "compact", "C1", [12, 6], [False, False]),
              "c1r": _compact(p0, J["d_u"], "compact", "C1_reset", [12, 6], [False, True]),
              "c1p": _compact(p0, J["d_u"], "compact", "C1_phase", [6, 6, 3, 3], [False, False, True, True]),
              "dlp": _compact(p0, J["d_u"], "compact_dsfrozen_lift", "C1_phase", [6, 6, 3, 3],
                              [False, False, True, True], DS, [True, True, False, False]),
              "dlr": _compact(p0, J["d_u"], "compact_dsfrozen_lift", "C1_reset", [12, 6], [False, True], DS,
                              [True, False])})
    if run:
        _run([p0, tu, td], tmp_path)
        for c in J.values():
            _run([c], tmp_path)
    return p0, tu, td, J, _manifest(tmp_path, [p0, tu, td, *J.values()])


def test_miniature_wave24_end_to_end(tmp_path):
    import selective_reversal as SR
    p0, tu, td, J, man = _panel(tmp_path)
    runs = tmp_path / "runs"
    L = _layers(runs / run_id(p0))
    K = len(L)
    f0 = _state(runs / run_id(p0), "baseline")
    # ---- training: the downstream hold keeps layers 2..K at f0 through the expansion; the first layer moves
    assert _same_layers(_state(runs / run_id(td), "final"), f0, L[1:])
    assert not _same_layers(_state(runs / run_id(td), "final"), f0, L[:1])
    assert not _same_layers(_state(runs / run_id(tu), "final"), f0, L[1:])
    dl = runs / run_id(J["dlr"])
    assert _same_layers(_state(dl, "at_12"), f0, L[1:]) and not _same_layers(_state(dl, "final"), f0, L[1:])
    st = torch.load(runs / run_id(td) / "ckpt" / "final.pt", weights_only=False)["trainer"]["state"]
    assert [r["pkeys"] for r in st["backbone_hold_record"]] == [L[1:]] * 2           # one record per round
    assert not _same_layers(_state(runs / run_id(J["d_d"]), "export"), f0, L[1:])    # the hold lifted
    # ---- the analysis
    r = _tool(tmp_path, man, "a", *ALL)
    assert r.returncode == 0, r.stdout + r.stderr
    cov = read_json(tmp_path / "a_coverage.json")
    assert cov["passed"] and cov["analysed"] == 9 and cov["registry"]["fork_u"] == 12
    assert not cov["registry"]["problems"] and not cov["compact_fork_equality_failures"]
    assert cov["analysis_schema"] == SR.ANALYSIS_SCHEMA and SR.ANALYSIS_SCHEMA.startswith("selective_reversal/v")
    # every keep / restore code on the named states
    codes = _rows(tmp_path / "a_codes.csv")
    E = {(x["run_id"], x["state"], x["code"]): float(x["test_err"]) for x in codes}
    assert {x["code"] for x in codes} == set(SR.all_codes(K)) and len(SR.all_codes(K)) == 2 ** K
    z, x1 = "-".join(["0"] * K), "-".join(["0"] + ["1"] * (K - 1))
    dd = run_id(J["d_d"])
    assert E[(dd, "abrupt", z)] == E[(dd, "abrupt", x1)]        # downstream at f0: the extraction is the state
    chk = {(x["run_id"], x["state"]): x for x in _rows(tmp_path / "a_checks.csv")}
    assert float(chk[(dd, "abrupt")]["downstream_change_max_abs"]) == 0.0
    assert float(chk[(dd, "repaired")]["downstream_change_max_abs"]) > 0.0
    assert float(chk[(run_id(J["d_u"]), "abrupt")]["downstream_change_max_abs"]) > 0.0
    # the trace: the auto codes, and every code at 2U (the trajectory's end and the compact controls' at_12)
    tr = _rows(tmp_path / "a_trace.csv")
    at2 = {(x["run_id"], x["code"]) for x in tr if x["updates_since_f0"] == "12"}
    for rid in (run_id(tu), run_id(td), run_id(J["c1"]), run_id(J["dlr"])):
        assert {c for r_, c in at2 if r_ == rid} == set(SR.all_codes(K)), rid
    assert {x["code"] for x in tr if x["updates_since_f0"] == "6"} == set(SR.auto_codes(K))
    assert all(float(x["downstream_change_max_abs"]) == 0.0 for x in tr if x["run_id"] == run_id(td))
    # the codes with the additions present: the zero code is the unedited state (the kept endpoint's native function)
    ci = _rows(tmp_path / "a_codes_implants.csv")
    assert {x["state"] for x in ci} == {"abrupt", "after_transition", "kept_end"}
    nat = {(x["run_id"], x["state"]): float(x["test_err"]) for x in _rows(tmp_path / "a_native.csv")}
    ku = run_id(J["k_u"])
    assert next(float(x["test_err"]) for x in ci if x["run_id"] == ku and x["code"] == z) == nat[(ku, "kept_end")]
    assert len([x for x in ci if x["run_id"] == ku]) == 2 ** K
    assert all(float(x["backbone_change_on_deletion_max_abs"]) == 0.0 for x in ci)
    ipc = _rows(tmp_path / "a_codes_implants_contrasts.csv")
    assert ipc and _rows(tmp_path / "a_codes_implants_contrasts_by_draw.csv")
    # the scaling + residual split: eleven controls; scaling and residual are orthogonal row by row
    sc = _rows(tmp_path / "a_scale.csv")
    assert len(sc) == SR.N_SCALE_CONTROLS * len(chk) and SR.N_SCALE_CONTROLS >= 11
    res = [x for x in sc if x["control"] == "f0_causal_plus_residual"]
    assert len(res) == len(chk) and all(0.0 <= float(x["residual_energy_fraction"]) <= 1.0 for x in res)
    assert "residual_energy_fraction" in {x["metric"] for x in _rows(tmp_path / "a_scale_metrics_summary.csv")}
    # the registry: every declared contrast; a cross_measure value from the named rows
    reg = _rows(tmp_path / "a_registry_by_setting.csv")
    assert {x["contrast"] for x in reg} == {c[0] for c in SR.REGISTRIES["wave24"]}
    x = next(x for x in reg if x["contrast"] == "extraction_vs_repaired_native_dsfrozen")
    assert x["a_run_id"] == x["b_run_id"] == dd
    assert float(x["value"]) == pytest.approx(nat[(dd, "repaired")] - E[(dd, "abrupt", x1)], abs=1e-15)
    x = next(x for x in reg if x["contrast"] == "extraction_vs_compact_extraction_at_2U_dsfrozen")
    assert x["b_run_id"] == run_id(J["dlr"])
    x = next(x for x in reg if x["contrast"] == "extraction_vs_expanded_native_ordinary")
    ab = next(float(y["test_err"]) for y in ci if y["run_id"] == run_id(J["d_u"]) and y["state"] == "abrupt"
              and y["code"] == z)
    assert float(x["value"]) == pytest.approx(ab - E[(run_id(J["d_u"]), "abrupt", x1)], abs=1e-15)
    # the compact fork audit: the downstream-frozen prefix is its own group, equal at 2U
    fa = _rows(tmp_path / "a_compact_fork_audit.csv")
    g2 = [x for x in fa if x["record"] == "segment_start" and x["update"] == "12"
          and x["prefix_freeze"] == "freeze_backbone=downstream"]
    assert {x["run_id"] for x in g2} == {run_id(J["dlp"]), run_id(J["dlr"])}
    for f in ("model_param_hash", "opt_digest", "sampler", "rng_hash", "batch_id_hash"):
        assert len({x[f] for x in g2}) == 1, f


def test_the_downstream_check_fails_a_moved_layer(tmp_path, monkeypatch):
    """the analysis' lineage check: a held lineage (kept through the removal) passes with layers 2..K exactly f0's;
    the same configs trained with the hold disabled (the config still says downstream) fail the check."""
    from cop.train.trainer import Trainer
    from test_v31 import _lin, _manifest, _traj, _x25
    p = _traj()
    td = resolve({**p[-1], "train": {**p[-1]["train"], **DS}})
    d = _x25(_lin(td), arm="treated_held", variant="fixed_dsfrozen")       # the hold kept through the removal
    _run([p[0], td, d], tmp_path / "ok")
    r = _tool(tmp_path / "ok", _manifest(tmp_path / "ok", [p[0], td, d]), "a")
    assert r.returncode == 0, r.stdout + r.stderr
    chk = _rows(tmp_path / "ok" / "a_checks.csv")
    assert {x["state"] for x in chk} == {"abrupt", "after_transition", "repaired"}
    assert all(float(x["downstream_change_max_abs"]) == 0.0 for x in chk)
    monkeypatch.setattr(Trainer, "_backbone_hold", lambda self, seg_mode=None: None)
    _run([p[0], td, d], tmp_path / "bad")
    r = _tool(tmp_path / "bad", _manifest(tmp_path / "bad", [p[0], td, d]), "a")
    cov = read_json(tmp_path / "bad" / "a_coverage.json")
    assert r.returncode != 0 and any("layers 2..K moved" in f["reason"] for f in cov["failed"]), cov["failed"]


def test_dsfrozen_compact_schedule_resumes(tmp_path):
    from resume_harness import compare_interrupted
    from test_v31 import _lin, _traj, _x25
    p = _traj()
    d = _x25(_lin(p[-1]))
    dlp = _compact(p[0], d, "compact_dsfrozen_lift", "C1_phase", [6, 6, 3, 3], [False, False, True, True], DS,
                   [True, True, False, False])
    rep = compare_interrupted(p + [d, dlp], tmp_path, fractions=(0.3, 0.7))
    assert rep["interrupted_at_polls"] and rep["equal"], rep


def test_dsfrozen_trajectory_resumes(tmp_path):
    from resume_harness import compare_interrupted
    from test_v31 import _traj
    p = _traj()
    td = resolve({**p[-1], "train": {**p[-1]["train"], **DS}})
    rep = compare_interrupted([p[0], td], tmp_path, fractions=(0.3, 0.7))
    assert rep["interrupted_at_polls"] and rep["equal"], rep


def test_freeze_backbone_config_rules():
    from test_v31 import _lin, _traj, _x25
    p = _traj()
    d = _x25(_lin(p[-1]))
    with pytest.raises(ConfigError):
        resolve({**p[-1], "train": {**p[-1]["train"], "freeze_backbone": "upstream"}})
    with pytest.raises(ConfigError):
        resolve({**p[-1], "train": {**p[-1]["train"], "freeze_backbone": "downstream", "freeze": "original_frozen"}})
    with pytest.raises(ConfigError):
        resolve({**p[0], "train": {**p[0]["train"], "freeze_backbone": "downstream"}})       # a baseline job
    # a freeze schedule holding the backbone only is valid; one naming nothing to hold is not
    _compact(p[0], d, "x", "C1_reset", [12, 6], [False, True], DS, [True, False])
    with pytest.raises(ConfigError):
        _compact(p[0], d, "x", "C1_reset", [12, 6], [False, True], LOG, [True, False])
    both = _compact(p[0], d, "x", "C1_reset", [12, 6], [False, True],
                    {**DS, "freeze_inputs": "shortcut"}, [True, False])
    assert both["train"]["freeze_backbone"] == "downstream" and both["train"]["freeze_inputs"] == "shortcut"


# ----------------------------------------------------------------------------- units

def test_code_sets_and_residual_split_analytic():
    import selective_reversal as SR
    assert SR.all_codes(2) == ["0-0", "0-1", "1-0", "1-1"]
    assert SR.code_set("all", 3) == SR.all_codes(3) and SR.code_set("auto", 3) == SR.auto_codes(3)
    assert SR.code_set("0-1-1,1-1-1", 3) == ["0-1-1", "1-1-1"]
    v = torch.tensor([[1.0, 0.0, 0.0], [0.0, 2.0, 0.0]], dtype=torch.float64)
    w = torch.tensor([[0.0, 3.0, 0.0], [0.0, 0.0, 0.0]], dtype=torch.float64)
    C1 = 2.0 * v + w                                       # row 0: scaled by 2 plus an orthogonal residual
    s, res, st = SR.row_scale_residual(v, C1)
    assert torch.allclose(s, torch.tensor([2.0, 2.0], dtype=torch.float64)) and torch.allclose(res, w)
    assert st["residual_energy_fraction"] == pytest.approx(9.0 / (4.0 + 9.0 + 16.0))
    assert st["residual_norm_vs_change"] == pytest.approx(3.0 / (1.0 + 9.0 + 4.0) ** 0.5)
    assert ((v * res).sum(1).abs() < 1e-12).all()       # each residual row orthogonal to f0's row
    s, res, st = SR.row_scale_residual(v, 3.0 * v)
    assert st["residual_energy_fraction"] == 0.0


def test_cross_measure_registry_pairs_and_missing():
    import selective_reversal as SR
    dj = {("fixed_dsfrozen", "treated", "full", "c", 1, 0)}
    base = {"variant": "fixed_dsfrozen", "arm": "treated", "cell": "c", "data_draw": 1, "optimizer_seed": 0,
            "run_id": "A", "draw_set": "x"}
    out = {"codes": [{**base, "state": "abrupt", "code": "0-1-1-1-1", "test_err": 0.2},
                     {**base, "state": "abrupt", "code": "1-1-1-1-1", "test_err": 0.3}],
           "native": [{**base, "state": "repaired", "measure": "native_endpoint", "test_err": 0.25}],
           "decomposition": [], "decomposition_trace": [], "scale": [], "codes_implants": [], "trace": []}
    rows, _, _, prob = SR.registry_contrasts("wave24", out, dj, 12)
    got = {x["contrast"]: x["value"] for x in rows}
    assert got["extraction_vs_repaired_native_dsfrozen"] == pytest.approx(0.05)
    assert got["extraction_vs_f0_dsfrozen"] == pytest.approx(0.1)
    miss = {p["contrast"] for p in prob if p["problem"] == "missing"}
    assert "extraction_vs_expanded_native_dsfrozen" in miss and "extraction_vs_causal_scale_selected_dsfrozen" in miss
    nojob = {p["contrast"] for p in prob if p["problem"] == "a side has no job in the manifest"}
    assert "extraction_vs_compact_extraction_at_2U_dsfrozen" in nojob and "repair_change_ordinary" in nojob


# ----------------------------------------------------------------------------- wave 24

def test_wave24_v44_structure():
    from collections import Counter
    from cop.orchestration.manifest import generate
    from cop.orchestration.wave13 import info_access
    m = generate([24], "full")
    ents = [e["cfg"] for e in m.entries.values()]
    assert len(ents) == 144 and {c["data"]["data_seed"] for c in ents} == set(range(319, 325))
    comp = [c for c in ents if c["kind"] == "continue"]
    assert all(c["continue"]["fork_audit"] and c["train"]["log_update_norms"] for c in comp)
    assert Counter((c["design"]["variant"], c["design"]["arm"], tuple(c["continue"]["segments"]),
                    tuple(c["continue"]["segment_reset"]), tuple(c["continue"]["freeze_segments"]),
                    c["train"]["freeze_backbone"]) for c in comp) == {
        ("compact", "C1", (4000, 3000), (False, False), (), "none"): 12,
        ("compact", "C1_reset", (4000, 3000), (False, True), (), "none"): 12,
        ("compact", "C1_phase", (2000, 2000, 200, 2800), (False, False, True, True), (), "none"): 12,
        ("compact_dsfrozen_lift", "C1_phase", (2000, 2000, 200, 2800), (False, False, True, True),
         (True, True, False, False), "downstream"): 12,
        ("compact_dsfrozen_lift", "C1_reset", (4000, 3000), (False, True), (True, False), "downstream"): 12}
    tr = [c for c in ents if c["kind"] == "trajectory"]
    assert Counter(c["train"]["freeze_backbone"] for c in tr) == {"none": 12, "downstream": 12}
    assert all(c["train"]["freeze_inputs"] == "none" for c in ents)          # the shortcut column trains
    rem = [c for c in ents if c["kind"] == "dissipation"]
    assert len(rem) == 48 and all(c["train"]["freeze_backbone"] == "none" for c in rem)
    assert all(c["train"]["log_update_norms"] for c in ents if c["kind"] != "baseline")
    assert {sum(c["continue"]["segments"]) for c in comp} == {7000}
    assert all(info_access(c)["backbone_hold"] for c in ents if c["train"]["freeze_backbone"] != "none")
    assert all(info_access(c)["backbone_hold"] is None for c in ents if c["train"]["freeze_backbone"] == "none")
    # every arm a wave-24 contrast names is in the manifest
    import selective_reversal as SR
    va = {(c["design"]["variant"], c["design"]["arm"]) for c in ents if c.get("design", {}).get("arm")}
    for name, kind, A, B in SR.REGISTRIES["wave24"]:
        for s_ in (A, B):
            assert s_[1] == "trajectory" or (s_[0], s_[1]) in va, (name, s_)


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA device required")
def test_cuda_downstream_hold_trajectory_and_compact_schedule(tmp_path):
    """the GPU path of the v44 training addition: the downstream hold in a trajectory and in a compact freeze
    schedule; an interrupted run equals an uninterrupted one."""
    from resume_harness import compare_interrupted
    from test_v31 import _lin, _traj, _x25
    p = _traj()
    td = resolve({**p[-1], "train": {**p[-1]["train"], **DS}})
    d = _x25(_lin(p[-1]))
    dlr = _compact(p[0], d, "compact_dsfrozen_lift", "C1_reset", [12, 6], [False, True], DS, [True, False])
    rep = compare_interrupted([p[0], td, p[-1], d, dlr], tmp_path, fractions=(0.3, 0.7), ex={"device": "cuda"})
    assert rep["interrupted_at_polls"] and rep["equal"], rep
