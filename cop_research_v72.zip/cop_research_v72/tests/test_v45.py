"""v45: the freezing factorial (wave 25) and its analysis: the minibatch-stream audit (train.audit_batches), the
training-cost parts under parameter holds, the extraction checks and saved extractions, the paired-stream audit,
the residual-versus-magnitude controls, the 2U extraction table and the wave-25 registry with its two primary
questions (the 'interaction' kind)."""
from __future__ import annotations

import csv
import json
import os
import subprocess
import sys
from pathlib import Path

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "audit_v5/tools"))
from cop.config import ConfigError, resolve, run_id  # noqa: E402
from cop.utils import read_json  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
TOOL = str(ROOT / "audit_v5/tools/selective_reversal.py")
AUD = {"log_update_norms": True, "audit_batches": True}
HOLDS = {"A": {}, "B": {"freeze_inputs": "shortcut"}, "C": {"freeze_backbone": "downstream"},
         "D": {"freeze_inputs": "shortcut", "freeze_backbone": "downstream"}}
VAR = {"A": "A_free", "B": "B_scfrozen", "C": "C_dsfrozen", "D": "D_bothfrozen"}
LIFT = {"freeze_inputs": "none", "freeze_backbone": "none"}
ALL = ("--codes", "all", "--trace", "--trace-codes", "auto", "--codes-at-2u", "--implant-codes", "--decompose",
       "--cross", "--scale-controls", "--displacement", "--paired-streams", "--contrasts", "wave25")


def _run(cfgs, d):
    from test_v15 import _run as r
    return r(cfgs, d)


def _rows(path):
    t = Path(path).read_text()
    return [] if t.strip() == "empty" else list(csv.DictReader(open(path)))


def _tool(root, man, prefix, *extra):
    return subprocess.run([sys.executable, TOOL, str(root), str(root / prefix), "--manifest", str(man), "--strict",
                           "--device", "cpu", *extra], capture_output=True, text=True, env=dict(os.environ))


def _traj(k):
    from test_v31 import _traj as t
    p = t()
    return p, resolve({**p[-1], "train": {**p[-1]["train"], **AUD, **HOLDS[k]}})


def _panel(root, run=True, conds="ABCD"):
    """a miniature wave 25: one f0, the four expansions (U = 6, 2U = 12), their removals with both holds lifted,
    and the four compact controls held for 2U then released, with the removal's resets."""
    from test_v31 import _lin, _manifest, _x25
    from test_v44 import _compact
    p, _ = _traj("A")
    T = {k: _traj(k)[1] for k in conds}
    R = {k: _x25(resolve({**_lin(T[k]), "train": {**T[k]["train"], **LIFT}}), variant=VAR[k]) for k in conds}
    Cc = {k: _compact(p[0], R[conds[0]], f"compact_{k}", "C1_phase", [6, 6, 3, 3], [False, False, True, True],
                      {**AUD, **HOLDS[k]}, [True, True, False, False] if HOLDS[k] else None) for k in conds}
    if run:
        _run([p[0], *T.values()], root)
        for c in [*R.values(), *Cc.values()]:
            _run([c], root)
    return p[0], T, R, Cc, _manifest(root, [p[0], *T.values(), *R.values(), *Cc.values()])


def test_miniature_wave25_end_to_end(tmp_path):
    import selective_reversal as SR
    from cop.graph.graph import GraphNet
    p0, T, R, Cc, man = _panel(tmp_path)
    runs = tmp_path / "runs"
    r = _tool(tmp_path, man, "a", *ALL, "--save-extractions", str(tmp_path / "ext"))
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-3000:]
    cov = read_json(tmp_path / "a_coverage.json")
    assert cov["passed"] and cov["analysed"] == 8 and not cov["registry"]["problems"]
    assert cov["paired_stream_failures"] == [] and cov["paired_stream_groups"] == 1
    # ---- the paired streams: one stream for all four expansions and the four compact controls at 2U
    ps = _rows(tmp_path / "a_paired_streams.csv")
    assert {x["batch_id_hash"] for x in ps} and len({x["batch_id_hash"] for x in ps}) == 1
    assert len({x["insertion_init_hash"] for x in ps if x["role"] == "trajectory"}) == 1
    # ---- the registry: every declared contrast, the primaries marked, the interaction from its named rows
    reg = _rows(tmp_path / "a_registry_by_setting.csv")
    assert {x["contrast"] for x in reg} == {c[0] for c in SR.REGISTRIES["wave25"]}
    assert {x["contrast"] for x in reg if x["role"] == "primary"} == SR.REGISTRY_PRIMARY["wave25"]
    codes = {(x["run_id"], x["state"], x["code"]): float(x["test_err"]) for x in _rows(tmp_path / "a_codes.csv")}
    tr = {(x["run_id"], x["code"]): float(x["test_err"]) for x in _rows(tmp_path / "a_trace.csv")
          if x["updates_since_f0"] == "12"}
    x1 = "0-1-1-1-1"
    eB, eD = codes[(run_id(R["B"]), "abrupt", x1)], codes[(run_id(R["D"]), "abrupt", x1)]
    cB, cD = tr[(run_id(Cc["B"]), x1)], tr[(run_id(Cc["D"]), x1)]
    it = next(x for x in reg if x["contrast"] == "P2_interaction_B_minus_D")
    assert float(it["value"]) == pytest.approx((cB - eB) - (cD - eD), abs=1e-15)
    p1 = next(x for x in reg if x["contrast"] == "P1_B_extraction_vs_compact_B_extraction")
    assert float(p1["value"]) == pytest.approx(cB - eB, abs=1e-15) and p1["b_run_id"] == run_id(Cc["B"])
    assert _rows(tmp_path / "a_registry_by_draw.csv")
    # ---- the 2U extraction table: five models for an expansion, the compact control's four
    ex = _rows(tmp_path / "a_extraction_2u.csv")
    for k in "ABCD":
        assert {x["model"] for x in ex if x["run_id"] == run_id(R[k])} == {m[0] for m in SR.EXTRACTION_MODELS}
        assert {x["model"] for x in ex if x["run_id"] == run_id(Cc[k])} == \
            {m[0] for m in SR.EXTRACTION_MODELS} - {"extraction_with_additions"}
    for f in ("test_err", "val_err", "shift_err", "rare_err", "shortcut_flip_rate", "macs_backward_aware"):
        assert all(x.get(f) not in (None, "") for x in ex), f
    # ---- the saved extractions: layers 2..K exactly f0's, the first layer exactly the state's, no addition
    sv = _rows(tmp_path / "a_extractions_saved.csv")
    assert len(sv) == 4 * 2 + 4
    f0 = torch.load(runs / run_id(p0) / "ckpt" / "baseline.pt", weights_only=False)["model"]
    L = SR.backbone_layers(GraphNet.from_checkpoint(f0))
    for k in "ABCD":
        e = torch.load(tmp_path / "ext" / f"{run_id(T[k])}__2U_extraction_additions_deleted.pt",
                       weights_only=False)
        g = GraphNet.from_checkpoint(e["model"])
        assert not any(g.nodes[n].owner for n in g.live_nodes())
        fin = torch.load(runs / run_id(T[k]) / "ckpt" / "final.pt", weights_only=False)["model"]["state"]
        for kk, v in e["model"]["state"].items():
            lay = kk.split(".")[1]
            if lay in L[1:]:
                assert torch.equal(v, f0["state"][kk]), kk
            elif lay == L[0]:
                assert torch.equal(v, fin[kk]), kk
        assert e["code"] == x1 and e["additions"] == "deleted"
    # ---- the holds: layers 2..K and the shortcut column exactly f0's at 2U where held (checks and trace)
    chk = {(x["run_id"], x["state"]): x for x in _rows(tmp_path / "a_checks.csv")}
    for k in "CD":
        assert float(chk[(run_id(R[k]), "abrupt")]["downstream_change_max_abs"]) == 0.0
    assert float(chk[(run_id(R["A"]), "abrupt")]["downstream_change_max_abs"]) > 0.0
    # ---- compute: 2U for the expansion and its compact control; the parts add up; holds discard gradient work
    cp = {(x["run_id"], x["state"]): x for x in _rows(tmp_path / "a_compute.csv")}
    for k in "ABCD":
        a_ = cp[(run_id(R[k]), "abrupt")]
        assert int(a_["cost_updates"]) == 12
        assert int(a_["macs_backward_aware"]) == sum(int(a_[f"macs_{q}"]) for q in ("forward", "input_grad",
                                                                                     "param_grad"))
        assert (int(a_["macs_param_grad_discarded"]) > 0) == (k != "A")
        rp = cp[(run_id(R[k]), "repaired")]
        assert int(rp["cost_updates"]) == 12 + 6 and int(rp["macs_param_grad_discarded"]) == \
            int(a_["macs_param_grad_discarded"])                     # the removal holds nothing
    ctr = [x for x in _rows(tmp_path / "a_trace.csv") if x["run_id"] == run_id(Cc["D"])
           and x["updates_since_f0"] == "12"]
    assert ctr and int(ctr[0]["cost_updates"]) == 12 and int(ctr[0]["macs_param_grad_discarded"]) > 0
    # the expansion costs more than its compact control over the same 2U (the additions compute too)
    assert int(cp[(run_id(R["A"]), "abrupt")]["macs_forward"]) > int(ctr[0]["macs_forward"])
    # ---- the residual-versus-magnitude controls: thirteen; orthogonality and reconstruction recorded
    sc = _rows(tmp_path / "a_scale.csv")
    assert SR.N_SCALE_CONTROLS == 13 and len(sc) == 13 * len(chk)
    by = {(x["run_id"], x["state"], x["control"]): x for x in sc}
    for (rid, st, c), x in by.items():
        if c != "causal_transplant":
            continue
        assert float(x["decomposition_orthogonality_max_abs_cos"]) <= 1e-9
        pr = by[(rid, st, "f0_causal_plus_residual")]
        dn = by[(rid, st, "f0_causal_dir_at_norm_of_plus_residual")]
        fn = by[(rid, st, "f0_causal_plus_residual_at_f0_norm")]
        # the assembled candidates: f0's directions at exactly the row norms of w0 + r; w0 + r at f0's (v46: the
        # ideal float64 construction exactly; the evaluated weights, in the model's dtype, to its precision)
        assert float(dn["ideal_candidate_row_norm_mean"]) == pytest.approx(float(pr["ideal_candidate_row_norm_mean"]),
                                                                           rel=1e-9)
        assert float(fn["ideal_candidate_row_norm_vs_f0_mean"]) == pytest.approx(1.0, rel=1e-9)
        assert float(dn["candidate_row_norm_mean"]) == pytest.approx(float(pr["candidate_row_norm_mean"]), rel=1e-5)


def test_holds_are_exact_every_step_and_do_not_detach(tmp_path, monkeypatch):
    """at every optimizer step of a held expansion, each held tensor (weights and biases) equals its value at the
    segment start and carries a zero gradient after the hold; the raw gradient that reaches the first layer and the
    additions through the held layers is bitwise the unheld expansion's at the first update."""
    from cop.train.trainer import Trainer
    raw: dict = {}
    seen = {"steps": 0, "held_checked": 0}
    orig_bh, orig_fz = Trainer._backbone_hold, Trainer._input_freeze

    def hooks(self, tag):
        if getattr(self, "_t45_hooked", False) or not any(n.owner for n in self.model.nodes.values()):
            return                                # f0's own training has no additions: not an expansion
        self._t45_hooked = True
        pk0, _ = self._first_layer()
        for pk in [pk0] + sorted({n.pkey for n in self.model.nodes.values() if n.owner and n.pkey}):
            for nm, p_ in self.model.mods[pk].named_parameters():
                p_.register_hook(lambda g, key=f"{pk}.{nm}": raw.setdefault(tag, {}).setdefault(key, g.clone())
                                 if key not in raw.get(tag, {}) else None)

    def bh(self, seg_mode=None):
        out = orig_bh(self, seg_mode)
        self._t45_bh = out
        hooks(self, self.t.get("freeze_backbone", "none") + "/" + self.t.get("freeze_inputs", "none"))
        return out

    def fz(self, seg_mode=None):
        out = orig_fz(self, seg_mode)
        self._t45_fz = out
        return out
    monkeypatch.setattr(Trainer, "_backbone_hold", bh)
    monkeypatch.setattr(Trainer, "_input_freeze", fz)
    orig_nb = Trainer._update_norms_before

    def before_step(self, ng):                   # called after the holds zero the gradients, before opt.step()
        b_ = getattr(self, "_t45_bh", None)
        if b_ is not None:
            for p_, v_ in zip(b_["params"], b_["values"]):
                assert torch.equal(p_.detach(), v_), "a held tensor moved"
                assert p_.grad is None or not bool(p_.grad.any()), "a held tensor has a gradient"
            seen["held_checked"] += 1
        f_ = getattr(self, "_t45_fz", None)
        if f_ is not None:
            assert torch.equal(f_["W"].detach()[:, f_["cols"]], f_["values"])
            assert not bool(f_["W"].grad[:, f_["cols"]].any())
        seen["steps"] += 1
        return orig_nb(self, ng)
    monkeypatch.setattr(Trainer, "_update_norms_before", before_step)
    p, tA = _traj("A")
    _, tD = _traj("D")
    _run([p[0], tA, tD], tmp_path)
    assert seen["steps"] > 0 and seen["held_checked"] > 0
    a_, d_ = raw["none/none"], raw["downstream/shortcut"]
    assert set(a_) == set(d_) and len(a_) > 2
    for key in a_:                               # the first update: same model, same batch, same raw gradient
        assert torch.equal(a_[key], d_[key]), key
    assert any(bool(v.abs().sum() > 0) for k_, v in d_.items() if not k_.startswith(sorted(a_)[0].split(".")[0]))


def test_the_step_hook_sits_between_the_holds_and_the_update():
    """the per-step hold test intercepts _update_norms_before; it relies on the trainer calling it after the holds
    zero the gradients and before the optimizer step (else the interception would check the wrong moment)."""
    src = (ROOT / "cop/train/trainer.py").read_text()
    i_zero, i_nb = src.index("p_.grad.zero_()"), src.index("nb = self._update_norms_before(ng)")
    assert i_zero < i_nb < src.index("self.opt.step()", i_nb)


def test_mac_parts_under_holds():
    from cop.graph.graph import GraphNet
    from cop.train.trainer import backward_aware_macs, training_mac_parts
    from cop.graph.accounting import count_macs
    from test_v31 import _traj as t
    import selective_reversal as SR
    p = t()
    tmp = Path(os.environ.get("TMPDIR", "/tmp")) / f"v45mac{os.getpid()}"
    _run(p, tmp)
    ck = torch.load(tmp / "runs" / run_id(p[-1]) / "ckpt" / "final.pt", weights_only=False)
    g = GraphNet.from_checkpoint(ck["model"])
    L = SR.backbone_layers(g)
    free = training_mac_parts(g, 1, {}, {})
    assert free["forward"] + free["input_grad"] + free["param_grad"] == backward_aware_macs(g, 1, {})
    assert free["param_grad_discarded"] == 0
    held = training_mac_parts(g, 1, {}, {pk: 1.0 for pk in L[1:]})
    per = count_macs(g, 1)["by_node"]
    want = sum(per.get(n, 0) for n in g.live_nodes() if g.nodes[n].pkey in L[1:])
    assert held["param_grad_discarded"] == want > 0
    assert {k: held[k] for k in ("forward", "input_grad", "param_grad")} == \
        {k: free[k] for k in ("forward", "input_grad", "param_grad")}   # holds keep the computation
    col = training_mac_parts(g, 1, {}, {L[0]: 0.25})
    n0 = [n for n in g.live_nodes() if g.nodes[n].pkey == L[0]]
    assert col["param_grad_discarded"] == round(0.25 * sum(per.get(n, 0) for n in n0))
    # the trainer's cumulative parts add up to its backward-aware counter (a run entirely under v45 code)
    st = ck["trainer"]["state"]
    assert sum(st["mac_parts"][k] for k in ("forward", "input_grad", "param_grad")) == st["train_macs_bwd"]


@pytest.mark.parametrize("which", ["trajectory_D", "compact_D", "removal_from_D"])
def test_v45_jobs_resume_with_their_holds(tmp_path, which):
    from resume_harness import compare_interrupted
    from test_v31 import _lin, _x25
    from test_v44 import _compact
    p, tD = _traj("D")
    if which == "trajectory_D":
        cfgs = [p[0], tD]
    elif which == "removal_from_D":
        cfgs = [p[0], tD, _x25(resolve({**_lin(tD), "train": {**tD["train"], **LIFT}}), variant="D_bothfrozen")]
    else:
        d = _x25(_lin(p[-1]))
        cfgs = p + [d, _compact(p[0], d, "compact_D", "C1_phase", [6, 6, 3, 3], [False, False, True, True],
                                {**AUD, **HOLDS["D"]}, [True, True, False, False])]
    rep = compare_interrupted(cfgs, tmp_path, fractions=(0.3, 0.7))
    assert rep["interrupted_at_polls"] and rep["equal"], rep
    # the resumed job kept its stream audit and its holds (records, counters) exactly
    A = sorted((tmp_path / "A" / "runs" / run_id(cfgs[-1]) / "ckpt").glob("*.pt"))
    B_ = tmp_path / "B" / "runs" / run_id(cfgs[-1]) / "ckpt"
    for f in A:
        a_ = torch.load(f, weights_only=False)
        b_ = torch.load(B_ / f.name, weights_only=False)
        for src in ("trainer", "extra"):
            sa = ((a_.get(src) or {}).get("state") if src == "trainer" else a_.get("extra")) or {}
            sb = ((b_.get(src) or {}).get("state") if src == "trainer" else b_.get("extra")) or {}
            for k in ("batch_id_hash", "batches_drawn", "mac_parts", "backbone_hold_record", "input_freeze_record",
                      "compute"):
                assert sa.get(k) == sb.get(k), (f.name, src, k)


def test_audit_batches_config_and_double_count():
    from test_v31 import _traj as t
    p = t()
    with pytest.raises(ConfigError):
        resolve({**p[-1], "train": {**p[-1]["train"], "audit_batches": "yes"}})
    src = (ROOT / "cop/experiments/continuation.py").read_text()
    assert 'cc.get("fork_audit") and not cfg["train"].get("audit_batches", False)' in src
    src = (ROOT / "cop/experiments/dissipation.py").read_text()
    assert 'if not cfg["train"].get("audit_batches", False):' in src


def test_audited_stream_matches_the_v43_construction(tmp_path):
    """the trainer's chain and the v43 continuation chain are the same construction: a compact control audited
    either way gives the same hash at every segment start."""
    from test_v31 import _lin, _traj as t, _x25
    from test_v44 import _compact
    p = t()
    d = _x25(_lin(p[-1]))
    old = _compact(p[0], d, "x", "C1_phase", [6, 6, 3, 3], [False, False, True, True], {"log_update_norms": True})
    new = _compact(p[0], d, "x", "C1_phase", [6, 6, 3, 3], [False, False, True, True], AUD)
    _run(p + [d, old, new], tmp_path)
    fo = json.load(open(tmp_path / "runs" / run_id(old) / "continue_result.json"))["fork_audit"]["starts"]
    fn = json.load(open(tmp_path / "runs" / run_id(new) / "continue_result.json"))["fork_audit"]["starts"]
    assert [(x["update"], x["batch_id_hash"], x["batches_drawn"]) for x in fo] == \
        [(x["update"], x["batch_id_hash"], x["batches_drawn"]) for x in fn]


# ----------------------------------------------------------------------------- units

def test_residual_magnitude_blocks_analytic():
    import selective_reversal as SR
    C0 = torch.tensor([[3.0, 0.0], [0.0, 0.0], [1.0, 1.0]], dtype=torch.float64)
    C1 = torch.tensor([[6.0, 4.0], [0.0, 2.0], [2.0, 2.0]], dtype=torch.float64)
    b, a, r, rec = SR.residual_magnitude_blocks(C0, C1)
    assert torch.allclose(a, torch.tensor([2.0, 1.0, 2.0], dtype=torch.float64))
    assert torch.allclose(r, torch.tensor([[0.0, 4.0], [0.0, 2.0], [0.0, 0.0]], dtype=torch.float64))
    assert rec["reconstruction_max_abs"] == 0.0 and rec["orthogonality_max_abs_cos"] == 0.0
    assert rec["degenerate_rows"] == 1 and rec["f0_zero_rows_kept_zero"] == 1
    assert torch.allclose(b["plus_residual"], C0 + r)
    # f0's directions at the row norms of w0 + r: row 0 |(3, 4)| = 5, row 1 stays zero, row 2 unchanged
    assert torch.allclose(b["f0_dir_norm_of_plus_res"],
                          torch.tensor([[5.0, 0.0], [0.0, 0.0], [1.0, 1.0]], dtype=torch.float64))
    # w0 + r at f0's row norms: row 0 (3, 4) * 3 / 5; row 1 (0, 2) * 0 / 2 = zero
    assert torch.allclose(b["plus_residual_f0_norm"],
                          torch.tensor([[1.8, 2.4], [0.0, 0.0], [1.0, 1.0]], dtype=torch.float64))
    nb = SR.block_norms(b["f0_dir_norm_of_plus_res"], C0)
    assert nb["candidate_causal_fro_vs_f0"] == pytest.approx((25 + 2) ** 0.5 / (9 + 2) ** 0.5)


def test_paired_stream_failures_detects_each_break():
    """v46 reworked the audit (manifest membership, one f0 per group, update and batch counts); the full set of
    negative cases is in test_v46.  Here: complete passes, and the v45 cases still fail."""
    import selective_reversal as SR
    from test_v46 import _streams
    rows, dj = _streams()
    assert SR.paired_stream_failures(rows, dj, 12) == []
    for i, f in ((2, "batch_id_hash"), (2, "insertion_init_hash"), (2, "config_apart_from_holds")):
        bad = [dict(r) for r in rows]
        bad[i][f] = "x"
        assert SR.paired_stream_failures(bad, dj, 12), f
    bad = [dict(r) for r in rows]
    bad[5]["batch_id_hash"] = "x"
    assert any(x["check"].startswith("compact stream") for x in SR.paired_stream_failures(bad, dj, 12))


def test_interaction_registry_arithmetic_and_missing():
    import selective_reversal as SR
    dj = {(SR.V45_VAR[k], "treated", "full", "c", 1, 0) for k in "ABCD"} | \
        {(f"compact_{k}", "C1_phase", "control", "c", 1, 0) for k in "ABCD"}
    m = {"cell": "c", "data_draw": 1, "optimizer_seed": 0, "draw_set": "x"}
    err = {"A": (0.20, 0.22), "B": (0.15, 0.21), "C": (0.25, 0.24), "D": (0.20, 0.205)}
    out = {"codes": [{**m, "variant": SR.V45_VAR[k], "arm": "treated", "state": "abrupt", "code": "0-1-1-1-1",
                      "test_err": e, "run_id": f"r{k}"} for k, (e, _) in err.items()],
           "trace": [{**m, "variant": f"compact_{k}", "arm": "C1_phase", "updates_since_f0": 12, "code": "0-1-1-1-1",
                      "test_err": c, "run_id": f"c{k}"} for k, (_, c) in err.items()],
           "decomposition": [], "decomposition_trace": [], "native": [], "scale": [], "codes_implants": []}
    rows, bd, sm, prob = SR.registry_contrasts("wave25", out, dj, 12)
    got = {x["contrast"]: x for x in rows}
    assert got["P2_interaction_B_minus_D"]["value"] == pytest.approx((0.21 - 0.15) - (0.205 - 0.20))
    assert got["P1_B_extraction_vs_compact_B_extraction"]["value"] == pytest.approx(0.06)
    assert got["S_interaction_A_minus_C"]["value"] == pytest.approx((0.22 - 0.20) - (0.24 - 0.25))
    assert got["P2_interaction_B_minus_D"]["role"] == "primary" and got["S_interaction_A_minus_C"]["role"] == \
        "secondary"
    miss = {x["contrast"] for x in prob if x["problem"] == "missing"}
    assert "P1_B_extraction_vs_f0" in miss and "P2_interaction_B_minus_D" not in miss
    out["trace"] = out["trace"][:-1]                   # compact_D gone: the interaction reports its missing side
    _, _, _, prob = SR.registry_contrasts("wave25", out, dj, 12)
    x = next(x for x in prob if x["contrast"] == "P2_interaction_B_minus_D")
    assert x["problem"] == "missing" and x["side"] == "B2"


# ----------------------------------------------------------------------------- wave 25

def test_wave25_v45_structure():
    from collections import Counter
    from cop.orchestration.manifest import WAVES, generate
    import selective_reversal as SR
    m = generate([25], "full")
    ents = [e["cfg"] for e in m.entries.values()]
    assert len(ents) == 312
    draws = {c["data"]["data_seed"] for c in ents}
    assert draws == set(range(325, 337))
    for w in WAVES:                                   # never used by any earlier wave, at any scale
        if w >= 25:
            continue
        for sc in ("full", "pilot", "smoke"):
            try:
                mm = generate([w], sc)
            except Exception:                         # noqa: BLE001  (a wave without that scale)
                continue
            assert not draws & {(e["cfg"].get("data") or {}).get("data_seed") for e in mm.entries.values()}, (w, sc)
    assert Counter(c["kind"] for c in ents) == {"baseline": 24, "trajectory": 96, "dissipation": 96,
                                               "continue": 96}
    tr = [c for c in ents if c["kind"] == "trajectory"]
    assert Counter((c["train"]["freeze_inputs"], c["train"]["freeze_backbone"]) for c in tr) == {
        ("none", "none"): 24, ("shortcut", "none"): 24, ("none", "downstream"): 24, ("shortcut", "downstream"): 24}
    groups = {}
    for c in tr:
        x = json.loads(json.dumps(c))
        x["train"].pop("freeze_inputs")
        x["train"].pop("freeze_backbone")
        groups.setdefault((c["data"]["data_seed"], c["seeds"]["optimizer"]), set()).add(json.dumps(x, sort_keys=True))
    assert len(groups) == 24 and all(len(v) == 1 for v in groups.values())
    rem = [c for c in ents if c["kind"] == "dissipation"]
    assert all(c["train"]["freeze_inputs"] == "none" and c["train"]["freeze_backbone"] == "none" for c in rem)
    comp = [c for c in ents if c["kind"] == "continue"]
    assert Counter((c["design"]["variant"], c["train"]["freeze_inputs"], c["train"]["freeze_backbone"],
                    tuple(c["continue"]["freeze_segments"]), tuple(c["continue"]["segment_reset"]),
                    tuple(c["continue"]["segments"])) for c in comp) == {
        ("compact_A", "none", "none", (), (False, False, True, True), (2000, 2000, 200, 2800)): 24,
        ("compact_B", "shortcut", "none", (True, True, False, False), (False, False, True, True),
         (2000, 2000, 200, 2800)): 24,
        ("compact_C", "none", "downstream", (True, True, False, False), (False, False, True, True),
         (2000, 2000, 200, 2800)): 24,
        ("compact_D", "shortcut", "downstream", (True, True, False, False), (False, False, True, True),
         (2000, 2000, 200, 2800)): 24}
    assert all(c["train"]["audit_batches"] and c["train"]["log_update_norms"] for c in ents if c["kind"] != "baseline")
    assert all(c["continue"]["fork_audit"] for c in comp)
    va = {(c["design"]["variant"], c["design"]["arm"]) for c in ents if (c.get("design") or {}).get("arm")}
    for name, kind, A, B in SR.REGISTRIES["wave25"]:
        for s_ in ((A[0], A[1], B[0], B[1]) if kind == "interaction" else (A, B)):
            assert s_[1] == "trajectory" or (s_[0], s_[1]) in va, (name, s_)


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA device required")
def test_cuda_both_holds_trajectory_and_compact_resume(tmp_path):
    """the GPU path of the v45 training additions: both holds together with the stream audit, in a trajectory
    and in a compact freeze schedule; an interrupted run equals an uninterrupted one."""
    from resume_harness import compare_interrupted
    from test_v31 import _lin, _x25
    from test_v44 import _compact
    p, tD = _traj("D")
    d = _x25(_lin(p[-1]))
    cD = _compact(p[0], d, "compact_D", "C1_phase", [6, 6, 3, 3], [False, False, True, True], {**AUD, **HOLDS["D"]},
                  [True, True, False, False])
    rep = compare_interrupted([p[0], tD, p[-1], d, cD], tmp_path, fractions=(0.3, 0.7), ex={"device": "cuda"})
    assert rep["interrupted_at_polls"] and rep["equal"], rep
