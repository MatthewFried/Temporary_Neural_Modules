"""v46: the v45 review's fixes, tested on REAL analysis outputs, not mocks: the wave-25 evidence contract (the
launcher's exact required list and the analysis' exact options), the direct residual-versus-magnitude contrasts,
norms measured on the evaluated weights, the paired-stream audit's manifest membership, training / extraction
access, costs in the extraction summaries with complete output membership, the confirmation cohort, and the
read-only reuse of a complete v45 panel (unchanged semantics, same run ids)."""
from __future__ import annotations

import csv
import json
import os
import re
import shlex
import subprocess
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "audit_v5/tools"))
from cop.config import run_id  # noqa: E402
from cop.utils import read_json  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
V45_SEMANTIC_HASH = "1f5f72b51291d08a"       # cop/ as shipped in v45-v58 (the panels' training code)


def v45_panels_reusable() -> bool:
    """the current semantics are v45's, or an audit (configs/reuse_audits.json, v59) accepts runs produced by v45's
    semantics for the current code: the earlier panels' baselines, trajectories and keep / linear forks are then
    the jobs these manifests describe (the audit names what changed and why those jobs execute the same code)."""
    import json as _j
    from cop.utils import semantic_code_hash
    sem = semantic_code_hash()
    if sem == V45_SEMANTIC_HASH:
        return True
    doc = _j.loads((ROOT / "configs/reuse_audits.json").read_text())
    return any(a["produced_by_semantic_hash"] == V45_SEMANTIC_HASH and a["accepted_for_semantic_hash"] == sem
               for a in doc["audits"])


def _rows(path):
    t = Path(path).read_text()
    return [] if t.strip() == "empty" else list(csv.DictReader(open(path)))


# v47: scripts/46 is retired (it refuses to run); the wave-25 analysis contract that produced the v46 reports is
# frozen here verbatim from it (LT25_FILES, CODE_OPTS and the reversal25 step's options after --strict)
V46_LT25_FILES = ("coverage.json,codes_summary.csv,codes_by_draw.csv,checks.csv,decomposition_summary.csv,trace.csv,"
                  "cross_summary.csv,cross_contrasts.csv,cross_contrasts_by_draw.csv,scale_summary.csv,"
                  "scale_contrasts.csv,scale_metrics_summary.csv,scale_metrics_by_draw.csv,scale_vectors.csv,"
                  "residual_contrasts.csv,residual_contrasts_by_draw.csv,residual_contrasts_by_setting.csv,"
                  "decomposition_trace.csv,native_summary.csv,displacement.csv,displacement_summary.csv,"
                  "codes_implants.csv,codes_implants_summary.csv,codes_implants_by_draw.csv,"
                  "codes_implants_contrasts.csv,codes_implants_contrasts_by_draw.csv,registry_by_setting.csv,"
                  "registry_by_draw.csv,registry_summary.csv,compact_fork_audit.csv,compute.csv,compute_summary.csv,"
                  "paired_streams.csv,extraction_2u.csv,extraction_2u_by_setting.csv,extraction_2u_by_draw.csv,"
                  "extraction_2u_summary.csv,extractions_saved.csv")
V46_CODE_OPTS = "--codes all --trace --trace-codes auto --codes-at-2u --implant-codes"
V46_REST = ('"${CODE_OPTS[@]}" --decompose --cross --scale-controls --displacement --paired-streams '
            '--save-extractions "$EXT" --contrasts wave25')


def _launcher_contract():
    """the wave-25 analysis' options and required files as the v46 launcher ran them."""
    return V46_LT25_FILES.split(","), shlex.split(V46_CODE_OPTS), shlex.split(V46_REST)


@pytest.fixture(scope="module")
def panel(tmp_path_factory):
    """a miniature wave 25 analysed with the launcher's exact options."""
    import test_v45 as T
    root = tmp_path_factory.mktemp("w25")
    p0, Tj, R, Cc, man = T._panel(root)
    files, code, rest = _launcher_contract()
    args = []
    for t in rest:
        if t == "${CODE_OPTS[@]}":
            args += code
        elif t == "$EXT":
            args.append(str(root / "ext"))
        else:
            args.append(t)
    r = subprocess.run([sys.executable, str(ROOT / "audit_v5/tools/selective_reversal.py"), str(root),
                        str(root / "layer_transplant25"), "--manifest", str(man), "--strict", "--device", "cpu",
                        *args], capture_output=True, text=True)
    return {"root": root, "r": r, "files": files, "R": R, "Cc": Cc, "T": Tj, "p0": p0, "man": man}


def _evidence(root, files, prefix="layer_transplant25"):
    out = root / "ev.json"
    r = subprocess.run([sys.executable, str(ROOT / "scripts/check_evidence.py"), str(out),
                        f"reversal25:0:{root / prefix}:{','.join(files)}"], capture_output=True, text=True)
    return r.returncode, json.loads(out.read_text())["steps"]["reversal25"]


def test_real_wave25_outputs_pass_the_launchers_evidence_contract(panel, tmp_path):
    assert panel["r"].returncode == 0, panel["r"].stdout[-3000:] + panel["r"].stderr[-3000:]
    rc, ev = _evidence(panel["root"], panel["files"])
    assert rc == 0 and ev["ok"], ev
    # why v45's list failed: the legacy C1 / variant-pair tables are empty for wave 25's arms
    for t in ("contrasts", "decomposition_contrasts", "native_contrasts"):
        assert (panel["root"] / f"layer_transplant25_{t}.csv").read_text().strip() == "empty"
        assert f"{t}.csv" not in panel["files"]
    # and the checker still rejects a missing or empty registry output (copies, so the fixture stays intact)
    import shutil
    for mode in ("missing", "empty"):
        d = tmp_path / mode
        d.mkdir()
        for f in panel["files"]:
            shutil.copy2(panel["root"] / f"layer_transplant25_{f}", d / f"layer_transplant25_{f}")
        p = d / "layer_transplant25_registry_summary.csv"
        p.unlink() if mode == "missing" else p.write_text("empty\n")
        rc, ev = _evidence(d, panel["files"])
        assert rc == 1 and not ev["ok"] and ev["missing"][0].startswith("layer_transplant25_registry_summary.csv")


def test_residual_contrasts_from_the_named_rows(panel):
    import selective_reversal as SR
    root = panel["root"]
    sc = {(x["run_id"], x["state"], x["control"]): x for x in _rows(root / "layer_transplant25_scale.csv")}
    rc = _rows(root / "layer_transplant25_residual_contrasts_by_setting.csv")
    assert {x["contrast"] for x in rc} == {c[0] for c in SR.RESIDUAL_CONTRASTS}
    n_states = len({(k[0], k[1]) for k in sc})
    assert len(rc) == 3 * n_states
    for x in rc:
        a = sc[(x["run_id"], x["state"], x["a"])]
        eb = float(a["f0_test_err"]) if x["b"] == "f0" else float(sc[(x["run_id"], x["state"], x["b"])]["test_err"])
        assert float(x["value"]) == pytest.approx(eb - float(a["test_err"]), abs=1e-15)
        assert x["sign"].startswith("positive = ")
    summ = _rows(root / "layer_transplant25_residual_contrasts.csv")
    assert summ and all(x["n_unique_data_draws"] for x in summ)
    assert read_json(root / "layer_transplant25_coverage.json")["residual_contrast_partners_missing"] == []
    # a run and state without one side is a coverage failure, not a silent drop
    rows = [r for r in sc.values() if r["control"] != "f0_causal_dir_at_norm_of_plus_residual"]
    _, missing = SR.residual_contrasts(rows)
    assert {m["contrast"] for m in missing} == {"direction_at_matched_row_norms", "magnitude_alone"}


def test_candidate_norms_are_measured_on_the_evaluated_weights_row_by_row(panel):
    sc = _rows(panel["root"] / "layer_transplant25_scale.csv")
    for x in sc:
        assert x["evaluated_dtype"].startswith("torch.") and x["ideal_candidate_causal_fro"] != ""
        assert x["probe_access"].startswith("feature-group labels")
    for c in ("f0_causal_dir_at_norm_of_plus_residual", "f0_causal_plus_residual_at_f0_norm"):
        xs = [x for x in sc if x["control"] == c]
        assert xs and all(int(x["norm_match_rows_checked"]) > 0 for x in xs)
        assert all(float(x["norm_match_max_abs_diff"]) < 1e-4 for x in xs)
    sel = [x for x in sc if x["control"] == "f0_causal_scale_selected"]
    assert all("selection on" in x["probe_access"] for x in sel)


def test_access_fields_follow_the_lineage(panel):
    ex = _rows(panel["root"] / "layer_transplant25_extraction_2u.csv")
    assert "privileged" not in ex[0]
    for x in ex:
        cond = x["variant"][-1] if x["variant"].startswith("compact_") else x["variant"][0]
        if x["model"] == "f0":
            assert x["training_access"] == "none (f0)"
        elif cond in "BD":                     # the removal job lifted the hold: the trajectory's lineage counts
            assert x["training_access"].startswith("feature layout"), x
        else:
            assert x["training_access"].startswith("none"), x
        assert x["extraction_access"].startswith("none")


def test_extraction_summaries_carry_costs_and_membership_is_complete(panel):
    import selective_reversal as SR
    root = panel["root"]
    cov = read_json(root / "layer_transplant25_coverage.json")
    assert cov["output_membership_failures"] == []
    assert cov["output_membership"] == {"extraction_2u_rows": 4 * 5 + 4 * 4, "extractions_saved": 4 * 2 + 4}
    sm = _rows(root / "layer_transplant25_extraction_2u_summary.csv")
    mets = {x["metric"] for x in sm}
    for m in ("test_err", "cost_updates", "macs_backward_aware", "macs_param_grad_discarded",
              "total_macs_backward_aware_including_f0", "inference_macs_per_example"):
        assert m in mets, m
    assert all("analytic" in x["note"] for x in sm if x["metric"].startswith("macs"))
    bd = _rows(root / "layer_transplant25_extraction_2u_by_draw.csv")
    assert {x["metric"] for x in bd} == mets
    ex = _rows(root / "layer_transplant25_extraction_2u.csv")
    f0r = [x for x in ex if x["model"] == "f0"]
    assert all(int(x["cost_updates"]) == 0 and int(x["macs_backward_aware"]) == 0 for x in f0r)
    exp = [x for x in ex if x["model"] == "expanded_with_additions" and x["source"] == "removal"]
    ext = [x for x in ex if x["model"] == "extraction_first_layer_rest_f0" and x["source"] == "removal"]
    assert int(exp[0]["inference_macs_per_example"]) > int(ext[0]["inference_macs_per_example"])
    # membership failures: a missing row, a duplicate, a wrong update count
    out = {"extraction_2u": [dict(x) for x in ex], "extractions_saved": _rows(root / "layer_transplant25_extractions_saved.csv")}
    for x in out["extractions_saved"]:
        x["reload_reproduces_predictions"] = x["reload_reproduces_predictions"] == "True"
        x["data_draw"], x["optimizer_seed"] = int(x["data_draw"]), int(x["optimizer_seed"])
    for x in out["extraction_2u"]:
        x["data_draw"], x["optimizer_seed"] = int(x["data_draw"]), int(x["optimizer_seed"])
    dj = _design_jobs(panel["man"])
    assert SR.output_membership_failures(out, dj, 12, True, True) == []
    o2 = {**out, "extraction_2u": out["extraction_2u"][1:]}
    assert any("0 rows" in f["check"] for f in SR.output_membership_failures(o2, dj, 12, True, False))
    o3 = {**out, "extraction_2u": out["extraction_2u"] + out["extraction_2u"][:1]}
    assert any("2 rows" in f["check"] for f in SR.output_membership_failures(o3, dj, 12, True, False))
    o4 = {**out, "extraction_2u": [dict(x) for x in out["extraction_2u"]]}
    next(x for x in o4["extraction_2u"] if x["model"] == "extraction_first_layer_rest_f0")["cost_updates"] = 11
    assert any(f["check"] == "updates after f0 at 2U" for f in SR.output_membership_failures(o4, dj, 12, True, False))
    o5 = {**out, "extractions_saved": out["extractions_saved"][1:]}
    assert SR.output_membership_failures(o5, dj, 12, False, True)


def _design_jobs(man):
    import selective_reversal as SR
    dj = set()
    for line in open(man):
        if line.strip():
            c = json.loads(line)["cfg"]
            if SR.eligible(c) is not None:
                dj.add(SR.design_key(c))
    return dj


def test_the_cohort_and_roles_are_recorded(panel):
    import selective_reversal as SR
    reg = _rows(panel["root"] / "layer_transplant25_registry_summary.csv")
    assert all(x["cohort"] == SR.REGISTRY_COHORT["wave25"] for x in reg)
    assert {x["contrast"] for x in reg if x["role"] == "primary"} == SR.REGISTRY_PRIMARY["wave25"]
    cov = read_json(panel["root"] / "layer_transplant25_coverage.json")
    assert cov["registry"]["cohort"] and cov["registry"]["primary"] == sorted(SR.REGISTRY_PRIMARY["wave25"])
    assert "full code map" in cov["registry"]["exploratory"]


# ----------------------------------------------------------------------------- the paired-stream audit

def _streams():
    base = {"cell": "c", "data_draw": 1, "optimizer_seed": 0, "f0": "f", "f0_state_hash": "h0", "updates": 12,
            "batches_drawn": 12, "data_hash": "d", "batch_id_hash": "s"}
    t = [{**base, "role": "trajectory", "run_id": f"t{k}", "variant": f"{k}_v", "insertion_init_hash": "i",
          "config_apart_from_holds": "c0"} for k in "ABCD"]
    c = [{**base, "role": "compact", "run_id": f"c{k}", "variant": f"compact_{k}", "insertion_init_hash": None,
          "config_apart_from_holds": None, "fork_records_at_2U": 1} for k in "ABCD"]
    dj = {(f"{k}_v", "treated", "full", "c", 1, 0) for k in "ABCD"} | \
        {(f"compact_{k}", "C1_phase", "control", "c", 1, 0) for k in "ABCD"}
    return t + c, dj


def test_paired_streams_pass_when_complete():
    import selective_reversal as SR
    rows, dj = _streams()
    assert SR.paired_stream_failures(rows, dj, 12) == []
    assert SR.paired_stream_failures(rows + [dict(rows[0])], dj, 12) == []      # an identical repeat is one record


@pytest.mark.parametrize("case", ["other_f0", "other_f0_state", "missing_condition", "missing_compact",
                                  "compact_wrong_update", "compact_wrong_batches", "conflicting_duplicate",
                                  "unexpected_condition", "two_runs_one_condition", "stream_differs"])
def test_paired_streams_detect_each_break(case):
    import selective_reversal as SR
    rows, dj = _streams()
    rows = [dict(r) for r in rows]
    if case == "other_f0":
        rows[2]["f0"] = "g"                     # one condition points at another f0: same group, a failure
    elif case == "other_f0_state":
        rows[5]["f0_state_hash"] = "h1"
    elif case == "missing_condition":
        rows = rows[1:]
    elif case == "missing_compact":
        rows = rows[:-1]
    elif case == "compact_wrong_update":
        rows[6]["updates"] = 11
    elif case == "compact_wrong_batches":
        rows[6]["batches_drawn"] = 13
    elif case == "conflicting_duplicate":
        rows.append({**rows[1], "batch_id_hash": "x"})
    elif case == "unexpected_condition":
        rows.append({**rows[0], "run_id": "tE", "variant": "E_v"})
    elif case == "two_runs_one_condition":
        rows.append({**rows[0], "run_id": "tA2"})
    elif case == "stream_differs":
        rows[7]["batch_id_hash"] = "x"
    bad = SR.paired_stream_failures(rows, dj, 12)
    assert bad, case


# ----------------------------------------------------------------------------- reuse of a complete v45 panel

def test_cop_semantics_are_v45s_so_its_panel_is_this_panel():
    """v46 changes no training code: the semantic code hash (cop/) is v45's, so a complete v45 panel has exactly the
    run ids and results this manifest describes and can be analysed read-only.  v59: or an audit accepts v45's
    semantics for the current code (the run ids are unchanged: same CODE_VERSION)."""
    from cop.config import CODE_VERSION
    assert v45_panels_reusable() and CODE_VERSION == "cop-7.21.0"


def test_panel_state_on_a_real_panel(panel, tmp_path):
    root, man = panel["root"], panel["man"]
    run = lambda res: subprocess.run([sys.executable, str(ROOT / "scripts/panel_state.py"), str(man), str(res)],
                                     capture_output=True, text=True)
    assert run(root).returncode == 0
    assert run(tmp_path / "nothing").returncode == 4
    import shutil
    cp = tmp_path / "copy"
    shutil.copytree(root / "runs", cp / "runs", ignore=shutil.ignore_patterns("*.pt", "preds", "graphs"))
    rid = run_id(panel["R"]["B"])
    st = json.loads((cp / "runs" / rid / "status.json").read_text())
    (cp / "runs" / rid / "status.json").write_text(json.dumps({**st, "status": "running"}))
    assert run(cp).returncode == 3                              # incomplete: never used
    (cp / "runs" / rid / "status.json").write_text(json.dumps(st))
    pv = json.loads((cp / "runs" / rid / "provenance.json").read_text())
    (cp / "runs" / rid / "provenance.json").write_text(json.dumps({**pv, "semantic_hash": "0" * 16}))
    assert run(cp).returncode == 6                              # other semantics: never used
