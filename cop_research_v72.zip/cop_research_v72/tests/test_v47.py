"""v47 and v48: the coordinated-reversal analysis, tested on REAL analysis outputs of a miniature wave 25 analysed
with the current launcher's exact options (scripts/48, the same options as v47's retired scripts/47): the evidence
contract, the 5x5 grid's corners against the existing code tables and against the trajectory's 2x2 at 2U (two
independent code paths: gated additions versus deletion by graph edit), zero gates on the nested leaf additions equal
to the deletion, the 2x2 cells and the interaction arithmetic, the rewind flagged as a no-op where layers 2..K are
f0's, the three predeclared paths with their endpoint-relative barriers and contrasts (v48), identical paths where
the rewind is a no-op (v48), the saved predictions, logits and labels against every table value (v48), and output
membership."""
from __future__ import annotations

import csv
import json
import re
import shlex
import shutil
import subprocess
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "audit_v5/tools"))

ROOT = Path(__file__).resolve().parents[1]
LAUNCHER = ROOT / "scripts/48_v48_reversal_barriers.sh"   # v48: same options as v47's
LEVELS = (1.0, 0.75, 0.5, 0.25, 0.0)
CORNERS = {(1.0, 1.0): "present_trained", (0.0, 1.0): "deleted_trained", (1.0, 0.0): "present_rewound",
           (0.0, 0.0): "deleted_rewound"}


def _rows(path):
    t = Path(path).read_text()
    return [] if t.strip() == "empty" else list(csv.DictReader(open(path)))


def _launcher_contract():
    src = LAUNCHER.read_text()
    files = re.search(r'^REV_FILES="([^"]+)"', src, re.M).group(1).split(",")
    codes = re.search(r'^CODES="([^"]+)"', src, re.M).group(1)
    cmd = re.search(r'^  step reversal25 (.*?"\$PREDS")', src, re.M | re.S).group(1).replace("\\\n", " ")
    toks = shlex.split(cmd)
    return files, codes, toks[toks.index("--strict") + 1:]


@pytest.fixture(scope="module")
def panel(tmp_path_factory):
    import test_v45 as T
    root = tmp_path_factory.mktemp("w25r")
    _, _, _, _, man = T._panel(root)
    files, codes, rest = _launcher_contract()
    sub = {"$CODES": codes, "$PREDS": str(root / "preds25")}
    args = [sub.get(t, t) for t in rest]
    r = subprocess.run([sys.executable, str(ROOT / "audit_v5/tools/selective_reversal.py"), str(root),
                        str(root / "coordinated25"), "--manifest", str(man), "--strict", "--device", "cpu", *args],
                       capture_output=True, text=True)
    t = lambda name: _rows(root / f"coordinated25_{name}.csv")
    return {"root": root, "r": r, "files": files, "codes": codes.split(","), "t": t}


def _evidence(root, files):
    out = root / "ev.json"
    r = subprocess.run([sys.executable, str(ROOT / "scripts/check_evidence.py"), str(out),
                        f"reversal25:0:{root / 'coordinated25'}:{','.join(files)}"], capture_output=True, text=True)
    return r.returncode, json.loads(out.read_text())["steps"]["reversal25"]


def _f(x):
    return float(x)


def test_real_outputs_pass_the_launchers_evidence_contract(panel, tmp_path):
    assert panel["r"].returncode == 0, panel["r"].stdout[-3000:] + panel["r"].stderr[-3000:]
    import selective_reversal as SR
    cov = json.loads((panel["root"] / "coordinated25_coverage.json").read_text())
    assert cov["passed"] and cov["analysis_schema"] == SR.ANALYSIS_SCHEMA
    assert cov["output_membership_failures"] == []
    rc, ev = _evidence(panel["root"], panel["files"])
    assert rc == 0 and ev["ok"], ev
    for name in ("reversal_grid_summary", "reversal_path_contrasts"):
        d = tmp_path / name
        d.mkdir()
        for f in panel["files"]:
            shutil.copy2(panel["root"] / f"coordinated25_{f}", d / f"coordinated25_{f}")
        (d / f"coordinated25_{name}.csv").write_text("empty\n")
        rc, ev = _evidence(d, panel["files"])
        assert rc == 1 and ev["missing"] == [f"coordinated25_{name}.csv (an empty table)"]


def test_grid_corners_are_the_existing_models(panel):
    """(1,1) the native 2U state, (0,1) the deletion, (1,0) the restored layers 2..K with the additions, (0,0) the
    extraction: equal to the code tables of the same job and to the trajectory's own 2x2 at 2U."""
    z, x1 = panel["codes"][0], panel["codes"][1]
    assert (z, x1) == ("0-0-0-0-0", "0-1-1-1-1")
    grid = panel["t"]("reversal_grid")
    codes = {(r["run_id"], r["code"]): r for r in panel["t"]("codes") if r["state"] == "abrupt"}
    imps = {(r["run_id"], r["code"]): r for r in panel["t"]("codes_implants") if r["state"] == "abrupt"}
    two = defaultdict(dict)
    for r in panel["t"]("reversal_2x2"):
        two[(r["run_id"], int(r["updates_since_f0"]))][r["reversal_cell"]] = r
    fork = {rid: max(u for (rr, u) in two if rr == rid) for rid, _ in two}
    by = defaultdict(dict)
    for r in grid:
        by[r["run_id"]][(_f(r["alpha"]), _f(r["beta"]))] = r
    assert by and all(len(p) == 25 for p in by.values())
    for rid, pts in by.items():
        ref = {(1.0, 1.0): imps[(rid, z)], (0.0, 1.0): codes[(rid, z)], (1.0, 0.0): imps[(rid, x1)],
               (0.0, 0.0): codes[(rid, x1)]}
        par = pts[(1.0, 1.0)]["parent"]
        t2 = two[(par, fork[par])]
        for q, cell in CORNERS.items():
            for m in ("test_err", "val_err", "shift_err", "rare_err", "shortcut_flip_rate"):
                assert _f(pts[q][m]) == _f(ref[q][m]) == _f(t2[cell][m]), (rid, q, m)
            assert _f(pts[q]["test_ce"]) == _f(t2[cell]["test_ce"]), (rid, q)
        assert _f(pts[(1.0, 1.0)]["disagreement_vs_native"]) == 0.0
        assert _f(pts[(0.0, 0.0)]["disagreement_vs_extraction"]) == 0.0


def test_zero_gates_on_the_nested_leaves_are_the_deletion(panel):
    """the analysis fails unless every corner is bitwise its reference; recorded per job, with the gated leaves
    (I2..I5, nested inside I1)."""
    chk = [r for r in panel["t"]("checks") if r.get("reversal_grid_gated_additions")]
    grid_runs = {r["run_id"] for r in panel["t"]("reversal_grid")}
    assert {r["run_id"] for r in chk} == grid_runs
    for r in chk:
        assert r["reversal_grid_corners_exact"] == "True"
        assert r["reversal_grid_gated_additions"].split() == ["I2", "I3", "I4", "I5"]


def test_2x2_cells_interaction_and_noop_flags(panel):
    two = defaultdict(dict)
    for r in panel["t"]("reversal_2x2"):
        two[(r["run_id"], r["checkpoint"])][r["reversal_cell"]] = r
    ages = defaultdict(set)
    for (rid, ck), cs in two.items():
        assert set(cs) == set(CORNERS.values()), (rid, ck)
        r0 = cs["present_trained"]
        ages[rid].add(int(r0["updates_since_f0"]))
        noop = r0["rewind_is_noop"] == "True"
        assert noop == (_f(r0["downstream_change_max_abs"]) == 0.0)
        if r0["variant"] in ("C_dsfrozen", "D_bothfrozen") or int(r0["updates_since_f0"]) == 0:
            assert noop
        if noop:                          # restoring f0's layers 2..K changes nothing
            for a_, b_ in (("present_rewound", "present_trained"), ("deleted_rewound", "deleted_trained")):
                for m in ("test_err", "test_ce", "val_err"):
                    assert _f(cs[a_][m]) == _f(cs[b_][m]), (rid, ck, m)
    assert {r["variant"] for r in panel["t"]("reversal_2x2")} == {"A_free", "B_scfrozen", "C_dsfrozen",
                                                                 "D_bothfrozen"}
    assert all(len(a) >= 3 and 0 in a for a in ages.values())     # age 0, intermediate(s) and 2U
    st = panel["t"]("reversal_2x2_by_setting")
    assert len(st) == len(two)
    for r in st:
        cs = two[(r["run_id"], r["checkpoint"])]
        e = {c: _f(cs[c]["test_err"]) for c in CORNERS.values()}
        assert _f(r["interaction"]) == pytest.approx(e["deleted_trained"] + e["present_rewound"]
                                                     - e["present_trained"] - e["deleted_rewound"], abs=1e-12)
        assert _f(r["joint_vs_native"]) == pytest.approx(e["present_trained"] - e["deleted_rewound"], abs=1e-12)


def test_paths_and_contrasts_from_the_grid(panel):
    import selective_reversal as SR
    assert {k: len(v) for k, v in SR.REVERSAL_PATHS.items()} == {"diagonal": 5, "delete_then_rewind": 9,
                                                                 "rewind_then_delete": 9}
    for p in SR.REVERSAL_PATHS.values():          # each path runs from the native state to the extraction
        assert p[0] == (1.0, 1.0) and p[-1] == (0.0, 0.0) and len(set(p)) == len(p)
    assert SR.REVERSAL_PATHS["delete_then_rewind"][4] == (0.0, 1.0)
    assert SR.REVERSAL_PATHS["rewind_then_delete"][4] == (1.0, 0.0)
    pts = defaultdict(dict)
    for r in panel["t"]("reversal_grid"):
        pts[r["run_id"]][(_f(r["alpha"]), _f(r["beta"]))] = r
    ps = panel["t"]("reversal_paths_by_setting")
    assert len(ps) == 3 * len(pts)
    worst = {}
    for r in ps:
        pth = SR.REVERSAL_PATHS[r["path"]]
        assert int(r["n_points"]) == len(pth)
        te = [_f(pts[r["run_id"]][q]["test_err"]) for q in pth]
        ce = [_f(pts[r["run_id"]][q]["test_ce"]) for q in pth]
        assert _f(r["max_test_err"]) == max(te) and _f(r["max_test_ce"]) == max(ce)
        assert "mean_test_err" not in r                       # v48: the schedule-weighted mean is dropped
        assert _f(r["barrier_test_err"]) == pytest.approx(max(te) - max(te[0], te[-1]), abs=1e-15)
        assert _f(r["barrier_test_ce"]) == pytest.approx(max(ce) - max(ce[0], ce[-1]), abs=1e-12)
        assert _f(r["barrier_test_err"]) >= 0 and _f(r["barrier_test_ce"]) >= 0
        worst[(r["run_id"], r["path"])] = (max(te), max(ce))
    con = panel["t"]("reversal_path_contrasts_by_draw")
    assert con and {r["contrast"] for r in con} == {"delete_then_rewind_vs_diagonal", "rewind_then_delete_vs_diagonal"}
    # one setting per draw in the miniature: the by-draw value is the run's own difference
    run_of = {(r["variant"], r["data_draw"]): r["run_id"] for r in ps}
    for r in con:
        rid = run_of[(r["variant"], r["data_draw"])]
        k = 0 if r["quantity"] == "max_test_err" else 1
        want = worst[(rid, r["contrast"].split("_vs_")[0])][k] - worst[(rid, "diagonal")][k]
        assert _f(r["value"]) == pytest.approx(want, abs=1e-12)


def test_no_op_rewind_makes_the_paths_identical(panel):
    """where layers 2..K are f0's (C, D) every path visits the same five functions: identical worst points and
    barriers, zero contrasts (v47's schedule mean differed between paths there)."""
    ps = panel["t"]("reversal_paths_by_setting")
    noop = [r for r in ps if r["rewind_is_noop"] == "True"]
    assert {r["variant"] for r in noop} == {"C_dsfrozen", "D_bothfrozen"}
    by = defaultdict(dict)
    for r in noop:
        by[r["run_id"]][r["path"]] = r
    for rid, d in by.items():
        for q in ("max_test_err", "max_test_ce", "barrier_test_err", "barrier_test_ce"):
            assert len({d[p][q] for p in d}) == 1, (rid, q)
    for r in panel["t"]("reversal_path_contrasts_by_draw"):
        if r["rewind_is_noop"] == "True":
            assert _f(r["value"]) == 0.0
    assert {r["quantity"] for r in panel["t"]("reversal_paths")} == {"max_test_err", "max_test_ce",
                                                                   "barrier_test_err", "barrier_test_ce"}


def test_logit_diagnostics_and_saved_logits(panel):
    """v48: the saved logits reproduce the decisions, the test cross-entropy (re-derived per example) and the
    margin quantiles of every grid and 2x2 row."""
    import selective_reversal as SR
    import torch
    cov = json.loads((panel["root"] / "coordinated25_coverage.json").read_text())
    assert "exploratory" in cov["reversal_status"]
    d = panel["root"] / "preds25"
    grid = defaultdict(list)
    for r in panel["t"]("reversal_grid"):
        grid[r["run_id"]].append(r)
    two = defaultdict(dict)
    for r in panel["t"]("reversal_2x2"):
        two[(r["run_id"], r["checkpoint"])][r["reversal_cell"]] = r
    files = [(d / f"{rid}__2U_grid.npz", rows) for rid, rows in grid.items()]
    files += [(d / f"{rid}__{ck}_2x2.npz", [cs[c] for c in CORNERS.values()]) for (rid, ck), cs in two.items()]
    qs = torch.tensor(SR.MARGIN_QUANTILES, dtype=torch.float64)
    for f, rows in files:
        z = np.load(f, allow_pickle=False)
        lg, pr, y = z["logits"], z["preds"], torch.from_numpy(z["labels"].astype(np.int64))
        assert lg.dtype == np.float32 and lg.shape[:2] == pr.shape and (lg.argmax(-1) == pr).all()
        assert y.shape[0] == lg.shape[1]
        for i, r in enumerate(rows):
            zt = torch.from_numpy(lg[i]).double()
            assert all(r.get(k) not in (None, "") for k in SR.LOGIT_DIAGNOSTICS), f
            nll = torch.nn.functional.cross_entropy(zt, y, reduction="none")
            assert _f(r["test_ce"]) == pytest.approx(float(nll.mean()), rel=1e-12)
            zo = zt.clone().scatter_(1, y[:, None], float("-inf"))
            mg = zt.gather(1, y[:, None])[:, 0] - zo.max(-1).values
            for q, v in zip(SR.MARGIN_QUANTILES, torch.quantile(mg, qs).tolist()):
                assert _f(r[f"test_margin_q{round(100 * q):02d}"]) == pytest.approx(v, rel=1e-12, abs=1e-12)
            for q, v in zip(SR.MARGIN_QUANTILES, torch.quantile(nll, qs).tolist()):
                assert _f(r[f"test_ce_q{round(100 * q):02d}"]) == pytest.approx(v, rel=1e-9, abs=1e-12)
            assert _f(r["test_err"]) == pytest.approx(float((torch.from_numpy(pr[i]).long() != y).double().mean()))
            assert _f(r["test_abs_logit_max"]) == pytest.approx(float(zt.abs().max()), rel=1e-12)
            assert _f(r["test_ce_gt10_share"]) == pytest.approx(float((nll > 10).double().mean()))


def test_saved_predictions_match_the_tables(panel):
    d = panel["root"] / "preds25"
    grid = defaultdict(dict)
    for r in panel["t"]("reversal_grid"):
        grid[r["run_id"]][(_f(r["alpha"]), _f(r["beta"]))] = r
    for rid, pts in grid.items():
        z = np.load(d / f"{rid}__2U_grid.npz", allow_pickle=False)
        meta = json.loads(str(z["meta"]))
        assert meta["order"] == "alpha-major" and tuple(meta["levels"]) == LEVELS
        p = z["preds"]
        assert p.shape[0] == 25 and p.dtype == np.int16
        idx = {(a_, b_): i for i, (a_, b_) in enumerate((a_, b_) for a_ in LEVELS for b_ in LEVELS)}
        for q, r in pts.items():
            pc = p[idx[q]]
            assert float((pc != p[idx[(1.0, 1.0)]]).mean()) == _f(r["disagreement_vs_native"])
            assert float((pc != p[idx[(0.0, 0.0)]]).mean()) == _f(r["disagreement_vs_extraction"])
    two = {(r["run_id"], r["checkpoint"]) for r in panel["t"]("reversal_2x2")}
    for rid, ck in two:
        z = np.load(d / f"{rid}__{ck}_2x2.npz", allow_pickle=False)
        assert z["preds"].shape[0] == 4 and tuple(json.loads(str(z["meta"]))["cells"]) == tuple(CORNERS.values())
    assert len(list(d.glob("*.npz"))) == len(grid) + len(two)


def test_the_launcher_names_every_reversal_output(panel):
    files, _, rest = _launcher_contract()
    for f in ("reversal_2x2_by_setting.csv", "reversal_grid_summary.csv", "reversal_paths_by_setting.csv",
              "reversal_path_contrasts.csv", "reversal_path_contrasts_by_draw.csv"):
        assert f in files
    assert "--reversal-grid" in rest and "--trace-implants" in rest and "--paired-streams" not in rest
    for f in files:
        assert (panel["root"] / f"coordinated25_{f}").exists(), f
