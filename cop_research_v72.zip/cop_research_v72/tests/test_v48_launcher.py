"""v48: the corrected coordinated-reversal launcher (scripts/48; v47's scripts/47 is retired), analysis only.  It
reads the complete v46 wave-25 panel read-only (an incomplete or foreign panel skips the tests and the analysis and
fails the launcher), runs the CPU tests and one analysis (the 2x2 at every expansion age, the 5x5 grid at 2U and its
predeclared paths), checks its evidence and packages a diagnostic archive whatever happens; it never trains.  The
real script runs in a mock COP_HOME (`cop` a shell function, stub tools, the real packager and evidence checker; the
harness taken over from the retired v46 launcher test, as v46 took over v45's).  scripts/39..47 refuse to run."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import zipfile
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
COMMON = r'''set -euo pipefail
export COP_HOME="$MOCK_HOME"
export COP_DATA_ROOT="$MOCK_HOME"
export WORKERS=1 THREADS=1 DEVICE=cpu
cd "$COP_HOME"
mkdir -p "$COP_RESULTS" "$COP_HOME/manifests"
cop() {
  echo "cop $*" >> "$MOCK_HOME/events.txt"
  case "$1" in
    generate-manifest) [ "${MOCK_MANIFEST_RC:-0}" = 0 ] && echo '{"run_id": "job0"}' > "$7"; return "${MOCK_MANIFEST_RC:-0}" ;;
    validate-manifest) return "${MOCK_VALIDATE_RC:-0}" ;;
    inspect-environment) return "${MOCK_ENV_RC:-0}" ;;
    run)
      if [ -n "${MOCK_RUN_DECLARED:-}" ]; then        # v36: the runner leaves one invalid job and exits 1
        d="$5/runs/job0"; mkdir -p "$d"
        echo '{"status": "invalid"}' > "$d/status.json"
        echo '{"kind": "continue", "continue": {"perturb_match": "parent_frozen_deletion"}}' > "$d/config.json"
        echo "{\"failure\": \"$MOCK_RUN_DECLARED\", \"metric\": \"val_err\"}" > "$d/perturb_match.json"
        return 1
      fi
      return "${MOCK_RUN_RC:-0}" ;;
    status) return "${MOCK_STATUS_RC:-0}" ;;
    summarize) [ "$2" = "--strict" ] || return 9; mkdir -p "$8"; echo x > "$8/s.csv"; return "${MOCK_SUM_RC:-0}" ;;
    *) return 0 ;;
  esac
}
'''
PANEL_STATE = """import json, os, sys
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write("panel_state " + sys.argv[2] + "\\n")
if not os.path.exists(sys.argv[1]):
    sys.exit(1)
print(json.dumps({"mock": True}))
sys.exit(int(os.environ.get("MOCK_PANEL_STATE", "4")))
"""
PYTEST = """#!/usr/bin/env bash
echo "3 passed"
exit "${MOCK_TEST_RC:-0}"
"""
SCRIPT = "48_v48_reversal_barriers.sh"
ANALYSIS = r"""import json, os, sys
prefix = sys.argv[2]
for f in ("--implant-codes", "--trace", "--trace-implants", "--reversal-grid", "--manifest", "--strict"):
    assert f in sys.argv, f
for f in ("--contrasts", "--decompose", "--paired-streams", "--save-extractions", "--preflight"):
    assert f not in sys.argv, f
codes = sys.argv[sys.argv.index("--codes") + 1].split(",")
assert "0-0-0-0-0" in codes and "0-1-1-1-1" in codes and sys.argv[sys.argv.index("--trace-codes") + 1] == ",".join(codes)
assert sys.argv[sys.argv.index("--save-preds") + 1].endswith("preds25")
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write("reversal reads " + sys.argv[1] + "\n")
rc = int(os.environ.get("MOCK_REVERSAL_RC", "0"))
json.dump({"expected": 1, "analysed": 1, "n_failed": 0, "passed": rc == 0}, open(prefix + "_coverage.json", "w"))
for t in ("checks", "codes_summary", "codes_implants_summary", "compute", "trace", "reversal_2x2",
          "reversal_2x2_by_setting", "reversal_2x2_by_draw", "reversal_2x2_summary", "reversal_grid",
          "reversal_grid_by_draw", "reversal_grid_summary", "reversal_paths_by_setting", "reversal_paths",
          "reversal_path_contrasts", "reversal_path_contrasts_by_draw"):
    empty = os.environ.get("MOCK_REVERSAL_EMPTY") == t
    open(prefix + "_" + t + ".csv", "w").write("empty\n" if empty else "cell,x\nc,1\n")
sys.exit(rc)
"""


@pytest.fixture
def h(tmp_path):
    home = tmp_path / "home"
    (home / "scripts").mkdir(parents=True)
    shutil.copy2(ROOT / "scripts" / SCRIPT, home / "scripts" / SCRIPT)
    for f in ("package_reports.py", "check_evidence.py"):
        shutil.copy2(ROOT / "scripts" / f, home / "scripts" / f)
    (home / "scripts/panel_state.py").write_text(PANEL_STATE)
    (home / "scripts/common.sh").write_text(COMMON)
    (home / "audit_v5/tools").mkdir(parents=True)
    (home / "audit_v5/tools/selective_reversal.py").write_text(ANALYSIS)
    pt = home / "fake_pytest.sh"
    pt.write_text(PYTEST)
    pt.chmod(0o755)
    zipdir = tmp_path / "zips"
    zipdir.mkdir()
    base = {k: v for k, v in os.environ.items() if k not in ("DIAGNOSTIC_OVERRIDE", "COP_PYTEST")}
    env = dict(base, MOCK_HOME=str(home), COP_RESULTS=str(tmp_path / "results"), ZIP_DIR=str(zipdir), SCALE="full",
               HOME=str(tmp_path), COP_PYTEST=str(pt), V46_RESULTS=str(tmp_path / "cop_results_v46"),
               MOCK_PANEL_STATE="0")
    return {"home": home, "res": tmp_path / "results", "zip": zipdir / "cop_v48_reversal_reports.zip", "env": env,
            "v46": tmp_path / "cop_results_v46"}


def _sh(h, **env):
    e = dict(h["env"], **{k: str(v) for k, v in env.items()})
    return subprocess.run(["bash", str(h["home"] / "scripts" / SCRIPT)], env=e, capture_output=True, text=True,
                          cwd=str(h["home"]))


def _verdict(h):
    return json.loads((h["res"] / "v48_reports/verdict.json").read_text())


def _events(h):
    p = h["home"] / "events.txt"
    return p.read_text() if p.exists() else ""


def test_success_reads_the_v46_panel_read_only_and_never_trains(h):
    r = _sh(h)
    assert r.returncode == 0, r.stdout + r.stderr
    v = _verdict(h)
    assert v["all_passed"] and set(v["steps"]) == {"environment", "manifest25", "panel_source", "cpu_tests",
                                                    "reversal25", "evidence25", "manifest_copy", "package",
                                                    "package_final"}
    ev = _events(h)
    assert "cop run" not in ev and "reversal reads " + str(h["v46"] / "panel25") in ev
    assert "panel_state " + str(h["v46"] / "panel25") in ev
    names = zipfile.ZipFile(h["zip"]).namelist()
    for f in ("coordinated25_reversal_grid_summary.csv", "coordinated25_reversal_path_contrasts.csv",
              "coordinated25_reversal_2x2_summary.csv", "evidence25.json"):
        assert f"cop_v48_reversal_reports/v48_reports/{f}" in names, f
    assert not (h["v46"] / "panel25").exists()                    # nothing was written into the v46 folder


@pytest.mark.parametrize("state", [3, 4, 6])
def test_no_complete_v46_panel_skips_the_tests_and_the_analysis(h, state):
    r = _sh(h, MOCK_PANEL_STATE=state)
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"]["panel_source"] == state and v["steps"]["cpu_tests"] == 99 and v["steps"]["reversal25"] == 99
    assert "reversal reads" not in _events(h) and h["zip"].exists()


@pytest.mark.parametrize("table", ["reversal_grid_summary", "reversal_path_contrasts", "reversal_2x2_by_setting"])
def test_an_empty_required_table_fails_the_evidence(h, table):
    r = _sh(h, MOCK_REVERSAL_EMPTY=table)
    assert r.returncode != 0
    ev = json.loads((h["res"] / "v48_reports/evidence25.json").read_text())
    assert ev["steps"]["reversal25"]["missing"] == [f"coordinated25_{table}.csv (an empty table)"]


def test_a_failed_analysis_or_test_suite_fails_the_launcher(h):
    assert _sh(h, MOCK_REVERSAL_RC=1).returncode != 0
    r = _sh(h, MOCK_TEST_RC=1)
    assert r.returncode != 0 and _verdict(h)["steps"]["reversal25"] == 99


def test_a_packaging_failure_fails_the_launcher(h):
    h["zip"].mkdir()
    r = _sh(h)
    assert r.returncode != 0 and _verdict(h)["steps"]["package"] != 0


def test_packager_verifies_required_members_and_replaces_a_stale_archive(tmp_path):
    import sys
    res = tmp_path / "res"
    (res / "rep").mkdir(parents=True)
    (res / "rep" / "a.txt").write_text("a")
    vf = tmp_path / "v.json"
    vf.write_text(json.dumps({"steps": {"x": 0}}))
    out = tmp_path / "o.zip"
    out.write_text("stale, not a zip")
    run = lambda *extra: subprocess.run([sys.executable, str(ROOT / "scripts/package_reports.py"), str(res), str(out),
                                         str(vf), "P", "--include", "rep", *extra], capture_output=True, text=True)
    r = run("--require", "rep/missing.txt")
    assert r.returncode == 2 and not out.exists()
    r = run("--require", "rep/a.txt")
    assert r.returncode == 0
    with zipfile.ZipFile(out) as z:
        assert set(z.namelist()) == {"P/rep/a.txt", "P/verdict.json"}


@pytest.mark.parametrize("script,target", [("39_v39_panel.sh", "41_v41_panel.sh"), ("41_v41_panel.sh", "42_v42_panel.sh"),
                                           ("42_v42_panel.sh", "43_v43_panel.sh"),
                                           ("43_v43_panel.sh", "44_v44_panel.sh"),
                                           ("44_v44_panel.sh", "45_v45_panel.sh"),
                                           ("45_v45_panel.sh", "46_v46_panel.sh"),
                                           ("46_v46_panel.sh", "47_v47_coordinated_reversal.sh"),
                                           ("47_v47_coordinated_reversal.sh", "48_v48_reversal_barriers.sh")])
def test_superseded_launchers_refuse(script, target):
    r = subprocess.run(["bash", str(ROOT / "scripts" / script)], capture_output=True, text=True)
    assert r.returncode == 1 and target in r.stderr
