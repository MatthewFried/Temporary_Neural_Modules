"""Regression gates for the v3 independent audit (V3-01 ... V3-12), v4 fixes.

The audit's own gates are in tests/test_v3_audit_supplied.py (verbatim except the source-path
adapter and the one pruning adapter documented there).  This file adds the broader acceptance
checks.  CUDA tests are marked and skip without a device: a skip is NOT validation; run them on the
GPU (scripts/12_v4_gpu_gates.sh)."""
from __future__ import annotations

import json
import math
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests"))

import tiny_configs as T  # noqa: E402
from cop.analysis.strengthening import compact_gain, endpoint_table, classify_pair  # noqa: E402
from cop.analysis.summarize import load_runs  # noqa: E402
from cop.config import resolve, run_id, TRAIN_DEFAULTS  # noqa: E402
from cop.data.registry import load_bundle  # noqa: E402
from cop.graph.accounting import architecture_hash, count_params  # noqa: E402
from cop.graph.builders import build_mlp  # noqa: E402
from cop.graph.graph import GraphNet  # noqa: E402
from cop.orchestration.runner import run_job, status_of  # noqa: E402
from cop.train.trainer import Trainer, Segment, backward_aware_macs, forward_macs, apply_trainable  # noqa: E402
from cop.utils import torch_gen, read_json, read_jsonl  # noqa: E402

CUDA = pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA device required (run scripts/12 on the GPU)")


def _run(cfgs, d, device="cpu"):
    st = [run_job(c, d, {"device": device}) for c in cfgs]
    assert st[-1] == "complete", status_of(d, run_id(cfgs[-1])).get("reason")
    return d / "runs" / run_id(cfgs[-1])


def _endpoint_metrics(rd):
    out = {}
    for r in read_jsonl(rd / "metrics.jsonl"):
        if r["stage"] == "endpoint" and r["evaluation_partition"] in ("val", "test"):
            out[(r["evaluation_partition"], r["metric_name"])] = r["metric_value"]
    return out


def _with_design(cfg, arm="treated", contrast="v4", panel=""):
    return resolve({**cfg, "design": {"family": "audit", "variant": "v4", "arm": arm, "contrast": contrast,
                                      "budget_panel": panel}})


# ----------------------------------------------------------------------------- V3-01 / V3-02

def test_every_endpoint_kind_records_a_reloadable_endpoint(tmp_path):
    """endpoint.json names a checkpoint; reloading that file reproduces every endpoint metric."""
    from cop.train.trainer import evaluate
    b = T.base()
    p = T.traj({"topology": "recursive_branch"})
    dis = T.child("dissipation", p[-1], {"dissipation": {"method": "abrupt", "post_updates": 4}})
    rep = T.child("repair", p[-1], {"repair": {"region": "full", "budget_multiplier": 0.3, "eval_points": 2}})
    cont = resolve({"kind": "continue", "data": T.DATA, "model": T.MODEL, "train": T.TRAIN,
                    "seeds": {"optimizer": 0}, "parents": {"baseline": run_id(b)}, "continue": {"updates": 6}})
    cop = T.cop({}, {"dim": 4})
    for c in p + [dis, rep, cont] + cop:
        run_job(c, tmp_path, {"device": "cpu"})
    bundle = load_bundle(T.DATA)
    for c in [b, p[-1], dis, rep, cont, cop[-1]]:
        rd = tmp_path / "runs" / run_id(c)
        ep = read_json(rd / "endpoint.json")
        ck = torch.load(rd / "ckpt" / f"{ep['checkpoint']}.pt", map_location="cpu", weights_only=False)
        g = GraphNet.from_checkpoint(ck["model"], "cpu")
        assert architecture_hash(g) == ep["architecture_hash"]
        res, _ = evaluate(g, bundle if c["kind"] != "cop" else load_bundle(c["data"]), ["val", "test"], 4096)
        m = _endpoint_metrics(rd)
        for part in ("val", "test"):
            for k in ("mse", "loss"):
                if (part, k) in m:
                    assert m[(part, k)] == pytest.approx(res[part][k], rel=1e-6, abs=1e-9), (c["kind"], part, k)
        assert ep["numerically_valid"] is True


def test_diverged_repair_between_evaluations_is_evaluated_where_it_stopped(tmp_path):
    cfgs = T.traj({"topology": "layered", "rounds": 1, "updates_per_round": 5})
    c = T.child("repair", cfgs[-1], {"repair": {"region": "full", "deletion": "all", "budget_multiplier": 4.,
                                                "eval_points": 2, "extension_factor": 1.}})
    c = resolve({**c, "train": {**c["train"], "optimizer": "sgd", "lr": 1e38, "grad_clip": 0.},
                 "design": {"family": "audit", "variant": "divergence", "arm": "treated", "contrast": "d"}})
    rd = _run(cfgs + [c], tmp_path)
    r = read_json(rd / "repair_result.json")
    ep = read_json(rd / "endpoint.json")
    assert r["diverged"] and ep["diverged"] and not ep["numerically_valid"]
    assert r["curve"][-1]["update"] == r["updates_done"]          # the curve ends at the actual endpoint
    row = next(x for x in endpoint_table(load_runs(tmp_path)) if x["run_id"] == run_id(c))
    assert row["eligible"] is False and "diverged" in row["eligibility_reasons"]
    summ, pairs = compact_gain([row], strict=False)
    assert not pairs


def test_cop_chain_divergence_reaches_the_endpoint_and_work_counts_actual_updates(tmp_path, monkeypatch):
    """Reviewer finding: a CoP chain whose training stops on a non-finite loss (parameters still finite)
    must export a diverged, ineligible endpoint, and its work must count the updates actually made."""
    import cop.train.trainer as TR
    b, c = T.cop({}, {"dim": 4})
    c = _with_design(c)
    assert run_job(b, tmp_path, {"device": "cpu"}) == "complete"
    real, calls = TR.task_loss, {"n": 0}

    def flaky(out, y, task):
        calls["n"] += 1
        v = real(out, y, task)
        return v * float("inf") if calls["n"] == 3 else v
    monkeypatch.setattr(TR, "task_loss", flaky)
    rd = _run([c], tmp_path)
    monkeypatch.setattr(TR, "task_loss", real)
    ep = read_json(rd / "endpoint.json")
    assert ep["diverged"] and not ep["numerically_valid"] and ep["finite_tensors"]
    work = read_json(rd / "summary.json")["work"]
    w = work if isinstance(work, dict) else {}
    assert w["chain_train:cop"]["updates"] == 2 < c["cop"]["global_updates"]
    row = next(x for x in endpoint_table(load_runs(tmp_path)) if x["run_id"] == run_id(c))
    assert row["eligible"] is False and "diverged" in row["eligibility_reasons"]


def test_dissipation_work_counts_actual_updates_after_divergence(tmp_path, monkeypatch):
    import cop.train.trainer as TR
    p = T.traj({"topology": "layered", "rounds": 1})
    for x in p:
        assert run_job(x, tmp_path, {"device": "cpu"}) == "complete"
    d = T.child("dissipation", p[-1], {"dissipation": {"method": "linear", "speed_updates": 6, "post_updates": 6}})
    real, calls = TR.task_loss, {"n": 0}

    def flaky(out, y, task):
        calls["n"] += 1
        v = real(out, y, task)
        return v * float("inf") if calls["n"] == 4 else v
    monkeypatch.setattr(TR, "task_loss", flaky)
    rd = _run([d], tmp_path)
    monkeypatch.setattr(TR, "task_loss", real)
    r = read_json(rd / "dissipation_result.json")
    ep = read_json(rd / "endpoint.json")
    assert r["diverged"] and ep["diverged"]
    assert r["total_updates"] == 3 and ep["updates"] == 3
    assert read_json(rd / "summary.json")["work"]["dissipation"]["updates"] == 3


def test_local_loop_divergence_fails_the_job_instead_of_completing():
    from cop.train.trainer import LocalOpt, NumericalDivergence
    m = torch.nn.Linear(3, 1)
    lo = LocalOpt(list(m.parameters()), dict(TRAIN_DEFAULTS, optimizer="sgd", lr=1e38, grad_clip=0.), 2)
    x = torch.randn(4, 3)
    with pytest.raises(NumericalDivergence):
        for k in range(2):
            lo.step((m(x) * 1e30).pow(2).sum(), k)
    with pytest.raises(NumericalDivergence, match="loss"):
        LocalOpt(list(torch.nn.Linear(3, 1).parameters()), TRAIN_DEFAULTS, 1).step(torch.tensor(float("nan"),
                                                                                       requires_grad=True), 0)


def test_finite_weights_with_non_finite_outputs_are_not_an_endpoint(tmp_path):
    """Perturbing f0 by 1e17 x its norm leaves finite weights whose forward overflows."""
    b = T.base()
    c = _with_design(resolve({"kind": "continue", "data": T.DATA, "model": T.MODEL, "train": T.TRAIN,
                              "seeds": {"optimizer": 0}, "parents": {"baseline": run_id(b)},
                              "continue": {"updates": 3, "arm": "perturb", "perturb_rel": 1e17}}))
    rd = _run([b, c], tmp_path)
    ep = read_json(rd / "endpoint.json")
    assert ep["finite_tensors"] is True and ep["finite_metrics"] is False
    assert ep["numerically_valid"] is False


def test_last_update_overflow_marks_divergence_and_counts_the_update():
    bundle = load_bundle(T.DATA)
    g = build_mlp(8, [4], 3, torch_gen(0, "init"))
    tr = Trainer(g, bundle, dict(TRAIN_DEFAULTS, batch_size=32, optimizer="sgd", lr=1e38, grad_clip=0.),
                 {"minibatch": 0, "augmentation": 0}, "cpu")
    tr.configure("none", None)
    tr.run(Segment("overflow", 1, target="custom", target_fn=lambda out, batch, X: out.sum() * 1e10))
    assert tr.state["diverged"] and tr.state["global_step"] == 1 and tr.state["diverged_at"] == 1
    assert "parameters" in tr.state["diverged_reason"]


# ----------------------------------------------------------------------------- V3-03 / V3-04

def _rows(**kw):
    base = dict(kind="dissipation", status="complete", validity="valid", compact=True, eligible=True,
                replication="r0", design_contrast="k", design_budget_panel="updates", f0_run="f0A",
                data="teacher", model="mlp", architecture_hash="A", f0_architecture_hash="A")
    t = dict(base, run_id="t", test_risk=.2, design_arm="treated")
    c = dict(base, run_id="c", test_risk=.5, design_arm="C1")
    t.update(kw)
    return t, c


def test_estimands_follow_the_endpoint_architectures():
    t, c = _rows()
    assert classify_pair(t, c)[0] == "fixed_architecture"
    t2, c2 = _rows(architecture_hash="B")
    assert classify_pair(t2, c2)[0] == "cost_frontier"
    assert not compact_gain([t2, c2])[1]
    assert compact_gain([t2, c2], estimand="cost_frontier")[1]
    t3, c3 = _rows(architecture_hash="B")
    c3["architecture_hash"] = "B"
    assert classify_pair(t3, c3)[0] == "matched_endpoint"


def test_pairing_rejects_duplicates_and_incompatible_contracts_but_not_other_scales():
    t, c = _rows()
    dup = dict(c, run_id="c2", test_risk=2.0)
    with pytest.raises(ValueError):
        compact_gain([t, c, dup])
    rej = []
    s1, p1 = compact_gain([t, c, dup], strict=False, rejected=rej)
    s2, p2 = compact_gain([t, dup, c], strict=False)
    assert not p1 and not p2 and any("duplicated" in r["reason"] for r in rej)     # order cannot decide
    # the same contrast at another scale (different f0 run) is a separate contract, not a duplicate
    tp, cp = dict(t, run_id="tp", f0_run="f0B"), dict(c, run_id="cp", f0_run="f0B", test_risk=.9)
    summ, pairs = compact_gain([t, c, tp, cp])
    assert sorted(round(q["G"], 6) for q in pairs) == [0.3, 0.7]
    bad = dict(c, data="fashion_mnist")
    rej = []
    assert not compact_gain([t, bad], strict=False, rejected=rej)[1]
    assert any("incompatible" in r["reason"] for r in rej)


def test_cop_export_against_f0_is_a_frontier_and_its_matched_control_is_matched(tmp_path):
    b, c = T.cop({}, {"dim": 4, "mode": "uniform", "bits": 2})
    c = _with_design(c)
    ctl = _with_design(resolve({"kind": "continue", "data": c["data"], "model": c["model"], "train": c["train"],
                                "seeds": {"optimizer": 0}, "parents": {"baseline": run_id(b), "treated": run_id(c)},
                                "continue": {"budget": "parent_updates", "budget_parent": "treated"}}), "C1",
                       panel="updates")
    m1 = _with_design(resolve({"kind": "continue", "data": c["data"], "model": c["model"], "train": c["train"],
                               "seeds": {"optimizer": 0}, "parents": {"baseline": run_id(b), "treated": run_id(c)},
                               "continue": {"start": "treated", "start_stage": "export", "reinit": True,
                                            "budget": "parent_updates", "budget_parent": "treated",
                                            "budget_add_f0": True}}), "M1", panel="updates")
    for x in (b, c, ctl, m1):
        _run([x], tmp_path)
    E = endpoint_table(load_runs(tmp_path))
    fixed = compact_gain(E, estimand="fixed_architecture")[1]
    matched = compact_gain(E, estimand="matched_endpoint")[1]
    frontier = compact_gain(E, estimand="cost_frontier")[1]
    assert not [q for q in fixed if q["control_arm"] == "C1"]
    assert [q["control_arm"] for q in matched] == ["M1"]
    assert {q["control_arm"] for q in frontier} >= {"C1", "C0"}
    rd = tmp_path / "runs" / run_id(m1)
    assert read_json(rd / "budget.json")["parent_chain_work"]["f0_added"]["updates"] == T.TRAIN["baseline_updates"]


# ----------------------------------------------------------------------------- V3-08

def _tie(g, i, j):
    h = g.clone(share_params=False)
    hid = [n for n in h.topo_order() if h.nodes[n].op == "linear" and n != h.output]
    old = h.nodes[hid[j]].pkey
    h.nodes[hid[j]].pkey = h.nodes[hid[i]].pkey
    del h.mods[old]
    h._plan = None
    return h


def test_sharing_pattern_is_part_of_architecture_identity():
    g = build_mlp(8, [8, 8, 8], 3, torch_gen(0, "init"))
    a, b = _tie(g, 1, 2), _tie(g, 0, 1)
    assert count_params(a)["total"] == count_params(b)["total"]
    assert len({architecture_hash(g), architecture_hash(a), architecture_hash(b)}) == 3
    assert architecture_hash(a) == architecture_hash(_tie(g, 1, 2).clone(share_params=False))


def _sym_graph(ties, share_input_node=True):
    g = GraphNet("vec", "mlp")
    x = g.set_input("x", 4)
    A1 = g.add_node("linear", [x], {"in": 4, "out": 4, "dim": 4}, build=True)
    A2 = g.add_node("linear", [x], {"in": 4, "out": 4, "dim": 4}, build=True) if share_input_node else None
    B1 = g.add_node("linear", [A1], {"in": 4, "out": 4, "dim": 4}, build=True)
    B2 = g.add_node("linear", [A2 if share_input_node else A1], {"in": 4, "out": 4, "dim": 4}, build=True)
    s_ = g.add_node("add", [B1, B2], {"dim": 4, "coefs": [1.0, 1.0], "gates": [None, None]})
    g.set_output(g.add_node("linear", [s_], {"in": 4, "out": 2, "dim": 2}, build=True))
    n = {"A1": A1, "A2": A2, "B1": B1, "B2": B2}
    for a, b in ties:
        old = g.nodes[n[b]].pkey
        g.nodes[n[b]].pkey = g.nodes[n[a]].pkey
        del g.mods[old]
    g._plan = None
    return g


def test_crossed_ties_between_symmetric_nodes_change_identity():
    """Reviewer probe: A1=B1, A2=B2 (W1W1 + W2W2) versus A1=B2, A2=B1 (W2W1 + W1W2) have equal parameter
    counts and equal Merkle keys per node; the canonical-position sharing classes separate them."""
    from cop.cop_pegs import modules  # noqa: F401  (registers module types)
    g1 = _sym_graph([("A1", "B1"), ("A2", "B2")])
    g2 = _sym_graph([("A1", "B2"), ("A2", "B1")])
    assert count_params(g1)["total"] == count_params(g2)["total"]
    assert architecture_hash(g1) != architecture_hash(g2)
    # the same pattern built with the branches in the other order is the same family
    g3 = _sym_graph([("A2", "B2"), ("A1", "B1")])
    assert architecture_hash(g1) == architecture_hash(g3)
    # one node read twice is not two equal-key nodes
    assert architecture_hash(_sym_graph([], share_input_node=False)) != architecture_hash(_sym_graph([]))


def test_aliasing_inside_a_custom_module_changes_identity():
    from cop.cop_pegs.modules import ChainModule
    a, b = ChainModule(4, 4, 4, 3, 8, shared=False), ChainModule(4, 4, 4, 3, 8, shared=True)
    pa = sorted((k, tuple(p.shape)) for k, p in a.named_parameters())
    pb = sorted((k, tuple(p.shape)) for k, p in b.named_parameters())
    assert pa != pb                              # the node signature reads the module's own parameter list


# ----------------------------------------------------------------------------- V3-05 / V3-06 / V3-10

def test_pruned_rows_stay_zero_through_steps_evaluation_and_resume(tmp_path):
    from cop.experiments.continuation import _PruneRegrow
    g = build_mlp(8, [8, 8], 3, torch_gen(0, "init"))
    opt = torch.optim.AdamW(g.parameters(), lr=.01, weight_decay=0.)
    for p in g.parameters():
        p.grad = torch.ones_like(p)
    opt.step()
    pr = _PruneRegrow(g, .25, 4, 2, 0)
    trn = SimpleNamespace(model=g, opt=opt)
    pr(trn, 0)
    for k in (0, 1):                             # nonzero gradients inside the window: post_step keeps rows at zero
        for p in g.parameters():
            p.grad = torch.randn_like(p)
        opt.step()
        pr.post_step(trn, k)
        assert all(torch.count_nonzero(g.mods[g.nodes[n].pkey].weight[i]) == 0 for n, i in pr.masks.items())
    assert pr.events[0]["moment_policy"] == "reset_at_prune_and_regrow" and pr.events[0]["moment_tensors_reset"] > 0
    # job level: a C8 run that ends inside a prune window saves its pruned rows at zero, and resumes exactly
    from resume_harness import compare_interrupted
    b = T.base(train={**T.TRAIN, "checkpoint_every": 3})
    c = resolve({"kind": "continue", "data": T.DATA, "model": T.MODEL, "train": {**T.TRAIN, "checkpoint_every": 3},
                 "seeds": {"optimizer": 0}, "parents": {"baseline": run_id(b)},
                 "continue": {"updates": 13, "arm": "prune_regrow", "prune_period": 10, "prune_duration": 5,
                              "eval_at": [12]}})
    r = compare_interrupted([b, c], tmp_path / "resume")
    assert r["equal"], r
    rd = tmp_path / "resume" / "A" / "runs" / run_id(c)
    ev = read_json(rd / "continue_result.json")["prune_events"]
    assert [e["event"] for e in ev] == ["prune", "regrow", "prune"]
    ck = torch.load(rd / "ckpt" / "final.pt", map_location="cpu", weights_only=False)
    gm = GraphNet.from_checkpoint(ck["model"], "cpu")
    W = [gm.mods[gm.nodes[n].pkey].weight for n in gm.topo_order() if gm.nodes[n].op == "linear"][:-1]
    assert all(int((w.abs().sum(1) == 0).sum()) > 0 for w in W)   # each hidden layer has pruned (zero) rows


def test_transplants_are_saved_and_reload_in_a_fresh_process(tmp_path):
    b = T.base()
    p = T.traj({"topology": "layered", "rounds": 2, "contract_every": 1, "contract_updates": 4})
    tp = resolve({"kind": "transplant", "data": T.DATA, "model": T.MODEL, "train": T.TRAIN, "seeds": {"optimizer": 0},
                  "parents": {"upstream": run_id(b), "downstream": run_id(p[-1])},
                  "transplant": {"upstream_stage": "baseline", "downstream_stage": "final", "align": "affine"}})
    rd = _run(p + [tp], tmp_path)
    saved = read_json(rd / "transplant_result.json")["info"]["saved_models"]
    assert set(saved) == {"upstream", "downstream", "direct", "aligned"}
    code = r"""
import sys, json, torch
sys.path.insert(0, sys.argv[1])
from cop.graph.graph import GraphNet
from cop.data.registry import load_bundle
from cop.train.trainer import predict
rd, data = sys.argv[2], json.loads(sys.argv[3])
b = load_bundle(data)
out = {}
for name in ("upstream", "downstream", "direct", "aligned"):
    g = GraphNet.from_checkpoint(torch.load(f"{rd}/ckpt/transplant_{name}.pt", weights_only=False)["model"], "cpu")
    y = predict(g, b.partitions()["test"]).float()
    out[name] = bool(torch.equal(y, torch.load(f"{rd}/preds/{name}__test.pt", weights_only=False)))
print(json.dumps(out))
"""
    res = subprocess.run([sys.executable, "-c", code, str(ROOT), str(rd), json.dumps(T.DATA)], capture_output=True,
                         text=True, check=True)
    assert all(json.loads(res.stdout.strip().splitlines()[-1]).values())


def test_alignment_fits_run_on_cpu_for_any_input_device():
    from cop.cop_pegs.transplant import fit_affine_alignment, fit_symbol_alignment
    x = torch.randn(40, 4)
    m, info = fit_affine_alignment(x, x @ torch.randn(4, 4) + 1)
    assert info["fit_device"] == "cpu" and next(m.parameters()).device.type == "cpu"
    m, info = fit_symbol_alignment(torch.tensor([[0.], [1.]]), torch.tensor([[1.], [0.]]))
    assert torch.equal(m(torch.tensor([[0.], [1.]])), torch.tensor([[1.], [0.]]))


# ----------------------------------------------------------------------------- V3-07 / V3-09 / V3-11

def test_map_adaptation_cells_share_dimensions_bits_and_narrowing(tmp_path):
    out = {}
    for maps in ("frozen", "learned"):
        cfgs = T.cop({"task_kind": "cycles", "cycles": 2, "n_pearls": 3, "cycle_pegs": "relearned",
                      "cycle_peg_maps": maps, "cycle_peg_width": "narrowed", "cycle_peg_recalibrate": "yes"},
                     {"dim": 4, "mode": "uniform", "bits": 2})
        rd = _run(cfgs, tmp_path / maps)
        cyc = read_json(rd / "cycles_result.json")
        out[maps] = [(c["peg_dims"], c["peg_bits_per_example"], (c.get("narrowing") or {}).get("to")) for c in cyc["cycles"]]
        assert cyc["peg_maps"] == maps and cyc["peg_width"] == "narrowed"
    assert out["frozen"] == out["learned"]


def test_backward_aware_estimate_depends_on_what_trains():
    from cop.graph import edits as E
    g = build_mlp(8, [16, 16], 3, torch_gen(0, "init"))
    iid = E.insert_residual_zero(g, E.cut_at(g, "post_act", 1), torch_gen(0, "insertion"), width=4)
    full = backward_aware_macs(g, 1, {})
    pk_impl = {g.nodes[n].pkey for n in g.implants[iid].nodes if g.nodes[n].pkey}
    apply_trainable(g, pk_impl)
    frozen = backward_aware_macs(g, 1, {})
    assert frozen < full < 3 * forward_macs(g, 1, {})


def test_local_fit_phases_mark_compute_incomplete(tmp_path):
    from cop.experiments.continuation import run_work
    rd = _run(T.cop({"task_kind": "cycles", "cycles": 2, "n_pearls": 3}, {"dim": 4}), tmp_path)
    assert run_work(rd)["macs_complete"] is False


def test_replay_contracts_at_the_realised_adaptive_rounds(tmp_path):
    g = {"topology": "layered", "rounds": 4, "contract_every": 2, "updates_per_round": 6, "contract_updates": 3}
    src = T.traj({**g, "contract_trigger": "damage", "contract_threshold": -1.0})
    rd = _run(src, tmp_path)
    realised = [x["round"] for x in read_json(rd / "contractions.json")]
    b = src[0]
    rep = resolve({"kind": "trajectory", "data": T.DATA, "model": T.MODEL, "train": T.TRAIN,
                   "growth": {"width": 8, **g, "contract_trigger": "replay"}, "seeds": {"optimizer": 0},
                   "parents": {"baseline": run_id(b), "schedule": run_id(src[-1])}})
    rd2 = _run([rep], tmp_path)
    assert [x["round"] for x in read_json(rd2 / "contractions.json")] == realised


def test_trainable_state_is_recorded_per_phase(tmp_path):
    """V3-11c: a growth policy label describes the growth phase; contraction trains every tensor, and the
    log says so phase by phase."""
    cf = T.traj({"topology": "layered", "rounds": 2, "contract_every": 1, "contract_updates": 4},
                train={**T.TRAIN, "freeze": "original_frozen"})
    rd = _run(cf, tmp_path)
    ev = [r for r in read_jsonl(rd / "log.jsonl") if r.get("event") == "trainable_state"]
    grow = [r for r in ev if r["segment"].startswith("round_")]
    con = [r for r in ev if r["segment"].startswith("contract_")]
    assert grow and con
    assert all(r["policy"] == "original_frozen" and r["trainable_params"] < r["total_params"] for r in grow)
    assert all(r["trainable_params"] == r["total_params"] for r in con)


def test_wave7_has_the_matched_factor_cells():
    """V3-11a/b, V3-07: the broad policy comparisons stay, and the matched cells exist beside them."""
    from cop.orchestration.manifest import generate
    B = generate([7], "smoke")
    E = list(B.entries.values())
    con = {(e["cfg"].get("design") or {}).get("contrast") for e in E
           if (e["cfg"].get("design") or {}).get("arm") == "treated"}
    for cut in ("same", "moving", "nested"):
        assert f"M_F|teacher3_n2048|{cut}_every2" in con            # matched contraction frequency
    for tag in ("policy_fixed_every1", "fixed_every2_matched_max_interval", "policy_damage_trigger",
                "replay_of_damage_trigger"):
        assert f"F06e|teacher3_n2048|{tag}" in con
    for maps in ("frozen", "learned"):
        for width in ("constant", "narrowed"):
            assert f"F07c|teacher3_n2048_d6|maps_{maps}_width_{width}" in con
    rep = [e for e in E if (e["cfg"].get("growth") or {}).get("contract_trigger") == "replay"]
    src = B.entries[rep[0]["cfg"]["parents"]["schedule"]]["cfg"]
    assert src["growth"]["contract_trigger"] == "damage"
    assert src["growth"]["contract_every"] == rep[0]["cfg"]["growth"]["contract_every"]
    # every wave-7 control runs at a constant learning rate without warmup (V3-11d guard)
    for e in E:
        if e["cfg"]["kind"] == "continue":
            assert e["cfg"]["train"].get("lr_schedule", "constant") == "constant"
            assert int(e["cfg"]["train"].get("warmup", 0) or 0) == 0


def test_controls_refuse_a_non_constant_schedule():
    from cop.orchestration.manifest import Builder, teacher_data, MLP
    from cop.orchestration.wave7 import W7, Cell
    B = Builder("smoke")
    S = W7(B)
    cell = Cell("c", lambda s: teacher_data(3, 2048, s), MLP(64))
    rid, _ = S.history(cell, {"topology": "layered", "rounds": 1}, 0)
    with pytest.raises(ValueError, match="constant learning rate"):
        S.controls(cell, 0, rid, "k", "F", "v", "blk", train_over={"lr_schedule": "cosine"})
    with pytest.raises(ValueError, match="constant learning rate"):   # warmup is not a control key
        S.controls(cell, 0, rid, "k", "F", "v", "blk", train_over={"warmup": 5})
    rid2, _ = S.history(cell, {"topology": "layered", "rounds": 1}, 0, train_over={"warmup": 5})
    with pytest.raises(ValueError, match="constant learning rate"):   # read from the treated job itself
        S.controls(cell, 0, rid2, "k", "F", "v", "blk")


def test_summary_counts_diverged_and_ineligible_and_lists_complete_but_diverged(tmp_path):
    """V3-12: denominators stay visible; a complete-but-diverged run is listed as untested."""
    from cop.analysis.strengthening import summarize_strengthening
    t, c = _rows()
    td = dict(t, run_id="t2", replication="r1", diverged=True, eligible=False, eligibility_reasons="diverged")
    c2 = dict(c, run_id="c2", replication="r1")
    summ, pairs = compact_gain([t, c, td, c2], strict=False, rejected=[])
    row = next(r for r in summ if r["control_arm"] == "C1")
    assert row["n_pairs"] == 1 and row["n_treated_diverged"] == 1 and row["n_expected"] == 2
    assert row["n_unmatched"] == 1 and "exploratory" in row["interval"]
    # real runs: a diverged repair is complete, yet it is not eligible and is listed
    p = T.traj({"topology": "layered", "rounds": 1, "updates_per_round": 5})
    rp = T.child("repair", p[-1], {"repair": {"region": "full", "deletion": "all", "budget_multiplier": 4.,
                                              "eval_points": 2, "extension_factor": 1.}})
    rp = resolve({**rp, "train": {**rp["train"], "optimizer": "sgd", "lr": 1e38, "grad_clip": 0.},
                  "design": {"family": "audit", "variant": "divergence", "arm": "treated", "contrast": "d"}})
    rd = _run(p + [rp], tmp_path)
    assert read_json(tmp_path / "runs" / run_id(rp) / "status.json")["status"] == "complete"
    assert read_json(rd / "endpoint.json")["diverged"]
    res = summarize_strengthening(load_runs(tmp_path), tmp_path / "s")
    un = read_json(tmp_path / "s" / "s_untested_or_ineligible_cells.json")
    assert res["n_diverged"] == 1 and res["n_ineligible"] == 1
    assert any("diverged" in u[3] for u in un)


# ----------------------------------------------------------------------------- CUDA paths (run on the GPU)

@CUDA
def test_cuda_affine_and_symbol_alignment():
    from cop.cop_pegs.transplant import fit_affine_alignment, fit_symbol_alignment
    x = torch.randn(40, 4, device="cuda")
    y = x @ torch.randn(4, 4, device="cuda") + 1
    m, _ = fit_affine_alignment(x, y)
    assert torch.allclose(m.cuda()(x), y, atol=1e-4, rtol=1e-4)
    xs = torch.tensor([[0.], [1.], [0.], [1.]], device="cuda")
    m, _ = fit_symbol_alignment(xs, 1 - xs)
    assert torch.equal(m.cuda()(xs), 1 - xs)


@CUDA
def test_cuda_end_to_end_jobs_and_resume(tmp_path):
    """transplant (affine), C8 across prune and regrowth (interrupted and resumed), a finite-peg later-query
    chain with unseen messages, a CoP bridge, and a tree contraction: all on the GPU."""
    from resume_harness import compare_interrupted
    ex = {"device": "cuda"}
    b = T.base()
    p = T.traj({"topology": "tree_depth2", "rounds": 3})
    dis = T.child("dissipation", p[-1], {"dissipation": {"method": "linear", "speed_updates": 6, "post_updates": 6}})
    tp = resolve({"kind": "transplant", "data": T.DATA, "model": T.MODEL, "train": T.TRAIN, "seeds": {"optimizer": 0},
                  "parents": {"upstream": run_id(b), "downstream": run_id(b)},
                  "transplant": {"upstream_stage": "baseline", "downstream_stage": "baseline", "align": "affine"}})
    LQ = {"name": "later_query", "n_train": 256, "n_val": 128, "n_test": 128, "params": {"n_bits": 10, "pool_size": 512}}
    lq = T.cop({}, {"mode": "uniform", "bits": 1, "dim": 2}, data=LQ)
    br = T.cop({}, {"temp_channel": 4, "temp_open_updates": 5, "temp_on": "middle", "temp_target": "peg"})
    for c in p + [dis, tp] + lq + br:
        assert run_job(c, tmp_path / "jobs", ex) == "complete", status_of(tmp_path / "jobs", run_id(c))
    lqr = read_json(tmp_path / "jobs" / "runs" / run_id(lq[-1]) / "cop_chain_result.json")["later_queries"]
    assert any(v.get("test_unseen_message_frac", 0) >= 0 for v in lqr["pegs"].values())
    TR = {**T.TRAIN, "checkpoint_every": 3}
    b2 = T.base(train=TR)
    c8 = resolve({"kind": "continue", "data": T.DATA, "model": T.MODEL, "train": TR, "seeds": {"optimizer": 0},
                  "parents": {"baseline": run_id(b2)},
                  "continue": {"updates": 13, "arm": "prune_regrow", "prune_period": 10, "prune_duration": 5}})
    r = compare_interrupted([b2, c8], tmp_path / "resume", ex=ex)
    assert r["equal"], r
