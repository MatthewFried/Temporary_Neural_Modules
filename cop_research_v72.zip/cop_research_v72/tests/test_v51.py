"""v50 and v51: coordinated edits (audit_v5/tools/coordinated_edits.py), tested on REAL outputs of a miniature
wave 25 analysed with the current launcher's exact options (read from scripts/51), plus a second experiment that
reuses the same seeds.

Real outputs: the evidence contract; the identities seen in the tables; the selection recomputed from the edit
table for every criterion and selection partition, unchanged when every test metric is replaced, and reproduced from
the saved validation decisions alone; the rank schemes, their identities against the edit table, the energy
bookkeeping and the three separate size measures (v51); the transfer factorial, its parameter accounting and every
contrast; the fold's two segments, its implementation check on every partition, its fit diagnostics and the saved
fit rebuilt into the folded tensors (v51); the training diagnostics recomputed independently (v51); output
membership.  Failure paths on real (forged or damaged) panels: a corrupted checkpoint, a variant with another f0, a
checkpoint of the wrong age, a missing variant, a group split across experiments, and each deliberately wrong fold
through the real pipeline (v51).  Units: the selection with one seed failing, grouping, the rank arithmetic and
accounting, a wrong patched layer, the fold algebra and its checks, the decision comparison (equal error with
different predictions must fail).  The CUDA test runs where CUDA is available and compares saved decisions."""
from __future__ import annotations

import csv
import json
import random
import re
import shlex
import shutil
import subprocess
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "audit_v5/tools"))

ROOT = Path(__file__).resolve().parents[1]
LAUNCHER = ROOT / "scripts/51_v51_coordinated_edits.sh"
TOOL = ROOT / "audit_v5/tools/coordinated_edits.py"
VARIANTS = ("A_free", "B_scfrozen", "C_dsfrozen", "D_bothfrozen")
LATER = ("L2", "L3", "L4", "L5")
ALL_S, ALL_R = "I2+I3+I4+I5", "L2+L3+L4+L5"


def _rows(path):
    t = Path(path).read_text()
    return [] if t.strip() == "empty" else list(csv.DictReader(open(path)))


def _f(x):
    return None if x in (None, "") else float(x)


def _launcher_contract():
    src = LAUNCHER.read_text()
    files = re.search(r'^EDIT_FILES="([^"]+)"', src, re.M).group(1).split(",")
    variants = re.search(r'^VARIANTS="([^"]+)"', src, re.M).group(1)
    cmd = re.search(r'^  step edits25 (.*?"\$PREDS")', src, re.M | re.S).group(1).replace("\\\n", " ")
    toks = shlex.split(cmd)
    return files, variants, toks[toks.index("--strict") + 1:]


def _tool(root, man, prefix, *args, device="cpu"):
    return subprocess.run([sys.executable, str(TOOL), str(root), str(root / prefix), "--manifest", str(man),
                           "--strict", "--device", device, *args], capture_output=True, text=True)


def _launcher_args(root, preds):
    _, variants, rest = _launcher_contract()
    sub = {"$PREDS": str(preds), "$VARIANTS": variants}
    args = [sub.get(t, t) for t in rest]
    i = args.index("--device")                       # the launcher's "$DEVICE"; the caller chooses the device
    return args[:i] + args[i + 2:]


@pytest.fixture(scope="module")
def panel(tmp_path_factory):
    import test_v45 as T
    root = tmp_path_factory.mktemp("w25e")
    _, Tr, R, _, man = T._panel(root)
    files, _, _ = _launcher_contract()
    r = _tool(root, man, "edits25", *_launcher_args(root, root / "preds25"))
    return {"root": root, "r": r, "files": files, "man": man, "T": Tr, "R": R,
            "t": lambda n: _rows(root / f"edits25_{n}.csv")}


def _evidence(root, files):
    out = root / "ev.json"
    r = subprocess.run([sys.executable, str(ROOT / "scripts/check_evidence.py"), str(out),
                        f"edits25:0:{root / 'edits25'}:{','.join(files)}"], capture_output=True, text=True)
    return r.returncode, json.loads(out.read_text())["steps"]["edits25"]


# ----------------------------------------------------------------------------- real outputs

def test_real_outputs_pass_the_launchers_evidence_contract(panel, tmp_path):
    assert panel["r"].returncode == 0, panel["r"].stdout[-3000:] + panel["r"].stderr[-3000:]
    import coordinated_edits as CE
    cov = json.loads((panel["root"] / "edits25_coverage.json").read_text())
    assert cov["passed"] and cov["analysis_schema"] == CE.ANALYSIS_SCHEMA
    assert "exploratory" in cov["status"] and cov["output_membership_failures"] == []
    assert cov["analysed_runs"] == cov["expected_runs"] == 4 and len(cov["experiments"]) == 1
    assert cov["numerics"]["device"] == "cpu" and cov["numerics"]["tf32"] is False
    assert cov["selection"]["primary"] == ["native", "val"] and set(cov["selection"]["criteria"]) == set(CE.CRITERIA)
    assert cov["manifest_sha256"] and set(cov["source_sha256"]) == {"coordinated_edits.py", "selective_reversal.py",
                                                                    "audit_common.py"}
    rc, ev = _evidence(panel["root"], panel["files"])
    assert rc == 0 and ev["ok"], ev
    assert cov["fold"]["implementation_tolerance"] == CE.FOLD_TOL and cov["options"]["inject_fold_fault"] is None
    for name in ("minimal_sets_counts", "fold_fit", "f0_gradients_summary"):
        d = tmp_path / name
        d.mkdir()
        for f in panel["files"]:
            shutil.copy2(panel["root"] / f"edits25_{f}", d / f"edits25_{f}")
        (d / f"edits25_{name}.csv").write_text("empty\n")
        rc, ev = _evidence(d, panel["files"])
        assert rc == 1 and ev["missing"] == [f"edits25_{name}.csv (an empty table)"]


def test_checks_record_age_provenance_and_inventory(panel):
    chk = panel["t"]("checks")
    assert len(chk) == 4 and {r["variant"] for r in chk} == set(VARIANTS)
    assert len({r["experiment"] for r in chk}) == 1 and "#" in chk[0]["experiment"]
    for r in chk:
        assert r["updates_since_f0"] == r["expected_updates_since_f0"] == "12"
        assert r["leaves"] == "I2 I3 I4 I5" and r["n_later_layers"] == "4"
        assert r["leaf_slots"].split() == ["I2=spec/r1/a", "I3=spec/r1/b", "I4=spec/r2/a", "I5=spec/r2/b"]
        assert r["selection_partitions"] == "val val_indep"
        assert (r["expected_minimal_points"], r["expected_selection_rows"], r["expected_rank_points"],
                r["expected_fold_points"], r["expected_fold_fit_rows"], r["expected_train_group_rows"]) == \
            ("256", "120", "39", "30", "3", "11")
        assert all(r[k] for k in ("f0_param_hash", "f0_graph_hash", "state_param_hash", "state_graph_hash"))
        assert (r["later_layers_equal_f0"] == "True") == (r["variant"] in ("C_dsfrozen", "D_bothfrozen"))
    assert len({(r["f0_param_hash"], r["f0_graph_hash"]) for r in chk}) == 1


def _edits(panel):
    by = defaultdict(dict)
    for r in panel["t"]("minimal_edits"):
        by[r["run_id"]][(r["deleted"], r["restored"])] = r
    return by


def test_edit_table_identities(panel):
    chk = {r["run_id"]: r for r in panel["t"]("checks")}
    for rid, pts in _edits(panel).items():
        assert len(pts) == 256
        assert _f(pts[("none", "none")]["dis_native"]) == 0.0 and _f(pts[("none", "none")]["minus_native"]) == 0.0
        assert _f(pts[("none", "none")]["logit_rms_native"]) == 0.0
        assert _f(pts[(ALL_S, ALL_R)]["dis_extraction"]) == 0.0 and _f(pts[(ALL_S, ALL_R)]["minus_extraction"]) == 0.0
        if chk[rid]["later_layers_equal_f0"] == "True":      # C, D: rewinding changes nothing
            for (S, R), r in pts.items():
                assert _f(r["test_err"]) == _f(pts[(S, "none")]["test_err"])
        for r in pts.values():
            assert r["val_indep_err"] != "" and r["experiment"] == chk[rid]["experiment"]
            assert _f(r["minus_native"]) == pytest.approx(_f(r["test_err"]) - _f(pts[("none", "none")]["test_err"]))


def _num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return v


def _table_rows(pts):
    """the edit table as the selection's input: {(deleted tuple, rewound tuple): metric row}."""
    tup = lambda s: () if s == "none" else tuple(s.split("+"))       # noqa: E731
    return {(tup(S), tup(R)): {k: _num(v) for k, v in r.items()} for (S, R), r in pts.items()}


SEL_COLS = ("deleted", "criterion", "selection_partition", "is_primary", "removable", "n_candidates",
            "inclusion_minimal_sets", "min_size", "chosen", "qualifies_by_construction")


def _norm(r):
    return tuple(str(r[c]) if r[c] is not None else "" for c in SEL_COLS)


def test_selection_is_recomputed_and_ignores_every_test_metric(panel):
    import coordinated_edits as CE
    sets = defaultdict(list)
    for r in panel["t"]("minimal_sets"):
        sets[r["run_id"]].append(r)
    rng = random.Random(0)
    for rid, pts in _edits(panel).items():
        rows = _table_rows(pts)
        mine = sets[rid]
        # f0's validation errors are not in the edit table: they are the f0 criterion's recorded references
        f0ref = {f"{r['selection_partition']}_err": _f(r["reference_sel_err"]) for r in mine
                 if r["criterion"] == "f0"}
        refs = {"native": rows[((), ())], "extraction": rows[(tuple(ALL_S.split("+")), LATER)], "f0": f0ref}
        want = CE.selection_rows({}, rows, refs, ("val", "val_indep"), ["I2", "I3", "I4", "I5"], 4)
        assert len(want) == len(mine) == 15 * 4 * 2
        assert sorted(_norm(r) for r in want) == sorted(_norm(r) for r in mine)
        # replace every test-side metric by noise: the selection is identical
        noisy = {k: {**r, **{m: rng.random() for m in ("test_err", "test_ce", "shift_err", "rare_err", "gain_vs_f0",
                                                       "minus_native", "minus_extraction", "dis_f0", "dis_native")}}
                 for k, r in rows.items()}
        again = CE.selection_rows({}, noisy, refs, ("val", "val_indep"), ["I2", "I3", "I4", "I5"], 4)
        assert [_norm(r) for r in again] == [_norm(r) for r in want]
        for r in mine:
            ref = {"native": pts[("none", "none")], "extraction": pts[(ALL_S, ALL_R)]}
            ek = f"{r['selection_partition']}_err"
            if r["criterion"] in ref:
                assert _f(r["reference_sel_err"]) == _f(ref[r["criterion"]][ek])
            if r["criterion"] == "legacy_worse_endpoint":
                assert _f(r["reference_sel_err"]) == max(_f(ref["native"][ek]), _f(ref["extraction"][ek]))
            assert _f(r["threshold"]) == pytest.approx(_f(r["reference_sel_err"]) + CE.MARGIN)
            near = min(abs(_f(q[ek]) - _f(r["threshold"])) for (S_, _), q in pts.items() if S_ == r["deleted"])
            assert _f(r["nearest_threshold_distance"]) == pytest.approx(near, abs=1e-15)
            assert (r["is_primary"] == "True") == ((r["criterion"], r["selection_partition"]) == CE.PRIMARY)
            assert "whole-layer rewinds" in r["edit_menu"] and r["margin"] == str(CE.MARGIN)
            if r["removable"] == "True":
                ch = pts[(r["deleted"], r["chosen"])]
                assert _f(r["chosen_test_err"]) == _f(ch["test_err"]) == _f(r["policy_test_err"])
                assert _f(r["chosen_sel_delta"]) == pytest.approx(_f(ch[ek]) - _f(r["reference_sel_err"]))
                assert r["policy_is_fallback"] == "False" and r["policy_additions_deleted"] == r["n_deleted"]
            else:
                assert r["chosen_test_err"] == "" and r["policy_is_fallback"] == "True"
                assert _f(r["policy_test_err"]) == _f(pts[("none", "none")]["test_err"])
                assert r["policy_additions_deleted"] == "0"
            if r["deleted"] == ALL_S and r["criterion"] in ("extraction", "legacy_worse_endpoint"):
                assert r["qualifies_by_construction"] and r["removable"] == "True"


def test_selection_summaries_count_every_run(panel):
    import coordinated_edits as CE
    counts = panel["t"]("minimal_sets_counts")
    assert len(counts) == 4 * 15 * 4 * 2
    sets = panel["t"]("minimal_sets")
    for c in counts:
        mine = [r for r in sets if all(r[k] == c[k] for k in ("variant", "deleted", "criterion",
                                                              "selection_partition"))]
        assert int(c["runs_expected"]) == int(c["runs_analysed"]) == len(mine) == 1
        assert int(c["runs_selected"]) == sum(r["removable"] == "True" for r in mine)
    sm = panel["t"]("minimal_sets_summary")
    assert {r["population"] for r in sm} == set(CE.POPULATIONS.values())
    for r in sm:
        if r["population"] == CE.POPULATIONS["policy"]:
            assert r["runs_contributing"] == r["runs_analysed"]
    ch = panel["t"]("minimal_sets_chosen")
    assert all(r["experiment"] and r["criterion"] for r in ch)


def test_saved_decisions_reproduce_errors_and_the_primary_selection(panel):
    import coordinated_edits as CE
    d = panel["root"] / "preds25"
    sets = defaultdict(dict)
    for r in panel["t"]("minimal_sets"):
        if r["is_primary"] == "True":
            sets[r["run_id"]][r["deleted"]] = r
    tables = {"minimal_edits": lambda r: f"{r['deleted']}|{r['restored']}",
              "rank_restores": lambda r: f"{r['scheme']}|{r['target_layer']}|{r['rank']}",
              "transfer": lambda r: f"{r['addition_donor']}|{r['change_donor'].split(' ')[0]}",
              "fold": lambda r: f"{r['fold']}|{r['segment']}|"
                                f"{float(r['lam'] if r['segment'].startswith('1') else r['rewind_t']):g}"}
    for t, key in tables.items():
        by = defaultdict(dict)
        for r in panel["t"](t):
            by[r["run_id"]][key(r)] = r
        assert len(by) == 4
        for rid, pts in by.items():
            z = np.load(d / f"{rid}__{t}.npz", allow_pickle=False)
            meta = json.loads(str(z["meta"]))
            assert meta["partitions"] == ["test", "val", "val_indep"] and meta["experiment"]
            assert len(meta["order"]) == len(pts) == z["preds_test"].shape[0]
            err = {p: (z[f"preds_{p}"] != z[f"labels_{p}"]).mean(1) for p in meta["partitions"]}
            for i, k in enumerate(meta["order"]):
                for p in meta["partitions"]:
                    assert float(err[p][i]) == pytest.approx(_f(pts[k][f"{p}_err"]), abs=1e-12), (t, k, p)
            if t != "minimal_edits":
                continue
            val = {k: float(err["val"][i]) for i, k in enumerate(meta["order"])}
            thr = val["none|none"] + CE.MARGIN                     # the primary rule from saved decisions alone
            for S, srow in sets[rid].items():
                pts_ = {(() if k.split("|")[1] == "none" else tuple(k.split("|")[1].split("+"))): v
                        for k, v in val.items() if k.split("|")[0] == S}
                _, mins, ch = CE.minimal_sets(pts_, thr)
                assert (srow["removable"] == "True") == (ch is not None)
                assert srow["chosen"] == (CE.label(ch) if ch is not None else "")
                assert srow["inclusion_minimal_sets"] == "|".join(CE.label(m) for m in mins)


def test_rank_schemes(panel):
    import coordinated_edits as CE
    plans = CE.rank_plans(list(LATER))
    assert len(plans) == 23 + 4 * 4 and len({(p["scheme"], p["target_layer"], p["rank"]) for p in plans}) == 39
    edits = _edits(panel)
    by = defaultdict(dict)
    for r in panel["t"]("rank_restores"):
        by[r["run_id"]][(r["scheme"], r["target_layer"], r["rank"])] = r
    for rid, pts in by.items():
        assert len(pts) == 39
        g = edits[rid]
        twins = {("no_edit", "none", "none"): "none", ("all_later_topk_bias_restored", "all", "full"): ALL_R,
                 ("head_only_full", "L5", "full"): "L5", ("hidden_topk_head_kept", "hidden", "full"): "L2+L3+L4"}
        for k, R in twins.items():                              # the same whole-layer rewinds in the edit table
            for m in ("test_err", "val_err", "val_indep_err", "dis_native"):
                assert _f(pts[k][m]) == _f(g[(ALL_S, R)][m]), (k, m)
        b0 = pts[("all_later_topk_bias_restored", "all", "0")]
        assert b0["note"] == "BIAS-ONLY edit" and b0["v49_scheme"] == "all_layers"
        assert all(b0[f"bias_{n}"] == "restored" and b0[f"eff_rank_{n}"] == "0" for n in LATER)
        full = pts[("all_later_topk_bias_restored", "all", "full")]
        none_ = pts[("no_edit", "none", "none")]
        assert (int(none_["entries_changed"]), int(none_["correction_factor_storage"])) == (0, 0)
        assert len({r["inference_params"] for r in pts.values()}) == 1 and "factor storage" in \
            full["storage_convention"]
        changed = full["energy_restored_L2"] != ""                # A, B: the later layers moved
        r1 = pts[("all_later_topk_bias_restored", "all", "1")]
        if changed:
            # a full rewind stores every entry; a rank-1 correction stores few numbers but changes most entries
            assert int(full["correction_factor_storage"]) == int(full["later_entries_total"])
            assert 0 < int(full["entries_changed"]) <= int(full["later_entries_total"])
            assert int(r1["entries_changed"]) > int(r1["correction_factor_storage"]) > \
                int(r1["correction_intrinsic_dim"]) > 0
        else:                                                     # C, D: nothing to correct, nothing counted
            assert all(int(r[k]) == 0 for r in pts.values()
                       for k in ("entries_changed", "correction_factor_storage", "correction_intrinsic_dim"))
        for n in LATER:
            e = [_f(pts[("all_later_topk_bias_restored", "all", str(k))][f"energy_restored_{n}"]) for k in CE.RANKS]
            if e[-1] is None:                                    # the layer did not change: reported, not scored
                assert all(x is None for x in e)
                continue
            assert e[0] == 0.0 and e[-1] == 1.0 and all(x <= y + 1e-12 for x, y in zip(e, e[1:]))
        assert full["eff_rank_L5"] == "2"                         # the two-output head: rank 2 is the whole head
        k4 = pts[("all_later_topk_bias_restored", "all", "4")]
        assert k4["eff_rank_L5"] == ("2" if k4["energy_restored_L5"] != "" else "0")   # an unchanged layer: no rank
        for n in LATER:
            for k in CE.ONE_LAYER_RANKS:
                r = pts[("partial_target_layer_other_layers_full", n, str(k))]
                assert r["v49_scheme"] == "one_layer" and "OTHER later layers are fully rewound" in r["note"]
                assert all(r[f"weight_{m}"] == "full" for m in LATER if m != n) and r[f"weight_{n}"] == str(k)
        kept = pts[("all_later_topk_bias_kept", "all", "2")]
        assert all(kept[f"bias_{n}"] == "kept" for n in LATER)
        hk = pts[("hidden_topk_head_kept", "hidden", "2")]
        assert hk["weight_L5"] == "keep" and hk["bias_L5"] == "kept" and hk["eff_rank_L5"] == "0"
    lay = panel["t"]("rank_layers")
    assert len(lay) == 4 * 4
    for r in lay:
        assert (r["is_head"] == "True") == (r["layer"] == "L5") and int(r["max_rank"]) == min(int(r["shape_out"]),
                                                                                           int(r["shape_in"]))
        if r["zero_change"] == "True":
            assert r["variant"] in ("C_dsfrozen", "D_bothfrozen") and r["energy_top1"] == ""
        else:
            assert 0.0 < _f(r["energy_top1"]) <= _f(r["energy_top2"]) <= 1.0 + 1e-12


def test_transfer_factorial_accounting_and_contrasts(panel):
    import coordinated_edits as CE
    rows = panel["t"]("transfer")
    res = {(r["group"], r["host"], r["addition_donor"], r["change_donor"]): r for r in rows}
    donors = sorted({r["change_donor"] for r in rows} - {"none (f0)"})
    assert donors == ["A_free", "B_scfrozen"]
    assert {r["transfer_kind"] for r in rows} == {CE.TRANSFER_KIND}
    F0 = "none (f0)"
    for g in {r["group"] for r in rows}:
        assert sum(1 for k in res if k[0] == g) == 4 * 5 * 3
        for h in VARIANTS:
            hd = h if h in donors else F0
            own = res[(g, h, h, hd)]
            assert own["package"] == "own" and _f(own["dis_native"]) == 0.0 and own["params_from_donor"] == "0"
            assert own["host_keeps"] == "first layer + its additions + its later layers"
            nop = res[(g, h, "none", F0)]
            assert nop["package"] == "none" and _f(nop["dis_extraction"]) == 0.0
            assert int(nop["params_deleted"]) > 0 and (int(nop["params_rewound_to_f0"]) > 0) == (h in donors)
            for d in donors:
                if d == h:
                    continue
                m = res[(g, h, d, d)]
                assert m["package"] == "matched_foreign" and m["host_keeps"] == "first layer"
                tot = int(m["host_params_total"])
                first = tot - int(m["params_from_donor"])        # everything but the host's first layer is replaced
                assert _f(m["share_of_host_from_donor"]) == pytest.approx(int(m["params_from_donor"]) / tot)
                assert 0 < first < tot and _f(m["share_of_host_from_donor"]) > 0.5
    con = panel["t"]("transfer_contrasts")
    seen = set()
    for c in con:
        g, h, d, q = c["group"], c["host"], c["donor"], c["quantity"]
        hd = h if h in donors else F0
        m = res[(g, h, d, d)]
        other = {"foreign_additions_on_host_changes_minus_matched": (h, d, hd),
                 "host_additions_on_foreign_changes_minus_matched": (h, h, d),
                 "foreign_additions_only_minus_matched": (h, d, F0),
                 "foreign_changes_only_minus_matched": (h, "none", d),
                 "host_extraction_minus_matched": (h, "none", F0),
                 "host_native_minus_matched": (h, h, hd)}.get(c["contrast"])
        seen.add(c["contrast"])
        if other is not None:
            assert _f(c["value"]) == pytest.approx(_f(res[(g, *other)][q]) - _f(m[q]), abs=1e-12)
        elif c["contrast"] == "matched_minus_donor_native":
            assert _f(c["value"]) == pytest.approx(_f(m[q]) - _f(res[(g, d, d, d)][q]), abs=1e-12)
        else:
            assert c["contrast"] == "f0_minus_matched"
            if q == "test_err":                                   # f0's test error = the row's error + its gain
                assert _f(c["value"]) == pytest.approx(_f(m["gain_vs_f0"]), abs=1e-12)
        dup = c["algebraic_duplicate_of"]
        assert (dup != "") == (c["contrast"] == "foreign_additions_on_host_changes_minus_matched"
                               and h not in donors)
    assert seen == {"foreign_additions_on_host_changes_minus_matched",
                    "host_additions_on_foreign_changes_minus_matched", "foreign_additions_only_minus_matched",
                    "foreign_changes_only_minus_matched", "host_extraction_minus_matched",
                    "host_native_minus_matched", "f0_minus_matched", "matched_minus_donor_native"}


def _fold(panel):
    by = defaultdict(dict)
    for r in panel["t"]("fold"):
        coord = float(r["lam"]) if r["segment"].startswith("1") else float(r["rewind_t"])
        by[r["run_id"]][(r["fold"], r["segment"], coord)] = r
    return by


def test_fold_two_segments_and_their_ends(panel):
    import coordinated_edits as CE
    edits = _edits(panel)
    S1, S2 = CE.SEGMENTS
    by = _fold(panel)
    assert len(by) == 4
    for rid, pts in by.items():
        assert len(pts) == 3 * (len(CE.LAMBDAS) + len(CE.FOLD_PATH)) == 30
        g = edits[rid]
        for fd in CE.FOLDS:
            for m in ("test_err", "val_err", "val_indep_err", "dis_native"):
                assert _f(pts[(fd, S1, 1.0)][m]) == _f(g[("none", "none")][m])       # lambda 1: the native network
                assert _f(pts[(fd, S2, 1.0)][m]) == _f(g[(ALL_S, ALL_R)][m])         # t 1: the extraction
            assert _f(pts[(fd, S1, 1.0)]["dis_native"]) == 0.0
            # the two implementations of the surrogate (in the graph, folded) are one function up to rounding
            assert abs(_f(pts[(fd, S1, 0.0)]["test_ce"]) - _f(pts[(fd, S2, 0.0)]["test_ce"])) < 1e-5
        for m in ("test_err", "val_err", "dis_native"):           # the zero surrogate is the deletion, both ways
            assert _f(pts[("zero", S1, 0.0)][m]) == _f(pts[("zero", S2, 0.0)][m]) == _f(g[(ALL_S, "none")][m])
    paths = panel["t"]("fold_paths")
    assert len(paths) == 4 * 3
    for p in paths:
        pts = by[p["run_id"]]
        for q in ("test_err", "test_ce"):
            v1 = [_f(pts[(p["fold"], S1, lam)][q]) for lam in CE.LAMBDAS]
            v2 = [_f(pts[(p["fold"], S2, t)][q]) for t in CE.FOLD_PATH]
            assert _f(p[f"seg1_max_{q}"]) == max(v1) and _f(p[f"seg2_max_{q}"]) == max(v2)
            assert _f(p[f"seg1_barrier_{q}"]) == pytest.approx(max(v1) - max(v1[0], v1[-1]), abs=1e-12)
            assert _f(p[f"seg2_barrier_{q}"]) == pytest.approx(max(v2) - max(v2[0], v2[-1]), abs=1e-12)
            assert _f(p[f"combined_max_{q}"]) == max(v1 + v2)
            # the whole sampled route against its two ends: the native network and the extraction
            assert _f(p[f"combined_barrier_{q}"]) == pytest.approx(max(v1 + v2) - max(v1[0], v2[-1]), abs=1e-12)
            assert _f(p[f"surrogate_minus_native_{q}"]) == pytest.approx(v1[-1] - v1[0], abs=1e-12)
        assert "sampled points only" in p["note"]


def test_fold_fit_diagnostics_and_implementation_check(panel):
    import coordinated_edits as CE
    chk = {r["run_id"]: r for r in panel["t"]("checks")}
    by = _fold(panel)
    fit = panel["t"]("fold_fit")
    assert len(fit) == 4 * 3
    for r in fit:
        parts = chk[r["run_id"]]["partitions_evaluated"].split()
        assert r["fold_layer"] == "L3" and r["fit_data"] == "train" and "no gradient steps" in r["fit_cost"]
        for p in ["train", *parts]:                               # residuals on every partition, fitted on train
            raw, thr = _f(r[f"resid_share_raw_{p}"]), _f(r[f"resid_share_through_layer_{p}"])
            if r["fold"] == "zero":
                assert raw == thr == 1.0
            else:
                assert 0.0 <= raw < 1.0 and thr >= 0.0
            assert (r[f"affine_r2_{p}"] != "") == (r["fold"] == "affine")
        if r["fold"] == "affine":
            assert int(r["design_rank"]) <= int(r["design_cols"]) == int(r["merge_width"]) + 1
            assert _f(r["lstsq_rcond"]) == CE.LSTSQ_RCOND and _f(r["M_fro"]) >= _f(r["M_spectral"]) > 0
            assert _f(r["resid_share_raw_train"]) <= next(
                _f(q["resid_share_raw_train"]) for q in fit if q["run_id"] == r["run_id"] and q["fold"] == "mean") \
                + 1e-12                                           # the affine fit contains the mean
        else:
            assert r["design_rank"] == "" and _f(r["M_fro"]) == 0.0
        # the implementation check: every partition, numerical tolerance, applies at t = 0 only
        if r["fold"] == "zero":
            assert _f(r["impl_max_rel_diff"]) == 0.0 and "bitwise" in r["impl_check_applies_to"]
        else:
            assert "rewind_t = 0" in r["impl_check_applies_to"] and _f(r["impl_tolerance"]) == CE.FOLD_TOL
            rel = [_f(r[f"impl_rel_diff_{p}"]) for p in parts]
            assert max(rel) == _f(r["impl_max_rel_diff"]) <= CE.FOLD_TOL
            assert sum(int(r[f"impl_decisions_differ_{p}"]) for p in parts) == int(r["impl_decisions_differ_total"])
        # agreement with the native network is reported per partition, separately from the errors
        t0 = by[r["run_id"]][(r["fold"], CE.SEGMENTS[1], 0.0)]
        assert _f(r["dis_native_test"]) == _f(t0["dis_native"])
        assert _f(r["err_minus_native_test"]) == pytest.approx(_f(t0["minus_native"]), abs=1e-12)
        assert all(r[f"prob_tv_native_{p}"] != "" and r[f"logit_rms_native_{p}"] != "" for p in parts)
    assert "impl_max_rel_diff" not in panel["t"]("fold")[0]       # not copied onto path rows


def test_the_saved_fit_rebuilds_the_folded_tensors(panel):
    import coordinated_edits as CE
    d = panel["root"] / "preds25"
    for r in panel["t"]("checks"):
        z = np.load(d / f"{r['run_id']}__fold_fit.npz", allow_pickle=False)
        meta = json.loads(str(z["meta"]))
        assert meta["fold_layer"] == "L3" and meta["state_param_hash"] == r["state_param_hash"]
        ck = torch.load(panel["root"] / "runs" / r["trajectory"] / "ckpt/final.pt", weights_only=False)
        W, b = ck["model"]["state"][meta["weight_key"]], ck["model"]["state"][meta["bias_key"]]
        M, c, um = (torch.from_numpy(z[k]) for k in ("M", "c", "u_mean"))
        Wa, ba = CE.fold_into(W, b, M, c)
        assert torch.equal(Wa, torch.from_numpy(z["W_fold_affine"])) and \
            torch.equal(ba, torch.from_numpy(z["b_fold_affine"]))
        Wm, bm = CE.fold_into(W, b, None, um)
        assert torch.equal(Wm, torch.from_numpy(z["W_fold_mean"])) and torch.equal(Wm, W) and \
            torch.equal(bm, torch.from_numpy(z["b_fold_mean"]))


@pytest.mark.parametrize("fault", ["transpose", "bias", "layer"])
def test_a_wrong_fold_fails_through_the_real_pipeline(panel, fault):
    """the tool's own self-test switch builds a wrong fold (M transposed, the bias term's sign, another layer):
    the implementation check against the in-graph surrogate must fail the group."""
    root = panel["root"]
    r = _tool(root, panel["man"], f"fault_{fault}", "--fold", "--inject-fold-fault", fault)
    cov = json.loads((root / f"fault_{fault}_coverage.json").read_text())
    assert r.returncode == 1 and cov["n_failed"] == 1 and cov["options"]["inject_fold_fault"] == fault
    assert "the surrogate" in cov["failed"][0]["reason"], cov["failed"][0]["reason"]


def test_training_diagnostics(panel):
    import coordinated_edits as CE
    from cop.data.registry import load_bundle
    from cop.graph.graph import GraphNet
    tg = panel["t"]("train_groups")
    assert len(tg) == (1 + 4) * len(CE.SUBGROUPS)
    by = defaultdict(dict)
    for r in tg:
        by[r["variant"]][r["subgroup"]] = r
    assert set(by) == {"f0", *VARIANTS}
    for v, g in by.items():
        n = int(g["all"]["n"])
        for a_, b_ in (("shortcut_sign_agrees", "shortcut_sign_disagrees"), ("majority", "rare"),
                       ("f0_correct", "f0_error")):
            assert int(g[a_]["n"]) + int(g[b_]["n"]) == n
            assert _f(g[a_]["loss_share"]) + _f(g[b_]["loss_share"]) == pytest.approx(1.0)
        assert sum(int(g[k]["n"]) for k in ("majority_agrees", "majority_disagrees", "rare_agrees",
                                            "rare_disagrees")) == n
    assert _f(by["f0"]["f0_error"]["err"]) == 1.0 and _f(by["f0"]["f0_correct"]["err"]) == 0.0
    # f0's gradient rows, recomputed here from the checkpoint and the data
    gr = {r["subgroup"]: r for r in panel["t"]("f0_gradients")}
    assert len(gr) == len(CE.SUBGROUPS) and gr["all"]["variant"] == "f0"
    cfg = panel["T"]["A"]
    b = load_bundle(cfg["data"], None, device="cpu")
    from cop.config import run_id
    ck = torch.load(panel["root"] / "runs" / run_id(cfg) / "ckpt/baseline_ref.pt", weights_only=False)
    f0 = GraphNet.from_checkpoint(ck["model"], "cpu").eval()
    tr = b.partitions()["train"]
    lay = b.meta["feature_layout"]
    c0, c1, sc = lay["causal"][0], lay["causal"][1], lay["shortcut"]
    x, y = tr.X["x"], tr.y.long()
    w1 = next(p for n_, p in f0.named_parameters() if p.dim() == 2 and p.shape[1] == x.shape[1])
    losses = torch.nn.functional.cross_entropy(f0.forward({"x": x}).double(), y, reduction="none")
    agree = (x[:, sc] > 0) == (y == 1)
    assert int(agree.sum()) == int(gr["shortcut_sign_agrees"]["n"])
    for sg, mk in (("all", torch.ones_like(agree)), ("shortcut_sign_disagrees", ~agree), ("rare", tr.groups == 1)):
        (gw,) = torch.autograd.grad(losses[mk].sum() / len(y), [w1], retain_graph=True)
        want = float((gw[:, c0:c1].double() * w1.detach()[:, c0:c1].double()).sum())
        assert _f(gr[sg]["dloss_dloggain_causal"]) == pytest.approx(want, rel=1e-6, abs=1e-12)
        assert _f(gr[sg]["grad_shortcut_norm"]) == pytest.approx(float(gw[:, sc].norm()), rel=1e-6, abs=1e-12)
        assert _f(gr[sg]["loss_contribution"]) == pytest.approx(float(losses[mk].sum()) / len(y), rel=1e-9)
    for q in ("dloss_dloggain_causal", "dloss_dloggain_shortcut", "loss_contribution"):
        assert _f(gr["majority"][q]) + _f(gr["rare"][q]) == pytest.approx(_f(gr["all"][q]), rel=1e-4, abs=1e-9)
    ch = {r["variant"]: r for r in panel["t"]("first_layer_change")}
    for v in VARIANTS:                                            # the shortcut column moves only where it trains
        frozen = v in ("B_scfrozen", "D_bothfrozen")
        assert (_f(ch[v]["shortcut_change_over_f0_norm"]) == 0.0) == frozen
        assert (_f(ch[v]["shortcut_norm_ratio"]) == 1.0) == frozen
        assert _f(ch[v]["causal_change_over_f0_norm"]) > 0 and -1.0 <= _f(ch[v]["causal_change_cos_with_f0"]) <= 1.0
        assert f"dloss_along_causal_change_{v}" in gr["all"]


# ----------------------------------------------------------------------------- a second experiment, same seeds

def _second_cell(root, conds="AB"):
    """two more expansions and removals on OTHER data settings (rho_train 0.8) with the same data and optimizer
    seeds and the same contrast label: a different experiment only through its settings."""
    import test_v45 as T
    from test_v31 import _lin, _traj as t31, _x25
    from cop.config import resolve
    base = t31()
    data = {**base[0]["data"], "params": {**base[0]["data"]["params"], "rho_train": 0.8}}
    p = t31(data=data)
    Tr = {k: resolve({**p[-1], "train": {**p[-1]["train"], **T.AUD, **T.HOLDS[k]}}) for k in conds}
    R = {k: _x25(resolve({**_lin(Tr[k]), "train": {**Tr[k]["train"], **T.LIFT}}), variant=T.VAR[k]) for k in conds}
    T._run([p[0], *Tr.values()], root)
    for c in R.values():
        T._run([c], root)
    return [p[0], *Tr.values(), *R.values()]


def test_two_experiments_with_identical_seeds_stay_separate(panel, tmp_path):
    from cop.config import run_id
    root = tmp_path / "two"
    shutil.copytree(panel["root"] / "runs", root / "runs")
    extra = _second_cell(root)
    man = root / "m2.jsonl"
    lines = [l for l in open(panel["man"]) if l.strip()]
    with open(man, "w") as f:
        f.writelines(lines)
        for c in extra:
            f.write(json.dumps({"run_id": run_id(c), "cfg": c}) + "\n")
    r = _tool(root, man, "two", "--minimal-edits", "--transfer")
    assert r.returncode == 0, r.stdout[-2000:] + r.stderr[-3000:]
    cov = json.loads((root / "two_coverage.json").read_text())
    assert cov["expected_groups"] == cov["analysed_groups"] == 2 and cov["expected_runs"] == 6
    exps = cov["experiments"]
    assert len(exps) == 2 and sorted(map(len, exps.values())) == [2, 4]
    assert len({e.split("#")[0] for e in exps}) == 1               # the same contrast label, two experiments
    chk = _rows(root / "two_checks.csv")
    assert len({(r["data_draw"], r["optimizer_seed"]) for r in chk}) == 1 and len({r["group"] for r in chk}) == 2
    small = next(e for e, v in exps.items() if len(v) == 2)
    sm = _rows(root / "two_minimal_edits_summary.csv")
    for e in exps:
        mine = [r for r in sm if r["experiment"] == e and r["metric"] == "test_err"]
        assert len(mine) == len(exps[e]) * 256 and all(r["n_unique_data_draws"] == "1" for r in mine)
    counts = _rows(root / "two_minimal_sets_counts.csv")
    assert {r["runs_expected"] for r in counts} == {"1"} and \
        len([r for r in counts if r["experiment"] == small]) == 2 * 15 * 4 * 2
    tr = _rows(root / "two_transfer.csv")
    assert len([r for r in tr if r["experiment"] == small]) == 2 * 3 * 3
    # with the wave-25 design declared, the two-variant experiment's group fails closed
    r = _tool(root, man, "two_declared", "--minimal-edits", "--expect-variants", ",".join(VARIANTS))
    cov = json.loads((root / "two_declared_coverage.json").read_text())
    assert r.returncode == 1 and cov["n_failed"] == 1 and "the design declares" in cov["failed"][0]["reason"]


# ----------------------------------------------------------------------------- failure paths on real panels

def _copy(panel, tmp_path):
    root = tmp_path / "bad"
    shutil.copytree(panel["root"] / "runs", root / "runs")
    return root


def _fails(root, man, why, *extra):
    r = _tool(root, man, "bad", "--rank-restores", *extra)
    cov = json.loads((root / "bad_coverage.json").read_text())
    assert r.returncode == 1 and not cov["passed"] and cov["analysed_groups"] == 0
    assert why in cov["failed"][0]["reason"], cov["failed"][0]["reason"]


def test_a_corrupted_checkpoint_fails_the_group(panel, tmp_path):
    from cop.config import run_id
    root = _copy(panel, tmp_path)
    p = root / "runs" / run_id(panel["T"]["B"]) / "ckpt/final.pt"
    ck = torch.load(p, weights_only=False)
    k = next(k for k, v in ck["model"]["state"].items() if v.is_floating_point())
    ck["model"]["state"][k] = ck["model"]["state"][k] + 1e-3
    torch.save(ck, p)
    _fails(root, panel["man"], "do not match the recorded parameter hash")


def test_a_variant_with_another_f0_fails_the_group(panel, tmp_path):
    """a self-consistent checkpoint (its hash re-recorded) that is not the group's f0: an incompatible donor."""
    import audit_common as AC
    from cop.config import run_id
    root = _copy(panel, tmp_path)
    p = root / "runs" / run_id(panel["T"]["C"]) / "ckpt/baseline_ref.pt"
    ck = torch.load(p, weights_only=False)
    k = next(k for k, v in ck["model"]["state"].items() if v.is_floating_point())
    ck["model"]["state"][k] = ck["model"]["state"][k] + 1e-3
    ck["lineage"]["param_hash"] = AC.param_hash_of(ck)
    torch.save(ck, p)
    _fails(root, panel["man"], "do not share f0")


def test_a_checkpoint_of_the_wrong_age_fails_the_group(panel, tmp_path):
    """a valid checkpoint whose trainer is not at the configured expansion length."""
    import coordinated_edits as CE
    from cop.config import run_id
    root = _copy(panel, tmp_path)
    p = root / "runs" / run_id(panel["T"]["A"]) / "ckpt/final.pt"
    ck = torch.load(p, weights_only=False)
    ck["trainer"]["state"]["global_step"] = int(ck["trainer"]["state"]["global_step"]) - 6
    torch.save(ck, p)
    _fails(root, panel["man"], "its configured age is 12")
    assert CE.expected_age(panel["T"]["A"]) == 12
    with pytest.raises(CE.Fail):
        CE.check_age(6, 12, "x")
    with pytest.raises(CE.Fail):
        CE.expected_age({"growth": {"compute_schedule": "total", "updates_per_round": 6, "rounds": 2}})


def test_a_missing_variant_fails_the_group(panel, tmp_path):
    from cop.config import run_id
    root = _copy(panel, tmp_path)
    drop = run_id(panel["R"]["D"])
    man = root / "m.jsonl"
    with open(man, "w") as f:
        f.writelines(l for l in open(panel["man"]) if l.strip() and json.loads(l)["run_id"] != drop)
    _fails(root, man, "the design declares", "--expect-variants", ",".join(VARIANTS))
    shutil.rmtree(root / "runs" / drop)                           # declared in the manifest, absent on disk
    _fails(root, panel["man"], "missing")


# ----------------------------------------------------------------------------- units

def _cfgs(rho, variant, ds=0, os_=0, tid="t"):
    t = {"data": {"data_seed": ds, "teacher_seed": ds, "params": {"rho_train": rho}}, "model": {"width": 8},
         "growth": {"rounds": 2, "updates_per_round": 6}, "seeds": {"optimizer": os_},
         "train": {"lr": 1e-3, "freeze_inputs": "shortcut" if variant == "B" else "none"}}
    r = {"kind": "dissipation", "data": t["data"], "seeds": {"optimizer": os_}, "parents": {"trajectory": tid},
         "design": {"family": "X25", "variant": variant, "arm": "treated", "contrast": "X25|c"},
         "dissipation": {"method": "linear", "speed_updates": 3}, "train": {"lr": 1e-3}}
    return r, t


def test_grouping_by_experiment_draw_and_seed():
    import coordinated_edits as CE
    m = {}
    for rho in (0.9, 0.8):
        for v in "AB":
            for ds in (0, 1):
                r, t = _cfgs(rho, v, ds, 0, f"t{rho}{v}{ds}")
                m[f"r{rho}{v}{ds}"], m[f"t{rho}{v}{ds}"] = r, t
    groups, declared = CE.group_jobs(m)
    assert len(groups) == 4 and len(declared) == 2 and all(set(g) == {"A", "B"} for g in groups.values())
    ra, ta = _cfgs(0.9, "A")
    rb, tb = _cfgs(0.9, "B")
    assert CE.experiment_id(ra, ta) == CE.experiment_id(rb, tb)            # the variant is not part of the cell
    assert CE.experiment_id(ra, ta) == CE.experiment_id(*_cfgs(0.9, "A", ds=5, os_=3))   # nor draw and seed
    assert CE.experiment_id(ra, ta) != CE.experiment_id(*_cfgs(0.8, "A"))
    wide = json.loads(json.dumps(ta))
    wide["model"]["width"] = 16
    assert CE.experiment_id(ra, ta) != CE.experiment_id(ra, wide)
    _, dec = CE.group_jobs(m, ["A", "B", "C"])
    assert all(v == {"A", "B", "C"} for v in dec.values())
    m["dup"] = json.loads(json.dumps(m["r0.9A0"]))
    with pytest.raises(CE.Fail):
        CE.group_jobs(m)


def _sel(draw, seed, removable, variant="B"):
    base = {"experiment": "e#1", "cell": "c", "variant": variant, "deleted": "I2", "n_deleted": 1,
            "criterion": "native", "selection_partition": "val", "selection_access": "a", "is_primary": True,
            "margin": 0.01, "data_draw": draw, "optimizer_seed": seed, "removable": removable}
    ch = {"chosen_test_err": 0.10 + 0.01 * seed, "chosen_n_restored": 1} if removable else \
        {"chosen_test_err": None, "chosen_n_restored": None}
    pol = {"policy_test_err": ch["chosen_test_err"] if removable else 0.30, "policy_n_restored": 1 if removable
           else 0, "policy_additions_deleted": 1 if removable else 0, "policy_is_fallback": not removable}
    return {**base, **ch, **pol}


def test_selection_summary_when_one_seed_fails():
    import coordinated_edits as CE
    rows = [_sel(1, 0, True), _sel(1, 1, False), _sel(2, 0, True), _sel(2, 1, True)]
    counts, bd, sm = CE.selection_summary(rows, {("e#1", "B"): 5})
    c = counts[0]
    assert (c["runs_expected"], c["runs_analysed"], c["runs_selected"]) == (5, 4, 3)
    assert (c["draws"], c["draws_every_seed_selected"], c["draws_partially_selected"],
            c["draws_no_seed_selected"]) == (2, 1, 1, 0) and c["success_rate_runs"] == 0.75
    get = lambda metric, pop: next(r for r in sm if r["metric"] == metric and r["population"] == pop)   # noqa: E731
    cond = get("test_err", CE.POPULATIONS["chosen"])
    # conditional on success: draw 1 contributes its one selected seed (0.10), draw 2 both (0.105)
    assert cond["mean_v"] == pytest.approx((0.10 + 0.105) / 2) and cond["runs_contributing"] == 3
    assert cond["draws_partially_selected"] == 1
    d1 = next(r for r in bd if r["metric"] == "test_err" and r["population"] == CE.POPULATIONS["chosen"]
              and r["data_draw"] == 1)
    assert d1["n_values"] == 1 and d1["optimizer_settings"] == "0"
    pol = get("test_err", CE.POPULATIONS["policy"])
    # every run, the failed one at the fallback's error: draw 1 = (0.10 + 0.30) / 2, draw 2 = 0.105
    assert pol["mean_v"] == pytest.approx((0.20 + 0.105) / 2) and pol["runs_contributing"] == 4
    assert get("is_fallback", CE.POPULATIONS["policy"])["mean_v"] == pytest.approx((0.5 + 0.0) / 2)
    assert get("additions_deleted", CE.POPULATIONS["policy"])["mean_v"] == pytest.approx((0.5 + 1.0) / 2)


def test_minimal_sets_unit():
    import coordinated_edits as CE
    pts = {(): 0.5, ("L2",): 0.2, ("L3",): 0.4, ("L2", "L3"): 0.1, ("L4",): 0.19}
    cand, mins, ch = CE.minimal_sets(pts, 0.2)
    assert set(cand) == {("L2",), ("L2", "L3"), ("L4",)} and mins == [("L2",), ("L4",)] and ch == ("L4",)
    assert CE.minimal_sets({(): 0.5}, 0.1) == ([], [], None)


def test_rank_k_restore_in_float64():
    import coordinated_edits as CE
    g = torch.Generator().manual_seed(0)
    w0 = torch.randn(6, 5, generator=g)
    d = torch.randn(6, 2, generator=g) @ torch.randn(2, 5, generator=g)        # a rank-2 change
    w = w0 + d
    r0, i0 = CE.rank_k_restore(w, w0, 0)
    assert torch.equal(r0, w) and i0 == {"eff_rank": 0, "energy": 0.0, "zero_change": False}
    r1, i1 = CE.rank_k_restore(w, w0, 1)
    assert 0.0 < i1["energy"] < 1.0 and torch.linalg.matrix_rank((r1 - w0).double(), atol=1e-4) == 1
    r2, i2 = CE.rank_k_restore(w, w0, 2)
    assert i2["energy"] == pytest.approx(1.0) and torch.allclose(r2, w0, atol=1e-5)
    r9, i9 = CE.rank_k_restore(w, w0, 9)
    assert i9["eff_rank"] == 5                                         # capped at the matrix's rank bound
    rf, i_f = CE.rank_k_restore(w, w0, "full")
    assert torch.equal(rf, w0) and i_f["energy"] == 1.0 and i_f["eff_rank"] == 5
    # no change at all: nothing to score (None), whatever the rank
    for k in (0, 1, "full"):
        t, i = CE.rank_k_restore(w0, w0, k)
        assert torch.equal(t, w0) and i["energy"] is None and i["zero_change"]
    # the subtraction and the SVD are in float64: the result equals the float64 reference exactly
    dd = w.double() - w0.double()
    U, S, Vh = torch.linalg.svd(dd, full_matrices=False)
    assert torch.equal(r1, (w.double() - (U[:, :1] * S[:1]) @ Vh[:1]).to(w.dtype))
    sp = CE.change_spectrum(w, w0)
    assert sp["numerical_rank"] == 2 and sp["energy_top2"] == pytest.approx(1.0) and sp["max_rank"] == 5
    assert CE.change_spectrum(w0, w0)["energy_top1"] is None


def test_a_wrong_patched_layer_is_caught():
    import coordinated_edits as CE
    f0 = {"mods.p2.weight": torch.zeros(2, 2), "mods.p2.bias": torch.zeros(2), "mods.p3.weight": torch.zeros(2, 2),
          "mods.p3.bias": torch.zeros(2)}
    base = {k: v + 1.0 for k, v in f0.items()}
    lkeys = {"p2": ["mods.p2.weight", "mods.p2.bias"], "p3": ["mods.p3.weight", "mods.p3.bias"]}
    t = CE.edit_tensors(f0, lkeys, ["p3"])
    assert set(t) == set(lkeys["p3"]) and all(t[k] is f0[k] for k in t)
    want = {**base, **t}
    CE.verify_patch({k: v.clone() for k, v in want.items()}, want, "ok")
    wrong = {**base, **CE.edit_tensors(f0, lkeys, ["p2"])}             # the other layer was rewound
    with pytest.raises(CE.Fail, match="is not the intended tensor"):
        CE.verify_patch(wrong, want, "edit")
    with pytest.raises(CE.Fail, match="parameter set"):
        CE.verify_patch({k: v for k, v in want.items() if "bias" not in k}, want, "edit")
    assert not CE.same_everywhere({"test": torch.ones(2), "val": torch.ones(2)},
                                  {"test": torch.ones(2), "val": torch.zeros(2)})


def test_fold_algebra():
    import coordinated_edits as CE
    g = torch.Generator().manual_seed(1)
    H = torch.randn(200, 6, generator=g).double().relu()
    M0, c0 = torch.randn(6, 6, generator=g).double() * 0.3, torch.randn(6, generator=g).double()
    U = H @ M0.T + c0                                                    # an exactly affine addition
    M, c, info = CE.affine_fit(H, U)
    assert torch.allclose(M, M0, atol=1e-9) and torch.allclose(c, c0, atol=1e-9)
    assert info["design_rank"] == info["design_cols"] == 7 and info["design_rows"] == 200
    assert info["lstsq_rcond"] == CE.LSTSQ_RCOND and info["design_cond"] > 1
    assert CE.r2(U, H @ M.T + c) == pytest.approx(1.0) and CE.r2(U, U.mean(0).expand_as(U)) == pytest.approx(0.0)
    assert CE.residual_share(U, H @ M.T + c) == pytest.approx(0.0, abs=1e-18)
    assert CE.residual_share(U, torch.zeros_like(U)) == 1.0 and CE.residual_share(torch.zeros(3, 2), U[:3, :2]) is None
    W, b = torch.randn(4, 6, generator=g), torch.randn(4, generator=g)
    # a residual the receiving layer does not see: large raw share, zero share through the layer
    null = torch.linalg.svd(W.double())[2][-1]                           # W null = 0
    R = torch.randn(200, 1, generator=g).double() * null
    assert CE.residual_share(U + R, U) > 1e-3 and CE.residual_share(U + R, U, W) < 1e-12
    Wf, bf = CE.fold_into(W, b, M, c)
    direct = (H + U) @ W.double().T + b.double()                         # the layer on h + u(h)
    assert torch.allclose(H @ Wf.double().T + bf.double(), direct, atol=1e-5)
    # the surrogate at the merge and its fold are the same function of h
    sv = CE.surrogate_value(H.float(), M, c)
    assert torch.allclose(sv.double() @ W.double().T + b.double(), H.float().double() @ Wf.double().T + bf.double(),
                          atol=1e-4)
    assert torch.equal(CE.surrogate_value(H.float(), None, torch.zeros(6, dtype=torch.float64)), H.float())
    Wm, bm = CE.fold_into(W, b, None, U.mean(0))                         # the mean fold touches the bias only
    assert torch.equal(Wm, W) and torch.allclose(bm.double(), b.double() + W.double() @ U.mean(0), atol=1e-6)
    assert CE.r2(torch.ones(3, 2), torch.ones(3, 2)) is None
    # the self-test faults really are wrong folds
    for fault in ("transpose", "bias"):
        Wx, bx = CE.fold_into(W, b, M, c, fault)
        assert not torch.allclose(H @ Wx.double().T + bx.double(), direct, atol=1e-2)


def test_implementation_check_unit():
    import coordinated_edits as CE
    g = torch.Generator().manual_seed(2)
    z = torch.randn(50, 2, generator=g) * 3
    ok = CE.implementation_check({"test": z + 1e-7, "val": z[:10]}, {"test": z, "val": z[:10]}, "x")
    assert ok["impl_max_rel_diff"] <= CE.FOLD_TOL and ok["impl_decisions_differ_total"] == 0
    assert {"impl_rel_diff_test", "impl_rel_diff_val", "impl_decisions_differ_val"} <= set(ok)
    with pytest.raises(CE.Fail, match="on val"):                          # a partition other than test
        CE.implementation_check({"test": z, "val": z[:10] + 0.1}, {"test": z, "val": z[:10]}, "x")
    with pytest.raises(CE.Fail, match="different partitions"):
        CE.implementation_check({"test": z}, {"test": z, "val": z[:10]}, "x")
    # a decision that differs at a near-tie is counted with its margin (within the tolerance it can only be one)
    tie = torch.tensor([[1.0, 1.0 + 1e-6], [3.0, -3.0]])
    flip = torch.tensor([[1.0 + 1e-6, 1.0], [3.0, -3.0]])
    r = CE.implementation_check({"test": flip}, {"test": tie}, "x")
    assert r["impl_decisions_differ_test"] == 1 and r["impl_decisions_differ_total"] == 1
    assert 0 < r["impl_max_margin_of_differing_test"] <= 2 * CE.FOLD_TOL * 3.0
    # a decision that differs at a real margin needs a logit difference beyond the tolerance: the check fails
    with pytest.raises(CE.Fail, match="differs from the surrogate"):
        CE.implementation_check({"test": torch.tensor([[1.0, 0.0], [3.0, -3.0]])},
                                {"test": torch.tensor([[0.0, 1.0], [3.0, -3.0]])}, "x")


def test_fold_site_refuses_unsupported_merges(panel):
    import coordinated_edits as CE
    from cop.config import run_id
    from cop.graph.graph import GraphNet
    import selective_reversal as SR
    ck = torch.load(panel["root"] / "runs" / run_id(panel["T"]["A"]) / "ckpt/final.pt", weights_only=False)
    g = GraphNet.from_checkpoint(ck["model"], "cpu")
    L = SR.backbone_layers(g)
    leaves = ["I2", "I3", "I4", "I5"]
    hin, mid, PL = CE.fold_site(g, leaves, L)
    assert PL == L[2] and g.nodes[mid].op == "add" and g.nodes[mid].inputs[0] == hin
    g.nodes[mid].attrs["coefs"][0] = 0.5                                  # the skip is no longer h itself
    with pytest.raises(CE.Fail, match="coefficient is not 1"):
        CE.fold_site(g, leaves, L)
    g.nodes[mid].attrs["coefs"][0] = 1.0
    with pytest.raises(CE.Fail, match=r"skip \+ the leaf additions"):
        CE.fold_site(g, leaves[:3], L)


def test_rank_accounting_units():
    import coordinated_edits as CE
    g = torch.Generator().manual_seed(3)
    w0 = torch.randn(6, 5, generator=g)
    w = w0 + torch.randn(6, 1, generator=g) @ torch.randn(1, 5, generator=g)      # a DENSE rank-1 change
    r1, info = CE.rank_k_restore(w, w0, 1)
    assert CE.entries_changed({"w": w}, {"w": r1}) == 30                    # every entry moves
    assert CE.rank_storage(w.shape, info["eff_rank"], False, False) == (11, 10)   # k (m + n), k (m + n - k)
    assert CE.rank_storage(w.shape, 5, True, False) == (30, 30)
    # no change: nothing changed, nothing stored, whatever is "restored"
    z, zi = CE.rank_k_restore(w0, w0, "full")
    assert CE.entries_changed({"w": w0}, {"w": z}) == 0 and CE.rank_storage(w0.shape, zi["eff_rank"], True,
                                                                           zi["zero_change"]) == (0, 0)
    assert CE.entries_changed({"w": w0, "b": torch.zeros(3)}, {"b": torch.tensor([0.0, 1.0, 0.0])}) == 1


def test_subgroups_unit():
    import coordinated_edits as CE
    xs = torch.tensor([1.0, -1.0, 1.0, -1.0])
    y = torch.tensor([1, 1, 0, 0])
    m = CE.subgroup_masks(xs, y, torch.tensor([0, 0, 1, 1]), torch.tensor([True, False, True, True]))
    assert tuple(m) == CE.SUBGROUPS
    assert m["shortcut_sign_agrees"].tolist() == [True, False, False, True]      # positive sign points at class 1
    assert m["rare_disagrees"].tolist() == [False, False, True, False]
    assert m["f0_error"].tolist() == [False, True, False, False] and m["all"].all()


# ----------------------------------------------------------------------------- comparing two analyses

def _fake_run(d, preds, labels, sel=None):
    d.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(d / "r1__minimal_edits.npz", preds_test=preds.astype(np.int16),
                        labels_test=labels.astype(np.int16),
                        meta=np.asarray(json.dumps({"order": ["a", "b"], "partitions": ["test"]})))
    if sel is not None:
        with open(d.parent / f"{d.name}_minimal_sets.csv", "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(sel[0]))
            w.writeheader()
            w.writerows(sel)


def test_equal_error_with_different_predictions_fails_the_comparison(tmp_path):
    import compare_edit_runs as CMP
    y = np.array([0, 1] * 50)
    a = np.stack([y.copy(), y.copy()])
    a[0, :10] = 1 - a[0, :10]                                           # 10 errors on examples 0..9
    b = np.stack([y.copy(), y.copy()])
    b[0, 50:60] = 1 - b[0, 50:60]                                       # 10 errors on OTHER examples
    assert (a != y).mean(1).tolist() == (b != y).mean(1).tolist()         # identical error rates
    row = {"run_id": "r1", "deleted": "I2", "criterion": "native", "selection_partition": "val",
           "removable": "True", "chosen": "none", "inclusion_minimal_sets": "none",
           "nearest_threshold_distance": "0.004"}
    _fake_run(tmp_path / "pa", a, y, [row])
    _fake_run(tmp_path / "pb", b, y, [{**row, "removable": "False", "chosen": ""}])
    rep = CMP.compare(tmp_path / "pa", tmp_path / "pa", tmp_path / "pb", tmp_path / "pb")
    d = rep["decisions"]["minimal_edits"]["test"]
    assert not rep["passed"] and d["max_disagreements"] == 20 and d["max_abs_error_diff"] == 0.0
    assert d["examples"] == 100 and d["tolerance"] == CMP.tolerance(100) == 2 and "differs on 20 of 100" in \
        rep["failures"][0]
    # a differing selection is listed with its threshold distance; it is reported, not what fails
    assert rep["selection"]["rows_differing"] == 1 and rep["selection"]["selection_identical"] is False
    assert rep["selection"]["differing"][0]["threshold_distance_a"] == "0.004"
    _fake_run(tmp_path / "pc", a, y, [row])
    same = CMP.compare(tmp_path / "pa", tmp_path / "pa", tmp_path / "pc", tmp_path / "pc")
    assert same["passed"] and same["selection"]["selection_identical"] and \
        same["decisions"]["minimal_edits"]["test"]["total_disagreements"] == 0
    near = a.copy()
    near[1, 3] = 1 - near[1, 3]                                         # one decision: inside the tolerance
    _fake_run(tmp_path / "pd", near, y)
    assert CMP.compare(tmp_path / "pa", tmp_path / "pa", tmp_path / "pd", tmp_path / "pd")["passed"]
    assert CMP.main([str(tmp_path / "pa"), str(tmp_path / "pa"), str(tmp_path / "pb"), str(tmp_path / "pb"),
                     "--out", str(tmp_path / "rep.json")]) == 1 and (tmp_path / "rep.json").exists()
    (tmp_path / "pd" / "r1__minimal_edits.npz").unlink()                  # a missing file is not agreement
    assert not CMP.compare(tmp_path / "pa", tmp_path / "pa", tmp_path / "pd", tmp_path / "pd")["passed"]


def test_junit_ran_distinguishes_skipped_from_run(tmp_path):
    def run(xml):
        p = tmp_path / "j.xml"
        p.write_text(xml)
        return subprocess.run([sys.executable, str(ROOT / "scripts/junit_ran.py"), str(p)],
                              capture_output=True, text=True).returncode
    ts = '<testsuites><testsuite tests="{t}" skipped="{s}" failures="{f}" errors="0"/></testsuites>'
    assert run(ts.format(t=1, s=0, f=0)) == 0
    assert run(ts.format(t=1, s=1, f=0)) == 1 and run(ts.format(t=0, s=0, f=0)) == 1
    assert run(ts.format(t=1, s=0, f=1)) == 1 and run("not xml") == 1
    assert subprocess.run([sys.executable, str(ROOT / "scripts/junit_ran.py"), str(tmp_path / "absent.xml")],
                          capture_output=True).returncode == 1


# ----------------------------------------------------------------------------- the CUDA backend

@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA device required")
def test_cuda_analysis_agrees_with_cpu_decision_by_decision(panel):
    """the same miniature analysed on the CUDA device: every bitwise identity holds on that backend (the tool
    fails otherwise), and its SAVED DECISIONS are compared with the CPU analysis' for every candidate of every table
    on every saved partition (compare_edit_runs; equal error rates are not the test).  Selection differences are
    written to the report."""
    import os
    import compare_edit_runs as CMP
    dev = os.environ.get("COP_TEST_CUDA_DEVICE", "cuda")
    root = panel["root"]
    r = _tool(root, panel["man"], "cuda25", *_launcher_args(root, root / "preds_cuda"), device=dev)
    assert r.returncode == 0, r.stdout[-2000:] + r.stderr[-3000:]
    cov = json.loads((root / "cuda25_coverage.json").read_text())
    assert cov["passed"] and cov["numerics"]["device"] == dev and cov["numerics"]["tf32"] is False
    rep = CMP.compare(root / "edits25", root / "preds25", root / "cuda25", root / "preds_cuda")
    rep["devices"] = {"a": "cpu", "b": dev, "gpu": cov["numerics"]["gpu"]}
    out = os.environ.get("COP_CUDA_REPORT")
    if out:
        Path(out).write_text(json.dumps(rep, indent=1))
    assert rep["passed"], rep["failures"][:5]
    assert set(rep["decisions"]) == {"minimal_edits", "rank_restores", "transfer", "fold"}
    for t, parts in rep["decisions"].items():
        assert set(parts) == {"test", "val", "val_indep"}, t
        for p, d in parts.items():
            assert d["candidates"] > 0 and d["max_disagreements"] <= d["tolerance"]
    assert rep["selection"]["compared"] and rep["selection"]["rows"] == 4 * 15 * 4 * 2
