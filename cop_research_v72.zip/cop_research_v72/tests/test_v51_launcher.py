"""v51: the coordinated-edits launcher (scripts/51; scripts/49 and scripts/50 are retired), analysis only.  It reads
the complete v46 wave-25 panel read-only, regenerates the manifest (a failed generation stops the run), runs the CPU
tests and audit_v5/tools/coordinated_edits.py with all five parts ON THE DECLARED DEVICE (passed explicitly; cuda
and cuda:N are CUDA), checks its evidence and packages a diagnostic archive whatever happens; it never trains.  On a
CUDA device the tool's CUDA test must have RUN and passed (its junit report is checked: a skipped test is not a
validation).  The real script runs in the v48 launcher test's mock COP_HOME."""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import test_v48_launcher as L  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = "51_v51_coordinated_edits.sh"
TABLES = re.search(r'^EDIT_FILES="([^"]+)"', (ROOT / "scripts" / SCRIPT).read_text(), re.M).group(1).split(",")
ANALYSIS = r"""import json, os, sys
prefix = sys.argv[2]
for f in ("--minimal-edits", "--rank-restores", "--transfer", "--fold", "--train-diagnostics", "--manifest",
          "--strict"):
    assert f in sys.argv, f
assert "--inject-fold-fault" not in sys.argv
assert sys.argv[sys.argv.index("--save-preds") + 1].endswith("preds25")
assert sys.argv[sys.argv.index("--expect-variants") + 1] == "A_free,B_scfrozen,C_dsfrozen,D_bothfrozen"
ev = open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a")
ev.write("edits read " + sys.argv[1] + "\n")
ev.write("edits device " + sys.argv[sys.argv.index("--device") + 1] + "\n")
rc = int(os.environ.get("MOCK_EDITS_RC", "0"))
for t in os.environ["MOCK_TABLES"].split(","):
    if t.endswith(".json"):
        json.dump({"passed": rc == 0}, open(prefix + "_" + t, "w"))
        continue
    empty = os.environ.get("MOCK_EDITS_EMPTY") == t
    open(prefix + "_" + t, "w").write("empty\n" if empty else "variant,x\nB,1\n")
sys.exit(rc)
"""


@pytest.fixture
def h(tmp_path):
    home = tmp_path / "home"
    (home / "scripts").mkdir(parents=True)
    shutil.copy2(ROOT / "scripts" / SCRIPT, home / "scripts" / SCRIPT)
    for f in ("package_reports.py", "check_evidence.py", "junit_ran.py"):
        shutil.copy2(ROOT / "scripts" / f, home / "scripts" / f)
    (home / "scripts/panel_state.py").write_text(L.PANEL_STATE)
    (home / "scripts/common.sh").write_text(L.COMMON)
    (home / "audit_v5/tools").mkdir(parents=True)
    (home / "audit_v5/tools/coordinated_edits.py").write_text(ANALYSIS)
    pt = home / "fake_pytest.sh"
    pt.write_text(r'''#!/usr/bin/env bash
echo "pytest $*" >> "$MOCK_HOME/events.txt"
echo "3 passed"
xml=""; prev=""
for a in "$@"; do [ "$prev" = "--junitxml" ] && xml="$a"; prev="$a"; done
case " $* " in
  *" -k cuda "*)
    [ -n "$xml" ] && echo "<testsuites><testsuite tests=\"1\" skipped=\"${MOCK_CUDA_SKIPPED:-0}\" failures=\"0\" errors=\"0\"/></testsuites>" > "$xml"
    [ -n "$COP_CUDA_REPORT" ] && [ "${MOCK_CUDA_SKIPPED:-0}" = 0 ] && echo '{"passed": true}' > "$COP_CUDA_REPORT"
    echo "cuda test device $COP_TEST_CUDA_DEVICE" >> "$MOCK_HOME/events.txt"
    exit "${MOCK_CUDA_TEST_RC:-0}" ;;
esac
[ -n "$xml" ] && echo "<testsuites><testsuite tests=\"3\" skipped=\"0\" failures=\"0\" errors=\"0\"/></testsuites>" > "$xml"
exit "${MOCK_TEST_RC:-0}"
''')
    pt.chmod(0o755)
    zipdir = tmp_path / "zips"
    zipdir.mkdir()
    base = {k: v for k, v in os.environ.items() if k not in ("DIAGNOSTIC_OVERRIDE", "COP_PYTEST")}
    env = dict(base, MOCK_HOME=str(home), COP_RESULTS=str(tmp_path / "results"), ZIP_DIR=str(zipdir), SCALE="full",
               HOME=str(tmp_path), COP_PYTEST=str(pt), V46_RESULTS=str(tmp_path / "cop_results_v46"),
               MOCK_PANEL_STATE="0", MOCK_TABLES=",".join(TABLES))
    return {"home": home, "res": tmp_path / "results", "zip": zipdir / "cop_v51_edits_reports.zip", "env": env,
            "v46": tmp_path / "cop_results_v46"}


def _sh(h, common=None, **env):
    if common is not None:
        (h["home"] / "scripts/common.sh").write_text(common)
    e = dict(h["env"], **{k: str(v) for k, v in env.items()})
    return subprocess.run(["bash", str(h["home"] / "scripts" / SCRIPT)], env=e, capture_output=True, text=True,
                          cwd=str(h["home"]))


def _verdict(h):
    return json.loads((h["res"] / "v51_reports/verdict.json").read_text())


def _events(h):
    p = h["home"] / "events.txt"
    return p.read_text() if p.exists() else ""


def test_success_reads_the_v46_panel_read_only_on_the_declared_device(h):
    r = _sh(h)
    assert r.returncode == 0, r.stdout + r.stderr
    v = _verdict(h)
    assert v["all_passed"] and set(v["steps"]) == {"environment", "manifest25", "panel_source", "cpu_tests",
                                                    "edits25", "evidence25", "manifest_copy", "package",
                                                    "package_final"}
    ev = _events(h)
    assert "cop run" not in ev and "edits read " + str(h["v46"] / "panel25") in ev
    assert "edits device cpu" in ev and "-k cuda" not in ev         # the mock environment declares DEVICE=cpu
    names = zipfile.ZipFile(h["zip"]).namelist()
    for f in TABLES:
        assert f"cop_v51_edits_reports/v51_reports/edits25_{f}" in names, f
    assert not (h["v46"] / "panel25").exists()


@pytest.mark.parametrize("device", ["cuda", "cuda:0"])
def test_cuda_devices_run_the_tools_cuda_test_first_and_forward_the_device(h, device):
    cuda = L.COMMON.replace("DEVICE=cpu", f"DEVICE={device}")
    r = _sh(h, common=cuda)
    assert r.returncode == 0, r.stdout + r.stderr
    ev = _events(h)
    assert f"edits device {device}" in ev and "tests/test_v51.py -k cuda" in ev
    assert f"cuda test device {device}" in ev and ev.index("-k cuda") < ev.index("edits read")
    v = _verdict(h)
    assert v["steps"]["cuda_analysis_test"] == 0 and v["steps"]["cuda_test_ran"] == 0
    assert "cop_v51_edits_reports/v51_reports/cuda_agreement.json" in zipfile.ZipFile(h["zip"]).namelist()
    (h["home"] / "events.txt").unlink()
    r = _sh(h, common=cuda, MOCK_CUDA_TEST_RC=1)                    # a failed CUDA test: no analysis
    assert r.returncode != 0 and "edits read" not in _events(h) and _verdict(h)["steps"]["edits25"] == 99


def test_a_skipped_cuda_test_is_not_a_validation(h):
    """pytest exits 0 when the CUDA test is skipped: the junit report shows it did not run, and the analysis does
    not start."""
    r = _sh(h, common=L.COMMON.replace("DEVICE=cpu", "DEVICE=cuda"), MOCK_CUDA_SKIPPED=1)
    v = _verdict(h)
    assert r.returncode != 0 and v["steps"]["cuda_analysis_test"] == 0 and v["steps"]["cuda_test_ran"] == 1
    assert v["steps"]["edits25"] == 99 and "edits read" not in _events(h)


def test_a_failed_manifest_generation_cannot_fall_through_to_a_stale_manifest(h):
    stale = h["home"] / "manifests/wave25_full.jsonl"
    stale.parent.mkdir(parents=True)
    stale.write_text('{"run_id": "stale"}\n')
    r = _sh(h, MOCK_MANIFEST_RC=1)
    assert r.returncode != 0 and not stale.exists()
    v = _verdict(h)
    assert v["steps"]["manifest25"] == 1 and v["steps"]["panel_source"] == 99 and v["steps"]["edits25"] == 99
    assert "edits read" not in _events(h) and "panel_state" not in _events(h) and h["zip"].exists()


@pytest.mark.parametrize("state", [3, 4, 6])
def test_no_complete_v46_panel_skips_the_tests_and_the_analysis(h, state):
    r = _sh(h, MOCK_PANEL_STATE=state)
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"]["panel_source"] == state and v["steps"]["cpu_tests"] == 99 and v["steps"]["edits25"] == 99
    assert "edits read" not in _events(h) and h["zip"].exists()


@pytest.mark.parametrize("table", ["minimal_sets_summary.csv", "minimal_sets_counts.csv", "rank_layers.csv",
                                   "transfer_contrasts_summary.csv", "fold_fit.csv", "fold_paths_summary.csv",
                                   "f0_gradients.csv", "train_groups_summary.csv"])
def test_an_empty_required_table_fails_the_evidence(h, table):
    r = _sh(h, MOCK_EDITS_EMPTY=table)
    assert r.returncode != 0
    ev = json.loads((h["res"] / "v51_reports/evidence25.json").read_text())
    assert ev["steps"]["edits25"]["missing"] == [f"edits25_{table} (an empty table)"]


def test_a_failed_analysis_or_test_suite_fails_the_launcher(h):
    assert _sh(h, MOCK_EDITS_RC=1).returncode != 0
    r = _sh(h, MOCK_TEST_RC=1)
    assert r.returncode != 0 and _verdict(h)["steps"]["edits25"] == 99


@pytest.mark.parametrize("script", ["49_v49_coordinated_edits.sh", "50_v50_coordinated_edits.sh"])
def test_earlier_edit_launchers_are_superseded(script):
    r = subprocess.run(["bash", str(ROOT / "scripts" / script)], capture_output=True, text=True)
    assert r.returncode == 1 and "coordinated_edits.sh" in r.stderr and ("51_v51" in r.stderr or "50_v50" in r.stderr)
