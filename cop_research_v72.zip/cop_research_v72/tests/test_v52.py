"""v52: the gain scan, the expansion's time course and the aligned paths (audit_v5/tools/coordinated_edits.py),
tested on REAL outputs of a miniature wave 25 analysed with the v52 launcher's exact options (read from scripts/52)
and cross-checked against the v51 parts run on the same panel.

Real outputs: the evidence contract; the gain scan against f0 scaled here by hand, its finite differences and the
autograd derivative recomputed, the descriptive optimum; the time course at every trajectory checkpoint (age 0 is
f0's function with silent additions; the end agrees with the v51 fold, training and first-layer tables), the
rank-truncated folds and the one-number channel readout recomputed from the saved fit; the aligned paths (the
unaligned path is the v51 fold path, every start preserved, every end the extraction); saved decisions; output
membership.  Failure paths: a trajectory checkpoint of the wrong age, a missing one.  Units: the alignment recovers
a hidden permutation and scaling and preserves a ReLU chain's function; rank truncation; the checkpoint list.  The
CUDA test compares saved decisions with the CPU analysis."""
from __future__ import annotations

import csv
import json
import math
import re
import shlex
import shutil
import subprocess
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "audit_v5/tools"))

ROOT = Path(__file__).resolve().parents[1]
LAUNCHER = ROOT / "scripts/52_v52_channel_course.sh"
TOOL = ROOT / "audit_v5/tools/coordinated_edits.py"
VARIANTS = ("A_free", "B_scfrozen", "C_dsfrozen", "D_bothfrozen")


def _rows(path):
    t = Path(path).read_text()
    return [] if t.strip() == "empty" else list(csv.DictReader(open(path)))


def _f(x):
    return None if x in (None, "") else float(x)


def _launcher_contract():
    src = LAUNCHER.read_text()
    files = re.search(r'^EDIT_FILES="([^"]+)"', src, re.M).group(1).split(",")
    variants = re.search(r'^VARIANTS="([^"]+)"', src, re.M).group(1)
    cmd = re.search(r'^  step channel25 (.*?"\$PREDS")', src, re.M | re.S).group(1).replace("\\\n", " ")
    toks = shlex.split(cmd)
    return files, variants, toks[toks.index("--strict") + 1:]


def _tool(root, man, prefix, *args, device="cpu"):
    return subprocess.run([sys.executable, str(TOOL), str(root), str(root / prefix), "--manifest", str(man),
                           "--strict", "--device", device, *args], capture_output=True, text=True)


def _launcher_args(root, preds):
    _, variants, rest = _launcher_contract()
    sub = {"$PREDS": str(preds), "$VARIANTS": variants}
    args = [sub.get(t, t) for t in rest]
    i = args.index("--device")
    return args[:i] + args[i + 2:]


@pytest.fixture(scope="module")
def panel(tmp_path_factory):
    import test_v45 as T
    root = tmp_path_factory.mktemp("w25c")
    _, Tr, R, _, man = T._panel(root)
    files, _, _ = _launcher_contract()
    r = _tool(root, man, "channel25", *_launcher_args(root, root / "preds25"))
    # the v51 parts on the same panel, to cross-check the new tables
    r51 = _tool(root, man, "v51", "--fold", "--train-diagnostics", "--save-preds", str(root / "v51_preds"))
    return {"root": root, "r": r, "r51": r51, "files": files, "man": man, "T": Tr, "R": R,
            "t": lambda n: _rows(root / f"channel25_{n}.csv"), "t51": lambda n: _rows(root / f"v51_{n}.csv")}


def test_real_outputs_pass_the_launchers_evidence_contract(panel, tmp_path):
    assert panel["r"].returncode == 0, panel["r"].stdout[-3000:] + panel["r"].stderr[-3000:]
    assert panel["r51"].returncode == 0, panel["r51"].stderr[-3000:]
    import coordinated_edits as CE
    cov = json.loads((panel["root"] / "channel25_coverage.json").read_text())
    assert cov["passed"] and cov["analysis_schema"] == CE.ANALYSIS_SCHEMA == "coordinated_edits/v52"
    assert cov["output_membership_failures"] == [] and cov["analysed_runs"] == 4
    assert cov["options"]["gain_scan"] and cov["options"]["age_course"] and cov["options"]["aligned_paths"]
    assert isinstance(cov["gain_derivative_disagreements"], list)
    out = tmp_path / "ev.json"
    spec = f"channel25:0:{panel['root'] / 'channel25'}:{','.join(panel['files'])}"
    r = subprocess.run([sys.executable, str(ROOT / "scripts/check_evidence.py"), str(out), spec],
                       capture_output=True, text=True)
    assert r.returncode == 0 and json.loads(out.read_text())["steps"]["channel25"]["ok"]
    d = tmp_path / "e"
    d.mkdir()
    for f in panel["files"]:
        shutil.copy2(panel["root"] / f"channel25_{f}", d / f"channel25_{f}")
    (d / "channel25_age_course.csv").write_text("empty\n")
    r = subprocess.run([sys.executable, str(ROOT / "scripts/check_evidence.py"), str(out),
                        f"channel25:0:{d / 'channel25'}:{','.join(panel['files'])}"], capture_output=True, text=True)
    assert r.returncode == 1
    chk = panel["t"]("checks")
    assert all((r["expected_age_rows"], r["expected_aligned_points"]) == ("3", "20") for r in chk)


def _f0(panel):
    from cop.config import run_id
    from cop.data.registry import load_bundle
    from cop.graph.graph import GraphNet
    cfg = panel["T"]["A"]
    b = load_bundle(cfg["data"], None, device="cpu")
    ck = torch.load(panel["root"] / "runs" / run_id(cfg) / "ckpt/baseline_ref.pt", weights_only=False)
    return b, ck, GraphNet.from_checkpoint(ck["model"], "cpu").eval()


def test_gain_scan_against_f0_scaled_by_hand(panel):
    import coordinated_edits as CE
    scan = panel["t"]("f0_gain_scan")
    assert len(scan) == len(CE.GAIN_BLOCKS) * (len(CE.GAINS) + 2) and {r["variant"] for r in scan} == {"f0"}
    b, ck, f0 = _f0(panel)
    tr = b.partitions()["train"]
    x, y = tr.X["x"], tr.y.long()
    lay = b.meta["feature_layout"]
    cols = {"causal": slice(lay["causal"][0], lay["causal"][1]), "shortcut": slice(lay["shortcut"],
                                                                                 lay["shortcut"] + 1)}
    wname, w1 = next((n, p) for n, p in f0.named_parameters() if p.dim() == 2 and p.shape[1] == x.shape[1])
    by = {(r["block"], r["purpose"], round(_f(r["gain"]), 9)): r for r in scan}
    base = w1.detach().clone()
    for bl in CE.GAIN_BLOCKS:
        for gain in (1.0, 1.5, 4.0):
            with torch.no_grad():
                w1.copy_(base)
                w1[:, cols[bl]] = (base[:, cols[bl]].double() * gain).to(base.dtype)
                nll = torch.nn.functional.cross_entropy(f0.forward({"x": x}).double(), y, reduction="none")
            r = by[(bl, "scan", gain)]
            assert _f(r["train_loss"]) == pytest.approx(float(nll.mean()), rel=1e-9)
            assert _f(r["log_gain"]) == pytest.approx(math.log(gain))
            assert _f(r["loss_contrib_all"]) == pytest.approx(float(nll.mean()), rel=1e-9)
            assert _f(r["loss_contrib_majority"]) + _f(r["loss_contrib_rare"]) == pytest.approx(float(nll.mean()))
    with torch.no_grad():
        w1.copy_(base)
    # gain 1 is f0: the same row whatever the block
    assert _f(by[("causal", "scan", 1.0)]["train_loss"]) == _f(by[("shortcut", "scan", 1.0)]["train_loss"])
    assert _f(by[("causal", "scan", 1.0)]["test_err"]) == _f(by[("shortcut", "scan", 1.0)]["test_err"])
    # the finite difference is the table's own two rows; the autograd value is recomputed here
    fd = {(r["block"], r["subgroup"]): r for r in panel["t"]("f0_gain_fd")}
    assert len(fd) == len(CE.GAIN_BLOCKS) * len(CE.SUBGROUPS)
    losses = torch.nn.functional.cross_entropy(f0.forward({"x": x}).double(), y, reduction="none")
    (gw,) = torch.autograd.grad(losses.mean(), [w1])
    for bl in CE.GAIN_BLOCKS:
        lo = by[(bl, "finite difference", round(math.exp(-CE.FD_EPS), 9))]
        hi = by[(bl, "finite difference", round(math.exp(CE.FD_EPS), 9))]
        for sg in CE.SUBGROUPS:
            want = (_f(hi[f"loss_contrib_{sg}"]) - _f(lo[f"loss_contrib_{sg}"])) / (2 * CE.FD_EPS)
            r = fd[(bl, sg)]
            assert _f(r["finite_difference_dloss_dloggain"]) == pytest.approx(want, rel=1e-9, abs=1e-15)
            a_, f_ = _f(r["autograd_dloss_dloggain"]), _f(r["finite_difference_dloss_dloggain"])
            assert (r["agrees"] == "True") == (abs(f_ - a_) <= max(CE.FD_TOL[0] * abs(a_), CE.FD_TOL[1]))
        ag = float((gw.double()[:, cols[bl]] * w1.detach().double()[:, cols[bl]]).sum())
        assert _f(fd[(bl, "all")]["autograd_dloss_dloggain"]) == pytest.approx(ag, rel=1e-6, abs=1e-12)
        assert fd[(bl, "all")]["agrees"] == "True"             # the derivative and its finite difference agree
    for o in panel["t"]("f0_gain_optimum"):
        rows = [r for r in scan if r["block"] == o["block"] and r["purpose"] == "scan"]
        best = min(rows, key=lambda r: (_f(r["train_loss"]), abs(_f(r["log_gain"]))))
        assert _f(o["gain_at_min_train_loss"]) == _f(best["gain"]) and _f(o["min_train_loss"]) == \
            _f(best["train_loss"])
        assert _f(o["test_err_at_min_train_loss"]) == _f(best["test_err"]) and "descriptive" in o["note"]
        assert _f(o["at_gain_1_train_loss"]) == _f(by[(o["block"], "scan", 1.0)]["train_loss"])


def _age(panel):
    by = defaultdict(dict)
    for r in panel["t"]("age_course"):
        by[r["variant"]][r["checkpoint"]] = r
    return by


def test_age_course_ends_agree_with_the_v51_tables(panel):
    import coordinated_edits as CE
    age = _age(panel)
    assert set(age) == set(VARIANTS) and all(list(a) == ["post_insert_r1", "post_insert_r2", "final"]
                                              for a in age.values())
    fold = {(r["variant"], r["fold"], r["segment"][0], float(r["lam"]), float(r["rewind_t"])): r
            for r in panel["t51"]("fold")}
    fit = {(r["variant"], r["fold"]): r for r in panel["t51"]("fold_fit")}
    tg = {(r["variant"], r["subgroup"]): r for r in panel["t51"]("train_groups")}
    flc = {r["variant"]: r for r in panel["t51"]("first_layer_change")}
    for v, a in age.items():
        r0, r2, fin = a["post_insert_r1"], a["post_insert_r2"], a["final"]
        assert (r0["updates_since_f0"], r2["updates_since_f0"], fin["updates_since_f0"]) == ("0", "6", "12")
        assert (r0["leaves"], r2["leaves"]) == ("I2 I3", "I2 I3 I4 I5") and r0["n_leaves"] == "2"
        # at the first insertion the additions are silent: the expanded network, the deletion and the extraction
        # are all f0's function, and there is nothing to fit
        assert _f(r0["u_rms_over_h_rms"]) == 0.0 and "exactly zero" in r0["note"] and r0["fold_test_err"] == ""
        assert _f(r0["native_test_err"]) == _f(r0["deletion_test_err"]) == _f(r0["extraction_test_err"])
        assert _f(r0["train_loss"]) == pytest.approx(_f(tg[("f0", "all")]["mean_loss"]), rel=1e-9)
        assert _f(r0["extraction_gain_vs_f0"]) == 0.0 and _f(r0["causal_norm_ratio"]) == 1.0
        assert _f(r0["change_over_f0_L2"]) == 0.0
        # the end agrees with v51's fold, training and first-layer tables
        nat = fold[(v, "affine", "1", 1.0, 0.0)]
        assert _f(fin["native_test_err"]) == _f(nat["test_err"]) and _f(fin["native_val_err"]) == _f(nat["val_err"])
        assert _f(fin["deletion_test_err"]) == _f(fold[(v, "zero", "2", 0.0, 0.0)]["test_err"])
        assert _f(fin["extraction_test_err"]) == _f(fold[(v, "affine", "2", 0.0, 1.0)]["test_err"])
        f0_ = fold[(v, "affine", "2", 0.0, 0.0)]
        assert _f(fin["fold_test_err"]) == _f(f0_["test_err"]) and _f(fin["fold_val_err"]) == _f(f0_["val_err"])
        assert _f(fin["fold_dis_native_test"]) == _f(f0_["dis_native"])
        assert _f(fin["fold_impl_max_rel_diff"]) <= CE.FOLD_TOL
        ff = fit[(v, "affine")]
        for a_, b_ in (("u_rms_over_h_rms", "u_rms_over_h_rms"), ("u_constant_energy_share",
                                                                 "u_constant_energy_share"),
                       ("M_spectral", "M_spectral"), ("M_fro", "M_fro"), ("affine_r2_train", "affine_r2_train"),
                       ("affine_r2_test", "affine_r2_test"), ("nonlinear_energy_share_test", "resid_share_raw_test")):
            assert _f(fin[a_]) == pytest.approx(_f(ff[b_]), rel=1e-9, abs=1e-15), (v, a_)
        assert _f(fin["train_loss"]) == pytest.approx(_f(tg[(v, "all")]["mean_loss"]), rel=1e-9)
        assert _f(fin["train_err"]) == pytest.approx(_f(tg[(v, "all")]["err"]))
        assert _f(fin["train_margin_q50"]) == pytest.approx(_f(tg[(v, "all")]["margin_q50"]), rel=1e-9)
        assert _f(fin["causal_norm_ratio"]) == pytest.approx(_f(flc[v]["causal_norm_ratio"]), rel=1e-9)
        assert _f(fin["shortcut_norm_ratio"]) == pytest.approx(_f(flc[v]["shortcut_norm_ratio"]), rel=1e-9)
        assert 0.0 < _f(fin["M_top1_energy"]) <= _f(fin["M_top2_energy"]) <= 1.0 + 1e-12
        assert _f(fin["M_top1_energy"]) == pytest.approx((_f(fin["M_spectral"]) / _f(fin["M_fro"])) ** 2)
        assert _f(fin["extraction_minus_native"]) == pytest.approx(_f(fin["extraction_test_err"])
                                                                    - _f(fin["native_test_err"]))
        frozen = v in ("C_dsfrozen", "D_bothfrozen")
        assert (_f(fin["change_over_f0_L2"]) == 0.0) == frozen


def test_rank_folds_and_channel_from_the_saved_fit(panel):
    """the rank-truncated folds and the one-number readout rebuilt from v51's saved fit (M, c) and the data."""
    import coordinated_edits as CE
    from cop.graph.graph import GraphNet
    from cop.data.registry import load_bundle
    age = _age(panel)
    b = load_bundle(panel["T"]["A"]["data"], None, device="cpu")
    parts = b.partitions()
    for r51 in panel["t51"]("checks"):
        v = r51["variant"]
        fin = age[v]["final"]
        z = np.load(panel["root"] / "preds25" / f"{r51['run_id']}__age_course.npz", allow_pickle=False)
        order = json.loads(str(z["meta"]))["order"]
        assert order[:3] == ["post_insert_r1|native", "post_insert_r1|deletion", "post_insert_r1|extraction"]
        for tag, col in (("native", "native_test_err"), ("deletion", "deletion_test_err"),
                         ("extraction", "extraction_test_err"), ("fold_affine", "fold_test_err"),
                         ("fold_rank1", "fold_rank1_test_err"), ("fold_rank4", "fold_rank4_test_err")):
            i = order.index(f"final|{tag}")
            assert float((z["preds_test"][i] != z["labels_test"]).mean()) == pytest.approx(_f(fin[col]), abs=1e-12)
        nat = z["preds_test"][order.index("final|native")]
        r1 = z["preds_test"][order.index("final|fold_rank1")]
        assert float((r1 != nat).mean()) == pytest.approx(_f(fin["fold_rank1_dis_native_test"]), abs=1e-12)
        # the readout: v1 . h thresholded between the training class means
        fz = np.load(panel["root"] / "v51_preds" / f"{r51['run_id']}__fold_fit.npz", allow_pickle=False)
        ck = torch.load(panel["root"] / "runs" / r51["trajectory"] / "ckpt/final.pt", weights_only=False)
        g = GraphNet.from_checkpoint(ck["model"], "cpu").eval()
        hin, mid, _ = CE.fold_site(g, r51["leaves"].split(), __import__("selective_reversal").backbone_layers(g))

        def acts(p):
            with torch.no_grad():
                _, nv = g.forward({"x": parts[p].X["x"]}, return_nodes=[hin, mid])
            return nv[hin].double(), (nv[mid] - nv[hin]).double()
        Ht, Ut = acts("train")
        M, c, _ = CE.affine_fit(Ht, Ut)
        assert torch.allclose(M, torch.from_numpy(fz["M"]), atol=1e-12)       # the fit v51 saved
        v1 = torch.linalg.svd(M)[2][0]
        s_tr, y = Ht @ v1, parts["train"].y.long()
        cl = CE.corr(s_tr, y.double())
        assert _f(fin["channel_label_corr_train"]) == pytest.approx(abs(cl), rel=1e-6)
        sign = -1.0 if cl < 0 else 1.0
        thr = 0.5 * float(s_tr[y == 0].mean() + s_tr[y == 1].mean())
        Hs, _ = acts("test")
        err = float((((sign * (Hs @ v1 - thr)) > 0).long() != parts["test"].y.long()).double().mean())
        assert _f(fin["channel_threshold_err_test"]) == pytest.approx(err, abs=1e-12)
        # a rank-r map keeps the training mean of the output and is the map itself at full rank
        Mr, cr = CE.rank_r_map(M, 1, Ht.mean(0), Ut.mean(0))
        assert torch.linalg.matrix_rank(Mr, atol=1e-10) == 1
        assert torch.allclose(Mr @ Ht.mean(0) + cr, Ut.mean(0), atol=1e-10)
        Mf, cf = CE.rank_r_map(M, 99, Ht.mean(0), Ut.mean(0))
        assert torch.allclose(Mf, M, atol=1e-10)


def test_aligned_paths(panel):
    import coordinated_edits as CE
    pts = defaultdict(dict)
    for r in panel["t"]("aligned_points"):
        pts[(r["variant"], r["mode"])][float(r["rewind_t"])] = r
    assert len(pts) == 4 * len(CE.ALIGN_MODES) and all(len(p) == len(CE.FOLD_PATH) for p in pts.values())
    fold = {(r["variant"], float(r["rewind_t"])): r for r in panel["t51"]("fold")
            if r["fold"] == "affine" and r["segment"].startswith("2")}
    paths = {(r["variant"], r["mode"]): r for r in panel["t"]("aligned_paths")}
    for (v, mode), p in pts.items():
        for t, r in p.items():
            if mode == "none":                                   # the unaligned path is v51's fold path
                for m in ("test_err", "val_err", "test_ce", "dis_native"):
                    assert _f(r[m]) == pytest.approx(_f(fold[(v, t)][m]), rel=1e-12, abs=1e-15), (v, t, m)
        assert _f(p[1.0]["dis_extraction"]) == 0.0 and _f(p[1.0]["minus_extraction"]) == 0.0
        # every aligned start is the folded network's function (numerically), whatever the alignment
        assert _f(p[0.0]["test_err"]) == pytest.approx(_f(pts[(v, "none")][0.0]["test_err"]), abs=2 / 64)
        s = paths[(v, mode)]
        assert _f(s["start_preserved_max_rel_diff"]) <= CE.FOLD_TOL
        te = [_f(p[t]["test_err"]) for t in CE.FOLD_PATH]
        assert _f(s["max_test_err"]) == max(te)
        assert _f(s["barrier_test_err"]) == pytest.approx(max(te) - max(te[0], te[-1]), abs=1e-12)
        if mode == "none":
            assert s["units_moved_L2"] == "" and _f(s["start_preserved_max_rel_diff"]) == 0.0
        else:
            for n in ("L2", "L3", "L4"):
                assert s[f"units_moved_{n}"] != "" and -1.0 <= _f(s[f"matched_corr_mean_{n}"]) <= 1.0 + 1e-9
                if "rescale" not in mode:
                    assert _f(s[f"alpha_min_{n}"]) == _f(s[f"alpha_max_{n}"]) == 1.0
                if "permute" not in mode:
                    assert s[f"units_moved_{n}"] == "0"
                else:
                    assert _f(s[f"matched_corr_mean_{n}"]) >= _f(s[f"identity_corr_mean_{n}"]) - 1e-9
        assert "sampled points only" in s["note"]


def test_saved_decisions_of_the_new_parts(panel):
    d = panel["root"] / "preds25"
    names = sorted(p.name.split("__")[-1] for p in d.glob("*.npz"))
    assert names == ["age_course.npz"] * 4 + ["aligned_paths.npz"] * 4 + ["gain_scan.npz"]
    pts = defaultdict(dict)
    for r in panel["t"]("aligned_points"):
        pts[r["run_id"]][f"{r['mode']}|{float(r['rewind_t']):g}"] = r
    for rid, p in pts.items():
        z = np.load(d / f"{rid}__aligned_paths.npz", allow_pickle=False)
        meta = json.loads(str(z["meta"]))
        for i, k in enumerate(meta["order"]):
            for part in meta["partitions"]:
                e = float((z[f"preds_{part}"][i] != z[f"labels_{part}"]).mean())
                assert e == pytest.approx(_f(p[k][f"{part}_err"]), abs=1e-12)
    scan = {f"{r['block']}|{_f(r['gain']):g}": r for r in panel["t"]("f0_gain_scan") if r["purpose"] == "scan"}
    z = np.load(next(d.glob("*__gain_scan.npz")), allow_pickle=False)
    for i, k in enumerate(json.loads(str(z["meta"]))["order"]):
        assert float((z["preds_test"][i] != z["labels_test"]).mean()) == pytest.approx(_f(scan[k]["test_err"]),
                                                                                       abs=1e-12)


# ----------------------------------------------------------------------------- failure paths

def _copy(panel, tmp_path):
    root = tmp_path / "bad"
    shutil.copytree(panel["root"] / "runs", root / "runs")
    return root


def test_an_intermediate_checkpoint_of_the_wrong_age_fails_the_group(panel, tmp_path):
    from cop.config import run_id
    root = _copy(panel, tmp_path)
    p = root / "runs" / run_id(panel["T"]["B"]) / "ckpt/post_insert_r2.pt"
    ck = torch.load(p, weights_only=False)
    ck["trainer"]["state"]["global_step"] = int(ck["trainer"]["state"]["global_step"]) + 1
    torch.save(ck, p)
    r = _tool(root, panel["man"], "bad", "--age-course")
    cov = json.loads((root / "bad_coverage.json").read_text())
    assert r.returncode == 1 and "its configured age is 6" in cov["failed"][0]["reason"]
    p.unlink()
    r = _tool(root, panel["man"], "bad2", "--age-course")
    cov = json.loads((root / "bad2_coverage.json").read_text())
    assert r.returncode == 1 and "checkpoint is missing" in cov["failed"][0]["reason"]


# ----------------------------------------------------------------------------- units

def test_alignment_recovers_a_permutation_and_scaling_and_preserves_the_function():
    import coordinated_edits as CE
    g = torch.Generator().manual_seed(4)
    wk, bk = ["w1", "w2", "w3", "w4"], ["b1", "b2", "b3", "b4"]
    X = {"w1": torch.randn(7, 5, generator=g), "b1": torch.randn(7, generator=g),
         "w2": torch.randn(6, 7, generator=g), "b2": torch.randn(6, generator=g),
         "w3": torch.randn(6, 6, generator=g), "b3": torch.randn(6, generator=g),
         "w4": torch.randn(2, 6, generator=g), "b4": torch.randn(2, generator=g)}
    x = torch.randn(400, 5, generator=g)
    # F: the same function with layer 2's units permuted and positively rescaled
    perm = torch.tensor([3, 0, 5, 1, 4, 2])
    scale = torch.tensor([0.5, 2.0, 3.0, 0.25, 1.5, 4.0])
    F = dict(X)
    F["w2"], F["b2"] = (X["w2"] * scale[:, None])[perm], (X["b2"] * scale)[perm]
    F["w3"] = (X["w3"] / scale[None, :])[:, perm]
    aF, zF = CE.mlp_forward(F, x, wk, bk)
    aX, zX = CE.mlp_forward(X, x, wk, bk)
    assert torch.allclose(zF, zX, atol=1e-5) and not torch.allclose(aF[1], aX[1], atol=1e-2)
    order, alpha, info = CE.unit_alignment(aF[1], aX[1], True, True)
    assert info["units_moved"] == 5 and info["matched_corr_mean"] == pytest.approx(1.0, abs=1e-6)
    assert info["identity_corr_mean"] < 0.9
    W2, b2, W3 = CE.apply_alignment(F["w2"], F["b2"], F["w3"], order, alpha)
    assert torch.allclose(W2, X["w2"], atol=1e-5) and torch.allclose(b2, X["b2"], atol=1e-5) and \
        torch.allclose(W3, X["w3"], atol=1e-5)                    # the hidden symmetry is undone
    # every mode preserves the function
    for pm, rs in ((False, True), (True, False), (True, True), (False, False)):
        od, al, inf = CE.unit_alignment(aF[1], aX[1], pm, rs)
        T = dict(F)
        T["w2"], T["b2"], T["w3"] = CE.apply_alignment(F["w2"], F["b2"], F["w3"], od, al)
        assert torch.allclose(CE.mlp_forward(T, x, wk, bk)[1], zF, atol=1e-5)
        if not pm:
            assert inf["units_moved"] == 0
        if not rs:
            assert inf["alpha_min"] == inf["alpha_max"] == 1.0
    # a dead unit is left at scale 1
    dead = aF[1].clone()
    dead[:, 0] = 0.0
    assert CE.unit_alignment(dead, aX[1], False, True)[1][0] == 1.0


def test_checkpoint_list_and_small_units():
    import coordinated_edits as CE
    cfg = {"growth": {"updates_per_round": 2000, "rounds": 2},
           "train": {"snapshot_at": [250, 500, 1000, 1500, 2250, 2500, 3000, 3500, 4000, 0]}}
    assert CE.trajectory_checkpoints(None, cfg) == [
        ("post_insert_r1", 0), ("snap_250", 250), ("snap_500", 500), ("snap_1000", 1000), ("snap_1500", 1500),
        ("post_insert_r2", 2000), ("snap_2250", 2250), ("snap_2500", 2500), ("snap_3000", 3000),
        ("snap_3500", 3500), ("final", 4000)]
    assert CE.trajectory_checkpoints(None, {"growth": {"updates_per_round": 6, "rounds": 2}}) == [
        ("post_insert_r1", 0), ("post_insert_r2", 6), ("final", 12)]
    assert CE.corr(torch.tensor([1.0, 2.0, 3.0]), torch.tensor([2.0, 4.0, 6.0])) == pytest.approx(1.0)
    assert CE.corr(torch.ones(3), torch.tensor([1.0, 2.0, 3.0])) is None
    with pytest.raises(CE.Fail, match="its configured age is 6"):
        CE.check_age(7, 6, "x")


# ----------------------------------------------------------------------------- the CUDA backend

@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA device required")
def test_cuda_analysis_of_the_new_parts_agrees_with_cpu_decision_by_decision(panel):
    import os
    import compare_edit_runs as CMP
    dev = os.environ.get("COP_TEST_CUDA_DEVICE", "cuda")
    root = panel["root"]
    r = _tool(root, panel["man"], "cuda25", *_launcher_args(root, root / "preds_cuda"), device=dev)
    assert r.returncode == 0, r.stdout[-2000:] + r.stderr[-3000:]
    cov = json.loads((root / "cuda25_coverage.json").read_text())
    assert cov["passed"] and cov["numerics"]["device"] == dev
    rep = CMP.compare(root / "channel25", root / "preds25", root / "cuda25", root / "preds_cuda")
    rep["devices"] = {"a": "cpu", "b": dev, "gpu": cov["numerics"]["gpu"]}
    out = os.environ.get("COP_CUDA_REPORT")
    if out:
        Path(out).write_text(json.dumps(rep, indent=1))
    assert rep["passed"], rep["failures"][:5]
    assert set(rep["decisions"]) == {"gain_scan", "age_course", "aligned_paths"}
    for t, parts in rep["decisions"].items():
        assert set(parts) == {"test", "val", "val_indep"}, t
        for d in parts.values():
            assert d["candidates"] > 0 and d["max_disagreements"] <= d["tolerance"]
