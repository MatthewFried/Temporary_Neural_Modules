"""v53: the wave-26 panel (routed / all-example gradients x relu / affine additions x holds, the lower learning rate,
the long compact controls), the gain-only training tool, the wave-26 registry and the paired table contrasts."""
from __future__ import annotations

import csv
import json
import os
import subprocess
import sys
from pathlib import Path

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "audit_v5" / "tools"))
from cop.config import resolve, run_id  # noqa: E402
from cop.utils import read_json  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
SR_TOOL = str(ROOT / "audit_v5/tools/selective_reversal.py")
CE_TOOL = str(ROOT / "audit_v5/tools/coordinated_edits.py")
GAIN_TOOL = str(ROOT / "audit_v5/tools/gain_training.py")
PC_TOOL = str(ROOT / "audit_v5/tools/panel26_tables.py")
AUD = {"log_update_norms": True, "audit_batches": True}
HOLDS = {"A": {}, "B": {"freeze_inputs": "shortcut"}}
LIFT = {"freeze_inputs": "none", "freeze_backbone": "none"}
SNAPS = [3, 9]                                # the miniature's clock: U = 6, 2U = 12, the long control 24
EA = [3, 6, 9, 12, 15, 18, 21, 24]


def _run(cfgs, d):
    from test_v15 import _run as r
    return r(cfgs, d)


def _rows(path):
    t = Path(path).read_text()
    return [] if t.strip() == "empty" else list(csv.DictReader(open(path)))


def _tool(tool, *args, env=None):
    return subprocess.run([sys.executable, tool, *map(str, args)], capture_output=True, text=True,
                          env={**os.environ, **(env or {})})


def _traj26(name):
    """the miniature of one wave-26 expansion arm (the builder's own growth settings and learning-rate factor)."""
    from test_v31 import _traj
    from cop.orchestration.wave13 import v53_variants
    h, growth, f = v53_variants()[name]
    p = _traj()
    t = p[-1]
    tr = {**t["train"], **AUD, **HOLDS[h], "snapshot_at": SNAPS}
    if f != 1.0:
        tr["lr"] = t["train"]["lr"] * f
    return p, resolve({**t, "growth": {**t["growth"], **growth}, "train": tr})


def _compact26(p0, treated, name):
    from cop.orchestration.wave13 import v53_compacts
    h, f = v53_compacts()[name]
    tr = {**p0["train"], **AUD, **HOLDS[h]}
    if f != 1.0:
        tr["lr"] = p0["train"]["lr"] * f
    cc = {"start": "baseline", "start_stage": "baseline", "budget": "fixed", "segments": [12, 12],
          "segment_reset": [False, False], "eval_at": EA, "save_eval_checkpoints": True, "fork_audit": True}
    return resolve({"kind": "continue", "data": p0["data"], "model": p0["model"], "train": tr, "seeds": p0["seeds"],
                    "parents": {"baseline": run_id(p0), "treated": run_id(treated)}, "continue": cc,
                    "design": {"family": "X25", "variant": name, "arm": "C1", "contrast": "X25|c"}})


def _panel26(root, run=True, arms=None, compacts=None):
    """a miniature wave 26: one f0, the expansions `arms` (default all ten) with their removals (holds lifted) and
    the compact controls `compacts` (default all four)."""
    from test_v31 import _lin, _manifest, _x25
    from cop.orchestration.wave13 import v53_compacts, v53_variants
    arms = list(arms or v53_variants())
    compacts = list(v53_compacts() if compacts is None else compacts)
    p, _ = _traj26(arms[0])
    T = {k: _traj26(k)[1] for k in arms}
    R = {k: _x25(resolve({**_lin(T[k]), "train": {**T[k]["train"], **LIFT}}), variant=k) for k in arms}
    Cc = {k: _compact26(p[0], R[arms[0]], k) for k in compacts}
    if run:
        _run([p[0], *T.values()], root)
        for c in [*R.values(), *Cc.values()]:
            _run([c], root)
    return p[0], T, R, Cc, _manifest(root, [p[0], *T.values(), *R.values(), *Cc.values()])


# ----------------------------------------------------------------------------- the launcher's commands

LAUNCHER = ROOT / "scripts/53_v53_drift_panel.sh"
STEPS = {"reversal26": ("LT26_FILES", SR_TOOL), "edits26": ("EDIT_FILES", CE_TOOL),
         "gains26": ("GAIN_FILES", GAIN_TOOL), "tables26": ("TABLE_FILES", PC_TOOL)}


def _launcher_contract(step):
    """the launcher's own required files and command line of one analysis step (from --manifest's value on)."""
    import re
    import shlex
    src = LAUNCHER.read_text()
    files = re.search(rf'^{STEPS[step][0]}="([^"]+)"', src, re.M).group(1).split(",")
    cmd = re.search(rf'^\s+step {step} (python .*?)\n(?!\s+--)', src, re.M | re.S).group(1).replace("\\\n", " ")
    toks = shlex.split(cmd)
    var = {f"${k}": re.search(rf'^{k}="([^"]+)"', src, re.M).group(1) for k in ("PAIRED_VARY", "TRACE_CODES")}
    return files, [var.get(t, t) for t in toks[toks.index("--manifest") + 2:]]


def _args(step, root, preds=None, gains=None, device="cpu"):
    sub = {"$DEVICE": device, "$PREDS": str(preds or root / "preds26"), "$m26": str(root / "m.jsonl"),
           "$GAINS": str(gains or root / "gain_states26"),
           "$O/reversal26": str(root / "reversal26"), "$O/edits26": str(root / "edits26"),
           "$O/gains26": str(root / "gains26")}
    return [sub.get(t, t) for t in _launcher_contract(step)[1]]


def _analyse(root, man, step, prefix=None, **kw):
    prefix = prefix or step
    if step == "tables26":
        return _tool(PC_TOOL, root / prefix, "--manifest", man, *_args(step, root, **kw))
    return _tool(STEPS[step][1], root, root / prefix, "--manifest", man, *_args(step, root, **kw))


@pytest.fixture(scope="module")
def panel(tmp_path_factory):
    root = tmp_path_factory.mktemp("w26")
    p0, T, R, Cc, man = _panel26(root)
    res = {s: _analyse(root, man, s) for s in ("reversal26", "edits26", "gains26")}
    res["tables26"] = _analyse(root, man, "tables26")
    return {"root": root, "p0": p0, "T": T, "R": R, "Cc": Cc, "man": man, "res": res,
            "t": lambda step, n: _rows(root / f"{step}_{n}.csv"),
            "cov": lambda step: read_json(root / f"{step}_coverage.json")}


def _f(x):
    return None if x in (None, "") else float(x)


def test_real_outputs_pass_the_launchers_evidence_contract(panel, tmp_path):
    for s, r in panel["res"].items():
        assert r.returncode == 0, (s, r.stdout[-2500:] + r.stderr[-2500:])
    specs = [f"{s}:0:{panel['root'] / s}:{','.join(_launcher_contract(s)[0])}" for s in STEPS]
    r = _tool(str(ROOT / "scripts/check_evidence.py"), tmp_path / "ev.json", *specs)
    assert r.returncode == 0, r.stdout[-3000:]
    ev = read_json(tmp_path / "ev.json")
    assert ev["passed"] and all(v["ok"] for v in ev["steps"].values())
    # a registry table missing or empty fails the same contract
    bad = tmp_path / "bad"
    bad.mkdir()
    import shutil
    for p in panel["root"].glob("reversal26_*"):
        shutil.copy2(p, bad / p.name)
    (bad / "reversal26_registry_summary.csv").write_text("empty\n")
    r = _tool(str(ROOT / "scripts/check_evidence.py"), tmp_path / "ev2.json",
              f"reversal26:0:{bad / 'reversal26'}:{','.join(_launcher_contract('reversal26')[0])}")
    assert r.returncode == 1


# ----------------------------------------------------------------------------- the design

def test_wave26_structure_and_unchanged_semantics():
    from collections import Counter
    from cop.config import CODE_VERSION
    from cop.orchestration.manifest import WAVES, generate
    from cop.orchestration.wave13 import v53_compacts, v53_variants
    from cop.utils import semantic_code_hash
    import selective_reversal as SR
    import test_v46
    assert test_v46.v45_panels_reusable() and CODE_VERSION == "cop-7.21.0"
    assert semantic_code_hash()
    m = generate([26], "full")
    ents = [e["cfg"] for e in m.entries.values()]
    assert len(ents) == 600
    assert Counter(c["kind"] for c in ents) == {"baseline": 24, "trajectory": 240, "dissipation": 240, "continue": 96}
    draws = {c["data"]["data_seed"] for c in ents}
    assert draws == set(range(337, 349))
    for w in WAVES:                                   # never used by any earlier wave, at any scale
        if w >= 26:
            continue
        for sc in ("full", "pilot", "smoke"):
            try:
                mm = generate([w], sc)
            except Exception:                         # noqa: BLE001  (a wave without that scale)
                continue
            assert not draws & {(e["cfg"].get("data") or {}).get("data_seed") for e in mm.entries.values()}, (w, sc)
    tr = [c for c in ents if c["kind"] == "trajectory"]
    lr = 0.001
    assert Counter((c["train"]["freeze_inputs"], c["growth"]["spec_partition"], c["growth"]["act"],
                    c["train"]["lr"]) for c in tr) == {
        (h, r, a_, lr): 24 for h in ("none", "shortcut") for r in ("random_matched", "all_examples")
        for a_ in ("relu", "identity")} | {(h, "random_matched", "relu", lr * 0.3): 24 for h in ("none", "shortcut")}
    assert all(c["train"]["freeze_backbone"] == "none" and c["growth"]["spec_mask_route"] == "gradient"
               and c["growth"]["rounds"] == 2 and c["growth"]["updates_per_round"] == 2000
               and c["train"]["snapshot_at"] == [250, 500, 1000, 1500, 2250, 2500, 3000, 3500] for c in tr)
    # apart from the three declared factors and the hold, the ten expansions of one f0 and seed are one config
    groups = {}
    for c in tr:
        x = json.loads(json.dumps(c))
        for sec, k in (("train", "freeze_inputs"), ("train", "lr"), ("growth", "act"), ("growth", "spec_partition")):
            x[sec].pop(k)
        groups.setdefault((c["data"]["data_seed"], c["seeds"]["optimizer"]), set()).add(json.dumps(x, sort_keys=True))
    assert len(groups) == 24 and all(len(v) == 1 for v in groups.values())
    # the routed relu arm with the shortcut column held is wave 25's B, on new draws
    b25 = next(e["cfg"] for e in generate([25], "full").entries.values() if e["cfg"]["kind"] == "trajectory"
               and e["cfg"]["train"]["freeze_inputs"] == "shortcut" and e["cfg"]["train"]["freeze_backbone"] == "none")
    b26 = next(c for c in tr if (c["train"]["freeze_inputs"], c["growth"]["spec_partition"], c["growth"]["act"],
                                 c["train"]["lr"]) == ("shortcut", "random_matched", "relu", lr))
    strip = lambda c: {k: ({kk: vv for kk, vv in v.items() if not kk.endswith("_seed")} if k == "data" else v)
                       for k, v in c.items() if k not in ("parents", "wave", "block")}
    assert strip(b25) == strip(b26)
    rem = [c for c in ents if c["kind"] == "dissipation"]
    assert all(c["train"]["freeze_inputs"] == "none" and c["train"]["freeze_backbone"] == "none" for c in rem)
    assert Counter(c["design"]["variant"] for c in rem) == {v: 24 for v in v53_variants()} and len(v53_variants()) == 10
    by_id = {e["run_id"]: e["cfg"] for e in m.entries.values()}
    for c in rem:                                     # a removal keeps its trajectory's rate and growth settings
        t = by_id[c["parents"]["trajectory"]]
        assert c["train"]["lr"] == t["train"]["lr"] and c["growth"] == t["growth"]
        h, growth, f = v53_variants()[c["design"]["variant"]]
        assert t["train"]["freeze_inputs"] == ("shortcut" if h == "B" else "none")
        assert t["train"]["lr"] == (lr * f if f != 1.0 else lr)
        assert all(t["growth"][k] == v for k, v in growth.items())
    comp = [c for c in ents if c["kind"] == "continue"]
    ea = [250, 500, 1000, 1500, 2000, 2250, 2500, 3000, 3500, 4000, 5000, 6000, 7000, 8000]
    assert Counter((c["design"]["variant"], c["design"]["arm"], c["train"]["freeze_inputs"], c["train"]["lr"],
                    tuple(c["continue"]["segments"]), tuple(c["continue"]["segment_reset"]),
                    tuple(c["continue"]["freeze_segments"]), tuple(c["continue"]["eval_at"])) for c in comp) == {
        ("compact_A", "C1", "none", lr, (4000, 4000), (False, False), (), tuple(ea)): 24,
        ("compact_B", "C1", "shortcut", lr, (4000, 4000), (False, False), (), tuple(ea)): 24,
        ("compact_A_lr0.3", "C1", "none", lr * 0.3, (4000, 4000), (False, False), (), tuple(ea)): 24,
        ("compact_B_lr0.3", "C1", "shortcut", lr * 0.3, (4000, 4000), (False, False), (), tuple(ea)): 24}
    assert set(v53_compacts()) == {c["design"]["variant"] for c in comp}
    assert all(c["continue"]["fork_audit"] and c["continue"]["save_eval_checkpoints"]
               and c["continue"]["budget"] == "fixed" for c in comp)
    assert all(c["train"]["audit_batches"] and c["train"]["log_update_norms"] for c in ents if c["kind"] != "baseline")
    base = [c for c in ents if c["kind"] == "baseline"]
    assert all(c["train"]["lr"] == lr and c["train"]["freeze_inputs"] == "none" for c in base)
    # every arm the registry names is in the manifest, and every expansion and compact control is in the registry
    va = {(c["design"]["variant"], c["design"]["arm"]) for c in ents if (c.get("design") or {}).get("arm")}
    named = set()
    for name, kind, A, B in SR.REGISTRIES["wave26"]:
        for s_ in ((A[0], A[1], B[0], B[1]) if kind == "interaction" else (A, B)):
            assert (s_[0], s_[1]) in va, (name, s_)
            named.add((s_[0], s_[1]))
    assert named == va
    assert len({c[0] for c in SR.REGISTRIES["wave26"]}) == len(SR.REGISTRIES["wave26"]) == 85
    # v54: the two primary contrasts are registry members, on the arm that repeats wave 25's B arm
    prim = SR.REGISTRY_PRIMARY["wave26"]
    assert prim == {"S_B_routed_relu_extraction_vs_f0", "S_B_routed_relu_extraction_vs_compact_B_extraction_at_2U"}
    assert prim <= {c[0] for c in SR.REGISTRIES["wave26"]}


# ----------------------------------------------------------------------------- selective_reversal on wave 26

X1, ZERO, ONES = "0-1-1-1-1", "0-0-0-0-0", "1-1-1-1-1"


def test_one_stream_and_one_insertion_for_every_arm_and_compact_control(panel):
    cov = panel["cov"]("reversal26")
    assert cov["passed"] and cov["analysed"] == 14 and cov["analysis_schema"].startswith("selective_reversal/v")
    assert cov["options"]["paired_vary"] == "growth.act,growth.spec_partition,train.lr"
    assert cov["paired_stream_failures"] == [] and cov["paired_stream_groups"] == 1
    assert cov["compact_fork_equality_failures"] == [] and cov["output_membership_failures"] == []
    ps = panel["t"]("reversal26", "paired_streams")
    assert len(ps) == 14 and len({x["batch_id_hash"] for x in ps}) == 1 and ps[0]["batch_id_hash"]
    tr = [x for x in ps if x["role"] == "trajectory"]
    assert len(tr) == 10 and len({x["insertion_init_hash"] for x in tr}) == 1
    assert len({x["config_apart_from_holds"] for x in tr}) == 1 and len({x["f0_state_hash"] for x in ps}) == 1
    assert all(x["updates"] == "12" and x["batches_drawn"] == "12" for x in ps)
    # the compact controls: one prefix group per (hold, learning rate); different rates never share a state
    fa = [x for x in panel["t"]("reversal26", "compact_fork_audit") if x["record"] == "segment_start"
          and x["update"] == "12"]
    assert len(fa) == 4 and len({x["model_param_hash"] for x in fa}) == 4
    assert len({(x["prefix_freeze"], x["prefix_train"]) for x in fa}) == 4
    assert len({x["prefix_train"] for x in fa}) == 2            # the two learning rates


def test_without_the_declared_factors_the_paired_stream_audit_fails(panel):
    root = panel["root"]
    r = _tool(SR_TOOL, root, root / "novary", "--manifest", panel["man"], "--strict", "--codes", X1,
              "--paired-streams", "--paired-vary", "growth.act")
    assert r.returncode == 1
    bad = read_json(root / "novary_coverage.json")["paired_stream_failures"]
    assert [b["check"] for b in bad] == ["trajectories: config_apart_from_holds"] and len(bad[0]["values"]) == 3
    r = _tool(SR_TOOL, root, root / "x", "--manifest", panel["man"], "--paired-vary", "growth.act")
    assert r.returncode == 2 and "--paired-vary needs --paired-streams" in r.stderr
    r = _tool(SR_TOOL, root, root / "x", "--manifest", panel["man"], "--paired-streams", "--paired-vary", "data.x")
    assert r.returncode == 2


def test_compact_fork_equality_groups_by_training_settings():
    import selective_reversal as SR
    def rec(run, h, ptrain):
        return {"cell": "c", "data_draw": 1, "optimizer_seed": 0, "parent": "f0", "prefix_frozen": False,
                "prefix_freeze": "none", "prefix_train": ptrain, "run_id": run, "record": "segment_start",
                "segment": 1, "update": 12, "model_param_hash": h, "opt_digest": "o", "sampler": "s",
                "rng_hash": "r", "batch_id_hash": "b", "batches_drawn": 12, "reset_applied": False,
                "opt_tensors_with_state_after_configure": 4}
    end = lambda run, ptrain: {**rec(run, None, ptrain), "record": "end", "segment": None, "update": 24}
    two_rates = [rec("a", "h1", "lr1"), rec("b", "h2", "lr0.3"), end("a", "lr1"), end("b", "lr0.3")]
    assert SR.compact_fork_equality(two_rates, 12) == []
    same_rate = [rec("a", "h1", "lr1"), rec("b", "h2", "lr1"), end("a", "lr1"), end("b", "lr1")]
    assert [b["field"] for b in SR.compact_fork_equality(same_rate, 12)] == ["model_param_hash"]
    legacy = [{k: v for k, v in r.items() if k != "prefix_train"} for r in same_rate]     # rows from before v53
    assert [b["field"] for b in SR.compact_fork_equality(legacy, 12)] == ["model_param_hash"]


def test_registry_values_are_the_named_rows(panel):
    import selective_reversal as SR
    cov = panel["cov"]("reversal26")
    assert cov["registry"]["name"] == "wave26" and cov["registry"]["problems"] == [] and \
        cov["registry"]["primary"] == sorted(SR.REGISTRY_PRIMARY["wave26"])
    reg = {x["contrast"]: x for x in panel["t"]("reversal26", "registry_by_setting")}
    prim = SR.REGISTRY_PRIMARY["wave26"]
    assert set(reg) == {c[0] for c in SR.REGISTRIES["wave26"]}
    assert all(x["role"] == ("primary" if k in prim else "secondary") for k, x in reg.items())
    codes = {(x["variant"], x["state"], x["code"]): float(x["test_err"]) for x in panel["t"]("reversal26", "codes")}
    imp = {(x["variant"], x["state"], x["code"]): float(x["test_err"])
           for x in panel["t"]("reversal26", "codes_implants")}
    tr = {(x["variant"], x["updates_since_f0"], x["code"]): float(x["test_err"])
          for x in panel["t"]("reversal26", "trace") if x["source"] == "control"}
    E = lambda v: codes[(v, "abrupt", X1)]
    val = lambda n: float(reg[n]["value"])
    for h in "AB":
        for v in (f"{h}_routed_relu", f"{h}_all_affine"):
            assert val(f"S_{v}_extraction_vs_f0") == pytest.approx(codes[(v, "abrupt", ONES)] - E(v), abs=1e-15)
            assert val(f"S_{v}_extraction_vs_compact_{h}_extraction_at_2U") == pytest.approx(
                tr[(f"compact_{h}", "12", X1)] - E(v), abs=1e-15)
            assert val(f"S_{v}_extraction_vs_compact_{h}_extraction_at_4U") == pytest.approx(
                codes[(f"compact_{h}", "C1_final", X1)] - E(v), abs=1e-15)
            assert val(f"S_{v}_extraction_vs_expanded_with_additions") == pytest.approx(
                imp[(v, "abrupt", ZERO)] - E(v), abs=1e-15)
        assert val(f"F_{h}_affine_vs_relu_given_routed_extraction") == pytest.approx(
            E(f"{h}_routed_relu") - E(f"{h}_routed_affine"), abs=1e-15)
        assert val(f"F_{h}_all_vs_routed_given_relu_expanded") == pytest.approx(
            imp[(f"{h}_routed_relu", "abrupt", ZERO)] - imp[(f"{h}_all_relu", "abrupt", ZERO)], abs=1e-15)
        assert val(f"F_{h}_interaction_act_by_route_extraction") == pytest.approx(
            (E(f"{h}_routed_relu") - E(f"{h}_routed_affine")) - (E(f"{h}_all_relu") - E(f"{h}_all_affine")),
            abs=1e-15)
        lo = f"{h}_routed_relu_lr0.3"
        assert val(f"L_{h}_lr0.3_vs_lr1_extraction") == pytest.approx(E(f"{h}_routed_relu") - E(lo), abs=1e-15)
        assert val(f"S_{lo}_extraction_vs_compact_{h}_lr0.3_extraction_at_2U") == pytest.approx(
            tr[(f"compact_{h}_lr0.3", "12", X1)] - E(lo), abs=1e-15)
        assert val(f"L_{h}_interaction_excess_over_compact_lr1_minus_lr0.3") == pytest.approx(
            (tr[(f"compact_{h}", "12", X1)] - E(f"{h}_routed_relu")) -
            (tr[(f"compact_{h}_lr0.3", "12", X1)] - E(lo)), abs=1e-15)
        cp = f"compact_{h}"
        assert val(f"S_{cp}_extraction_at_4U_vs_at_2U") == pytest.approx(
            tr[(cp, "12", X1)] - codes[(cp, "C1_final", X1)], abs=1e-15)
        assert val(f"S_{cp}_extraction_at_2U_vs_f0") == pytest.approx(tr[(cp, "12", ONES)] - tr[(cp, "12", X1)],
                                                                    abs=1e-15)
    assert val("H_all_relu_B_vs_A_extraction") == pytest.approx(E("A_all_relu") - E("B_all_relu"), abs=1e-15)
    # the compact control's endpoint is its state at 4U: the trace's last checkpoint is the same model
    assert codes[("compact_B", "C1_final", X1)] == tr[("compact_B", "24", X1)]
    # the 2U table: five models per expansion, four per compact control
    ex = panel["t"]("reversal26", "extraction_2u")
    assert len(ex) == 10 * 5 + 4 * 4


# ----------------------------------------------------------------------------- the arms are what they are named

def test_affine_additions_are_affine_and_all_example_arms_mask_nothing(panel):
    from cop.graph.graph import GraphNet
    runs = panel["root"] / "runs"
    for k, c in panel["T"].items():
        g = GraphNet.from_checkpoint(torch.load(runs / run_id(c) / "ckpt" / "final.pt", weights_only=False)["model"])
        fns = {g.nodes[n].attrs["fn"] for im in g.implants.values() for n in im.nodes
               if n in g.nodes and g.nodes[n].op == "act"}
        assert fns == ({"identity"} if "affine" in k else {"relu"}), k
        acc = read_json(runs / run_id(c) / "specialization_access.json")
        cov = acc["gradient_coverage"]
        if "_all_" in k:
            assert acc["membership"] == "every example in both" and cov["branch_a"] == cov["branch_b"] == 1.0
        else:
            assert acc["membership"] == "fixed per example" and cov["branch_a"] + cov["branch_b"] == pytest.approx(1.0)
            assert 0.0 < cov["branch_b"] < cov["branch_a"] < 1.0
    # the fitted map of the additions' output: exact for the affine arms, at every checkpoint with any output
    ac = panel["t"]("edits26", "age_course")
    assert len(ac) == 10 * 5
    for r in ac:
        if r["affine_r2_train"] == "":
            assert r["checkpoint"] == "post_insert_r1"            # nothing to fit: the output is exactly zero
            continue
        if "affine" in r["variant"]:
            assert float(r["affine_r2_train"]) == pytest.approx(1.0, abs=1e-9), r["variant"]
            assert float(r["nonlinear_energy_share_test"]) < 1e-9
            assert float(r["fold_dis_native_test"]) == 0.0 and float(r["fold_minus_native_test_err"]) == 0.0
        else:
            assert float(r["nonlinear_energy_share_test"]) > 1e-6, r["variant"]


def test_all_example_masks_leave_every_branch_gradient_unmasked(panel):
    """one batch through the all-example arm's trained network, with the arm's own masks and with no masks at all:
    the same gradient on every addition parameter.  A split of the same batch changes it (the routed arms)."""
    from cop.data.registry import load_bundle
    from cop.experiments.trajectory import spec_masks
    from cop.graph.graph import GraphNet
    from cop.train.trainer import task_loss
    c = panel["T"]["B_all_relu"]
    b = load_bundle(c["data"], None, device="cpu")
    ck = torch.load(panel["root"] / "runs" / run_id(c) / "ckpt" / "final.pt", weights_only=False)
    batch = b.train.index(torch.arange(64))

    def branch_grads(ctx):
        g = GraphNet.from_checkpoint(ck["model"])
        g.train()
        owned = {nd.pkey for nd in g.nodes.values() if nd.owner is not None and nd.pkey}
        ps = [(n, p) for n, p in g.named_parameters() if n.split(".")[1] in owned]
        gs = torch.autograd.grad(task_loss(g(batch.X, ctx), batch.y, b.task), [p for _, p in ps])
        return dict(zip([n for n, _ in ps], gs))
    ctx = spec_masks(b, mode="all_examples")(batch)
    assert set(ctx) == {"grad_masks"} and all(bool((m == 1).all()) for m in ctx["grad_masks"].values())
    ga, gn = branch_grads(ctx), branch_grads({})
    assert len(ga) == 16 and all(torch.equal(ga[n], gn[n]) for n in ga)      # 4 additions x (A, B) x (weight, bias)
    assert all(float(v.abs().sum()) > 0 for v in ga.values())
    half = (torch.arange(64) % 2 == 0).float()
    gs = branch_grads({"grad_masks": {"spec_a": half, "spec_b": 1 - half}})
    assert any(not torch.equal(gs[n], gn[n]) for n in gs)


# ----------------------------------------------------------------------------- gain-only training

def test_gain_training_draws_the_expansions_minibatches_and_starts_at_f0(panel):
    import gain_training as GT
    cov = panel["cov"]("gains26")
    assert cov["passed"] and cov["expected_f0"] == cov["analysed_f0"] == 1 and cov["analysis_schema"] == \
        GT.ANALYSIS_SCHEMA and set(cov["modes"]) == set(GT.MODES) and cov["output_membership_failures"] == []
    ends = {torch.load(panel["root"] / "runs" / run_id(c) / "ckpt" / "final.pt",
                       weights_only=False)["trainer"]["state"]["batch_id_hash"] for c in panel["T"].values()}
    st = panel["t"]("gains26", "gain_stream")
    assert len(ends) == 1 and len(st) == 3
    assert all(x["batch_id_hash"] == next(iter(ends)) and x["batches_drawn"] == "12"
               and x["same_minibatches_as_every_expansion"] == "True" and len(x["expansions_compared"].split()) == 10
               for x in st)
    rows = panel["t"]("gains26", "gain_runs")
    assert len(rows) == 3 * 5 and {r["age"] for r in rows} == {"0", "3", "6", "9", "12"}
    for r in rows:
        assert float(r["impl_max_rel_diff"]) <= GT.IMPL_TOL and r["impl_decisions_differ"] == "0"
        assert r["lr"] == "0.001" and r["updates"] == "12"
        if r["age"] == "0":                               # gains of 1: f0 itself
            assert float(r["test_gain_vs_f0"]) == 0.0 and float(r["gain_min"]) == float(r["gain_max"]) == 1.0
            assert float(r["train_loss"]) == float(r["f0_train_loss"]) and r["test_err"] == r["f0_test_err"]
        else:
            assert float(r["gain_min"]) != 1.0 or float(r["gain_max"]) != 1.0
        if r["mode"] == "causal_scalar":
            assert float(r["gain_shortcut"]) == 1.0 and float(r["gain_other_mean"]) == 1.0 and r["n_gains"] == "1"
            assert float(r["gain_causal_min"]) == float(r["gain_causal_max"])
        if r["mode"] == "per_column_shortcut_held":
            assert float(r["gain_shortcut"]) == 1.0 and r["n_gains"] == "16"
        if r["mode"] == "per_column":
            assert r["n_gains"] == "17" and (r["age"] == "0" or float(r["gain_shortcut"]) != 1.0)
    vec = panel["t"]("gains26", "gain_vectors")
    assert len(vec) == 3 * 17
    assert {(v["mode"], v["block"]) for v in vec if v["trained"] == "False"} == {
        ("causal_scalar", "shortcut"), ("causal_scalar", "other"), ("per_column_shortcut_held", "shortcut")}
    assert all(float(v["gain"]) == 1.0 for v in vec if v["trained"] == "False")


def test_gain_training_matches_an_independent_implementation(panel):
    """the same training written again without the tool's pieces: a plain ReLU chain on f0's tensors, torch's AdamW,
    the minibatches from a second trainer started at f0.  The trained gains and the test decisions must agree."""
    import numpy as np
    import coordinated_edits as CE
    import selective_reversal as SR
    from cop.data.registry import load_bundle
    from cop.experiments.common import seeds
    from cop.graph.graph import GraphNet
    from cop.train.trainer import Trainer
    root, p0 = panel["root"], panel["p0"]
    c = panel["T"]["A_routed_relu"]
    f0k = torch.load(root / "runs" / run_id(c) / "ckpt" / "baseline_ref.pt", weights_only=False)
    b = load_bundle(c["data"], None, device="cpu")
    f0 = GraphNet.from_checkpoint(f0k["model"]).eval()
    sd = {k: v.clone() for k, v in f0.state_dict().items()}
    L = SR.backbone_layers(f0)
    wk = [next(k for k in sd if k.startswith(f"mods.{Lk}.") and sd[k].dim() == 2) for Lk in L]
    bk = [next(k for k in sd if k.startswith(f"mods.{Lk}.") and sd[k].dim() == 1) for Lk in L]
    lay = b.meta["feature_layout"]
    sc = int(lay["shortcut"])
    free = [j for j in range(sd[wk[0]].shape[1]) if j != sc]
    for mode in ("per_column_shortcut_held", "causal_scalar"):
        trn = Trainer(GraphNet.from_checkpoint(f0k["model"]), b, dict(p0["train"]), seeds(p0), "cpu")
        trn.load_state_dict(f0k["extra"]["trainer"])
        n = len(free) if mode != "causal_scalar" else 1
        g = torch.nn.Parameter(torch.ones(n))
        opt = torch.optim.AdamW([g], lr=p0["train"]["lr"], betas=tuple(p0["train"]["betas"]), weight_decay=0.0)
        for _ in range(12):
            bt = trn.next_batch()
            gv = torch.ones(sd[wk[0]].shape[1])
            if mode == "causal_scalar":
                gv = torch.cat([g.expand(lay["causal"][1] - lay["causal"][0]),
                                torch.ones(sd[wk[0]].shape[1] - lay["causal"][1])])
                assert lay["causal"][0] == 0
            else:
                gv = gv.index_put((torch.tensor(free),), g)
            _, z = CE.mlp_forward({**sd, wk[0]: sd[wk[0]] * gv[None, :]}, bt.X["x"].float(), wk, bk)
            opt.zero_grad()
            torch.nn.functional.cross_entropy(z.float(), bt.y.long()).backward()
            opt.step()
        saved = np.load(root / "gain_states26" / f"{run_id(p0)}__gain_{mode}.npz")
        assert json.loads(str(saved["meta"]))["order"][-1] == f"{mode}|12"
        np.testing.assert_allclose(saved["gains"], g.detach().numpy(), rtol=0, atol=2e-6)
        assert float(np.abs(saved["gains"] - 1).max()) > 1e-4               # the gains did move
        gv = torch.ones(sd[wk[0]].shape[1])
        gv[torch.tensor(free if mode != "causal_scalar" else list(range(*lay["causal"])))] = torch.tensor(
            saved["gains"]).expand(len(free) if mode != "causal_scalar" else lay["causal"][1] - lay["causal"][0])
        _, zt = CE.mlp_forward({**sd, wk[0]: sd[wk[0]] * gv[None, :]}, b.test.X["x"].float(), wk, bk)
        assert np.array_equal(saved["preds_test"][-1], zt.argmax(-1).numpy())
        assert np.array_equal(saved["labels_test"], b.test.y.numpy())


def test_gain_training_fails_when_an_expansion_drew_other_minibatches(panel, tmp_path):
    import shutil
    root = tmp_path / "p"
    shutil.copytree(panel["root"] / "runs", root / "runs")
    shutil.copy2(panel["man"], root / "m.jsonl")
    ckp = root / "runs" / run_id(panel["T"]["B_all_affine"]) / "ckpt" / "final.pt"
    ck = torch.load(ckp, weights_only=False)
    ck["trainer"]["state"]["batch_id_hash"] = "0" * 24
    torch.save(ck, ckp)
    r = _tool(GAIN_TOOL, root, root / "g", "--manifest", root / "m.jsonl", "--strict", "--device", "cpu")
    assert r.returncode == 1 and "different minibatch streams" in r.stderr
    cov = read_json(root / "g_coverage.json")
    assert not cov["passed"] and cov["analysed_f0"] == 0 and _rows(root / "g_gain_runs.csv") == []
    for p in (root / "runs").glob("*/ckpt/final.pt"):                 # every expansion agrees, but not with f0's stream
        ck = torch.load(p, weights_only=False)
        if "batch_id_hash" in ((ck.get("trainer") or {}).get("state") or {}) and "traj-" in str(p):
            ck["trainer"]["state"]["batch_id_hash"] = "1" * 24
            torch.save(ck, p)
    r = _tool(GAIN_TOOL, root, root / "g2", "--manifest", root / "m.jsonl", "--strict", "--device", "cpu")
    assert r.returncode == 1 and "differs from the expansions'" in r.stderr


def test_gain_owners_and_vector():
    import gain_training as GT
    lay = {"causal": [0, 3], "shortcut": 3, "noise": [4, 6]}
    own, n = GT.owners("causal_scalar", 6, lay)
    assert own.tolist() == [0, 0, 0, -1, -1, -1] and n == 1
    own, n = GT.owners("per_column", 6, {})
    assert own.tolist() == list(range(6)) and n == 6
    own, n = GT.owners("per_column_shortcut_held", 6, lay)
    assert own.tolist() == [0, 1, 2, -1, 3, 4] and n == 5
    g = torch.tensor([2.0, 3.0, 4.0, 5.0, 6.0], requires_grad=True)
    v = GT.gain_vector(g, own)
    assert v.tolist() == [2.0, 3.0, 4.0, 1.0, 5.0, 6.0]
    (gr,) = torch.autograd.grad(v.sum(), [g])
    assert gr.tolist() == [1.0] * 5
    for mode in ("causal_scalar", "per_column_shortcut_held"):
        with pytest.raises(GT.Fail):
            GT.owners(mode, 6, {"causal": [0, 3], "shortcut": 3, "input_rotation": [[1.0]]})
    with pytest.raises(GT.Fail):
        GT.owners("other", 6, lay)


# ----------------------------------------------------------------------------- the paired tables

def test_panel_tables_are_the_named_differences(panel):
    import panel26_tables as PT
    cov = panel["cov"]("tables26")
    assert cov["passed"] and cov["problems"] == [] and cov["groups"] == 1 and cov["expansion_updates"] == 12
    assert len(cov["one_factor_pairs"]) == 15
    assert {tuple(p) for p in cov["one_factor_pairs"]} >= {
        ("act", "B_routed_affine", "B_routed_relu"), ("route", "A_all_relu", "A_routed_relu"),
        ("lr", "B_routed_relu_lr0.3", "B_routed_relu"), ("hold", "B_all_affine", "A_all_affine")}
    assert cov["matched_compact"]["B_all_affine"] == "compact_B" and \
        cov["matched_compact"]["A_routed_relu_lr0.3"] == "compact_A_lr0.3"
    age = {(r["variant"], r["checkpoint"]): r for r in panel["t"]("edits26", "age_course")}
    ac = panel["t"]("tables26", "arm_contrasts")
    for r in ac:
        a_, b_ = age[(r["first"], r["checkpoint"])], age[(r["second"], r["checkpoint"])]
        assert float(r["value"]) == pytest.approx(float(a_[r["metric"]]) - float(b_[r["metric"]]), abs=1e-15)
        assert r["metric"] in PT.CONTRAST_METRICS
    got = {(r["first"], r["second"], r["checkpoint"], r["metric"]) for r in ac}
    assert len(got) == len(ac)
    for f, v1, v2 in cov["one_factor_pairs"]:
        for ck in ("post_insert_r1", "snap_3", "post_insert_r2", "snap_9", "final"):
            for m in ("extraction_test_err", "train_loss", "native_test_err"):
                assert (v1, v2, ck, m) in got
        assert (v1, v2, "final", "M_spectral") in got and (v1, v2, "post_insert_r1", "M_spectral") not in got
    # the common clock and the excess over the matched compact control
    tr = {(x["variant"], x["updates_since_f0"], x["code"]): x for x in panel["t"]("reversal26", "trace")
          if x["source"] == "control"}
    ex = panel["t"]("tables26", "excess")
    assert len(ex) == 10 * (4 + 1) * 2
    for r in ex:
        ck = "final" if r["match"] != "same update" else r["checkpoint"]
        ev = float(age[(r["expansion"], ck)][r["metric"]])
        cv = float(tr[(r["compact"], r["compact_updates"], X1)]["test_err" if r["metric"].endswith("test_err")
                                                                else "val_err"])
        assert float(r["value"]) == pytest.approx(ev - cv, abs=1e-15)
        if r["match"] == "same update":
            assert r["compact_updates"] == r["updates_since_f0"] and r["compact_over_expansion_macs"] == ""
        else:
            # the first saved compact state with at least the expansion's compute: here the last one (4U)
            assert r["compact_updates"] == "24" and float(r["compact_over_expansion_macs"]) >= 1.0
    tt = {(x["variant"], x["updates_since_f0"]): float(x["macs_backward_aware"])
          for x in panel["t"]("reversal26", "trace") if x["source"] == "trajectory"}
    need = tt[("B_routed_relu", "12")]
    cm = {u: float(tr[("compact_B", str(u), ZERO)]["macs_backward_aware"]) for u in EA}
    assert min(u for u in EA if cm[u] >= need) == 24 and cm[21] < need
    assert cov["compute_match"]["compact_updates_used"] == [24]
    assert cov["compute_match"]["compact_over_expansion_macs_min"] == pytest.approx(cm[24] / need)
    course = panel["t"]("tables26", "course")
    assert len(course) == 10 * 5 + 4 * 8
    # the gain-trained f0 against f0, every expansion's extraction and every compact control's
    gr = {r["mode"]: r for r in panel["t"]("gains26", "gain_runs") if r["age"] == "12"}
    gc = panel["t"]("tables26", "gain_contrasts")
    assert len(gc) == 3 * (1 + 10 + 4) * 2
    for r in gc:
        mine = float(gr[r["mode"]][r["metric"]])
        if r["other"] == "f0":
            other = float(gr[r["mode"]][f"f0_{r['metric']}"])
        elif r["other_kind"] == "expansion extraction":
            other = float(age[(r["other"].split()[0], "final")][f"extraction_{r['metric']}"])
        else:
            other = float(tr[(r["other"].split()[0], "12", X1)][r["metric"]])
        assert float(r["value"]) == pytest.approx(mine - other, abs=1e-15)


def test_panel_tables_fail_on_a_missing_partner(panel, tmp_path):
    root = panel["root"]
    rows = panel["t"]("edits26", "age_course")
    keep = [r for r in rows if not (r["variant"] == "B_all_relu" and r["checkpoint"] == "snap_9")]
    with open(tmp_path / "e_age_course.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(keep)
    r = _tool(PC_TOOL, tmp_path / "t", "--manifest", panel["man"], "--reversal", root / "reversal26", "--edits",
              tmp_path / "e", "--gains", root / "gains26", "--strict")
    assert r.returncode == 1
    prob = read_json(tmp_path / "t_coverage.json")["problems"]
    assert prob and all(p["problem"] == "missing checkpoint" and "B_all_relu" in p["key"] for p in prob)
    r = _tool(PC_TOOL, tmp_path / "u", "--manifest", panel["man"], "--reversal", root / "reversal26", "--edits",
              tmp_path / "none", "--gains", root / "gains26", "--strict")
    assert r.returncode == 1 and "missing input table" in r.stderr


def test_one_factor_pairs_and_matched_compact():
    import panel26_tables as PT
    L = lambda h, r, a_, lr: {"hold": h, "route": r, "act": a_, "lr": lr}        # noqa: E731
    exp = {"a": L("none/none", "random_matched", "relu", 1e-3), "b": L("none/none", "random_matched", "identity", 1e-3),
           "c": L("none/none", "all_examples", "relu", 1e-3), "d": L("shortcut/none", "random_matched", "relu", 1e-3),
           "e": L("none/none", "random_matched", "relu", 3e-4), "f": L("shortcut/none", "all_examples", "identity", 1e-3)}
    assert PT.one_factor_pairs(exp) == [("act", "b", "a"), ("hold", "d", "a"), ("lr", "e", "a"), ("route", "c", "a")]
    comp = {"x": {"hold": "none/none", "lr": 1e-3}, "y": {"hold": "none/none", "lr": 3e-4}}
    assert PT.matched_compact(exp, comp) == {"a": "x", "b": "x", "c": "x", "d": None, "e": "y", "f": None}
    assert PT.num("") is None and PT.num(None) is None and PT.num("0.5") == 0.5


# ----------------------------------------------------------------------------- the CUDA backend

@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA device required")
def test_cuda_analyses_agree_with_cpu(panel):
    """coordinated_edits on the CUDA device against the CPU analysis, decision by decision (saved decisions); the
    gain training on the CUDA device passes its own checks (same minibatches, f0 at gains of 1) and its trained
    gains are reported beside the CPU's (float32 training is device dependent, so they are not required equal)."""
    import numpy as np
    import compare_edit_runs as CMP
    dev = os.environ.get("COP_TEST_CUDA_DEVICE", "cuda")
    root = panel["root"]
    r = _analyse(root, panel["man"], "edits26", prefix="edits_cuda", preds=root / "preds_cuda", device=dev)
    assert r.returncode == 0, r.stdout[-2000:] + r.stderr[-3000:]
    cov = read_json(root / "edits_cuda_coverage.json")
    assert cov["passed"] and cov["numerics"]["device"] == dev
    rep = CMP.compare(root / "edits26", root / "preds26", root / "edits_cuda", root / "preds_cuda")
    rep["devices"] = {"a": "cpu", "b": dev, "gpu": cov["numerics"]["gpu"]}
    r = _analyse(root, panel["man"], "gains26", prefix="gains_cuda", gains=root / "gains_cuda", device=dev)
    assert r.returncode == 0, r.stdout[-2000:] + r.stderr[-3000:]
    gc = read_json(root / "gains_cuda_coverage.json")
    assert gc["passed"] and gc["numerics"]["device"] == dev
    diffs = {}
    for p in sorted((root / "gain_states26").glob("*__gain_*.npz")):
        a_, b_ = np.load(p), np.load(root / "gains_cuda" / p.name)
        diffs[p.stem.split("__gain_")[1]] = float(np.abs(a_["gains"] - b_["gains"]).max())
    rep["gain_training"] = {"max_abs_gain_difference_cpu_vs_cuda": diffs,
                            "note": "reported, not required equal: float32 training is device dependent"}
    out = os.environ.get("COP_CUDA_REPORT")
    if out:
        Path(out).write_text(json.dumps(rep, indent=1))
    assert rep["passed"], rep["failures"][:5]
    assert set(rep["decisions"]) == {"fold", "age_course"}
    for t, parts in rep["decisions"].items():
        assert set(parts) == {"test", "val", "val_indep"}, t
        for d in parts.values():
            assert d["candidates"] > 0 and d["max_disagreements"] <= d["tolerance"]
    assert len(diffs) == 3 and max(diffs.values()) < 1e-2
