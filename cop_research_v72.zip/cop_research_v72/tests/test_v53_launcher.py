"""v53: the wave-26 panel launcher (scripts/53): it TRAINS (unlike scripts/47..52).  Order: environment, manifest
(a failed generation cannot fall through to a stale file), validation, CPU tests; on a CUDA device the whole suite's
CUDA tests and the wave-26 tools' agreement test must RUN and pass before any training; the panel; its status,
checks, reload, strict summary and timing; the four analyses (the two tools that evaluate networks on the declared
device); evidence; packaging whatever happens.  The real script runs in the v48 launcher test's mock COP_HOME."""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import test_v48_launcher as L  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = "53_v53_drift_panel.sh"
SRC = (ROOT / "scripts" / SCRIPT).read_text()
FILES = {k: re.search(rf'^{k}="([^"]+)"', SRC, re.M).group(1).split(",")
         for k in ("LT26_FILES", "EDIT_FILES", "GAIN_FILES", "TABLE_FILES")}
PREFIX = {"LT26_FILES": "reversal26", "EDIT_FILES": "edits26", "GAIN_FILES": "gains26", "TABLE_FILES": "tables26"}
WRITE = r"""
def write(prefix, tables, name, rc):
    for t in tables.split(","):
        if t.endswith(".json"):
            json.dump({"passed": rc == 0}, open(prefix + "_" + t, "w"))
        else:
            empty = os.environ.get("MOCK_EMPTY") == name + ":" + t
            open(prefix + "_" + t, "w").write("empty\n" if empty else "variant,x\nB,1\n")
ev = open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a")
"""
REVERSAL = "import json, os, sys\n" + WRITE + r"""
for f in ("--trace", "--codes-at-2u", "--implant-codes", "--decompose", "--paired-streams", "--strict"):
    assert f in sys.argv, f
for f in ("--save-extractions", "--trace-implants", "--reversal-grid", "--preflight", "--device"):
    assert f not in sys.argv, f
assert sys.argv[sys.argv.index("--contrasts") + 1] == "wave26"
assert sys.argv[sys.argv.index("--paired-vary") + 1] == "growth.act,growth.spec_partition,train.lr"
assert sys.argv[sys.argv.index("--codes") + 1] == "auto"
assert sys.argv[sys.argv.index("--trace-codes") + 1] == "0-0-0-0-0,0-1-1-1-1,1-1-1-1-1"
assert sys.argv[sys.argv.index("--manifest") + 1].endswith("wave26_full.jsonl")
ev.write("reversal read " + sys.argv[1] + "\n")
rc = int(os.environ.get("MOCK_REVERSAL_RC", "0"))
write(sys.argv[2], os.environ["MOCK_LT26_FILES"], "reversal26", rc)
sys.exit(rc)
"""
EDITS = "import json, os, sys\n" + WRITE + r"""
for f in ("--fold", "--train-diagnostics", "--age-course", "--strict"):
    assert f in sys.argv, f
for f in ("--expect-variants", "--minimal-edits", "--rank-restores", "--transfer", "--gain-scan", "--aligned-paths",
          "--inject-fold-fault"):
    assert f not in sys.argv, f
assert sys.argv[sys.argv.index("--save-preds") + 1].endswith("preds26")
ev.write("edits read " + sys.argv[1] + "\n")
ev.write("edits device " + sys.argv[sys.argv.index("--device") + 1] + "\n")
rc = int(os.environ.get("MOCK_EDITS_RC", "0"))
write(sys.argv[2], os.environ["MOCK_EDIT_FILES"], "edits26", rc)
sys.exit(rc)
"""
GAINS = "import json, os, sys\n" + WRITE + r"""
assert "--strict" in sys.argv and sys.argv[sys.argv.index("--save-gains") + 1].endswith("gains26")
ev.write("gains read " + sys.argv[1] + "\n")
ev.write("gains device " + sys.argv[sys.argv.index("--device") + 1] + "\n")
rc = int(os.environ.get("MOCK_GAINS_RC", "0"))
write(sys.argv[2], os.environ["MOCK_GAIN_FILES"], "gains26", rc)
sys.exit(rc)
"""
TABLES = "import json, os, sys\n" + WRITE + r"""
assert "--strict" in sys.argv
for f, tail in (("--reversal", "reversal26"), ("--edits", "edits26"), ("--gains", "gains26")):
    assert sys.argv[sys.argv.index(f) + 1].endswith("v53_reports/" + tail), f
ev.write("tables\n")
rc = int(os.environ.get("MOCK_TABLES_RC", "0"))
write(sys.argv[1], os.environ["MOCK_TABLE_FILES"], "tables26", rc)
sys.exit(rc)
"""
REPORT = r"""import json, os, sys
name = os.path.basename(sys.argv[0])
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write(name + " " + " ".join(sys.argv[1:4]) + "\n")
if name == "runtime_v13.py":                      # runtime_v13.py fit MANIFEST RESULTS OUT
    assert sys.argv[1] == "fit" and sys.argv[3].endswith("panel26")
    out = sys.argv[4]
else:                                             # <tool> RESULTS OUT ...
    assert sys.argv[1].endswith("panel26") and "--manifest" in sys.argv or name == "fresh_reload.py"
    out = sys.argv[2]
json.dump({"passed": True}, open(out, "w"))
"""
PYTEST = r'''#!/usr/bin/env bash
echo "pytest $*" >> "$MOCK_HOME/events.txt"
echo "3 passed"
xml=""; prev=""
for a in "$@"; do [ "$prev" = "--junitxml" ] && xml="$a"; prev="$a"; done
junit() { [ -n "$xml" ] && echo "<testsuites><testsuite tests=\"$1\" skipped=\"$2\" failures=\"0\" errors=\"0\"/></testsuites>" > "$xml"; }
case " $* " in
  *"tests/test_v53.py -k cuda "*)
    junit 1 "${MOCK_CUDA_SKIPPED:-0}"
    [ -n "$COP_CUDA_REPORT" ] && [ "${MOCK_CUDA_SKIPPED:-0}" = 0 ] && echo '{"passed": true}' > "$COP_CUDA_REPORT"
    echo "cuda analysis test device $COP_TEST_CUDA_DEVICE" >> "$MOCK_HOME/events.txt"
    exit "${MOCK_CUDA_TEST_RC:-0}" ;;
  *" -k cuda or gpu_equivalence "*)
    junit 5 "${MOCK_SUITE_SKIPPED:-0}"
    echo "cuda suite device $COP_TEST_CUDA_DEVICE" >> "$MOCK_HOME/events.txt"
    exit "${MOCK_SUITE_RC:-0}" ;;
esac
junit 3 0
exit "${MOCK_TEST_RC:-0}"
'''


@pytest.fixture
def h(tmp_path):
    home = tmp_path / "home"
    (home / "scripts").mkdir(parents=True)
    shutil.copy2(ROOT / "scripts" / SCRIPT, home / "scripts" / SCRIPT)
    for f in ("package_reports.py", "check_evidence.py", "junit_ran.py"):
        shutil.copy2(ROOT / "scripts" / f, home / "scripts" / f)
    (home / "scripts/common.sh").write_text(L.COMMON)
    (home / "audit_v5/tools").mkdir(parents=True)
    (home / "audit_v8/tools").mkdir(parents=True)
    for name, body in (("selective_reversal.py", REVERSAL), ("coordinated_edits.py", EDITS),
                       ("gain_training.py", GAINS), ("panel26_tables.py", TABLES), ("fresh_reload.py", REPORT),
                       ("runtime_v13.py", REPORT)):
        (home / "audit_v5/tools" / name).write_text(body)
    (home / "audit_v8/tools/check_results.py").write_text(REPORT)
    pt = home / "fake_pytest.sh"
    pt.write_text(PYTEST)
    pt.chmod(0o755)
    zipdir = tmp_path / "zips"
    zipdir.mkdir()
    base = {k: v for k, v in os.environ.items() if k not in ("DIAGNOSTIC_OVERRIDE", "COP_PYTEST")}
    env = dict(base, MOCK_HOME=str(home), COP_RESULTS=str(tmp_path / "results"), ZIP_DIR=str(zipdir), SCALE="full",
               HOME=str(tmp_path), COP_PYTEST=str(pt), **{f"MOCK_{k}": ",".join(v) for k, v in FILES.items()})
    return {"home": home, "res": tmp_path / "results", "zip": zipdir / "cop_v53_panel_reports.zip", "env": env,
            "tmp": tmp_path}


def _sh(h, common=None, **env):
    if common is not None:
        (h["home"] / "scripts/common.sh").write_text(common)
    e = dict(h["env"], **{k: str(v) for k, v in env.items()})
    return subprocess.run(["bash", str(h["home"] / "scripts" / SCRIPT)], env=e, capture_output=True, text=True,
                          cwd=str(h["home"]))


def _verdict(h):
    return json.loads((h["res"] / "v53_reports/verdict.json").read_text())


def _events(h):
    p = h["home"] / "events.txt"
    return p.read_text() if p.exists() else ""


ANALYSES = ("reversal26", "edits26", "gains26", "tables26")
AFTER_RUN = ("status26", "checks26", "reload26", "summary26", "rates26") + ANALYSES


def test_success_trains_the_panel_then_analyses_it(h):
    r = _sh(h)
    assert r.returncode == 0, r.stdout + r.stderr
    v = _verdict(h)
    assert v["all_passed"] and list(v["steps"]) == [
        "environment", "manifest26", "validate26", "cpu_tests", "run26", *AFTER_RUN, "evidence26", "manifest_copy",
        "package", "package_final"]
    ev = _events(h)
    panel = str(h["res"] / "panel26")
    run = next(l for l in ev.splitlines() if l.startswith("cop run "))
    assert f"--results {panel}" in run and "wave26_full.jsonl" in run and "--resume" in run and "--device cpu" in run
    assert "cop generate-manifest --wave 26 --scale full" in ev and "cop summarize --strict" in ev
    order = [ev.index(x) for x in ("cop generate-manifest", "cop validate-manifest", "\npytest ", "cop run ",
                                   "cop status", "check_results.py", "fresh_reload.py", "cop summarize",
                                   "runtime_v13.py", "reversal read", "edits read", "gains read", "tables\n")]
    assert order == sorted(order)
    for t in ("reversal", "edits", "gains"):
        assert f"{t} read {panel}" in ev
    assert "edits device cpu" in ev and "gains device cpu" in ev and "-k cuda" not in ev
    names = zipfile.ZipFile(h["zip"]).namelist()
    for k, fs in FILES.items():
        for f in fs:
            assert f"cop_v53_panel_reports/v53_reports/{PREFIX[k]}_{f}" in names, (k, f)
    for f in ("evidence26.json", "checks26.json", "fresh_reload26.json", "wave26_full.jsonl", "rates26.json"):
        assert f"cop_v53_panel_reports/v53_reports/{f}" in names, f
    inner = json.loads(zipfile.ZipFile(h["zip"]).read("cop_v53_panel_reports/verdict.json"))
    assert inner["completed_steps_passed"] and inner["pending"] == ["package_final"]     # the archive's own step
    assert "cop_v53_panel_reports/summary26/s.csv" in names
    # nothing is written outside its own results folder, the archive folder and the manifest folder
    made = {p.name for p in h["tmp"].iterdir()}
    assert made == {"home", "results", "zips"}


@pytest.mark.parametrize("device", ["cuda", "cuda:1"])
def test_on_cuda_every_cuda_test_runs_before_any_training_and_the_device_is_forwarded(h, device):
    cuda = L.COMMON.replace("DEVICE=cpu", f"DEVICE={device}")
    r = _sh(h, common=cuda)
    assert r.returncode == 0, r.stdout + r.stderr
    ev = _events(h)
    assert f"cuda suite device {device}" in ev and f"cuda analysis test device {device}" in ev
    suite = next(l for l in ev.splitlines() if "gpu_equivalence" in l)
    assert "--ignore tests/test_v53.py" in suite and " tests/ " in suite
    assert ev.index("cuda suite device") < ev.index("cuda analysis test device") < ev.index("cop run ")
    assert f"--device {device}" in next(l for l in ev.splitlines() if l.startswith("cop run "))
    assert f"edits device {device}" in ev and f"gains device {device}" in ev
    v = _verdict(h)
    assert all(v["steps"][k] == 0 for k in ("cuda_tests", "cuda_tests_ran", "cuda_analysis_test", "cuda_test_ran"))
    assert "cop_v53_panel_reports/v53_reports/cuda_agreement.json" in zipfile.ZipFile(h["zip"]).namelist()


@pytest.mark.parametrize("env,step", [({"MOCK_CUDA_SKIPPED": 1}, "cuda_test_ran"),
                                      ({"MOCK_SUITE_SKIPPED": 2}, "cuda_tests_ran"),
                                      ({"MOCK_CUDA_TEST_RC": 1}, "cuda_analysis_test"),
                                      ({"MOCK_SUITE_RC": 1}, "cuda_tests")])
def test_a_skipped_or_failed_cuda_test_stops_before_training(h, env, step):
    r = _sh(h, common=L.COMMON.replace("DEVICE=cpu", "DEVICE=cuda"), **env)
    v = _verdict(h)
    assert r.returncode != 0 and v["steps"][step] == 1 and v["steps"]["run26"] == 99
    assert "cop run" not in _events(h) and all(v["steps"][k] == 99 for k in AFTER_RUN) and h["zip"].exists()


def test_a_failed_manifest_generation_cannot_fall_through_to_a_stale_manifest(h):
    stale = h["home"] / "manifests/wave26_full.jsonl"
    stale.parent.mkdir(parents=True)
    stale.write_text('{"run_id": "stale"}\n')
    r = _sh(h, MOCK_MANIFEST_RC=1)
    assert r.returncode != 0 and not stale.exists()
    v = _verdict(h)
    assert v["steps"]["manifest26"] == 1 and v["steps"]["validate26"] == 99 and v["steps"]["cpu_tests"] == 99
    assert v["steps"]["run26"] == 99 and v["steps"]["manifest_copy"] == 99
    assert "cop run" not in _events(h) and "\npytest " not in _events(h) and h["zip"].exists()


def test_failed_tests_skip_the_panel_unless_overridden(h):
    r = _sh(h, MOCK_TEST_RC=1)
    v = _verdict(h)
    assert r.returncode != 0 and v["steps"]["cpu_tests"] == 1 and v["steps"]["run26"] == 99
    assert "cop run" not in _events(h)
    r = _sh(h, MOCK_TEST_RC=1, DIAGNOSTIC_OVERRIDE=1)
    v = _verdict(h)
    assert r.returncode != 0 and v["steps"]["run26"] == 0 and "cop run" in _events(h)
    assert (h["res"] / "v53_reports/override.txt").exists()
    r = _sh(h, MOCK_VALIDATE_RC=1)
    assert r.returncode != 0 and _verdict(h)["steps"]["cpu_tests"] == 99 and _verdict(h)["steps"]["run26"] == 99


def test_an_unfinished_panel_reports_its_status_and_analyses_nothing(h):
    r = _sh(h, MOCK_RUN_RC=1)
    v = _verdict(h)
    assert r.returncode != 0 and v["steps"]["run26"] == 1 and v["steps"]["status26"] == 0
    assert all(v["steps"][k] == 99 for k in AFTER_RUN if k != "status26")
    ev = _events(h)
    assert "cop status" in ev and "reversal read" not in ev and "check_results" not in ev
    assert v["steps"]["evidence26"] == 0 and h["zip"].exists()
    assert "run the same command again" in (h["res"] / "v53_reports/reversal26.txt").read_text()


@pytest.mark.parametrize("which", ["REVERSAL", "EDITS", "GAINS"])
def test_a_failed_analysis_fails_the_launcher_and_skips_the_tables(h, which):
    r = _sh(h, **{f"MOCK_{which}_RC": 1})
    v = _verdict(h)
    assert r.returncode != 0 and v["steps"]["tables26"] == 99 and "tables\n" not in _events(h)
    assert sum(v["steps"][k] == 1 for k in ANALYSES) == 1 and h["zip"].exists()
    assert _sh(h, MOCK_TABLES_RC=1).returncode != 0


@pytest.mark.parametrize("empty", ["reversal26:registry_summary.csv", "reversal26:paired_streams.csv",
                                   "edits26:age_course.csv", "gains26:gain_stream.csv",
                                   "tables26:arm_contrasts_summary.csv", "tables26:excess.csv"])
def test_an_empty_required_table_fails_the_evidence(h, empty):
    r = _sh(h, MOCK_EMPTY=empty)
    assert r.returncode != 0
    step, table = empty.split(":")
    ev = json.loads((h["res"] / "v53_reports/evidence26.json").read_text())
    assert ev["steps"][step]["missing"] == [f"{step}_{table} (an empty table)"]
    assert all(ev["steps"][s]["ok"] for s in ANALYSES if s != step)


def test_stale_outputs_of_an_earlier_run_cannot_stand_in(h):
    assert _sh(h).returncode == 0
    r = _sh(h, MOCK_RUN_RC=1)                                  # the second run does not finish
    assert r.returncode != 0
    left = [p.name for p in (h["res"] / "v53_reports").glob("*26_*.csv")]
    assert left == [] and not list((h["res"] / "v53_reports").glob("reversal26_coverage.json"))


def test_the_analysis_only_launchers_before_it_stay_valid():
    for s, flag in (("48_v48_reversal_barriers.sh", "--reversal-grid"),
                    ("51_v51_coordinated_edits.sh", "--minimal-edits"), ("52_v52_channel_course.sh", "--gain-scan")):
        src = (ROOT / "scripts" / s).read_text()
        assert "is superseded" not in src and flag in src and "cop_results_v46" in src and "cop run" not in src
    assert "cop run --manifest" in SRC and "cop_results_v53" in SRC and "cop_results_v46" not in SRC
