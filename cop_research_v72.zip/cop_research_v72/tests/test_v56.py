"""v56: the component-change analysis (audit_v5/tools/component_change.py): the linear probe solver, the first-layer
controls, the design checks, and the whole tool on real miniature panels (wave 26 and wave 25) through the launcher's
own command line, with states, edits, probes in both representation contexts, contrasts and the saved probes
recomputed independently."""
from __future__ import annotations

import csv
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
from pathlib import Path

import numpy as np
import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "audit_v5" / "tools"))
from cop.config import run_id  # noqa: E402
from cop.utils import read_json  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
TOOL = str(ROOT / "audit_v5/tools/component_change.py")
LAUNCHER = ROOT / "scripts/56_v56_backbone_change.sh"
ARMS = ["A_routed_relu", "B_routed_relu", "B_all_affine"]
COMPACTS = ["compact_A", "compact_B"]
N_STATES = 8                                     # f0, three expansions, two compact controls at two ages
N_PROBED = 6                                     # probed controls per state
N_PROBES = 16 + N_STATES * 32 + N_STATES * 16 + (N_PROBED * (N_STATES - 1) + 1) * 32


def _rows(path):
    t = Path(path).read_text()
    return [] if t.strip() == "empty" else list(csv.DictReader(open(path)))


def _tool(*args):
    return subprocess.run([sys.executable, TOOL, *map(str, args)], capture_output=True, text=True, env=dict(os.environ))


def _launcher_args(wave: int, probes) -> list:
    """the launcher's own options for the tool (everything after --manifest's value), for one wave."""
    src = LAUNCHER.read_text()
    cmd = re.search(r'^\s+step "change\$w" (python .*?)\n(?!\s+--)', src, re.M | re.S).group(1).replace("\\\n", " ")
    toks = shlex.split(cmd)
    mult = re.search(rf'^MULT\[{wave}\]="([^"]+)"', src, re.M).group(1)
    sub = {"${MULT[$w]}": mult, "$PROBES/wave$w": str(probes)}
    out = [sub.get(t, t) for t in toks[toks.index("--manifest") + 2:]]
    assert "--save-probes" in out and "--strict" in out and not any("$" in t for t in out), out
    return out


def _files() -> list:
    return re.search(r'^CHANGE_FILES="([^"]+)"', LAUNCHER.read_text(), re.M).group(1).split(",")


# ----------------------------------------------------------------------------- the probe solver

def _objective(X, y, w, b, lam):
    z = X @ w + b
    return (torch.nn.functional.softplus(z) - y.double() * z).mean() + 0.5 * lam * (w * w).sum()


def test_fit_logistic_meets_first_order_stationarity_of_its_objective():
    import component_change as CC
    g = torch.Generator().manual_seed(0)
    X = torch.randn(300, 5, generator=g, dtype=torch.float64) * torch.tensor([1.0, 3.0, 0.2, 1.0, 10.0])
    y = ((X[:, 0] - 0.3 * X[:, 1] + 0.5 * torch.randn(300, generator=g, dtype=torch.float64)) > 0.2).long()
    for lam in CC.LAMBDAS:
        w, b, info = CC.fit_logistic(X, y, lam)
        assert info["grad_inf"] <= 1e-8 and info["iterations"] < CC.NEWTON_MAX_ITER
        # from an independent gradient of the stated objective (the intercept unpenalised)
        wv, bv = w.clone().requires_grad_(True), torch.tensor(b, dtype=torch.float64, requires_grad=True)
        obj = _objective(X, y, wv, bv, lam)
        gw, gb = torch.autograd.grad(obj, [wv, bv])
        assert float(gw.abs().max()) <= 1e-8 and abs(float(gb)) <= 1e-8
        assert info["loss"] == pytest.approx(float(obj.detach()), abs=1e-12)
        for _ in range(5):                                    # nearby points are no better
            dw = 1e-3 * torch.randn(5, generator=g, dtype=torch.float64)
            assert float(_objective(X, y, w + dw, torch.tensor(b + 1e-3), lam)) >= float(obj.detach())
    with pytest.raises(CC.Fail):
        CC.fit_logistic(X, y, 0.0)
    with pytest.raises(CC.Fail):
        CC.finite(torch.tensor([1.0, float("nan")]), "x")
    with pytest.raises(CC.Fail):
        CC.finite(torch.tensor([float("inf")]), "x")
    CC.finite(torch.tensor([1.0, -2.0]), "x")


def test_fit_logistic_on_separable_data_and_the_error():
    import component_change as CC
    X = torch.tensor([[-2.0], [-1.0], [1.0], [2.0]], dtype=torch.float64)
    y = torch.tensor([0, 0, 1, 1])
    w, b, info = CC.fit_logistic(X, y, 1e-4)
    assert info["grad_inf"] <= CC.CONVERGED_TOL and float(w) > 0 and abs(b) < 1e-6        # symmetric data
    assert CC.probe_error(X, y, w, b) == 0.0 and CC.probe_error(X, 1 - y, w, b) == 1.0
    assert CC.probe_error(X, torch.tensor([0, 1, 1, 1]), w, b) == 0.25


def test_standardised_probes_do_not_see_activation_scale():
    """the same activations with every feature rescaled and shifted: after standardising by the fit set, the fitted
    probe and its decisions are the same."""
    import component_change as CC
    g = torch.Generator().manual_seed(1)
    F = torch.randn(200, 4, generator=g, dtype=torch.float64)
    F[:, 3] = 2.5                                             # a constant (dead) feature
    y = (F[:, 0] + F[:, 1] > 0).long()
    G = F * torch.tensor([7.0, 0.01, 3.0, 1.0]) + torch.tensor([1.0, -2.0, 0.5, 4.0])
    out = []
    for A in (F, G):
        mu, sd = CC.standardiser(A)
        assert float(sd[3]) == 1.0                            # constant: scale 1, value exactly 0 after centring
        Z = (A - mu) / sd
        assert float(Z[:, 3].abs().max()) == 0.0
        w, b, _ = CC.fit_logistic(Z, y, 1e-2)
        out.append((w, b, Z @ w + b))
    assert torch.allclose(out[0][0], out[1][0], atol=1e-5) and out[0][1] == pytest.approx(out[1][1], abs=1e-5)
    assert torch.equal(out[0][2] > 0, out[1][2] > 0)
    w1, _, _ = CC.fit_logistic(F[:, :3], y, 1e-2)             # raw features do depend on the scale
    w2, _, _ = CC.fit_logistic(G[:, :3], y, 1e-2)
    assert not torch.allclose(w1, w2, atol=1e-3)


def test_standardised_probes_still_see_an_input_gain():
    """a gain on INPUT weights is not a rescaling of the activations: it changes which units are active, so a
    standardised probe on relu(W diag(g) x + b) differs from one on relu(W x + b), although no weight direction
    within a column changed.  A positive gain per unit on the activations themselves is removed.  This is why the
    norm-matched edits are probed and standardising alone does not answer 'beyond gains'."""
    import component_change as CC
    g = torch.Generator().manual_seed(3)
    X = torch.randn(400, 6, generator=g, dtype=torch.float64)
    W = torch.randn(8, 6, generator=g, dtype=torch.float64)
    b = 0.5 * torch.randn(8, generator=g, dtype=torch.float64)
    gain = torch.ones(6, dtype=torch.float64)
    gain[:3] = 3.0
    y = (X[:, 0] + X[:, 1] - X[:, 2] > 0).long()
    F1 = (X @ W.T + b).clamp_min(0.0)
    F2 = ((X * gain) @ W.T + b).clamp_min(0.0)                # = relu(W diag(gain) x + b)
    F3 = F1 * torch.linspace(0.2, 5.0, 8, dtype=torch.float64)
    assert bool(((F1 > 0) != (F2 > 0)).any())                 # other units are active

    def fit(F):
        mu, sd = CC.standardiser(F)
        Z = (F - mu) / sd
        w, bb, info = CC.fit_logistic(Z, y, 1e-2)
        return info["loss"], Z @ w + bb > 0
    (l1, d1), (l2, d2), (l3, d3) = fit(F1), fit(F2), fit(F3)
    assert abs(l1 - l3) < 1e-8 and torch.equal(d1, d3)        # an activation gain is removed
    assert abs(l1 - l2) > 1e-4 and not torch.equal(d1, d2)    # an input gain is not


# ----------------------------------------------------------------------------- the controls

def test_blocks_and_norm_controls():
    import component_change as CC
    lay = {"causal": [0, 3], "shortcut": 3}
    blk = CC.blocks_of(lay, 6)
    assert blk["causal"].tolist() == [0, 1, 2] and blk["shortcut"].tolist() == [3] and blk["other"].tolist() == [4, 5]
    assert CC.blocks_of({**lay, "input_rotation": [[1.0]]}, 6) is None and CC.blocks_of({}, 6) is None
    with pytest.raises(CC.Fail):
        CC.blocks_of({"causal": [0, 4], "shortcut": 3}, 6)
    g = torch.Generator().manual_seed(2)
    W0, W = torch.randn(5, 6, generator=g), torch.randn(5, 6, generator=g) * 2.0
    b0, b1 = torch.randn(5, generator=g), torch.randn(5, generator=g)
    W[:, 3] = W0[:, 3]                                         # a held shortcut column
    ed = CC.edit_layers(W, b1, W0, b0, blk)
    assert set(ed) == set(CC.EDITS) and all(info["unmatched"] == 0 for _, _, info in ed.values())
    up, bu, iu = ed["f0_at_state_block_norms"]
    down, bd, _ = ed["state_at_f0_block_norms"]
    used = iu["scales"]
    assert bu is b0 and bd is b1 and used["shortcut"] == pytest.approx(1.0)
    for name, idx in blk.items():
        # f0's directions at the state's block norm; the state's directions at f0's block norm
        assert CC.fro(up[:, idx]) == pytest.approx(CC.fro(W[:, idx]), rel=1e-5)
        assert torch.allclose(up[:, idx] / CC.fro(up[:, idx]), W0[:, idx] / CC.fro(W0[:, idx]), atol=1e-6)
        assert CC.fro(down[:, idx]) == pytest.approx(CC.fro(W0[:, idx]), rel=1e-5)
        assert torch.allclose(down[:, idx] / CC.fro(down[:, idx]), W[:, idx] / CC.fro(W[:, idx]), atol=1e-6)
        assert used[name] == pytest.approx(CC.fro(W[:, idx]) / CC.fro(W0[:, idx]), rel=1e-6)
    assert torch.allclose(up[:, 3], W0[:, 3], atol=1e-7)
    upl, _, ul = ed["f0_at_state_layer_norm"]
    dnl, bdl, _ = ed["state_at_f0_layer_norm"]
    r = CC.fro(W) / CC.fro(W0)
    assert ul["scales"]["layer"] == pytest.approx(r, rel=1e-9) and bdl is b1
    assert torch.allclose(upl, W0 * r, atol=1e-5) and CC.fro(dnl) == pytest.approx(CC.fro(W0), rel=1e-5)
    assert torch.allclose(dnl * r, W, atol=1e-5)
    # per unit and block: every row segment takes the other layer's norm and keeps its own direction
    upr, bur, _ = ed["f0_at_state_block_row_norms"]
    dnr, bdr, _ = ed["state_at_f0_block_row_norms"]
    assert bur is b0 and bdr is b1
    for idx in blk.values():
        assert torch.allclose(upr[:, idx].norm(dim=1), W[:, idx].norm(dim=1), rtol=1e-5)
        assert torch.allclose(dnr[:, idx].norm(dim=1), W0[:, idx].norm(dim=1), rtol=1e-5)
        cu = (upr[:, idx] * W0[:, idx]).sum(1) / (upr[:, idx].norm(dim=1) * W0[:, idx].norm(dim=1))
        cd = (dnr[:, idx] * W[:, idx]).sum(1) / (dnr[:, idx].norm(dim=1) * W[:, idx].norm(dim=1))
        assert torch.allclose(cu, torch.ones(5), atol=1e-5) and torch.allclose(cd, torch.ones(5), atol=1e-5)
    # the block control keeps the state's distribution of norm over units; the row control does not
    assert not torch.allclose(down[:, :3].norm(dim=1), W0[:, :3].norm(dim=1), rtol=1e-3)
    # the bias controls
    assert ed["state_weights_f0_bias"][0] is W and ed["state_weights_f0_bias"][1] is b0
    assert ed["f0_weights_state_bias"][0] is W0 and ed["f0_weights_state_bias"][1] is b1
    assert set(CC.edit_layers(W, b1, W0, b0, None)) == {"f0_at_state_layer_norm", "state_at_f0_layer_norm",
                                                        "state_weights_f0_bias", "f0_weights_state_bias"}
    assert {f for f, _ in CC.EDITS.values()} == {"layer_norm", "block_norm", "block_row_norm", "bias",
                                                 "block_norm_f0_bias", "block_row_norm_f0_bias"}
    assert set(CC.PROBED_EDITS) <= set(CC.EDITS) and CC.PRESPECIFIED_SHRINK in CC.SHRINK
    assert len(CC.PROBED_EDITS) == N_PROBED and set(CC.F0_BIAS_TWINS) | set(CC.F0_BIAS_TWINS.values()) <= set(
        CC.PROBED_EDITS)
    # the f0-bias controls: their twin's weight with f0's bias (scale and bias both controlled)
    for e1, e2 in CC.F0_BIAS_TWINS.items():
        assert ed[e1][0] is ed[e2][0] and ed[e1][1] is b0 and ed[e2][1] is b1
        assert ed[e1][2]["unmatched"] == ed[e2][2]["unmatched"] == 0
    s = CC.layer_summary(W, W0, b1, b0, blk)
    assert s["shortcut_norm_ratio"] == pytest.approx(1.0) and s["shortcut_cos_to_f0"] == pytest.approx(1.0)
    assert s["shortcut_unit_log_norm_ratio_sd"] == pytest.approx(0.0, abs=1e-12)
    assert s["layer_norm_ratio"] == pytest.approx(r) and -1.0 <= s["layer_cos_to_f0"] <= 1.0
    assert s["causal_unit_log_norm_ratio_sd"] > 0 and s["bias_change_over_f0_norm"] > 0
    same = CC.layer_summary(W0, W0, b0, b0, blk)
    assert same["layer_norm_ratio"] == 1.0 and same["change_over_f0_norm"] == 0.0 and \
        same["causal_cos_to_f0"] == pytest.approx(1.0) and same["bias_change_over_f0_norm"] == 0.0 and \
        same["layer_unit_log_norm_ratio_sd"] == 0.0


def test_a_bias_only_change_is_not_attributed_to_weight_directions():
    """a state that differs from f0 only in its first-layer bias: every weight measure says 'unchanged', the
    bias controls isolate the change, and the norm controls of the 'state at f0's norms' kind still carry that bias
    (which is why they are controls and not a decomposition)."""
    import component_change as CC
    g = torch.Generator().manual_seed(4)
    W0, b0, b1 = torch.randn(5, 6, generator=g), torch.randn(5, generator=g), torch.randn(5, generator=g)
    blk = CC.blocks_of({"causal": [0, 3], "shortcut": 3}, 6)
    s = CC.layer_summary(W0, W0, b1, b0, blk)
    assert s["change_over_f0_norm"] == 0.0 and s["layer_norm_ratio"] == 1.0 and s["bias_change_over_f0_norm"] > 0
    assert all(s[f"{k}_norm_ratio"] == 1.0 and s[f"{k}_cos_to_f0"] == pytest.approx(1.0) for k in blk)
    ed = CC.edit_layers(W0, b1, W0, b0, blk)
    w, bb, _ = ed["state_weights_f0_bias"]                     # the state's weights with f0's bias: f0 itself
    assert torch.equal(w, W0) and torch.equal(bb, b0)
    w, bb, _ = ed["f0_weights_state_bias"]                     # f0's weights with the state's bias: the state itself
    assert torch.equal(w, W0) and torch.equal(bb, b1)
    for k in ("state_at_f0_layer_norm", "state_at_f0_block_norms", "state_at_f0_block_row_norms"):
        w, bb, info = ed[k]
        assert torch.allclose(w, W0, atol=1e-6) and torch.equal(bb, b1) and info["unmatched"] == 0, k
    for k in ("f0_at_state_layer_norm", "f0_at_state_block_norms", "f0_at_state_block_row_norms",
              "state_at_f0_block_norms_f0_bias", "state_at_f0_block_row_norms_f0_bias"):
        w, bb, _ = ed[k]                                       # with scale and bias both controlled: f0 itself
        assert torch.allclose(w, W0, atol=1e-6) and torch.equal(bb, b0), k


def test_a_norm_that_cannot_be_matched_is_flagged():
    import component_change as CC
    assert CC.norm_ratio(2.0, 4.0) == 0.5 and CC.norm_ratio(0.0, 0.0) == 1.0 and CC.norm_ratio(1.0, 0.0) is None
    z = torch.zeros(3, 2)
    t, ok = CC.scale_to(z, 1.0)
    assert not ok and torch.equal(t, z)
    assert CC.scale_to(z, 0.0)[1] and CC.scale_to(torch.ones(3, 2), 0.0)[1]
    assert float(CC.scale_to(torch.ones(3, 2), 0.0)[0].abs().max()) == 0.0
    t, bad = CC.scale_rows_to(torch.tensor([[3.0, 4.0], [0.0, 0.0], [0.0, 0.0]]), torch.tensor([10.0, 1.0, 0.0]))
    assert bad == 1 and t.tolist() == [[6.0, 8.0], [0.0, 0.0], [0.0, 0.0]]
    g = torch.Generator().manual_seed(5)
    W0, W = torch.randn(5, 6, generator=g), torch.randn(5, 6, generator=g)
    b0 = torch.randn(5, generator=g)
    blk = CC.blocks_of({"causal": [0, 3], "shortcut": 3}, 6)
    Z0 = W0.clone()
    Z0[:, 4:] = 0.0                                            # f0 has a zero block the state fills
    ed = CC.edit_layers(W, b0, Z0, b0, blk)
    assert ed["f0_at_state_block_norms"][2]["unmatched"] == 1 and ed["f0_at_state_block_norms"][2]["scales"]["other"] \
        is None
    assert ed["f0_at_state_block_row_norms"][2]["unmatched"] == 5
    assert ed["state_at_f0_block_norms"][2]["unmatched"] == 0             # scaling the state's block to zero works
    assert float(ed["state_at_f0_block_norms"][0][:, 4:].abs().max()) == 0.0
    assert CC.layer_summary(W, Z0, b0, b0, blk)["other_norm_ratio"] is None
    assert CC.layer_summary(W, Z0, b0, b0, blk)["other_cos_to_f0"] is None
    ed = CC.edit_layers(Z0, b0, W, b0, blk)                    # the reverse: the state has the zero block
    assert ed["state_at_f0_block_norms"][2]["unmatched"] == 1 and ed["f0_at_state_block_norms"][2]["unmatched"] == 0
    assert ed["state_at_f0_block_row_norms"][2]["unmatched"] == 5
    ed = CC.edit_layers(torch.zeros(5, 6), b0, W, b0, blk)     # a zero layer
    assert ed["state_at_f0_layer_norm"][2]["unmatched"] == 1 and ed["f0_at_state_layer_norm"][2]["unmatched"] == 0


# ----------------------------------------------------------------------------- the design

def test_held_through_and_job_grouping():
    import component_change as CC
    hold = {"train": {"freeze_inputs": "shortcut"}}
    assert CC.held_through(hold, 10 ** 6) and not CC.held_through({"train": {"freeze_inputs": "none"}}, 1)
    sched = {**hold, "continue": {"segments": [6, 6, 3, 3], "freeze_segments": [True, True, False, False]}}
    assert CC.held_through(sched, 12) and not CC.held_through(sched, 13)
    assert CC.held_through({**hold, "continue": {"segments": [12, 12], "freeze_segments": []}}, 24)
    rem = lambda v, t: {"kind": "dissipation", "design": {"family": "X25", "variant": v, "arm": "treated"},   # noqa
                        "dissipation": {"method": "linear"}, "parents": {"trajectory": t}, "train": {}}
    tr = {"kind": "trajectory", "parents": {"baseline": "f"}}
    ctl = lambda v: {"kind": "continue", "design": {"family": "X25", "variant": v, "arm": "C1"},              # noqa
                     "parents": {"baseline": "f"}}
    m = {"f": {"kind": "baseline"}, "t1": tr, "t2": tr, "r1": rem("A", "t1"), "r2": rem("B", "t2"), "c1": ctl("cA")}
    assert CC.f0_jobs(m) == {"f": {"exp": {"A": ("r1", "t1"), "B": ("r2", "t2")}, "comp": {"cA": "c1"}}}
    with pytest.raises(CC.Fail):
        CC.f0_jobs({**m, "r3": rem("A", "t2")})
    with pytest.raises(CC.Fail):
        CC.f0_jobs({**m, "c2": ctl("cA")})
    with pytest.raises(CC.Fail):
        CC.f0_jobs({"r1": rem("A", "gone")})


def test_every_expansion_needs_exactly_one_matched_compact_control():
    import component_change as CC
    E = lambda h, lr=1e-3: {"hold": h, "route": "random_matched", "act": "relu", "lr": lr}                    # noqa
    C = lambda h, lr=1e-3: {"hold": h, "lr": lr}                                                              # noqa
    exp = {"A": E("none/none"), "B": E("shortcut/none"), "B_low": E("shortcut/none", 3e-4)}
    comp = {"cA": C("none/none"), "cB": C("shortcut/none"), "cB_low": C("shortcut/none", 3e-4)}
    assert CC.require_matched(exp, comp) == {"A": "cA", "B": "cB", "B_low": "cB_low"}
    with pytest.raises(CC.Fail, match="no single matched compact control.*B_low"):
        CC.require_matched(exp, {k: v for k, v in comp.items() if k != "cB_low"})        # missing
    with pytest.raises(CC.Fail, match="no single matched compact control.*A "):
        CC.require_matched(exp, {**comp, "cA2": C("none/none")})                         # ambiguous
    assert CC.role_of("extraction", "test_err", "expansion_minus_matched_compact", "B_routed_relu") == "primary"
    assert CC.role_of("extraction", "test_err", "expansion_minus_f0", "B_scfrozen") == "primary"
    for q, m, c, v in (("extraction", "val_err", "expansion_minus_f0", "B_routed_relu"),
                       ("probe", "test_err", "expansion_minus_f0", "B_routed_relu"),
                       ("extraction", "test_err", "expansion_minus_matched_compact_longer", "B_routed_relu"),
                       ("extraction", "test_err", "compact_minus_f0", "B_routed_relu"),
                       ("extraction", "test_disagreement", "expansion_minus_f0", "B_routed_relu"),
                       ("extraction", "test_err", "expansion_minus_f0", "A_routed_relu")):
        assert CC.role_of(q, m, c, v) == "exploratory", (q, m, c, v)


def test_two_experiments_that_share_a_cell_label_are_not_pooled():
    import component_change as CC
    import selective_reversal as SR
    exp = {"A": {"hold": "none/none", "route": "random_matched", "act": "relu", "lr": 1e-3}}
    comp = {"cA": {"hold": "none/none", "lr": 1e-3}}
    base = {"data": {"name": "shortcut", "n_train": 4096, "data_seed": 1}, "model": {"family": "mlp", "width": 64},
            "train": {"lr": 1e-3}, "seeds": {"optimizer": 0}}
    d0 = CC.design_id(base, "X25|cell", exp, comp)
    assert d0.startswith("X25|cell#")
    # the same experiment on another draw and seed
    assert CC.design_id({**base, "data": {**base["data"], "data_seed": 9}, "seeds": {"optimizer": 5}},
                        "X25|cell", exp, comp) == d0
    # another dataset, another network, another arm set: other experiments, although the label is the same
    others = [CC.design_id({**base, "data": {**base["data"], "n_train": 512}}, "X25|cell", exp, comp),
              CC.design_id({**base, "model": {"family": "mlp", "width": 32}}, "X25|cell", exp, comp),
              CC.design_id(base, "X25|cell", {**exp, "B": exp["A"]}, comp),
              CC.design_id(base, "X25|cell", exp, {"cA": {"hold": "none/none", "lr": 3e-4}})]
    assert len({d0, *others}) == 5
    for keys in (CC.STATE_KEYS, CC.EDIT_KEYS, CC.PROBE_KEYS, CC.CONTRAST_KEYS):
        assert keys[0] == "design_id" and "cell" in keys
    assert "representation_context" in CC.PROBE_KEYS and "representation_context" in CC.CONTRAST_KEYS
    assert "matching" in CC.CONTRAST_KEYS and "edit" in CC.CONTRAST_KEYS
    rows = [{**dict.fromkeys(CC.CONTRAST_KEYS, "x"), "design_id": d, "cell": "cell", "data_draw": dr,
             "optimizer_seed": 0, "value": val}
            for d, val in ((d0, 1.0), (others[0], 3.0)) for dr in (1, 2)]
    _, sm = SR.two_stage(rows, CC.CONTRAST_KEYS, "value")
    assert sorted((x["design_id"], x["mean_value"], x["n_unique_data_draws"]) for x in sm) == sorted(
        [(d0, 1.0, 2), (others[0], 3.0, 2)])


@pytest.mark.parametrize("wave, n_f0", [(25, 24), (26, 24)])
def test_one_design_identity_and_matched_controls_in_the_real_manifests(wave, n_f0):
    import component_change as CC
    import panel26_tables as PT
    from cop.orchestration.manifest import generate
    mcfg = {rid: e["cfg"] for rid, e in generate([wave], "full").entries.items()}
    exp, comp, _, fork_u = PT.design(mcfg)
    matched = CC.require_matched(exp, comp)
    assert set(matched) == set(exp) and fork_u == 4000
    jobs = CC.f0_jobs(mcfg)
    assert len(jobs) == n_f0 and all(set(j["exp"]) == set(exp) and set(j["comp"]) == set(comp) for j in jobs.values())
    ids = set()
    for bid, j in jobs.items():
        rid = next(iter(j["exp"].values()))[0]
        ids.add(CC.design_id(mcfg[bid], mcfg[rid]["design"]["contrast"], exp, comp))
    assert len(ids) == 1                                       # every f0 of the panel is one experiment
    prim = set(exp) & set(CC.PRIMARY_VARIANTS)
    assert prim == ({"B_scfrozen"} if wave == 25 else {"B_routed_relu"})
    assert matched[prim.pop()] == "compact_B"
    if wave == 26:                                             # the long controls are saved at 2U and at 4U
        for j in jobs.values():
            for cid in j["comp"].values():
                cc = mcfg[cid]["continue"]
                assert cc["save_eval_checkpoints"] and {4000, 8000} <= set(cc["eval_at"])


# ----------------------------------------------------------------------------- the tool on a miniature wave 26

@pytest.fixture(scope="module")
def w26(tmp_path_factory):
    from test_v53 import _panel26
    root = tmp_path_factory.mktemp("c26")
    p0, T, R, Cc, man = _panel26(root, arms=ARMS, compacts=COMPACTS)
    r = _tool(root, root / "change26", "--manifest", man, *_launcher_args(26, root / "probes"))
    return {"root": root, "p0": p0, "T": T, "R": R, "Cc": Cc, "man": man, "res": r,
            "t": lambda n: _rows(root / f"change26_{n}.csv"), "cov": read_json(root / "change26_coverage.json")}


class _Net:
    """independent access to the miniature's networks: f0's tensors, a state's own tensors and graph, features."""

    def __init__(self, w26):
        import coordinated_edits as CE
        import selective_reversal as SR
        from cop.data.registry import load_bundle
        from cop.graph.graph import GraphNet
        self.CE, self.GraphNet, self.w = CE, GraphNet, w26
        self.runs = w26["root"] / "runs"
        c = w26["T"]["A_routed_relu"]
        self.b = load_bundle(c["data"], None, device="cpu")
        self.P = self.b.partitions()
        f0 = GraphNet.from_checkpoint(torch.load(self.runs / run_id(c) / "ckpt" / "baseline_ref.pt",
                                                 weights_only=False)["model"])
        self.sd = {k: v.clone() for k, v in f0.state_dict().items()}
        self.L = SR.backbone_layers(f0)
        self.wk = [next(k for k in self.sd if k.startswith(f"mods.{Lk}.") and self.sd[k].dim() == 2) for Lk in self.L]
        self.bk = [next(k for k in self.sd if k.startswith(f"mods.{Lk}.") and self.sd[k].dim() == 1) for Lk in self.L]
        self.W0, self.b0 = self.sd[self.wk[0]], self.sd[self.bk[0]]
        self.sc = int(self.b.meta["feature_layout"]["shortcut"])

    def graph(self, name):
        if name == "f0":
            p = self.runs / run_id(self.w["T"]["A_routed_relu"]) / "ckpt" / "baseline_ref.pt"
        elif "@" in name:
            v, m = name.split("@")
            p = self.runs / run_id(self.w["Cc"][v]) / "ckpt" / f"at_{12 * int(m[:-1])}.pt"
        else:
            p = self.runs / run_id(self.w["T"][name]) / "ckpt" / "final.pt"
        return self.GraphNet.from_checkpoint(torch.load(p, weights_only=False)["model"]).eval()

    def first(self, name):
        st = self.graph(name).state_dict()
        return st[self.wk[0]].clone(), st[self.bk[0]].clone()

    def chain(self, tensors, part):
        """(layer-1 activations, penultimate activations, logits) of a plain chain, float64."""
        acts, z = self.CE.mlp_forward(tensors, self.P[part].X["x"], self.wk, self.bk)
        return acts[0], acts[-1], z

    def extracted(self, W, bias, part):
        return self.chain({**self.sd, self.wk[0]: W, self.bk[0]: bias}, part)

    def target(self, tg, part):
        return self.P[part].y.long() if tg == "label" else (self.P[part].X["x"][:, self.sc] > 0).long()

    def err(self, part, z):
        return float((z.argmax(-1) != self.P[part].y.long()).double().mean())


@pytest.fixture(scope="module")
def net(w26):
    return _Net(w26)


def test_tool_passes_with_the_launchers_options_and_complete_tables(w26):
    import component_change as CC
    r = w26["res"]
    assert r.returncode == 0, r.stdout[-2000:] + r.stderr[-3000:]
    cov = w26["cov"]
    assert cov["passed"] and cov["expected_f0"] == cov["analysed_f0"] == 1 and cov["failed"] == []
    assert cov["analysis_schema"] == CC.ANALYSIS_SCHEMA == "component_change/v57"
    assert cov["options"]["compact_multiples"] == [1, 2] and cov["options"]["save_probes"].endswith("probes")
    assert cov["probe_not_converged"] == [] and cov["output_membership_failures"] == []
    assert cov["design"]["matched_compact"] == {"A_routed_relu": "compact_A", "B_routed_relu": "compact_B",
                                                "B_all_affine": "compact_B"}
    assert cov["design"]["expansion_updates"] == 12 and len(cov["design_ids"]) == 1
    assert cov["probes_saved"] == N_PROBES and cov["unmatched_norm_edits"] == 0
    assert cov["definitions"]["prespecified_shrink"] == 0.0 and cov["definitions"]["equivalence_margin"] == 0.01
    for f in _files():
        p = w26["root"] / f"change26_{f}"
        assert p.exists() and p.read_text().strip() != "empty", f
    st = w26["t"]("states")
    names = [x["state"] for x in st]
    assert names == ["f0", "A_routed_relu", "B_all_affine", "B_routed_relu", "compact_A@1x", "compact_A@2x",
                     "compact_B@1x", "compact_B@2x"] and len(names) == N_STATES
    by = {x["state"]: x for x in st}
    assert [by[n]["updates_since_f0"] for n in names] == ["0", "12", "12", "12", "12", "24", "12", "24"]
    assert by["f0"]["kind"] == "f0" and by["B_routed_relu"]["kind"] == "expansion" and \
        by["compact_B@2x"]["kind"] == "compact" and by["compact_B@2x"]["variant"] == "compact_B"
    assert by["B_all_affine"]["route"] == "all_examples" and by["B_all_affine"]["act"] == "identity" and \
        by["B_all_affine"]["hold"] == "shortcut/none" and by["compact_A@1x"]["hold"] == "none/none"
    assert {x["design_id"] for x in st} == set(cov["design_ids"])
    f0 = by["f0"]
    assert float(f0["test_gain_vs_f0"]) == 0.0 and float(f0["layer_norm_ratio"]) == 1.0 and \
        float(f0["change_over_f0_norm"]) == 0.0 and float(f0["layer_cos_to_f0"]) == pytest.approx(1.0)
    for k in CC.NATIVE_METRICS:                                # f0's actual network is f0
        assert f0[f"native_{k}"] == f0[k], k
    for n in names[1:]:
        held = by[n]["hold"].startswith("shortcut")
        assert by[n]["shortcut_column_held"] == str(held), n
        assert (float(by[n]["shortcut_norm_ratio"]) == 1.0) == held and float(by[n]["change_over_f0_norm"]) > 0.0
        assert float(by[n]["test_gain_vs_f0"]) == pytest.approx(float(f0["test_err"]) - float(by[n]["test_err"]))
        assert by[n]["native_test_err"] != "" and by[n]["native_train_loss"] != ""
    ed = w26["t"]("edits")
    assert len(ed) == len(CC.SHRINK) + len(CC.EDITS) * (N_STATES - 1)
    assert len(w26["t"]("probes")) == N_PROBES


def test_states_and_edits_are_the_networks_they_name(w26, net):
    import component_change as CC
    st = {x["state"]: x for x in w26["t"]("states")}
    ed = {(x["state"], x["edit"]): x for x in w26["t"]("edits")}
    for name in ("f0", "B_routed_relu", "compact_A@2x"):
        W, bias = net.first(name)
        for part in ("test", "val", "val_indep"):
            assert float(st[name][f"{part}_err"]) == pytest.approx(net.err(part, net.extracted(W, bias, part)[2]),
                                                                    abs=1e-12), (name, part)
    # the native columns: a compact control's actual network is its own chain; an expansion's is its own graph
    own = net.graph("compact_A@2x").state_dict()
    assert float(st["compact_A@2x"]["native_test_err"]) == pytest.approx(net.err("test", net.chain(own, "test")[2]),
                                                                          abs=1e-12)
    g = net.graph("B_routed_relu")
    with torch.no_grad():
        z = g(net.P["test"].X).double()
    assert float(st["B_routed_relu"]["native_test_err"]) == pytest.approx(net.err("test", z), abs=1e-12)
    assert st["B_routed_relu"]["native_test_err"] != st["B_routed_relu"]["test_err"] or \
        st["B_routed_relu"]["native_train_loss"] != st["B_routed_relu"]["train_loss"]
    W, bias = net.first("B_routed_relu")
    W0, b0 = net.W0, net.b0
    blk = CC.blocks_of(net.b.meta["feature_layout"], W0.shape[1])
    for s in CC.SHRINK:                                        # f0 with its shortcut column shrunk
        Ws = W0.clone()
        Ws[:, net.sc] *= s
        row = ed[("f0", f"f0_shortcut_x{s:g}")]
        assert float(row["test_err"]) == pytest.approx(net.err("test", net.extracted(Ws, b0, "test")[2]), abs=1e-12)
        assert float(row["shortcut_scale"]) == s and "shortcut" in row["access"]
        assert row["control_family"] == "shortcut_shrink" and row["construction"] == "training_free"
        assert row["baseline"] == ("prespecified" if s == CC.PRESPECIFIED_SHRINK else "descriptive")
        assert row["probed"] == str(s == CC.PRESPECIFIED_SHRINK)
    mine = CC.edit_layers(W, bias, W0, b0, blk)
    assert set(mine) == set(CC.EDITS)
    for ename, (We, be, info) in mine.items():
        row = ed[("B_routed_relu", ename)]
        assert float(row["test_err"]) == pytest.approx(net.err("test", net.extracted(We, be, "test")[2]),
                                                       abs=1e-12), ename
        for k, v in info["scales"].items():
            assert float(row[f"scale_{k}"]) == pytest.approx(v, rel=1e-9)
        assert row["control_family"] == CC.EDITS[ename][0] and row["access"] == CC.EDITS[ename][1]
        assert row["construction"] == "needs_trained_state" and row["baseline"] == ""
        assert row["norm_match_exact"] == "True" and row["n_unmatched"] == "0"
        assert row["probed"] == str(ename in CC.PROBED_EDITS) and row["net"] == f"{ename}(B_routed_relu)"
    # the block scales are the state's own norm ratios
    row = ed[("B_routed_relu", "f0_at_state_block_norms")]
    for blk_ in ("causal", "shortcut", "other"):
        assert float(row[f"scale_{blk_}"]) == pytest.approx(float(st["B_routed_relu"][f"{blk_}_norm_ratio"]), rel=1e-9)
    assert float(ed[("B_routed_relu", "f0_at_state_layer_norm")]["scale_layer"]) == pytest.approx(
        float(st["B_routed_relu"]["layer_norm_ratio"]), rel=1e-9)
    # the bias controls are the two mixed networks
    for ename, (Wm, bm) in (("state_weights_f0_bias", (W, b0)), ("f0_weights_state_bias", (W0, bias))):
        assert float(ed[("B_routed_relu", ename)]["val_err"]) == pytest.approx(
            net.err("val", net.extracted(Wm, bm, "val")[2]), abs=1e-12)


def _fit(net, F, tg, fit, std, lam):
    """-> (mean, scale, w, b) of the probe refitted here on features F = {partition: activations}."""
    import component_change as CC
    Xf = F[fit]
    mu, sdv = CC.standardiser(Xf) if std else (torch.zeros_like(Xf[0]), torch.ones_like(Xf[0]))
    w, bb, _ = CC.fit_logistic((Xf - mu) / sdv, net.target(tg, fit), lam)
    return mu, sdv, w, bb


def _spec(feats, tg, fit, std, lam):
    return f"{feats}|{tg}|fit={fit}|{'standardised' if std else 'raw'}|lam={lam:g}"


def test_probes_are_fitted_on_the_named_features_targets_sets_and_contexts(w26, net):
    import component_change as CC
    pr = w26["t"]("probes")
    assert all(x["converged"] == "True" and float(x["grad_inf"]) <= CC.CONVERGED_TOL for x in pr)
    by = {(x["net"], x["representation_context"], x["spec"]): x for x in pr}
    assert len(by) == len(pr) and sorted(int(x["probe_id"]) for x in pr) == list(range(N_PROBES))
    width, n_in = (str(int(n)) for n in net.W0.shape)
    assert net.sd[net.wk[-2]].shape[0] == net.W0.shape[0]      # layer 1 and the penultimate layer have one width
    for x in pr:
        assert (x["val_indep_err"] == "") == (x["fit"] == "val_indep")
        assert x["test_err"] != "" and 0.0 <= float(x["test_err"]) <= 1.0 and 0.0 <= float(x["fit_err"]) <= 1.0
        assert x["access"] == CC.ACCESS[f"probe_fit_{x['fit']}"]
        assert x["n_features"] == (n_in if x["features"] == "input" else width)
    # which networks are probed, in which context, on which features
    kinds = {}
    for x in pr:
        kinds.setdefault((x["net_kind"], x["representation_context"]), set()).add(x["features"])
    assert kinds == {("input", "input"): {"input"}, ("state", "extracted"): {"layer1", "penultimate"},
                     ("state", "native"): {"penultimate"}, ("edit", "extracted"): {"layer1", "penultimate"}}
    states = {x["state"] for x in w26["t"]("states")}
    assert {x["net"] for x in pr if x["net_kind"] == "state"} == states
    assert {x["net"] for x in pr if x["net_kind"] == "edit"} == {"f0_shortcut_x0"} | {
        f"{e}({s})" for e in CC.PROBED_EDITS for s in states - {"f0"}}
    assert sum(x["net_kind"] == "input" for x in pr) == 16
    W, bias = net.first("B_routed_relu")
    # ---- extracted context: f0 with the state's first layer
    for feats, tg, fit, std, lam in (("layer1", "shortcut_sign", "val_indep", True, 1e-2),
                                     ("penultimate", "label", "train", False, 1e-4),
                                     ("layer1", "label", "val_indep", False, 1e-2)):
        F = {p: net.extracted(W, bias, p)[0 if feats == "layer1" else 1] for p in ("train", "val_indep", "test", "val")}
        mu, sdv, w, bb = _fit(net, F, tg, fit, std, lam)
        row = by[("B_routed_relu", "extracted", _spec(feats, tg, fit, std, lam))]
        for part in ("test", "val"):
            assert float(row[f"{part}_err"]) == pytest.approx(
                CC.probe_error((F[part] - mu) / sdv, net.target(tg, part), w, bb), abs=1e-12), (feats, tg, fit, part)
        assert float(row["fit_err"]) == pytest.approx(
            CC.probe_error((F[fit] - mu) / sdv, net.target(tg, fit), w, bb), abs=1e-12)
    # ---- native context, a compact control: the penultimate activations of ITS OWN chain
    own = net.graph("compact_A@2x").state_dict()
    Fn = {p: net.chain(own, p)[1] for p in ("train", "val_indep", "test", "val")}
    Wc, bc = net.first("compact_A@2x")
    Fe = {p: net.extracted(Wc, bc, p)[1] for p in ("train", "val_indep", "test", "val")}
    assert not torch.allclose(Fn["test"], Fe["test"])          # its later layers moved: the contexts differ
    for F, ctx in ((Fn, "native"), (Fe, "extracted")):
        mu, sdv, w, bb = _fit(net, F, "label", "train", True, 1e-2)
        row = by[("compact_A@2x", ctx, _spec("penultimate", "label", "train", True, 1e-2))]
        assert float(row["test_err"]) == pytest.approx(
            CC.probe_error((F["test"] - mu) / sdv, net.target("label", "test"), w, bb), abs=1e-12), ctx
    a = by[("compact_A@2x", "native", _spec("penultimate", "label", "train", False, 1e-2))]
    e = by[("compact_A@2x", "extracted", _spec("penultimate", "label", "train", False, 1e-2))]
    assert a["fit_loss"] != e["fit_loss"]                      # two measurements, kept apart
    # ---- native context, an expansion: what its own output layer reads, with the additions in place
    g = net.graph("B_routed_relu")
    node = CC.head_input_node(g, net.L[-1])
    Fx, zx = {}, {}
    with torch.no_grad():
        for p in ("train", "val_indep", "test", "val"):
            zx[p], nv = g.forward(net.P[p].X, return_nodes=[node])
            Fx[p] = nv[node].double()
    gs = g.state_dict()
    assert torch.allclose(Fx["test"] @ gs[net.wk[-1]].double().T + gs[net.bk[-1]].double(), zx["test"].double(),
                          atol=1e-4)
    assert not torch.allclose(Fx["test"], net.extracted(W, bias, "test")[1], atol=1e-4)
    mu, sdv, w, bb = _fit(net, Fx, "label", "val_indep", True, 1e-4)
    row = by[("B_routed_relu", "native", _spec("penultimate", "label", "val_indep", True, 1e-4))]
    assert float(row["test_err"]) == pytest.approx(
        CC.probe_error((Fx["test"] - mu) / sdv, net.target("label", "test"), w, bb), abs=1e-12)
    # f0: the two contexts are one network
    for sp in (_spec("penultimate", "label", "train", True, 1e-2), _spec("penultimate", "shortcut_sign", "train",
                                                                          False, 1e-4)):
        assert float(by[("f0", "native", sp)]["test_err"]) == pytest.approx(float(by[("f0", "extracted", sp)]
                                                                                   ["test_err"]), abs=1e-12)
    # ---- the probed edits: f0 at the state's block norms, the state at f0's block norms, f0 without its shortcut
    blk = CC.blocks_of(net.b.meta["feature_layout"], net.W0.shape[1])
    mine = CC.edit_layers(W, bias, net.W0, net.b0, blk)
    Wx = net.W0.clone()
    Wx[:, net.sc] = 0.0
    for nm, (We, be) in ((f"f0_at_state_block_norms(B_routed_relu)", mine["f0_at_state_block_norms"][:2]),
                         (f"state_at_f0_block_norms(B_routed_relu)", mine["state_at_f0_block_norms"][:2]),
                         ("f0_shortcut_x0", (Wx, net.b0))):
        F = {p: net.extracted(We, be, p)[0] for p in ("train", "val_indep", "test", "val")}
        mu, sdv, w, bb = _fit(net, F, "label", "val_indep", True, 1e-2)
        row = by[(nm, "extracted", _spec("layer1", "label", "val_indep", True, 1e-2))]
        assert float(row["test_err"]) == pytest.approx(
            CC.probe_error((F["test"] - mu) / sdv, net.target("label", "test"), w, bb), abs=1e-12), nm
        assert row["net_kind"] == "edit" and row["edit"] == nm.split("(")[0]
    # without its shortcut column, f0's first layer cannot carry the shortcut's sign beyond what the label gives
    row = by[("input", "input", "input|shortcut_sign|fit=train|standardised|lam=0.0001")]
    assert float(row["test_err"]) <= 0.05                      # read directly from the raw input
    # the summaries keep the contexts apart
    sm = _rows(w26["root"] / "change26_probes_summary.csv")
    got = {(x["net"], x["representation_context"]) for x in sm}
    assert ("compact_A@2x", "native") in got and ("compact_A@2x", "extracted") in got
    one = [x for x in sm if x["net"] == "compact_A@2x" and x["metric"] == "test_err"
           and x["spec"] == _spec("penultimate", "label", "train", True, 1e-2)]
    assert sorted(x["representation_context"] for x in one) == ["extracted", "native"]


def test_contrasts_are_the_named_differences(w26, net):
    import component_change as CC
    st = {x["state"]: x for x in w26["t"]("states")}
    ed = {x["net"]: x for x in w26["t"]("edits")}
    pr = {(x["net"], x["representation_context"], x["spec"]): x for x in w26["t"]("probes")}
    co = w26["t"]("contrasts")
    seen = set()
    for r in co:
        seen.add((r["comparison"], r["first"], r["second"], r["matching"]))
        if r["metric"].endswith("_disagreement"):
            assert r["first_value"] == "" and 0.0 <= float(r["value"]) <= 1.0 and r["role"] == "exploratory"
            assert r["quantity"] in ("extraction", "edit")
            continue
        assert float(r["value"]) == pytest.approx(float(r["first_value"]) - float(r["second_value"]), abs=1e-15)
        ctx, m = r["representation_context"], r["metric"]
        if r["quantity"] == "extraction":
            a, b_ = st[r["first"]][m], st[r["second"]][m]
            assert ctx == "extracted"
        elif r["quantity"] == "native":
            a, b_ = st[r["first"]][f"native_{m}"], st[r["second"]][f"native_{m}"]
            assert ctx == "native"
        elif r["quantity"] == "probe":
            a, b_ = pr[(r["first"], ctx, r["spec"])][m], pr[(r["second"], ctx, r["spec"])][m]
            assert ctx in CC.CONTEXTS and (ctx == "extracted" or r["spec"].startswith("penultimate|"))
        elif r["quantity"] == "edit":
            twin = r["comparison"] == "f0_bias_minus_state_bias"
            a, b_ = ed[r["first"]][m], (ed if twin else st)[r["second"]][m]
            assert r["edit"] == r["spec"] == ed[r["first"]]["edit"] and ctx == "extracted"
            if twin:                                           # the same state, the same weights, the other bias
                assert ed[r["second"]]["edit"] == CC.F0_BIAS_TWINS[r["edit"]]
                assert ed[r["second"]]["state"] == ed[r["first"]]["state"]
        else:
            assert r["quantity"] == "edit_probe" and ctx == "extracted"
            a, b_ = pr[(r["first"], ctx, r["spec"])][m], pr[(r["second"], ctx, r["spec"])][m]
            assert r["edit"] == ed[r["first"]]["edit"] and ed[r["first"]]["probed"] == "True"
        assert float(r["first_value"]) == pytest.approx(float(a), abs=1e-15)
        assert float(r["second_value"]) == pytest.approx(float(b_), abs=1e-15)
        if r["comparison"] == "edit_minus_state":
            assert r["second"] == ed[r["first"]]["state"] != "f0"
        if r["comparison"] == "edit_minus_f0":
            assert r["second"] == "f0"
    # the matched compact control at the same update, and trained twice as long: two separately named comparisons
    assert ("expansion_minus_matched_compact", "B_routed_relu", "compact_B@1x", "same_updates") in seen
    assert ("expansion_minus_matched_compact", "B_all_affine", "compact_B@1x", "same_updates") in seen
    assert ("expansion_minus_matched_compact", "A_routed_relu", "compact_A@1x", "same_updates") in seen
    assert ("expansion_minus_matched_compact_longer", "B_routed_relu", "compact_B@2x", "compact_at_2x_updates") in seen
    assert ("expansion_minus_matched_compact_longer", "A_routed_relu", "compact_A@2x", "compact_at_2x_updates") in seen
    assert not any(c == "expansion_minus_matched_compact" and s.endswith("@2x") for c, _, s, _ in seen)
    assert not any(c == "expansion_minus_matched_compact_longer" and s.endswith("@1x") for c, _, s, _ in seen)
    assert ("expansion_minus_f0", "A_routed_relu", "f0", "") in seen and \
        ("compact_minus_f0", "compact_A@2x", "f0", "") in seen
    assert ("f0_shortcut_shrunk_minus_state", "f0_shortcut_x0", "B_routed_relu", "") in seen
    assert ("edit_minus_f0", "f0_shortcut_x0.5", "f0", "") in seen
    assert ("edit_minus_state", "state_weights_f0_bias(B_routed_relu)", "B_routed_relu", "") in seen
    assert ("edit_minus_f0", "f0_weights_state_bias(compact_A@1x)", "f0", "") in seen
    n_state, n_err = N_STATES - 1, len(CC.ERR_METRICS)
    per_state = 2 * len(CC.EDITS) + len(CC.F0_BIAS_TWINS) + len(CC.SHRINK)
    errs = [r for r in co if r["quantity"] == "edit" and not r["metric"].endswith("_disagreement")]
    assert len(errs) == (len(CC.SHRINK) + n_state * per_state) * n_err
    diss = [r for r in co if r["quantity"] == "edit" and r["metric"].endswith("_disagreement")]
    assert len(diss) == (len(CC.SHRINK) + n_state * per_state) * len(CC.DISAGREE_PARTS)
    assert ("f0_bias_minus_state_bias", "state_at_f0_block_row_norms_f0_bias(A_routed_relu)",
            "state_at_f0_block_row_norms(A_routed_relu)", "") in seen
    # probe contrasts exist in both contexts, and for the probed edits against their state and against f0
    q = lambda **kw: [r for r in co if all(r[k] == v for k, v in kw.items())]                      # noqa: E731
    assert len(q(quantity="probe", first="B_routed_relu", second="compact_B@1x",
                 representation_context="extracted")) == 32 * 2
    assert len(q(quantity="probe", first="B_routed_relu", second="compact_B@2x",
                 representation_context="native")) == 16 * 2
    assert len(q(quantity="edit_probe", first="f0_at_state_block_norms(B_routed_relu)", second="B_routed_relu",
                 comparison="edit_minus_state")) == 32 * 2
    assert len(q(quantity="edit_probe", first="state_at_f0_block_norms(B_routed_relu)", second="f0",
                 comparison="edit_minus_f0")) == 32 * 2
    assert len(q(quantity="edit_probe", first="f0_shortcut_x0", second="B_routed_relu")) == 32 * 2
    assert not q(quantity="edit_probe", first="f0_shortcut_x0.5")
    # the row-block controls and the f0-bias controls are probed too, and each f0-bias control meets its twin
    assert len(q(quantity="edit_probe", first="state_at_f0_block_row_norms(A_routed_relu)", second="f0",
                 comparison="edit_minus_f0")) == 32 * 2
    assert len(q(quantity="edit_probe", first="state_at_f0_block_norms_f0_bias(A_routed_relu)",
                 second="state_at_f0_block_norms(A_routed_relu)", comparison="f0_bias_minus_state_bias")) == 32 * 2
    assert len(q(quantity="edit", first="state_at_f0_block_norms_f0_bias(A_routed_relu)",
                 second="state_at_f0_block_norms(A_routed_relu)", metric="test_err")) == 1
    # decision disagreement, recomputed: the state's first layer in f0 against f0, and an edit against its state
    W, bias = net.first("B_routed_relu")
    zs, z0 = net.extracted(W, bias, "test")[2], net.extracted(net.W0, net.b0, "test")[2]
    d = float((zs.argmax(-1) != z0.argmax(-1)).double().mean())
    row = q(quantity="extraction", first="B_routed_relu", second="f0", metric="test_disagreement")
    assert len(row) == 1 and float(row[0]["value"]) == pytest.approx(d, abs=1e-12)
    blk = CC.blocks_of(net.b.meta["feature_layout"], net.W0.shape[1])
    We, be, _ = CC.edit_layers(W, bias, net.W0, net.b0, blk)["f0_at_state_block_norms"]
    ze = net.extracted(We, be, "test")[2]
    row = q(quantity="edit", first="f0_at_state_block_norms(B_routed_relu)", second="B_routed_relu",
            metric="test_disagreement")
    assert len(row) == 1 and float(row[0]["value"]) == pytest.approx(
        float((ze.argmax(-1) != zs.argmax(-1)).double().mean()), abs=1e-12)
    # disagreement is at least the error difference: equal error rates do not mean equal predictions
    er = q(quantity="edit", first="f0_at_state_block_norms(B_routed_relu)", second="B_routed_relu",
           metric="test_err")[0]
    assert float(row[0]["value"]) >= abs(float(er["value"])) - 1e-12
    # the two primary contrasts: the arm that repeats wave 25's B arm, against f0 and its matched compact control
    prim = [r for r in co if r["role"] == "primary"]
    assert sorted((r["comparison"], r["first"], r["second"], r["quantity"], r["metric"]) for r in prim) == [
        ("expansion_minus_f0", "B_routed_relu", "f0", "extraction", "test_err"),
        ("expansion_minus_matched_compact", "B_routed_relu", "compact_B@1x", "extraction", "test_err")]
    assert {r["role"] for r in co} == {"primary", "exploratory"} and w26["cov"]["primary"]["rows"] == 2
    sm = _rows(w26["root"] / "change26_contrasts_summary.csv")
    assert sm and set(CC.CONTRAST_KEYS) | {"mean_value", "equivalence_margin", "ci95_within_margin"} <= set(sm[0])
    assert sum(x["role"] == "primary" for x in sm) == 2
    for x in sm:                                               # the margin is declared for error differences only
        assert (x["equivalence_margin"] == "0.01") == x["metric"].endswith("_err"), x["metric"]
        assert x["ci95_within_margin"] == ""                   # one draw: no interval, so no equivalence statement


def test_saved_probes_reproduce_the_tables_from_the_checkpoints(w26, net):
    """every fitted probe is saved; reloaded coefficients applied to features rebuilt here from the checkpoints give
    the saved decisions and the table's errors."""
    import component_change as CC
    bid = run_id(w26["p0"])
    idx = read_json(w26["root"] / "probes" / f"{bid}.json")
    z = np.load(w26["root"] / "probes" / f"{bid}.npz")
    assert idx["analysis_schema"] == CC.ANALYSIS_SCHEMA and idx["f0"] == bid and len(idx["probes"]) == N_PROBES
    assert idx["design_id"] == w26["cov"]["design_ids"][0]
    hs = net.b.hashes()
    assert idx["split_hashes"] == {p: hs[p] for p in idx["split_hashes"]} and "test" in idx["split_hashes"]
    assert idx["n_examples"]["test"] == len(net.P["test"])
    assert {"f0", "B_routed_relu", "compact_A@2x", "f0_shortcut_x0",
            "f0_at_state_block_norms(B_routed_relu)"} <= set(idx["nets"])
    assert all(v["first_layer_hash"] for v in idx["nets"].values())
    assert idx["nets"]["B_routed_relu"] == {"run_id": run_id(w26["T"]["B_routed_relu"]), "stage": "final",
                                            "first_layer_hash": idx["nets"]["B_routed_relu"]["first_layer_hash"]}
    assert idx["nets"]["compact_A@2x"]["stage"] == "at_24"
    tab = {int(x["probe_id"]): x for x in w26["t"]("probes")}
    W, bias = net.first("B_routed_relu")
    own = net.graph("compact_A@2x").state_dict()
    Wx = net.W0.clone()
    Wx[:, net.sc] = 0.0
    feats = {("B_routed_relu", "extracted", "layer1"): lambda p: net.extracted(W, bias, p)[0],
             ("B_routed_relu", "extracted", "penultimate"): lambda p: net.extracted(W, bias, p)[1],
             ("compact_A@2x", "native", "penultimate"): lambda p: net.chain(own, p)[1],
             ("f0_shortcut_x0", "extracted", "layer1"): lambda p: net.extracted(Wx, net.b0, p)[0],
             ("input", "input", "input"): lambda p: net.P[p].X["x"].double()}
    checked = 0
    for x in idx["probes"]:
        k = (x["net"], x["representation_context"], x["features"])
        row = tab[x["probe_id"]]
        assert (row["net"], row["representation_context"], row["spec"]) == (x["net"], x["representation_context"],
                                                                             x["spec"])
        assert set(x["pred_rows"]) == {p for p in CC.PROBE_EVAL if p != x["fit"]}
        if k not in feats:
            continue
        d, i = x["n_features"], x["coef_row"]
        w, mu = torch.from_numpy(z[f"coef_d{d}"][i]), torch.from_numpy(z[f"mean_d{d}"][i])
        sd, b_ = torch.from_numpy(z[f"scale_d{d}"][i]), float(z[f"intercept_d{d}"][i])
        assert bool(torch.isfinite(w).all()) and (x["standardised"] or (float(mu.abs().max()) == 0.0 and
                                                                         float((sd - 1).abs().max()) == 0.0))
        for p, r_ in x["pred_rows"].items():
            F = feats[k](p)
            pred = ((F - mu) / sd) @ w + b_ > 0
            saved = np.unpackbits(z[f"pred_{p}"][r_])[:F.shape[0]].astype(bool)
            assert np.array_equal(pred.numpy(), saved), (k, x["spec"], p)
            assert float((pred.long() != net.target(x["target"], p)).double().mean()) == pytest.approx(
                float(row[f"{p}_err"]), abs=1e-12)
        checked += 1
    assert checked == 5 * 16                                   # every probe of the five chosen feature sets
    # the reload check of the tool itself
    st = CC.ProbeStore()
    y = np.array([0, 1, 1, 0, 1, 0, 1, 1, 0], dtype=np.int64)
    pred = torch.tensor([0, 1, 0, 0, 1, 0, 1, 1, 1], dtype=torch.bool)
    pid = st.add({"net": "n", "target": "label"}, torch.tensor([1.0, 2.0], dtype=torch.float64), 0.5,
                 torch.zeros(2, dtype=torch.float64), torch.ones(2, dtype=torch.float64), {"test": pred})
    npz, jsn = st.save(w26["root"] / "store", "one", {"f0": "x"})
    good = {pid: {"test_err": 2 / 9}}
    assert CC.reload_check(npz, jsn, st, {"test": {"label": y}}, good) == 1
    with pytest.raises(CC.Fail, match="saved decisions give error"):
        CC.reload_check(npz, jsn, st, {"test": {"label": y}}, {pid: {"test_err": 1 / 9}})
    st.arr["coef_d2"][0] = st.arr["coef_d2"][0] + 1.0          # the file no longer holds what was fitted
    with pytest.raises(CC.Fail, match="differs from the fitted one"):
        CC.reload_check(npz, jsn, st, {"test": {"label": y}}, good)


def test_a_missing_compact_state_or_a_bad_option_fails(w26):
    root = w26["root"]
    r = _tool(root, root / "bad", "--manifest", w26["man"], "--strict", "--compact-multiples", "1,3")
    assert r.returncode == 1 and "no saved state at update 36" in r.stderr
    cov = read_json(root / "bad_coverage.json")
    assert not cov["passed"] and cov["analysed_f0"] == 0 and _rows(root / "bad_states.csv") == []
    assert _tool(root, root / "x", "--manifest", w26["man"], "--compact-multiples", "2").returncode == 2
    assert _tool(root, root / "x", "--manifest", w26["man"], "--compact-multiples", "a").returncode == 2


def test_a_compact_checkpoint_that_records_another_update_fails(w26, tmp_path):
    """the file name and the lineage say at_12; the checkpoint's own record says 9: refused."""
    shutil.copytree(w26["root"] / "runs", tmp_path / "runs")
    p = tmp_path / "runs" / run_id(w26["Cc"]["compact_B"]) / "ckpt" / "at_12.pt"
    ck = torch.load(p, weights_only=False)
    assert ck["extra"]["update"] == 12 and ck.get("trainer") is None
    ck["extra"]["update"] = 9
    torch.save(ck, p)
    r = _tool(tmp_path, tmp_path / "age", "--manifest", w26["man"], "--strict", "--compact-multiples", "1,2")
    assert r.returncode == 1 and "the checkpoint at_12 records update 9, not 12" in r.stderr
    assert not read_json(tmp_path / "age_coverage.json")["passed"]
    ck["extra"].pop("update")                                  # and one with no record at all
    torch.save(ck, p)
    r = _tool(tmp_path, tmp_path / "age2", "--manifest", w26["man"], "--strict")
    assert r.returncode == 1 and "records update None, not 12" in r.stderr


def test_an_expansion_without_its_matched_compact_control_fails(w26, tmp_path):
    """compact_A removed from the manifest: A_routed_relu has no matched control, and the run stops instead of
    leaving that comparison out."""
    drop = run_id(w26["Cc"]["compact_A"])
    man = tmp_path / "m.jsonl"
    lines = [ln for ln in Path(w26["man"]).read_text().splitlines() if ln.strip()]
    kept = [ln for ln in lines if json.loads(ln)["run_id"] != drop]
    assert len(kept) == len(lines) - 1
    man.write_text("\n".join(kept) + "\n")
    r = _tool(w26["root"], tmp_path / "nomatch", "--manifest", man, "--strict")
    assert r.returncode == 1 and "no single matched compact control" in r.stderr and "A_routed_relu" in r.stderr
    cov = read_json(tmp_path / "nomatch_coverage.json")
    assert not cov["passed"] and cov["analysed_f0"] == 0 and cov["failed"][0]["f0"] is None
    assert _rows(tmp_path / "nomatch_contrasts.csv") == []


# ----------------------------------------------------------------------------- and on a miniature wave 25

def test_tool_on_a_miniature_wave_25(tmp_path):
    import component_change as CC
    from test_v45 import _panel
    p0, T, R, Cc, man = _panel(tmp_path)
    r = _tool(tmp_path, tmp_path / "change25", "--manifest", man, *_launcher_args(25, tmp_path / "probes"))
    assert r.returncode == 0, r.stdout[-2000:] + r.stderr[-3000:]
    cov = read_json(tmp_path / "change25_coverage.json")
    assert cov["passed"] and cov["options"]["compact_multiples"] == [1] and len(cov["design_ids"]) == 1
    assert cov["design"]["matched_compact"] == {"A_free": "compact_A", "B_scfrozen": "compact_B",
                                                "C_dsfrozen": "compact_C", "D_bothfrozen": "compact_D"}
    st = {x["state"]: x for x in _rows(tmp_path / "change25_states.csv")}
    assert set(st) == {"f0", *cov["design"]["expansions"], *[f"{c}@1x" for c in cov["design"]["compact_controls"]]}
    n = len(st)
    assert n == 9 and cov["probes_saved"] == 16 + n * 32 + n * 16 + (N_PROBED * (n - 1) + 1) * 32
    assert len(_rows(tmp_path / "change25_edits.csv")) == len(CC.SHRINK) + len(CC.EDITS) * (n - 1)
    assert (tmp_path / "probes" / f"{run_id(p0)}.npz").exists()
    for s in ("B_scfrozen", "D_bothfrozen", "compact_B@1x", "compact_D@1x"):
        assert st[s]["shortcut_column_held"] == "True" and float(st[s]["shortcut_norm_ratio"]) == 1.0
    for s in ("A_free", "C_dsfrozen", "compact_A@1x"):
        assert st[s]["shortcut_column_held"] == "False"
    # with the later layers held at f0 (C and D), a compact control's actual network IS f0 with its first layer
    for s in ("compact_C@1x", "compact_D@1x"):
        assert float(st[s]["native_test_err"]) == pytest.approx(float(st[s]["test_err"]), abs=1e-12)
    for f in _files():
        assert (tmp_path / f"change25_{f}").read_text().strip() != "empty", f
    co = _rows(tmp_path / "change25_contrasts.csv")
    assert not any(r["comparison"].endswith("_longer") for r in co)          # wave 25 has no longer control
    # wave 25's primary contrasts (v46's P1), recomputed: B's extraction against f0 and against compact_B at 2U
    prim = [r for r in co if r["role"] == "primary"]
    assert sorted((r["comparison"], r["first"], r["second"]) for r in prim) == [
        ("expansion_minus_f0", "B_scfrozen", "f0"), ("expansion_minus_matched_compact", "B_scfrozen", "compact_B@1x")]
    assert all(r["quantity"] == "extraction" and r["metric"] == "test_err" for r in prim)
    assert float(prim[0]["value"]) == pytest.approx(float(st["B_scfrozen"]["test_err"]) - float(st["f0"]["test_err"]))
