"""v56: the layer and age course (audit_v5/tools/layer_course.py) and the update diagnostics
(audit_v5/tools/routing_updates.py) on a real miniature wave 26 whose expansions save two consecutive updates, through
the launcher's own command lines.  The course's probes are refitted here from the checkpoints in every context; the
reconstructed AdamW step is checked against a real optimizer and against the consecutive saved states; the routed
gradient is rederived from per-example sums."""
from __future__ import annotations

import csv
import math
import os
import re
import shlex
import subprocess
import sys
from pathlib import Path

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "audit_v5" / "tools"))
from cop.config import run_id  # noqa: E402
from cop.utils import read_json  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
LAUNCHER = ROOT / "scripts/56_v56_backbone_change.sh"
ARMS = ["A_routed_relu", "B_routed_relu", "B_all_affine"]
COMPACTS = ["compact_A", "compact_B"]
SNAPS = [3, 4, 9]                                 # two consecutive saved updates (3 and 4): the step between them
EXP_AGES = {"post_insert_r1": 0, "snap_3": 3, "snap_4": 4, "post_insert_r2": 6, "snap_9": 9, "final": 12}
COMP_AGES = [3, 6, 9, 12, 15, 18, 21, 24]


def _rows(path):
    t = Path(path).read_text()
    return [] if t.strip() == "empty" else list(csv.DictReader(open(path)))


def _tool(name, *args):
    return subprocess.run([sys.executable, str(ROOT / "audit_v5/tools" / name), *map(str, args)], capture_output=True,
                          text=True, env=dict(os.environ))


def _launcher_args(step: str, wave: int) -> list:
    """the launcher's own options for one tool (everything after --manifest's value), for one wave."""
    src = LAUNCHER.read_text()
    cmd = re.search(rf'^\s+step "{step}\$w" (python .*?)\n(?!\s+--)', src, re.M | re.S).group(1).replace("\\\n", " ")
    toks = shlex.split(cmd)
    mult = re.search(rf'^MULT\[{wave}\]="([^"]+)"', src, re.M).group(1)
    out = [mult if t == "${MULT[$w]}" else t for t in toks[toks.index("--manifest") + 2:]]
    assert "--strict" in out and not any("$" in t for t in out), out
    return out


def _files(name: str) -> list:
    return re.search(rf'^{name}_FILES="([^"]+)"', LAUNCHER.read_text(), re.M).group(1).split(",")


@pytest.fixture(scope="module")
def w26(tmp_path_factory):
    import test_v53 as V
    root = tmp_path_factory.mktemp("k26")
    old = V.SNAPS
    V.SNAPS = list(SNAPS)
    try:
        p0, T, R, Cc, man = V._panel26(root, arms=ARMS, compacts=COMPACTS)
    finally:
        V.SNAPS = old
    rc = _tool("layer_course.py", root, root / "course26", "--manifest", man, *_launcher_args("course", 26))
    rr = _tool("routing_updates.py", root, root / "routing26", "--manifest", man, *_launcher_args("routing", 26))
    return {"root": root, "p0": p0, "T": T, "R": R, "Cc": Cc, "man": man, "course": rc, "routing": rr,
            "c": lambda n: _rows(root / f"course26_{n}.csv"), "r": lambda n: _rows(root / f"routing26_{n}.csv")}


@pytest.fixture(scope="module")
def net(w26):
    from test_v56 import _Net
    return _Net(w26)


def _graph(net, variant, stage):
    d = net.w["T"][variant] if variant in net.w["T"] else net.w["Cc"][variant]
    ck = torch.load(net.runs / run_id(d) / "ckpt" / f"{stage}.pt", weights_only=False)
    return net.GraphNet.from_checkpoint(ck["model"]).eval(), ck


def _probe(net, F, tg, lam):
    """component_change's probe, refitted here: fitted on val_indep, standardised -> test error."""
    import component_change as CC
    mu, sd = CC.standardiser(F["val_indep"])
    w, b, _ = CC.fit_logistic((F["val_indep"] - mu) / sd, net.target(tg, "val_indep"), lam)
    return CC.probe_error((F["test"] - mu) / sd, net.target(tg, "test"), w, b)


# ----------------------------------------------------------------------------- the layer and age course

def test_course_passes_and_walks_every_saved_state(w26):
    import layer_course as LC
    r = w26["course"]
    assert r.returncode == 0, r.stdout[-2000:] + r.stderr[-3000:]
    cov = read_json(w26["root"] / "course26_coverage.json")
    assert cov["passed"] and cov["analysis_schema"] == LC.ANALYSIS_SCHEMA == "layer_course/v56"
    assert cov["expected_f0"] == cov["analysed_f0"] == 1 and cov["probe_not_converged"] == []
    assert cov["options"]["compact_multiples"] == [1, 2] and len(cov["design_ids"]) == 1
    for f in _files("COURSE"):
        assert (w26["root"] / f"course26_{f}").read_text().strip() != "empty", f
    st = w26["c"]("states")
    got = {(x["variant"], x["stage"]): int(x["updates_since_f0"]) for x in st}
    want = {("f0", "f0"): 0}
    want.update({(v, s): u for v in ARMS for s, u in EXP_AGES.items()})
    want.update({(c, f"at_{u}"): u for c in COMPACTS for u in COMP_AGES})
    assert got == want and len(st) == len(want) == cov["n_states"]
    by = {(x["variant"], x["stage"]): x for x in st}
    assert by[("f0", "f0")]["has_merge"] == "False" and by[("f0", "f0")]["folded_test_err"] == ""
    assert by[("f0", "f0")]["native_test_err"] == by[("f0", "f0")]["extracted_test_err"]
    for v in ARMS:
        for s in EXP_AGES:
            assert by[(v, s)]["has_merge"] == "True" and by[(v, s)]["folded_test_err"] != "", (v, s)
        # right after an insertion the additions add nothing: the actual network is f0's function
        assert by[(v, "post_insert_r1")]["native_test_err"] == by[("f0", "f0")]["native_test_err"]
        assert by[(v, "post_insert_r1")]["fold_fit_r2"] == ""
    # affine additions fold exactly; the fit of ReLU additions is not exact
    assert float(by[("B_all_affine", "final")]["fold_fit_r2"]) == pytest.approx(1.0, abs=1e-8)
    assert float(by[("B_all_affine", "final")]["folded_test_err"]) == pytest.approx(
        float(by[("B_all_affine", "final")]["native_test_err"]), abs=1e-12)
    for c in COMPACTS:
        assert by[(c, "at_24")]["has_merge"] == "False" and by[(c, "at_24")]["folded_test_err"] == ""
    # which layers are probed in which context (4 hidden layers; the additions merge after layer 2)
    pr = w26["c"]("probes")
    feats = {}
    for x in pr:
        feats.setdefault((x["kind"], x["representation_context"]), set()).add(x["feature"])
    L4 = {"layer1", "layer2", "layer3", "layer4"}
    assert feats == {("f0", "extracted"): L4, ("f0", "native"): L4, ("compact", "extracted"): L4,
                     ("compact", "native"): L4, ("expansion", "extracted"): L4,
                     ("expansion", "native"): L4 | {"layer2_post_merge"}, ("expansion", "folded"): {"layer3", "layer4"}}
    per = len(LC.TARGETS) * len(LC.LAMBDAS)
    n_exp, n_comp = len(ARMS) * len(EXP_AGES), len(COMPACTS) * len(COMP_AGES)
    assert len(pr) == per * (8 + n_exp * (4 + 5 + 2) + n_comp * 8) == cov["n_probe_rows"]
    assert all(x["converged"] == "True" for x in pr)
    shared = [x for x in pr if x["shared_with"]]
    assert {(x["representation_context"], x["feature"], x["shared_with"]) for x in shared} == {
        ("native", "layer1", "extracted")}


def test_course_probes_are_the_named_layers_in_the_named_context(w26, net):
    import component_change as CC
    import coordinated_edits as CE
    import f0_panel as FP
    import layer_course as LC
    pr = {(x["variant"], x["stage"], x["representation_context"], x["spec"]): x for x in w26["c"]("probes")}
    parts = ("val_indep", "test")

    def row(v, s, ctx, feature, tg, lam):
        return float(pr[(v, s, ctx, LC.spec_of(feature, tg, lam))]["test_err"])
    for v, stage in (("B_routed_relu", "snap_9"), ("A_routed_relu", "final")):
        g, _ = _graph(net, v, stage)
        sd = g.state_dict()
        sites = FP.layer_sites(g, net.L)
        assert set(sites) == {"layer1", "layer2", "layer2_post_merge", "layer3", "layer4"}
        nat = {}
        with torch.no_grad():
            for p in parts:
                _, nv = g.forward(net.P[p].X, return_nodes=list(sites.values()))
                nat[p] = {n: nv[i].double() for n, i in sites.items()}
        # the node names mean what they say: layer 3 reads the post-merge value; the head reads layer 4
        w3, b3 = sd[net.wk[2]].double(), sd[net.bk[2]].double()
        assert torch.allclose((nat["test"]["layer2_post_merge"] @ w3.T + b3).clamp_min(0), nat["test"]["layer3"],
                              atol=1e-4)
        assert not torch.allclose(nat["test"]["layer2_post_merge"], nat["test"]["layer2"], atol=1e-5)
        w1, b1 = sd[net.wk[0]].double(), sd[net.bk[0]].double()
        assert torch.allclose((net.P["test"].X["x"].double() @ w1.T + b1).clamp_min(0), nat["test"]["layer1"],
                              atol=1e-4)
        for feature, tg, lam in (("layer2", "label", 1e-2), ("layer2_post_merge", "label", 1e-2),
                                 ("layer3", "shortcut_sign", 1e-4), ("layer4", "label", 1e-4)):
            F = {p: nat[p][feature] for p in parts}
            assert row(v, stage, "native", feature, tg, lam) == pytest.approx(_probe(net, F, tg, lam), abs=1e-12), \
                (v, stage, feature)
        # extracted: f0's layers on this first layer
        W, bias = sd[net.wk[0]], sd[net.bk[0]]
        for k, tg, lam in ((2, "label", 1e-2), (4, "label", 1e-4), (1, "shortcut_sign", 1e-2)):
            F = {}
            for p in parts:
                acts, _ = CE.mlp_forward({**net.sd, net.wk[0]: W, net.bk[0]: bias}, net.P[p].X["x"], net.wk, net.bk)
                F[p] = acts[k - 1]
            assert row(v, stage, "extracted", f"layer{k}", tg, lam) == pytest.approx(_probe(net, F, tg, lam),
                                                                                    abs=1e-12)
        # layer 1 is one function: the native row is the extracted row
        for tg in LC.TARGETS:
            assert row(v, stage, "native", "layer1", tg, 1e-2) == row(v, stage, "extracted", "layer1", tg, 1e-2)
        # folded: the additions' affine fit on the training set folded into layer 3, later layers the state's own
        with torch.no_grad():
            _, nv = g.forward(net.P["train"].X, return_nodes=[sites["layer2"], sites["layer2_post_merge"]])
        H = nv[sites["layer2"]].double()
        U = nv[sites["layer2_post_merge"]].double() - H
        A = torch.cat([H, torch.ones(H.shape[0], 1, dtype=torch.float64)], 1)
        Th = torch.linalg.lstsq(A, U, driver="gelsd").solution
        M, c = Th[:-1].T, Th[-1]
        F = {}
        for p in parts:
            h2 = nat[p]["layer2"]
            h3 = ((h2 + h2 @ M.T + c) @ w3.T + b3).clamp_min(0)
            F[p] = (h3 @ sd[net.wk[3]].double().T + sd[net.bk[3]].double()).clamp_min(0)
        assert row(v, stage, "folded", "layer4", "label", 1e-2) == pytest.approx(_probe(net, F, "label", 1e-2),
                                                                                 abs=1e-12)
    # a compact control: native = its own chain
    g, ck = _graph(net, "compact_B", "at_21")
    assert ck["extra"]["update"] == 21
    own = g.state_dict()
    F = {p: net.chain(own, p)[1] for p in parts}
    assert row("compact_B", "at_21", "native", "layer4", "label", 1e-2) == pytest.approx(
        _probe(net, F, "label", 1e-2), abs=1e-12)
    assert CC.CONVERGED_TOL == 1e-6


def test_course_contrasts_pair_the_same_layer_context_and_age(w26):
    import layer_course as LC
    pr = {}
    for x in w26["c"]("probes"):
        pr[(f"{x['variant']}@{x['stage']}" if x["variant"] != "f0" else "f0", x["representation_context"],
            x["feature"], x["target"], x["lam"])] = x
    co = w26["c"]("contrasts")
    seen = set()
    for r in co:
        k1, c1, f1 = r["first"].split("|")
        k2, c2, f2 = r["second"].split("|")
        tg, lam = r["spec"].split("|")[1], r["spec"].split("lam=")[1]
        a = pr[(k1, c1, f1, tg, str(float(lam)))][r["metric"]]
        b = pr[(k2, c2, f2, tg, str(float(lam)))][r["metric"]]
        assert float(r["first_value"]) == pytest.approx(float(a), abs=1e-15)
        assert float(r["second_value"]) == pytest.approx(float(b), abs=1e-15)
        assert float(r["value"]) == pytest.approx(float(a) - float(b), abs=1e-15)
        assert (c1, f1) == (r["representation_context"], r["feature"])
        f1o = f1.replace("_post_merge", "")
        if r["comparison"] == "minus_f0":
            assert k2 == "f0" and f2 == f1o and c2 == ("native" if c1 == "folded" else c1)
        elif r["comparison"] == "minus_matched_compact_same_updates":
            v, stage = k1.split("@")
            want = {"A_routed_relu": "compact_A"}.get(v, "compact_B")
            assert k2 == f"{want}@at_{EXP_AGES[stage]}" and f2 == f1o and c2 == ("native" if c1 == "folded" else c1)
            assert r["kind"] == "expansion"
        elif r["comparison"] == "native_minus_extracted":
            assert k2 == k1 and (c1, c2) == ("native", "extracted") and f2 == f1 and "_post_merge" not in f1
        else:
            assert r["comparison"] == "post_merge_minus_pre_merge"
            assert k2 == k1 and c1 == c2 == "native" and f1 == "layer2_post_merge" and f2 == "layer2"
        seen.add((r["comparison"], k1, c1, f1))
    # the compact control has saved states at 3, 6, 9 and 12, not at 0 or 4
    assert ("minus_matched_compact_same_updates", "B_routed_relu@snap_9", "native", "layer4") in seen
    assert ("minus_matched_compact_same_updates", "B_routed_relu@final", "folded", "layer3") in seen
    assert ("minus_matched_compact_same_updates", "A_routed_relu@post_insert_r2", "native", "layer2_post_merge") in seen
    assert not any(c == "minus_matched_compact_same_updates" and k.endswith(("@snap_4", "@post_insert_r1"))
                   for c, k, _, _ in seen)
    assert ("minus_f0", "compact_A@at_24", "native", "layer2") in seen
    assert ("post_merge_minus_pre_merge", "B_all_affine@snap_3", "native", "layer2_post_merge") in seen
    sm = _rows(w26["root"] / "course26_contrasts_summary.csv")
    assert sm and set(LC.CONTRAST_KEYS) | {"mean_value"} <= set(sm[0])
    ps = _rows(w26["root"] / "course26_probes_summary.csv")
    one = [x for x in ps if x["variant"] == "B_routed_relu" and x["stage"] == "final" and x["metric"] == "test_err"
           and x["feature"] == "layer4" and x["spec"] == LC.spec_of("layer4", "label", 1e-2)]
    assert sorted(x["representation_context"] for x in one) == ["extracted", "folded", "native"]


def test_layer_sites_refuse_what_they_cannot_name(net):
    import f0_panel as FP
    g, _ = _graph(net, "compact_A", "at_12")
    assert FP.layer_sites(g, net.L) == {f"layer{k}": FP.activation_after(g, FP.backbone_nodes(g, net.L)[k - 1])
                                        for k in range(1, 5)}
    with pytest.raises(FP.Fail):
        FP.backbone_nodes(g, [*net.L, "no_such_layer"])
    g, _ = _graph(net, "A_routed_relu", "final")
    assert len(FP.leaves_of(g)) == 4                           # two additions per round, two rounds


# ----------------------------------------------------------------------------- the last update and the gradients

def test_the_reconstructed_step_is_the_optimizers_step():
    import routing_updates as RU
    torch.manual_seed(0)
    a, b = torch.nn.Parameter(torch.randn(3, 4)), torch.nn.Parameter(torch.randn(5))
    held = torch.nn.Parameter(torch.randn(2))                 # in the optimizer, never given a gradient
    opt = torch.optim.AdamW([a, b, held], lr=3e-3, betas=(0.9, 0.999), weight_decay=0.0)
    for _ in range(7):
        before = (a.detach().clone(), b.detach().clone())
        opt.zero_grad()
        loss = (a ** 2).sum() * torch.rand(()) + (b * torch.randn(5)).sum()
        loss.backward()
        a.grad[:, 1] = 0.0                                     # a held column: its gradient is zeroed every step
        opt.step()
    names = ["a", "b", "held"]
    upd, moved, lr = RU.adam_last_update(opt.state_dict(), names, {"a": a.shape, "b": b.shape, "held": held.shape})
    assert lr == 3e-3
    assert torch.allclose(upd["a"], (a.detach() - before[0]).double(), rtol=1e-4, atol=1e-9)
    assert torch.allclose(upd["b"], (b.detach() - before[1]).double(), rtol=1e-4, atol=1e-9)
    assert float(upd["a"][:, 1].abs().max()) == 0.0 and not bool(moved["a"][:, 1].any())
    assert bool(moved["a"][:, [0, 2, 3]].all()) and bool(moved["b"].all())
    assert float(upd["held"].abs().max()) == 0.0 and not bool(moved["held"].any())
    with pytest.raises(RU.Fail, match="weight decay"):
        o2 = torch.optim.AdamW([a], lr=1e-3, weight_decay=0.1)
        RU.adam_last_update(o2.state_dict(), ["a"], {"a": a.shape})
    with pytest.raises(RU.Fail, match="tensors"):
        RU.adam_last_update(opt.state_dict(), ["a", "b"], {"a": a.shape, "b": b.shape})
    with pytest.raises(RU.Fail, match="not Adam"):
        RU.adam_last_update(torch.optim.SGD([a], lr=0.1).state_dict(), ["a"], {"a": a.shape})
    assert RU.cos(torch.tensor([1.0, 0.0]), torch.tensor([0.0, 0.0])) is None
    assert RU.cos(torch.tensor([1.0, 0.0]), torch.tensor([-2.0, 0.0])) == -1.0


def test_routing_passes_and_reports_every_state_with_an_update(w26):
    import routing_updates as RU
    r = w26["routing"]
    assert r.returncode == 0, r.stdout[-2000:] + r.stderr[-3000:]
    cov = read_json(w26["root"] / "routing26_coverage.json")
    assert cov["passed"] and cov["analysis_schema"] == RU.ANALYSIS_SCHEMA == "routing_updates/v57"
    assert cov["expected_f0"] == cov["analysed_f0"] == 1 and cov["failed"] == []
    for f in _files("ROUTING"):
        assert (w26["root"] / f"routing26_{f}").read_text().strip() != "empty", f
    ck = w26["r"]("checkpoints")
    stages = ["snap_3", "snap_4", "snap_9", "final"]          # not the states saved right at an insertion
    assert sorted((x["variant"], x["stage"]) for x in ck) == sorted((v, s) for v in ARMS for s in stages)
    up = w26["r"]("updates")
    assert len(up) == len(ck) * len(RU.GROUPS) and {x["group"] for x in up} == set(RU.GROUPS)
    by = {(x["variant"], x["stage"], x["group"]): x for x in up}
    for x in ck:
        v, s = x["variant"], x["stage"]
        assert x["merge_after_layer"] == "2" and float(x["lr"]) > 0
        assert float(x["check_routed_value_diff"]) <= RU.VALUE_TOL
        assert float(x["check_after_merge_grad_diff"]) <= RU.GRAD_TOL
        assert float(x["check_ones_mask_grad_diff"]) <= RU.GRAD_TOL
        assert float(x["actual_dloss"]) == pytest.approx(float(x["train_loss_after"]) - float(x["train_loss_before"]))
        assert float(x["remainder_dloss"]) == pytest.approx(
            float(x["actual_dloss"]) - float(x["predicted_dloss_ordinary"]), abs=1e-12)
        # the groups' shares add up to the whole prediction
        parts = sum(float(by[(v, s, g)]["predicted_dloss_ordinary"])
                    for g in ("backbone_to_merge", "backbone_after_merge", "additions"))
        assert parts == pytest.approx(float(x["predicted_dloss_ordinary"]), rel=1e-9, abs=1e-12)
        assert float(by[(v, s, "all")]["predicted_dloss_ordinary"]) == pytest.approx(
            float(x["predicted_dloss_ordinary"]), rel=1e-9, abs=1e-12)
        cols = sum(float(by[(v, s, g)]["update_norm"]) ** 2
                   for g in ("first_layer_causal", "first_layer_shortcut", "first_layer_other"))
        assert math.sqrt(cols) <= float(by[(v, s, "first_layer")]["update_norm"]) + 1e-12
        # after the merge routing changes nothing; in an all-examples arm it changes nothing anywhere
        assert float(by[(v, s, "backbone_after_merge")]["cos_ordinary_routed"]) == pytest.approx(1.0, abs=1e-6)
        if v == "B_all_affine":
            assert float(x["routed_vs_ordinary_grad_diff"]) <= RU.GRAD_TOL
            assert float(by[(v, s, "additions")]["cos_ordinary_routed"]) == pytest.approx(1.0, abs=1e-6)
        else:
            assert float(x["routed_vs_ordinary_grad_diff"]) > 1e-3
            assert float(by[(v, s, "additions")]["cos_ordinary_routed"]) < 0.9999
        # the held shortcut column: no update, counted as unmoved, its ordinary gradient reported apart
        sc = by[(v, s, "first_layer_shortcut")]
        if v.startswith("B_"):
            assert float(sc["update_norm"]) == 0.0 and float(sc["free_fraction"]) == 0.0
            assert float(sc["ordinary_grad_norm"]) == 0.0 and float(sc["ordinary_grad_norm_on_held"]) > 0.0
            assert sc["cos_descent_ordinary"] == "" and float(sc["weight_norm_change"]) == 0.0
        else:
            assert float(sc["update_norm"]) > 0.0 and float(sc["free_fraction"]) == 1.0
            assert float(sc["ordinary_grad_norm_on_held"]) == 0.0
    sm = _rows(w26["root"] / "routing26_updates_summary.csv")
    assert sm and {"design_id", "variant", "stage", "group", "metric", "mean_v"} <= set(sm[0])


def test_the_step_before_a_saved_state_is_the_previous_saved_state(w26, net):
    """snap_3 and snap_4 are consecutive updates: theta(snap_4) minus the reconstructed step is theta(snap_3), so
    the weight norms and the training loss 'before' at snap_4 are those of snap_3."""
    import routing_updates as RU
    ck = {(x["variant"], x["stage"]): x for x in w26["r"]("checkpoints")}
    up = {(x["variant"], x["stage"], x["group"]): x for x in w26["r"]("updates")}
    Xtr, ytr = net.P["train"].X, net.P["train"].y.long()
    for v in ARMS:
        g3, _ = _graph(net, v, "snap_3")
        g4, c4 = _graph(net, v, "snap_4")
        p3, p4 = dict(g3.named_parameters()), dict(g4.named_parameters())
        names = [f"mods.{n}" for n in c4["trainer"]["opt_param_names"]]
        upd, _, _ = RU.adam_last_update(c4["trainer"]["opt"], names, {n: p4[n].shape for n in names})
        held = RU.held_masks(net.w["T"][v], {n: p4[n].shape for n in p4}, net.wk, net.bk, net.sc)
        if v.startswith("B_"):                                 # the optimizer still carries momentum for the held
            assert float(upd[net.wk[0]][:, net.sc].abs().max()) > 0      # column; the trainer restores it
            assert torch.equal(p4[net.wk[0]][:, net.sc], p3[net.wk[0]][:, net.sc])
            assert bool(held[net.wk[0]][:, net.sc].all()) and int(held[net.wk[0]].sum()) == p4[net.wk[0]].shape[0]
        else:
            assert not any(bool(h.any()) for h in held.values())
        upd = {n: upd[n] * (~held[n]).double() for n in names}
        for n in names:                                        # the reconstruction itself, tensor by tensor
            assert torch.allclose(p4[n].detach().double() - upd[n], p3[n].detach().double(), rtol=0, atol=1e-6), n
        w3 = math.sqrt(sum(float(p.detach().double().pow(2).sum()) for p in p3.values()))
        w4 = math.sqrt(sum(float(p.detach().double().pow(2).sum()) for p in p4.values()))
        row = up[(v, "snap_4", "all")]
        assert float(row["weight_norm_before"]) == pytest.approx(w3, rel=1e-6)
        assert float(row["weight_norm_after"]) == pytest.approx(w4, rel=1e-9)
        assert float(row["update_norm"]) == pytest.approx(
            math.sqrt(sum(float((p4[n].detach().double() - p3[n].detach().double()).pow(2).sum()) for n in p4)),
            rel=5e-3)
        with torch.no_grad():
            l3 = float(torch.nn.functional.cross_entropy(g3(Xtr), ytr))
            l4 = float(torch.nn.functional.cross_entropy(g4(Xtr), ytr))
        assert float(ck[(v, "snap_4")]["train_loss_before"]) == pytest.approx(l3, rel=1e-5)
        assert float(ck[(v, "snap_4")]["train_loss_after"]) == pytest.approx(l4, rel=1e-6)
        assert float(ck[(v, "snap_3")]["train_loss_after"]) == pytest.approx(l3, rel=1e-6)


def test_the_routed_gradient_is_the_sum_over_each_additions_own_examples(w26, net):
    """rederived without masks: an addition's parameters receive the loss gradient of the examples assigned to it
    and of no others (the ordinary gradient of the loss summed over those examples only)."""
    import routing_updates as RU
    up = {(x["variant"], x["stage"], x["group"]): x for x in w26["r"]("updates")}
    Xtr, ytr = net.P["train"].X, net.P["train"].y.long()
    N = ytr.shape[0]
    for v in ("A_routed_relu", "B_routed_relu"):
        g, ck = _graph(net, v, "final")
        params = dict(g.named_parameters())
        names = [f"mods.{n}" for n in ck["trainer"]["opt_param_names"]]
        upd, _, _ = RU.adam_last_update(ck["trainer"]["opt"], names, {n: params[n].shape for n in names})
        held = RU.held_masks(net.w["T"][v], {n: p.shape for n, p in params.items()}, net.wk, net.bk, net.sc)
        with torch.no_grad():
            for n in names:
                params[n].copy_((params[n].detach().double() - upd[n] * (~held[n]).double()).to(params[n].dtype))
        ind = torch.load(net.runs / run_id(net.w["T"][v]) / "spec_partition.pt", weights_only=False).bool()
        assert ind.shape == (N,) and 0 < int(ind.sum()) < N
        sel = {"spec_a": ind, "spec_b": ~ind}
        backbone = set(net.wk) | set(net.bk)
        total = 0.0
        import f0_panel as FP
        for iid in FP.leaves_of(g):
            imp = g.implants[iid]
            key = ((imp.meta or {}).get("specialization") or {}).get("mask_key")
            mine = sorted({f"mods.{g.nodes[n].pkey}.{nm}" for n in imp.nodes if g.nodes[n].pkey is not None
                           for nm, _ in g.mods[g.nodes[n].pkey].named_parameters()})
            if not mine:
                continue
            assert key in sel and not set(mine) & backbone
            g.zero_grad(set_to_none=True)
            idx = sel[key].nonzero().squeeze(1)
            out = g({"x": Xtr["x"][idx]})
            (torch.nn.functional.cross_entropy(out, ytr[idx], reduction="sum") / N).backward()
            for n in mine:
                gr = params[n].grad.detach().double()
                total += float(gr.pow(2).sum())
        assert total > 0
        assert float(up[(v, "final", "additions")]["routed_grad_norm"]) == pytest.approx(math.sqrt(total), rel=1e-4)
        # and the ordinary gradient of the additions is larger: every example reaches both additions of a round
        assert float(up[(v, "final", "additions")]["ordinary_grad_norm"]) != pytest.approx(math.sqrt(total), rel=1e-3)


def test_routing_refuses_a_state_without_an_optimizer_state(w26, tmp_path):
    import shutil
    shutil.copytree(w26["root"] / "runs", tmp_path / "runs")
    p = tmp_path / "runs" / run_id(w26["T"]["B_routed_relu"]) / "ckpt" / "snap_9.pt"
    ck = torch.load(p, weights_only=False)
    ck["trainer"]["opt"] = None
    torch.save(ck, p)
    r = _tool("routing_updates.py", tmp_path, tmp_path / "bad", "--manifest", w26["man"], "--strict")
    assert r.returncode == 1 and "carries no optimizer state" in r.stderr
    assert not read_json(tmp_path / "bad_coverage.json")["passed"]
