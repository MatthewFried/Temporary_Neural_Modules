"""v56: the backbone-change launcher (scripts/56; scripts/54 and 55 are retired), analysis only and CPU only from
its first step: CUDA is hidden from every step, the environment report included, even when the shared settings ask for
a CUDA device.  It reads the complete v46 wave-25 panel and the complete v53 wave-26 panel read-only (WAVES chooses;
an incomplete or foreign panel skips the tests and every analysis and fails the launcher), regenerates each manifest
(a failed generation stops that wave), runs the CPU tests once, then three tools per wave (component_change.py with
that wave's compact multiples and a probe folder, layer_course.py, routing_updates.py), checks the evidence and
packages an archive whatever happens.  The per-row probe and contrast tables are evidence but are archived only when
small.
Each choice of WAVES has its own reports folder, probe folder and archive.  The real script runs in the v48 launcher
test's mock COP_HOME."""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import test_v48_launcher as L  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = "56_v56_backbone_change.sh"
SRC = (ROOT / "scripts" / SCRIPT).read_text()
TABLES = re.search(r'^CHANGE_FILES="([^"]+)"', SRC, re.M).group(1).split(",")
COURSE = re.search(r'^COURSE_FILES="([^"]+)"', SRC, re.M).group(1).split(",")
ROUTING = re.search(r'^ROUTING_FILES="([^"]+)"', SRC, re.M).group(1).split(",")
LARGE = re.search(r'^LARGE="([^"]+)"', SRC, re.M).group(1).split()
# the shared settings ask for a CUDA device, as the real common.sh does by default: the launcher must override them.
# `cop` records what it could see
COMMON = L.COMMON.replace("DEVICE=cpu", "DEVICE=cuda").replace(
    'echo "cop $*" >>', 'echo "cop $* cuda=[${CUDA_VISIBLE_DEVICES-unset}] device=$DEVICE" >>')
assert "DEVICE=cuda" in COMMON and "cuda=[" in COMMON
# the panel state by wave: MOCK_PANEL_STATE_25 / _26 (0 = complete)
PANEL_STATE = """import json, os, sys
w = sys.argv[2][-2:]
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write("panel_state " + sys.argv[2] + "\\n")
assert sys.argv[1].endswith("wave" + w + "_full.jsonl"), sys.argv
if not os.path.exists(sys.argv[1]):
    sys.exit(1)
print(json.dumps({"mock": True}))
sys.exit(int(os.environ.get("MOCK_PANEL_STATE_" + w, "0")))
"""
ANALYSIS = r"""import json, os, sys
panel, prefix = sys.argv[1], sys.argv[2]
w = panel[-2:]
assert panel.endswith("panel" + w) and prefix.endswith("change" + w), sys.argv
for f in ("--manifest", "--strict", "--data-root"):
    assert f in sys.argv, f
assert sys.argv[sys.argv.index("--manifest") + 1].endswith("wave" + w + "_full.jsonl")
assert sys.argv[sys.argv.index("--device") + 1] == "cpu"
probes = sys.argv[sys.argv.index("--save-probes") + 1]
assert probes.endswith("/wave" + w) and "/probes_w" in probes, probes
os.makedirs(probes, exist_ok=True)
open(os.path.join(probes, "f0.npz"), "w").write("x")
ev = open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a")
ev.write("change read " + panel + "\n")
ev.write("change" + w + " multiples " + sys.argv[sys.argv.index("--compact-multiples") + 1] + "\n")
ev.write("change" + w + " out " + prefix + "\n")
ev.write("change" + w + " probes " + probes + "\n")
ev.write("change" + w + " cuda=[" + os.environ.get("CUDA_VISIBLE_DEVICES", "unset") + "] device="
         + os.environ.get("DEVICE", "unset") + "\n")
rc = int(os.environ.get("MOCK_CHANGE_RC_" + w, "0"))
for t in os.environ["MOCK_TABLES"].split(","):
    if t.endswith(".json"):
        json.dump({"passed": rc == 0}, open(prefix + "_" + t, "w"))
        continue
    empty = os.environ.get("MOCK_CHANGE_EMPTY") == w + ":" + t
    open(prefix + "_" + t, "w").write("empty\n" if empty else "state,x\nf0,1\n")
sys.exit(rc)
"""
OTHER = r"""import json, os, sys
tool = os.path.basename(sys.argv[0])[:-3]
name = {"layer_course": "course", "routing_updates": "routing"}[tool]
panel, prefix = sys.argv[1], sys.argv[2]
w = panel[-2:]
assert panel.endswith("panel" + w) and prefix.endswith(name + w), sys.argv
for f in ("--manifest", "--strict", "--data-root"):
    assert f in sys.argv, f
assert sys.argv[sys.argv.index("--manifest") + 1].endswith("wave" + w + "_full.jsonl")
assert sys.argv[sys.argv.index("--device") + 1] == "cpu" and "--save-probes" not in sys.argv
ev = open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a")
ev.write(name + " read " + panel + "\n")
if name == "course":
    ev.write("course" + w + " multiples " + sys.argv[sys.argv.index("--compact-multiples") + 1] + "\n")
else:
    assert "--compact-multiples" not in sys.argv
ev.write(name + w + " cuda=[" + os.environ.get("CUDA_VISIBLE_DEVICES", "unset") + "] device="
         + os.environ.get("DEVICE", "unset") + "\n")
rc = int(os.environ.get("MOCK_" + name.upper() + "_RC_" + w, "0"))
for t in os.environ["MOCK_" + name.upper() + "_TABLES"].split(","):
    if t.endswith(".json"):
        json.dump({"passed": rc == 0}, open(prefix + "_" + t, "w"))
        continue
    big = os.environ.get("MOCK_BIG") == name + ":" + t
    open(prefix + "_" + t, "w").write("state,x\n" + ("f0,1\n" * (2000000 if big else 1)))
sys.exit(rc)
"""
PYTEST = r'''#!/usr/bin/env bash
echo "pytest $* cuda=[${CUDA_VISIBLE_DEVICES-unset}] device=$DEVICE" >> "$MOCK_HOME/events.txt"
echo "3 passed"
xml=""; prev=""
for a in "$@"; do [ "$prev" = "--junitxml" ] && xml="$a"; prev="$a"; done
[ -n "$xml" ] && echo "<testsuites><testsuite tests=\"3\" skipped=\"0\" failures=\"0\" errors=\"0\"/></testsuites>" > "$xml"
exit "${MOCK_TEST_RC:-0}"
'''
BOTH = {"environment", "manifest25", "panel_source25", "manifest26", "panel_source26", "cpu_tests", "change25",
        "course25", "routing25", "change26", "course26", "routing26", "evidence", "manifest_copy25",
        "manifest_copy26", "package", "package_final"}


@pytest.fixture
def h(tmp_path):
    home = tmp_path / "home"
    (home / "scripts").mkdir(parents=True)
    shutil.copy2(ROOT / "scripts" / SCRIPT, home / "scripts" / SCRIPT)
    for f in ("package_reports.py", "check_evidence.py"):
        shutil.copy2(ROOT / "scripts" / f, home / "scripts" / f)
    (home / "scripts/panel_state.py").write_text(PANEL_STATE)
    (home / "scripts/common.sh").write_text(COMMON)
    (home / "audit_v5/tools").mkdir(parents=True)
    (home / "audit_v5/tools/component_change.py").write_text(ANALYSIS)
    (home / "audit_v5/tools/layer_course.py").write_text(OTHER)
    (home / "audit_v5/tools/routing_updates.py").write_text(OTHER)
    pt = home / "fake_pytest.sh"
    pt.write_text(PYTEST)
    pt.chmod(0o755)
    zipdir = tmp_path / "zips"
    zipdir.mkdir()
    base = {k: v for k, v in os.environ.items() if k not in ("DIAGNOSTIC_OVERRIDE", "COP_PYTEST", "WAVES")}
    # the caller's shell exposes a GPU and asks for it: the launcher must hide it
    env = dict(base, MOCK_HOME=str(home), COP_RESULTS=str(tmp_path / "results"), ZIP_DIR=str(zipdir), SCALE="full",
               HOME=str(tmp_path), COP_PYTEST=str(pt), V46_RESULTS=str(tmp_path / "cop_results_v46"),
               V53_RESULTS=str(tmp_path / "cop_results_v53"), MOCK_TABLES=",".join(TABLES),
               MOCK_COURSE_TABLES=",".join(COURSE), MOCK_ROUTING_TABLES=",".join(ROUTING),
               CUDA_VISIBLE_DEVICES="0", DEVICE="cuda")
    return {"home": home, "res": tmp_path / "results", "zips": zipdir, "env": env, "tmp": tmp_path,
            "p25": tmp_path / "cop_results_v46" / "panel25", "p26": tmp_path / "cop_results_v53" / "panel26"}


def _sh(h, **env):
    e = dict(h["env"], **{k: str(v) for k, v in env.items()})
    return subprocess.run(["bash", str(h["home"] / "scripts" / SCRIPT)], env=e, capture_output=True, text=True,
                          cwd=str(h["home"]))


def _verdict(h, tag="w25_26"):
    return json.loads((h["res"] / f"v56_reports_{tag}" / "verdict.json").read_text())


def _zip(h, tag="w25_26"):
    return h["zips"] / f"cop_v56_reports_{tag}.zip"


def _events(h):
    p = h["home"] / "events.txt"
    return p.read_text() if p.exists() else ""


def test_every_step_runs_without_cuda_although_the_shell_and_the_settings_ask_for_it(h):
    """the caller exports CUDA_VISIBLE_DEVICES=0 and DEVICE=cuda, and common.sh sets DEVICE=cuda: the environment
    report runs with --no-cuda, and no step (cop, the tests, the analysis) sees a GPU or a CUDA device setting."""
    r = _sh(h)
    assert r.returncode == 0, r.stdout + r.stderr
    ev = _events(h).splitlines()
    env_line = [ln for ln in ev if ln.startswith("cop inspect-environment")]
    assert len(env_line) == 1 and " --no-cuda " in env_line[0]
    seen = [ln for ln in ev if "cuda=[" in ln]
    assert len(seen) >= 10                                     # cop (environment, two manifests), pytest, six analyses
    assert all("cuda=[] device=cpu" in ln for ln in seen), [ln for ln in seen if "cuda=[] device=cpu" not in ln]
    assert any(ln.startswith("pytest ") for ln in seen) and any(ln.startswith("change25 ") for ln in seen)
    assert any(ln.startswith("change26 ") for ln in seen)
    for name in ("course25", "course26", "routing25", "routing26"):
        assert any(ln.startswith(name + " cuda=[] device=cpu") for ln in seen), name
    # and in the script itself: the two settings come before anything runs, and again after the shared settings
    lines = [ln.strip() for ln in SRC.splitlines() if not ln.lstrip().startswith("#")]
    first = lines.index('export CUDA_VISIBLE_DEVICES=""')
    src_at = next(i for i, ln in enumerate(lines) if ln.startswith("source "))
    assert first < src_at and 'export CUDA_VISIBLE_DEVICES=""          # again after common.sh: nothing here may ' \
                              'touch the GPU' in SRC
    assert lines.index("export DEVICE=cpu") < src_at and lines[src_at + 1:].count("export DEVICE=cpu") == 1
    assert "inspect-environment --no-cuda" in SRC and SRC.count("inspect-environment") == 1
    assert SRC.count("--device cpu") == 3 and "--device \"$DEVICE\"" not in SRC and "cuda_tests" not in SRC


def test_both_panels_are_read_read_only_with_their_own_compact_multiples(h):
    r = _sh(h)
    assert r.returncode == 0, r.stdout + r.stderr
    v = _verdict(h)
    assert v["all_passed"] and set(v["steps"]) == BOTH
    ev = _events(h)
    assert "cop run" not in ev and "cop generate-manifest --wave 25" in ev and "cop generate-manifest --wave 26" in ev
    assert f"change read {h['p25']}\n" in ev and f"change read {h['p26']}\n" in ev
    assert "change25 multiples 1\n" in ev and "change26 multiples 1,2\n" in ev
    assert "course25 multiples 1\n" in ev and "course26 multiples 1,2\n" in ev
    for name in ("course", "routing"):
        assert f"{name} read {h['p25']}\n" in ev and f"{name} read {h['p26']}\n" in ev
    assert f"change25 out {h['res']}/v56_reports_w25_26/change25\n" in ev
    assert f"change25 probes {h['res']}/probes_w25_26/wave25\n" in ev
    assert f"change26 probes {h['res']}/probes_w25_26/wave26\n" in ev
    assert ev.count("\npytest ") == 1                                           # the tests run once
    assert ev.index("\npytest ") < ev.index("change read") and ev.rindex("panel_state") < ev.index("\npytest ")
    names = zipfile.ZipFile(_zip(h)).namelist()
    for w in ("25", "26"):
        for tool, files in (("change", TABLES), ("course", COURSE), ("routing", ROUTING)):
            for f in files:
                assert f"cop_v56_reports_w25_26/v56_reports_w25_26/{tool}{w}_{f}" in names, (tool, w, f)
    assert "cop_v56_reports_w25_26/v56_reports_w25_26/evidence.json" in names
    assert "cop_v56_reports_w25_26/verdict.json" in names
    assert not any("/probes_w" in n or n.endswith(".npz") for n in names)       # the fitted probes stay on disk
    # nothing is written to either panel, and nothing outside the results folder and the archive
    assert not h["p25"].exists() and not h["p26"].exists()
    assert sorted(p.name for p in h["zips"].iterdir()) == ["cop_v56_reports_w25_26.zip"]
    assert sorted(p.name for p in h["res"].iterdir()) == ["probes_w25_26", "v56_reports_w25_26"]
    assert (h["res"] / "probes_w25_26/wave26/f0.npz").exists()


@pytest.mark.parametrize("waves, tag, w", [("25", "w25", "25"), ("26", "w26", "26")])
def test_one_wave_alone_needs_only_its_panel(h, waves, tag, w):
    other = "26" if w == "25" else "25"
    r = _sh(h, WAVES=waves, **{f"MOCK_PANEL_STATE_{other}": 3})     # the other panel is still training
    assert r.returncode == 0, r.stdout + r.stderr
    v = _verdict(h, tag)
    assert v["all_passed"] and set(v["steps"]) == {"environment", f"manifest{w}", f"panel_source{w}", "cpu_tests",
                                                    f"change{w}", f"course{w}", f"routing{w}", "evidence",
                                                    f"manifest_copy{w}", "package", "package_final"}
    ev = _events(h)
    assert f"panel{other}" not in ev and f"--wave {other}" not in ev and f"change{w} multiples" in ev
    names = zipfile.ZipFile(_zip(h, tag)).namelist()
    assert all(f"cop_v56_reports_{tag}/v56_reports_{tag}/change{w}_{f}" in names for f in TABLES)
    assert not any(f"change{other}_" in n for n in names)


def test_a_later_run_for_another_wave_leaves_the_earlier_reports_probes_and_archive(h):
    assert _sh(h, WAVES="25").returncode == 0
    z25 = _zip(h, "w25")
    before = (z25.read_bytes(), (h["res"] / "v56_reports_w25/change25_states.csv").read_bytes())
    assert _sh(h, WAVES="26").returncode == 0
    assert _sh(h, WAVES="26 25").returncode == 0                    # any order, one tag
    assert (z25.read_bytes(), (h["res"] / "v56_reports_w25/change25_states.csv").read_bytes()) == before
    assert sorted(p.name for p in h["zips"].iterdir()) == [f"cop_v56_reports_{t}.zip"
                                                            for t in ("w25", "w25_26", "w26")]
    assert sorted(p.name for p in h["res"].iterdir()) == [
        "probes_w25", "probes_w25_26", "probes_w26", "v56_reports_w25", "v56_reports_w25_26", "v56_reports_w26"]
    assert not list((h["res"] / "v56_reports_w26").glob("change25_*"))
    assert (h["res"] / "probes_w25/wave25/f0.npz").exists() and not (h["res"] / "probes_w26/wave25").exists()


@pytest.mark.parametrize("waves", ["24", "25 27", "all", " "])
def test_waves_takes_25_and_26_only(h, waves):
    r = _sh(h, WAVES=waves)
    assert r.returncode == 2 and ("WAVES takes" in r.stdout or "WAVES is empty" in r.stdout)
    assert _events(h) == "" and not list(h["zips"].iterdir())


def test_a_repeated_wave_runs_once(h):
    r = _sh(h, WAVES="25 25")
    assert r.returncode == 0, r.stdout + r.stderr
    assert _events(h).count("change read") == 1 and set(_verdict(h, "w25")["steps"]) >= {"change25"}


@pytest.mark.parametrize("state", [3, 4, 6])
def test_an_incomplete_or_foreign_panel_skips_the_tests_and_every_analysis(h, state):
    """with both waves requested, one unusable panel stops both analyses (WAVES=25 runs wave 25 alone)."""
    r = _sh(h, MOCK_PANEL_STATE_26=state)
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"]["panel_source25"] == 0 and v["steps"]["panel_source26"] == state
    assert v["steps"]["cpu_tests"] == 99 and all(v["steps"][f"{t}{w}"] == 99 for t in ("change", "course", "routing")
                                                 for w in ("25", "26"))
    ev = _events(h)
    assert " read " not in ev and "\npytest " not in ev and _zip(h).exists()
    names = zipfile.ZipFile(_zip(h)).namelist()
    assert not any(f"/{t}2" in n and "_" in n.rsplit("/", 1)[1] for n in names for t in ("change", "course", "routing"))


def test_a_failed_manifest_generation_cannot_fall_through_to_a_stale_manifest(h):
    stale = [h["home"] / f"manifests/wave{w}_full.jsonl" for w in (25, 26)]
    stale[0].parent.mkdir(parents=True)
    for s in stale:
        s.write_text('{"run_id": "stale"}\n')
    r = _sh(h, MOCK_MANIFEST_RC=1)
    assert r.returncode != 0 and not any(s.exists() for s in stale)
    v = _verdict(h)
    for w in ("25", "26"):
        assert v["steps"][f"manifest{w}"] == 1 and v["steps"][f"panel_source{w}"] == 99
        assert v["steps"][f"change{w}"] == 99 and v["steps"][f"manifest_copy{w}"] == 99
        assert v["steps"][f"course{w}"] == 99 and v["steps"][f"routing{w}"] == 99
    assert " read " not in _events(h) and "panel_state" not in _events(h) and _zip(h).exists()


def test_a_failed_analysis_of_one_wave_fails_the_launcher_and_keeps_the_other(h):
    r = _sh(h, MOCK_CHANGE_RC_26=1)
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"]["change25"] == 0 and v["steps"]["change26"] == 1 and v["steps"]["evidence"] == 0
    assert v["steps"]["course26"] == 0 and v["steps"]["routing26"] == 0     # the other tools still run
    assert not v["all_passed"]
    names = zipfile.ZipFile(_zip(h)).namelist()
    assert all(f"cop_v56_reports_w25_26/v56_reports_w25_26/change25_{f}" in names for f in TABLES)
    ev = json.loads((h["res"] / "v56_reports_w25_26/evidence.json").read_text())
    assert ev["steps"]["change25"]["ok"] is True and ev["steps"]["change26"]["ok"] is None


@pytest.mark.parametrize("wave, table", [("25", "states.csv"), ("26", "probes_summary.csv"),
                                         ("25", "contrasts_by_draw.csv"), ("26", "edits.csv")])
def test_an_empty_required_table_fails_the_evidence(h, wave, table):
    r = _sh(h, MOCK_CHANGE_EMPTY=f"{wave}:{table}")
    assert r.returncode != 0
    ev = json.loads((h["res"] / "v56_reports_w25_26/evidence.json").read_text())
    assert ev["steps"][f"change{wave}"]["missing"] == [f"change{wave}_{table} (an empty table)"]
    other = "26" if wave == "25" else "25"
    assert ev["steps"][f"change{other}"]["ok"] is True and _verdict(h)["steps"]["evidence"] == 1


@pytest.mark.parametrize("tool, files", [("course", COURSE), ("routing", ROUTING)])
def test_a_failed_course_or_routing_step_fails_the_launcher(h, tool, files):
    r = _sh(h, **{f"MOCK_{tool.upper()}_RC_25": 1})
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"][f"{tool}25"] == 1 and v["steps"]["change25"] == 0 and v["steps"][f"{tool}26"] == 0
    names = zipfile.ZipFile(_zip(h)).namelist()
    assert all(f"cop_v56_reports_w25_26/v56_reports_w25_26/{tool}26_{f}" in names for f in files)
    ev = json.loads((h["res"] / "v56_reports_w25_26/evidence.json").read_text())
    assert ev["steps"][f"{tool}25"]["ok"] is None and ev["steps"][f"{tool}26"]["ok"] is True


@pytest.mark.parametrize("tool, table", [("course", "probes.csv"), ("course", "contrasts.csv")])
def test_a_large_per_row_table_stays_on_disk_and_its_summaries_are_archived(h, tool, table):
    assert table in LARGE
    r = _sh(h, WAVES="25", MOCK_BIG=f"{tool}:{table}")
    assert r.returncode == 0, r.stdout + r.stderr
    big = h["res"] / "v56_reports_w25" / f"{tool}25_{table}"
    assert big.stat().st_size > 8 * 2 ** 20
    names = zipfile.ZipFile(_zip(h, "w25")).namelist()
    base = "cop_v56_reports_w25/v56_reports_w25/"
    assert f"{base}{tool}25_{table}" not in names
    stem = table[:-4]
    assert f"{base}{tool}25_{stem}_by_draw.csv" in names and f"{base}{tool}25_{stem}_summary.csv" in names
    skipped = json.loads(zipfile.ZipFile(_zip(h, "w25")).read("cop_v56_reports_w25/skipped_large_files.json"))
    assert [x["file"] for x in skipped] == [f"v56_reports_w25/{tool}25_{table}"]
    ev = json.loads((h["res"] / "v56_reports_w25/evidence.json").read_text())
    assert ev["steps"][f"{tool}25"]["ok"] is True                 # still checked as evidence


def test_a_failed_test_suite_or_environment_check_stops_the_analyses(h):
    r = _sh(h, MOCK_TEST_RC=1)
    v = _verdict(h)
    assert r.returncode != 0 and v["steps"]["cpu_tests"] == 1 and v["steps"]["change25"] == 99
    assert v["steps"]["change26"] == 99 and "change read" not in _events(h)
    (h["home"] / "events.txt").unlink()
    r = _sh(h, MOCK_ENV_RC=1)
    v = _verdict(h)
    assert r.returncode != 0 and v["steps"]["environment"] == 1 and v["steps"]["cpu_tests"] == 99
    assert v["steps"]["change25"] == 99 and "change read" not in _events(h) and "\npytest " not in _events(h)


def test_a_rerun_cannot_reuse_the_previous_runs_tables_or_probes(h):
    assert _sh(h).returncode == 0
    assert (h["res"] / "probes_w25_26/wave25/f0.npz").exists()
    r = _sh(h, MOCK_TEST_RC=1)                                       # nothing is analysed this time
    assert r.returncode != 0
    for t in ("change", "course", "routing"):
        assert not list((h["res"] / "v56_reports_w25_26").glob(f"{t}2?_*")), t
    assert not (h["res"] / "probes_w25_26").exists()
    assert json.loads((h["res"] / "v56_reports_w25_26/evidence.json").read_text())["steps"]["change25"]["exit"] == 99


def test_the_script_trains_nothing_and_touches_the_panels_only_through_the_two_readers():
    assert "cop run" not in SRC and "run_wave" not in SRC and "--resume" not in SRC
    uses = [ln.strip() for ln in SRC.splitlines() if "PANEL[" in ln and not ln.lstrip().startswith("#")]
    assert len(uses) == 6, uses                       # the two definitions and the four readers
    assert uses[0] == 'PANEL[25]="${V46_RESULTS:-$HOME/cop_results_v46}/panel25"'
    assert uses[1] == 'PANEL[26]="${V53_RESULTS:-$HOME/cop_results_v53}/panel26"'
    assert "scripts/panel_state.py" in uses[2] and "audit_v5/tools/component_change.py" in uses[3]
    assert "audit_v5/tools/layer_course.py" in uses[4] and "audit_v5/tools/routing_updates.py" in uses[5]
    assert 'COP_RESULTS="${COP_RESULTS:-$HOME/cop_results_v56}"' in SRC and "cop_results_v55" not in SRC
    assert re.search(r'^MULT\[25\]="1"$', SRC, re.M) and re.search(r'^MULT\[26\]="1,2"$', SRC, re.M)
    rm = [ln.strip() for ln in SRC.splitlines() if ln.strip().startswith("rm -r")]
    assert len(rm) == 1 and rm[0].startswith('rm -rf "${PROBES:?}"') and 'PROBES="$COP_RESULTS/probes_$TAG"' in SRC


def test_scripts_54_and_55_are_retired_and_the_earlier_launchers_are_still_launchers(tmp_path):
    for old in ("54_v54_component_change.sh", "55_v55_component_change.sh"):
        r = subprocess.run(["bash", str(ROOT / "scripts" / old)], capture_output=True, text=True,
                           env=dict(os.environ, HOME=str(tmp_path), COP_RESULTS=str(tmp_path / "r")),
                           cwd=str(tmp_path))
        assert r.returncode == 1 and "superseded" in r.stderr, old
        assert not list(tmp_path.iterdir())                     # it writes nothing
    assert "scripts/56_v56_backbone_change.sh" in (ROOT / "scripts/55_v55_component_change.sh").read_text()
    for name, marks in (("52_v52_channel_course.sh", ("--gain-scan", "panel25")),
                        ("53_v53_drift_panel.sh", ("run26", "--contrasts wave26", "cop_results_v53"))):
        src = (ROOT / "scripts" / name).read_text()
        assert "is superseded" not in src and all(m in src for m in marks), name
