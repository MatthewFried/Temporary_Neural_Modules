"""v57: the wave-27 panel (the parameter mask route next to wave 26's routed and all arms), seeding a panel folder
with the finished runs two manifests share (scripts/seed_panel.py), the wave27 registry, and the four analyses on a
real miniature wave 27 through the launcher's own command lines.  The parameter route's meaning is checked on the
trained miniature: the backbone's routed gradient is its ordinary gradient, the additions' is the sum over their
own examples."""
from __future__ import annotations

import csv
import json
import math
import os
import re
import shlex
import shutil
import subprocess
import sys
from pathlib import Path

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "audit_v5" / "tools"))
from cop.config import resolve, run_id  # noqa: E402
from cop.utils import read_json, stable_hash  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
LAUNCHER = ROOT / "scripts/57_v57_route_panel.sh"
SEED_TOOL = str(ROOT / "scripts/seed_panel.py")
ARMS = ["A_routed_relu", "A_param_relu", "A_all_relu", "B_routed_relu", "B_param_relu", "B_all_relu"]
COMPACTS = ["compact_A", "compact_B"]
STEPS = {"reversal27": ("LT_FILES", "selective_reversal.py"), "change27": ("CHANGE_FILES", "component_change.py"),
         "course27": ("COURSE_FILES", "layer_course.py"), "routing27": ("ROUTING_FILES", "routing_updates.py")}


def _rows(path):
    t = Path(path).read_text()
    return [] if t.strip() == "empty" else list(csv.DictReader(open(path)))


def _contract(step: str) -> tuple:
    """the launcher's own required files and options of one analysis step (everything after --manifest's value)."""
    src = LAUNCHER.read_text()
    files = re.search(rf'^{STEPS[step][0]}="([^"]+)"', src, re.M).group(1).split(",")
    cmd = re.search(rf'^\s+step {step} (?:env CUDA_VISIBLE_DEVICES="" )?(python .*?)\n(?!\s+--)', src,
                    re.M | re.S).group(1).replace("\\\n", " ")
    toks = shlex.split(cmd)
    assert toks[1] == f"audit_v5/tools/{STEPS[step][1]}"
    var = {f"${k}": re.search(rf'^{k}="([^"]+)"', src, re.M).group(1) for k in ("PAIRED_VARY", "TRACE_CODES",
                                                                                 "PRIMARY")}
    return files, [var.get(t, t) for t in toks[toks.index("--manifest") + 2:]]


def _analyse(root, man, step, out=None, sub=None):
    files, opts = _contract(step)
    opts = [(sub or {}).get(t, t) for t in opts]
    assert not any("$" in t for t in opts), opts
    r = subprocess.run([sys.executable, str(ROOT / "audit_v5/tools" / STEPS[step][1]), str(root),
                        str(out or root / step), "--manifest", str(man), *opts], capture_output=True, text=True,
                       env=dict(os.environ, CUDA_VISIBLE_DEVICES=""))
    return r, files


# ----------------------------------------------------------------------------- the panel

def test_wave27_is_wave_26s_jobs_unchanged_plus_the_parameter_route_arms():
    from cop.orchestration.manifest import generate
    from cop.orchestration.wave13 import V53_DRAWS, v53_variants, v57_compacts, v57_variants
    from cop.utils import semantic_code_hash
    import test_v46
    assert semantic_code_hash() and test_v46.v45_panels_reusable()   # a new manifest builder is not semantic code
    va = v57_variants()
    assert list(va) == ARMS and list(v57_compacts()) == COMPACTS
    old = v53_variants()
    assert {k for k in va if k in old} == {"A_routed_relu", "A_all_relu", "B_routed_relu", "B_all_relu"}
    assert all(va[k] == old[k] for k in va if k in old)
    for h in "AB":
        hold, growth, f = va[f"{h}_param_relu"]
        assert hold == h and f == 1.0 and growth == {"spec_partition": "random_matched",
                                                    "spec_mask_route": "parameter"}
    m26 = generate([26], "full").entries
    m27 = generate([27], "full").entries
    cf = {r: e["cfg"] for r, e in m27.items()}
    assert len(cf) == 360
    kinds = {}
    for c in cf.values():
        kinds[c["kind"]] = kinds.get(c["kind"], 0) + 1
    assert kinds == {"baseline": 24, "trajectory": 144, "dissipation": 144, "continue": 48}
    # 264 jobs are wave 26's: the same run id and the same FULL configuration (the tags checkpoints record too)
    shared = set(m26) & set(m27)
    assert len(shared) == 264 and all(stable_hash(cf[r]) == stable_hash(m26[r]["cfg"]) for r in shared)
    assert all(cf[r]["wave"] == 26 for r in shared)
    new = {r: c for r, c in cf.items() if r not in shared}
    assert len(new) == 96 and all(c["wave"] == 27 and c["block"] == "V57_core" for c in new.values())
    assert {c["kind"] for c in new.values()} == {"trajectory", "dissipation"}
    assert all(c["growth"]["spec_mask_route"] == "parameter" and c["growth"]["spec_partition"] == "random_matched"
               and c["growth"]["topology"] == "specialized" and c["growth"].get("act", "relu") == "relu"
               for c in new.values())
    assert {c["design"]["variant"] for c in new.values() if c["kind"] == "dissipation"} == {"A_param_relu",
                                                                                           "B_param_relu"}
    assert {c["data"]["data_seed"] for c in cf.values()} == set(V53_DRAWS)
    # a param arm differs from the routed arm of its hold in the mask route only (trajectory and removal)
    tr = {}
    for c in cf.values():
        if c["kind"] == "trajectory":
            tr[(c["train"]["freeze_inputs"], c["growth"]["spec_partition"], c["growth"]["spec_mask_route"],
                c["data"]["data_seed"], c["seeds"]["optimizer"])] = c
    for (hold, part, route, d, o), c in tr.items():
        if route != "parameter":
            continue
        twin = tr[(hold, "random_matched", "gradient", d, o)]
        strip = lambda x: {k: v for k, v in x.items() if k not in ("wave", "block")}                # noqa: E731
        a, b = strip(c), strip(twin)
        assert {**a, "growth": {**a["growth"], "spec_mask_route": "gradient"}} == b
    # the removals lift the hold, as in wave 26
    for c in new.values():
        if c["kind"] == "dissipation":
            assert c["train"]["freeze_inputs"] == "none" and c["dissipation"]["method"] == "linear"


def test_the_wave27_registry_names_this_panels_arms_and_two_primary_contrasts():
    import selective_reversal as SR
    reg = SR.REGISTRIES["wave27"]
    names = [c[0] for c in reg]
    assert len(names) == len(set(names)) == 6 * 4 + 12 + 3 + 2
    arms = set(ARMS)
    for name, kind, a, b in reg:
        assert kind == "cross_measure"
        for side in (a, b):
            assert side[0] in arms | set(COMPACTS), (name, side)
    prim = SR.REGISTRY_PRIMARY["wave27"]
    assert prim == {"S_B_param_relu_extraction_vs_f0", "R_B_param_vs_routed_extraction"} <= set(names)
    by = {c[0]: c for c in reg}
    assert by["R_B_param_vs_routed_extraction"][2][0] == "B_param_relu"
    assert by["R_B_param_vs_routed_extraction"][3][0] == "B_routed_relu"
    assert by["R_A_routed_vs_all_expanded"][2] == SR._N26("A_routed_relu")
    assert by["S_B_param_relu_extraction_vs_compact_B_extraction_at_4U"][3] == SR._CL26("compact_B")
    assert "wave27" in SR.REGISTRY_COHORT and "not new evidence" in SR.REGISTRY_COHORT["wave27"]
    assert SR.REGISTRY_PRIMARY["wave26"] == {"S_B_routed_relu_extraction_vs_f0",
                                             "S_B_routed_relu_extraction_vs_compact_B_extraction_at_2U"}


# ----------------------------------------------------------------------------- a real miniature wave 27

def _traj27(name):
    from test_v31 import _traj
    from test_v53 import AUD, HOLDS, SNAPS
    from cop.orchestration.wave13 import v57_variants
    h, growth, f = v57_variants()[name]
    p = _traj()
    t = p[-1]
    return p, resolve({**t, "growth": {**t["growth"], **growth},
                       "train": {**t["train"], **AUD, **HOLDS[h], "snapshot_at": SNAPS}})


def _panel27(root):
    from test_v31 import _lin, _manifest, _x25
    from test_v53 import LIFT, _compact26, _run
    p, _ = _traj27(ARMS[0])
    T = {k: _traj27(k)[1] for k in ARMS}
    R = {k: _x25(resolve({**_lin(T[k]), "train": {**T[k]["train"], **LIFT}}), variant=k) for k in ARMS}
    Cc = {k: _compact26(p[0], R[ARMS[0]], k) for k in COMPACTS}
    _run([p[0], *T.values()], root)
    for c in [*R.values(), *Cc.values()]:
        _run([c], root)
    return p[0], T, R, Cc, _manifest(root, [p[0], *T.values(), *R.values(), *Cc.values()])


@pytest.fixture(scope="module")
def w27(tmp_path_factory):
    root = tmp_path_factory.mktemp("p27")
    p0, T, R, Cc, man = _panel27(root)
    out = {"root": root, "p0": p0, "T": T, "R": R, "Cc": Cc, "man": man, "res": {}, "files": {}}
    for step in STEPS:
        out["res"][step], out["files"][step] = _analyse(root, man, step, sub={"$PROBES": str(root / "probes27")})
    return out


def test_every_analysis_passes_on_the_miniature_with_the_launchers_options(w27):
    for step in STEPS:
        r = w27["res"][step]
        assert r.returncode == 0, step + "\n" + r.stdout[-1500:] + r.stderr[-3000:]
        cov = read_json(w27["root"] / f"{step}_coverage.json")
        assert cov["passed"], step
        for f in w27["files"][step]:
            assert (w27["root"] / f"{step}_{f}").read_text().strip() != "empty", (step, f)
    # the trained miniature has the three routes
    routes = {k: (c["growth"]["spec_partition"], c["growth"]["spec_mask_route"]) for k, c in w27["T"].items()}
    assert routes["B_param_relu"] == ("random_matched", "parameter")
    assert routes["B_routed_relu"] == ("random_matched", "gradient") and routes["B_all_relu"][0] == "all_examples"


def test_the_registry_reads_the_route_contrasts_and_marks_the_two_primary_ones(w27):
    import selective_reversal as SR
    cov = read_json(w27["root"] / "reversal27_coverage.json")
    assert cov["analysis_schema"] == SR.ANALYSIS_SCHEMA and cov["registry"]["name"] == "wave27"
    assert cov["registry"]["primary"] == sorted(SR.REGISTRY_PRIMARY["wave27"])
    assert cov["registry"]["problems"] == []
    reg = {x["contrast"]: x for x in _rows(w27["root"] / "reversal27_registry_by_setting.csv")}
    assert set(reg) == {c[0] for c in SR.REGISTRIES["wave27"]}
    prim = SR.REGISTRY_PRIMARY["wave27"]
    assert all(x["role"] == ("primary" if k in prim else "secondary") for k, x in reg.items())
    # value = err(b) - err(a): the param arm's extraction against the routed arm's, from the code table
    codes = {(x["variant"], x["code"]): float(x["test_err"]) for x in _rows(w27["root"] / "reversal27_codes.csv")
             if x["arm"] == "treated" and x["state"] == "abrupt"}
    want = codes[("B_routed_relu", "0-1-1-1-1")] - codes[("B_param_relu", "0-1-1-1-1")]
    assert float(reg["R_B_param_vs_routed_extraction"]["value"]) == pytest.approx(want, abs=1e-12)
    f0 = codes[("B_param_relu", "1-1-1-1-1")]
    assert float(reg["S_B_param_relu_extraction_vs_f0"]["value"]) == pytest.approx(
        f0 - codes[("B_param_relu", "0-1-1-1-1")], abs=1e-12)


def test_the_component_analysis_takes_this_panels_primary_arm(w27):
    import component_change as CC
    cov = read_json(w27["root"] / "change27_coverage.json")
    assert cov["analysis_schema"] == CC.ANALYSIS_SCHEMA and list(cov["primary"]["variants"]) == ["B_param_relu"]
    assert cov["design"]["matched_compact"] == {a: f"compact_{a[0]}" for a in ARMS}
    assert cov["options"]["compact_multiples"] == [1, 2] and cov["primary"]["rows"] == 2
    co = _rows(w27["root"] / "change27_contrasts.csv")
    prim = sorted((r["comparison"], r["first"], r["second"]) for r in co if r["role"] == "primary")
    assert prim == [("expansion_minus_f0", "B_param_relu", "f0"),
                    ("expansion_minus_matched_compact", "B_param_relu", "compact_B@1x")]
    assert not any(r["role"] == "primary" and r["variant"] == "B_routed_relu" for r in co)
    st = {x["state"] for x in _rows(w27["root"] / "change27_states.csv")}
    assert st == {"f0", *ARMS, *[f"{c}@{m}x" for c in COMPACTS for m in (1, 2)]}
    assert (w27["root"] / "probes27" / f"{run_id(w27['p0'])}.npz").exists()
    assert CC.role_of("extraction", "test_err", "expansion_minus_f0", "B_routed_relu") == "primary"
    assert CC.role_of("extraction", "test_err", "expansion_minus_f0", "B_routed_relu", {"B_param_relu": 1}) == \
        "exploratory"
    lc = read_json(w27["root"] / "course27_coverage.json")
    assert lc["n_states"] == 1 + len(ARMS) * 5 + len(COMPACTS) * 8


def test_the_parameter_route_masks_the_additions_parameters_and_nothing_of_the_backbone(w27):
    """under the parameter route the whole backbone's routed gradient is its ordinary gradient; under the gradient
    route the backbone below the merge sees a different gradient; in both, an addition's parameters receive the
    gradient of their own examples only."""
    import f0_panel as FP
    import routing_updates as RU
    from test_v56 import _Net
    ck = {(x["variant"], x["stage"]): x for x in _rows(w27["root"] / "routing27_checkpoints.csv")}
    up = {(x["variant"], x["stage"], x["group"]): x for x in _rows(w27["root"] / "routing27_updates.csv")}
    assert {v for v, _ in ck} == set(ARMS) and {s for _, s in ck} == {"snap_3", "snap_9", "final"}
    for (v, s), x in ck.items():
        assert x["mask_route"] == ("parameter" if "_param_" in v else "gradient")
        assert float(x["check_after_merge_grad_diff"]) <= RU.GRAD_TOL
        assert float(x["check_ones_mask_grad_diff"]) <= RU.GRAD_TOL
        below = float(up[(v, s, "backbone_to_merge")]["cos_ordinary_routed"])
        adds = float(up[(v, s, "additions")]["cos_ordinary_routed"])
        if "_param_" in v:
            assert float(x["routed_vs_ordinary_backbone_grad_diff"]) <= RU.GRAD_TOL
            assert below == pytest.approx(1.0, abs=1e-9) and adds < 0.9999
            assert float(x["routed_vs_ordinary_grad_diff"]) > 1e-3          # the additions' parameters differ
        elif "_routed_" in v:
            assert float(x["routed_vs_ordinary_backbone_grad_diff"]) > 1e-3 and below < 0.9999999 and adds < 0.9999
        else:
            assert float(x["routed_vs_ordinary_grad_diff"]) <= RU.GRAD_TOL and adds == pytest.approx(1.0, abs=1e-9)
    # rederived without masks, for a param arm and a routed arm
    net = _Net({"root": w27["root"], "T": w27["T"], "Cc": w27["Cc"]})
    Xtr, ytr = net.P["train"].X, net.P["train"].y.long()
    N = ytr.shape[0]
    for v in ("B_param_relu", "A_param_relu", "B_routed_relu"):
        g = net.graph(v)
        c = torch.load(net.runs / run_id(w27["T"][v]) / "ckpt" / "final.pt", weights_only=False)
        params = dict(g.named_parameters())
        names = [f"mods.{n}" for n in c["trainer"]["opt_param_names"]]
        upd, _, _ = RU.adam_last_update(c["trainer"]["opt"], names, {n: params[n].shape for n in names})
        held = RU.held_masks(w27["T"][v], {n: p.shape for n, p in params.items()}, net.wk, net.bk, net.sc)
        with torch.no_grad():
            for n in names:
                params[n].copy_((params[n].detach().double() - upd[n] * (~held[n]).double()).to(params[n].dtype))
        ind = torch.load(net.runs / run_id(w27["T"][v]) / "spec_partition.pt", weights_only=False).bool()
        sel = {"spec_a": ind, "spec_b": ~ind}
        total = 0.0
        for iid in FP.leaves_of(g):
            imp = g.implants[iid]
            key = ((imp.meta or {}).get("specialization") or {}).get("mask_key")
            mine = sorted({f"mods.{g.nodes[n].pkey}.{nm}" for n in imp.nodes if g.nodes[n].pkey is not None
                           for nm, _ in g.mods[g.nodes[n].pkey].named_parameters()})
            g.zero_grad(set_to_none=True)
            idx = sel[key].nonzero().squeeze(1)
            (torch.nn.functional.cross_entropy(g({"x": Xtr["x"][idx]}), ytr[idx], reduction="sum") / N).backward()
            total += sum(float(params[n].grad.detach().double().pow(2).sum()) for n in mine)
        assert float(up[(v, "final", "additions")]["routed_grad_norm"]) == pytest.approx(math.sqrt(total), rel=1e-4)
        if "_param_" in v:                                    # the backbone: the plain full-batch gradient
            g.zero_grad(set_to_none=True)
            (torch.nn.functional.cross_entropy(g(Xtr), ytr, reduction="sum") / N).backward()
            free = lambda n: params[n].grad.detach().double() * (~held[n]).double()              # noqa: E731
            bb = math.sqrt(sum(float(free(n).pow(2).sum()) for n in (*net.wk[:2], *net.bk[:2])))
            assert float(up[(v, "final", "backbone_to_merge")]["routed_grad_norm"]) == pytest.approx(bb, rel=1e-5)


# ----------------------------------------------------------------------------- seeding a panel folder

def _seed(*args):
    return subprocess.run([sys.executable, SEED_TOOL, *map(str, args)], capture_output=True, text=True,
                          env=dict(os.environ))


def _tree(d: Path) -> dict:
    return {str(p.relative_to(d)): (p.stat().st_size, p.stat().st_mtime_ns) for p in sorted(d.rglob("*"))
            if p.is_file()}


def test_seeding_copies_only_finished_runs_of_the_same_configuration_and_never_touches_the_source(w27, tmp_path):
    src = w27["root"]
    lines = [json.loads(ln) for ln in Path(w27["man"]).read_text().splitlines() if ln.strip()]
    ids = [e["run_id"] for e in lines]
    assert len(ids) == 1 + 2 * len(ARMS) + len(COMPACTS)
    before = _tree(src / "runs")
    # one job the source lacks, one whose descriptive tag differs (the checkpoints record the full configuration)
    extra = {"run_id": "traj-notinthesource00000", "cfg": lines[1]["cfg"]}
    retag = {**lines[2], "cfg": {**lines[2]["cfg"], "block": "another_block"}}
    man = tmp_path / "m.jsonl"
    man.write_text("\n".join(json.dumps(e) for e in [*lines[:2], retag, *lines[3:], extra]) + "\n")
    dst = tmp_path / "panel"
    # a job that is already in the destination is left alone
    (dst / "runs" / ids[0]).mkdir(parents=True)
    (dst / "runs" / ids[0] / "marker").write_text("mine")
    r = _seed(man, src, dst, tmp_path / "seed.json")
    assert r.returncode == 0, r.stdout + r.stderr
    rec = read_json(tmp_path / "seed.json")
    assert rec["already_there"] == [ids[0]] and rec["n_copied"] == len(ids) - 2
    assert rec["to_train"] == {ids[2]: "its saved configuration is not the manifest's",
                               "traj-notinthesource00000": "not in the source"}
    assert rec["bytes_copied"] > 0 and rec["source"] == str(src)
    assert sorted(p.name for p in (dst / "runs").iterdir()) == sorted(set(ids) - {ids[2]})
    assert [p.name for p in (dst / "runs" / ids[0]).iterdir()] == ["marker"]
    for rid in rec["copied"]:
        a, b = _tree(src / "runs" / rid), _tree(dst / "runs" / rid)
        assert {k: v[0] for k, v in a.items()} == {k: v[0] for k, v in b.items()}
        assert (dst / "runs" / rid / "ckpt").is_dir()
        assert (src / "runs" / rid / "status.json").read_bytes() == (dst / "runs" / rid / "status.json").read_bytes()
    assert _tree(src / "runs") == before                       # the source was only read
    # again: nothing is copied twice
    r = _seed(man, src, dst, tmp_path / "seed2.json")
    rec2 = read_json(tmp_path / "seed2.json")
    assert r.returncode == 0 and rec2["n_copied"] == 0 and rec2["n_already_there"] == len(ids) - 1
    # an unfinished, an invalid and a foreign-semantics source run are not used
    for i, (name, edit, why) in enumerate((
            ("status.json", {"status": "running"}, "status running"),
            ("status.json", {"status": "complete", "validity": "invalid"}, "validity invalid"),
            ("provenance.json", {"semantic_hash": "0000"},
             "written by code of other semantics (no audit covers it)"))):
        s2 = tmp_path / f"src{i}"
        shutil.copytree(src / "runs" / ids[3], s2 / "runs" / ids[3])
        (s2 / "runs" / ids[3] / name).write_text(json.dumps(edit))
        one = tmp_path / f"one{i}.jsonl"
        one.write_text(json.dumps(lines[3]) + "\n")
        r = _seed(one, s2, tmp_path / f"d{i}", tmp_path / f"s{i}.json")
        assert r.returncode == 0 and read_json(tmp_path / f"s{i}.json")["to_train"] == {ids[3]: why}
        assert not (tmp_path / f"d{i}" / "runs" / ids[3]).exists()
    # no source at all: everything is left to train; the same folder twice is refused
    r = _seed(w27["man"], tmp_path / "nowhere", tmp_path / "d9", tmp_path / "s9.json")
    assert r.returncode == 0 and read_json(tmp_path / "s9.json")["n_to_train"] == len(ids)
    assert _seed(w27["man"], src, src, tmp_path / "s10.json").returncode == 2
    assert _seed(w27["man"], src).returncode == 2


def test_a_seeded_panel_is_analysed_like_the_one_it_came_from(w27, tmp_path):
    """every run copied: the analyses read the copy (configuration, lineage and checkpoints all hold there)."""
    dst = tmp_path / "panel"
    r = _seed(w27["man"], w27["root"], dst, tmp_path / "seed.json")
    assert r.returncode == 0 and read_json(tmp_path / "seed.json")["n_to_train"] == 0
    r, _ = _analyse(dst, w27["man"], "routing27", out=tmp_path / "routing27")
    assert r.returncode == 0, r.stdout[-1500:] + r.stderr[-3000:]
    a = _rows(tmp_path / "routing27_checkpoints.csv")
    b = _rows(w27["root"] / "routing27_checkpoints.csv")
    assert [(x["variant"], x["stage"], x["train_loss_before"], x["predicted_dloss_ordinary"]) for x in a] == \
        [(x["variant"], x["stage"], x["train_loss_before"], x["predicted_dloss_ordinary"]) for x in b]
