"""v57: the wave-27 panel launcher (scripts/57).  It TRAINS: environment, manifest (a failed generation cannot fall
through to a stale file), validation, CPU tests, on a CUDA device the training code's CUDA tests (run, none skipped);
then it seeds the panel folder with the finished wave-26 runs the manifest shares (read from the v53 panel, SEED=0
trains everything), trains the rest, checks and reloads every job, and runs four analyses on the CPU (the reversal
tool with the wave27 registry, the component analysis with this panel's primary arm, the layer course, the update
diagnostics); evidence; packaging whatever happens.  The real script runs in the v48 launcher test's mock COP_HOME."""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import test_v48_launcher as L  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = "57_v57_route_panel.sh"
SRC = (ROOT / "scripts" / SCRIPT).read_text()
FILES = {k: re.search(rf'^{k}="([^"]+)"', SRC, re.M).group(1).split(",")
         for k in ("LT_FILES", "CHANGE_FILES", "COURSE_FILES", "ROUTING_FILES")}
PREFIX = {"LT_FILES": "reversal27", "CHANGE_FILES": "change27", "COURSE_FILES": "course27",
          "ROUTING_FILES": "routing27"}
LARGE = re.search(r'^LARGE="([^"]+)"', SRC, re.M).group(1).split()
TOOL = r"""import json, os, sys
tool = os.path.basename(sys.argv[0])[:-3]
name = {"selective_reversal": "reversal27", "component_change": "change27", "layer_course": "course27",
        "routing_updates": "routing27"}[tool]
panel, prefix = sys.argv[1], sys.argv[2]
assert panel.endswith("panel27") and prefix.endswith("v57_reports/" + name), sys.argv
assert "--strict" in sys.argv and sys.argv[sys.argv.index("--manifest") + 1].endswith("wave27_full.jsonl")
ev = open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a")
if name == "reversal27":
    for f in ("--trace", "--codes-at-2u", "--implant-codes", "--decompose", "--paired-streams"):
        assert f in sys.argv, f
    assert sys.argv[sys.argv.index("--contrasts") + 1] == "wave27"
    assert sys.argv[sys.argv.index("--paired-vary") + 1] == "growth.spec_mask_route,growth.spec_partition"
    assert sys.argv[sys.argv.index("--trace-codes") + 1] == "0-0-0-0-0,0-1-1-1-1,1-1-1-1-1"
    assert "--device" not in sys.argv
else:
    assert sys.argv[sys.argv.index("--device") + 1] == "cpu"
    assert os.environ.get("CUDA_VISIBLE_DEVICES", "unset") == "", os.environ.get("CUDA_VISIBLE_DEVICES")
if name == "change27":
    assert sys.argv[sys.argv.index("--primary-variants") + 1] == "B_param_relu"
    assert sys.argv[sys.argv.index("--compact-multiples") + 1] == "1,2"
    probes = sys.argv[sys.argv.index("--save-probes") + 1]
    assert probes.endswith("results/probes27"), probes
    os.makedirs(probes, exist_ok=True)
    open(os.path.join(probes, "f0.npz"), "w").write("x")
if name == "course27":
    assert sys.argv[sys.argv.index("--compact-multiples") + 1] == "1,2" and "--save-probes" not in sys.argv
if name == "routing27":
    assert "--compact-multiples" not in sys.argv
ev.write(name + " read " + panel + "\n")
rc = int(os.environ.get("MOCK_RC_" + name, "0"))
for t in os.environ["MOCK_FILES_" + name].split(","):
    if t.endswith(".json"):
        json.dump({"passed": rc == 0}, open(prefix + "_" + t, "w"))
        continue
    empty = os.environ.get("MOCK_EMPTY") == name + ":" + t
    big = os.environ.get("MOCK_BIG") == name + ":" + t
    open(prefix + "_" + t, "w").write("empty\n" if empty else "variant,x\n" + "B,1\n" * (2500000 if big else 1))
sys.exit(rc)
"""
REPORT = r"""import json, os, sys
name = os.path.basename(sys.argv[0])
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write(name + " " + " ".join(sys.argv[1:4]) + "\n")
if name == "runtime_v13.py":                      # runtime_v13.py fit MANIFEST RESULTS OUT
    assert sys.argv[1] == "fit" and sys.argv[3].endswith("panel27")
    out = sys.argv[4]
else:                                             # <tool> RESULTS OUT ...
    assert sys.argv[1].endswith("panel27") and ("--manifest" in sys.argv or name == "fresh_reload.py")
    out = sys.argv[2]
json.dump({"passed": True}, open(out, "w"))
"""
SEED = r"""import json, os, sys
man, src, dst, out = sys.argv[1:5]
assert man.endswith("wave27_full.jsonl") and dst.endswith("results/panel27") and out.endswith("v57_reports/seed27.json")
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write("seed " + src + " -> " + dst + "\n")
json.dump({"source": src, "n_copied": 264}, open(out, "w"))
sys.exit(int(os.environ.get("MOCK_SEED_RC", "0")))
"""
PYTEST = r'''#!/usr/bin/env bash
echo "pytest $*" >> "$MOCK_HOME/events.txt"
echo "3 passed"
xml=""; prev=""
for a in "$@"; do [ "$prev" = "--junitxml" ] && xml="$a"; prev="$a"; done
junit() { [ -n "$xml" ] && echo "<testsuites><testsuite tests=\"$1\" skipped=\"$2\" failures=\"0\" errors=\"0\"/></testsuites>" > "$xml"; }
case " $* " in
  *" -k cuda or gpu_equivalence "*)
    junit 5 "${MOCK_SUITE_SKIPPED:-0}"
    echo "cuda suite device $COP_TEST_CUDA_DEVICE" >> "$MOCK_HOME/events.txt"
    exit "${MOCK_SUITE_RC:-0}" ;;
esac
junit 3 0
exit "${MOCK_TEST_RC:-0}"
'''
ANALYSES = ("reversal27", "change27", "course27", "routing27")
AFTER_RUN = ("status27", "checks27", "reload27", "summary27", "rates27") + ANALYSES


@pytest.fixture
def h(tmp_path):
    home = tmp_path / "home"
    (home / "scripts").mkdir(parents=True)
    shutil.copy2(ROOT / "scripts" / SCRIPT, home / "scripts" / SCRIPT)
    for f in ("package_reports.py", "check_evidence.py", "junit_ran.py"):
        shutil.copy2(ROOT / "scripts" / f, home / "scripts" / f)
    (home / "scripts/seed_panel.py").write_text(SEED)
    (home / "scripts/common.sh").write_text(L.COMMON)
    (home / "audit_v5/tools").mkdir(parents=True)
    (home / "audit_v8/tools").mkdir(parents=True)
    for name in ("selective_reversal.py", "component_change.py", "layer_course.py", "routing_updates.py"):
        (home / "audit_v5/tools" / name).write_text(TOOL)
    for name in ("fresh_reload.py", "runtime_v13.py"):
        (home / "audit_v5/tools" / name).write_text(REPORT)
    (home / "audit_v8/tools/check_results.py").write_text(REPORT)
    pt = home / "fake_pytest.sh"
    pt.write_text(PYTEST)
    pt.chmod(0o755)
    zipdir = tmp_path / "zips"
    zipdir.mkdir()
    base = {k: v for k, v in os.environ.items() if k not in ("DIAGNOSTIC_OVERRIDE", "COP_PYTEST", "SEED",
                                                              "SEED_FROM", "V53_RESULTS")}
    env = dict(base, MOCK_HOME=str(home), COP_RESULTS=str(tmp_path / "results"), ZIP_DIR=str(zipdir), SCALE="full",
               HOME=str(tmp_path), COP_PYTEST=str(pt),
               **{f"MOCK_FILES_{PREFIX[k]}": ",".join(v) for k, v in FILES.items()})
    return {"home": home, "res": tmp_path / "results", "zip": zipdir / "cop_v57_panel_reports.zip", "env": env,
            "tmp": tmp_path}


def _sh(h, common=None, **env):
    if common is not None:
        (h["home"] / "scripts/common.sh").write_text(common)
    e = dict(h["env"], **{k: str(v) for k, v in env.items()})
    return subprocess.run(["bash", str(h["home"] / "scripts" / SCRIPT)], env=e, capture_output=True, text=True,
                          cwd=str(h["home"]))


def _verdict(h):
    return json.loads((h["res"] / "v57_reports/verdict.json").read_text())


def _events(h):
    p = h["home"] / "events.txt"
    return p.read_text() if p.exists() else ""


def test_success_seeds_trains_checks_and_analyses(h):
    r = _sh(h)
    assert r.returncode == 0, r.stdout + r.stderr
    v = _verdict(h)
    assert v["all_passed"] and list(v["steps"]) == [
        "environment", "manifest27", "validate27", "cpu_tests", "seed27", "run27", *AFTER_RUN, "evidence27",
        "manifest_copy", "package", "package_final"]
    ev = _events(h)
    panel = str(h["res"] / "panel27")
    # the default source of the copied runs is the v53 panel under HOME; it is an argument, never a destination
    assert f"seed {h['tmp']}/cop_results_v53/panel26 -> {panel}\n" in ev
    run = next(ln for ln in ev.splitlines() if ln.startswith("cop run "))
    assert f"--results {panel}" in run and "wave27_full.jsonl" in run and "--resume" in run and "--device cpu" in run
    assert "cop generate-manifest --wave 27 --scale full" in ev and "cop summarize --strict" in ev
    order = [ev.index(x) for x in ("cop generate-manifest", "cop validate-manifest", "\npytest ", "seed ",
                                   "cop run ", "cop status", "check_results.py", "fresh_reload.py", "cop summarize",
                                   "runtime_v13.py", "reversal27 read", "change27 read", "course27 read",
                                   "routing27 read")]
    assert order == sorted(order)
    for t in ANALYSES:
        assert f"{t} read {panel}\n" in ev
    names = zipfile.ZipFile(h["zip"]).namelist()
    for k, fs in FILES.items():
        for f in fs:
            assert f"cop_v57_panel_reports/v57_reports/{PREFIX[k]}_{f}" in names, (k, f)
    for f in ("evidence27.json", "checks27.json", "fresh_reload27.json", "wave27_full.jsonl", "rates27.json",
              "seed27.json"):
        assert f"cop_v57_panel_reports/v57_reports/{f}" in names, f
    assert "cop_v57_panel_reports/summary27/s.csv" in names
    assert not any("probes27" in n for n in names) and (h["res"] / "probes27/f0.npz").exists()
    # nothing is written outside its own results folder, the archive folder and the manifest folder
    assert {p.name for p in h["tmp"].iterdir()} == {"home", "results", "zips"}
    assert not (h["tmp"] / "cop_results_v53").exists()


def test_the_seed_source_can_be_pointed_elsewhere_or_switched_off(h):
    r = _sh(h, V53_RESULTS=h["tmp"] / "elsewhere")
    assert r.returncode == 0 and f"seed {h['tmp']}/elsewhere/panel26 -> " in _events(h)
    (h["home"] / "events.txt").unlink()
    r = _sh(h, SEED_FROM=h["tmp"] / "x" / "p")
    assert r.returncode == 0 and f"seed {h['tmp']}/x/p -> " in _events(h)
    (h["home"] / "events.txt").unlink()
    r = _sh(h, SEED=0)
    assert r.returncode == 0, r.stdout + r.stderr
    ev = _events(h)
    assert "seed " not in ev and "cop run " in ev and _verdict(h)["steps"]["seed27"] == 0
    assert "SEED=0" in (h["res"] / "v57_reports/seed27.txt").read_text()
    assert "cop_v57_panel_reports/v57_reports/seed27.json" not in zipfile.ZipFile(h["zip"]).namelist()


def test_a_failed_copy_stops_before_training(h):
    r = _sh(h, MOCK_SEED_RC=1)
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"]["seed27"] == 1 and v["steps"]["run27"] == 99
    assert all(v["steps"][k] == 99 for k in AFTER_RUN) and "cop run " not in _events(h) and h["zip"].exists()


@pytest.mark.parametrize("device", ["cuda", "cuda:1"])
def test_on_cuda_the_training_codes_cuda_tests_run_first_and_the_analyses_stay_on_the_cpu(h, device):
    cuda = L.COMMON.replace("DEVICE=cpu", f"DEVICE={device}")
    r = _sh(h, common=cuda)
    assert r.returncode == 0, r.stdout + r.stderr
    v = _verdict(h)
    assert list(v["steps"])[:8] == ["environment", "manifest27", "validate27", "cpu_tests", "cuda_tests",
                                    "cuda_tests_ran", "seed27", "run27"]
    ev = _events(h)
    assert f"cuda suite device {device}" in ev and ev.index("cuda suite device") < ev.index("seed ")
    run = next(ln for ln in ev.splitlines() if ln.startswith("cop run "))
    assert f"--device {device}" in run
    for t in ("change27", "course27", "routing27"):          # the mock tool asserts CUDA is hidden and --device cpu
        assert v["steps"][t] == 0


def test_a_skipped_or_failed_cuda_test_stops_before_seeding_and_training(h):
    cuda = L.COMMON.replace("DEVICE=cpu", "DEVICE=cuda")
    for env in ({"MOCK_SUITE_SKIPPED": 2}, {"MOCK_SUITE_RC": 1}):
        if (h["home"] / "events.txt").exists():
            (h["home"] / "events.txt").unlink()
        r = _sh(h, common=cuda, **env)
        assert r.returncode != 0
        v = _verdict(h)
        assert v["steps"]["seed27"] == 99 and v["steps"]["run27"] == 99
        ev = _events(h)
        assert "seed " not in ev and "cop run " not in ev


@pytest.mark.parametrize("env, step", [({"MOCK_ENV_RC": 1}, "environment"), ({"MOCK_MANIFEST_RC": 1}, "manifest27"),
                                       ({"MOCK_VALIDATE_RC": 1}, "validate27"), ({"MOCK_TEST_RC": 1}, "cpu_tests")])
def test_a_failed_prerequisite_trains_nothing(h, env, step):
    stale = h["home"] / "manifests/wave27_full.jsonl"
    stale.parent.mkdir(parents=True, exist_ok=True)
    stale.write_text('{"run_id": "stale"}\n')
    r = _sh(h, **env)
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"][step] == 1 and v["steps"]["run27"] == 99 and v["steps"]["seed27"] == 99
    ev = _events(h)
    assert "cop run " not in ev and "seed " not in ev and " read " not in ev and h["zip"].exists()
    if step == "manifest27":
        assert not stale.exists() and v["steps"]["validate27"] == 99


def test_an_unfinished_panel_reports_its_status_and_analyses_nothing(h):
    r = _sh(h, MOCK_RUN_RC=1)
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"]["run27"] == 1 and v["steps"]["status27"] == 0
    assert all(v["steps"][k] == 99 for k in AFTER_RUN[1:])
    ev = _events(h)
    assert "cop status" in ev and " read " not in ev and "check_results.py" not in ev and h["zip"].exists()


@pytest.mark.parametrize("step", ANALYSES)
def test_a_failed_analysis_fails_the_launcher_and_the_others_still_run(h, step):
    r = _sh(h, **{f"MOCK_RC_{step}": 1})
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"][step] == 1 and all(v["steps"][k] == 0 for k in ANALYSES if k != step)
    ev = json.loads((h["res"] / "v57_reports/evidence27.json").read_text())
    assert ev["steps"][step]["ok"] is None and all(ev["steps"][k]["ok"] is True for k in ANALYSES if k != step)
    names = zipfile.ZipFile(h["zip"]).namelist()
    other = next(k for k in FILES if PREFIX[k] != step)
    assert all(f"cop_v57_panel_reports/v57_reports/{PREFIX[other]}_{f}" in names for f in FILES[other])


@pytest.mark.parametrize("step, table", [("reversal27", "codes.csv"), ("change27", "states.csv"),
                                         ("course27", "probes_summary.csv"), ("routing27", "updates.csv")])
def test_an_empty_required_table_fails_the_evidence(h, step, table):
    r = _sh(h, MOCK_EMPTY=f"{step}:{table}")
    assert r.returncode != 0
    ev = json.loads((h["res"] / "v57_reports/evidence27.json").read_text())
    assert ev["steps"][step]["missing"] == [f"{step}_{table} (an empty table)"]
    assert _verdict(h)["steps"]["evidence27"] == 1


@pytest.mark.parametrize("step, table", [("change27", "contrasts.csv"), ("course27", "probes.csv")])
def test_a_large_per_row_table_stays_on_disk(h, step, table):
    assert table in LARGE
    r = _sh(h, MOCK_BIG=f"{step}:{table}")
    assert r.returncode == 0, r.stdout + r.stderr
    assert (h["res"] / "v57_reports" / f"{step}_{table}").stat().st_size > 8 * 2 ** 20
    names = zipfile.ZipFile(h["zip"]).namelist()
    base = "cop_v57_panel_reports/v57_reports/"
    assert f"{base}{step}_{table}" not in names and f"{base}{step}_{table[:-4]}_summary.csv" in names


def test_a_rerun_cannot_reuse_the_previous_runs_tables_or_probes(h):
    assert _sh(h).returncode == 0
    r = _sh(h, MOCK_RUN_RC=1)
    assert r.returncode != 0
    for t in ANALYSES:
        assert not list((h["res"] / "v57_reports").glob(f"{t}_*")), t
    assert not (h["res"] / "probes27").exists()


def test_the_script_writes_its_own_results_only_and_reads_the_v53_panel_through_the_seed_step():
    assert 'COP_RESULTS="${COP_RESULTS:-$HOME/cop_results_v57}"' in SRC
    uses = [ln.strip() for ln in SRC.splitlines() if "SEED_FROM" in ln and not ln.lstrip().startswith("#")]
    assert uses == ['SEED_FROM="${SEED_FROM:-${V53_RESULTS:-$HOME/cop_results_v53}/panel26}"',
                    'step seed27 python scripts/seed_panel.py "$m27" "$SEED_FROM" "$P" "$O/seed27.json"']
    assert SRC.count("cop_results_v53") == 1 + sum("cop_results_v53" in ln for ln in SRC.splitlines()
                                                   if ln.lstrip().startswith("#"))
    assert SRC.count("--device cpu") == 3 and SRC.count('env CUDA_VISIBLE_DEVICES="" python') == 3
    assert "--contrasts wave27" in SRC and '--primary-variants "$PRIMARY"' in SRC
    assert re.search(r'^PRIMARY="B_param_relu"$', SRC, re.M)
