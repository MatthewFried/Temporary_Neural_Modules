"""v58 (updated in v59 and v60): the wave-28 fork panel (forks of wave 26's routed affine trajectories from saved states:
v58's four keep forks and v59's folded fork), its analysis (audit_v5/tools/fork_continuation.py) and the merge
geometry of a wave-26 panel (audit_v5/tools/merge_geometry.py), on real miniatures through the launcher's own
command lines (scripts/60).  Also: the result checker, the fresh reload and the strict summary accept the forks."""
from __future__ import annotations

import csv
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
from pathlib import Path

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "audit_v5" / "tools"))
from cop.config import resolve, run_id  # noqa: E402
from cop.utils import read_json, stable_hash  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
LAUNCHER = ROOT / "scripts/61_v61_reanalysis.sh"      # v61: the analyses' current command lines
PARENTS = ["A_routed_affine", "B_routed_affine"]
FORKS = {"snap_3": 3, "snap_9": 9}                    # the miniature's clock: U = 6, 2U = 12
STEPS = {"fork28": ("FORK_FILES", "fork_continuation.py"), "geometry26": ("GEOM_FILES", "merge_geometry.py")}


def _rows(path):
    t = Path(path).read_text()
    return [] if t.strip() == "empty" else list(csv.DictReader(open(path)))


def _contract(step: str) -> tuple:
    src = LAUNCHER.read_text()
    files = re.search(rf'^{STEPS[step][0]}="([^"]+)"', src, re.M).group(1).split(",")
    # the command with its continuation lines (each ending in a backslash)
    cmd = re.search(rf'^\s+step {step} (?:env CUDA_VISIBLE_DEVICES="" )?(python (?:[^\n]*\\\n)*[^\n]*)', src,
                    re.M).group(1).replace("\\\n", " ")
    # the device the runs were trained on is added on a CUDA machine only (FORK_EXTRA); the miniature is CPU
    toks = [t for t in shlex.split(cmd) if t != "${FORK_EXTRA[@]}"]
    assert toks[1] == f"audit_v5/tools/{STEPS[step][1]}"
    return files, toks[toks.index("--manifest") + 2:]


def _analyse(root, man, step, out=None):
    files, opts = _contract(step)
    assert not any("$" in t for t in opts), opts
    r = subprocess.run([sys.executable, str(ROOT / "audit_v5/tools" / STEPS[step][1]), str(root),
                        str(out or root / step), "--manifest", str(man), *opts], capture_output=True, text=True,
                       env=dict(os.environ, CUDA_VISIBLE_DEVICES=""))
    return r, files


# ----------------------------------------------------------------------------- the panel

def test_wave28_is_wave_26s_affine_trajectories_384_keep_forks_and_96_folded_forks():
    from cop.orchestration.manifest import generate
    from cop.orchestration.wave13 import V58_CONTS, V58_FORKS, V58_PARENTS, V59_CONTS, v53_variants, v58_forks
    import test_v46
    assert test_v46.v45_panels_reusable()
    assert V58_PARENTS == tuple(PARENTS) and v58_forks(2000) == {"snap_1000": 1000, "snap_2500": 2500}
    with pytest.raises(ValueError):
        v58_forks(500)
    assert set(V58_CONTS) == {"routed_reset", "ordinary_reset", "frozen_reset", "routed_carry"}
    assert all(c["method"] == "keep" for c in V58_CONTS.values())
    assert V59_CONTS == {"folded_reset": {"method": "fold_unrouted", "removal_masks": "released",
                                         "optimizer_policy": "reset_each_phase"}}
    CONTS = {**V58_CONTS, **V59_CONTS}
    m26 = generate([26], "full").entries
    m28 = generate([28], "full").entries
    cf = {r: e["cfg"] for r, e in m28.items()}
    assert len(cf) == 552
    shared = set(m26) & set(m28)
    assert len(shared) == 72 and all(stable_hash(cf[r]) == stable_hash(m26[r]["cfg"]) for r in shared)
    assert {(cf[r]["kind"]) for r in shared} == {"baseline", "trajectory"}
    tr = {r: c for r, c in cf.items() if c["kind"] == "trajectory"}
    assert all(c["growth"]["act"] == "identity" and c["growth"]["spec_partition"] == "random_matched"
               for c in tr.values())
    new = {r: c for r, c in cf.items() if r not in shared}
    assert len(new) == 480 and all(c["wave"] == 28 and c["kind"] == "dissipation" and c["block"] ==
                                   ("V59_folded" if c["design"]["arm"] == "folded_reset" else "V58_core")
                                   for c in new.values())
    va = v53_variants()
    seen = {}
    for c in new.values():
        d, dc, t = c["design"], c["dissipation"], cf[c["parents"]["trajectory"]]
        parent, _, stage = d["variant"].partition("@")
        assert parent in PARENTS and stage in V58_FORKS and c["tags"]["parent_stage"] == stage
        assert all(t["growth"][k] == v for k, v in va[parent][1].items()) and t["growth"]["act"] == "identity"
        assert dc["post_updates"] == 4000 - int(stage.split("_")[1])
        for k, v in CONTS[d["arm"]].items():
            assert dc[k] == v, (d["arm"], k)
        assert c["train"]["freeze_inputs"] == ("shortcut" if parent.startswith("B") else "none")
        assert c["train"] == {**t["train"]}                    # the fork trains as its parent did (hold included)
        seen[(parent, stage, d["arm"])] = seen.get((parent, stage, d["arm"]), 0) + 1
    assert set(seen.values()) == {24} and len(seen) == 20


def _panel28(root):
    from test_v31 import _diss, _manifest
    from test_v53 import _run, _traj26
    from cop.orchestration.wave13 import V58_CONTS, V59_CONTS
    p, TA = _traj26("A_routed_affine")
    _, TB = _traj26("B_routed_affine")
    _run([p[0], TA], root)
    _run([TB], root)
    forks = {}
    for name, T in (("A_routed_affine", TA), ("B_routed_affine", TB)):
        for stage, u in FORKS.items():
            for cn, sec in {**V58_CONTS, **V59_CONTS}.items():
                d = _diss(T, **sec, post_updates=12 - u, early_eval=[], path_eval_points=4)
                d = resolve({**d, "tags": {"parent_stage": stage},
                             "design": {"family": "X28", "variant": f"{name}@{stage}", "arm": cn,
                                        "contrast": "X28|c"}})
                _run([d], root)
                forks[(name, stage, cn)] = d
    return p[0], {"A_routed_affine": TA, "B_routed_affine": TB}, forks, \
        _manifest(root, [p[0], TA, TB, *forks.values()])


@pytest.fixture(scope="module")
def w28(tmp_path_factory):
    root = tmp_path_factory.mktemp("p28")
    p0, T, forks, man = _panel28(root)
    r, files = _analyse(root, man, "fork28")
    return {"root": root, "p0": p0, "T": T, "forks": forks, "man": man, "res": r, "files": files}


def test_the_forks_do_what_their_names_say(w28):
    """from one saved state: routed forks keep the masks, ordinary, frozen and folded release them, frozen leaves every
    addition unchanged, folded has none left, routed_carry carries the optimizer; every fork has the same minibatch
    stream; the held column stays held."""
    runs = w28["root"] / "runs"
    for (name, stage, cn), d in w28["forks"].items():
        res = read_json(runs / run_id(d) / "dissipation_result.json")
        pol = res["removal_policy"]
        assert pol["masks"] == ("retained" if cn.startswith("routed") else "released"), cn
        assert pol["optimizer"] == ("carry_from_parent" if cn == "routed_carry" else "reset_each_phase"), cn
    import selective_reversal as SR
    from cop.graph.graph import GraphNet
    for name in PARENTS:
        for stage in FORKS:
            start = torch.load(runs / run_id(w28["T"][name]) / "ckpt" / f"{stage}.pt", weights_only=False)["model"]
            g0 = GraphNet.from_checkpoint(start)
            first = SR.backbone_layers(g0)[0]
            imp = {g0.nodes[n].pkey for im in g0.implants.values() for n in im.nodes if g0.nodes[n].pkey}
            s0 = start["state"]
            streams = set()
            for cn in ("routed_reset", "ordinary_reset", "frozen_reset", "folded_reset", "routed_carry"):
                d = w28["forks"][(name, stage, cn)]
                end = torch.load(runs / run_id(d) / "ckpt" / "export.pt", weights_only=False)["model"]["state"]
                ks = [k for k in s0 if k.startswith("mods.") and s0[k].is_floating_point() and k in end]
                same_imp = [torch.equal(end[k], s0[k]) for k in ks if k.split(".")[1] in imp]
                if cn == "folded_reset":
                    assert not same_imp                                 # no addition left
                else:
                    assert same_imp and all(same_imp) == (cn == "frozen_reset"), (name, stage, cn)
                w1 = next(k for k in ks if k.split(".")[1] == first and end[k].dim() == 2)
                assert not torch.equal(end[w1], s0[w1])                # the backbone learned in every fork
                if name.startswith("B"):
                    assert torch.equal(end[w1][:, 8], s0[w1][:, 8])     # the held shortcut column
                streams.add(read_json(runs / run_id(d) / "dissipation_result.json")["schedule_audit"]
                            ["batch_id_hash"])
            assert len(streams) == 1                                    # the same minibatch stream


def test_the_checker_the_reload_and_the_strict_summary_accept_the_forks(w28, tmp_path):
    root, man = w28["root"], w28["man"]
    chk = subprocess.run([sys.executable, str(ROOT / "audit_v8/tools/check_results.py"), str(root),
                          str(tmp_path / "chk.json"), "--manifest", str(man), "--transplants-if-any",
                          "--diagnostics-if-any"], capture_output=True, text=True)
    assert chk.returncode == 0, chk.stdout[-2000:] + chk.stderr[-2000:]
    rl = subprocess.run([sys.executable, str(ROOT / "audit_v5/tools/fresh_reload.py"), str(root),
                         str(tmp_path / "rl.json"), "--device", "recorded"], capture_output=True, text=True)
    assert rl.returncode == 0, rl.stdout[-2000:] + rl.stderr[-2000:]
    # (the miniature's manifest has no block records, which only the coverage table reads: summarised without it)
    sm = subprocess.run([sys.executable, "-m", "cop.cli", "summarize", "--strict", "--results", str(root),
                         "--out", str(tmp_path / "summary")], capture_output=True, text=True, cwd=str(ROOT))
    assert sm.returncode == 0, sm.stdout[-2000:] + sm.stderr[-2000:]


def test_fork_continuation_passes_with_the_launchers_options(w28):
    import fork_continuation as FC
    r = w28["res"]
    assert r.returncode == 0, r.stdout[-2000:] + r.stderr[-3000:]
    cov = read_json(w28["root"] / "fork28_coverage.json")
    assert cov["passed"] and cov["analysis_complete"] and cov["analysis_schema"] == FC.ANALYSIS_SCHEMA == \
        "fork_continuation/v68"
    assert cov["design"] == {"parents": PARENTS, "forks": sorted(FORKS), "continuations": list(FC.CONTS)}
    assert cov["n_states"] == 1 + 2 * 2 * (2 + 5) and cov["probe_not_converged"] == []
    assert cov["n_audited_forks"] == 2 * 2 * 5 and cov["audit_failures"] == []
    for f in w28["files"]:
        assert (w28["root"] / f"fork28_{f}").read_text().strip() != "empty", f


def test_the_fork_audit_reads_every_fork_and_fails_on_a_broken_record(w28, tmp_path):
    """v59 / v60: every fork is audited from its own records and checkpoints.  Each broken record fails exactly its
    check: a fork that did not start from the snapshot; a frozen fork whose trainable set is a subset of the
    backbone; a carried fork whose carried optimizer state is not the parent's; a folded fork whose saved after-fold
    checkpoint is not the composition W3 A, b3 + W3 c (and so not the snapshot's function)."""
    au = _rows(w28["root"] / "fork28_audits.csv")
    assert len(au) == 20 and all(r["audit_passed"] == "True" for r in au)
    fo = [r for r in au if r["state"] == "folded_reset"]
    assert len(fo) == 4 and all(r["fold_function_detail"].startswith("algebra (float64 refold") and
                                r["fold_start_detail"].startswith("integrity: run, stage") and   # v66: check_ckpt first
                                "; saved after-fold checkpoint" in r["fold_start_detail"] for r in fo)
    # v61: algebra and rounding apart; v60's float32 rule kept as a column
    for r in fo:
        assert float(r["outcome_fold_algebra64"]) <= 1e-10 and float(r["outcome_fold_storage64"]) <= 1e-5
        assert float(r["outcome_fold_forward32"]) < 1e-4 and r["outcome_fold_float32_rule_v60_passed"] in ("True",
                                                                                                         "False")
        assert float(r["outcome_fold_storage64"]) <= float(r["outcome_fold_forward32"]) + 1e-6
    cov = read_json(w28["root"] / "fork28_coverage.json")
    assert cov["fold_precision"]["fold_algebra64"] <= 1e-10 and cov["flagged_draws_excluded_in_sensitivity"] == []
    # the central table: every state against f0 and every continuation against the start, both probe penalties
    ce = _rows(w28["root"] / "fork28_central.csv")
    got = {(r["parent"], r["fork"], r["comparison"], r["first"]) for r in ce if r["metric"] == "native_test_err"}
    want = {(p_, f_, "minus_f0", c) for p_ in PARENTS for f_ in FORKS
            for c in ("routed_reset", "ordinary_reset", "frozen_reset", "folded_reset", "routed_carry",
                      "trajectory_end")} | \
        {(p_, f_, "start_minus_f0", "start") for p_ in PARENTS for f_ in FORKS} | \
        {(p_, f_, "continuation_minus_start", c) for p_ in PARENTS for f_ in FORKS
         for c in ("routed_reset", "ordinary_reset", "frozen_reset", "folded_reset", "routed_carry")}
    assert got == want
    assert {r["metric"] for r in ce} >= {"extraction_test_err", "state_at_f0_block_row_norms_f0_bias_test_err",
                                         "probe|layer1|standardised|lam=0.0001|test_err",
                                         "probe|layer1|standardised|lam=0.01|test_err"}
    for r in ce:
        assert int(r["n_draw_seed_pairs"]) == 1 and int(r["n_unique_data_draws"]) == 1
        if r["metric"].endswith("_err"):
            assert float(r["gain_points"]) == pytest.approx(-100 * float(r["mean_value"]))
    assert all(r["held_column_detail"] == ("the first layer's shortcut column held" if r["parent"].startswith("B")
                                           else "no hold") for r in au)
    # whether the additions moved is an outcome, recorded and never a check
    assert all(r["outcome_additions_moved"] for r in au if r["state"] != "folded_reset")
    assert "carry events, digest" in next(r for r in au if r["state"] == "routed_carry")["optimizer_policy_detail"]
    root = tmp_path / "copy"
    shutil.copytree(w28["root"] / "runs", root / "runs")
    bad = {run_id(w28["forks"][("A_routed_affine", "snap_3", "routed_reset")]): {"starts_from_snapshot"},
           run_id(w28["forks"][("B_routed_affine", "snap_9", "frozen_reset")]): {"parameters"},
           run_id(w28["forks"][("A_routed_affine", "snap_9", "routed_carry")]): {"optimizer_policy"},
           run_id(w28["forks"][("B_routed_affine", "snap_3", "folded_reset")]): {"fold_start", "fold_function"}}
    for rid, what in bad.items():
        p_ = root / "runs" / rid / "dissipation_result.json"
        res = json.loads(p_.read_text())
        if what == {"starts_from_snapshot"}:
            res["schedule_audit"]["parent_state_hash"] = "0" * 16
        elif what == {"parameters"}:
            for ph in res["schedule_audit"]["phases"]:
                ph["trainable"] = ph["trainable"][:-1]                 # a subset of the backbone
        elif what == {"optimizer_policy"}:
            for e in res["schedule_audit"]["events"]:
                if e["event"] == "optimizer_carried":
                    e["digest"] = "0" * 16
        else:
            ckp = root / "runs" / rid / "ckpt" / "event_after_fold.pt"
            ck = torch.load(ckp, weights_only=False)
            k3 = next(k for k in ck["model"]["state"] if k.endswith(".weight") and
                      k.split(".")[1] not in {"p1", "p2", "p4", "p5"})
            ck["model"]["state"][k3] = ck["model"]["state"][k3] * 1.01
            torch.save(ck, ckp)
        p_.write_text(json.dumps(res))
    r, _ = _analyse(root, w28["man"], "fork28", out=tmp_path / "f")
    assert r.returncode == 1
    cov = read_json(tmp_path / "f_coverage.json")
    assert cov["analysis_complete"] and not cov["passed"]
    got = {x["run_id"]: set(x) - {"f0", "parent", "fork", "state", "run_id"} for x in cov["audit_failures"]}
    assert got == bad


def test_fork_states_are_the_networks_they_name(w28):
    import component_change as CC
    import merge_geometry as MG
    from test_v56 import _Net
    st = {(x["parent"], x["fork"], x["state"]): x for x in _rows(w28["root"] / "fork28_states.csv")}
    net = _Net({"root": w28["root"], "T": {"A_routed_relu": w28["T"]["A_routed_affine"], **w28["T"]}, "Cc": {}})
    runs = w28["root"] / "runs"
    from cop.graph.graph import GraphNet
    blk = CC.blocks_of(net.b.meta["feature_layout"], net.W0.shape[1])
    for (parent, fork, state) in (("A_routed_affine", "snap_3", "ordinary_reset"),
                                  ("B_routed_affine", "snap_9", "frozen_reset"),
                                  ("A_routed_affine", "snap_9", "start"), ("B_routed_affine", "snap_3", "routed_carry")):
        if state == "start":
            p = runs / run_id(w28["T"][parent]) / "ckpt" / f"{fork}.pt"
        else:
            p = runs / run_id(w28["forks"][(parent, fork, state)]) / "ckpt" / "export.pt"
        g = GraphNet.from_checkpoint(torch.load(p, weights_only=False)["model"]).eval()
        sd = g.state_dict()
        W, bias = sd[net.wk[0]], sd[net.bk[0]]
        row = st[(parent, fork, state)]
        with torch.no_grad():
            z = g(net.P["test"].X).double()
        assert float(row["native_test_err"]) == pytest.approx(net.err("test", z), abs=1e-12)
        assert float(row["extraction_test_err"]) == pytest.approx(
            net.err("test", net.extracted(W, bias, "test")[2]), abs=1e-12)
        We, be, _ = CC.edit_layers(W, bias, net.W0, net.b0, blk)["state_at_f0_block_row_norms_f0_bias"]
        assert torch.equal(be, net.b0)
        assert float(row["state_at_f0_block_row_norms_f0_bias_val_indep_err"]) == pytest.approx(
            net.err("val_indep", net.extracted(We, be, "val_indep")[2]), abs=1e-12)
        # one probe of each kind, refitted
        F = {p_: net.extracted(W, bias, p_)[0] for p_ in ("val_indep", "test", "val", "shift")}
        Z, _, _ = MG.preprocess(F, "whitened")
        _, _, r = MG.fit_probe(Z, {p_: net.P[p_].y.long() for p_ in F}, 1e-2, "x")
        assert float(row["probe|layer1|whitened|lam=0.01|test_err"]) == pytest.approx(r["test_err"], abs=1e-12)
        assert row["has_additions"] == "True"
        assert row["probe|native_layer2_post_merge|standardised|lam=0.0001|test_err"] != ""
    f0 = st[("f0", "f0", "f0")]
    assert f0["native_test_err"] == f0["extraction_test_err"] and float(f0["layer_norm_ratio"]) == 1.0
    assert f0["has_additions"] == "False" and "probe|native_layer2_post_merge|whitened|lam=0.01|test_err" not in \
        {k for k, v in f0.items() if v != ""}


def test_fork_contrasts_are_the_named_differences(w28):
    st = {(x["parent"], x["fork"], x["state"]): x for x in _rows(w28["root"] / "fork28_states.csv")}
    co = _rows(w28["root"] / "fork28_contrasts.csv")
    seen = set()
    for r in co:
        a = st[(r["parent"], r["fork"], r["first"])] if r["parent"] != "f0" else None
        b = st[("f0", "f0", "f0")] if r["second"] == "f0" else st[(r["parent"], r["fork"], r["second"])]
        assert float(r["first_value"]) == pytest.approx(float(a[r["metric"]]), abs=1e-15)
        assert float(r["second_value"]) == pytest.approx(float(b[r["metric"]]), abs=1e-15)
        assert float(r["value"]) == pytest.approx(float(r["first_value"]) - float(r["second_value"]), abs=1e-15)
        seen.add((r["comparison"], r["first"], r["second"]))
    assert seen == {("start_minus_f0", "start", "f0"),
                    *{("minus_f0", c, "f0") for c in
                      ("routed_reset", "ordinary_reset", "frozen_reset", "folded_reset", "routed_carry",
                       "trajectory_end")},
                    *{("continuation_minus_start", c, "start") for c in
                      ("routed_reset", "ordinary_reset", "frozen_reset", "folded_reset", "routed_carry")},
                    ("routed_minus_ordinary", "routed_reset", "ordinary_reset"),
                    ("ordinary_minus_frozen", "ordinary_reset", "frozen_reset"),
                    ("frozen_minus_folded", "frozen_reset", "folded_reset"),
                    ("carry_minus_reset", "routed_carry", "routed_reset"),
                    ("trajectory_end_minus_routed_carry", "trajectory_end", "routed_carry")}
    # post-merge probe columns, which f0 and the folded fork lack, are contrasted between states that have them
    assert any(r["metric"].startswith("probe|native_layer2_post_merge") and r["comparison"] == "routed_minus_ordinary"
               for r in co)
    assert not any(r["metric"].startswith("probe|native_layer2_post_merge") and r["comparison"] ==
                   "frozen_minus_folded" for r in co)
    sm = _rows(w28["root"] / "fork28_contrasts_summary.csv")
    assert sm and {"parent", "fork", "comparison", "first", "metric", "mean_value"} <= set(sm[0])


def test_fork_jobs_refuses_an_incomplete_or_ambiguous_design(w28, tmp_path):
    import fork_continuation as FC
    mcfg = {json.loads(ln)["run_id"]: json.loads(ln)["cfg"] for ln in Path(w28["man"]).read_text().splitlines()
            if ln.strip()}
    jobs = FC.fork_jobs(mcfg)
    assert list(jobs) == [run_id(w28["p0"])]
    j = jobs[run_id(w28["p0"])]
    assert set(j) == set(PARENTS) and all(set(v["forks"]) == set(FORKS) for v in j.values())
    d = dict(w28["forks"][("A_routed_affine", "snap_3", "routed_reset")])
    bad = {**mcfg, "dup": d}
    with pytest.raises(FC.Fail, match="two routed_reset forks"):
        FC.fork_jobs(bad)
    wrong = {**d, "tags": {"parent_stage": "snap_9"}}
    with pytest.raises(FC.Fail, match="does not match its fork point"):
        FC.fork_jobs({**mcfg, run_id(d): wrong})
    # a missing fork: the tool stops before analysing anything
    drop = run_id(w28["forks"][("B_routed_affine", "snap_9", "frozen_reset")])
    man = tmp_path / "m.jsonl"
    man.write_text("".join(ln + "\n" for ln in Path(w28["man"]).read_text().splitlines()
                           if ln.strip() and json.loads(ln)["run_id"] != drop))
    r, _ = _analyse(w28["root"], man, "fork28", out=tmp_path / "f")
    assert r.returncode == 1 and "not a complete wave-28 design" in r.stderr


# ----------------------------------------------------------------------------- the merge geometry

def test_whitening_removes_any_invertible_linear_map():
    import merge_geometry as MG
    g = torch.Generator().manual_seed(7)
    n, d = 500, 6
    H = torch.randn(n, d, generator=g, dtype=torch.float64)
    H[:, 5] = 0.0                                             # a dead unit
    A = torch.randn(d, d, generator=g, dtype=torch.float64) + 3 * torch.eye(d, dtype=torch.float64)
    A[5, :] = 0.0
    A[5, 5] = 1.0                                             # invertible
    c = torch.randn(d, generator=g, dtype=torch.float64)
    Pst = H @ A.T + c
    y = (H[:, 0] - H[:, 1] + 0.3 * torch.randn(n, generator=g, dtype=torch.float64) > 0).long()
    mu, P, r = MG.whitener(H)
    assert r == 5 and torch.allclose(((H - mu) @ P).T @ ((H - mu) @ P) / n, torch.eye(5, dtype=torch.float64),
                                     atol=1e-9)
    out = []
    for F in (H, Pst):
        Z, _, dims = MG.preprocess({MG.FIT: F, "test": F, "val": F, "shift": F}, "whitened")
        assert dims == 5
        w, b, r_ = MG.fit_probe(Z, {p: y for p in (MG.FIT, "test", "val", "shift")}, 1e-2, "x")
        out.append((r_["fit_loss"], CC_scores(Z[MG.FIT], w, b)))
    assert abs(out[0][0] - out[1][0]) < 1e-9 and torch.allclose(out[0][1], out[1][1], atol=1e-7)
    # standardised features do see the map
    outs = []
    for F in (H, Pst):
        Z, _, _ = MG.preprocess({MG.FIT: F, "test": F, "val": F, "shift": F}, "standardised")
        _, _, r_ = MG.fit_probe(Z, {p: y for p in (MG.FIT, "test", "val", "shift")}, 1e-2, "x")
        outs.append(r_["fit_loss"])
    assert abs(outs[0] - outs[1]) > 1e-4
    # the merge map recovered from data
    A_, c_, m = MG.merge_map(H, Pst, H, Pst)
    assert m["fit_r2"] == pytest.approx(1.0, abs=1e-12) and m["test_residual"] < 1e-10
    assert torch.allclose(A_[:, :5], A[:, :5], atol=1e-8) and torch.allclose(c_, c, atol=1e-8)
    assert m["span_dims"] == 5 and m["span_rank"] == 5 and m["rank"] == 6
    s = torch.linalg.svdvals(A_)
    assert m["s_max"] == pytest.approx(float(s.max())) and m["cond"] == pytest.approx(float(s.max() / s.min()))


def CC_scores(Z, w, b):
    import component_change as CC
    return CC.probe_scores(Z, w, b)


@pytest.fixture(scope="module")
def g26(tmp_path_factory):
    from test_v53 import _panel26
    root = tmp_path_factory.mktemp("g26")
    p0, T, R, Cc, man = _panel26(root, arms=["A_routed_affine", "B_routed_affine", "A_routed_relu"],
                                 compacts=["compact_A", "compact_B"])
    r, files = _analyse(root, man, "geometry26")
    return {"root": root, "p0": p0, "T": T, "Cc": Cc, "man": man, "res": r, "files": files}


def test_merge_geometry_passes_and_carries_probes_through_affine_merges(g26):
    import merge_geometry as MG
    r = g26["res"]
    assert r.returncode == 0, r.stdout[-2000:] + r.stderr[-3000:]
    cov = read_json(g26["root"] / "geometry26_coverage.json")
    assert cov["passed"] and cov["analysis_complete"] and cov["analysis_schema"] == MG.ANALYSIS_SCHEMA == \
        "merge_geometry/v63"
    for f in g26["files"]:
        assert (g26["root"] / f"geometry26_{f}").read_text().strip() != "empty", f
    maps = _rows(g26["root"] / "geometry26_maps.csv")
    n_states = {"A_routed_affine": 5, "B_routed_affine": 5, "A_routed_relu": 5}  # 2 insertions, 2 snapshots, end
    by = {}
    for m in maps:
        by.setdefault(m["variant"], []).append(m)
    assert {v: len(x) for v, x in by.items()} == n_states
    assert cov["n_maps"] == 15 and cov["maps_by_source"] == {MG.MAP_EXACT: 10, MG.MAP_LS: 5}
    cert = cov["transport_certificate"]
    assert {k: cert[k] for k in ("expected", "eligible", "checked", "passed", "failed")} == \
        {"expected": 10, "eligible": 10, "checked": 10, "passed": 10, "failed": 0}
    assert cert["valid"] and cert["complete"] and cert["skipped"] == {}
    # v61: the float32 certificate (v60's) is reported beside it, with the precision diagnostic
    c32 = cov["transport_certificate_float32"]
    assert c32["checked"] == 10 and c32["passed"] + c32["failed"] == 10
    pc = cov["precision"]
    assert pc["max_merge64_vs_map"] <= MG.EXACT64_TOL and pc["max_forward_residual32"] < 1e-4
    prec = _rows(g26["root"] / "geometry26_precision.csv")
    assert len(prec) == 10 * 4 and all(float(x["merge64_vs_map"]) <= MG.EXACT64_TOL for x in prec)
    # a pass is not identical predictions: flips inside the margin band and error differences are reported
    assert cert["passed_rows"] == 10 * len(MG.PREPS) * len(MG.LAMBDAS) * 4
    assert cert["passed_rows_max_disagree_frac"] is not None and cert["passed_rows_max_abs_err_diff"] is not None
    wc = _rows(g26["root"] / "geometry26_whitening_coverage.csv")
    assert wc and {(x["metric"]) for x in wc} == {"fit_err", "test_err"}
    for x in wc:
        assert int(x["planned_pairs"]) == 1 and int(x["planned_draws"]) == 1    # one f0 in the miniature
        assert int(x["comparable_pairs"]) <= int(x["planned_pairs"])
    for v, xs in by.items():
        for m in xs:
            affine = v != "A_routed_relu"
            assert m["map_source"] == (MG.MAP_EXACT if affine else MG.MAP_LS)
            assert (m["transport_eligible"] == "True") == affine
            assert m["transport_passed"] == ("True" if affine else "")
            if affine:
                assert m["fit_r2"] == "" and float(m["data_residual_test"]) <= MG.EXACT_TOL
            else:
                # (R^2 is undefined where the additions' output is constant, e.g. zero right after an insertion)
                assert (m["fit_r2"] == "" or float(m["fit_r2"]) <= 1.0) and m["whitening_comparable"] == "False"
            assert int(m["rank"]) > 0 and int(m["span_rank"]) == int(m["span_dims"]) > 0
    tr = _rows(g26["root"] / "geometry26_transport.csv")
    assert len(tr) == 10 * len(MG.PREPS) * len(MG.LAMBDAS) * 4 * 2
    assert {t["partition"] for t in tr} == {MG.FIT, *MG.EVAL} and {t["precision"] for t in tr} == {"float64", "float32"}
    for t in [t for t in tr if t["precision"] == "float64"]:
        assert t["passed"] == "True" and float(t["score_diff"]) <= MG.SCORE_TOL
        assert float(t["solve_residual"]) <= MG.SOLVE_TOL and t["disagree_outside_margin"] == "0"
        assert float(t["transported_err"]) == pytest.approx(float(t["pre_merge_err"]), abs=1e-12)
        assert float(t["err_diff"]) == pytest.approx(float(t["transported_err"]) - float(t["pre_merge_err"]))
    # comparable whitened probes cannot tell the pre- and post-merge features of an affine merge apart on the fit set
    pr = {(x["variant"], x["stage"], x["feature"], x["prep"], x["lam"]): x
          for x in _rows(g26["root"] / "geometry26_probes.csv")}
    comp = {(m["variant"], m["stage"]): m["whitening_comparable_fit"] == "True" for m in maps}
    # (the miniature's fit set is small: some evaluation points leave its retained span, so the affine states are
    # comparable on the fit set only, and say so)
    assert {k for k, v in comp.items() if v} == {k for k in comp if k[0] != "A_routed_relu"}
    for m in maps:
        if m["variant"] != "A_routed_relu" and m["whitening_comparable"] == "False":
            assert m["whitening_note"].startswith("evaluation points outside") and \
                float(m["whitening_offspan_max"]) > MG.OFFSPAN_TOL
    for (v, stage, feat, prep, lam), x in pr.items():
        if feat == "layer2_post_merge" and prep == "whitened" and comp[(v, stage)]:
            pre = pr[(v, stage, "layer2", prep, lam)]
            assert float(x["fit_loss"]) == pytest.approx(float(pre["fit_loss"]), abs=1e-7), (v, stage)
            assert x["dims"] == pre["dims"]
        if prep == "whitened":
            assert int(x["white_total_dims"]) >= int(x["dims"]) and x["white_discarded_var_frac"] != ""


def test_merge_geometry_probes_and_maps_are_recomputed_from_the_checkpoints(g26):
    import f0_panel as FP
    import merge_geometry as MG
    from cop.graph.graph import GraphNet
    from test_v56 import _Net
    net = _Net({"root": g26["root"], "T": g26["T"], "Cc": g26["Cc"]})
    g = GraphNet.from_checkpoint(torch.load(g26["root"] / "runs" / run_id(g26["T"]["B_routed_affine"]) / "ckpt" /
                                            "final.pt", weights_only=False)["model"]).eval()
    sites = FP.layer_sites(g, net.L)
    vals = {}
    for p in ("train", "val_indep", "test", "val", "shift"):
        v_, _ = FP.node_values(g, net.P[p], list(sites.values()), 4096)
        vals[p] = {k: v_[n] for k, n in sites.items()}
    y = {p: net.P[p].y.long() for p in vals}
    pr = {(x["variant"], x["stage"], x["feature"], x["prep"], x["lam"]): x
          for x in _rows(g26["root"] / "geometry26_probes.csv")}
    for feat, prep, lam in (("layer2_post_merge", "standardised", 1e-4), ("layer4", "whitened", 1e-2)):
        F = {p: vals[p][feat] for p in ("val_indep", "test", "val", "shift")}
        Z, _, dims = MG.preprocess(F, prep)
        _, _, r = MG.fit_probe(Z, y, lam, "x")
        row = pr[("B_routed_affine", "final", feat, prep, str(lam))]
        assert float(row["test_err"]) == pytest.approx(r["test_err"], abs=1e-12) and int(row["dims"]) == dims
    A, c = MG.exact_merge_map(g, sites["layer2"], sites["layer2_post_merge"])
    m = MG.map_fields(A, vals["train"]["layer2"])
    row = next(x for x in _rows(g26["root"] / "geometry26_maps.csv") if x["variant"] == "B_routed_affine"
               and x["stage"] == "final")
    assert float(row["cond"]) == pytest.approx(m["cond"], rel=1e-9) and int(row["span_rank"]) == m["span_rank"]
    # the exact map is the whole merge: post = A h + c on test (float32 activations)
    post = vals["test"]["layer2"] @ A.T + c
    assert torch.allclose(post, vals["test"]["layer2_post_merge"], atol=1e-4)


def test_merge_geometry_contrasts_are_the_named_differences(g26):
    pr = {(x["variant"], x["stage"], x["feature"], x["prep"], x["lam"]): x
          for x in _rows(g26["root"] / "geometry26_probes.csv")}
    co = _rows(g26["root"] / "geometry26_contrasts.csv")
    trs = _rows(g26["root"] / "geometry26_transport.csv")
    kinds = set()
    for r in co:
        kinds.add(r["comparison"])
        a = pr[(r["variant"], r["stage"], r["feature"], r["prep"], r["lam"])]
        if r["comparison"].startswith("fitted_minus_transported"):
            # v63: matched precision (both probes read the same merge outputs); mixed precision labelled
            tr = next(t for t in trs if (t["variant"], t["stage"], t["prep"], t["lam"]) ==
                      (r["variant"], r["stage"], r["prep"], r["lam"]) and t["partition"] == "test" and
                      t["precision"] == ("float32" if r["comparison"].endswith("float32") else "float64"))
            fitted = {"fitted_minus_transported_float32": "layer2_post_merge",
                      "fitted_minus_transported_float64": "layer2_post_merge@float64",
                      "fitted_minus_transported_mixed_precision": "layer2_post_merge"}[r["comparison"]]
            f_ = pr[(r["variant"], r["stage"], fitted, r["prep"], r["lam"])]
            assert float(r["value"]) == pytest.approx(float(f_["test_err"]) - float(tr["transported_err"]),
                                                      abs=1e-15)
            if r["prep"] == "whitened":
                assert r["comparable"] in ("True", "False")
                if r["comparison"].endswith("mixed_precision"):
                    assert r["comparable"] == "False" and "mixed precision" in r["comparability_note"]
            continue
        if r["comparison"] == "post_merge_minus_pre_merge":
            b = pr[(r["variant"], r["stage"], "layer2", r["prep"], r["lam"])]
        elif r["comparison"] == "whitened_minus_standardised":
            b = pr[(r["variant"], r["stage"], r["feature"], "standardised", r["lam"])]
        elif r["comparison"] == "minus_f0":
            b = pr[("f0", "f0", r["feature"], r["prep"], r["lam"])]
        else:
            assert r["comparison"] == "expansion_minus_matched_compact_2U"
            want = "compact_A" if r["variant"].startswith("A") else "compact_B"
            assert r["second"] == f"{want}@at_12"
            b = pr[(want, "at_12", r["feature"], r["prep"], r["lam"])]
        m_ = r["metric"]
        assert m_ == "test_err" or (m_ == "fit_err" and r["comparison"] == "post_merge_minus_pre_merge" and
                                    r["prep"] == "whitened")
        assert float(r["value"]) == pytest.approx(float(a[m_]) - float(b[m_]), abs=1e-15)
        if r["comparison"] == "post_merge_minus_pre_merge" and r["prep"] == "whitened":
            assert r["comparable"] in ("True", "False") and (r["comparable"] == "True" or r["comparability_note"])
            if r["comparable"] == "True" and m_ == "fit_err":
                assert abs(float(r["value"])) <= 1.0 / 64          # invariance on the fit set (a tie at most)
    sm = _rows(g26["root"] / "geometry26_contrasts_summary.csv")
    # rows that are not comparable never reach the summaries
    bad = {(r["variant"], r["stage"], r["metric"], r["lam"]) for r in co
           if r["comparable"] == "False" and r["comparison"] == "post_merge_minus_pre_merge"}
    assert bad and not any((x["variant"], x["stage"], x["metric"], x["lam"]) in bad and x["prep"] == "whitened" and
                           x["comparison"] == "post_merge_minus_pre_merge" for x in sm)
    assert kinds == {"post_merge_minus_pre_merge", "whitened_minus_standardised", "minus_f0",
                     "expansion_minus_matched_compact_2U", "fitted_minus_transported_float32",
                     "fitted_minus_transported_float64", "fitted_minus_transported_mixed_precision"}
    # the probes refitted on the float64 merge outputs exist for every affine expansion state, and nowhere else
    at64 = {(k[0], k[1]) for k in pr if k[2] == "layer2_post_merge@float64"}
    assert at64 == {(v, s_) for (v, s_, f, _, _) in pr if f == "layer2_post_merge" and v != "A_routed_relu"}
    wc = _rows(g26["root"] / "geometry26_whitening_coverage.csv")
    assert {x["comparison"] for x in wc} == {"post_merge_minus_pre_merge", "fitted_minus_transported_float32",
                                             "fitted_minus_transported_float64"}
