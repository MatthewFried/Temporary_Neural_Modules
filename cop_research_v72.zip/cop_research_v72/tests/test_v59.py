"""v59: the folded continuation (dissipation method fold_unrouted), the audited cross-version reuse
(configs/reuse_audits.json; scripts/seed_panel.py, scripts/panel_state.py, scripts/reuse_reproduce.py) and the
corrected merge geometry (exact maps, whitening comparability, the transport certificate)."""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "audit_v5" / "tools"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from cop.config import run_id  # noqa: E402
from cop.utils import read_json, semantic_code_hash  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
AUDITS = ROOT / "configs/reuse_audits.json"
V45 = "1f5f72b51291d08a"


# ----------------------------------------------------------------------------- the fold that ends the routing

@pytest.fixture(scope="module")
def traj(tmp_path_factory):
    """a trained miniature routed affine expansion (two rounds: four branches, every bias trained)."""
    from test_v53 import _run, _traj26
    root = tmp_path_factory.mktemp("t59")
    p, T = _traj26("A_routed_affine")
    _run([p[0], T], root)
    ck = torch.load(root / "runs" / run_id(T) / "ckpt" / "final.pt", weights_only=False)
    return {"root": root, "T": T, "ck": ck}


def _graph64(ck):
    from cop.graph.graph import GraphNet
    g = GraphNet.from_checkpoint(ck["model"])
    g.double()
    g._plan = None
    return g.eval()


def _backbone(g):
    return [g.nodes[n] for n in g.topo_order(g.live_nodes()) if g.nodes[n].op == "linear" and g.nodes[n].owner is None]


def _fold(g):
    from cop.graph import edits as E
    from cop.graph.export import export_compact
    m = g
    for t in sorted([i for i, im in g.implants.items() if im.parent is None], key=lambda s_: int(s_[1:])):
        m = E.fold_implant(m, t, share_params=False, drop_grad_masks=True)
    out = export_compact(m, fold_linear=True)[0]
    out.double()
    out._plan = None
    return out.eval(), m.meta["history"][-1]


def _xy(n=96, seed=3):
    gen = torch.Generator().manual_seed(seed)
    X = {"x": torch.randn(n, 17, generator=gen, dtype=torch.float64)}
    return X, torch.randint(0, 2, (n,), generator=gen)


def test_the_unrouted_fold_is_exact_with_offsets_and_four_branches_and_matches_upstream_gradients(traj):
    from cop.graph import edits as E
    from cop.graph.graph import InvalidDeletion
    g = _graph64(traj["ck"])
    leaves = [i for i, im in g.implants.items() if im.parent is not None]
    masks = E.grad_mask_nodes(g, g.live_nodes())
    assert len(leaves) == 4 and len(masks) == 4
    imp_b = [t for k, t in g.state_dict().items() if k.endswith("bias") and k.split(".")[1] in
             {g.nodes[n].pkey for im in g.implants.values() for n in im.nodes if g.nodes[n].pkey}]
    assert imp_b and all(float(b.abs().max()) > 0 for b in imp_b)               # nonzero offsets
    top = [i for i, im in g.implants.items() if im.parent is None]
    with pytest.raises(InvalidDeletion):                                         # the ordinary fold still refuses
        E.fold_implant(g, top[0], share_params=False)
    f, hist = _fold(g)
    assert hist["op"] == "fold_unrouted" and hist["grad_masks_removed"] == sorted(
        {g.nodes[n].attrs["mask_key"] for n in masks})
    assert not f.implants and len(_backbone(f)) == len(_backbone(g))
    X, y = _xy()
    zg, zf = g(X), f(X)
    assert float((zg - zf).detach().abs().max()) <= 1e-12 * max(1.0, float(zg.detach().abs().max()))
    # without a mask context (masks released) every gradient below the merge is the folded network's
    lg = torch.nn.functional.cross_entropy(zg, y)
    lf = torch.nn.functional.cross_entropy(zf, y)
    bg, bf = _backbone(g), _backbone(f)
    pg = [p for nd in bg[:2] for p in g.mods[nd.pkey].parameters()]
    pf = [p for nd in bf[:2] for p in f.mods[nd.pkey].parameters()]
    for a, b in zip(torch.autograd.grad(lg, pg), torch.autograd.grad(lf, pf)):
        assert torch.allclose(a, b, rtol=1e-10, atol=1e-13)


def test_frozen_scaffold_and_folded_training_diverge_after_one_update(traj):
    """with SGD the frozen scaffold moves layer 3's effective weight by -lr (G A^T A + gb c^T A), the folded network
    by -lr G (G, gb: the compact layer's weight and bias gradients): the two start as one function and are different
    networks after one update (so no test may require them equal)."""
    import f0_panel as FP
    import merge_geometry as MG
    g = _graph64(traj["ck"])
    f, _ = _fold(g)
    bg, bf = _backbone(g), _backbone(f)
    sites = FP.layer_sites(g, [nd.pkey for nd in bg])
    A, c = MG.exact_merge_map(g, sites["layer2"], sites["layer2_post_merge"])
    X, y = _xy()
    lr = 0.1
    W3, Wt3 = g.mods[bg[2].pkey].weight, f.mods[bf[2].pkey].weight
    W3_0, Wt3_0 = W3.detach().clone(), Wt3.detach().clone()
    assert torch.allclose(W3_0 @ A, Wt3_0, atol=1e-12)                           # the fold: W3 A
    # the frozen scaffold: only the backbone moves
    imp_pk = {g.nodes[n].pkey for im in g.implants.values() for n in im.nodes if g.nodes[n].pkey}
    pb = [p for pk, m in g.mods.items() if pk not in imp_pk for p in m.parameters()]
    gr = dict(zip([id(p) for p in pb], torch.autograd.grad(torch.nn.functional.cross_entropy(g(X), y), pb)))
    pfp = list(f.parameters())
    grf = dict(zip([id(p) for p in pfp], torch.autograd.grad(torch.nn.functional.cross_entropy(f(X), y), pfp)))
    G = grf[id(Wt3)]                                          # the gradient for the compact weight W3 A
    gb = grf[id(f.mods[bf[2].pkey].bias)]                     # ... and for its bias
    # the chain rule through the fixed map h -> A h + c: layer 3 reads A h + c, so dL/dW3 = G A^T + gb c^T
    gW3 = G @ A.T + torch.outer(gb, c)
    assert torch.allclose(gr[id(W3)], gW3, atol=1e-12)
    with torch.no_grad():
        for p in pb:
            p -= lr * gr[id(p)]
        for p in pfp:
            p -= lr * grf[id(p)]
    g._plan = None
    f._plan = None
    eff = g.mods[bg[2].pkey].weight.detach() @ A
    assert torch.allclose(eff, Wt3_0 - lr * gW3 @ A, atol=1e-10)    # frozen: -lr (G A^T A + gb c^T A)
    assert torch.allclose(f.mods[bf[2].pkey].weight.detach(), Wt3_0 - lr * G, atol=1e-12)   # folded: -lr G
    assert not torch.allclose(A.T @ A, torch.eye(A.shape[0], dtype=A.dtype), atol=1e-6)
    with torch.no_grad():
        d = float((g(X) - f(X)).abs().max())
    assert d > 1e-6


def test_fold_unrouted_configs():
    from cop.config import ConfigError, resolve
    from test_v31 import _diss, _traj
    T = _traj()[-1]
    d = _diss(T, method="fold_unrouted", post_updates=3, removal_masks="released")
    assert d["dissipation"]["method"] == "fold_unrouted"
    with pytest.raises(ConfigError):
        resolve({**d, "dissipation": {**d["dissipation"], "removal_masks": "retained"}})
    with pytest.raises(ConfigError):
        resolve({**d, "dissipation": {**d["dissipation"], "keep_frozen_implants": True}})


# ----------------------------------------------------------------------------- merge geometry, synthetic

def _probe(H, y, prep, lam=1e-2):
    import merge_geometry as MG
    F = {MG.FIT: H, "test": H, "val": H, "shift": H}
    Z, fn, dims = MG.preprocess(F, prep)
    w, b, _ = MG.fit_probe(Z, {p: y for p in F}, lam, "x")
    return w, b, fn, dims


def _data(n=400, d=6, seed=7):
    g = torch.Generator().manual_seed(seed)
    H = torch.randn(n, d, generator=g, dtype=torch.float64)
    y = (H[:, 0] - H[:, 1] + 0.3 * torch.randn(n, generator=g, dtype=torch.float64) > 0).long()
    A = torch.randn(d, d, generator=g, dtype=torch.float64) + 3 * torch.eye(d, dtype=torch.float64)
    c = torch.randn(d, generator=g, dtype=torch.float64)
    return H, y, A, c


def test_a_corrupted_transport_fails_its_certificate():
    import merge_geometry as MG
    H, y, A, c = _data()
    P = H @ A.T + c
    for prep in MG.PREPS:
        w, b, fn, dims = _probe(H, y, prep)
        ok = MG.transport_check(A, c, {"test": H}, {"test": P}, fn, w, b, dims, {"test": y})
        assert ok[0]["passed"] and ok[0]["score_diff"] <= MG.SCORE_TOL and ok[0]["solve_residual"] <= MG.SOLVE_TOL
        assert ok[0]["disagree_outside_margin"] == 0 and ok[0]["transported_err"] == ok[0]["pre_merge_err"]
        bad = A.clone()
        bad[0, 1] += 0.2                                       # the wrong map
        r = MG.transport_check(bad, c, {"test": H}, {"test": P}, fn, w, b, dims, {"test": y})[0]
        assert not r["passed"] and r["score_diff"] > MG.SCORE_TOL
        r = MG.transport_check(A, c + 0.5, {"test": H}, {"test": P}, fn, w, b, dims, {"test": y})[0]
        assert not r["passed"]                                  # the wrong offset
        Pn = P.clone()
        Pn[:, 2] += 0.3 * torch.randn(Pn.shape[0], generator=torch.Generator().manual_seed(1), dtype=torch.float64)
        r = MG.transport_check(A, c, {"test": H}, {"test": Pn}, fn, w, b, dims, {"test": y})[0]
        assert not r["passed"] and r["reconstruction_residual"] > 1e-3   # post features the map does not produce


def test_an_anisotropic_invertible_map_truncates_whitening_unequally_and_transport_still_certifies():
    import merge_geometry as MG
    H, y, _, c = _data()
    A = torch.eye(H.shape[1], dtype=torch.float64)
    A[0, 0] = 1e6                                              # invertible (condition number 1e6 < COND_MAX)
    P = H @ A.T + c
    F_pre = {MG.FIT: H, "test": H}
    F_post = {MG.FIT: P, "test": P}
    _, _, d_pre, r_pre = MG.preprocess_full(F_pre, "whitened")
    _, _, d_post, r_post = MG.preprocess_full(F_post, "whitened")
    assert d_pre == 6 and d_post == 1                          # the post-merge whitener drops five live directions
    assert r_post["discarded_var_frac"] < 1e-10                # ... though it discarded almost no variance
    s = torch.linalg.svdvals(A)
    wc = MG.whitening_comparable(r_pre, r_post, A, float(s.max() / s.min()))
    assert not wc["fit"] and not wc["eval"] and wc["note"].startswith("unequal retained dimensions")
    w, b, fn, dims = _probe(H, y, "whitened")
    r = MG.transport_check(A, c, {"test": H}, {"test": P}, fn, w, b, dims, {"test": y})[0]
    assert r["passed"]
    # a singular or ill-conditioned map is never comparable
    S = A.clone()
    S[0, 0] = 1e9
    assert MG.whitening_comparable(r_pre, r_post, S, 1e9)["note"].startswith("the exact map is singular")
    # the comparable case: a well-conditioned map, full support
    B = torch.eye(6, dtype=torch.float64) + 0.3 * torch.randn(6, 6, generator=torch.Generator().manual_seed(2),
                                                                 dtype=torch.float64)
    Q = H @ B.T + c
    _, _, _, r_q = MG.preprocess_full({MG.FIT: Q, "test": Q}, "whitened")
    s = torch.linalg.svdvals(B)
    wc = MG.whitening_comparable(r_pre, r_q, B, float(s.max() / s.min()))
    assert wc["fit"] and wc["eval"] and wc["sine"] < 1e-8


def test_rank_deficient_activations_under_a_known_invertible_map():
    """dead units leave the activations rank deficient; the least-squares map then differs from the real map off
    their span (rank, conditioning), the exact map does not, and both agree on the span."""
    import merge_geometry as MG
    H, y, A, c = _data()
    H[:, 4:] = 0.0                                             # two dead units
    A[:, 4:] += 2.0 * torch.eye(6, dtype=torch.float64)[:, 4:] # the real map acts on them (invertible)
    s = torch.linalg.svdvals(A)
    assert float(s.min()) > 0
    P = H @ A.T + c
    Al, cl, r2 = MG.ls_merge_map(H, P)
    assert r2 == pytest.approx(1.0, abs=1e-10) and MG.data_residual(Al, cl, H, P) < 1e-10
    ex, ls = MG.map_fields(A, H), MG.map_fields(Al, H)
    assert ex["rank"] == 6 and ex["s_min"] == pytest.approx(float(s.min()))
    assert ex["span_dims"] == ls["span_dims"] == 4 and ex["span_s_min"] == pytest.approx(ls["span_s_min"], rel=1e-9)
    assert not torch.allclose(Al, A, atol=1e-3) and abs(ls["s_min"] - ex["s_min"]) > 1e-3
    # the data check of the exact map: it reproduces the activations it did not come from
    assert MG.data_residual(A, c, H, P) < 1e-12


# ----------------------------------------------------------------------------- audited reuse

def _entry(kind, method=None):
    from cop.orchestration.manifest import generate
    for rid, e in generate([28], "full").entries.items():
        c = e["cfg"]
        if c["kind"] == kind and (method is None or (c.get("dissipation") or {}).get("method") == method):
            assert run_id(c) == rid
            return rid, c
    raise AssertionError((kind, method))


def _fake_run(root, rid, cfg, produced, status="complete"):
    d = root / "runs" / rid
    (d / "ckpt").mkdir(parents=True)
    (d / "config.json").write_text(json.dumps(cfg))
    (d / "status.json").write_text(json.dumps({"status": status}))
    (d / "provenance.json").write_text(json.dumps({"semantic_hash": produced}))
    torch.save({"model": {"state": {"w": torch.arange(6.0)}}}, d / "ckpt" / "final.pt")
    (d / "endpoint.json").write_text(json.dumps({"checkpoint_param_hash": "abc"}))
    return d


def _seed(man, src, dst, out, *extra):
    return subprocess.run([sys.executable, str(ROOT / "scripts/seed_panel.py"), str(man), str(src), str(dst),
                           str(out), *map(str, extra)], capture_output=True, text=True)


def _tree(d):
    return {str(p.relative_to(d)): p.read_bytes() for p in sorted(Path(d).rglob("*")) if p.is_file()}


def test_the_audit_file_is_this_codes_and_names_its_scope():
    import reuse_audit as RA
    sem = semantic_code_hash()
    au = RA.load(AUDITS, sem)
    assert [a["id"] for a in au] == ["v68_from_v58", "v68_from_v59", "v68_from_v60", "v68_from_v65"]   # v68: this code's audits
    assert au[1]["produced_by_semantic_hash"] == "c50b0c740e212700" and au[1]["scope"] == au[0]["scope"]
    a = au[0]
    assert a["produced_by_semantic_hash"] == V45 and a["accepted_for_semantic_hash"] == sem
    assert a["scope"]["kinds"] == ["baseline", "trajectory", "dissipation", "continue"]
    assert a["scope"]["excluded_dissipation_methods"] == ["fold_unrouted"]
    assert RA.in_scope(a, {"kind": "dissipation", "dissipation": {"method": "keep"}})
    assert not RA.in_scope(a, {"kind": "dissipation", "dissipation": {"method": "fold_unrouted"}})
    assert not RA.in_scope(a, {"kind": "transplant"})
    assert RA.load(AUDITS, "0" * 16) == []                     # an audit of other code is not this code's


def test_audited_copies_carry_a_ledger_and_nothing_else_is_accepted(tmp_path):
    import reuse_audit as RA
    from cop.experiments.context import reuse_accepted
    from cop.orchestration.runner import effective_status
    sem = semantic_code_hash()
    src, dst = tmp_path / "src", tmp_path / "dst"
    jobs = {"base": _entry("baseline"), "keep": _entry("dissipation", "keep"),
            "fold": _entry("dissipation", "fold_unrouted"), "traj": _entry("trajectory")}
    produced = {"base": V45, "keep": V45, "fold": V45, "traj": "0" * 16}
    for k, (rid, c) in jobs.items():
        _fake_run(src, rid, c, produced[k])
    man = tmp_path / "m.jsonl"
    man.write_text("".join(json.dumps({"run_id": rid, "cfg": c}) + "\n" for rid, c in jobs.values()))
    before = _tree(src)
    # without the audit: nothing of other semantics is copied
    r = _seed(man, src, tmp_path / "plain", tmp_path / "plain.json")
    assert r.returncode == 0 and read_json(tmp_path / "plain.json")["n_copied"] == 0
    r = _seed(man, src, dst, tmp_path / "s.json", "--audited", AUDITS)
    assert r.returncode == 0, r.stdout + r.stderr
    rec = read_json(tmp_path / "s.json")
    rb, rk, rf, rt = (jobs[k][0] for k in ("base", "keep", "fold", "traj"))
    assert sorted(rec["copied"]) == sorted([rb, rk]) and rec["copied_audited"] == {rb: "v68_from_v58",
                                                                                   rk: "v68_from_v58"}
    assert rec["to_train"] == {rf: "written by code of other semantics (no audit covers it)",
                               rt: "written by code of other semantics (no audit covers it)"}
    assert _tree(src) == before                                # the source was only read
    for rid in (rb, rk):
        a, b = _tree(src / "runs" / rid), _tree(dst / "runs" / rid)
        assert set(b) == set(a) | {"reuse_accepted.jsonl"} and all(a[k] == b[k] for k in a)   # provenance untouched
        led = [json.loads(x) for x in (dst / "runs" / rid / "reuse_accepted.jsonl").read_text().splitlines()]
        assert len(led) == 1
        e = led[0]
        assert e["accepted_for_semantic_hash"] == sem and e["produced_by_semantic_hash"] == V45
        assert e["audit_id"] == "v68_from_v58" and e["audit_file_sha256"] == RA.sha256_file(AUDITS)
        v = e["verification"]
        assert v["copy_identical_sha256"] and v["config_hashes_to_run_id"] and v["tree_sha256"] == \
            RA.digest_of(RA.tree_digest(src / "runs" / rid)) == rec["digests"][rid]
        assert reuse_accepted(dst / "runs" / rid, sem)
        assert effective_status(dst, rid, sem) == "complete"
        assert effective_status(src, rid, sem) == "stale"     # the source itself is not accepted
    # a saved configuration that does not hash to its run id is never copied
    s2 = tmp_path / "src2"
    _fake_run(s2, rb, {**jobs["base"][1], "tags": {"x": 1}}, V45)
    one = tmp_path / "one.jsonl"
    one.write_text(json.dumps({"run_id": rb, "cfg": {**jobs["base"][1], "tags": {"x": 1}}}) + "\n")
    _seed(one, s2, tmp_path / "d2", tmp_path / "s2.json", "--audited", AUDITS)
    assert read_json(tmp_path / "s2.json")["to_train"] == {rb: "its saved configuration does not hash to its run id"}
    # an audit file for other code accepts nothing; a malformed one is refused
    other = tmp_path / "a.json"
    doc = json.loads(AUDITS.read_text())
    for a_ in doc["audits"]:                                   # v65: several audits; none for this code
        a_["accepted_for_semantic_hash"] = "f" * 16
    other.write_text(json.dumps(doc))
    _seed(man, src, tmp_path / "d3", tmp_path / "s3.json", "--audited", other)
    assert read_json(tmp_path / "s3.json")["n_copied"] == 0
    del doc["audits"][0]["reason"]
    other.write_text(json.dumps(doc))
    assert _seed(man, src, tmp_path / "d4", tmp_path / "s4.json", "--audited", other).returncode == 2


def test_panel_state_accepts_audited_runs_read_only(tmp_path):
    jobs = [_entry("baseline"), _entry("dissipation", "keep")]
    for rid, c in jobs:
        _fake_run(tmp_path / "p", rid, c, V45)
    man = tmp_path / "m.jsonl"
    man.write_text("".join(json.dumps({"run_id": rid, "cfg": c}) + "\n" for rid, c in jobs))
    before = _tree(tmp_path / "p")
    run = lambda *x: subprocess.run([sys.executable, str(ROOT / "scripts/panel_state.py"), str(man),
                                     str(tmp_path / "p"), *map(str, x)], capture_output=True, text=True)
    assert run().returncode == 6
    r = run("--audited", AUDITS)
    assert r.returncode == 0 and json.loads(r.stdout)["complete_under_audit"] == {"v68_from_v58": 2}
    assert _tree(tmp_path / "p") == before                     # nothing written
    rid, c = _entry("dissipation", "fold_unrouted")
    _fake_run(tmp_path / "p", rid, c, V45)
    man.write_text(man.read_text() + json.dumps({"run_id": rid, "cfg": c}) + "\n")
    assert run("--audited", AUDITS).returncode == 6            # out of the audit's scope


def test_the_reproduction_check_selects_audited_copies_and_compares_every_checkpoint(tmp_path):
    import reuse_reproduce as RR
    sem = semantic_code_hash()
    (rb, cb), (rt, ct) = _entry("baseline"), _entry("trajectory")
    ct = {**ct, "parents": {"baseline": rb}}
    rt = "traj-x"
    panel, scratch = tmp_path / "panel", tmp_path / "scratch"
    man = tmp_path / "m.jsonl"
    man.write_text(json.dumps({"run_id": rb, "cfg": cb}) + "\n" + json.dumps({"run_id": rt, "cfg": ct}) + "\n")
    for rid, c in ((rb, cb), (rt, ct)):
        d = _fake_run(panel, rid, c, V45)
        (d / "reuse_accepted.jsonl").write_text(json.dumps({"accepted_for_semantic_hash": sem, "audit_id": "x",
                                                            "user": "seed_panel (audited)"}) + "\n")
        _fake_run(scratch, rid, c, sem)
    sub = tmp_path / "sub.jsonl"
    assert RR.select(str(man), panel, sub) == 0
    assert [json.loads(x)["run_id"] for x in sub.read_text().splitlines()] == [rb, rt]
    assert RR.compare(str(sub), panel, scratch, tmp_path / "c.json") == 0
    assert read_json(tmp_path / "c.json")["reproduced"]
    torch.save({"model": {"state": {"w": torch.arange(6.0) + 1e-7}}}, scratch / "runs" / rt / "ckpt" / "final.pt")
    assert RR.compare(str(sub), panel, scratch, tmp_path / "c2.json") == 1
    assert read_json(tmp_path / "c2.json")["jobs"][rt]["differing"] == {"final": ["model"]}
    # an audited trajectory without an audited baseline: still verified, with its ancestor in the sample
    (panel / "runs" / rb / "reuse_accepted.jsonl").unlink()
    assert RR.select(str(man), panel, tmp_path / "sub2.jsonl") == 0
    assert [json.loads(x)["run_id"] for x in (tmp_path / "sub2.jsonl").read_text().splitlines()] == [rb, rt]
    (panel / "runs" / rt / "reuse_accepted.jsonl").unlink()
    assert RR.select(str(man), panel, tmp_path / "sub3.jsonl") == 5   # no audited run at all: nothing to verify
