"""Acceptance checks of the v5 review (section 10 of CoP_v5_Review_and_Claude_Handoff).

One test (or a small group) per check, in the review's order.  CUDA tests are marked and skip
without a device: a skip is NOT validation; run them on the GPU (scripts/12_v5_gpu_gates.sh)."""
from __future__ import annotations

import itertools
import json
import math
import random
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests"))

import tiny_configs as T  # noqa: E402
from cop.analysis import dependence_game as DG  # noqa: E402
from cop.analysis.v5_tables import DELTA, gain_retention, predictor_screen  # noqa: E402
from cop.config import resolve, run_id  # noqa: E402
from cop.cop_pegs.locality import scope_summary  # noqa: E402
from cop.data.registry import load_bundle  # noqa: E402
from cop.experiments.diagnostics import (_apply, _fit, _values, contraction_diagnostics, jvp_sensitivity,  # noqa: E402
                                         virtual_affine_clone)
from cop.finite import codebook as CB  # noqa: E402
from cop.graph import edits as E  # noqa: E402
from cop.graph.builders import build_mlp  # noqa: E402
from cop.graph.graph import GraphNet  # noqa: E402
from cop.orchestration.runner import run_job, status_of  # noqa: E402
from cop.utils import read_json, torch_gen  # noqa: E402

CUDA = pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA device required (run scripts/12 on the GPU)")
F64 = torch.float64


def _run(cfgs, d, device="cpu"):
    for c in cfgs:
        st = run_job(c, d, {"device": device})
        assert st == "complete", status_of(d, run_id(c)).get("reason")
    return d / "runs" / run_id(cfgs[-1])


# ----------------------------------------------------------------------------- P1: residual counterexamples

def _residual_net(scale: float, head: list[float]):
    """h = (x, 0) -> implant exit (x, scale * |x|) -> head . exit.  The affine fit of |x| on the
    symmetric inputs {-2, -1, 1, 2} is the constant 1.5, residual mean square 0.25."""
    g = build_mlp(1, [2], 1, torch_gen(0, "init"), act="identity").double()
    iid = E.insert_residual_zero(g, E.cut_at(g, "post_act", 0), torch_gen(0, "insertion", "v5"), width=2, act="relu")
    imp = g.implants[iid]
    role = {g.nodes[n].role: n for n in g.topo_order()}
    A = next(n for n in imp.nodes if g.nodes[n].role == "A")
    B = next(n for n in imp.nodes if g.nodes[n].role == "B")
    with torch.no_grad():
        for nid, W in ((role["L0.lin"], [[1.0], [0.0]]), (A, [[1.0, 0.0], [-1.0, 0.0]]),
                       (B, [[0.0, 0.0], [scale, scale]]), (role["head"], [head])):
            m = g.mods[g.nodes[nid].pkey]
            m.weight.copy_(torch.tensor(W, dtype=F64))
            m.bias.zero_()
    g.eval()
    return g, iid


X4 = {"x": torch.tensor([[-2.0], [-1.0], [1.0], [2.0]], dtype=F64)}


def _diag(g, iid, X):
    imp = g.implants[iid]
    v = _values(g, X, [imp.entry, imp.exit], 64)
    W, b, info = _fit(v[imp.entry], v[imp.exit])
    rho = float(((v[imp.exit].double() - _apply(W, b, v[imp.entry])) ** 2).sum(1).mean())
    vc = virtual_affine_clone(g, iid, W, b)
    vc.eval()
    with torch.no_grad():
        virt = float(((vc(X) - g(X)) ** 2).mean())
    return rho, virt, jvp_sensitivity(g, iid, W, b, X)["jvp_residual"], info


@pytest.mark.parametrize("eps", [1.0, 1e-3, 1e-6])
def test_tiny_affine_residual_can_carry_all_the_task_signal(eps):
    """Reviewer's epsilon counterexample: rho -> 0 with eps while the output change after the affine
    replacement stays 0.25 (the downstream reads z[1] / eps).  The virtual replacement and the
    downstream JVP see it; rho alone does not."""
    g, iid = _residual_net(eps, [0.0, 1.0 / eps])
    rho, virt, jvp, info = _diag(g, iid, X4)
    assert rho == pytest.approx(0.25 * eps ** 2, rel=1e-6)
    assert virt == pytest.approx(0.25, rel=1e-6)
    assert jvp == pytest.approx(0.25, rel=1e-6)              # exact: the downstream map is linear here
    assert info["rank"] == 1                                 # h = (x, 0): the zero column is reported


def test_large_affine_residual_can_be_task_irrelevant():
    g, iid = _residual_net(1e3, [1.0, 0.0])
    rho, virt, jvp, _ = _diag(g, iid, X4)
    assert rho == pytest.approx(0.25e6, rel=1e-9)
    assert virt < 1e-20 and jvp < 1e-15


def test_identity_and_exactly_foldable_implants_have_zero_residual_and_no_virtual_damage():
    G = lambda k: torch_gen(0, "insertion", "v5", k)
    g = build_mlp(6, [8, 8], 3, torch_gen(0, "init"), act="relu").double()
    i_id = E.insert_residual_zero(g, E.cut_at(g, "post_act", 0), G("id"), width=5)       # B = 0: exact identity
    i_lf = E.insert_linear_factor(g, E.cut_at(g, "post_act", 1), G("lf"))                 # affine region
    g.eval()
    X = {"x": torch.randn(200, 6, generator=torch.Generator().manual_seed(1), dtype=F64)}
    for iid in (i_id, i_lf):                                 # zero up to float64 round-off (activations are O(1))
        rho, virt, jvp, _ = _diag(g, iid, X)
        assert rho < 1e-15 and virt < 1e-15 and jvp < 1e-15, (iid, rho, virt, jvp)


# ----------------------------------------------------------------------------- P1: non-mutating, saved, reloadable

def _ctx(tmp_path, cfg):
    tmp_path.mkdir(parents=True, exist_ok=True)
    return SimpleNamespace(dir=tmp_path, cfg=cfg, metric=lambda *a, **k: None)


def test_diagnostics_change_no_state_and_saved_maps_reproduce_the_virtual_risk(tmp_path):
    cfg = T.base()
    bundle = load_bundle(cfg["data"])
    g = build_mlp(8, [16, 16], 3, torch_gen(0, "init"), act="relu")
    G = lambda k: torch_gen(0, "insertion", "v5", k)
    iids = [E.insert_residual_zero(g, E.cut_at(g, "post_act", 0), G("a"), width=4, b_init_scale=0.5),
            E.insert_linear_factor(g, E.cut_at(g, "post_act", 1), G("b"))]
    g.train()
    opt = torch.optim.Adam(g.parameters(), lr=1e-3)
    loss = g(bundle.train.X)[:, 0].pow(2).mean()
    loss.backward()
    opt.step()                                               # optimizer with non-empty state
    grads = {k: p.grad.clone() for k, p in g.named_parameters() if p.grad is not None}
    sd = {k: v.clone() for k, v in g.state_dict().items()}
    ost = {k: {kk: (vv.clone() if torch.is_tensor(vv) else vv) for kk, vv in v.items()}
           for k, v in opt.state_dict()["state"].items()}
    rng = torch.get_rng_state().clone()
    ctx = _ctx(tmp_path / "job", cfg)
    rec = contraction_diagnostics(ctx, g, bundle, iids, "t")
    assert rec["state_unchanged"] and g.training
    assert torch.equal(torch.get_rng_state(), rng)
    assert all(torch.equal(v, g.state_dict()[k]) for k, v in sd.items())
    assert all(torch.equal(grads[k], p.grad) for k, p in g.named_parameters() if p.grad is not None)
    for k, v in opt.state_dict()["state"].items():
        assert all((torch.equal(vv, ost[k][kk]) if torch.is_tensor(vv) else vv == ost[k][kk]) for kk, vv in v.items())
    for iid in iids:
        row = rec["implants"][iid]
        assert "error" not in row, row
        for k in ("rho_raw", "rho_rel_output", "cond", "rank", "jvp_residual", "virtual_affine_damage",
                  "deletion_damage", "fit_seconds", "virtual_seconds", "jvp_seconds"):
            assert k in row, k
    assert rec["implants"][iids[1]]["rho_rel_output"] < 1e-10           # the linear factor is affine
    # calibration on train, scoring on val
    assert rec["calibration"]["partition"] == "train" and rec["scoring"]["partition"] == "val"
    # saved maps reload and reproduce the recorded virtual risk
    maps = torch.load(tmp_path / "job" / rec["maps_file"])
    from cop.experiments.diagnostics import _risk
    for iid in iids:
        vc = virtual_affine_clone(g, iid, maps[iid]["weight"], maps[iid]["bias"])
        vc.eval()
        r = _risk(vc, bundle, ["val", "test"], 4096)
        for p in ("val", "test"):
            assert r[p] == pytest.approx(rec["implants"][iid]["virtual_affine_risk"][p], rel=1e-6, abs=1e-9)
    # idempotent per tag (a resumed job reuses the record) and persisted
    assert contraction_diagnostics(ctx, g, bundle, iids, "t") == rec
    assert "t" in read_json(tmp_path / "job" / "contraction_diagnostics.json")


def test_dissipation_job_records_unchanged_state_diagnostics(tmp_path):
    p = T.traj({"topology": "layered", "rounds": 1})
    d = T.child("dissipation", p[-1], {"dissipation": {"method": "linear", "speed_updates": 6, "post_updates": 6}})
    rd = _run(p + [d], tmp_path)
    rec = read_json(rd / "contraction_diagnostics.json")["dissipation_start"]
    assert rec["state_unchanged"] and rec["implants"]
    assert all("rho_raw" in r and "error" not in r for r in rec["implants"].values() if "skipped" not in r)
    assert (rd / rec["maps_file"]).exists()


def test_diagnostics_refuse_a_state_change(tmp_path, monkeypatch):
    """The before / after comparison is live: a diagnostic that touches the RNG fails the job."""
    import cop.experiments.diagnostics as D
    real = D.jvp_sensitivity

    def leaky(*a, **k):
        torch.rand(1)
        return real(*a, **k)
    monkeypatch.setattr(D, "jvp_sensitivity", leaky)
    cfg = T.base()
    bundle = load_bundle(cfg["data"])
    g = build_mlp(8, [16], 3, torch_gen(0, "init"))
    iid = E.insert_residual_zero(g, E.cut_at(g, "post_act", 0), torch_gen(0, "insertion", "v5", "x"), width=4)
    with pytest.raises(RuntimeError, match="changed the model or RNG"):
        D.contraction_diagnostics(_ctx(tmp_path / "j", cfg), g, bundle, [iid], "t")


# ----------------------------------------------------------------------------- P2: exact solver

@pytest.mark.parametrize("n,k", [(2, 0), (2, 1), (2, 2), (3, 0), (3, 1)])
def test_codebook_solver_equals_exhaustive_encoder_enumeration(n, k):
    a = CB.delayed_query_optimum(n, k)
    b = CB.brute_force(n, k)
    assert a["complete"] and b["complete"]
    assert a["errors"] == b["min_errors"]
    # the reported encoder achieves the reported errors
    assert CB.oracle_errors(np.asarray(a["encoder"]), n) == a["errors"]


def test_exact_optima_match_the_review():
    acc = lambda n, k: 1 - CB.delayed_query_optimum(n, k)["errors"] / (n * 2 ** n)
    assert [acc(3, k) for k in range(4)] == pytest.approx([0.5, 0.75, 5 / 6, 1.0])
    assert [acc(4, k) for k in range(4)] == pytest.approx([0.5, 0.6875, 0.8125, 0.875])
    assert [acc(5, k) for k in range(3)] == pytest.approx([0.5, 0.6875, 0.775])
    tab = read_json(ROOT / "configs" / "finite_interface_optima.json")
    assert tab, "shipped optimum table missing"


def test_original_task_constraint_n3_k1_is_two_thirds_and_matches_brute_force():
    r = CB.retention_optimum(3, 1, "bit:0")
    assert r["complete"] and r["errors"] == 8 and 1 - r["errors"] / 24 == pytest.approx(2 / 3)
    bf = CB.brute_force(3, 1, "bit:0")
    assert bf["min_errors"] == 6 and bf["min_errors_zero_task_error"] == 8
    assert bf["frontier"][0] == {"task_errors": 0, "later_errors": 8}
    for task, n, k in (("bit:0", 3, 2), ("parity:2", 3, 1), ("parity:2", 3, 2), ("bit:0", 2, 1)):
        assert CB.retention_optimum(n, k, task)["errors"] == CB.brute_force(n, k, task)["min_errors_zero_task_error"]


def test_decomposition_closes():
    d = CB.decomposition(8, 8, 6)
    assert (d["decoder_learning_gap"], d["code_gap"], d["excess_total"]) == (0, 2, 2)
    for _ in range(50):
        s = random.randint(0, 10)
        o = s + random.randint(0, 10)
        m = random.randint(0, 30)
        d = CB.decomposition(m, o, s)
        assert d["decoder_learning_gap"] + d["code_gap"] == m - s


# ----------------------------------------------------------------------------- P2: bypass and query gating

DQ = {"name": "delayed_query", "n_train": "full", "params": {"n_bits": 3, "split_mode": "complete"}}
DQ_MODEL = {"family": "mlp", "width": 16, "depth": 3, "query_at_layer": 1}
FIN = {"task_kind": "chain", "n_pearls": 2, "global_updates": 20}


def _fin(tmp_path, peg, model=DQ_MODEL, data=DQ):
    cfgs = T.cop(FIN, {"dim": 1, "mode": "uniform", "bits": 1, **peg}, data=data, model=model)
    return read_json(_run(cfgs, tmp_path) / "cop_chain_result.json")


def test_finite_scores_need_bridge_removed_and_a_query_blind_encoder(tmp_path):
    ok = _fin(tmp_path, {})["finite_interface"]
    assert ok["applicable"] and ok["encoder_query_blind_empirical"] and ok["K_bits"] == 1
    assert ok["e_star"] == 6 and ok["e_oracle"] >= ok["e_star"] and ok["e_model"] >= ok["e_oracle"]
    br = _fin(tmp_path, {"temp_channel": 4, "temp_open_updates": 5, "temp_target": "adapter"})["finite_interface"]
    assert br["applicable"] is False and "around the bottleneck" in br["reason"]
    tmp = _fin(tmp_path, {"temp_channel": 4, "temp_open_updates": 5})
    assert tmp["finite_interface"]["applicable"]                       # temporary bridge retired before scoring
    assert tmp.get("bridge_phases")
    early = _fin(tmp_path, {}, model={**DQ_MODEL, "query_at_layer": -1})["finite_interface"]
    assert early["applicable"] is False and "query" in early["reason"]


# ----------------------------------------------------------------------------- P3: certificate and scope logic

def test_incoming_table_certificate_fails_on_a_changed_unseen_code(tmp_path):
    from cop.cop_pegs.locality import interfaces, incoming_table_certificate
    from cop.cop_pegs.modules import segment_between
    from cop.graph.export import export_compact
    cfgs = T.cop({"task_kind": "locality", "n_pearls": 3, "global_updates": 20, "local_updates": 5,
                  "locality_repair_updates": 5, "locality_eval_points": 2, "locality_interface": "finite_learned"},
                 {"dim": 2, "mode": "uniform", "bits": 1})
    rd = _run(cfgs, tmp_path)
    res = read_json(rd / "locality_result.json")
    cert = res["snapshots"][0]["certificate"]
    assert cert["scope0"]["applicable"] and cert["scope0"]["coverage"] == "every incoming code"
    ck = torch.load(next(rd.glob("**/loc_snap0*.pt")), weights_only=False)
    gx = export_compact(GraphNet.from_checkpoint(ck["model"], "cpu"), fold_linear=False)[0]
    gx.eval()
    itf = interfaces(gx, True, res["cut_indices"])
    q_in, enc, q_out = itf[0]["quant"], itf[1]["enc"], itf[1]["quant"]
    same = incoming_table_certificate(gx, gx.clone(share_params=False), q_in, enc, q_out)
    assert same["all_equal"] and same["n_codes"] == 4
    # change the pearl until some incoming code maps to a different outgoing code
    found = None
    for scale in (0.5, 1.0, 2.0, 4.0, 8.0):
        for sign in (1.0, -1.0):
            h = gx.clone(share_params=False)
            lin = [n for n in h.topo_order(segment_between(h, q_in, enc)) if h.nodes[n].op == "linear"
                   and n in segment_between(h, q_in, enc)]
            with torch.no_grad():
                h.mods[h.nodes[lin[-1]].pkey].bias.add_(sign * scale)
            c = incoming_table_certificate(gx, h, q_in, enc, q_out)
            if 0 < c["n_mismatched"] < c["n_codes"]:
                found = (h, c)
                break
        if found:
            break
    assert found, "no perturbation changed a strict subset of codes"
    h, c = found
    assert not c["all_equal"]
    # a check restricted to the codes that still agree (the 'seen' ones) passes: only full-table coverage
    # catches the changed unseen code
    grid = torch.cartesian_prod(torch.arange(2), torch.arange(2))
    bad = {tuple(x) for x in c["mismatched_codes"]}
    seen = torch.stack([g_ for g_ in grid if tuple(g_.tolist()) not in bad])
    part = incoming_table_certificate(gx, h, q_in, enc, q_out, observed=seen, max_codes=0)
    assert part["all_equal"] and part["coverage"].startswith("observed")


def _row(final_ok, diverged=False, curve_ok=()):
    return {"curve": [{"update": u, "val": {"ok": True}} for u in curve_ok], "final": {"val": {"ok": final_ok}},
            "diverged": diverged}


def test_smallest_successful_scope_ignores_failed_and_diverged_forks_and_records_censoring():
    ok = lambda m: m["ok"]
    rows = {0: _row(False), 1: _row(True, diverged=True, curve_ok=[5]), 2: _row(False), 3: _row(True, curve_ok=[7]),
            4: _row(True, curve_ok=[2])}
    s = scope_summary(rows, ok)
    assert s["smallest_successful_tested_scope"] == 3 and not s["censored"]
    assert s["per_scope"][1]["success_at_end"] is False and s["per_scope"][1]["diverged"]
    assert s["per_scope"][3]["first_update_reaching"] == 7
    s = scope_summary({k: _row(False) for k in range(5)}, ok)
    assert s["smallest_successful_tested_scope"] is None and s["censored"]
    s = scope_summary({0: _row(False), 4: _row(True, diverged=True)}, ok)    # untested scopes are absent
    assert s["censored"] and s["tested_scopes"] == [0, 4]


# ----------------------------------------------------------------------------- P4: dependence game

def _random_game(n, seed):
    r = random.Random(seed)
    d = [0.0] + [r.uniform(-1, 2) for _ in range((1 << n) - 1)]
    return d


def test_shapley_efficiency_symmetry_and_dummy():
    for n in (2, 3, 4):
        d = _random_game(n, n)
        phi = DG.shapley(d, n)
        assert sum(phi) == pytest.approx(d[-1])
        # dummy: player n contributes exactly c to every coalition
        c = 0.3
        e = [0.0] * (1 << (n + 1))
        for S in range(1 << n):
            e[S] = d[S]
            e[S | (1 << n)] = d[S] + c
        assert DG.shapley(e, n + 1)[n] == pytest.approx(c)
        assert DG.shapley(e, n + 1)[:n] == pytest.approx(phi)
        # symmetry: a game that depends on |S| only gives equal values
        f = [float(bin(S).count("1") ** 2) for S in range(1 << n)]
        p = DG.shapley(f, n)
        assert max(p) - min(p) < 1e-12


def test_inverse_pair_has_zero_shapley_nonzero_interaction_and_needs_a_batch_of_two():
    d = [0.0, 1.0, 1.0, 0.0]
    a = DG.analyse_game(d, 2, taus=(0.5,), labels=["a", "b"])
    assert a["shapley"] == {"a": 0.0, "b": 0.0}
    assert a["pair_at_empty"]["a,b"] == -2.0 and a["shapley_interaction"]["a,b"] == -2.0
    assert a["min_batch"]["0.5"] == 2 and a["minmax_path"]["minmax_damage"] == 1.0
    # strong symmetric interactions with greedy optimal
    n = 4
    s = [len_ + 100 * math.comb(len_, 2) for len_ in (bin(S).count("1") for S in range(1 << n))]
    assert all(r["greedy_gap"] == 0 for r in DG.greedy_vs_best([float(v) for v in s], n))


def test_incomplete_or_invalid_landscapes_are_rejected():
    assert DG.analyse_game([0.0, 1.0, None, 0.5], 2)["exact"] is False
    base = {"stage": "final", "info": {"atoms": ["I1", "I2"], "exhaustive": False}, "rows": []}
    assert DG.game_from_deletions(base, "val")["exact"] is False
    m = lambda v: {"metrics": {"val": {"delta_risk": v}}}
    rows = [{"atoms": [], **m(0.0)}, {"atoms": ["I1"], **m(1.0)}, {"atoms": ["I2"], "invalid": "x"},
            {"atoms": ["I1", "I2"], **m(0.5)}]
    full = {"stage": "final", "info": {"atoms": ["I1", "I2"], "exhaustive": True}, "rows": rows}
    r = DG.game_from_deletions(full, "val")
    assert r["exact"] is False and "incomplete" in r["reason"]
    rows[2] = {"atoms": ["I2"], **m(1.0)}
    assert DG.game_from_deletions(full, "val")["exact"] is True
    missing = {**full, "rows": rows[:3]}                     # one coalition never evaluated
    assert DG.game_from_deletions(missing, "val")["exact"] is False


# ----------------------------------------------------------------------------- P0: witness

RELU_T = {"name": "teacher", "n_train": 256, "n_val": 128, "n_test": 128,
          "params": {"teacher_depth": 2, "teacher_width": 12, "activation": "relu", "task": "regression", "d_in": 8,
                     "out_dim": 3}}


def test_witness_reproduces_the_teacher_and_mismatch_is_reported(tmp_path):
    b = T.base(data=RELU_T, model={"family": "mlp", "width": 16, "depth": 4, "act": "relu"})
    w = read_json(_run([b], tmp_path) / "witness.json")
    assert w["realizable"] and w["verification"]["verified"], w
    assert w["verification"]["max_abs_err"] <= 1e-4 and "fresh" in w["verification"]["partitions"]
    assert w["risk"]["test"]["mse"] < 1e-8
    tanh = {**RELU_T, "params": {**RELU_T["params"], "activation": "tanh"}}
    w2 = read_json(_run([T.base(data=tanh, model={"family": "mlp", "width": 16, "depth": 4, "act": "relu"})],
                        tmp_path) / "witness.json")
    assert w2["realizable"] is False and "mismatch" in w2["reason"]
    narrow = read_json(_run([T.base(data=RELU_T, model={"family": "mlp", "width": 8, "depth": 4, "act": "relu"})],
                            tmp_path) / "witness.json")
    assert narrow["realizable"] is False and "width" in narrow["reason"]


# ----------------------------------------------------------------------------- gain retention denominator

def _E(arm, risk, expanded=None, contrast="c"):
    return {"run_id": f"{arm}{risk}{expanded}", "design_contrast": contrast, "f0_run": "f", "replication": "r",
            "design_arm": arm, "kind": "dissipation", "eligible": True, "test_risk": risk,
            "expanded_test_risk": expanded, "task": "regression"}


@pytest.mark.parametrize("den,defined", [(0.0, False), (DELTA / 2, False), (DELTA, False), (-0.2, False),
                                         (0.1, True)])
def test_gain_retention_is_undefined_at_or_below_delta_and_never_clipped(den, defined):
    R_C1 = den                                               # R_expanded = 0, so the denominator is exactly den
    E_ = [_E("C1", R_C1), _E("treated", R_C1 - 0.3, expanded=0.0)]
    row = next(r for r in gain_retention(E_) if r["status"] == "ok")
    assert row["G_numerator"] == pytest.approx(0.3)
    assert row["expansion_gain_denominator"] == pytest.approx(den)
    if defined:
        assert row["retention_eta"] == pytest.approx(3.0)          # > 1: not clipped
        assert row["retention_status"] == "defined"
    else:
        assert row["retention_eta"] is None and row["retention_status"].startswith("undefined")


def test_gain_retention_negative_numerator_is_kept():
    row = next(r for r in gain_retention([_E("C1", 1.0), _E("treated", 1.2, expanded=0.5)]) if r["status"] == "ok")
    assert row["retention_eta"] == pytest.approx(-0.4)


def test_predictor_screen_uses_a_discovery_replication_and_held_out_replications():
    rows = []
    for rep, sign in (("r0", 1), ("r1", 1), ("r2", -1)):
        for i in range(6):
            rows.append({"replication": rep, "family": "F01", "rho_raw": float(i), "G_vs_C1": sign * float(i)})
    s = predictor_screen(rows)
    assert s["discovery_replication"] == "r0" and s["held_out_replications"] == ["r1", "r2"]
    r = s["results"]["rho_raw->G_vs_C1"]
    assert r["discovery_spearman"] == pytest.approx(1.0)
    assert r["held_out_same_sign"] == 1 and r["held_out_n"] == 2
    assert "rho_raw->G_vs_C1" in s["by_family"]["F01"]
    for i, r in enumerate(rows):
        r["topology"] = "layered" if i % 2 else "linear_factor"
    t = predictor_screen(rows)["transfer"]["topology"]["rho_raw->G_vs_C1"]
    assert set(t) == {"layered", "linear_factor"} and all("same_sign" in v for v in t.values())


# ----------------------------------------------------------------------------- fixes from the independent review

def test_expanded_reference_exists_for_snapshot_starts_and_matches_the_parent_at_final(tmp_path):
    from cop.analysis.strengthening import _expanded_state
    from cop.analysis.summarize import load_runs
    TRs = {**T.TRAIN, "snapshot_at": [20]}
    p = T.traj({"topology": "layered", "rounds": 2}, train=TRs)
    sec = {"dissipation": {"method": "linear", "speed_updates": 4, "post_updates": 4}}
    d_snap = T.child("dissipation", p[-1], sec, tags={"parent_stage": "snap_20"})
    d_fin = T.child("dissipation", p[-1], sec)
    _run(p + [d_snap, d_fin], tmp_path)
    runs = load_runs(tmp_path)
    es = _expanded_state(runs, d_snap, "regression", tmp_path / "runs" / run_id(d_snap))
    assert es["expanded_test_risk"] is not None and es["expanded_source"].startswith("contraction_diagnostics")
    ef = _expanded_state(runs, d_fin, "regression", tmp_path / "runs" / run_id(d_fin))
    ep = _expanded_state(runs, d_fin, "regression", None)                   # the parent's own final metrics
    assert ep["expanded_source"] == "parent:final"
    assert ef["expanded_test_risk"] == pytest.approx(ep["expanded_test_risk"], rel=1e-6)
    assert es["expanded_test_risk"] != pytest.approx(ef["expanded_test_risk"], rel=1e-9)   # a different model
    miss = _expanded_state({}, d_snap, "regression", None)
    assert miss["expanded_test_risk"] is None and "missing" in miss["expanded_source"]


def test_gain_retention_without_expanded_risk_is_explicitly_undefined():
    row = next(r for r in gain_retention([_E("C1", 1.0), _E("treated", 0.7, expanded=None)]) if r["status"] == "ok")
    assert row["retention_eta"] is None and row["retention_status"].startswith("undefined: no expanded-model risk")


def test_locality_certificate_covers_the_full_table_of_the_wave7_peg_and_scopes_are_nested(tmp_path):
    cfgs = T.cop({"task_kind": "locality", "n_pearls": 3, "global_updates": 20, "local_updates": 5,
                  "locality_repair_updates": 5, "locality_eval_points": 2, "locality_interface": "finite_learned"},
                 {"dim": 8, "mode": "uniform", "bits": 2})
    res = read_json(_run(cfgs, tmp_path) / "locality_result.json")
    snap = res["snapshots"][0]
    c = snap["certificate"]["scope0"]
    assert c["applicable"] and c["coverage"] == "every incoming code" and c["n_codes"] == 4 ** 8
    tr = [set(snap["scopes"][str(k)]["trainable"]) for k in range(5)]
    # with three pearls the neighbours of the middle pearl are the whole chain, so scope 3 may equal scope 4
    assert all(tr[k] <= tr[k + 1] for k in range(4)) and tr[3] != tr[2]
    assert len(res["checkpoints_fraction_of_endpoint"]) == len(res["checkpoint_updates"])


@pytest.mark.parametrize("n,m", [(2, 3), (3, 3), (3, 5), (3, 6)])
def test_alphabets_that_are_not_a_power_of_two_get_their_exact_optimum(n, m):
    a = CB.delayed_query_optimum(n, 3, messages=m)
    bf = CB.brute_force(n, 3, "bit:0", messages=m, max_encoders=1 << 21)
    assert bf["complete"]
    assert a["messages"] == min(m, 2 ** n) and a["errors"] == bf["min_errors"]
    assert CB.retention_optimum(n, 3, "bit:0", messages=m)["errors"] == bf["min_errors_zero_task_error"]


def test_continuous_locality_arm_and_a_large_later_query_cube_complete(tmp_path):
    """Regressions found by the v5 smoke run: the certificate path for a continuous peg, and the exact-solver
    guards on a 12-bit cube (no huge integers are formed or written)."""
    cfgs = T.cop({"task_kind": "locality", "n_pearls": 3, "global_updates": 20, "local_updates": 5,
                  "locality_repair_updates": 5, "locality_eval_points": 2, "locality_interface": "continuous"},
                 {"dim": 4, "mode": "none"})
    res = read_json(_run(cfgs, tmp_path) / "locality_result.json")
    cert = res["snapshots"][0]["certificate"]
    assert cert["scope0"]["applicable"] is False and "uniform finite" in cert["scope0"]["reason"]
    LQ = {"name": "later_query", "n_train": 256, "n_val": 128, "n_test": 128,
          "params": {"n_bits": 12, "pool_size": 1024, "task_bits": 1}}
    r = read_json(_run(T.cop({}, {"dim": 4, "mode": "uniform", "bits": 2}, data=LQ), tmp_path) / "cop_chain_result.json")
    fi = r.get("finite_interface")
    assert fi is None or "frontier" not in fi


def test_float32_identity_gate_allows_roundoff_but_not_a_real_change():
    """Lab finding (archive v7): a float32 node factorisation changed float32 outputs by max_rel 1.03e-5 on
    digits.  v8 judges the edit in float64 from the stored parameters (tolerance by storage dtype) and checks
    execution stability against a declared bound; a real change of 1e-3 still fails."""
    from cop.experiments import common as Cm
    crit = {"criteria": {"identity_rel_tol_fp32": 1e-5, "identity_rel_tol_fp64": 1e-10}}
    for seed in range(6):
        g = build_mlp(64, [64, 64, 64, 64], 10, torch_gen(seed, "init"))
        sets = {"cal": {"x": 3 * torch.randn(1024, 64, generator=torch.Generator().manual_seed(seed))}}
        lin = [n for n in g.topo_order() if g.nodes[n].op == "linear"][1]
        h = g.clone(share_params=False)
        E.factorize_node(h, lin, torch_gen(seed, "insertion", "v7"))
        chk = Cm.identity_check(g, h, sets, torch.float32, crit)
        assert chk["verdict"] == "exact", chk
        bad = g.clone(share_params=False)
        with torch.no_grad():
            W = bad.mods[bad.nodes[lin].pkey].weight
            W.add_(1e-3 * W.abs().mean() * torch.randn(W.shape, generator=torch.Generator().manual_seed(seed)))
        assert Cm.identity_check(g, bad, sets, torch.float32, crit)["verdict"] == "changed"


# ----------------------------------------------------------------------------- CUDA paths (run on the GPU)

@CUDA
def test_cuda_diagnostics_fit_virtual_jvp_and_reload(tmp_path):
    cfg = T.base()
    bundle = load_bundle(cfg["data"], device="cuda")
    g = build_mlp(8, [16, 16], 3, torch_gen(0, "init"), act="relu").cuda()
    G = lambda k: torch_gen(0, "insertion", "v5", k)
    iids = [E.insert_residual_zero(g, E.cut_at(g, "post_act", 0), G("a"), width=4, b_init_scale=0.5),
            E.insert_linear_factor(g, E.cut_at(g, "post_act", 1), G("b"))]
    g.cuda()
    sd = {k: v.clone() for k, v in g.state_dict().items()}
    crng = [s.clone() for s in torch.cuda.get_rng_state_all()]
    rec = contraction_diagnostics(_ctx(tmp_path / "j", cfg), g, bundle, iids, "t")
    assert rec["state_unchanged"]
    assert all(torch.equal(a, b) for a, b in zip(crng, torch.cuda.get_rng_state_all()))
    assert all(torch.equal(v, g.state_dict()[k]) for k, v in sd.items())
    maps = torch.load(tmp_path / "j" / rec["maps_file"])
    from cop.experiments.diagnostics import _risk
    for iid in iids:
        row = rec["implants"][iid]
        assert "error" not in row and math.isfinite(row["jvp_residual"])
        vc = virtual_affine_clone(g, iid, maps[iid]["weight"].cuda(), maps[iid]["bias"].cuda())
        vc.eval()
        r = _risk(vc, bundle, ["val"], 4096)
        assert r["val"] == pytest.approx(row["virtual_affine_risk"]["val"], rel=1e-5, abs=1e-7)
    assert rec["implants"][iids[1]]["rho_rel_output"] < 1e-6


@CUDA
def test_cuda_v5_jobs(tmp_path):
    """dissipation diagnostics, a finite chain with a temporary bridge, a locality job and the transplant grid."""
    ex = {"device": "cuda"}
    p = T.traj({"topology": "layered", "rounds": 1})
    d = T.child("dissipation", p[-1], {"dissipation": {"method": "linear", "speed_updates": 6, "post_updates": 6}})
    fin = T.cop(FIN, {"dim": 1, "mode": "uniform", "bits": 1, "temp_channel": 4, "temp_open_updates": 5},
                data=DQ, model=DQ_MODEL)
    loc = T.cop({"task_kind": "locality", "n_pearls": 3, "global_updates": 20, "local_updates": 5,
                 "locality_repair_updates": 5, "locality_interface": "finite_stabilized"},
                {"dim": 2, "mode": "uniform", "bits": 1})
    b = T.base()
    tp = resolve({"kind": "transplant", "data": T.DATA, "model": T.MODEL, "train": T.TRAIN, "seeds": {"optimizer": 0},
                  "parents": {"upstream": run_id(b), "downstream": run_id(b)},
                  "transplant": {"upstream_stage": "baseline", "downstream_stage": "baseline", "design": "grid",
                                 "align_families": ["identity", "orthogonal", "affine", "mlp", "affine_task"],
                                 "adapter_updates": 5}})
    for c in p + [d] + fin + loc + [b, tp]:
        assert run_job(c, tmp_path, ex) == "complete", status_of(tmp_path, run_id(c))
    rd = tmp_path / "runs"
    drec = read_json(rd / run_id(d) / "contraction_diagnostics.json")["dissipation_start"]
    assert drec["state_unchanged"] and drec["implants"]
    assert all("error" not in r for r in drec["implants"].values()), drec["implants"]   # per-implant errors are caught
    assert read_json(rd / run_id(fin[-1]) / "cop_chain_result.json")["finite_interface"]["applicable"]
    assert read_json(rd / run_id(loc[-1]) / "locality_result.json")["snapshots"]
    g = read_json(rd / run_id(tp) / "transplant_result.json")
    assert g["info"]["design"] == "grid" and g["contrasts"]
