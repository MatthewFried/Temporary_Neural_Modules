"""v60: the saved after-fold checkpoint and its composition, an acceptance test of fold_unrouted on the training device
(CPU here, CUDA on a GPU machine: both fork ages, both parent arms, the held shortcut column, interruption against an
uninterrupted run, a fresh reload), and the reuse verification's section-by-section comparison."""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "audit_v5" / "tools"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from cop.config import resolve, run_id  # noqa: E402
from cop.utils import read_json  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
FORKS = {"snap_3": 3, "snap_9": 9}                    # the miniature's clock: U = 6, 2U = 12
CUDA = pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA device required")


def _backbone(g):
    return [g.nodes[n] for n in g.topo_order(g.live_nodes()) if g.nodes[n].op == "linear" and g.nodes[n].owner is None]


def _ck(p):
    return torch.load(p, map_location="cpu", weights_only=False)


@pytest.mark.parametrize("parent", ["A_routed_affine", "B_routed_affine"])
@pytest.mark.parametrize("device", ["cpu", pytest.param("cuda", marks=CUDA)])
def test_fold_unrouted_on_the_training_device_cuda(tmp_path, device, parent):
    """(named for the launcher's CUDA selection; its cpu case runs everywhere)  From a trained routed affine parent with
    nonzero offsets, at both fork ages: the fold's saved start is W3 A, b3 + W3 c (float64 algebra) with every other
    layer unchanged and no addition or mask left, and computes the parent's function in the training precision; the
    compact network then trains (the held column stays held); an interrupted run equals an uninterrupted one; a
    fresh process reloads every run."""
    import f0_panel as FP
    import merge_geometry as MG
    from resume_harness import compare_interrupted
    from test_v31 import _diss
    from test_v53 import _traj26
    from cop.graph.graph import GraphNet
    from cop.orchestration.wave13 import V59_CONTS
    dev = os.environ.get("COP_TEST_CUDA_DEVICE", "cuda") if device == "cuda" else "cpu"
    p, T = _traj26(parent)
    for stage, u in FORKS.items():
        d = resolve({**_diss(T, **V59_CONTS["folded_reset"], post_updates=12 - u, early_eval=[], path_eval_points=4),
                     "tags": {"parent_stage": stage}})
        root = tmp_path / stage
        rep = compare_interrupted([p[0], T, d], root, fractions=(0.3, 0.7), ex={"device": dev})
        assert rep["interrupted_at_polls"] and rep["equal"], rep
        A = root / "A"
        rd = A / "runs" / run_id(d)
        res, ep = read_json(rd / "dissipation_result.json"), read_json(rd / "endpoint.json")
        snap = _ck(A / "runs" / run_id(T) / "ckpt" / f"{stage}.pt")
        start = _ck(rd / "ckpt" / "event_after_fold.pt")
        fs = res["fold_start"]
        assert fs["checkpoint"] == "event_after_fold" and fs["update"] == 0
        assert start["lineage"]["param_hash"] == fs["param_hash"] and start["lineage"]["graph_hash"] == fs["graph_hash"]
        assert fs["architecture_hash"] == ep["f0_architecture_hash"] == ep["architecture_hash"]
        assert not start["model"]["spec"]["implants"]
        assert not any(n["op"] == "mask_grad" for n in start["model"]["spec"]["nodes"])
        assert res["grad_masks_removed"] == ["spec_a", "spec_b"]
        # float64 algebra: the exact map of the snapshot's merge, composed into layer 3
        gs = GraphNet.from_checkpoint(snap["model"])
        gs.double()
        gs._plan = None
        L = [nd.pkey for nd in _backbone(gs)]
        sites = FP.layer_sites(gs, L)
        Am, c = MG.exact_merge_map(gs, sites["layer2"], sites["layer2_post_merge"])
        assert float(c.abs().max()) > 0                                         # a nonzero offset
        gf = GraphNet.from_checkpoint(start["model"])
        bf = _backbone(gf)
        assert len(bf) == len(L)
        ss = {k: v.double() for k, v in snap["model"]["state"].items()}
        sf = {k: v.double() for k, v in start["model"]["state"].items()}
        W3, b3 = ss[f"mods.{L[2]}.weight"], ss[f"mods.{L[2]}.bias"]
        Wf, bfold = sf[f"mods.{bf[2].pkey}.weight"], sf[f"mods.{bf[2].pkey}.bias"]
        assert torch.allclose(Wf, W3 @ Am, rtol=1e-5, atol=1e-6)
        assert torch.allclose(bfold, b3 + W3 @ c, rtol=1e-5, atol=1e-6)
        for i, nd in enumerate(bf):
            if i != 2:
                assert torch.equal(start["model"]["state"][f"mods.{nd.pkey}.weight"],
                                   snap["model"]["state"][f"mods.{L[i]}.weight"])
                assert torch.equal(start["model"]["state"][f"mods.{nd.pkey}.bias"],
                                   snap["model"]["state"][f"mods.{L[i]}.bias"])
        # the operational check, in the training precision on the training device
        g0 = GraphNet.from_checkpoint(snap["model"], torch.device(dev)).eval()
        g1 = GraphNet.from_checkpoint(start["model"], torch.device(dev)).eval()
        X = {"x": torch.randn(256, 17, generator=torch.Generator().manual_seed(5)).to(dev)}
        with torch.no_grad():
            z0, z1 = g0(X), g1(X)
        assert z1.dtype == z0.dtype == torch.float32
        assert float((z1 - z0).abs().max()) <= 1e-5 * max(1.0, float(z0.abs().max()))
        pa = next(x for x in res["path"] if x["tag"] == "after_fold")
        assert pa["val_kl_receiver_to_model"] <= 1e-8
        # compact training took its steps from that start
        end = _ck(rd / "ckpt" / "export.pt")
        assert int(ep["updates"]) == 12 - u and int(res["schedule_audit"]["updates_total"]) == 12 - u
        assert any(not torch.equal(end["model"]["state"][k], start["model"]["state"][k])
                   for k in start["model"]["state"])
        w1 = f"mods.{L[0]}.weight"
        if parent.startswith("B"):
            assert torch.equal(end["model"]["state"][w1][:, 8], snap["model"]["state"][w1][:, 8])
        # a fresh process reloads every run of the chain on its recorded device
        rl = subprocess.run([sys.executable, str(ROOT / "audit_v5/tools/fresh_reload.py"), str(A),
                             str(tmp_path / f"rl_{stage}.json"), "--device", "recorded"],
                            capture_output=True, text=True, env=dict(os.environ))
        assert rl.returncode == 0, rl.stdout[-2000:] + rl.stderr[-2000:]


# ----------------------------------------------------------------------------- the reuse verification

def _write(d, ck):
    (d / "ckpt").mkdir(parents=True, exist_ok=True)
    torch.save(ck, d / "ckpt" / "s.pt")
    (d / "status.json").write_text(json.dumps({"status": "complete"}))
    (d / "endpoint.json").write_text(json.dumps({"checkpoint_param_hash": "h"}))


def _real_ck():
    """a real snapshot checkpoint of a routed affine trajectory with its optimizer state."""
    from test_v15 import _run
    from test_v53 import _traj26
    import tempfile
    p, T = _traj26("A_routed_affine")
    root = Path(tempfile.mkdtemp())
    _run([p[0], T], root)
    return _ck(root / "runs" / run_id(T) / "ckpt" / "snap_9.pt")


@pytest.fixture(scope="module")
def ck0():
    return _real_ck()


def _compare(tmp_path, a, b):
    import reuse_reproduce as RR
    pa, pb = tmp_path / "pa", tmp_path / "pb"
    _write(pa / "runs" / "r", a)
    _write(pb / "runs" / "r", b)
    sub = tmp_path / "s.jsonl"
    sub.write_text(json.dumps({"run_id": "r", "cfg": {}}) + "\n")
    rc = RR.compare(str(sub), pa, pb, tmp_path / "c.json")
    return rc, read_json(tmp_path / "c.json")["jobs"]["r"]["differing"]


def test_the_comparison_sees_the_graph_not_only_the_weights(tmp_path, ck0):
    import copy
    rc, diff = _compare(tmp_path, ck0, copy.deepcopy(ck0))
    assert rc == 0 and diff == {}
    # the same tensors, another merge coefficient
    b = copy.deepcopy(ck0)
    add = next(n for n in b["model"]["spec"]["nodes"] if n["op"] == "add")
    assert add["attrs"]
    key = next(k for k, v in add["attrs"].items() if isinstance(v, list) and v and isinstance(v[0], (int, float)))
    add["attrs"][key] = [x * 0.5 for x in add["attrs"][key]] if not isinstance(add["attrs"][key][0], bool) else \
        [not x for x in add["attrs"][key]]
    rc, diff = _compare(tmp_path, ck0, b)
    assert rc == 1 and diff == {"s": ["model"]}
    # the same tensors, a gate value
    b = copy.deepcopy(ck0)
    b["model"]["spec"]["gate_vals"] = {"g1": 0.5}
    rc, diff = _compare(tmp_path, ck0, b)
    assert rc == 1 and diff == {"s": ["model"]}
    # the same values in another dtype
    b = copy.deepcopy(ck0)
    k = next(iter(b["model"]["state"]))
    b["model"]["state"][k] = b["model"]["state"][k].double()
    rc, diff = _compare(tmp_path, ck0, b)
    assert rc == 1 and diff == {"s": ["model"]}


def test_the_comparison_sees_the_optimizer_state_by_name(tmp_path, ck0):
    import copy
    st = ck0["trainer"]["opt"]["state"]
    i = next(iter(st))
    # one Adam moment
    b = copy.deepcopy(ck0)
    b["trainer"]["opt"]["state"][i]["exp_avg"] = b["trainer"]["opt"]["state"][i]["exp_avg"] + 1e-9
    rc, diff = _compare(tmp_path, ck0, b)
    assert rc == 1 and diff == {"s": ["optimizer"]}
    # one step counter
    b = copy.deepcopy(ck0)
    b["trainer"]["opt"]["state"][i]["step"] = b["trainer"]["opt"]["state"][i]["step"] + 1
    rc, diff = _compare(tmp_path, ck0, b)
    assert rc == 1 and diff == {"s": ["optimizer"]}
    # the same state under swapped parameter names is another state
    b = copy.deepcopy(ck0)
    names = b["trainer"]["opt_param_names"]
    names[0], names[1] = names[1], names[0]
    rc, diff = _compare(tmp_path, ck0, b)
    assert rc == 1 and diff == {"s": ["optimizer"]}
    # the sampler's position, and wall-clock fields are excluded
    b = copy.deepcopy(ck0)
    b["trainer"]["state"]["pos"] = b["trainer"]["state"]["pos"] + 1
    rc, diff = _compare(tmp_path, ck0, b)
    assert rc == 1 and diff == {"s": ["trainer"]}
    b = copy.deepcopy(ck0)
    b["trainer"]["timing"] = {"train_seconds": 123.0}
    b["lineage"]["code_hash"] = "x"
    rc, diff = _compare(tmp_path, ck0, b)
    assert rc == 0 and diff == {}


def test_selection_covers_every_audited_class_and_reports_a_missing_ancestor(tmp_path):
    import reuse_reproduce as RR
    from cop.utils import semantic_code_hash
    sem = semantic_code_hash()

    def cfg(kind, parents=None, method=None, arm=None, stage=None):
        c = {"kind": kind, "parents": parents or {}}
        if method:
            c["dissipation"] = {"method": method}
        if arm:
            c["design"] = {"arm": arm}
        if stage:
            c["tags"] = {"parent_stage": stage}
        return c
    ents = {"b1": cfg("baseline"), "t1": cfg("trajectory", {"baseline": "b1"}),
            "t2": cfg("trajectory", {"baseline": "b1"}),
            "f1": cfg("dissipation", {"trajectory": "t1"}, "keep", "routed_reset", "snap_9"),
            "f2": cfg("dissipation", {"trajectory": "t2"}, "keep", "frozen_reset", "snap_3")}
    man = tmp_path / "m.jsonl"
    man.write_text("".join(json.dumps({"run_id": r, "cfg": c}) + "\n" for r, c in ents.items()))
    for r in ents:
        d = tmp_path / "p" / "runs" / r
        d.mkdir(parents=True)
        (d / "reuse_accepted.jsonl").write_text(json.dumps({"accepted_for_semantic_hash": sem, "audit_id": "a",
                                                            "user": "seed_panel (audited)"}) + "\n")
    assert RR.select(str(man), tmp_path / "p", tmp_path / "s.jsonl") == 0
    got = [json.loads(x)["run_id"] for x in (tmp_path / "s.jsonl").read_text().splitlines()]
    assert got == ["b1", "t1", "t2", "f1", "f2"]            # frozen_reset's class pulls t2 in as its ancestor
    # an audited run whose ancestor is not in the manifest is a coverage error, not "nothing to verify"
    man.write_text("".join(json.dumps({"run_id": r, "cfg": c}) + "\n" for r, c in ents.items() if r != "t2"))
    assert RR.select(str(man), tmp_path / "p", tmp_path / "s2.jsonl") == 1
