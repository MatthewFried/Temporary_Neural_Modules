"""v60: the wave-28 fork panel launcher (scripts/60, which replaces scripts/58 and 59).  It TRAINS: environment, manifest (a
failed generation cannot fall through to a stale file), validation, CPU tests, on a CUDA device the training code's
CUDA tests (run, none skipped); then it seeds the panel folder under the reuse audits (the v59, v58 and v53 panels,
only read; SEED=0 copies nothing in that attempt), verifies every audited copy in the panel by retraining a sample in
its own folder, and trains the rest ONLY when that verification passed or there is no audited copy; checks the v53 wave-26 panel is complete
under the audit (read only) and runs the merge geometry on it; checks and reloads every wave-28 job and runs the fork
analysis; both analyses on the CPU; evidence; packaging whatever happens.  The real script runs in the v48 launcher
test's mock COP_HOME."""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import test_v48_launcher as L  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = "60_v60_fork_panel.sh"
SRC = (ROOT / "scripts" / SCRIPT).read_text()
FILES = {k: re.search(rf'^{k}="([^"]+)"', SRC, re.M).group(1).split(",") for k in ("FORK_FILES", "GEOM_FILES")}
PREFIX = {"FORK_FILES": "fork28", "GEOM_FILES": "geometry26"}
LARGE = re.search(r'^LARGE="([^"]+)"', SRC, re.M).group(1).split()
TOOL = r"""import json, os, sys
tool = os.path.basename(sys.argv[0])[:-3]
name = {"fork_continuation": "fork28", "merge_geometry": "geometry26"}[tool]
panel, prefix = sys.argv[1], sys.argv[2]
want_panel = "results/panel28" if name == "fork28" else "cop_results_v53/panel26"
assert panel.endswith(want_panel) and prefix.endswith("v60_reports/" + name), sys.argv
want_man = "wave28_full.jsonl" if name == "fork28" else "wave26_full.jsonl"
assert "--strict" in sys.argv and sys.argv[sys.argv.index("--manifest") + 1].endswith(want_man)
assert sys.argv[sys.argv.index("--device") + 1] == "cpu"
assert os.environ.get("CUDA_VISIBLE_DEVICES", "unset") == "", os.environ.get("CUDA_VISIBLE_DEVICES")
ev = open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a")
ev.write(name + " read " + panel + "\n")
rc = int(os.environ.get("MOCK_RC_" + name, "0"))
for t in os.environ["MOCK_FILES_" + name].split(","):
    if t.endswith(".json"):
        json.dump({"passed": rc == 0}, open(prefix + "_" + t, "w"))
        continue
    empty = os.environ.get("MOCK_EMPTY") == name + ":" + t
    big = os.environ.get("MOCK_BIG") == name + ":" + t
    open(prefix + "_" + t, "w").write("empty\n" if empty else "variant,x\n" + "B,1\n" * (2500000 if big else 1))
sys.exit(rc)
"""
PANEL_STATE = """import json, os, sys
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write("panel_state " + sys.argv[2] + "\\n")
assert sys.argv[1].endswith("wave26_full.jsonl") and sys.argv[2].endswith("cop_results_v53/panel26"), sys.argv
assert sys.argv[3] == "--audited" and sys.argv[4].endswith("configs/reuse_audits.json"), sys.argv
sys.exit(int(os.environ.get("MOCK_PANEL_STATE", "0")))
"""
REPORT = r"""import json, os, sys
name = os.path.basename(sys.argv[0])
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write(name + " " + " ".join(sys.argv[1:4]) + "\n")
if name == "runtime_v13.py":                      # runtime_v13.py fit MANIFEST RESULTS OUT
    assert sys.argv[1] == "fit" and sys.argv[3].endswith("panel28")
    out = sys.argv[4]
else:                                             # <tool> RESULTS OUT ...
    assert sys.argv[1].endswith("panel28") and ("--manifest" in sys.argv or name == "fresh_reload.py")
    out = sys.argv[2]
json.dump({"passed": True}, open(out, "w"))
"""
SEED = r"""import json, os, sys
man, src, dst, out = sys.argv[1:5]
assert man.endswith("wave28_full.jsonl") and dst.endswith("results/panel28"), sys.argv
assert any(out.endswith(f"v60_reports/{n}.json") for n in ("seed28", "seed28_v58", "seed28_v59")), sys.argv
assert sys.argv[5] == "--audited" and sys.argv[6].endswith("configs/reuse_audits.json"), sys.argv
which = "v59" if out.endswith("seed28_v59.json") else "v58" if out.endswith("seed28_v58.json") else "v53"
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write("seed " + src + " -> " + dst + "\n")
json.dump({"source": src, "n_copied": 264}, open(out, "w"))
sys.exit(int(os.environ.get("MOCK_SEED_RC_" + which, "0")))
"""
REUSE = r"""import json, os, sys
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write("reuse " + " ".join(sys.argv[1:]) + "\n")
if sys.argv[1] == "select":
    man, panel, sub = sys.argv[2:5]
    assert man.endswith("wave28_full.jsonl") and panel.endswith("results/panel28") and sub.endswith("reuse_sample.jsonl")
    rc = int(os.environ.get("MOCK_REUSE_SELECT_RC", "0"))
    if rc == 0:
        open(sub, "w").write('{"run_id": "base-x"}\n')
    sys.exit(rc)
sub, panel, scratch, out = sys.argv[2:6]
assert sub.endswith("reuse_sample.jsonl") and panel.endswith("results/panel28") and scratch.endswith("reuse_check")
json.dump({"reproduced": True}, open(out, "w"))
sys.exit(int(os.environ.get("MOCK_REUSE_COMPARE_RC", "0")))
"""
PYTEST = r'''#!/usr/bin/env bash
echo "pytest $*" >> "$MOCK_HOME/events.txt"
echo "3 passed"
xml=""; prev=""
for a in "$@"; do [ "$prev" = "--junitxml" ] && xml="$a"; prev="$a"; done
junit() { [ -n "$xml" ] && echo "<testsuites><testsuite tests=\"$1\" skipped=\"$2\" failures=\"0\" errors=\"0\"/></testsuites>" > "$xml"; }
case " $* " in
  *" -k cuda or gpu_equivalence "*)
    junit 5 "${MOCK_SUITE_SKIPPED:-0}"
    echo "cuda suite device $COP_TEST_CUDA_DEVICE" >> "$MOCK_HOME/events.txt"
    exit "${MOCK_SUITE_RC:-0}" ;;
esac
junit 3 0
exit "${MOCK_TEST_RC:-0}"
'''
# v60: the reproduction's run (results .../reuse_check) has its own switch, MOCK_REUSE_RUN_RC
COMMON = L.COMMON.replace('      return "${MOCK_RUN_RC:-0}" ;;',
                          '      case "$5" in *reuse_check) return "${MOCK_REUSE_RUN_RC:-0}" ;; esac\n'
                          '      return "${MOCK_RUN_RC:-0}" ;;')
assert COMMON != L.COMMON
AFTER_RUN = ("status28", "checks28", "reload28", "summary28", "rates28", "fork28")
ANALYSES = ("fork28", "geometry26")


@pytest.fixture
def h(tmp_path):
    home = tmp_path / "home"
    (home / "scripts").mkdir(parents=True)
    shutil.copy2(ROOT / "scripts" / SCRIPT, home / "scripts" / SCRIPT)
    for f in ("package_reports.py", "check_evidence.py", "junit_ran.py"):
        shutil.copy2(ROOT / "scripts" / f, home / "scripts" / f)
    (home / "scripts/seed_panel.py").write_text(SEED)
    (home / "scripts/reuse_reproduce.py").write_text(REUSE)
    (home / "scripts/panel_state.py").write_text(PANEL_STATE)
    (home / "scripts/common.sh").write_text(COMMON)
    (home / "audit_v5/tools").mkdir(parents=True)
    (home / "audit_v8/tools").mkdir(parents=True)
    for name in ("fork_continuation.py", "merge_geometry.py"):
        (home / "audit_v5/tools" / name).write_text(TOOL)
    for name in ("fresh_reload.py", "runtime_v13.py"):
        (home / "audit_v5/tools" / name).write_text(REPORT)
    (home / "audit_v8/tools/check_results.py").write_text(REPORT)
    pt = home / "fake_pytest.sh"
    pt.write_text(PYTEST)
    pt.chmod(0o755)
    zipdir = tmp_path / "zips"
    zipdir.mkdir()
    base = {k: v for k, v in os.environ.items() if k not in ("DIAGNOSTIC_OVERRIDE", "COP_PYTEST", "SEED",
                                                              "SEED_FROM", "SEED_FROM58", "SEED_FROM59",
                                                              "V53_RESULTS", "V58_RESULTS", "V59_RESULTS")}
    (tmp_path / "cop_results_v53").mkdir()                      # the v53 results folder exists (only read)
    (tmp_path / "cop_results_v58").mkdir()                      # the v58 results folder exists (only read)
    (tmp_path / "cop_results_v59").mkdir()                      # the v59 results folder exists (only read)
    env = dict(base, MOCK_HOME=str(home), COP_RESULTS=str(tmp_path / "results"), ZIP_DIR=str(zipdir), SCALE="full",
               HOME=str(tmp_path), COP_PYTEST=str(pt), V53_RESULTS=str(tmp_path / "cop_results_v53"),
               V58_RESULTS=str(tmp_path / "cop_results_v58"), V59_RESULTS=str(tmp_path / "cop_results_v59"),
               **{f"MOCK_FILES_{PREFIX[k]}": ",".join(v) for k, v in FILES.items()})
    return {"home": home, "res": tmp_path / "results", "zip": zipdir / "cop_v60_panel_reports.zip", "env": env,
            "tmp": tmp_path}


def _sh(h, common=None, **env):
    if common is not None:
        (h["home"] / "scripts/common.sh").write_text(common)
    e = dict(h["env"], **{k: str(v) for k, v in env.items()})
    return subprocess.run(["bash", str(h["home"] / "scripts" / SCRIPT)], env=e, capture_output=True, text=True,
                          cwd=str(h["home"]))


def _verdict(h):
    return json.loads((h["res"] / "v60_reports/verdict.json").read_text())


def _events(h):
    p = h["home"] / "events.txt"
    return p.read_text() if p.exists() else ""


SEEDING = ["seed28_v59", "seed28_v58", "seed28", "reuse_select", "reuse_run", "reuse_compare"]
ORDER = ["environment", "manifest28", "validate28", "cpu_tests", *SEEDING, "run28", "manifest26", "panel_source26",
         "geometry26", *AFTER_RUN, "evidence28", "manifest_copy", "manifest_copy26", "package", "package_final"]


def test_success_seeds_trains_checks_and_analyses(h):
    r = _sh(h)
    assert r.returncode == 0, r.stdout + r.stderr
    v = _verdict(h)
    assert v["all_passed"] and list(v["steps"]) == ORDER
    ev = _events(h)
    panel = str(h["res"] / "panel28")
    v53 = f"{h['tmp']}/cop_results_v53/panel26"
    v58 = f"{h['tmp']}/cop_results_v58/panel28"
    v59 = f"{h['tmp']}/cop_results_v59/panel28"
    assert ev.index(f"seed {v59} -> {panel}\n") < ev.index(f"seed {v58} -> {panel}\n") < \
        ev.index(f"seed {v53} -> {panel}\n")
    runs = [ln for ln in ev.splitlines() if ln.startswith("cop run ")]
    assert len(runs) == 2
    chk, run = runs
    assert f"--results {h['res']}/reuse_check" in chk and "reuse_sample.jsonl" in chk and "--resume" in chk
    assert f"--results {panel}" in run and "wave28_full.jsonl" in run and "--resume" in run and "--device cpu" in run
    assert ev.index("reuse select") < ev.index(chk) < ev.index("reuse compare") < ev.index(run)
    assert "cop generate-manifest --wave 28 --scale full" in ev and "cop generate-manifest --wave 26" in ev
    assert "cop summarize --strict" in ev and f"panel_state {v53}\n" in ev
    order = [ev.index(x) for x in ("cop generate-manifest --wave 28", "cop validate-manifest", "\npytest ", "seed ",
                                   "cop run ", "cop generate-manifest --wave 26", "panel_state", "geometry26 read",
                                   "cop status", "check_results.py", "fresh_reload.py", "cop summarize",
                                   "runtime_v13.py", "fork28 read")]
    assert order == sorted(order)
    assert f"fork28 read {panel}\n" in ev and f"geometry26 read {v53}\n" in ev
    names = zipfile.ZipFile(h["zip"]).namelist()
    for k, fs in FILES.items():
        for f in fs:
            if f in LARGE:
                continue
            assert f"cop_v60_panel_reports/v60_reports/{PREFIX[k]}_{f}" in names, (k, f)
    for f in ("evidence28.json", "checks28.json", "fresh_reload28.json", "wave28_full.jsonl", "wave26_full.jsonl",
              "rates28.json", "seed28.json", "seed28_v58.json", "seed28_v59.json", "reuse_sample.jsonl",
              "reuse_check.json"):
        assert f"cop_v60_panel_reports/v60_reports/{f}" in names, f
    assert "cop_v60_panel_reports/summary28/s.csv" in names
    # nothing is written outside its own results folder, the archive folder and the manifest folder; the v53
    # folder is only read
    assert {p_.name for p_ in h["tmp"].iterdir()} == {"home", "results", "zips", "cop_results_v53", "cop_results_v58",
                                                      "cop_results_v59"}
    assert all(not list((h["tmp"] / f"cop_results_v5{k}").iterdir()) for k in (3, 8, 9))


def test_the_seed_source_can_be_pointed_elsewhere_or_switched_off(h):
    r = _sh(h, SEED_FROM=h["tmp"] / "x" / "p")
    assert r.returncode == 0 and f"seed {h['tmp']}/x/p -> " in _events(h)
    (h["home"] / "events.txt").unlink()
    r = _sh(h, SEED_FROM58=h["tmp"] / "y" / "q")
    assert r.returncode == 0 and f"seed {h['tmp']}/y/q -> " in _events(h)
    (h["home"] / "events.txt").unlink()
    r = _sh(h, SEED_FROM59=h["tmp"] / "z" / "s")
    assert r.returncode == 0 and f"seed {h['tmp']}/z/s -> " in _events(h)
    (h["home"] / "events.txt").unlink()
    # SEED=0 copies nothing in this attempt, but copies an earlier attempt made stay in the panel, so they are still
    # verified before anything trains
    r = _sh(h, SEED=0)
    assert r.returncode == 0, r.stdout + r.stderr
    ev = _events(h)
    v = _verdict(h)
    assert "seed " not in ev and "reuse select" in ev and "reuse compare" in ev and ev.count("cop run ") == 2
    assert all(v["steps"][k] == 0 for k in SEEDING)
    assert "SEED=0" in (h["res"] / "v60_reports/seed28.txt").read_text()
    assert "cop_v60_panel_reports/v60_reports/seed28.json" not in zipfile.ZipFile(h["zip"]).namelist()


def test_no_audited_copy_needs_no_verification_and_trains(h):
    r = _sh(h, MOCK_REUSE_SELECT_RC=5)
    assert r.returncode == 0, r.stdout + r.stderr
    v = _verdict(h)
    assert v["all_passed"] and v["steps"]["reuse_run"] == 0 and v["steps"]["reuse_compare"] == 0
    assert v["steps"]["run28"] == 0
    ev = _events(h)
    assert "reuse compare" not in ev and ev.count("cop run ") == 1
    assert "no audited copy" in (h["res"] / "v60_reports/reuse_run.txt").read_text()


@pytest.mark.parametrize("env, failed", [({"MOCK_REUSE_COMPARE_RC": 1}, "reuse_compare"),
                                         ({"MOCK_REUSE_RUN_RC": 1}, "reuse_run"),
                                         ({"MOCK_REUSE_SELECT_RC": 1}, "reuse_select")])
def test_a_failed_reuse_verification_trains_nothing_and_packages_the_diagnostics(h, env, failed):
    r = _sh(h, **env)
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"][failed] == 1 and not v["all_passed"]
    assert v["steps"]["run28"] == 99 and all(v["steps"][k] == 99 for k in AFTER_RUN)
    assert "did not pass" in (h["res"] / "v60_reports/run28.txt").read_text()
    ev = _events(h)
    assert not any(f"--results {h['res']}/panel28" in ln for ln in ev.splitlines() if ln.startswith("cop run "))
    assert v["steps"]["geometry26"] == 0                        # it reads the v53 panel, not this one
    names = zipfile.ZipFile(h["zip"]).namelist()
    for k in ("reuse_select", "reuse_run", "reuse_compare", "run28"):
        assert f"cop_v60_panel_reports/v60_reports/{k}.txt" in names
    if failed == "reuse_compare":
        assert "cop_v60_panel_reports/v60_reports/reuse_check.json" in names
    if failed == "reuse_run":
        assert v["steps"]["reuse_compare"] == 99


@pytest.mark.parametrize("which", ["v59", "v58", "v53"])
def test_a_failed_copy_stops_before_training_and_the_geometry_still_runs(h, which):
    r = _sh(h, **{f"MOCK_SEED_RC_{which}": 1})
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"]["seed28"] == 1 and v["steps"]["run28"] == 99
    assert all(v["steps"][k] == 99 for k in ("reuse_select", "reuse_run", "reuse_compare"))
    assert all(v["steps"][k] == 99 for k in AFTER_RUN) and "cop run " not in _events(h) and h["zip"].exists()
    assert v["steps"]["geometry26"] == 0          # it reads the v53 panel, not this one


def test_an_incomplete_v53_panel_skips_the_geometry_only(h):
    r = _sh(h, MOCK_PANEL_STATE=4)
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"]["panel_source26"] == 4 and v["steps"]["geometry26"] == 99
    assert v["steps"]["run28"] == 0 and v["steps"]["fork28"] == 0
    assert "geometry26 read" not in _events(h)


@pytest.mark.parametrize("device", ["cuda", "cuda:1"])
def test_on_cuda_the_training_codes_cuda_tests_run_first_and_the_analyses_stay_on_the_cpu(h, device):
    cuda = COMMON.replace("DEVICE=cpu", f"DEVICE={device}")
    r = _sh(h, common=cuda)
    assert r.returncode == 0, r.stdout + r.stderr
    v = _verdict(h)
    assert list(v["steps"])[:13] == ["environment", "manifest28", "validate28", "cpu_tests", "cuda_tests",
                                     "cuda_tests_ran", *SEEDING, "run28"]
    ev = _events(h)
    assert f"cuda suite device {device}" in ev and ev.index("cuda suite device") < ev.index("seed ")
    assert all(f"--device {device}" in ln for ln in ev.splitlines() if ln.startswith("cop run "))
    for t in ANALYSES:                                       # the mock tool asserts CUDA is hidden and --device cpu
        assert v["steps"][t] == 0


def test_a_skipped_or_failed_cuda_test_stops_before_seeding_and_training(h):
    cuda = COMMON.replace("DEVICE=cpu", "DEVICE=cuda")
    for env in ({"MOCK_SUITE_SKIPPED": 2}, {"MOCK_SUITE_RC": 1}):
        if (h["home"] / "events.txt").exists():
            (h["home"] / "events.txt").unlink()
        r = _sh(h, common=cuda, **env)
        assert r.returncode != 0
        v = _verdict(h)
        assert v["steps"]["seed28"] == 99 and v["steps"]["run28"] == 99 and v["steps"]["geometry26"] == 99
        assert all(v["steps"][k] == 99 for k in SEEDING)
        ev = _events(h)
        assert "seed " not in ev and "cop run " not in ev and " read " not in ev and "reuse " not in ev


@pytest.mark.parametrize("env, step", [({"MOCK_ENV_RC": 1}, "environment"), ({"MOCK_MANIFEST_RC": 1}, "manifest28"),
                                       ({"MOCK_VALIDATE_RC": 1}, "validate28"), ({"MOCK_TEST_RC": 1}, "cpu_tests")])
def test_a_failed_prerequisite_trains_and_analyses_nothing(h, env, step):
    stale = h["home"] / "manifests/wave28_full.jsonl"
    stale.parent.mkdir(parents=True, exist_ok=True)
    stale.write_text('{"run_id": "stale"}\n')
    r = _sh(h, **env)
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"][step] == 1 and v["steps"]["run28"] == 99 and v["steps"]["seed28"] == 99
    assert v["steps"]["geometry26"] == 99
    ev = _events(h)
    assert "cop run " not in ev and "seed " not in ev and " read " not in ev and h["zip"].exists()
    if step == "manifest28":
        assert not stale.exists() and v["steps"]["validate28"] == 99


def test_an_unfinished_panel_reports_its_status_and_analyses_nothing_of_it(h):
    r = _sh(h, MOCK_RUN_RC=1)
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"]["run28"] == 1 and v["steps"]["status28"] == 0
    assert all(v["steps"][k] == 99 for k in AFTER_RUN[1:])
    ev = _events(h)
    assert "cop status" in ev and "fork28 read" not in ev and "check_results.py" not in ev and h["zip"].exists()
    assert v["steps"]["geometry26"] == 0


@pytest.mark.parametrize("step", ANALYSES)
def test_a_failed_analysis_fails_the_launcher_and_the_other_still_runs(h, step):
    r = _sh(h, **{f"MOCK_RC_{step}": 1})
    assert r.returncode != 0
    v = _verdict(h)
    other = next(k for k in ANALYSES if k != step)
    assert v["steps"][step] == 1 and v["steps"][other] == 0
    ev = json.loads((h["res"] / "v60_reports/evidence28.json").read_text())
    assert ev["steps"][step]["ok"] is None and ev["steps"][other]["ok"] is True
    names = zipfile.ZipFile(h["zip"]).namelist()
    k_other = next(k for k in FILES if PREFIX[k] == other)
    assert all(f"cop_v60_panel_reports/v60_reports/{other}_{f}" in names for f in FILES[k_other] if f not in LARGE)


@pytest.mark.parametrize("step, table", [("fork28", "states.csv"), ("geometry26", "maps_summary.csv"),
                                         ("geometry26", "transport.csv")])
def test_an_empty_required_table_fails_the_evidence(h, step, table):
    r = _sh(h, MOCK_EMPTY=f"{step}:{table}")
    assert r.returncode != 0
    ev = json.loads((h["res"] / "v60_reports/evidence28.json").read_text())
    assert ev["steps"][step]["missing"] == [f"{step}_{table} (an empty table)"]
    assert _verdict(h)["steps"]["evidence28"] == 1


@pytest.mark.parametrize("step, table", [("fork28", "contrasts.csv"), ("geometry26", "probes.csv")])
def test_a_large_per_row_table_stays_on_disk(h, step, table):
    assert table in LARGE
    r = _sh(h, MOCK_BIG=f"{step}:{table}")
    assert r.returncode == 0, r.stdout + r.stderr
    assert (h["res"] / "v60_reports" / f"{step}_{table}").stat().st_size > 8 * 2 ** 20
    names = zipfile.ZipFile(h["zip"]).namelist()
    base = "cop_v60_panel_reports/v60_reports/"
    assert f"{base}{step}_{table}" not in names and f"{base}{step}_{table[:-4]}_summary.csv" in names


def test_a_rerun_cannot_reuse_the_previous_runs_tables(h):
    assert _sh(h).returncode == 0
    r = _sh(h, MOCK_RUN_RC=1, MOCK_PANEL_STATE=4)
    assert r.returncode != 0
    for t in ANALYSES:
        assert not list((h["res"] / "v60_reports").glob(f"{t}_*")), t


def test_the_script_writes_its_own_results_only_and_reads_the_earlier_panels_through_named_steps():
    assert 'COP_RESULTS="${COP_RESULTS:-$HOME/cop_results_v60}"' in SRC
    code = [ln.strip() for ln in SRC.splitlines() if not ln.lstrip().startswith("#")]
    assert [ln for ln in code if "cop_results_v53" in ln] == [
        'SEED_FROM="${SEED_FROM:-${V53_RESULTS:-$HOME/cop_results_v53}/panel26}"',
        'GEOM_PANEL="${V53_RESULTS:-$HOME/cop_results_v53}/panel26"']
    assert [ln for ln in code if "cop_results_v58" in ln] == [
        'SEED_FROM58="${SEED_FROM58:-${V58_RESULTS:-$HOME/cop_results_v58}/panel28}"']
    assert [ln for ln in code if "cop_results_v59" in ln] == [
        'SEED_FROM59="${SEED_FROM59:-${V59_RESULTS:-$HOME/cop_results_v59}/panel28}"']
    assert [ln for ln in code if '"$SEED_FROM59"' in ln] == [
        'step seed28_v59 python scripts/seed_panel.py "$m28" "$SEED_FROM59" "$P" "$O/seed28_v59.json" --audited '
        '"$AUDITS"']
    assert [ln for ln in code if '"$SEED_FROM"' in ln] == [
        'step seed28 python scripts/seed_panel.py "$m28" "$SEED_FROM" "$P" "$O/seed28.json" --audited "$AUDITS"']
    assert [ln for ln in code if '"$SEED_FROM58"' in ln] == [
        'step seed28_v58 python scripts/seed_panel.py "$m28" "$SEED_FROM58" "$P" "$O/seed28_v58.json" --audited '
        '"$AUDITS"']
    assert [ln for ln in code if "$GEOM_PANEL" in ln] == [
        'step panel_source26 python scripts/panel_state.py "$m26" "$GEOM_PANEL" --audited "$AUDITS"',
        'step geometry26 env CUDA_VISIBLE_DEVICES="" python audit_v5/tools/merge_geometry.py "$GEOM_PANEL" \\']
    assert SRC.count("--device cpu") == 2 and SRC.count('env CUDA_VISIBLE_DEVICES="" python') == 2
