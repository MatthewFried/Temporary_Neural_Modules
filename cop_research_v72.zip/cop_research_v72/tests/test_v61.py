"""v61: the transport certificate in two precisions and the precision diagnostic, on a controlled case: the same
pre-merge activations, an ill-conditioned invertible map, and post-merge activations carrying a float32-sized
forward error."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "audit_v5" / "tools"))


def _case(cond=1e4, n=600, d=8, seed=3):
    g = torch.Generator().manual_seed(seed)
    H = torch.randn(n, d, generator=g, dtype=torch.float64)
    y = (H[:, 0] + 0.5 * H[:, 1] - H[:, 2] + 0.3 * torch.randn(n, generator=g, dtype=torch.float64) > 0).long()
    U, _ = torch.linalg.qr(torch.randn(d, d, generator=g, dtype=torch.float64))
    V, _ = torch.linalg.qr(torch.randn(d, d, generator=g, dtype=torch.float64))
    s = torch.logspace(0, -torch.log10(torch.tensor(cond)).item(), d, dtype=torch.float64)
    A = U @ torch.diag(s) @ V.T
    c = torch.randn(d, generator=g, dtype=torch.float64)
    P64 = H @ A.T + c
    P32 = (P64.float()).double()                      # the post-merge activations rounded to float32
    return H, y, A, c, P64, P32


def _probe(H, y, prep):
    import merge_geometry as MG
    F = {MG.FIT: H, "test": H}
    Z, fn, dims = MG.preprocess(F, prep)
    w, b, _ = MG.fit_probe(Z, {p: y for p in F}, 1e-2, "x")
    return w, b, fn, dims


def test_the_precision_record_separates_algebra_rounding_and_amplification():
    import merge_geometry as MG
    H, y, A, c, P64, P32 = _case()
    r = MG.precision_record(A, c, H, P32, P64)
    assert r["merge64_vs_map"] == 0.0
    assert 1e-9 < r["forward_residual32"] < 1e-6                # float32 rounding of the post-merge activations
    s = torch.linalg.svdvals(A)
    cond = float(s.max() / s.min())
    assert r["recovered_error32"] > 10 * r["forward_residual32"]   # amplified through the inverse ...
    assert r["amplification"] <= 10 * cond                      # ... within what the conditioning allows
    w = MG.precision_record(torch.eye(8, dtype=torch.float64), c, H, (H + c).float().double(), H + c)
    assert w["amplification"] < 10                              # a well-conditioned merge does not amplify


@pytest.mark.parametrize("prep", ["standardised", "whitened"])
def test_float64_certifies_where_float32_rounding_through_an_ill_conditioned_merge_fails(prep):
    import merge_geometry as MG
    H, y, A, c, P64, P32 = _case(cond=1e6)
    w, b, fn, dims = _probe(H, y, prep)
    r64 = MG.transport_check(A, c, {"test": H}, {"test": P64}, fn, w, b, dims, {"test": y})[0]
    r32 = MG.transport_check(A, c, {"test": H}, {"test": P32}, fn, w, b, dims, {"test": y})[0]
    assert r64["passed"] and r64["score_diff"] <= MG.SCORE_TOL and r64["reconstruction_residual"] < 1e-8
    assert not r32["passed"] and r32["score_diff"] > MG.SCORE_TOL and r32["reconstruction_residual"] > 1e-4
    # the same map, well conditioned: float32 passes too
    H, y, A, c, P64, P32 = _case(cond=10.0)
    w, b, fn, dims = _probe(H, y, prep)
    assert MG.transport_check(A, c, {"test": H}, {"test": P32}, fn, w, b, dims, {"test": y})[0]["passed"]
