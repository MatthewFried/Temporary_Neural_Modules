"""v61: the reanalysis launcher (scripts/61).  It trains nothing: environment, both manifests and their validation,
CPU tests, the v60 wave-28 panel and the v53 wave-26 panel checked complete under the reuse audit (both only read),
the fork analysis (on a CUDA machine with the fold also evaluated on the training device), the merge geometry, the
status record that keeps training, fork validity, transport validity and analysis completion apart, evidence,
packaging.  The real script runs in the v48 launcher test's mock COP_HOME."""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import test_v48_launcher as L  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = "61_v61_reanalysis.sh"
SRC = (ROOT / "scripts" / SCRIPT).read_text()
FILES = {k: re.search(rf'^{k}="([^"]+)"', SRC, re.M).group(1).split(",") for k in ("FORK_FILES", "GEOM_FILES")}
PREFIX = {"FORK_FILES": "fork28", "GEOM_FILES": "geometry26"}
TOOL = r"""import json, os, sys
tool = os.path.basename(sys.argv[0])[:-3]
name = {"fork_continuation": "fork28", "merge_geometry": "geometry26"}[tool]
panel, prefix = sys.argv[1], sys.argv[2]
want_panel = "cop_results_v60/panel28" if name == "fork28" else "cop_results_v53/panel26"
assert panel.endswith(want_panel) and prefix.endswith("v61_reports/" + name), sys.argv
want_man = "wave28_full.jsonl" if name == "fork28" else "wave26_full.jsonl"
assert "--strict" in sys.argv and sys.argv[sys.argv.index("--manifest") + 1].endswith(want_man)
assert sys.argv[sys.argv.index("--device") + 1] == "cpu"
if name == "geometry26":
    assert os.environ.get("CUDA_VISIBLE_DEVICES", "unset") == ""
rd = sys.argv[sys.argv.index("--recorded-device") + 1] if "--recorded-device" in sys.argv else "none"
ev = open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a")
ev.write(name + " read " + panel + " recorded " + rd + "\n")
rc = int(os.environ.get("MOCK_RC_" + name, "0"))
for t in os.environ["MOCK_FILES_" + name].split(","):
    if t.endswith(".json"):
        json.dump({"passed": rc == 0, "analysis_complete": True, "audit_failures": [] if rc == 0 else [{"x": 1}],
                   "n_expected_forks": 480, "n_audited_forks": 480, "audit_complete": True,
                   "n_passed_forks": 480 if rc == 0 else 479, "n_failed_forks": 0 if rc == 0 else 1,
                   "transport_certificate": {"valid": rc == 0}}, open(prefix + "_" + t, "w"))
        continue
    open(prefix + "_" + t, "w").write("variant,x\nB,1\n")
sys.exit(rc)
"""
PANEL_STATE = """import json, os, sys
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write("panel_state " + sys.argv[2] + "\\n")
w = "28" if sys.argv[1].endswith("wave28_full.jsonl") else "26"
want = "cop_results_v60/panel28" if w == "28" else "cop_results_v53/panel26"
assert sys.argv[2].endswith(want), sys.argv
assert sys.argv[3] == "--audited" and sys.argv[4].endswith("configs/reuse_audits.json"), sys.argv
print(json.dumps({"manifest_jobs": 552, "by_status": {"complete": 552}}))
sys.exit(int(os.environ.get("MOCK_PANEL_STATE" + w, "0")))
"""
PYTEST = r'''#!/usr/bin/env bash
echo "pytest $*" >> "$MOCK_HOME/events.txt"
xml=""; prev=""
for a in "$@"; do [ "$prev" = "--junitxml" ] && xml="$a"; prev="$a"; done
[ -n "$xml" ] && echo "<testsuites><testsuite tests=\"3\" skipped=\"0\" failures=\"0\" errors=\"0\"/></testsuites>" > "$xml"
exit "${MOCK_TEST_RC:-0}"
'''
ORDER = ["environment", "manifest28", "manifest26", "validate28", "validate26", "cpu_tests", "panel28",
         "panel_source26", "fork28", "geometry26", "status", "evidence28", "manifest_copy", "manifest_copy26",
         "package", "package_final"]


@pytest.fixture
def h(tmp_path):
    home = tmp_path / "home"
    (home / "scripts").mkdir(parents=True)
    shutil.copy2(ROOT / "scripts" / SCRIPT, home / "scripts" / SCRIPT)
    for f in ("package_reports.py", "check_evidence.py", "panel_status.py"):
        shutil.copy2(ROOT / "scripts" / f, home / "scripts" / f)
    (home / "scripts/panel_state.py").write_text(PANEL_STATE)
    (home / "scripts/common.sh").write_text(L.COMMON)
    (home / "audit_v5/tools").mkdir(parents=True)
    for name in ("fork_continuation.py", "merge_geometry.py"):
        (home / "audit_v5/tools" / name).write_text(TOOL)
    pt = home / "fake_pytest.sh"
    pt.write_text(PYTEST)
    pt.chmod(0o755)
    zipdir = tmp_path / "zips"
    zipdir.mkdir()
    for d in ("cop_results_v53", "cop_results_v60"):
        (tmp_path / d).mkdir()
    base = {k: v for k, v in os.environ.items() if k not in ("COP_PYTEST", "V53_RESULTS", "V60_RESULTS")}
    env = dict(base, MOCK_HOME=str(home), COP_RESULTS=str(tmp_path / "results"), ZIP_DIR=str(zipdir), SCALE="full",
               HOME=str(tmp_path), COP_PYTEST=str(pt), V53_RESULTS=str(tmp_path / "cop_results_v53"),
               V60_RESULTS=str(tmp_path / "cop_results_v60"),
               **{f"MOCK_FILES_{PREFIX[k]}": ",".join(v) for k, v in FILES.items()})
    return {"home": home, "res": tmp_path / "results", "zip": zipdir / "cop_v61_reanalysis_reports.zip",
            "env": env, "tmp": tmp_path}


def _sh(h, common=None, **env):
    if common is not None:
        (h["home"] / "scripts/common.sh").write_text(common)
    e = dict(h["env"], **{k: str(v) for k, v in env.items()})
    return subprocess.run(["bash", str(h["home"] / "scripts" / SCRIPT)], env=e, capture_output=True, text=True,
                          cwd=str(h["home"]))


def _verdict(h):
    return json.loads((h["res"] / "v61_reports/verdict.json").read_text())


def _events(h):
    p = h["home"] / "events.txt"
    return p.read_text() if p.exists() else ""


def test_it_trains_nothing_reads_both_panels_and_packages_the_status(h):
    r = _sh(h)
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-3000:]
    v = _verdict(h)
    assert v["all_passed"] and list(v["steps"]) == ORDER
    ev = _events(h)
    assert "cop run" not in ev and "seed" not in ev
    assert f"fork28 read {h['tmp']}/cop_results_v60/panel28 recorded none" in ev
    assert f"geometry26 read {h['tmp']}/cop_results_v53/panel26" in ev
    assert all(not list((h["tmp"] / d).iterdir()) for d in ("cop_results_v53", "cop_results_v60"))
    st = json.loads((h["res"] / "v61_reports/panel_status.json").read_text())
    assert set(st) == {"training", "fork_validity", "transport_validity", "analysis_completion"}
    assert st["training"]["complete"] and st["fork_validity"]["valid"] is True
    names = zipfile.ZipFile(h["zip"]).namelist()
    assert "cop_v61_reanalysis_reports/v61_reports/panel_status.json" in names
    for k, pre in PREFIX.items():
        for f in FILES[k]:
            if f not in ("probes.csv", "contrasts.csv"):
                assert f"cop_v61_reanalysis_reports/v61_reports/{pre}_{f}" in names, f


def test_on_a_cuda_machine_the_fold_is_also_evaluated_on_the_training_device(h):
    r = _sh(h, common=L.COMMON.replace("DEVICE=cpu", "DEVICE=cuda"))
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-3000:]
    assert "fork28 read " in _events(h) and " recorded cuda" in _events(h)


def test_failed_analyses_stay_failed_and_the_status_says_which(h):
    r = _sh(h, MOCK_RC_fork28=1)
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"]["fork28"] == 1 and v["steps"]["evidence28"] == 0 and not v["all_passed"]
    st = json.loads((h["res"] / "v61_reports/panel_status.json").read_text())
    assert st["fork_validity"]["valid"] is False and st["training"]["complete"]


def test_an_incomplete_v60_panel_skips_the_fork_analysis_only(h):
    r = _sh(h, MOCK_PANEL_STATE28=3)
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"]["panel28"] == 3 and v["steps"]["fork28"] == 99 and v["steps"]["geometry26"] == 0
    assert "fork28 read" not in _events(h)


def test_failed_tests_skip_both_analyses(h):
    r = _sh(h, MOCK_TEST_RC=1)
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"]["fork28"] == 99 and v["steps"]["geometry26"] == 99 and v["steps"]["status"] == 0
