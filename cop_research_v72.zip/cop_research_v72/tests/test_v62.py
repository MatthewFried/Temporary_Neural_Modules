"""v62: wave 29, v60's design in a second setting (a deeper, wider network whose additions merge after layer 3, and
another shortcut task), and the two analyses on a miniature of it through the v62 launcher's own command lines: the
merge found at depth 3, the fold composed into layer 4, every audit, the central table and the geometry."""
from __future__ import annotations

import csv
import json
import os
import re
import shlex
import subprocess
import sys
from pathlib import Path

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "audit_v5" / "tools"))
from cop.config import resolve, run_id  # noqa: E402
from cop.utils import read_json, stable_hash  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
LAUNCHER = ROOT / "scripts/62_v62_replication.sh"
SRC = LAUNCHER.read_text()
FORKS = {"snap_3": 3, "snap_9": 9}                    # the miniature's clock: U = 6, 2U = 12
STEPS = {"fork29": ("FORK_FILES", "fork_continuation.py"), "geometry29": ("GEOM_FILES", "merge_geometry.py")}
ARMS = ("A_routed_affine", "A_all_affine", "B_routed_affine", "B_all_affine")
DEEP = {"depth": 6, "width": 24}
TASK = {"d_causal": 12, "d_noise": 12, "rho_train": 0.95}


def _rows(path):
    t = Path(path).read_text()
    return [] if t.strip() == "empty" else list(csv.DictReader(open(path)))


def _contract(step):
    files = re.search(rf'^{STEPS[step][0]}="([^"]+)"', SRC, re.M).group(1).split(",")
    cmd = re.search(rf'^\s+step {step} (?:env CUDA_VISIBLE_DEVICES="" )?(python (?:[^\n]*\\\n)*[^\n]*)', SRC,
                    re.M).group(1).replace("\\\n", " ")
    toks = [t for t in shlex.split(cmd) if t != "${FORK_EXTRA[@]}"]
    assert toks[1] == f"audit_v5/tools/{STEPS[step][1]}"
    return files, toks[toks.index("--manifest") + 2:]


def _analyse(root, man, step):
    files, opts = _contract(step)
    assert not any("$" in t for t in opts), opts
    r = subprocess.run([sys.executable, str(ROOT / "audit_v5/tools" / STEPS[step][1]), str(root), str(root / step),
                        "--manifest", str(man), *opts], capture_output=True, text=True,
                       env=dict(os.environ, CUDA_VISIBLE_DEVICES=""))
    return r, files


# ----------------------------------------------------------------------------- the wave

def test_wave29_is_v60s_design_in_the_second_setting():
    from cop.orchestration.manifest import generate
    from cop.orchestration.wave13 import (V58_CONTS, V59_CONTS, V62_ARMS, V62_DRAWS, v53_variants, v58_forks,
                                          v62_cell)
    from collections import Counter
    from cop.utils import semantic_code_hash
    import test_v46
    assert semantic_code_hash() and test_v46.v45_panels_reusable()   # v65: cop/ changed; the audits accept v60-v64 runs
    cell = v62_cell()
    assert cell.model["width"] == 128 and cell.model["depth"] == 6
    assert cell._data["params"] == {"rho_train": 0.95, "d_causal": 12, "d_noise": 12}
    m = generate([29], "full").entries
    cf = {r: e["cfg"] for r, e in m.items()}
    assert len(cf) == 744
    kinds = Counter((c["kind"], (c.get("dissipation") or {}).get("method")) for c in cf.values())
    assert kinds == {("baseline", None): 24, ("trajectory", None): 96, ("dissipation", "linear"): 96,
                     ("continue", None): 48, ("dissipation", "keep"): 384, ("dissipation", "fold_unrouted"): 96}
    assert {c["data"]["data_seed"] for c in cf.values()} == set(V62_DRAWS) and set(V62_DRAWS) == set(range(349, 361))
    assert all(c["model"]["width"] == 128 and c["model"]["depth"] == 6 and c["data"]["params"]["d_causal"] == 12
               and c["data"]["params"]["d_noise"] == 12 for c in cf.values())
    # the draws were never used by any earlier wave
    used = set()
    for w in range(13, 29):
        try:
            used |= {e["cfg"]["data"].get("data_seed") for e in generate([w], "full").entries.values()
                     if isinstance(e["cfg"].get("data"), dict)}
        except KeyError:
            continue
    assert not used & set(V62_DRAWS)
    va = v53_variants()
    tr = {r: c for r, c in cf.items() if c["kind"] == "trajectory"}
    assert Counter(c["growth"]["spec_partition"] for c in tr.values()) == {"random_matched": 48, "all_examples": 48}
    assert all(c["growth"]["act"] == "identity" for c in tr.values())
    forks = {r: c for r, c in cf.items() if c["kind"] == "dissipation" and c["design"]["family"] == "X28"}
    seen = Counter()
    for c in forks.values():
        d, dc, t = c["design"], c["dissipation"], cf[c["parents"]["trajectory"]]
        parent, _, stage = d["variant"].partition("@")
        assert parent in ("A_routed_affine", "B_routed_affine") and t["growth"]["spec_partition"] == "random_matched"
        assert all(t["growth"][k] == v for k, v in va[parent][1].items())
        assert dc["post_updates"] == 4000 - v58_forks(2000)[stage]
        for k, v in {**V58_CONTS, **V59_CONTS}[d["arm"]].items():
            assert dc[k] == v
        assert c["train"] == t["train"] and c["tags"]["parent_stage"] == stage
        seen[(parent, stage, d["arm"])] += 1
    assert len(seen) == 20 and set(seen.values()) == {24}
    lin = [c for c in cf.values() if (c.get("dissipation") or {}).get("method") == "linear"]
    assert Counter(c["design"]["variant"] for c in lin) == {a: 24 for a in V62_ARMS}
    assert all(c["train"]["freeze_inputs"] == "none" for c in lin)


# ----------------------------------------------------------------------------- the miniature

def _deepen(cfgs):
    """the same jobs in the second setting: a six-layer network and the 12 + 12 input task; parents re-pointed."""
    ids, out = {}, []
    for c in cfgs:
        d = {**c, "model": {**c["model"], **DEEP}, "data": {**c["data"], "params": {**c["data"]["params"], **TASK}}}
        if c.get("parents"):
            d["parents"] = {k: ids[v] for k, v in c["parents"].items()}
        d = resolve(d)
        ids[run_id(c)] = run_id(d)
        out.append(d)
    return out


@pytest.fixture(scope="module")
def p29(tmp_path_factory):
    from test_v31 import _diss, _manifest
    from test_v53 import _panel26, _run
    from cop.orchestration.wave13 import V58_CONTS, V59_CONTS
    root = tmp_path_factory.mktemp("p29")
    p0, T, R, Cc, _ = _panel26(root, run=False, arms=list(ARMS), compacts=["compact_A", "compact_B"])
    F = {}
    for name in ("A_routed_affine", "B_routed_affine"):
        for stage, u in FORKS.items():
            for cn, sec in {**V58_CONTS, **V59_CONTS}.items():
                d = _diss(T[name], **sec, post_updates=12 - u, early_eval=[], path_eval_points=4)
                F[(name, stage, cn)] = resolve({**d, "tags": {"parent_stage": stage},
                                                "design": {"family": "X28", "variant": f"{name}@{stage}", "arm": cn,
                                                           "contrast": "X28|c"}})
    allc = [p0, *T.values(), *R.values(), *Cc.values(), *F.values()]
    deep = _deepen(allc)
    keys = ["p0", *[("T", k) for k in T], *[("R", k) for k in R], *[("C", k) for k in Cc], *[("F", k) for k in F]]
    D = dict(zip(keys, deep))
    _run([D["p0"], *[D[("T", k)] for k in T]], root)
    for k in [*R, ]:
        _run([D[("R", k)]], root)
    for k in Cc:
        _run([D[("C", k)]], root)
    for k in F:
        _run([D[("F", k)]], root)
    man = _manifest(root, deep)
    rf, ff = _analyse(root, man, "fork29")
    rg, gf = _analyse(root, man, "geometry29")
    return {"root": root, "D": D, "man": man, "fork": rf, "geom": rg, "ffiles": ff, "gfiles": gf}


def test_the_second_setting_merges_after_layer_3(p29):
    import f0_panel as FP
    import selective_reversal as SR
    from cop.graph.graph import GraphNet
    T = p29["D"][("T", "A_routed_affine")]
    ck = torch.load(p29["root"] / "runs" / run_id(T) / "ckpt" / "final.pt", weights_only=False)
    g = GraphNet.from_checkpoint(ck["model"]).eval()
    f0 = GraphNet.from_checkpoint(torch.load(p29["root"] / "runs" / run_id(T) / "ckpt" / "baseline_ref.pt",
                                             weights_only=False)["model"])
    L = SR.backbone_layers(f0)
    assert len(L) == 7                                         # six hidden layers and the output layer
    sites = FP.layer_sites(g, L)
    assert [k for k in sites if k.endswith("_post_merge")] == ["layer3_post_merge"]
    assert [k for k in sites if not k.endswith("_post_merge")] == [f"layer{i}" for i in range(1, 7)]
    assert T["data"]["params"]["d_causal"] == 12 and ck["model"]["state"][f"mods.{L[0]}.weight"].shape[1] == 25


def test_the_fork_analysis_passes_in_the_second_setting(p29):
    r = p29["fork"]
    assert r.returncode == 0, r.stdout[-2000:] + r.stderr[-3000:]
    root = p29["root"]
    cov = read_json(root / "fork29_coverage.json")
    assert cov["passed"] and cov["analysis_complete"] and cov["n_audited_forks"] == 20 and not cov["audit_failures"]
    assert cov["analysis_schema"] == "fork_continuation/v68"
    for f in p29["ffiles"]:
        assert (root / f"fork29_{f}").read_text().strip() != "empty", f
    au = _rows(root / "fork29_audits.csv")
    fo = [x for x in au if x["state"] == "folded_reset"]
    assert len(fo) == 4 and all("layer 4 = W A, b + W c" in x["fold_start_detail"] for x in fo)
    assert all(float(x["outcome_fold_algebra64"]) <= 1e-10 for x in fo)
    st = _rows(root / "fork29_states.csv")
    cols = set(st[0])
    for k in (3, 4, 5, 6):
        assert f"probe|native_layer{k}|standardised|lam=0.0001|test_err" in cols
    assert "probe|native_layer3_post_merge|whitened|lam=0.01|test_err" in cols
    ce = _rows(root / "fork29_central.csv")
    assert {r_["comparison"] for r_ in ce} == {"minus_f0", "start_minus_f0", "continuation_minus_start",
                                               "fork_minus_compact_2U", "fork_minus_compact_4U"}
    # v63: the compact controls are measured like every other state, with the parent arm whose hold they share
    cov = read_json(root / "fork29_coverage.json")
    assert cov["n_states"] == 1 + 2 * 2 * (2 + 5) + 2 * 2 and cov["audit_complete"]
    assert cov["n_expected_forks"] == cov["n_audited_forks"] == cov["n_passed_forks"] == 20
    assert sorted(map(tuple, cov["compact_controls"])) == sorted(
        (p_, s_) for p_ in ("A_routed_affine", "B_routed_affine") for s_ in ("compact_2U", "compact_4U"))
    stt = {(x["parent"], x["fork"], x["state"]): x for x in st}
    D = p29["D"]
    for parent, comp in (("A_routed_affine", "compact_A"), ("B_routed_affine", "compact_B")):
        for lab, uu in (("compact_2U", 12), ("compact_4U", 24)):
            row = stt[(parent, "compact", lab)]
            ck = torch.load(root / "runs" / run_id(D[("C", comp)]) / "ckpt" / f"at_{uu}.pt", weights_only=False)
            assert int(ck["extra"]["update"]) == uu and row["has_additions"] == "False"
            assert row["state_at_f0_block_row_norms_f0_bias_test_err"] != ""
    co = _rows(root / "fork29_contrasts.csv")
    for r_ in co:
        if r_["comparison"].startswith("fork_minus_compact"):
            a_, b_ = stt[(r_["parent"], r_["fork"], r_["first"])], stt[(r_["parent"], "compact", r_["second"])]
            assert float(r_["value"]) == pytest.approx(float(a_[r_["metric"]]) - float(b_[r_["metric"]]), abs=1e-15)
    cp = _rows(root / "fork29_compute.csv")
    forks_c = [x for x in cp if x["fork"] != "compact"]
    assert len(forks_c) == 20 and all(int(x["train_macs_total"]) == int(x["train_macs_to_fork"]) +
                                      int(x["train_macs_fork"]) > 0 for x in forks_c)
    assert all(float(x["fork_over_compact_4U_macs"]) > 0 for x in forks_c)


def test_the_geometry_passes_in_the_second_setting(p29):
    import merge_geometry as MG
    r = p29["geom"]
    assert r.returncode == 0, r.stdout[-2000:] + r.stderr[-3000:]
    root = p29["root"]
    cov = read_json(root / "geometry29_coverage.json")
    assert cov["passed"] and cov["analysis_complete"]
    for f in p29["gfiles"]:
        assert (root / f"geometry29_{f}").read_text().strip() != "empty", f
    maps = _rows(root / "geometry29_maps.csv")
    assert {m["variant"] for m in maps} == set(ARMS)
    assert all(m["map_source"] == MG.MAP_EXACT and m["merge_after"] == "layer3" for m in maps)
    assert all(int(m["rank"]) == 24 for m in maps)            # the merge acts on the width-24 layer 3
    cert = cov["transport_certificate"]
    assert cert["valid"] and cert["complete"] and cert["checked"] == len(maps)
    tr = _rows(root / "geometry29_transport.csv")
    assert {t["feature"] for t in tr} == {"layer3_post_merge"}
    pr = _rows(root / "geometry29_probes.csv")
    assert {"layer5", "layer6", "layer3_post_merge"} <= {x["feature"] for x in pr}


def test_a_fold_into_the_wrong_layer_and_a_missing_fork_fail(p29, tmp_path):
    """negative cases: a saved fold whose receiving layer was not composed (the composition left out, as if it went
    elsewhere) fails the fold checks; a manifest missing one expected fork is not the design."""
    import shutil
    root = tmp_path / "copy"
    shutil.copytree(p29["root"] / "runs", root / "runs")
    rid = run_id(p29["D"][("F", ("A_routed_affine", "snap_9", "folded_reset"))])
    T = p29["D"][("T", "A_routed_affine")]
    snap = torch.load(root / "runs" / run_id(T) / "ckpt" / "snap_9.pt", weights_only=False)["model"]["state"]
    ckp = root / "runs" / rid / "ckpt" / "event_after_fold.pt"
    ck = torch.load(ckp, weights_only=False)
    lin = [k for k in ck["model"]["state"] if k.endswith(".weight")]
    snap_w = [k for k in snap if k.endswith(".weight") and k.split(".")[1] in {"p1", "p2", "p3", "p4", "p5", "p6",
                                                                               "p7"}]
    # the receiving layer (layer 4) gets the snapshot's uncomposed weight: the fold went nowhere
    recv = next(k for k in lin if k.split(".")[1] not in {"p1", "p2", "p3", "p5", "p6", "p7"})
    ck["model"]["state"][recv] = snap["mods.p4.weight"].clone()
    torch.save(ck, ckp)
    r, _ = _analyse(root, p29["man"], "fork29")
    assert r.returncode == 1
    cov = read_json(root / "fork29_coverage.json")
    got = {x["run_id"]: set(x) - {"f0", "parent", "fork", "state", "run_id"} for x in cov["audit_failures"]}
    assert got == {rid: {"fold_start", "fold_function"}}
    assert "layer 4 is not W A" in next(x for x in _rows(root / "fork29_audits.csv")
                                        if x["run_id"] == rid)["fold_start_detail"]
    # one fork left out of the manifest
    man = tmp_path / "m.jsonl"
    drop = run_id(p29["D"][("F", ("B_routed_affine", "snap_3", "ordinary_reset"))])
    man.write_text("".join(ln for ln in Path(p29["man"]).read_text().splitlines(keepends=True)
                           if json.loads(ln)["run_id"] != drop))
    files, opts = _contract("fork29")
    r = subprocess.run([sys.executable, str(ROOT / "audit_v5/tools/fork_continuation.py"), str(p29["root"]),
                        str(tmp_path / "f"), "--manifest", str(man), *opts], capture_output=True, text=True,
                       env=dict(os.environ, CUDA_VISIBLE_DEVICES=""))
    assert r.returncode == 1
    cov = read_json(tmp_path / "f_coverage.json")
    assert not cov["passed"] and cov["n_expected_forks"] == 0 and not cov["audit_complete"]
    assert "not a complete wave-28 design" in cov["failed"][0]["reason"]


def test_the_registry_reads_the_contrasts_with_their_signs(p29, tmp_path):
    """the registry reader on the miniature's contrasts (its fork points renamed to the miniature's): each
    hypothesis finds its rows, flips the stored first - second where the favourable direction is second - first,
    averages seeds within draws, and reads primaries at the Bonferroni level."""
    sys.path.insert(0, str(ROOT / "scripts"))
    import replication_registry as RR
    reg = json.loads((ROOT / "configs/v62_replication_registry.json").read_text())
    assert [h["key"] for h in reg["hypotheses"] if h["role"] == "primary"] == [
        "early_routing_improves_normalised_extraction", "early_routing_worsens_the_complete_network",
        "late_folding_retains_a_component_advantage", "expansion_history_beats_compact_continuation"]
    assert all(h["parent"] == "A_routed_affine" for h in reg["hypotheses"] if h["role"] == "primary")
    from v66_helpers import bind, draw_seed
    cs = p29["root"] / "fork29_contrasts.csv"
    reg = bind(reg, p29["root"] / "fork29_coverage.json", *draw_seed(cs), {"snap_1000": "snap_3", "snap_2500": "snap_9"})
    rp = tmp_path / "reg.json"
    rp.write_text(json.dumps(reg))
    assert RR.main([str(rp), str(cs), str(tmp_path / "out"), "--coverage", str(p29["root"] / "fork29_coverage.json"),
                    "--manifest", str(p29["man"]), "--audits", str(p29["root"] / "fork29_audits.csv"),
                    "--states", str(p29["root"] / "fork29_states.csv")]) == 0
    rec = json.loads((tmp_path / "out.json").read_text())
    co = _rows(p29["root"] / "fork29_contrasts.csv")
    for h in rec["results"]:
        assert h["found"] and h["n_draws"] == 1 and h["n_draw_seed_pairs"] == 1
        row = next(r_ for r_ in co if (r_["parent"], r_["fork"], r_["comparison"], r_["first"], r_["second"],
                                       r_["metric"]) == (h["parent"], h["fork"], h["comparison"], h["first"],
                                                         h["second"], h["metric"]))
        v = float(row["value"])
        assert h["mean_favourable"] == pytest.approx(-v if h["favourable"] == "second - first" else v, abs=1e-15)
        assert h["interval_low"] is None and h["reading"] in ("inconclusive", "secondary: inconclusive at 95%")
    assert RR.t_quantile(0.975, 11) == pytest.approx(2.200985, abs=1e-5)
    assert RR.t_quantile(1 - 0.0125 / 2, 11) == pytest.approx(2.98, abs=0.01)


def test_the_fitted_and_transported_probes_read_the_same_representation(p29):
    """v63: fitted_minus_transported_<precision> pairs the probe fitted on that precision's merge outputs with the
    probe transported through the same outputs; the mixed comparison is labelled; the whitened rows carry the
    comparability of their own representation; the summaries count planned and included pairs."""
    root = p29["root"]
    pr = {(x["f0"], x["variant"], x["stage"], x["feature"], x["prep"], x["lam"]): x
          for x in _rows(root / "geometry29_probes.csv")}
    tr = {(x["f0"], x["variant"], x["stage"], x["prep"], x["lam"], x["precision"]): x
          for x in _rows(root / "geometry29_transport.csv") if x["partition"] == "test"}
    maps = {(x["f0"], x["variant"], x["stage"]): x for x in _rows(root / "geometry29_maps.csv")}
    co = [x for x in _rows(root / "geometry29_contrasts.csv") if x["comparison"].startswith("fitted_minus_transported")]
    seen = set()
    for c in co:
        cmp_ = c["comparison"].rsplit("_", 1)[-1] if not c["comparison"].endswith("mixed_precision") else "mixed"
        seen.add(cmp_)
        fitted_prec = "float32" if cmp_ in ("float32", "mixed") else "float64"
        trans_prec = "float32" if cmp_ == "float32" else "float64"
        feat = "layer3_post_merge" + ("@float64" if fitted_prec == "float64" else "")
        k = (c["f0"], c["variant"], c["stage"])
        assert float(c["first_value"]) == float(pr[k + (feat, c["prep"], c["lam"])]["test_err"])
        assert float(c["second_value"]) == float(tr[k + (c["prep"], c["lam"], trans_prec)]["transported_err"])
        if c["prep"] == "whitened":
            want = {"float32": maps[k]["whitening_comparable"], "float64": maps[k]["whitening64_comparable"],
                    "mixed": "False"}[cmp_]
            assert c["comparable"] == want, (cmp_, c["comparable"], want)
        else:
            assert c["comparable"] == ""
    assert seen == {"float32", "float64", "mixed"}
    sm = _rows(root / "geometry29_contrasts_summary.csv")
    assert sm and all(int(x["included_pairs"]) <= int(x["planned_pairs"]) for x in sm)
    assert all(int(x["included_pairs"]) > 0 for x in sm)
