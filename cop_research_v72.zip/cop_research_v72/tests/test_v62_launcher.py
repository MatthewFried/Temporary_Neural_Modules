"""v62: the wave-29 launcher (scripts/62).  It TRAINS: environment, manifest (a failed generation cannot fall through
to a stale file), validation, CPU tests, on a CUDA device the CUDA tests (run, none skipped), the panel; then status,
checks, fresh reload, strict summary, timing, the fork analysis (on a CUDA machine with the fold also evaluated on the
training device) and the merge geometry on the same panel, the status record, evidence, packaging whatever happens.
The real script runs in the v48 launcher test's mock COP_HOME."""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import test_v48_launcher as L  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = "62_v62_replication.sh"
SRC = (ROOT / "scripts" / SCRIPT).read_text()
FILES = {k: re.search(rf'^{k}="([^"]+)"', SRC, re.M).group(1).split(",") for k in ("FORK_FILES", "GEOM_FILES")}
PREFIX = {"FORK_FILES": "fork29", "GEOM_FILES": "geometry29"}
TOOL = r"""import json, os, sys
tool = os.path.basename(sys.argv[0])[:-3]
name = {"fork_continuation": "fork29", "merge_geometry": "geometry29"}[tool]
panel, prefix = sys.argv[1], sys.argv[2]
assert panel.endswith("results/panel29") and prefix.endswith("v62_reports/" + name), sys.argv
assert "--strict" in sys.argv and sys.argv[sys.argv.index("--manifest") + 1].endswith("wave29_full.jsonl")
assert sys.argv[sys.argv.index("--device") + 1] == "cpu"
if name == "geometry29":
    assert os.environ.get("CUDA_VISIBLE_DEVICES", "unset") == ""
rd = sys.argv[sys.argv.index("--recorded-device") + 1] if "--recorded-device" in sys.argv else "none"
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write(name + " read " + panel + " recorded " + rd + "\n")
rc = int(os.environ.get("MOCK_RC_" + name, "0"))
for t in os.environ["MOCK_FILES_" + name].split(","):
    if t.endswith(".json"):
        json.dump({"passed": rc == 0, "analysis_complete": True, "audit_failures": [], "n_expected_forks": 480,
                   "n_audited_forks": 480, "audit_complete": True, "n_passed_forks": 480, "n_failed_forks": 0},
                  open(prefix + "_" + t, "w"))
        continue
    open(prefix + "_" + t, "w").write("variant,x\nB,1\n")
sys.exit(rc)
"""
PANEL_STATE = """import json, os, sys
assert sys.argv[1].endswith("wave29_full.jsonl") and sys.argv[2].endswith("results/panel29"), sys.argv
print(json.dumps({"manifest_jobs": 744, "by_status": {"complete": 744}}))
"""
REPORT = r"""import json, os, sys
name = os.path.basename(sys.argv[0])
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write(name + " " + " ".join(sys.argv[1:4]) + "\n")
if name == "runtime_v13.py":                      # runtime_v13.py fit MANIFEST RESULTS OUT
    assert sys.argv[1] == "fit" and sys.argv[3].endswith("panel29")
    out = sys.argv[4]
else:
    assert sys.argv[1].endswith("panel29")
    out = sys.argv[2]
json.dump({"passed": True}, open(out, "w"))
"""
PYTEST = r'''#!/usr/bin/env bash
echo "pytest $*" >> "$MOCK_HOME/events.txt"
xml=""; prev=""
for a in "$@"; do [ "$prev" = "--junitxml" ] && xml="$a"; prev="$a"; done
[ -n "$xml" ] && echo "<testsuites><testsuite tests=\"3\" skipped=\"0\" failures=\"0\" errors=\"0\"/></testsuites>" > "$xml"
exit "${MOCK_TEST_RC:-0}"
'''
ORDER = ["environment", "manifest29", "validate29", "cpu_tests", "run29", "status29", "checks29", "reload29",
         "summary29", "rates29", "fork29", "geometry29", "status", "evidence29", "manifest_copy", "package",
         "package_final"]


@pytest.fixture
def h(tmp_path):
    home = tmp_path / "home"
    (home / "scripts").mkdir(parents=True)
    shutil.copy2(ROOT / "scripts" / SCRIPT, home / "scripts" / SCRIPT)
    for f in ("package_reports.py", "check_evidence.py", "panel_status.py", "junit_ran.py"):
        shutil.copy2(ROOT / "scripts" / f, home / "scripts" / f)
    (home / "scripts/panel_state.py").write_text(PANEL_STATE)
    (home / "scripts/common.sh").write_text(L.COMMON)
    (home / "audit_v5/tools").mkdir(parents=True)
    (home / "audit_v8/tools").mkdir(parents=True)
    for name in ("fork_continuation.py", "merge_geometry.py"):
        (home / "audit_v5/tools" / name).write_text(TOOL)
    for name in ("fresh_reload.py", "runtime_v13.py"):
        (home / "audit_v5/tools" / name).write_text(REPORT)
    (home / "audit_v8/tools/check_results.py").write_text(REPORT)
    pt = home / "fake_pytest.sh"
    pt.write_text(PYTEST)
    pt.chmod(0o755)
    zipdir = tmp_path / "zips"
    zipdir.mkdir()
    base = {k: v for k, v in os.environ.items() if k not in ("COP_PYTEST", "DIAGNOSTIC_OVERRIDE")}
    env = dict(base, MOCK_HOME=str(home), COP_RESULTS=str(tmp_path / "results"), ZIP_DIR=str(zipdir), SCALE="full",
               HOME=str(tmp_path), COP_PYTEST=str(pt),
               **{f"MOCK_FILES_{PREFIX[k]}": ",".join(v) for k, v in FILES.items()})
    return {"home": home, "res": tmp_path / "results", "zip": zipdir / "cop_v62_panel_reports.zip", "env": env,
            "tmp": tmp_path}


def _sh(h, common=None, **env):
    if common is not None:
        (h["home"] / "scripts/common.sh").write_text(common)
    e = dict(h["env"], **{k: str(v) for k, v in env.items()})
    return subprocess.run(["bash", str(h["home"] / "scripts" / SCRIPT)], env=e, capture_output=True, text=True,
                          cwd=str(h["home"]))


def _verdict(h):
    return json.loads((h["res"] / "v62_reports/verdict.json").read_text())


def _events(h):
    p = h["home"] / "events.txt"
    return p.read_text() if p.exists() else ""


def test_it_trains_the_panel_then_analyses_it_and_packages_everything(h):
    r = _sh(h)
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-3000:]
    v = _verdict(h)
    assert v["all_passed"] and list(v["steps"]) == ORDER
    ev = _events(h)
    run = next(ln for ln in ev.splitlines() if ln.startswith("cop run "))
    assert f"--results {h['res']}/panel29" in run and "wave29_full.jsonl" in run and "--resume" in run
    assert ev.index(run) < ev.index("fork29 read") < ev.index("geometry29 read")
    assert "recorded none" in ev
    st = json.loads((h["res"] / "v62_reports/panel_status.json").read_text())
    assert st["training"]["complete"] and st["fork_validity"]["valid"] is True
    names = zipfile.ZipFile(h["zip"]).namelist()
    for f in ("panel_status.json", "checks29.json", "fresh_reload29.json", "evidence29.json", "wave29_full.jsonl"):
        assert f"cop_v62_panel_reports/v62_reports/{f}" in names, f
    for k, pre in PREFIX.items():
        for f in FILES[k]:
            if f not in ("probes.csv", "contrasts.csv"):
                assert f"cop_v62_panel_reports/v62_reports/{pre}_{f}" in names, f


def test_on_cuda_it_runs_the_cuda_tests_and_evaluates_folds_on_the_device(h):
    r = _sh(h, common=L.COMMON.replace("DEVICE=cpu", "DEVICE=cuda"))
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-3000:]
    v = _verdict(h)
    assert list(v["steps"])[:6] == ["environment", "manifest29", "validate29", "cpu_tests", "cuda_tests",
                                    "cuda_tests_ran"]
    assert " recorded cuda" in _events(h)


def test_an_unfinished_panel_reports_its_status_and_analyses_nothing(h):
    r = _sh(h, MOCK_RUN_RC=1)
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"]["run29"] == 1 and v["steps"]["status29"] == 0
    assert all(v["steps"][k] == 99 for k in ("checks29", "reload29", "summary29", "rates29", "fork29", "geometry29"))
    assert "fork29 read" not in _events(h)


def test_failed_tests_train_nothing(h):
    r = _sh(h, MOCK_TEST_RC=1)
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"]["run29"] == 99 and "cop run" not in _events(h)


def test_a_failed_analysis_stays_failed(h):
    r = _sh(h, MOCK_RC_geometry29=1)
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"]["geometry29"] == 1 and v["steps"]["fork29"] == 0 and not v["all_passed"]
