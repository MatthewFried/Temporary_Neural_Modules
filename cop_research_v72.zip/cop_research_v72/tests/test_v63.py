"""v63 analysis corrections: matched-precision fitted-versus-transported comparisons, whitening comparability on the
summaries, and the scale guard of the v62 launcher."""
import os
import subprocess
import sys
from pathlib import Path

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "audit_v5" / "tools"))
import merge_geometry as MG  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


def _ill_conditioned(n=3000, d=8, cond=1e6, seed=0):
    """pre-merge activations H, an affine map h -> A h + c with the given condition number, labels from a linear
    rule on H, and the merge outputs in float64 and as float32 would store them."""
    g = torch.Generator().manual_seed(seed)
    U, _ = torch.linalg.qr(torch.randn(d, d, generator=g, dtype=torch.float64))
    V, _ = torch.linalg.qr(torch.randn(d, d, generator=g, dtype=torch.float64))
    s = torch.logspace(0, -torch.log10(torch.tensor(cond)).item(), d, dtype=torch.float64)
    A = U @ torch.diag(s) @ V.T
    c = torch.randn(d, generator=g, dtype=torch.float64)
    parts = (MG.FIT, *MG.EVAL)
    H = {p: torch.randn(n, d, generator=g, dtype=torch.float64) * 3.0 for p in parts}
    wt = torch.randn(d, generator=g, dtype=torch.float64)
    y = {p: (H[p] @ wt > 0).long() for p in parts}
    P64 = {p: H[p] @ A.T + c for p in parts}
    P32 = {p: P64[p].float().double() for p in parts}
    return A, c, H, y, P64, P32


def test_float32_rounding_changes_the_comparison_while_float64_transport_holds():
    """an ill-conditioned (but eligible) map: the probe transported through the float64 outputs reproduces the
    pre-merge probe; through the float32 outputs it does not.  The two matched comparisons therefore differ, and
    the mixed comparison (fitted on float32, transported through float64) equals neither."""
    A, c, H, y, P64, P32 = _ill_conditioned()
    assert float(torch.linalg.cond(A)) < MG.COND_MAX
    Z, fn, dims = MG.preprocess(H, "standardised")
    w, b, _ = MG.fit_probe(Z, y, 1e-3, "pre")
    t64 = {t["partition"]: t for t in MG.transport_check(A, c, H, P64, fn, w, b, dims, y)}
    t32 = {t["partition"]: t for t in MG.transport_check(A, c, H, P32, fn, w, b, dims, y)}
    assert all(t["passed"] and t["err_diff"] == 0 for t in t64.values())
    assert not all(t["passed"] for t in t32.values())
    assert any(t["disagree_frac"] > 0 for t in t32.values())
    pr = MG.precision_record(A, c, H["test"], P32["test"], P64["test"])
    assert pr["merge64_vs_map"] < MG.EXACT64_TOL and pr["amplification"] > 1e3
    # the probes fitted on each representation (as one_state fits them, preprocessing refitted per representation)
    fitted = {}
    for name, P in (("float32", P32), ("float64", P64)):
        Zp, _, _ = MG.preprocess(P, "standardised")
        _, _, r = MG.fit_probe(Zp, y, 1e-3, name)
        fitted[name] = r["test_err"]
    matched = {k: fitted[k] - (t32 if k == "float32" else t64)["test"]["transported_err"] for k in fitted}
    mixed = fitted["float32"] - t64["test"]["transported_err"]
    assert t32["test"]["transported_err"] != t64["test"]["transported_err"]
    assert matched["float32"] != matched["float64"]
    assert mixed == pytest.approx(fitted["float32"] - t64["test"]["transported_err"])


def _rec(F, prep="whitened"):
    _, _, _, rec = MG.preprocess_full(F, prep)
    return rec


def test_whitening_comparability_rejects_unequal_dimensions_and_off_span_points():
    g = torch.Generator().manual_seed(1)
    n, d = 400, 6
    A = torch.eye(d, dtype=torch.float64) + 0.1 * torch.randn(d, d, generator=g, dtype=torch.float64)
    cond = float(torch.linalg.cond(A))
    # pre-merge fit set confined to 4 of 6 dimensions, post-merge given extra variance in the others: unequal dims
    Hf = torch.randn(n, d, generator=g, dtype=torch.float64)
    Hf[:, 4:] = 0
    pre = {MG.FIT: Hf, "test": Hf.clone()}
    post = {MG.FIT: Hf @ A.T + torch.randn(n, d, generator=g, dtype=torch.float64), "test": Hf @ A.T}
    wc = MG.whitening_comparable(_rec(pre), _rec(post), A, cond)
    assert not wc["fit"] and not wc["eval"] and "unequal retained dimensions" in wc["note"]
    # same rank before and after (the exact image), but the test points leave the fit set's span
    Ht = torch.randn(n, d, generator=g, dtype=torch.float64)
    pre = {MG.FIT: Hf, "test": Ht}
    post = {MG.FIT: Hf @ A.T, "test": Ht @ A.T}
    wc = MG.whitening_comparable(_rec(pre), _rec(post), A, cond)
    assert wc["fit"] and not wc["eval"] and "outside the fit set's retained span" in wc["note"]
    # inside the span on every partition: comparable
    Hi = torch.randn(n, d, generator=g, dtype=torch.float64)
    Hi[:, 4:] = 0
    pre = {MG.FIT: Hf, "test": Hi}
    post = {MG.FIT: Hf @ A.T, "test": Hi @ A.T}
    wc = MG.whitening_comparable(_rec(pre), _rec(post), A, cond)
    assert wc["fit"] and wc["eval"]


def _crow(draw, seed, value, comparable, comparison="fitted_minus_transported_float64", prep="whitened"):
    return {"design_id": "X", "cell": "c", "comparison": comparison, "variant": "A_routed_affine",
            "kind": "expansion", "stage": "at_2", "updates_since_f0": 2, "feature": "layer3_post_merge",
            "prep": prep, "lam": 0.001, "metric": "test_err", "second": "t", "sign": "first - second",
            "data_draw": draw, "optimizer_seed": seed, "value": value, "comparable": comparable,
            "comparability_note": "" if comparable is not False else "unequal retained dimensions (3 before, 4 after)"}


def test_the_summaries_use_only_comparable_rows_and_report_the_pairs():
    rows = [_crow(0, 0, 0.10, True), _crow(0, 1, 0.20, True), _crow(1, 0, 0.30, True), _crow(1, 1, 9.0, False),
            _crow(2, 0, 9.0, False), _crow(2, 1, 9.0, False),
            # a standardised row has no comparability flag and is always included
            _crow(0, 0, 0.5, "", prep="standardised"), _crow(1, 0, 0.7, "", prep="standardised")]
    bd, sm = MG.contrast_summaries(rows)
    w = next(r for r in sm if r["prep"] == "whitened")
    assert (w["planned_pairs"], w["included_pairs"], w["planned_draws"], w["included_draws"]) == (6, 3, 3, 2)
    # seeds averaged within a draw (0.15, 0.30), then over draws
    assert w["mean_value"] == pytest.approx(0.225) and w["n_unique_data_draws"] == 2
    assert all(r["value"] != 9.0 for r in bd)
    s_ = next(r for r in sm if r["prep"] == "standardised")
    assert (s_["planned_pairs"], s_["included_pairs"]) == (2, 2)
    # every whitened row incomparable: no summary at all (never a summary of nothing)
    _, sm2 = MG.contrast_summaries([_crow(0, 0, 1.0, False), _crow(1, 0, 1.0, False)])
    assert sm2 == []


def test_the_v62_launcher_refuses_a_reduced_scale(tmp_path):
    for scale in ("pilot", "smoke"):
        r = subprocess.run(["bash", str(ROOT / "scripts/62_v62_replication.sh")], capture_output=True, text=True,
                           env=dict(os.environ, SCALE=scale, COP_RESULTS=str(tmp_path / "r"),
                                    COP_VENV=str(tmp_path / "novenv")), timeout=60)
        assert r.returncode == 2, r.stdout + r.stderr
        assert "full" in (r.stdout + r.stderr) and not (tmp_path / "r").exists()
