"""v63: the status record keeps validity apart from coverage: an empty or partial audit is not a valid one, and
transport is valid among eligible states apart from being complete across the planned ones."""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _status(tmp_path, fork=None, geom=None, panel=None):
    import tempfile
    tmp_path = Path(tempfile.mkdtemp(dir=tmp_path))         # a fresh folder per call
    paths = []
    for name, obj in (("p.txt", panel), ("f.json", fork), ("g.json", geom)):
        p = tmp_path / name
        if obj is not None:
            p.write_text(json.dumps(obj) if name.endswith(".json") else json.dumps(obj) + "\n")
        paths.append(str(p))
    r = subprocess.run([sys.executable, str(ROOT / "scripts/panel_status.py"), str(tmp_path / "s.json"), *paths],
                       capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    return json.loads((tmp_path / "s.json").read_text())


def test_an_empty_audit_is_not_valid(tmp_path):
    st = _status(tmp_path, fork={"audit_failures": [], "n_expected_forks": 480, "n_audited_forks": 0,
                                 "audit_complete": False, "n_passed_forks": 0, "n_failed_forks": 0})
    assert st["fork_validity"]["state"] == "incomplete" and st["fork_validity"]["valid"] is None
    st = _status(tmp_path, fork={"audit_failures": []})                       # no coverage fields at all
    assert st["fork_validity"]["state"] == "incomplete" and st["fork_validity"]["valid"] is None
    st = _status(tmp_path)                                                    # no analysis output
    assert st["fork_validity"]["state"] == "unknown" and st["transport_validity"]["float64_among_eligible"] == \
        "unknown"


def test_a_partially_analysed_panel_is_incomplete_and_a_failure_is_invalid(tmp_path):
    st = _status(tmp_path, fork={"audit_failures": [], "n_expected_forks": 480, "n_audited_forks": 460,
                                 "audit_complete": False, "n_passed_forks": 460, "n_failed_forks": 0})
    assert st["fork_validity"]["state"] == "incomplete"
    st = _status(tmp_path, fork={"audit_failures": [{"run_id": "x"}], "n_expected_forks": 480,
                                 "n_audited_forks": 460, "audit_complete": False, "n_passed_forks": 459,
                                 "n_failed_forks": 1})
    assert st["fork_validity"]["state"] == "invalid" and st["fork_validity"]["valid"] is False
    st = _status(tmp_path, fork={"audit_failures": [], "n_expected_forks": 480, "n_audited_forks": 480,
                                 "audit_complete": True, "n_passed_forks": 480, "n_failed_forks": 0})
    assert st["fork_validity"]["state"] == "valid" and st["fork_validity"]["valid"] is True


def test_transport_with_no_eligible_state_or_skipped_states(tmp_path):
    st = _status(tmp_path, geom={"transport_certificate": {"expected": 40, "eligible": 0, "checked": 0, "passed": 0,
                                                           "failed": 0, "skipped": {"singular": 40}}})
    tv = st["transport_validity"]
    assert tv["float64_among_eligible"] == "no eligible state" and tv["float64_complete_across_planned"] is False
    st = _status(tmp_path, geom={"transport_certificate": {"expected": 40, "eligible": 38, "checked": 38,
                                                           "passed": 38, "failed": 0, "skipped": {"singular": 2}}})
    tv = st["transport_validity"]
    assert tv["float64_among_eligible"] == "valid" and tv["float64_complete_across_planned"] is False
    st = _status(tmp_path, geom={"transport_certificate": {"expected": 40, "eligible": 40, "checked": 40,
                                                           "passed": 39, "failed": 1}})
    assert st["transport_validity"]["float64_among_eligible"] == "invalid"
