"""v64: the combined launcher (scripts/64).  It TRAINS wave 29 (as scripts/62), then runs v63's corrected analyses:
the fork analysis with the compact controls and compute, the merge geometry, the registry (only after a passed fork
analysis), and the geometry of the v53 wave-26 panel (only read, independent of the training), then the status,
evidence, packaging.  The real script runs in the v48 launcher test's mock COP_HOME."""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import test_v48_launcher as L  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = "64_v64_panel.sh"
SRC = (ROOT / "scripts" / SCRIPT).read_text()
FILES = {k: re.search(rf'^{k}="([^"]+)"', SRC, re.M).group(1).split(",") for k in ("FORK_FILES", "GEOM_FILES")}
NAMES = {"fork29": "FORK_FILES", "geometry29": "GEOM_FILES", "geometry26": "GEOM_FILES"}
TOOL = r"""import json, os, sys
panel, prefix = sys.argv[1], sys.argv[2]
name = os.path.basename(prefix)
assert prefix.endswith("v64_reports/" + name), sys.argv
want_panel = "cop_results_v53/panel26" if name == "geometry26" else "results/panel29"
assert panel.endswith(want_panel), sys.argv
want_man = "wave26_full.jsonl" if name == "geometry26" else "wave29_full.jsonl"
assert "--strict" in sys.argv and sys.argv[sys.argv.index("--manifest") + 1].endswith(want_man)
assert sys.argv[sys.argv.index("--device") + 1] == "cpu"
tool = os.path.basename(sys.argv[0])[:-3]
assert tool == ("fork_continuation" if name == "fork29" else "merge_geometry"), (tool, name)
if name != "fork29":
    assert os.environ.get("CUDA_VISIBLE_DEVICES", "unset") == ""
rd = sys.argv[sys.argv.index("--recorded-device") + 1] if "--recorded-device" in sys.argv else "none"
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write(name + " read " + panel + " recorded " + rd + "\n")
rc = int(os.environ.get("MOCK_RC_" + name, "0"))
for t in os.environ["MOCK_FILES_" + name].split(","):
    if t.endswith(".json"):
        json.dump({"passed": rc == 0, "analysis_complete": True, "audit_failures": [] if rc == 0 else [{"x": 1}],
                   "n_expected_forks": 480, "n_audited_forks": 480, "audit_complete": True,
                   "n_passed_forks": 480 if rc == 0 else 479, "n_failed_forks": 0 if rc == 0 else 1,
                   "transport_certificate": {"valid": rc == 0, "expected": 4, "eligible": 4, "checked": 4,
                                             "passed": 4, "failed": 0, "complete": True}},
                  open(prefix + "_" + t, "w"))
        continue
    open(prefix + "_" + t, "w").write("variant,x\nB,1\n")
sys.exit(rc)
"""
PANEL_STATE = """import json, os, sys
w = "29" if sys.argv[1].endswith("wave29_full.jsonl") else "26"
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write("panel_state" + w + "\\n")
if w == "29":
    assert sys.argv[2].endswith("results/panel29") and len(sys.argv) == 3, sys.argv
else:
    assert sys.argv[2].endswith("cop_results_v53/panel26"), sys.argv
    assert sys.argv[3] == "--audited" and sys.argv[4].endswith("configs/reuse_audits.json"), sys.argv
print(json.dumps({"manifest_jobs": 744, "by_status": {"complete": 744}}))
sys.exit(int(os.environ.get("MOCK_PANEL_STATE" + w, "0")))
"""
REPORT = r"""import json, os, sys
name = os.path.basename(sys.argv[0])
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write(name + " " + " ".join(sys.argv[1:4]) + "\n")
if name == "runtime_v13.py":
    assert sys.argv[1] == "fit" and sys.argv[3].endswith("panel29")
    out = sys.argv[4]
else:
    assert sys.argv[1].endswith("panel29")
    out = sys.argv[2]
json.dump({"passed": True}, open(out, "w"))
"""
REGISTRY = """import json, os, sys
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write("registry read " + sys.argv[2] + "\\n")
assert sys.argv[1].endswith("configs/v62_replication_registry.json") and sys.argv[2].endswith("fork29_contrasts.csv")
json.dump({"results": []}, open(sys.argv[3] + ".json", "w"))
open(sys.argv[3] + ".csv", "w").write("key\\n")
"""
PYTEST = r'''#!/usr/bin/env bash
echo "pytest $*" >> "$MOCK_HOME/events.txt"
xml=""; prev=""
for a in "$@"; do [ "$prev" = "--junitxml" ] && xml="$a"; prev="$a"; done
[ -n "$xml" ] && echo "<testsuites><testsuite tests=\"3\" skipped=\"0\" failures=\"0\" errors=\"0\"/></testsuites>" > "$xml"
exit "${MOCK_TEST_RC:-0}"
'''
ORDER = ["environment", "manifest29", "validate29", "cpu_tests", "run29", "status29", "checks29", "reload29",
         "summary29", "rates29", "fork29", "geometry29", "registry29", "manifest26", "validate26", "panel_source26",
         "geometry26", "status", "evidence29", "manifest_copy", "manifest_copy26", "package", "package_final"]


@pytest.fixture
def h(tmp_path):
    home = tmp_path / "home"
    (home / "scripts").mkdir(parents=True)
    shutil.copy2(ROOT / "scripts" / SCRIPT, home / "scripts" / SCRIPT)
    for f in ("package_reports.py", "check_evidence.py", "panel_status.py", "junit_ran.py"):
        shutil.copy2(ROOT / "scripts" / f, home / "scripts" / f)
    (home / "scripts/panel_state.py").write_text(PANEL_STATE)
    (home / "scripts/replication_registry.py").write_text(REGISTRY)
    (home / "scripts/common.sh").write_text(L.COMMON)
    (home / "audit_v5/tools").mkdir(parents=True)
    (home / "audit_v8/tools").mkdir(parents=True)
    for name in ("fork_continuation.py", "merge_geometry.py"):
        (home / "audit_v5/tools" / name).write_text(TOOL)
    for name in ("fresh_reload.py", "runtime_v13.py"):
        (home / "audit_v5/tools" / name).write_text(REPORT)
    (home / "audit_v8/tools/check_results.py").write_text(REPORT)
    (home / "configs").mkdir()
    for f in ("reuse_audits.json", "v62_replication_registry.json"):
        shutil.copy2(ROOT / "configs" / f, home / "configs" / f)
    pt = home / "fake_pytest.sh"
    pt.write_text(PYTEST)
    pt.chmod(0o755)
    zipdir = tmp_path / "zips"
    zipdir.mkdir()
    (tmp_path / "cop_results_v53").mkdir()
    base = {k: v for k, v in os.environ.items() if k not in ("COP_PYTEST", "DIAGNOSTIC_OVERRIDE", "V53_RESULTS")}
    env = dict(base, MOCK_HOME=str(home), COP_RESULTS=str(tmp_path / "results"), ZIP_DIR=str(zipdir), SCALE="full",
               HOME=str(tmp_path), COP_PYTEST=str(pt), V53_RESULTS=str(tmp_path / "cop_results_v53"),
               **{f"MOCK_FILES_{n}": ",".join(FILES[k]) for n, k in NAMES.items()})
    return {"home": home, "res": tmp_path / "results", "zip": zipdir / "cop_v64_panel_reports.zip", "env": env,
            "tmp": tmp_path}


def _sh(h, common=None, **env):
    if common is not None:
        (h["home"] / "scripts/common.sh").write_text(common)
    e = dict(h["env"], **{k: str(v) for k, v in env.items()})
    return subprocess.run(["bash", str(h["home"] / "scripts" / SCRIPT)], env=e, capture_output=True, text=True,
                          cwd=str(h["home"]))


def _verdict(h):
    return json.loads((h["res"] / "v64_reports/verdict.json").read_text())


def _events(h):
    p = h["home"] / "events.txt"
    return p.read_text() if p.exists() else ""


def test_it_trains_then_runs_every_corrected_analysis_and_packages_everything(h):
    r = _sh(h)
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-3000:]
    v = _verdict(h)
    assert v["all_passed"] and list(v["steps"]) == ORDER
    ev = _events(h)
    run = next(ln for ln in ev.splitlines() if ln.startswith("cop run "))
    assert f"--results {h['res']}/panel29" in run and "wave29_full.jsonl" in run and "--resume" in run
    assert ev.index(run) < ev.index("fork29 read") < ev.index("geometry29 read") < ev.index("registry read") \
        < ev.index("geometry26 read")
    assert f"geometry26 read {h['tmp']}/cop_results_v53/panel26" in ev
    assert not list((h["tmp"] / "cop_results_v53").iterdir())
    st = json.loads((h["res"] / "v64_reports/panel_status.json").read_text())
    assert st["training"]["complete"] and st["fork_validity"]["valid"] is True
    names = zipfile.ZipFile(h["zip"]).namelist()
    for f in ("panel_status.json", "checks29.json", "fresh_reload29.json", "evidence29.json", "wave29_full.jsonl",
              "wave26_full.jsonl", "registry29.json", "registry29.csv"):
        assert f"cop_v64_panel_reports/v64_reports/{f}" in names, f
    for n, k in NAMES.items():
        for f in FILES[k]:
            if f not in ("probes.csv", "contrasts.csv"):
                assert f"cop_v64_panel_reports/v64_reports/{n}_{f}" in names, (n, f)
    assert "compute.csv" in FILES["FORK_FILES"]


def test_on_cuda_it_runs_the_cuda_tests_and_evaluates_folds_on_the_device(h):
    r = _sh(h, common=L.COMMON.replace("DEVICE=cpu", "DEVICE=cuda"))
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-3000:]
    assert list(_verdict(h)["steps"])[4:6] == ["cuda_tests", "cuda_tests_ran"]
    assert "fork29 read" in _events(h) and " recorded cuda" in _events(h)


def test_an_unfinished_panel_analyses_nothing_of_wave_29(h):
    r = _sh(h, MOCK_RUN_RC=1)
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"]["run29"] == 1 and v["steps"]["status29"] == 0
    assert all(v["steps"][k] == 99 for k in ("checks29", "fork29", "geometry29", "registry29"))
    assert v["steps"]["geometry26"] == 0          # the v53 panel is read regardless
    assert "fork29 read" not in _events(h)


def test_failed_tests_train_and_analyse_nothing(h):
    r = _sh(h, MOCK_TEST_RC=1)
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"]["run29"] == 99 and "cop run" not in _events(h) and v["steps"]["geometry26"] == 99


def test_a_failed_fork_analysis_is_not_read_by_the_registry(h):
    r = _sh(h, MOCK_RC_fork29=1)
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"]["fork29"] == 1 and v["steps"]["registry29"] == 99 and v["steps"]["geometry29"] == 0
    assert "registry read" not in _events(h)
    assert json.loads((h["res"] / "v64_reports/panel_status.json").read_text())["fork_validity"]["valid"] is False


def test_a_missing_v53_panel_does_not_stop_wave_29(h):
    r = _sh(h, MOCK_PANEL_STATE26=3)
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"]["panel_source26"] == 3 and v["steps"]["geometry26"] == 99
    assert all(v["steps"][k] == 0 for k in ("run29", "fork29", "geometry29", "registry29", "package"))
    assert h["zip"].exists()


def test_a_reduced_scale_is_refused_before_anything_runs(h):
    r = _sh(h, SCALE="pilot")
    assert r.returncode == 2 and not h["res"].exists() and not _events(h)
