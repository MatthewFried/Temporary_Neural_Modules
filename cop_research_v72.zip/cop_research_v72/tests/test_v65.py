"""v65: the image replication (wave 30) and the mechanism forks (wave 31).

  the image task     image_shortcut: partitions, the shortcut plane, the counterfactual pair, the layout
  the image network  cnn_cut: the 1x1 receiving layer; additions at the middle cut and at the pooled features
  the image fold     exact at every position (zero inputs with offsets, corner / edge / interior impulses, rectangular
                     images, unequal channel counts) in float64; float32 differences on CPU and (cuda) on the GPU
                     reported apart; the compact architecture; a padded 3x3 receiver refused (and shown inexact)
  redistribution     swap and shift keep the function (float64), change the routed backbone gradient and leave the
                     ordinary one unchanged at the edit; refusals; config validation; resume equivalence
  the waves          wave 30 and wave 31 as designed; wave 31 shares wave 29's jobs (same run ids); new draws
  miniatures         a real wave's jobs for one f0, scaled down and trained: image_forks.py and fork_continuation.py
                     pass; the registries read their rows; negative cases fail"""
from __future__ import annotations

import copy
import json
import os
import shutil
import subprocess
import sys
from collections import Counter
from pathlib import Path

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "audit_v5" / "tools"))
import v65_mini as VM  # noqa: E402
from cop.config import ConfigError, resolve, run_id  # noqa: E402
from cop.data.registry import load_bundle  # noqa: E402
from cop.graph import edits as E  # noqa: E402
from cop.graph.accounting import architecture_hash  # noqa: E402
from cop.graph.builders import build_model  # noqa: E402
from cop.graph.export import export_compact  # noqa: E402
from cop.graph.redistribute import redistribute, shift_to_receiver, swap_branches  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
CUDA = pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA device required")
TOY = {"name": "image_shortcut", "n_train": 160, "data_seed": 5, "params": dict(VM.TOY_IMG)}


def _rows(p):
    import csv
    return list(csv.DictReader(open(p)))


def _bundle():
    return load_bundle(TOY)


def _expanded(g, gen_seed=0, cut_kind="post_act", act="identity", width=5, scale=0.4):
    """two rounds of a / b branches (gradient masks spec_a / spec_b) at the cut, every parameter perturbed so the
    branches have nonzero maps and offsets."""
    h = g.clone(share_params=False)
    G = E.insert_group(h, E.cut_at(h, cut_kind, "middle"), torch.Generator().manual_seed(gen_seed))
    for r in (1, 2):
        for ab in "ab":
            E.add_branch(h, G, torch.Generator().manual_seed(100 * r + ord(ab)), width=width, act=act,
                         specialize_mask=f"spec_{ab}", slot=f"spec/r{r}/{ab}")
    gp = torch.Generator().manual_seed(gen_seed + 7)
    with torch.no_grad():
        for n in h.live_nodes():
            if h.nodes[n].owner is not None and h.nodes[n].pkey:
                for p in h.mods[h.nodes[n].pkey].parameters():
                    p.add_(scale * torch.randn(p.shape, generator=gp))
    return h, G


def _f64(g):
    m = copy.deepcopy(g).double()
    m._plan = None
    return m.eval()


def _out(g, x):
    g.eval()
    with torch.no_grad():
        return g({"x": x.to(next(g.parameters()).dtype)}).double()


def _rel(a, b):
    return float((a - b).abs().max()) / max(1.0, float(b.abs().max()))


# ----------------------------------------------------------------------------- the image task and network

def test_the_image_task_has_its_shortcut_plane_partitions_and_layout():
    b = _bundle()
    P = b.partitions()
    assert b.layout == "img" and b.input_spec["x"]["shape"] == [4, 12, 10] and b.out_dim == 2
    assert set(P) == {"train", "val", "test", "shift", "val_indep", "val_reversed", "cf_base", "cf_shortcut"}
    assert b.meta["feature_layout"]["causal"] == [0, 3] and b.meta["feature_layout"]["shortcut"] == 3
    for nm, p in P.items():
        x = p.X["x"]
        assert bool((x[:, 3] == x[:, 3, :1, :1]).all())                  # one constant plane per image
        a = p.aux["_shortcut_a"]
        s = p.aux["_shortcut_value"]
        assert torch.equal(x[:, 3, 0, 0], s.float())
        agree = float((a == p.y).float().mean())
        if nm in ("train", "val"):
            assert agree > 0.85
        elif nm in ("shift", "val_reversed", "cf_shortcut"):
            assert agree < 0.15
        elif nm == "cf_base":
            assert agree == 1.0
        else:
            assert 0.3 < agree < 0.7
    # the colour channels are standardised on the training subset; the plane is not rescaled
    xt = P["train"].X["x"]
    assert abs(float(xt[:, :3].mean())) < 1e-4 and abs(float(xt[:, :3].std()) - 1.0) < 1e-2
    assert torch.equal(P["cf_base"].X["x"][:, :3], P["cf_shortcut"].X["x"][:, :3])
    assert torch.equal(P["cf_base"].X["x"][:, :3], P["test"].X["x"][:len(P["cf_base"]), :3])
    # an image keeps its shortcut value whatever the training-set size (keyed per pool image)
    b2 = load_bundle({**TOY, "n_train": 200})
    i1, i2 = b.train_indices.tolist(), b2.train_indices.tolist()
    common = sorted(set(i1) & set(i2))
    assert len(common) > 50
    v1 = {i: float(v) for i, v in zip(i1, b.train.aux["_shortcut_value"])}
    v2 = {i: float(v) for i, v in zip(i2, b2.train.aux["_shortcut_value"])}
    assert all(v1[i] == v2[i] for i in common)
    with pytest.raises(ValueError):
        load_bundle({**TOY, "augment": "crop_flip"})


def test_the_image_network_has_its_receiving_layer_and_two_cuts():
    b = _bundle()
    g = build_model({"family": "cnn_cut", "width_mult": 0.25}, b, torch.Generator().manual_seed(0))
    cps = {c["kind"]: c for c in g.meta["cutpoints"]}
    assert set(cps) == {"post_act", "penultimate"}
    recv = g.meta["receiving_layer"]
    assert g.nodes[recv].op == "linear" and g.nodes[recv].attrs["layout"] == "img"
    assert [list(e) for e in cps["post_act"]["edges"]] == [[recv, 0]]
    head = g.output
    assert [list(e) for e in cps["penultimate"]["edges"]] == [[head, 0]]
    ops = [g.nodes[n].op for n in g.topo_order(g.live_nodes()) if g.nodes[n].pkey]
    assert ops == ["conv", "conv", "linear", "conv", "linear"]
    assert all(g.mods[g.nodes[n].pkey].bias is not None for n in g.live_nodes() if g.nodes[n].pkey)
    # additions at either cut keep the function at insertion, in the layout of the node they read
    z = _out(g, b.test.X["x"])
    for kind, lay in (("post_act", "img"), ("penultimate", "vec")):
        h = g.clone(share_params=False)
        G = E.insert_group(h, E.cut_at(h, kind, "middle"), torch.Generator().manual_seed(1))
        bid = E.add_branch(h, G, torch.Generator().manual_seed(2), width=6, act="relu", specialize_mask="spec_a")
        assert torch.equal(_out(h, b.test.X["x"]), z)
        assert {h.nodes[n].attrs["layout"] for n in h.implants[bid].nodes} == {lay}


# ----------------------------------------------------------------------------- the image fold

def _impulses(C, H, W):
    out = {"zero": torch.zeros(1, C, H, W)}
    for nm, (i, j) in {"corner": (0, 0), "far_corner": (H - 1, W - 1), "edge": (0, W // 2),
                       "interior": (H // 2, W // 2)}.items():
        x = torch.zeros(1, C, H, W)
        x[0, :, i, j] = 3.0
        out[nm] = x
    out["random"] = torch.randn(4, C, H, W, generator=torch.Generator().manual_seed(3))
    return out


@pytest.mark.parametrize("width_mult,branch_width", [(0.25, 5), (0.5, 3)])
def test_the_image_fold_is_exact_at_every_position(width_mult, branch_width):
    """affine additions with nonzero offsets folded into the 1x1 receiving layer: in float64 the folded network
    computes the expanded one's function on zero inputs (offsets only), on corner, edge and interior impulses and on
    random inputs, for rectangular images and unequal channel counts; float32 differences are rounding."""
    b = _bundle()
    g0 = build_model({"family": "cnn_cut", "width_mult": width_mult}, b, torch.Generator().manual_seed(0))
    h, G = _expanded(g0, width=branch_width)
    folded = export_compact(E.fold_implant(h, G, share_params=False, drop_grad_masks=True), fold_linear=True)[0]
    assert architecture_hash(folded) == architecture_hash(g0)
    assert not any(folded.nodes[n].op == "mask_grad" for n in folded.live_nodes())
    assert not any(im.nodes for im in folded.implants.values())
    h64 = _f64(h)
    # algebra: the fold made in float64 from the float64 network; storage: the float32 fold evaluated in float64
    alg = export_compact(E.fold_implant(h64, G, share_params=False, drop_grad_masks=True), fold_linear=True)[0]
    alg = _f64(alg)
    sto = _f64(folded)
    C, H, W = b.input_spec["x"]["shape"]
    for nm, x in _impulses(C, H, W).items():
        assert _rel(_out(alg, x), _out(h64, x)) < 1e-12, nm
        assert _rel(_out(sto, x), _out(h64, x)) < 1e-6, nm
        assert _rel(_out(folded, x), _out(h, x)) < 1e-5, nm
    # the composed receiving layer is W A, b + W c for the exact map of the merge
    A, c = E.affine_map(h, h.implants[G].entry, h.implants[G].exit, h.region(G))
    recv = h.meta["receiving_layer"]
    Wr, br = h.mods[h.nodes[recv].pkey].weight.double(), h.mods[h.nodes[recv].pkey].bias.double()
    lin = [folded.nodes[n] for n in folded.topo_order(folded.live_nodes()) if folded.nodes[n].op == "linear"]
    Wf, bf = folded.mods[lin[0].pkey].weight.double(), folded.mods[lin[0].pkey].bias.double()
    assert _rel(Wf, Wr @ A.double()) < 1e-6 and _rel(bf, br + Wr @ c.double()) < 1e-6
    assert float(c.abs().max()) > 1e-3                        # the offsets were not zero


@CUDA
def test_the_image_fold_on_the_gpu_cuda():
    """the same fold evaluated in float32 on the GPU (rounding only; float64 on the GPU exact)."""
    dev = os.environ.get("COP_TEST_CUDA_DEVICE", "cuda")
    b = _bundle()
    g0 = build_model({"family": "cnn_cut", "width_mult": 0.25}, b, torch.Generator().manual_seed(0))
    h, G = _expanded(g0)
    folded = export_compact(E.fold_implant(h, G, share_params=False, drop_grad_masks=True), fold_linear=True)[0]
    hg, fg = copy.deepcopy(h).to(dev), copy.deepcopy(folded).to(dev)
    hg._plan = fg._plan = None
    C, H, W = b.input_spec["x"]["shape"]
    for nm, x in _impulses(C, H, W).items():
        xg = x.to(dev)
        assert _rel(_out(fg, xg).cpu(), _out(hg, xg).cpu()) < 1e-4, nm
    hg64 = _f64(hg)
    ag = _f64(export_compact(E.fold_implant(hg64, G, share_params=False, drop_grad_masks=True), fold_linear=True)[0])
    for nm, x in _impulses(C, H, W).items():
        xg = x.to(dev)
        assert _rel(_out(ag, xg).cpu(), _out(hg64, xg).cpu()) < 1e-12, nm


def test_a_fold_into_a_padded_3x3_layer_is_refused_and_would_be_inexact():
    """additions whose merge feeds a padded 3x3 convolution: the fold cannot compose (another architecture), the
    dissipation check refuses it, and the naive composition (kernel x A, bias + sum of kernel x c) is wrong at the
    border on a zero input while right in the interior."""
    from cop.experiments.dissipation import fold_receiver_problems
    b = _bundle()
    g0 = build_model({"family": "cnn_cut", "width_mult": 0.25}, b, torch.Generator().manual_seed(0))
    order = g0.topo_order(g0.live_nodes())
    convs = [n for n in order if g0.nodes[n].op == "conv"]
    a1 = next(n for n in order if g0.nodes[n].op == "act")
    h = g0.clone(share_params=False)
    G = E.insert_group(h, E.Cut(source=a1, consumers=[(convs[1], 0)]), torch.Generator().manual_seed(1))
    for ab in "ab":
        E.add_branch(h, G, torch.Generator().manual_seed(ord(ab)), width=4, act="identity",
                     specialize_mask=f"spec_{ab}", slot=f"spec/r1/{ab}")
    with torch.no_grad():
        for n in h.implants[G].nodes + [x for k in h.implant_children(G) for x in h.implants[k].nodes]:
            if h.nodes[n].pkey:
                for p in h.mods[h.nodes[n].pkey].parameters():
                    p.add_(0.5 * torch.randn(p.shape, generator=torch.Generator().manual_seed(9)))
    assert fold_receiver_problems(h, [G]) and "padded spatial convolution" in fold_receiver_problems(h, [G])[0]
    assert not fold_receiver_problems(_expanded(g0)[0], [_expanded(g0)[1]])
    folded = export_compact(E.fold_implant(h, G, share_params=False, drop_grad_masks=True), fold_linear=True)[0]
    assert architecture_hash(folded) != architecture_hash(g0)        # the fold stays a separate 1x1 layer
    A, c = (t.double() for t in E.affine_map(h, h.implants[G].entry, h.implants[G].exit, h.region(G)))
    conv = h.mods[h.nodes[convs[1]].pkey].double()
    K, bk = conv.weight.detach(), conv.bias.detach()
    Kf = torch.einsum("oikl,ij->ojkl", K, A)
    bf = bk + torch.einsum("oikl,i->o", K, c)
    z = torch.zeros(1, A.shape[1], 6, 5, dtype=torch.float64)
    true = torch.nn.functional.conv2d(z + c.view(1, -1, 1, 1), K, bk, padding=1)
    naive = torch.nn.functional.conv2d(z, Kf, bf, padding=1)
    d = (true - naive).abs()
    assert float(d[..., 2:4, 2:3].max()) < 1e-10 and float(d[..., 0, 0].max()) > 1e-3


# ----------------------------------------------------------------------------- redistribution

def _grads(g, X, y, masks):
    g.train()
    g.zero_grad(set_to_none=True)
    ctx = {"grad_masks": masks} if masks else None
    out = g({"x": X}, ctx) if ctx else g({"x": X})
    torch.nn.functional.cross_entropy(out, y).backward()
    first = next(n for n in g.topo_order(g.live_nodes()) if g.nodes[n].pkey and g.nodes[n].owner is None)
    return g.mods[g.nodes[first].pkey].weight.grad.clone()


@pytest.mark.parametrize("family", ["mlp", "cnn_cut"])
@pytest.mark.parametrize("method", ["keep_swap", "keep_shift50", "keep_shift100"])
def test_redistribution_keeps_the_function_and_changes_only_routed_gradients(family, method):
    """in float64: the edited network computes the same function; the first layer's gradient under ordinary
    gradients (no masks) is unchanged at the edit; under routing (spec_a / spec_b masks) it changes."""
    if family == "mlp":
        b = load_bundle({"name": "shortcut", "n_train": 128, "data_seed": 3, "params": {"d_causal": 6, "d_noise": 4}})
        g0 = build_model({"family": "mlp", "width": 12, "depth": 4}, b, torch.Generator().manual_seed(0))
    else:
        b = _bundle()
        g0 = build_model({"family": "cnn_cut", "width_mult": 0.25}, b, torch.Generator().manual_seed(0))
    h, G = _expanded(g0)
    h64 = _f64(h)
    e64 = _f64(h)
    info = redistribute(e64, method)
    X = b.train.X["x"][:64].double()
    y = b.train.y[:64]
    assert _rel(_out(e64, X), _out(h64, X)) < 1e-12
    m = (torch.arange(64) % 3 != 0).double()
    routed = {"spec_a": m, "spec_b": 1 - m}
    g_o0, g_o1 = _grads(h64, X, y, None), _grads(e64, X, y, None)
    g_r0, g_r1 = _grads(h64, X, y, routed), _grads(e64, X, y, routed)
    assert _rel(g_o1, g_o0) < 1e-10
    assert _rel(g_r1, g_r0) > 1e-4
    if method == "keep_swap":
        assert len(info["moved"]) == 4
    else:
        assert info["s"] == {"keep_shift50": 0.5, "keep_shift100": 0.0}[method]
        assert info["solve_relative_residual"] < 1e-12


def test_swap_moves_tensors_exactly_and_shift_scales_exactly():
    b = _bundle()
    g0 = build_model({"family": "cnn_cut", "width_mult": 0.25}, b, torch.Generator().manual_seed(0))
    h, G = _expanded(g0)
    s0 = {k: v.clone() for k, v in h.state_dict().items()}
    e = h.clone(share_params=False)
    info = swap_branches(e)
    s1 = e.state_dict()
    changed = {k for k in s0 if not torch.equal(s0[k], s1[k])}
    assert changed and len(changed) == 16                     # 2 pairs x 2 layers x (weight, bias) x 2 branches
    e2 = h.clone(share_params=False)
    swap_branches(e2)
    swap_branches(e2)
    assert all(torch.equal(v, e2.state_dict()[k]) for k, v in s0.items())   # a swap twice is the identity
    e3 = h.clone(share_params=False)
    shift_to_receiver(e3, 1.0)
    out = _out(e3, b.test.X["x"])
    assert _rel(out, _out(h, b.test.X["x"])) < 1e-5
    for k in info["pairs"]:
        for bid in k:
            nB = next(n for n in e3.implants[bid].nodes if e3.nodes[n].role == "B")
            assert float(e3.mods[e3.nodes[nB].pkey].weight.abs().max()) == 0.0


def test_redistribution_refuses_other_structures():
    from cop.graph.graph import GraphError
    b = _bundle()
    g0 = build_model({"family": "cnn_cut", "width_mult": 0.25}, b, torch.Generator().manual_seed(0))
    with pytest.raises(GraphError):
        swap_branches(g0.clone(share_params=False))              # no addition
    h = g0.clone(share_params=False)
    G = E.insert_group(h, E.cut_at(h, "post_act", "middle"), torch.Generator().manual_seed(1))
    E.add_branch(h, G, torch.Generator().manual_seed(2), width=4, act="identity", specialize_mask="spec_a",
                 slot="spec/r1/a")
    with pytest.raises(GraphError):
        swap_branches(h)                                          # an a branch without its b partner
    h2, _ = _expanded(g0, act="relu")
    with pytest.raises(GraphError):
        shift_to_receiver(h2, 0.5)                                # not affine
    with pytest.raises(GraphError):
        shift_to_receiver(_expanded(g0)[0], 0.0)                  # the share must be in (0, 1]


def test_the_redistribution_methods_are_validated():
    base = {"kind": "dissipation", "data": {"name": "shortcut", "n_train": 64}, "model": {"family": "mlp"},
            "train": {"baseline_updates": 10}, "growth": {"topology": "specialized", "act": "identity"},
            "parents": {"trajectory": "x"}, "tags": {"parent_stage": "snap_3"}}
    for m in ("keep_swap", "keep_shift50", "keep_shift100"):
        resolve({**base, "dissipation": {"method": m, "removal_masks": "retained"}})
        for bad in ({"optimizer_policy": "carry_from_parent"}, {"split_updates": 2},
                    {"keep_frozen_implants": True}, {"rebuild": {"backbone": "f0", "implants": "receiver"}}):
            with pytest.raises(ConfigError):
                resolve({**base, "dissipation": {"method": m, **bad}})


def test_a_redistribution_fork_resumes_bitwise(tmp_path):
    """an interrupted keep_shift50 fork (from the miniature of wave 31) ends where an uninterrupted one does."""
    from resume_harness import compare_interrupted
    from cop.orchestration.manifest import generate
    cf = VM.shrink(generate([31], "full").entries, 349, 0, 2000, 20,
                   {"top": {"n_train": 128}, "params": {"d_causal": 12, "d_noise": 12}}, {"width": 12})
    by = {run_id(c): c for c in cf}
    job = next(c for c in cf if c["kind"] == "dissipation" and c["dissipation"]["method"] == "keep_shift50"
               and c["tags"]["parent_stage"] == "snap_10" and c["design"]["variant"].startswith("A_"))
    traj = by[job["parents"]["trajectory"]]
    base = by[traj["parents"]["baseline"]]
    rep = compare_interrupted([base, traj, job], tmp_path, fractions=(0.3, 0.7))
    assert rep["interrupted_at_polls"] and rep["equal"], rep


# ----------------------------------------------------------------------------- the waves

def test_wave30_is_the_image_design():
    from cop.orchestration.manifest import generate
    from cop.orchestration.wave13 import V58_CONTS, V59_CONTS, V65_DRAWS, v58_forks, v65_image_arms
    m = generate([30], "full").entries
    cf = {r: e["cfg"] for r, e in m.items()}
    assert len(cf) == 792
    kinds = Counter((c["kind"], (c.get("dissipation") or {}).get("method")) for c in cf.values())
    assert kinds == {("baseline", None): 24, ("trajectory", None): 120, ("dissipation", "linear"): 120,
                     ("continue", None): 48, ("dissipation", "keep"): 384, ("dissipation", "fold_unrouted"): 96}
    assert {c["data"]["data_seed"] for c in cf.values()} == set(V65_DRAWS) == set(range(361, 373))
    assert all(c["data"]["name"] == "image_shortcut" and c["model"]["family"] == "cnn_cut" and
               c["data"]["n_train"] == 8192 for c in cf.values())
    used = set()
    for w in range(13, 30):
        try:
            used |= {e["cfg"]["data"].get("data_seed") for e in generate([w], "full").entries.values()
                     if isinstance(e["cfg"].get("data"), dict)}
        except KeyError:
            continue
    assert not used & set(V65_DRAWS)
    arms = v65_image_arms()
    tr = [c for c in cf.values() if c["kind"] == "trajectory"]
    assert Counter((c["growth"]["cut_kind"], c["growth"]["spec_partition"], c["growth"]["act"]) for c in tr) == {
        ("post_act", "random_matched", "identity"): 48, ("post_act", "all_examples", "identity"): 48,
        ("penultimate", "all_examples", "relu"): 24}
    assert all(c["growth"]["spec_random_fraction"] == 0.95 for c in tr if c["growth"]["spec_partition"] ==
               "random_matched")
    assert all(c["growth"]["updates_per_round"] == 2000 for c in tr)
    lin = [c for c in cf.values() if (c.get("dissipation") or {}).get("method") == "linear"]
    assert Counter(c["design"]["variant"] for c in lin) == {a: 24 for a in arms}
    forks = [c for c in cf.values() if c["kind"] == "dissipation" and c["design"]["family"] == "X28"]
    seen = Counter()
    for c in forks:
        parent, _, stage = c["design"]["variant"].partition("@")
        t = cf[c["parents"]["trajectory"]]
        assert parent in ("A_routed_affine", "B_routed_affine") and t["growth"]["spec_partition"] == "random_matched"
        assert c["dissipation"]["post_updates"] == 4000 - v58_forks(2000)[stage]
        for k, v in {**V58_CONTS, **V59_CONTS}[c["design"]["arm"]].items():
            assert c["dissipation"][k] == v
        assert c["train"] == t["train"]
        assert t["train"]["freeze_inputs"] == ("shortcut" if parent.startswith("B") else "none")
        seen[(parent, stage, c["design"]["arm"])] += 1
    assert len(seen) == 20 and set(seen.values()) == {24}


def test_wave31_reuses_wave29s_jobs_and_adds_the_mechanism_forks():
    from cop.orchestration.manifest import generate
    from cop.orchestration.wave13 import V65_CONTS
    m29, m31 = generate([29], "full").entries, generate([31], "full").entries
    shared = set(m29) & set(m31)
    assert len(m31) == 1032 and len(shared) == 552
    assert all(m29[r]["cfg"] == m31[r]["cfg"] for r in shared)              # the same jobs, the same run ids
    new = {r: m31[r]["cfg"] for r in set(m31) - set(m29)}
    assert len(new) == 480 and all(c["kind"] == "dissipation" for c in new.values())
    seen = Counter()
    for c in new.values():
        assert c["parents"]["trajectory"] in shared and c["design"]["family"] == "X28"
        parent, _, stage = c["design"]["variant"].partition("@")
        for k, v in V65_CONTS[c["design"]["arm"]].items():
            assert c["dissipation"][k] == v
        t = m29[c["parents"]["trajectory"]]["cfg"]
        assert c["train"] == t["train"] and c["tags"]["parent_stage"] == stage
        seen[(parent, stage, c["design"]["arm"])] += 1
    assert len(seen) == 20 and set(seen.values()) == {24}


# ----------------------------------------------------------------------------- the miniatures

def _tool(*args, cuda_off=True):
    return subprocess.run([sys.executable, *map(str, args)], capture_output=True, text=True,
                          env=dict(os.environ, **({"CUDA_VISIBLE_DEVICES": ""} if cuda_off else {})))


@pytest.fixture(scope="module")
def mini30(tmp_path_factory):
    from cop.orchestration.manifest import generate
    root = tmp_path_factory.mktemp("mini30")
    cf = VM.shrink(generate([30], "full").entries, 361, 0, 2000, 20,
                   {"top": {"n_train": 160}, "params": VM.TOY_IMG}, {"width_mult": 0.25})
    VM.run_all(cf, root)
    man = VM.write_manifest(root / "m.jsonl", cf)
    r = _tool(ROOT / "audit_v5/tools/image_forks.py", root, root / "image30", "--manifest", man, "--strict",
              "--device", "cpu")
    return {"root": root, "cf": cf, "man": man, "r": r}


@pytest.fixture(scope="module")
def mini31(tmp_path_factory):
    from cop.orchestration.manifest import generate
    root = tmp_path_factory.mktemp("mini31")
    cf = VM.shrink(generate([31], "full").entries, 349, 0, 2000, 20,
                   {"top": {"n_train": 192}, "params": {"d_causal": 12, "d_noise": 12}}, {"width": 12})
    VM.run_all(cf, root)
    man = VM.write_manifest(root / "m.jsonl", cf)
    r = _tool(ROOT / "audit_v5/tools/fork_continuation.py", root, root / "fork31", "--manifest", man, "--strict",
              "--device", "cpu")
    return {"root": root, "cf": cf, "man": man, "r": r}


def test_the_image_miniature_passes_its_analysis(mini30):
    r = mini30["r"]
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-3000:]
    root = mini30["root"]
    cov = json.loads((root / "image30_coverage.json").read_text())
    assert cov["passed"] and cov["n_states"] == 1 + 5 * 2 + 2 * 2 * 6 + 4 and cov["audit_complete"]
    assert cov["n_expected_forks"] == cov["n_passed_forks"] == 20
    assert cov["fold_precision"]["fold_algebra64"] < 1e-12
    st = _rows(root / "image30_states.csv")
    states = Counter((x["parent"], x["fork"], x["state"]) for x in st)
    assert states[("A_head_all_relu", "end", "trajectory_end")] == 1 and states[("B", "compact", "compact_4U")] == 1
    by = {(x["parent"], x["fork"], x["state"]): x for x in st}
    assert by[("A_head_all_relu", "end", "trajectory_end")]["has_additions"] == "True"
    assert by[("A_routed_affine", "snap_25", "folded_reset")]["has_additions"] == "False"
    for x in st:
        assert x["native_shortcut_flip_rate"] != "" and x["state_at_f0_block_row_norms_f0_bias_test_err"] != ""
    f0r = by[("f0", "f0", "f0")]
    assert float(f0r["extraction_test_err"]) == float(f0r["native_test_err"])
    assert float(f0r["state_at_f0_block_row_norms_f0_bias_test_err"]) == float(f0r["native_test_err"])
    # the held arm keeps its shortcut-channel kernels exactly (f0's) through the trajectory and its forks
    by_id = {run_id(c): c for c in mini30["cf"]}
    f0id = next(r_ for r_, c in by_id.items() if c["kind"] == "baseline")
    tB = next(r_ for r_, c in by_id.items() if c["kind"] == "trajectory" and c["train"]["freeze_inputs"] == "shortcut"
              and c["growth"]["spec_partition"] == "random_matched")
    ck0 = torch.load(root / "runs" / tB / "ckpt" / "baseline_ref.pt", weights_only=False)["model"]["state"]
    ck1 = torch.load(root / "runs" / tB / "ckpt" / "final.pt", weights_only=False)["model"]["state"]
    k = next(k for k, v in ck0.items() if v.dim() == 4)
    assert torch.equal(ck0[k][:, 3], ck1[k][:, 3]) and not torch.equal(ck0[k][:, :3], ck1[k][:, :3])
    assert f0id
    co = _rows(root / "image30_contrasts.csv")
    arm = [x for x in co if x["comparison"] == "arm_minus_arm"]
    assert {(x["fork"], x["first"], x["second"]) for x in arm} == {
        (f, a, b) for f in ("trajectory_end", "removal_end")
        for a, b in (("A_routed_affine", "A_all_affine"), ("A_routed_affine", "A_head_all_relu"),
                     ("A_all_affine", "A_head_all_relu"), ("B_routed_affine", "B_all_affine"))}


def test_the_image_registry_reads_the_miniature(mini30, tmp_path):
    reg = json.loads((ROOT / "configs/v65_image_registry.json").read_text())
    assert [h["key"] for h in reg["hypotheses"] if h["role"] == "primary"] == [
        "early_routing_improves_normalised_extraction", "early_routing_worsens_the_complete_network",
        "late_folding_retains_a_component_advantage", "expansion_history_beats_compact_continuation",
        "routed_expansion_beats_the_late_head"]
    from v66_helpers import bind, draw_seed
    cs = mini30["root"] / "image30_contrasts.csv"
    reg = bind(reg, mini30["root"] / "image30_coverage.json", *draw_seed(cs), {"snap_1000": "snap_10", "snap_2500": "snap_25"})
    p = tmp_path / "r.json"
    p.write_text(json.dumps(reg))
    r = _tool(ROOT / "scripts/replication_registry.py", p, cs, tmp_path / "o", "--coverage",
              mini30["root"] / "image30_coverage.json", "--manifest", mini30["man"], "--audits",
              mini30["root"] / "image30_audits.csv", "--states", mini30["root"] / "image30_states.csv")
    assert r.returncode == 0, r.stdout + r.stderr
    rec = json.loads((tmp_path / "o.json").read_text())
    assert all(x["found"] for x in rec["results"])
    assert next(x for x in rec["results"] if x["role"] == "primary")["interval_level"] == pytest.approx(0.99)


def test_image_negative_cases_fail(mini30, tmp_path):
    root = tmp_path / "copy"
    shutil.copytree(mini30["root"] / "runs", root / "runs")
    # the saved fold with its receiving layer left as the snapshot's (the composition went nowhere)
    fold = next(c for c in mini30["cf"] if (c.get("dissipation") or {}).get("method") == "fold_unrouted")
    rid = run_id(fold)
    ckp = root / "runs" / rid / "ckpt" / "event_after_fold.pt"
    ck = torch.load(ckp, weights_only=False)
    lin_keys = [k for k, v in ck["model"]["state"].items() if v.dim() == 2]
    tgt = max(lin_keys, key=lambda k: ck["model"]["state"][k].numel())      # the receiving 1x1 layer (not the head)
    ck["model"]["state"][tgt] = ck["model"]["state"][tgt] * 1.5
    torch.save(ck, ckp)
    r = _tool(ROOT / "audit_v5/tools/image_forks.py", root, tmp_path / "x", "--manifest", mini30["man"], "--strict",
              "--device", "cpu")
    assert r.returncode == 1
    cov = json.loads((tmp_path / "x_coverage.json").read_text())
    fails = {x["run_id"]: set(x) - {"f0", "parent", "fork", "state", "run_id"} for x in cov["audit_failures"]}
    assert set(fails) == {rid} and {"fold_start"} <= fails[rid]
    # one fork left out of the manifest
    man = tmp_path / "m.jsonl"
    drop = next(run_id(c) for c in mini30["cf"] if (c.get("dissipation") or {}).get("method") == "keep")
    man.write_text("".join(ln for ln in Path(mini30["man"]).read_text().splitlines(keepends=True)
                           if json.loads(ln)["run_id"] != drop))
    r = _tool(ROOT / "audit_v5/tools/image_forks.py", mini30["root"], tmp_path / "y", "--manifest", man, "--strict",
              "--device", "cpu")
    assert r.returncode == 1
    cov = json.loads((tmp_path / "y_coverage.json").read_text())
    assert not cov["passed"] and "not a complete wave-30 design" in cov["failed"][0]["reason"]


def test_the_mechanism_miniature_passes_its_analysis(mini31):
    r = mini31["r"]
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-3000:]
    root = mini31["root"]
    cov = json.loads((root / "fork31_coverage.json").read_text())
    assert cov["passed"] and cov["n_expected_forks"] == cov["n_passed_forks"] == 40
    assert set(cov["design"]["continuations"]) == {"routed_reset", "ordinary_reset", "frozen_reset", "folded_reset",
                                                   "routed_carry", "routed_swap", "ordinary_swap", "routed_shift50",
                                                   "routed_shift100", "ordinary_shift100"}
    assert cov["redistribution_precision"]["redistribution_algebra64"] < 1e-12
    assert not cov["redistribution_storage_flags"]
    au = _rows(root / "fork31_audits.csv")
    mech = [x for x in au if x["state"] in ("routed_swap", "ordinary_swap", "routed_shift50", "routed_shift100",
                                             "ordinary_shift100")]
    assert len(mech) == 20 and all(x["redistribution"] == "True" for x in mech)
    assert all(x["mask_membership_detail"].startswith("masks retained") == x["state"].startswith("routed")
               for x in mech)
    co = _rows(root / "fork31_contrasts.csv")
    st = {(x["parent"], x["fork"], x["state"]): x for x in _rows(root / "fork31_states.csv")}
    inter = [x for x in co if x["comparison"] == "swap_interaction" and x["metric"] == "native_test_err"]
    assert len(inter) == 4
    for x in inter:
        g_ = lambda s_: float(st[(x["parent"], x["fork"], s_)]["native_test_err"])
        want = (g_("routed_swap") - g_("routed_reset")) - (g_("ordinary_swap") - g_("ordinary_reset"))
        assert float(x["value"]) == pytest.approx(want, abs=1e-12)


def test_the_mechanism_registry_reads_the_miniature(mini31, tmp_path):
    reg = json.loads((ROOT / "configs/v65_mechanism_registry.json").read_text())
    assert all(h["favourable"] == "two-sided" for h in reg["hypotheses"])
    assert [h["key"] for h in reg["hypotheses"] if h["role"] == "primary"] == ["swap_changes_routed_learning",
                                                                                "shift_changes_routed_learning"]
    from v66_helpers import bind, draw_seed
    cs = mini31["root"] / "fork31_contrasts.csv"
    reg = bind(reg, mini31["root"] / "fork31_coverage.json", *draw_seed(cs), {"snap_1000": "snap_10", "snap_2500": "snap_25"})
    p = tmp_path / "r.json"
    p.write_text(json.dumps(reg))
    r = _tool(ROOT / "scripts/replication_registry.py", p, cs, tmp_path / "o", "--coverage",
              mini31["root"] / "fork31_coverage.json", "--manifest", mini31["man"], "--audits",
              mini31["root"] / "fork31_audits.csv", "--states", mini31["root"] / "fork31_states.csv")
    assert r.returncode == 0, r.stdout + r.stderr
    rec = json.loads((tmp_path / "o.json").read_text())
    assert all(x["found"] for x in rec["results"])
    assert all(x["reading"] in ("inconclusive", "nonzero (positive)", "nonzero (negative)") or
               x["reading"].startswith("secondary:") for x in rec["results"])


def test_a_tampered_redistribution_start_fails(mini31, tmp_path):
    root = tmp_path / "copy"
    shutil.copytree(mini31["root"] / "runs", root / "runs")
    job = next(c for c in mini31["cf"] if (c.get("dissipation") or {}).get("method") == "keep_swap")
    rid = run_id(job)
    ckp = root / "runs" / rid / "ckpt" / "event_after_redistribute.pt"
    ck = torch.load(ckp, weights_only=False)
    snap = torch.load(root / "runs" / job["parents"]["trajectory"] / "ckpt" / f"{job['tags']['parent_stage']}.pt",
                      weights_only=False)["model"]["state"]
    ck["model"]["state"] = {k: v.clone() for k, v in snap.items()}            # the swap undone
    torch.save(ck, ckp)
    r = _tool(ROOT / "audit_v5/tools/fork_continuation.py", root, tmp_path / "x", "--manifest", mini31["man"],
              "--strict", "--device", "cpu")
    assert r.returncode == 1
    cov = json.loads((tmp_path / "x_coverage.json").read_text())
    fails = {x["run_id"]: x for x in cov["audit_failures"]}
    assert set(fails) == {rid} and "redistribution" in fails[rid]
