"""v65: the launcher (scripts/65) in the v48 launcher test's mock COP_HOME.  Both manifests and their validation,
CPU (and on CUDA, CUDA) tests; wave 31: v64's panel copied under the audit (only read) and verified by a retrained
sample before training; wave 30: the image data checked, then trained; per panel status, checks, reload, summary,
timing, the analysis (image_forks on the training device; fork_continuation on the CPU) and its registry (only after
a passed analysis); status records, evidence, packaging."""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import test_v48_launcher as L  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = "65_v65_panels.sh"
SRC = (ROOT / "scripts" / SCRIPT).read_text()
FILES = {k: re.search(rf'^{k}="([^"]+)"', SRC, re.M).group(1).split(",") for k in ("IMG_FILES", "FORK_FILES")}
NAMES = {"image30": "IMG_FILES", "fork31": "FORK_FILES"}
TOOL = r"""import json, os, sys
panel, prefix = sys.argv[1], sys.argv[2]
name = os.path.basename(prefix)
tool = os.path.basename(sys.argv[0])[:-3]
assert (tool, name) in (("image_forks", "image30"), ("fork_continuation", "fork31")), (tool, name)
w = name[-2:]
assert panel.endswith(f"results/panel{w}") and prefix.endswith("v65_reports/" + name), sys.argv
assert "--strict" in sys.argv and sys.argv[sys.argv.index("--manifest") + 1].endswith(f"wave{w}_full.jsonl")
assert sys.argv[sys.argv.index("--device") + 1] == ("cpu" if w == "31" else os.environ["EXPECT_DEVICE"])
rd = sys.argv[sys.argv.index("--recorded-device") + 1] if "--recorded-device" in sys.argv else "none"
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write(name + " read " + panel + " recorded " + rd + "\n")
rc = int(os.environ.get("MOCK_RC_" + name, "0"))
for t in os.environ["MOCK_FILES_" + name].split(","):
    if t.endswith(".json"):
        json.dump({"passed": rc == 0, "analysis_complete": True, "audit_failures": [] if rc == 0 else [{"x": 1}],
                   "n_expected_forks": 480, "n_audited_forks": 480, "audit_complete": True,
                   "n_passed_forks": 480 if rc == 0 else 479, "n_failed_forks": 0 if rc == 0 else 1},
                  open(prefix + "_" + t, "w"))
        continue
    open(prefix + "_" + t, "w").write("variant,x\nB,1\n")
sys.exit(rc)
"""
PANEL_STATE = """import json, os, sys
w = "30" if sys.argv[1].endswith("wave30_full.jsonl") else "31"
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write("panel_state" + w + " " + " ".join(sys.argv[3:]) + "\\n")
assert sys.argv[2].endswith(f"results/panel{w}"), sys.argv
if w == "31":
    assert sys.argv[3] == "--audited" and sys.argv[4].endswith("configs/reuse_audits.json"), sys.argv
print(json.dumps({"manifest_jobs": 792, "by_status": {"complete": 792}}))
"""
REPORT = r"""import json, os, sys
name = os.path.basename(sys.argv[0])
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write(name + " " + " ".join(sys.argv[1:4]) + "\n")
if name == "runtime_v13.py":
    out = sys.argv[4]
else:
    out = sys.argv[2]
json.dump({"passed": True}, open(out, "w"))
"""
SEED = r"""import json, os, sys
man, src, dst, out = sys.argv[1:5]
assert man.endswith("wave31_full.jsonl") and dst.endswith("results/panel31") and out.endswith("v65_reports/seed31.json")
assert src.endswith("cop_results_v64/panel29"), sys.argv
assert sys.argv[5] == "--audited" and sys.argv[6].endswith("configs/reuse_audits.json"), sys.argv
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write("seed " + src + " -> " + dst + "\n")
json.dump({"source": src, "n_copied": 552}, open(out, "w"))
sys.exit(int(os.environ.get("MOCK_SEED_RC", "0")))
"""
REUSE = r"""import json, os, sys
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write("reuse " + " ".join(sys.argv[1:]) + "\n")
if sys.argv[1] == "select":
    man, panel, sub = sys.argv[2:5]
    assert man.endswith("wave31_full.jsonl") and panel.endswith("results/panel31") and sub.endswith("reuse_sample31.jsonl")
    rc = int(os.environ.get("MOCK_REUSE_SELECT_RC", "0"))
    if rc == 0:
        open(sub, "w").write('{"run_id": "base-x"}\n')
    sys.exit(rc)
sub, panel, scratch, out = sys.argv[2:6]
assert sub.endswith("reuse_sample31.jsonl") and panel.endswith("results/panel31") and scratch.endswith("reuse_check31")
json.dump({"reproduced": True}, open(out, "w"))
sys.exit(int(os.environ.get("MOCK_REUSE_COMPARE_RC", "0")))
"""
DATA = """import os, sys
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write("data " + sys.argv[1] + "\\n")
sys.exit(int(os.environ.get("MOCK_DATA_RC", "0")))
"""
REGISTRY = """import json, os, sys
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write("registry " + os.path.basename(sys.argv[1]) + " " + sys.argv[2] + "\\n")
json.dump({"results": []}, open(sys.argv[3] + ".json", "w"))
open(sys.argv[3] + ".csv", "w").write("key\\n")
"""
PYTEST = r'''#!/usr/bin/env bash
echo "pytest $*" >> "$MOCK_HOME/events.txt"
xml=""; prev=""
for a in "$@"; do [ "$prev" = "--junitxml" ] && xml="$a"; prev="$a"; done
[ -n "$xml" ] && echo "<testsuites><testsuite tests=\"3\" skipped=\"0\" failures=\"0\" errors=\"0\"/></testsuites>" > "$xml"
exit "${MOCK_TEST_RC:-0}"
'''
COMMON = L.COMMON.replace('      return "${MOCK_RUN_RC:-0}" ;;',
                          '      case "$5" in *reuse_check31) return "${MOCK_REUSE_RUN_RC:-0}" ;;\n'
                          '                   *panel30) return "${MOCK_RUN30_RC:-0}" ;;\n'
                          '                   *panel31) return "${MOCK_RUN31_RC:-0}" ;; esac\n'
                          '      return "${MOCK_RUN_RC:-0}" ;;')
assert COMMON != L.COMMON
ORDER = ["environment", "manifest30", "manifest31", "validate30", "validate31", "cpu_tests", "seed31",
         "reuse_select31", "reuse_run31", "reuse_compare31", "run31", "data30", "run30",
         "status31", "checks31", "reload31", "summary31", "rates31", "fork31", "registry31",
         "status30", "checks30", "reload30", "summary30", "rates30", "image30", "registry30",
         "status_record30", "status_record31", "evidence", "manifest_copy30", "manifest_copy31", "package",
         "package_final"]


@pytest.fixture
def h(tmp_path):
    home = tmp_path / "home"
    (home / "scripts").mkdir(parents=True)
    shutil.copy2(ROOT / "scripts" / SCRIPT, home / "scripts" / SCRIPT)
    for f in ("package_reports.py", "check_evidence.py", "panel_status.py", "junit_ran.py"):
        shutil.copy2(ROOT / "scripts" / f, home / "scripts" / f)
    for f, body in (("panel_state.py", PANEL_STATE), ("seed_panel.py", SEED), ("reuse_reproduce.py", REUSE),
                    ("check_image_data.py", DATA), ("replication_registry.py", REGISTRY)):
        (home / "scripts" / f).write_text(body)
    (home / "scripts/common.sh").write_text(COMMON)
    (home / "audit_v5/tools").mkdir(parents=True)
    (home / "audit_v8/tools").mkdir(parents=True)
    for name in ("image_forks.py", "fork_continuation.py"):
        (home / "audit_v5/tools" / name).write_text(TOOL)
    for name in ("fresh_reload.py", "runtime_v13.py"):
        (home / "audit_v5/tools" / name).write_text(REPORT)
    (home / "audit_v8/tools/check_results.py").write_text(REPORT)
    (home / "configs").mkdir()
    for f in ("reuse_audits.json", "v65_image_registry.json", "v65_mechanism_registry.json"):
        shutil.copy2(ROOT / "configs" / f, home / "configs" / f)
    pt = home / "fake_pytest.sh"
    pt.write_text(PYTEST)
    pt.chmod(0o755)
    zipdir = tmp_path / "zips"
    zipdir.mkdir()
    (tmp_path / "cop_results_v64" / "panel29").mkdir(parents=True)
    base = {k: v for k, v in os.environ.items() if k not in ("COP_PYTEST", "DIAGNOSTIC_OVERRIDE", "V64_RESULTS",
                                                             "SEED", "SEED_FROM")}
    env = dict(base, MOCK_HOME=str(home), COP_RESULTS=str(tmp_path / "results"), ZIP_DIR=str(zipdir), SCALE="full",
               HOME=str(tmp_path), COP_PYTEST=str(pt), EXPECT_DEVICE="cpu",
               **{f"MOCK_FILES_{n}": ",".join(FILES[k]) for n, k in NAMES.items()})
    return {"home": home, "res": tmp_path / "results", "zip": zipdir / "cop_v65_panel_reports.zip", "env": env,
            "tmp": tmp_path}


def _sh(h, common=None, **env):
    if common is not None:
        (h["home"] / "scripts/common.sh").write_text(common)
    e = dict(h["env"], **{k: str(v) for k, v in env.items()})
    return subprocess.run(["bash", str(h["home"] / "scripts" / SCRIPT)], env=e, capture_output=True, text=True,
                          cwd=str(h["home"]))


def _verdict(h):
    return json.loads((h["res"] / "v65_reports/verdict.json").read_text())


def _events(h):
    p = h["home"] / "events.txt"
    return p.read_text() if p.exists() else ""


def test_it_copies_verifies_trains_both_panels_analyses_and_packages(h):
    r = _sh(h)
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-3000:]
    v = _verdict(h)
    assert v["all_passed"] and list(v["steps"]) == ORDER
    ev = _events(h)
    runs = [ln for ln in ev.splitlines() if ln.startswith("cop run ")]
    assert any("panel31" in x for x in runs) and any("panel30" in x for x in runs)
    i_seed, i_cmp = ev.index("seed "), ev.index("reuse compare")
    i_run31 = next(ev.index(x) for x in runs if "results/panel31" in x)
    i_run30 = next(ev.index(x) for x in runs if "results/panel30" in x)
    assert i_seed < i_cmp < i_run31 < ev.index("data ") < i_run30 < ev.index("fork31 read") < ev.index("image30 read")
    assert "registry v65_mechanism_registry.json" in ev and "registry v65_image_registry.json" in ev
    assert not list((h["tmp"] / "cop_results_v64" / "panel29").iterdir())        # v64's panel was only read
    for w in ("30", "31"):
        st = json.loads((h["res"] / f"v65_reports/panel_status{w}.json").read_text())
        assert st["training"]["complete"] and st["fork_validity"]["valid"] is True
    names = zipfile.ZipFile(h["zip"]).namelist()
    for f in ("panel_status30.json", "panel_status31.json", "evidence.json", "wave30_full.jsonl", "wave31_full.jsonl",
              "registry30.json", "registry31.csv", "seed31.json", "reuse_check31.json", "checks30.json",
              "fresh_reload31.json"):
        assert f"cop_v65_panel_reports/v65_reports/{f}" in names, f
    for n, k in NAMES.items():
        for f in FILES[k]:
            if f != "contrasts.csv":
                assert f"cop_v65_panel_reports/v65_reports/{n}_{f}" in names, (n, f)


def test_on_cuda_the_image_analysis_runs_on_the_device(h):
    r = _sh(h, common=COMMON.replace("DEVICE=cpu", "DEVICE=cuda"), EXPECT_DEVICE="cuda")
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-3000:]
    assert list(_verdict(h)["steps"])[6:8] == ["cuda_tests", "cuda_tests_ran"]
    ev = _events(h)
    assert "image30 read" in ev and "fork31 read" in ev and ev.count(" recorded cuda") == 2


def test_a_failed_verification_trains_no_mechanism_fork_but_the_image_panel_runs(h):
    r = _sh(h, MOCK_REUSE_COMPARE_RC=1)
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"]["reuse_compare31"] == 1 and v["steps"]["run31"] == 99
    assert all(v["steps"][k] == 99 for k in ("status31", "fork31", "registry31"))
    assert v["steps"]["run30"] == 0 and v["steps"]["image30"] == 0 and v["steps"]["registry30"] == 0
    assert not any("results/panel31" in ln for ln in _events(h).splitlines() if ln.startswith("cop run "))


def test_missing_image_data_skips_the_image_panel_only(h):
    r = _sh(h, MOCK_DATA_RC=1)
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"]["data30"] == 1 and v["steps"]["run30"] == 99 and v["steps"]["image30"] == 99
    assert v["steps"]["run31"] == 0 and v["steps"]["fork31"] == 0 and v["steps"]["registry31"] == 0


def test_a_failed_analysis_is_not_read_by_its_registry(h):
    r = _sh(h, MOCK_RC_fork31=1)
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"]["fork31"] == 1 and v["steps"]["registry31"] == 99 and v["steps"]["registry30"] == 0
    assert "registry v65_mechanism_registry.json" not in _events(h)
    st = json.loads((h["res"] / "v65_reports/panel_status31.json").read_text())
    assert st["fork_validity"]["valid"] is False


def test_an_unfinished_panel_analyses_nothing_of_it(h):
    r = _sh(h, MOCK_RUN30_RC=1)
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"]["run30"] == 1 and v["steps"]["status30"] == 0
    assert all(v["steps"][k] == 99 for k in ("checks30", "image30", "registry30"))
    assert v["steps"]["fork31"] == 0


def test_failed_tests_train_nothing(h):
    r = _sh(h, MOCK_TEST_RC=1)
    assert r.returncode != 0
    v = _verdict(h)
    assert v["steps"]["run30"] == 99 and v["steps"]["run31"] == 99 and v["steps"]["seed31"] == 99
    assert "cop run" not in _events(h) and "seed " not in _events(h)


def test_a_reduced_scale_is_refused_before_anything_runs(h):
    r = _sh(h, SCALE="pilot")
    assert r.returncode == 2 and not h["res"].exists() and not _events(h)


def test_the_audit_accepts_v60_to_v64_runs_for_this_code():
    sys.path.insert(0, str(ROOT / "scripts"))
    import reuse_audit as RA
    from cop.utils import semantic_code_hash
    au = {a["id"]: a for a in RA.load(ROOT / "configs/reuse_audits.json", semantic_code_hash())}
    a = au["v68_from_v60"]                     # v68: carried over to the current code
    assert a["produced_by_semantic_hash"] == "09850974bb32663f"
    assert RA.in_scope(a, {"kind": "dissipation", "dissipation": {"method": "fold_unrouted"}})
    assert RA.in_scope(a, {"kind": "trajectory"}) and not RA.in_scope(a, {"kind": "transplant"})
