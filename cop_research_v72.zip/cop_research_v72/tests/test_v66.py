"""v66: the re-audit revision (CHANGES_v66.md).

  registry      the reader is bound to its evidence: exact draws x seeds, one finite row each, one design, the
                coverage's schema / manifest / design; missing, duplicated, extra, cross-design and non-finite rows,
                a missing arm, an unbound coverage are not read; failed audits make a reading conditional, a failed
                prerequisite or coverage diagnostic; the exit codes
  registries    the v66 registries keep the earlier primaries unchanged and carry their contracts
  numerics      func_compare and within reject NaN and infinities (no zero discrepancy)
  wave 32       the reset-matched compact controls as designed
  miniatures    waves 31 + 32 (MLP) and 30 + 32 (images) scaled down and trained: the reset-matched control is
                measured, the storage certificate, event integrity and eligibility are reported, the mechanism
                diagnostics and validity table read them, the bound registries read them; tampered starts (storage
                within the composition tolerance, a tiny change without a new hash, a NaN with a new hash, a fold
                start changed slightly) fail for the right reason; an analysis-only batch size leaves the states"""
from __future__ import annotations

import csv
import json
import math
import shutil
import subprocess
import sys
from collections import Counter
from pathlib import Path

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "audit_v5" / "tools"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import v65_mini as VM  # noqa: E402
from v66_helpers import bind, draw_seed  # noqa: E402
from cop.config import run_id  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
REG = ROOT / "scripts/replication_registry.py"


def _rows(p):
    return list(csv.DictReader(open(p)))


def _tool(*args):
    import os
    return subprocess.run([sys.executable, *map(str, args)], capture_output=True, text=True,
                          env=dict(os.environ, CUDA_VISIBLE_DEVICES=""))


# the synthetic registry-reader, comparison and prerequisite tests moved to tests/test_v68.py (v68 binding)


# ----------------------------------------------------------------------------- the v66 registries

@pytest.mark.parametrize("new, old, schema, draws, conts", [
    ("v66_wave29_registry", "v62_replication_registry", "fork_continuation/v68", range(349, 361), 5),
    ("v66_image_registry", "v65_image_registry", "image_forks/v68", range(361, 373), 5),
    ("v66_mechanism_registry", "v65_mechanism_registry", "fork_continuation/v68", range(349, 361), 10)])
def test_the_v66_registries_keep_the_primaries_and_carry_contracts(new, old, schema, draws, conts):
    n = json.loads((ROOT / f"configs/{new}.json").read_text())
    o = json.loads((ROOT / f"configs/{old}.json").read_text())
    fields = ("key", "parent", "fork", "comparison", "first", "second", "metric", "favourable")
    prim = lambda r: [tuple(h[f] for f in fields) for h in r["hypotheses"] if h["role"] == "primary"]  # noqa: E731
    assert prim(n) == prim(o) and n["multiplicity"] == o["multiplicity"]
    c = n["contract"]
    assert c["analysis_schemas"] == [schema] and c["data_draws"] == list(draws) and c["optimizer_seeds"] == [0, 1]
    assert len(c["design"]["continuations"]) == conts and c["design"]["forks"] == ["snap_1000", "snap_2500"]
    old_keys = {h["key"] for h in o["hypotheses"]}
    for h in n["hypotheses"]:
        if h["key"] not in old_keys:
            assert h["role"] == "secondary" and h.get("added_in_v66") is True
    assert "preregistration" not in json.dumps(n).replace("not a preregistration", "")


def test_the_mechanism_wording_is_corrected():
    n = json.loads((ROOT / "configs/v66_mechanism_registry.json").read_text())
    t = json.dumps(n)
    assert "zeroed trainable additions retained" in t and "not a removal" in t
    assert "summation order" in t and "does not by itself" in t
    i = json.loads((ROOT / "configs/v66_image_registry.json").read_text())
    late = next(h for h in i["hypotheses"] if h["key"] == "routed_expansion_beats_the_late_head")
    assert "two complete interventions" in late["reads"]
    assert "image-content block" in i["scope"] and "conditional on this image corpus" in i["scope"]


# ----------------------------------------------------------------------------- numerics

def test_func_compare_and_within_reject_non_finite_values():
    import fork_continuation as FC
    from cop.data.registry import load_bundle
    from cop.graph.builders import build_model
    b = load_bundle({"name": "shortcut", "n_train": 64, "data_seed": 3, "params": {"d_causal": 6, "d_noise": 4}})
    g = build_model({"family": "mlp", "width": 8, "depth": 3}, b, torch.Generator().manual_seed(0)).eval()
    parts = b.partitions()
    ok = FC.func_compare(g, g, parts, ["test"], 64)
    assert ok["rel"] == 0.0 and ok["finite"]
    for bad in (math.nan, math.inf):
        h = g.clone(share_params=False).eval()
        with torch.no_grad():
            next(iter(h.parameters())).view(-1)[0] = bad
        c = FC.func_compare(h, g, parts, ["test"], 64)
        assert c["rel"] == math.inf and not c["finite"]
        assert not FC.within(c["rel"], 1e-5)
    assert not FC.within(math.nan, 1.0) and not FC.within(math.inf, 1.0) and FC.within(0.0, 0.0)


# ----------------------------------------------------------------------------- wave 32

def test_wave32_is_the_reset_matched_compact_controls():
    from cop.orchestration.manifest import generate
    m32, m29, m30 = ({r: e["cfg"] for r, e in generate([w], "full").entries.items()} for w in (32, 29, 30))
    assert len(m32) == 336
    shared = {r for r in m32 if r in m29 or r in m30}
    assert len(shared) == 144 and all(m32[r] == (m29.get(r) or m30.get(r)) for r in shared)
    assert Counter(m32[r]["kind"] for r in shared) == {"baseline": 48, "trajectory": 48, "dissipation": 48}
    new = {r: c for r, c in m32.items() if r not in shared}
    assert len(new) == 192
    seen = Counter()
    for r, c in new.items():
        assert c["kind"] == "continue" and c["design"]["arm"] == "C1R"
        name, _, stage = c["design"]["variant"].partition("@")
        U = 2000
        u = {"snap_1000": 1000, "snap_2500": 2500}[stage]
        cc = c["continue"]
        assert cc["segments"] == [u, 2 * U - u] and cc["segment_reset"] == [False, True]
        assert cc["eval_at"] == [u, 2 * U] and cc["fork_audit"] is True and cc["budget"] == "fixed"
        assert cc["save_eval_checkpoints"] is True
        assert c["parents"]["baseline"] in shared and c["parents"]["treated"] in shared
        assert cc["start"] == "baseline" and cc["budget_parent"] == "treated"
        seen[(c["data"]["name"], name, stage)] += 1
    assert set(seen.values()) == {24} and len(seen) == 8


# ----------------------------------------------------------------------------- the miniatures

@pytest.fixture(scope="module")
def mini3132(tmp_path_factory):
    from cop.orchestration.manifest import generate
    root = tmp_path_factory.mktemp("mini3132")
    cf = VM.shrink(generate([31, 32], "full").entries, 349, 0, 2000, 20,
                   {"top": {"n_train": 192}, "params": {"d_causal": 12, "d_noise": 12}}, {"width": 12})
    VM.run_all(cf, root)
    man = VM.write_manifest(root / "m.jsonl", cf)
    r = _tool(ROOT / "audit_v5/tools/fork_continuation.py", root, root / "fork31", "--manifest", man, "--strict",
              "--device", "cpu")
    return {"root": root, "cf": cf, "man": man, "r": r}


@pytest.fixture(scope="module")
def mini3032(tmp_path_factory):
    from cop.orchestration.manifest import generate
    root = tmp_path_factory.mktemp("mini3032")
    cf = VM.shrink(generate([30, 32], "full").entries, 361, 0, 2000, 20,
                   {"top": {"n_train": 160}, "params": VM.TOY_IMG}, {"width_mult": 0.25})
    VM.run_all(cf, root)
    man = VM.write_manifest(root / "m.jsonl", cf)
    r = _tool(ROOT / "audit_v5/tools/image_forks.py", root, root / "image30", "--manifest", man, "--strict",
              "--device", "cpu")
    return {"root": root, "cf": cf, "man": man, "r": r}


def test_the_mlp_miniature_measures_the_reset_matched_control(mini3132):
    r = mini3132["r"]
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-3000:]
    root = mini3132["root"]
    cov = json.loads((root / "fork31_coverage.json").read_text())
    assert cov["passed"] and cov["analysis_schema"] == "fork_continuation/v68"
    assert sorted(map(tuple, cov["compact_reset_controls"])) == [(p, f) for p in ("A_routed_affine", "B_routed_affine")
                                                                 for f in ("snap_10", "snap_25")]
    assert cov["normalised_ineligible"] == [] and cov["n_states"] == 49 + 4
    st = _rows(root / "fork31_states.csv")
    assert Counter(x["state"] for x in st)["compact_reset"] == 4
    assert all(x["state_at_f0_block_row_norms_f0_bias_eligible"] == "True" for x in st)
    assert all(float(x["state_at_f0_block_row_norms_f0_bias_norm_miss"]) <= 1e-5 for x in st)
    co = _rows(root / "fork31_contrasts.csv")
    cr = {(x["parent"], x["fork"], x["first"]) for x in co if x["comparison"] == "fork_minus_compact_reset"}
    assert ("A_routed_affine", "snap_25", "folded_reset") in cr and ("A_routed_affine", "snap_10", "routed_reset") in cr
    au = _rows(root / "fork31_audits.csv")
    mech = [x for x in au if x["state"] in ("routed_swap", "ordinary_swap", "routed_shift50", "routed_shift100",
                                             "ordinary_shift100")]
    assert len(mech) == 20
    for x in mech:
        assert x["redistribution"] == x["redistribution_storage"] == "True"
        assert x["redistribution_detail"].startswith("integrity: run, stage, configuration, recomputed tensor hash")
        assert float(x["outcome_redistribution_storage64"]) <= 1e-5
    fo = [x for x in au if x["state"] == "folded_reset"]
    assert all(x["fold_start_detail"].startswith("integrity: run, stage") for x in fo)


# v68: the mechanism diagnostic changed (the actual trainer step, the hold, completeness); its miniature tests are in
# tests/test_v68.py


def test_the_validity_table_and_the_bound_registry_read_the_miniature(mini3132, tmp_path):
    root = mini3132["root"]
    shutil.copy2(root / "fork31_audits.csv", tmp_path / "f_audits.csv")
    shutil.copy2(root / "fork31_states.csv", tmp_path / "f_states.csv")
    r = _tool(ROOT / "scripts/validity_table.py", tmp_path / "f")
    assert r.returncode == 0, r.stderr
    v = _rows(tmp_path / "f_validity.csv")
    assert len(v) == 40 + 4 + 4 + 4                 # forks; starts, trajectory ends, reset-matched controls
    assert all(x["audit_passed"] in ("True", "not a fork (checked inline)") for x in v)
    red = [x for x in v if x["edit"] == "redistribution"]
    assert len(red) == 20 and all(x["integrity"] == "True" and x["storage64"] for x in red)
    cs = root / "fork31_contrasts.csv"
    for name in ("v66_mechanism_registry", "v66_wave29_registry"):
        reg = bind(json.loads((ROOT / f"configs/{name}.json").read_text()), root / "fork31_coverage.json",
                   *draw_seed(cs), {"snap_1000": "snap_10", "snap_2500": "snap_25"})
        p = tmp_path / f"{name}.json"
        p.write_text(json.dumps(reg))
        r = _tool(REG, p, cs, tmp_path / name, "--coverage", root / "fork31_coverage.json", "--manifest",
                  mini3132["man"], "--audits", root / "fork31_audits.csv", "--states", root / "fork31_states.csv")
        rec = json.loads((tmp_path / f"{name}.json").read_text())
        if name == "v66_mechanism_registry":
            assert r.returncode == 0, r.stdout + r.stderr
            assert all(x["status"] == "validated" and x["found_rows"] == 1 for x in rec["results"])
        else:
            # waves 31 + 32 hold no carried-state compact controls (wave 29's compact_2U / compact_4U): those two
            # hypotheses have no rows and are not read; everything else is
            assert r.returncode == 1, r.stdout + r.stderr
            for x in rec["results"]:
                if "compact_continuation" in x["key"]:
                    assert x["status"] == "incomplete" and x["found_rows"] == 0, x
                else:
                    assert x["status"] == "validated" and x["found_rows"] == 1, x


def test_tampered_starts_fail_for_the_right_reason(mini3132, tmp_path):
    """one copy, four tampered runs: (1) a shift's receiving layer moved within COMPOSE_TOL with every hash re-signed:
    the structure passes, the storage certificate fails; (2) a swap's start changed by one ulp without a new hash:
    integrity fails; (3) a NaN in a shift's start with every hash re-signed: integrity (finite) fails, no zero
    discrepancy; (4) a fold's saved start changed by one ulp without a new hash: integrity fails.  Every other fork
    passes; the bound registry reads the affected hypotheses as conditional."""
    import audit_common as AC
    from cop.graph.graph import GraphNet
    from cop.graph import redistribute as RD
    root = tmp_path / "copy"
    shutil.copytree(mini3132["root"] / "runs", root / "runs")
    cf = mini3132["cf"]

    def job(arm, parent, stage):
        return next(c for c in cf if (c.get("design") or {}).get("arm") == arm and
                    c["design"]["variant"] == f"{parent}@{stage}")

    def resign(rid, ck, path, rec_key):
        ck["lineage"]["param_hash"] = AC.param_hash_of(ck)
        torch.save(ck, path)
        rp = root / "runs" / rid / "dissipation_result.json"
        res = json.loads(rp.read_text())
        res[rec_key]["start"]["param_hash"] = ck["lineage"]["param_hash"]
        rp.write_text(json.dumps(res))

    want = {}
    j = job("routed_shift100", "A_routed_affine", "snap_25")
    rid = run_id(j)
    p = root / "runs" / rid / "ckpt/event_after_redistribute.pt"
    ck = torch.load(p, weights_only=False)
    g = GraphNet.from_checkpoint(ck["model"], "cpu")
    pk = g.nodes[RD.receiving_layer(g, RD.the_group(g))].pkey
    for what in ("weight", "bias"):
        t = ck["model"]["state"][f"mods.{pk}.{what}"]
        ck["model"]["state"][f"mods.{pk}.{what}"] = t + 9e-6 * max(1.0, float(t.abs().max()))
    resign(rid, ck, p, "redistribution")
    want[rid] = "storage"
    j = job("routed_swap", "A_routed_affine", "snap_10")
    rid = run_id(j)
    p = root / "runs" / rid / "ckpt/event_after_redistribute.pt"
    ck = torch.load(p, weights_only=False)
    k = next(k for k, v in ck["model"]["state"].items() if v.is_floating_point() and v.dim() == 2)
    t = ck["model"]["state"][k]
    t.view(-1)[0] = torch.nextafter(t.view(-1)[0], torch.tensor(math.inf))
    torch.save(ck, p)
    want[rid] = "integrity"
    j = job("routed_shift50", "B_routed_affine", "snap_10")
    rid = run_id(j)
    p = root / "runs" / rid / "ckpt/event_after_redistribute.pt"
    ck = torch.load(p, weights_only=False)
    k = next(k for k, v in ck["model"]["state"].items() if v.is_floating_point() and v.dim() == 2)
    ck["model"]["state"][k].view(-1)[0] = math.nan
    resign(rid, ck, p, "redistribution")
    want[rid] = "non-finite"
    j = job("folded_reset", "B_routed_affine", "snap_25")
    rid = run_id(j)
    p = root / "runs" / rid / "ckpt/event_after_fold.pt"
    ck = torch.load(p, weights_only=False)
    k = next(k for k, v in ck["model"]["state"].items() if v.is_floating_point() and v.dim() == 2)
    t = ck["model"]["state"][k]
    t.view(-1)[0] = torch.nextafter(t.view(-1)[0], torch.tensor(-math.inf))
    torch.save(ck, p)
    want[rid] = "integrity"
    r = _tool(ROOT / "audit_v5/tools/fork_continuation.py", root, tmp_path / "x", "--manifest", mini3132["man"],
              "--strict", "--device", "cpu")
    assert r.returncode == 1
    cov = json.loads((tmp_path / "x_coverage.json").read_text())
    assert {x["run_id"] for x in cov["audit_failures"]} == set(want)
    au = {x["run_id"]: x for x in _rows(tmp_path / "x_audits.csv")}
    for rid, why in want.items():
        a = au[rid]
        assert a["audit_passed"] == "False"
        if why == "storage":
            assert a["redistribution"] == "True" and a["redistribution_storage"] == "False"
            assert "ABOVE" in a["redistribution_storage_detail"]
            assert float(a["outcome_redistribution_storage64"]) > 1e-5
        elif why == "non-finite":
            assert a["redistribution"] == "False" and "non-finite" in a["redistribution_detail"]
            assert a["outcome_redistribution_storage64"] == ""
        elif a["state"] == "folded_reset":
            assert a["fold_start"] == "False" and "saved tensors do not match" in a["fold_start_detail"]
        else:
            assert a["redistribution"] == "False" and "saved tensors do not match" in a["redistribution_detail"]
    cs = tmp_path / "x_contrasts.csv"
    reg = bind(json.loads((ROOT / "configs/v66_mechanism_registry.json").read_text()), tmp_path / "x_coverage.json",
               *draw_seed(cs), {"snap_1000": "snap_10", "snap_2500": "snap_25"})
    (tmp_path / "r.json").write_text(json.dumps(reg))
    r = _tool(REG, tmp_path / "r.json", cs, tmp_path / "o", "--coverage", tmp_path / "x_coverage.json", "--manifest",
              mini3132["man"], "--audits", tmp_path / "x_audits.csv", "--states", tmp_path / "x_states.csv")
    assert r.returncode in (1, 3), r.stdout + r.stderr
    res = {x["key"]: x for x in json.loads((tmp_path / "o.json").read_text())["results"]}
    # the A snap_10 swap fork failed: the swap interaction there is not validated
    assert res["swap_changes_routed_learning"]["status"] in ("conditional", "diagnostic")
    assert res["swap_changes_routed_learning"]["status"] != "validated"


def test_an_analysis_batch_size_leaves_the_states(mini3132, tmp_path):
    r = _tool(ROOT / "audit_v5/tools/fork_continuation.py", mini3132["root"], tmp_path / "b", "--manifest",
              mini3132["man"], "--strict", "--device", "cpu", "--eval-batch", "37")
    assert r.returncode == 0, r.stdout[-2000:] + r.stderr[-2000:]
    assert json.loads((tmp_path / "b_coverage.json").read_text())["eval_batch"] == 37
    a = {(x["parent"], x["fork"], x["state"]): x for x in _rows(mini3132["root"] / "fork31_states.csv")}
    b = {(x["parent"], x["fork"], x["state"]): x for x in _rows(tmp_path / "b_states.csv")}
    assert set(a) == set(b)
    for k in a:
        for m in ("native_test_err", "state_at_f0_block_row_norms_f0_bias_test_err", "native_train_loss"):
            assert float(a[k][m]) == pytest.approx(float(b[k][m]), abs=1e-6), (k, m)


def test_the_image_miniature_measures_the_reset_matched_control(mini3032, tmp_path):
    r = mini3032["r"]
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-3000:]
    root = mini3032["root"]
    cov = json.loads((root / "image30_coverage.json").read_text())
    assert cov["passed"] and cov["analysis_schema"] == "image_forks/v68" and cov["normalised_ineligible"] == []
    assert sorted(map(tuple, cov["compact_reset_controls"])) == [(p, f) for p in ("A", "B")
                                                                 for f in ("snap_10", "snap_25")]
    st = _rows(root / "image30_states.csv")
    assert Counter(x["state"] for x in st)["compact_reset"] == 4
    assert all(x["state_at_f0_block_row_norms_f0_bias_eligible"] == "True" and
               x["state_at_f0_row_norms_f0_bias_eligible"] == "True" for x in st)
    co = _rows(root / "image30_contrasts.csv")
    assert {(x["parent"], x["fork"]) for x in co if x["comparison"] == "fork_minus_compact_reset"} == {
        (p, f) for p in ("A_routed_affine", "B_routed_affine") for f in ("snap_10", "snap_25")}
    fo = [x for x in _rows(root / "image30_audits.csv") if x["state"] == "folded_reset"]
    assert len(fo) == 4 and all(x["fold_start_detail"].startswith("integrity: run, stage") for x in fo)
    cs = root / "image30_contrasts.csv"
    reg = bind(json.loads((ROOT / "configs/v66_image_registry.json").read_text()), root / "image30_coverage.json",
               *draw_seed(cs), {"snap_1000": "snap_10", "snap_2500": "snap_25"})
    (tmp_path / "r.json").write_text(json.dumps(reg))
    r = _tool(REG, tmp_path / "r.json", cs, tmp_path / "o", "--coverage", root / "image30_coverage.json",
              "--manifest", mini3032["man"], "--audits", root / "image30_audits.csv", "--states",
              root / "image30_states.csv")
    assert r.returncode == 0, r.stdout + r.stderr
    res = json.loads((tmp_path / "o.json").read_text())["results"]
    assert all(x["status"] == "validated" for x in res)
    assert {x["key"] for x in res} >= {"expansion_history_beats_reset_matched_compact",
                                       "routed_fork_against_reset_matched_compact"}
    shutil.copy2(root / "image30_audits.csv", tmp_path / "i_audits.csv")
    shutil.copy2(root / "image30_states.csv", tmp_path / "i_states.csv")
    assert _tool(ROOT / "scripts/validity_table.py", tmp_path / "i").returncode == 0
    v = _rows(tmp_path / "i_validity.csv")
    assert sum(x["state"] == "compact_reset" for x in v) == 4 and all(x["finite"] == "True" for x in v)


def test_a_view_links_runs_without_copying(mini3132, tmp_path):
    root = mini3132["root"]
    ents = [json.loads(ln) for ln in open(mini3132["man"])]
    a = tmp_path / "a.jsonl"
    b = tmp_path / "b.jsonl"
    a.write_text("".join(json.dumps(e) + "\n" for e in ents if e["cfg"].get("wave") != 32))
    b.write_text("".join(json.dumps(e) + "\n" for e in ents))
    r = _tool(ROOT / "scripts/make_view.py", tmp_path / "v", tmp_path / "v.jsonl", tmp_path / "v.json",
              "--source", root, a, "--source", root, b, "--data", "shortcut")
    assert r.returncode == 0, r.stderr
    rec = json.loads((tmp_path / "v.json").read_text())
    assert rec["entries"] == len(ents) and rec["missing"] == [] and rec["shared"] > 0
    runs = list((tmp_path / "v" / "runs").iterdir())
    assert len(runs) == len(ents) and all(p.is_symlink() for p in runs)
    assert [json.loads(ln)["run_id"] for ln in open(tmp_path / "v.jsonl")] == [e["run_id"] for e in ents if
                                                                               e["cfg"].get("wave") != 32] + \
        [e["run_id"] for e in ents if e["cfg"].get("wave") == 32]
    # a conflicting configuration is refused
    bad = [dict(e, cfg=dict(e["cfg"], note="other")) for e in ents[:1]]
    c = tmp_path / "c.jsonl"
    c.write_text("".join(json.dumps(e) + "\n" for e in bad))
    r = _tool(ROOT / "scripts/make_view.py", tmp_path / "w", tmp_path / "w.jsonl", tmp_path / "w.json",
              "--source", root, a, "--source", root, c)
    assert r.returncode == 1
