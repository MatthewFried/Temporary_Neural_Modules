"""v66: the re-audit launcher (scripts/66) in the v48 launcher test's mock COP_HOME.  Four manifests and their
validation, tests; wave 32 copied (v64's panel29 under the audit, v65's panel30), verified, trained; its checks,
reload and summary; read-only views; the analyses (fork29 on view29, image30 on view30, fork31 and mech31 on v65's
panel31); validity tables; the registries bound to coverage, manifest and audits, with every failed scientific
prerequisite passed on (v64's and v65's verdicts, v66's tests and wave 32), compared with the earlier readings;
evidence and packaging.  v64's and v65's folders are only read."""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import test_v48_launcher as L  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = "66_v66_reaudit.sh"
SRC = (ROOT / "scripts" / SCRIPT).read_text()
FILES = {k: re.search(rf'^{k}="([^"]+)"', SRC, re.M).group(1).split(",") for k in ("IMG_FILES", "FORK_FILES",
                                                                                     "MECH_FILES")}
NAMES = {"fork29": "FORK_FILES", "image30": "IMG_FILES", "fork31": "FORK_FILES", "mech31": "MECH_FILES"}
TOOL = r"""import json, os, sys
panel, prefix = sys.argv[1], sys.argv[2]
name = os.path.basename(prefix)
tool = os.path.basename(sys.argv[0])[:-3]
assert (tool, name) in (("fork_continuation", "fork29"), ("image_forks", "image30"), ("fork_continuation", "fork31"),
                        ("mechanism_diagnostics", "mech31")), (tool, name)
want = {"fork29": "results/view29", "image30": "results/view30", "fork31": "cop_results_v65/panel31",
        "mech31": "cop_results_v65/panel31"}[name]
assert panel.endswith(want) and prefix.endswith("v66_reports/" + name), sys.argv
man = sys.argv[sys.argv.index("--manifest") + 1]
assert man.endswith({"fork29": "view29_manifest.jsonl", "image30": "view30_manifest.jsonl"}.get(name, "wave31_full.jsonl"))
assert "--strict" in sys.argv
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write(name + " read " + panel + "\n")
rc = int(os.environ.get("MOCK_RC_" + name, "0"))
for t in os.environ["MOCK_FILES_" + name].split(","):
    if t == "validity.csv":
        continue
    if t.endswith(".json"):
        json.dump({"passed": rc == 0, "analysis_schema": "x"}, open(prefix + "_" + t, "w"))
        continue
    open(prefix + "_" + t, "w").write("variant,x\nB,1\n")
sys.exit(rc)
"""
VALIDITY = r"""import os, sys
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write("validity " + os.path.basename(sys.argv[1]) + "\n")
open(sys.argv[1] + "_validity.csv", "w").write("f0,x\nb,1\n")
"""
REPORT = r"""import json, os, sys
name = os.path.basename(sys.argv[0])
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write(name + " " + " ".join(sys.argv[1:4]) + "\n")
json.dump({"passed": True}, open(sys.argv[2], "w"))
sys.exit(int(os.environ.get("MOCK_RC_" + name[:-3], "0")))
"""
SEED = r"""import json, os, sys
man, src, dst, out = sys.argv[1:5]
assert man.endswith("wave32_full.jsonl") and dst.endswith("results/panel32"), sys.argv
assert src.endswith("cop_results_v64/panel29") or src.endswith("cop_results_v65/panel30"), sys.argv
assert sys.argv[5] == "--audited" and sys.argv[6].endswith("configs/reuse_audits.json"), sys.argv
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write("seed " + src + " -> " + dst + "\n")
json.dump({"source": src, "n_copied": 72}, open(out, "w"))
"""
REUSE = r"""import json, os, sys
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write("reuse " + " ".join(sys.argv[1:]) + "\n")
if sys.argv[1] == "select":
    open(sys.argv[4], "w").write('{"run_id": "base-x"}\n')
    sys.exit(0)
json.dump({"reproduced": True}, open(sys.argv[5], "w"))
sys.exit(int(os.environ.get("MOCK_REUSE_COMPARE_RC", "0")))
"""
SIMPLE = """import os, sys
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write(os.path.basename(sys.argv[0]) + " " + " ".join(sys.argv[1:]) + "\\n")
"""
VIEW = r"""import json, os, sys
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write("view " + " ".join(sys.argv[1:]) + "\n")
os.makedirs(os.path.join(sys.argv[1], "runs"), exist_ok=True)
open(sys.argv[2], "w").write('{"run_id": "x", "cfg": {}}\n')
json.dump({"entries": 1}, open(sys.argv[3], "w"))
"""
REGISTRY = r"""import json, os, sys
a = sys.argv[1:]
pf = [a[i + 1] for i, x in enumerate(a) if x == "--prerequisite-failed"]
for k in ("--coverage", "--manifest", "--audits"):
    assert k in a, (k, a)
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write(
    "registry " + os.path.basename(a[0]) + " " + a[1] + " manifest " + a[a.index("--manifest") + 1] + " PF " + json.dumps(pf) + "\n")
json.dump({"results": [{"key": "k", "status": "diagnostic" if pf else "validated", "reading": "inconclusive"}]},
          open(a[2] + ".json", "w"))
open(a[2] + ".csv", "w").write("key\nk\n")
sys.exit(3 if pf else 0)
"""
PYTEST = r'''#!/usr/bin/env bash
echo "pytest $*" >> "$MOCK_HOME/events.txt"
xml=""; prev=""
for a in "$@"; do [ "$prev" = "--junitxml" ] && xml="$a"; prev="$a"; done
[ -n "$xml" ] && echo "<testsuites><testsuite tests=\"3\" skipped=\"0\" failures=\"0\" errors=\"0\"/></testsuites>" > "$xml"
exit "${MOCK_TEST_RC:-0}"
'''
COMMON = L.COMMON.replace('      return "${MOCK_RUN_RC:-0}" ;;',
                          '      case "$5" in *reuse_check32) return "${MOCK_REUSE_RUN_RC:-0}" ;;\n'
                          '                   *panel32) return "${MOCK_RUN32_RC:-0}" ;; esac\n'
                          '      return "${MOCK_RUN_RC:-0}" ;;')
assert COMMON != L.COMMON
GOOD64 = {"run29": 0, "checks29": 0, "reload29": 0, "summary29": 0}
GOOD65 = {"data30": 0, "run30": 0, "checks30": 0, "reload30": 0, "summary30": 0, "seed31": 0, "reuse_compare31": 0,
          "run31": 0, "checks31": 0, "reload31": 0, "summary31": 0}


@pytest.fixture
def h(tmp_path):
    home = tmp_path / "home"
    (home / "scripts").mkdir(parents=True)
    shutil.copy2(ROOT / "scripts" / SCRIPT, home / "scripts" / SCRIPT)
    for f in ("package_reports.py", "check_evidence.py", "junit_ran.py", "prereq_status.py",
              "compare_registries.py"):
        shutil.copy2(ROOT / "scripts" / f, home / "scripts" / f)
    for f, body in (("panel_state.py", SIMPLE), ("seed_panel.py", SEED), ("reuse_reproduce.py", REUSE),
                    ("check_image_data.py", SIMPLE), ("replication_registry.py", REGISTRY),
                    ("make_view.py", VIEW), ("validity_table.py", VALIDITY)):
        (home / "scripts" / f).write_text(body)
    (home / "scripts/common.sh").write_text(COMMON)
    (home / "audit_v5/tools").mkdir(parents=True)
    (home / "audit_v8/tools").mkdir(parents=True)
    for name in ("image_forks.py", "fork_continuation.py", "mechanism_diagnostics.py"):
        (home / "audit_v5/tools" / name).write_text(TOOL)
    (home / "audit_v5/tools/fresh_reload.py").write_text(REPORT)
    (home / "audit_v8/tools/check_results.py").write_text(REPORT)
    (home / "configs").mkdir()
    for f in ("reuse_audits.json", "v66_wave29_registry.json", "v66_image_registry.json",
              "v66_mechanism_registry.json"):
        shutil.copy2(ROOT / "configs" / f, home / "configs" / f)
    pt = home / "fake_pytest.sh"
    pt.write_text(PYTEST)
    pt.chmod(0o755)
    zipdir = tmp_path / "zips"
    zipdir.mkdir()
    for v, panels, steps in (("64", ["panel29"], GOOD64), ("65", ["panel30", "panel31"], GOOD65)):
        for p in panels:
            (tmp_path / f"cop_results_v{v}" / p).mkdir(parents=True)
        (tmp_path / f"cop_results_v{v}" / f"v{v}_reports").mkdir()
        (tmp_path / f"cop_results_v{v}" / f"v{v}_reports" / "verdict.json").write_text(json.dumps({"steps": steps}))
        reg = {"64": ["registry29"], "65": ["registry30", "registry31"]}[v]
        for r in reg:
            (tmp_path / f"cop_results_v{v}" / f"v{v}_reports" / f"{r}.json").write_text(
                json.dumps({"results": [{"key": "k", "reading": "replicated", "mean_favourable": 0.1}]}))
    base = {k: v for k, v in os.environ.items() if k not in ("COP_PYTEST", "DIAGNOSTIC_OVERRIDE", "V64_RESULTS",
                                                             "V65_RESULTS", "SEED")}
    env = dict(base, MOCK_HOME=str(home), COP_RESULTS=str(tmp_path / "results"), ZIP_DIR=str(zipdir), SCALE="full",
               HOME=str(tmp_path), COP_PYTEST=str(pt),
               **{f"MOCK_FILES_{n}": ",".join(FILES[k]) for n, k in NAMES.items()})
    return {"home": home, "res": tmp_path / "results", "zip": zipdir / "cop_v66_reaudit_reports.zip", "env": env,
            "tmp": tmp_path}


def _sh(h, **env):
    e = dict(h["env"], **{k: str(v) for k, v in env.items()})
    return subprocess.run(["bash", str(h["home"] / "scripts" / SCRIPT)], env=e, capture_output=True, text=True,
                          cwd=str(h["home"]))


def _verdict(h):
    return json.loads((h["res"] / "v66_reports/verdict.json").read_text())


def _events(h):
    p = h["home"] / "events.txt"
    return p.read_text() if p.exists() else ""


def _pf(h):
    out = {}
    for ln in _events(h).splitlines():
        if ln.startswith("registry "):
            name = ln.split()[1]
            out[name] = json.loads(ln.split(" PF ", 1)[1])
    return out


def _trains32(ln: str) -> bool:
    return ln.startswith("cop run ") and ln.split(" --results ")[1].split()[0].endswith("panel32")


def _tree(p: Path) -> list:
    return sorted(str(x.relative_to(p)) for x in p.rglob("*"))


def test_it_trains_wave32_reaudits_and_packages(h):
    before = {v: _tree(h["tmp"] / f"cop_results_v{v}") for v in ("64", "65")}
    r = _sh(h)
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-3000:]
    v = _verdict(h)
    assert v["all_passed"], v
    ev = _events(h)
    i_seed, i_cmp = ev.index("seed "), ev.index("reuse compare")
    run32 = next(ev.index(x) for x in ev.splitlines() if _trains32(x))
    assert i_seed < i_cmp < run32 < ev.index("fork29 read") < ev.index("image30 read") < ev.index("fork31 read")
    views = [x for x in ev.splitlines() if x.startswith("view ")]
    assert len(views) == 2 and all("panel32" in x for x in views)
    assert "--data shortcut" in views[0] and "cop_results_v64/panel29" in views[0]
    assert "--data image_shortcut" in views[1] and "cop_results_v65/panel30" in views[1]
    pf = _pf(h)
    assert pf == {"v66_wave29_registry.json": [], "v66_image_registry.json": [], "v66_mechanism_registry.json": []}
    assert "manifest " + str(h["res"] / "v66_reports/view29_manifest.jsonl") in ev
    for vv in ("64", "65"):                                          # the earlier folders were only read
        assert _tree(h["tmp"] / f"cop_results_v{vv}") == before[vv]
    names = zipfile.ZipFile(h["zip"]).namelist()
    for f in ("registry29.json", "registry30.csv", "registry31.json", "changes_registry29.csv", "evidence.json",
              "prereq29_failed.txt", "fork29_validity.csv", "mech31_regrowth.csv", "wave32_full.jsonl", "checks32.json",
              "seed32_mlp.json", "seed32_img.json"):
        assert f"cop_v66_reaudit_reports/v66_reports/{f}" in names, f


def test_a_failed_wave32_check_labels_the_registries_that_read_it(h):
    r = _sh(h, MOCK_RC_check_results=1)
    assert r.returncode == 1
    pf = _pf(h)
    assert any("v66:checks32 (1)" in x for x in pf["v66_wave29_registry.json"])
    assert any("v66:checks32 (1)" in x for x in pf["v66_image_registry.json"])
    assert pf["v66_mechanism_registry.json"] == []          # wave 31 does not read wave 32


@pytest.mark.parametrize("which, step, reg", [("64", "checks29", "v66_wave29_registry.json"),
                                              ("64", "reload29", "v66_wave29_registry.json"),
                                              ("64", "summary29", "v66_wave29_registry.json"),
                                              ("65", "reload30", "v66_image_registry.json"),
                                              ("65", "summary31", "v66_mechanism_registry.json"),
                                              ("65", "reuse_compare31", "v66_mechanism_registry.json")])
def test_an_earlier_failed_prerequisite_labels_its_registry(h, which, step, reg):
    p = h["tmp"] / f"cop_results_v{which}" / f"v{which}_reports" / "verdict.json"
    d = json.loads(p.read_text())
    d["steps"][step] = 1
    p.write_text(json.dumps(d))
    _sh(h)
    pf = _pf(h)
    assert pf[reg] == [f"v{which}:{step} (1)"]
    assert all(v == [] for k, v in pf.items() if k != reg)
    assert _verdict(h)["all_passed"] is False


def test_a_missing_earlier_verdict_labels_its_registries(h):
    (h["tmp"] / "cop_results_v65" / "v65_reports" / "verdict.json").unlink()
    _sh(h)
    pf = _pf(h)
    assert pf["v66_wave29_registry.json"] == []
    assert pf["v66_image_registry.json"][0].startswith("v65: verdict missing")
    assert pf["v66_mechanism_registry.json"][0].startswith("v65: verdict missing")


def test_a_failed_analysis_is_still_read_and_labelled(h):
    r = _sh(h, MOCK_RC_fork31=1)
    assert r.returncode == 1
    ev = _events(h)
    assert "registry v66_mechanism_registry.json" in ev           # read; the reader labels a failed coverage
    v = _verdict(h)
    assert v["steps"]["fork31"] == 1 and v["steps"]["registry31"] == 0


def test_failed_tests_train_nothing_and_label_every_registry(h):
    r = _sh(h, MOCK_TEST_RC=1)
    assert r.returncode == 1
    ev = _events(h)
    assert not any(x.startswith("cop run ") for x in ev.splitlines())
    assert "seed " not in ev
    views = [x for x in ev.splitlines() if x.startswith("view ")]
    assert len(views) == 2 and not any("panel32" in x for x in views)    # the views without wave 32
    pf = _pf(h)
    assert set(pf) == {"v66_wave29_registry.json", "v66_image_registry.json", "v66_mechanism_registry.json"}
    assert all(any(x.startswith("v66:cpu_tests") for x in v) for v in pf.values())


def test_an_unfinished_wave32_leaves_it_out_of_the_views(h):
    r = _sh(h, MOCK_RUN32_RC=1)
    assert r.returncode == 1
    ev = _events(h)
    views = [x for x in ev.splitlines() if x.startswith("view ")]
    assert not any("panel32" in x for x in views)
    v = _verdict(h)
    assert v["steps"]["checks32"] == 99 and v["steps"]["fork29"] == 0


def test_a_failed_reuse_verification_trains_nothing(h):
    r = _sh(h, MOCK_REUSE_COMPARE_RC=1)
    assert r.returncode == 1
    ev = _events(h)
    assert not any(_trains32(x) for x in ev.splitlines())
    assert _verdict(h)["steps"]["run32"] == 99


def test_a_reduced_scale_is_refused(h):
    r = _sh(h, SCALE="smoke")
    assert r.returncode == 2 and not _events(h)
