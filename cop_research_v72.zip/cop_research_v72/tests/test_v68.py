"""v68: the second static review of v67 (CHANGES_v68.md).

  registry      bound to the exact tables the analysis wrote (outputs_sha256), an audit table that matches the
                coverage (unique keys, the audited count, the failed runs), explicit dependency records
                (depends_on: forks with an audit row, measured states), the coverage's design ids, and f0s that are
                the manifest's f0 of their draw and seed; negative cases (empty audit table, missing failed row,
                duplicate audit key, audit of another analysis, a contrast changed after the coverage was written,
                a uniformly wrong design id, a dependency without a record) are not validated; a failed fork that
                no hypothesis reads leaves the others validated
  comparison    separate change flags (status, reading, estimate, interval, membership, key)
  prerequisites every failed or missing step, CUDA steps included"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
REG = ROOT / "scripts/replication_registry.py"
DRAWS, SEEDS = [11, 12, 13], [0, 1]
DESIGN = {"parents": ["P"], "forks": ["s1"], "continuations": ["routed_reset", "ordinary_reset", "frozen_reset"]}
KEYS = ["f0", "design_id", "f0_param_hash", "data_draw", "optimizer_seed", "parent", "fork", "comparison", "first",
        "second", "metric", "first_value", "second_value", "value", "sign", "depends_on"]
STATES = ("routed_reset", "ordinary_reset", "frozen_reset")


def _rows(p):
    return list(csv.DictReader(open(p)))


def _tool(*args):
    return subprocess.run([sys.executable, *map(str, args)], capture_output=True, text=True,
                          env=dict(os.environ, CUDA_VISIBLE_DEVICES=""))


def _sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def _write(path, keys, rows):
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def _case(tmp, failed=(), rows=None, cov=None, contract=None, audits=None, after=None):
    """a bound analysis: manifest (one f0 per draw x seed), states, audits, contrasts, then the coverage with the
    tables' digests.  failed: (f0, state) pairs whose fork audit fails.  after(tmp): tamper after the coverage."""
    man = tmp / "m.jsonl"
    man.write_text("".join(json.dumps({"run_id": f"b{d}{o}", "cfg": {"kind": "baseline", "data": {"data_seed": d},
                                                                      "seeds": {"optimizer": o}}}) + "\n"
                           for d in DRAWS for o in SEEDS))
    reg = {"hypotheses": [
        {"key": "one", "role": "primary", "parent": "P", "fork": "s1", "comparison": "routed_minus_ordinary",
         "first": "routed_reset", "second": "ordinary_reset", "metric": "m", "favourable": "second - first"},
        {"key": "two", "role": "secondary", "parent": "P", "fork": "s1", "comparison": "routed_minus_ordinary",
         "first": "routed_reset", "second": "ordinary_reset", "metric": "n", "favourable": "two-sided"}],
        "contract": contract or {"analysis_schemas": ["fork_continuation/v68"], "data_draws": DRAWS,
                                 "optimizer_seeds": SEEDS, "design": DESIGN}}
    (tmp / "reg.json").write_text(json.dumps(reg))
    dep = "P/s1/ordinary_reset;P/s1/routed_reset"
    if rows is None:
        rows = []
        for d in DRAWS:
            for o in SEEDS:
                for met, v in (("m", -0.1 - 0.01 * d - 0.001 * o), ("n", 0.05 + 0.001 * d)):
                    rows.append({"f0": f"b{d}{o}", "design_id": "D#1", "f0_param_hash": "h", "data_draw": d,
                                 "optimizer_seed": o, "parent": "P", "fork": "s1",
                                 "comparison": "routed_minus_ordinary", "first": "routed_reset",
                                 "second": "ordinary_reset", "metric": met, "first_value": 0, "second_value": 0,
                                 "value": v, "sign": "first - second", "depends_on": dep})
    _write(tmp / "c.csv", KEYS, rows)
    extra = sorted({r_.get(x) for r_ in rows for x in ("first", "second") if r_.get(x)} - set(STATES))
    st = [{"f0": f"b{d}{o}", "design_id": "D#1", "parent": "P", "fork": "s1", "state": s} for d in DRAWS
          for o in SEEDS for s in STATES + tuple(extra)]
    # v70: the registry recomputes every value from the states table: the first state holds the value, every other 0
    by = {(r_["f0"], r_["state"]): r_ for r_ in st}
    for r_ in rows:
        if (r_.get("f0"), r_.get("first")) in by:
            for s_ in STATES + tuple(extra):
                by[(r_["f0"], s_)].setdefault(r_["metric"], 0.0)
            by[(r_["f0"], r_["first"])][r_["metric"]] = r_["value"]
    _write(tmp / "s.csv", ["f0", "design_id", "parent", "fork", "state", "m", "n"], st)
    if audits is None:
        audits = [{"f0": f"b{d}{o}", "parent": "P", "fork": "s1", "state": s, "run_id": f"r{d}{o}{s}",
                   "audit_passed": str((f"b{d}{o}", s) not in failed)} for d in DRAWS for o in SEEDS for s in STATES]
    _write(tmp / "a.csv", ["f0", "parent", "fork", "state", "run_id", "audit_passed"], audits)
    fails = [{"run_id": r["run_id"], "f0": r["f0"], "state": r["state"]} for r in audits
             if r["audit_passed"] != "True"]
    c = {"analysis_schema": "fork_continuation/v68", "design": DESIGN, "analysis_complete": True,
         "passed": not fails, "manifest_sha256": _sha(man)[:16], "design_ids": ["D#1"],
         "n_audited_forks": len(audits), "audit_failures": fails,
         "audit_failure_run_ids": sorted(r["run_id"] for r in fails),
         "outputs_sha256": {"contrasts.csv": _sha(tmp / "c.csv"), "audits.csv": _sha(tmp / "a.csv"),
                            "states.csv": _sha(tmp / "s.csv")}}
    c.update(cov or {})
    (tmp / "cov.json").write_text(json.dumps(c))
    if after:
        after(tmp)
    return rows


def _read(tmp, *extra, audits="a.csv", states="s.csv"):
    for f in ("o.json", "o.csv"):
        (tmp / f).unlink(missing_ok=True)
    r = _tool(REG, tmp / "reg.json", tmp / "c.csv", tmp / "o", "--coverage", tmp / "cov.json", "--manifest",
              tmp / "m.jsonl", "--audits", tmp / audits, "--states", tmp / states, *extra)
    rec = json.loads((tmp / "o.json").read_text()) if (tmp / "o.json").exists() else None
    return r, rec


def test_a_complete_bound_reading_is_validated(tmp_path):
    _case(tmp_path)
    r, rec = _read(tmp_path)
    assert r.returncode == 0, r.stdout + r.stderr
    one, two = rec["results"]
    assert one["status"] == two["status"] == "validated" and rec["all_validated"] and rec["unbound"] == []
    assert one["expected_pairs"] == one["found_rows"] == one["unique_pairs"] == one["finite_rows"] == 6
    dm = [sum(0.1 + 0.01 * d + 0.001 * o for o in SEEDS) / 2 for d in DRAWS]
    assert one["mean_favourable"] == pytest.approx(sum(dm) / 3, abs=1e-12) and one["n_draws"] == 3
    assert one["reading"] == "replicated" and two["reading"].startswith("secondary: nonzero (positive)")
    assert one["pairs_digest"] and rec["audits_sha256"] and rec["states_sha256"]


@pytest.mark.parametrize("damage, why", [
    ("missing_seed", "missing"), ("missing_draw", "missing"), ("duplicate", "duplicated"), ("extra_draw", "outside"),
    ("cross_design", "designs"), ("nan", "non-finite"), ("inf", "non-finite"), ("missing_arm", "missing"),
    ("wrong_design_everywhere", "design id the analysis did not report"), ("empty_design", "design id"),
    ("wrong_f0", "not the manifest's f0"), ("empty_f0", "not the manifest's f0"),
    ("no_record", "without a validity record"), ("no_depends", "without a validity record")])
def test_incomplete_evidence_is_not_read(tmp_path, damage, why):
    rows = _case(tmp_path)
    m = [r for r in rows if r["metric"] == "m"]
    rest = [r for r in rows if r["metric"] != "m"]
    if damage == "missing_seed":
        m = [r for r in m if not (r["data_draw"] == 12 and r["optimizer_seed"] == 1)]
    elif damage == "missing_draw":
        m = [r for r in m if r["data_draw"] != 13]
    elif damage == "duplicate":
        m = m + [dict(m[0])]
    elif damage == "extra_draw":
        m = m + [dict(m[0], data_draw=99, f0="b990")]
    elif damage == "cross_design":
        m[2] = dict(m[2], design_id="D#2")
    elif damage == "nan":
        m[1] = dict(m[1], value="nan")
    elif damage == "inf":
        m[1] = dict(m[1], value="inf")
    elif damage == "missing_arm":
        m = []
    elif damage == "wrong_design_everywhere":
        m = [dict(r, design_id="D#9") for r in m]
    elif damage == "empty_design":
        m = [dict(r, design_id="") for r in m]
    elif damage == "wrong_f0":
        m[0] = dict(m[0], f0="b120")                       # another draw's f0
    elif damage == "empty_f0":
        m[0] = dict(m[0], f0="")
    elif damage == "no_record":
        m[0] = dict(m[0], depends_on="P/s1/routed_reset;P/s1/nowhere")
    elif damage == "no_depends":
        m[0] = dict(m[0], depends_on="")
    _case(tmp_path, rows=m + rest)
    r, rec = _read(tmp_path)
    assert r.returncode == 1, r.stdout + r.stderr
    one = rec["results"][0]
    assert one["status"] == "incomplete" and one["reading"].startswith("not read") and why in one["reading"], one
    assert one.get("mean_favourable") is None and not rec["all_validated"]
    assert rec["results"][1]["status"] == "validated"


def _hdr_only(tmp):
    _write(tmp / "a2.csv", ["f0", "parent", "fork", "state", "run_id", "audit_passed"], [])


@pytest.mark.parametrize("what, why", [
    ("manifest", "manifest"), ("schema", "analysis schema"), ("design", "design forks"), ("no_contract", "contract"),
    ("contrast_changed", "contrasts.csv is not the table"), ("audit_other", "audits.csv is not the table"),
    ("states_other", "states.csv is not the table"), ("no_digest", "records no digest"),
    ("empty_audits", "audit table has 0 rows"), ("missing_failed_row", "failed runs"),
    ("duplicate_audit", "duplicate fork keys"), ("cov_hides_failure", "failed runs")])
def test_an_unbound_analysis_is_not_read(tmp_path, what, why):
    def contrast_changed(t):
        rows = _rows(t / "c.csv")
        rows[0]["value"] = "0.5"
        _write(t / "c.csv", KEYS, rows)

    def audit_other(t):
        rows = _rows(t / "a.csv")
        rows[0]["run_id"] = "another"
        _write(t / "a.csv", list(rows[0]), rows)

    def states_other(t):
        rows = _rows(t / "s.csv")
        _write(t / "s.csv", list(rows[0]), rows[:-1])
    cov = {"manifest": {"manifest_sha256": "0" * 16}, "schema": {"analysis_schema": "fork_continuation/v66"},
           "design": {"design": {**DESIGN, "forks": ["s1", "s2"]}}, "no_digest": {"outputs_sha256": {}},
           "cov_hides_failure": {"audit_failures": [], "audit_failure_run_ids": []}}.get(what)
    after = {"contrast_changed": contrast_changed, "audit_other": audit_other, "states_other": states_other}.get(what)
    failed = {("b120", "frozen_reset")} if what in ("missing_failed_row", "cov_hides_failure", "empty_audits") else ()
    _case(tmp_path, failed=failed, cov=cov, after=after, contract={"x": 1} if what == "no_contract" else None)
    if what == "no_contract":
        reg = json.loads((tmp_path / "reg.json").read_text())
        del reg["contract"]
        (tmp_path / "reg.json").write_text(json.dumps(reg))
    audits = "a.csv"
    if what in ("empty_audits", "missing_failed_row", "duplicate_audit"):
        rows = _rows(tmp_path / "a.csv")
        if what == "empty_audits":
            rows = []
        elif what == "missing_failed_row":
            rows = [r for r in rows if r["audit_passed"] == "True"]
        else:
            rows = rows + [dict(rows[0], run_id="dup")]
        _write(tmp_path / "a2.csv", ["f0", "parent", "fork", "state", "run_id", "audit_passed"], rows)
        c = json.loads((tmp_path / "cov.json").read_text())       # a coverage that names this table's digest:
        c["outputs_sha256"]["audits.csv"] = _sha(tmp_path / "a2.csv")   # the membership checks still refuse it
        (tmp_path / "cov.json").write_text(json.dumps(c))
        audits = "a2.csv"
    r, rec = _read(tmp_path, audits=audits)
    assert r.returncode == 1, r.stdout + r.stderr
    assert all(x["status"] == "unbound" and x["reading"].startswith("not read") for x in rec["results"])
    assert any(why in u for u in rec["unbound"]), rec["unbound"]


def test_a_failed_fork_makes_its_rows_conditional(tmp_path):
    _case(tmp_path, failed={("b120", "routed_reset"), ("b131", "ordinary_reset")})
    r, rec = _read(tmp_path)
    assert r.returncode == 3
    one = rec["results"][0]
    assert one["status"] == "conditional" and one["excluded_rows"] == 2 and one["n_draw_seed_pairs"] == 4
    assert one["excluded"] == ["b120:P/s1/routed_reset", "b131:P/s1/ordinary_reset"]
    assert "not a validated result" in one["reading"] and not rec["all_validated"]


def test_a_failed_fork_no_hypothesis_reads_leaves_the_others_validated(tmp_path):
    """the v65 case: one fork (here frozen_reset of one f0) failed its audit and no hypothesis reads it."""
    _case(tmp_path, failed={("b120", "frozen_reset")})
    cov = json.loads((tmp_path / "cov.json").read_text())
    assert cov["passed"] is False and cov["analysis_complete"] is True
    r, rec = _read(tmp_path)
    assert r.returncode == 0, r.stdout + r.stderr
    assert all(x["status"] == "validated" for x in rec["results"])


def test_an_interaction_depends_on_four_forks(tmp_path):
    rows = _case(tmp_path)
    dep = "P/s1/ordinary_reset;P/s1/ordinary_swap;P/s1/routed_reset;P/s1/routed_swap"
    rows = [dict(r, comparison="swap_interaction", first="routed_swap", second="ordinary_swap", depends_on=dep)
            for r in rows]
    st = STATES + ("routed_swap", "ordinary_swap")
    aud = [{"f0": f"b{d}{o}", "parent": "P", "fork": "s1", "state": s, "run_id": f"r{d}{o}{s}",
            "audit_passed": str((f"b{d}{o}", s) != ("b110", "routed_reset"))} for d in DRAWS for o in SEEDS for s in st]
    _case(tmp_path, rows=rows, audits=aud)
    reg = json.loads((tmp_path / "reg.json").read_text())
    for h in reg["hypotheses"]:
        h.update(comparison="swap_interaction", first="routed_swap", second="ordinary_swap")
    (tmp_path / "reg.json").write_text(json.dumps(reg))
    r, rec = _read(tmp_path)
    one = rec["results"][0]
    assert one["status"] == "conditional" and one["excluded_rows"] == 1 and one["excluded"] == ["b110:P/s1/routed_reset"]


def test_an_incomplete_analysis_or_a_failed_prerequisite_is_diagnostic(tmp_path):
    _case(tmp_path)
    r, rec = _read(tmp_path, "--prerequisite-failed", "v67:cuda_tests (1)")
    assert r.returncode == 3 and all(x["status"] == "diagnostic" for x in rec["results"])
    assert "v67:cuda_tests" in rec["results"][0]["reading"]
    _case(tmp_path, cov={"analysis_complete": False, "passed": False})
    r, rec = _read(tmp_path)
    assert r.returncode == 3 and all(x["status"] == "diagnostic" for x in rec["results"])


def test_the_reader_needs_every_table(tmp_path):
    _case(tmp_path)
    r = _tool(REG, tmp_path / "reg.json", tmp_path / "c.csv", tmp_path / "o", "--coverage", tmp_path / "cov.json",
              "--manifest", tmp_path / "m.jsonl", "--audits", tmp_path / "a.csv")
    assert r.returncode == 2 and not (tmp_path / "o.json").exists()


# ----------------------------------------------------------------------------- comparison

def test_compare_registries_flags_each_kind_of_change(tmp_path):
    base = {"status": "validated", "reading": "replicated", "mean_favourable": 0.1, "interval_level": 0.975,
            "interval_low": 0.01, "interval_high": 0.2, "n_draws": 12, "n_draw_seed_pairs": 24, "excluded": [],
            "pairs_digest": "aa"}
    old = {"results": [{"key": k, **base} for k in ("same", "downgrade", "wider", "members", "repaired", "gone")]}
    new = {"results": [{"key": "same", **base},
                       {"key": "downgrade", **base, "status": "conditional",
                        "reading": "conditional (23 of 24 ...): replicated; not a validated result"},
                       {"key": "wider", **base, "interval_low": 0.0},
                       {"key": "members", **base, "pairs_digest": "bb"},
                       {"key": "repaired", **base},
                       {"key": "new", **base}]}
    old["results"][4] = {**old["results"][4], "status": "incomplete", "reading": "not read: missing"}
    (tmp_path / "o.json").write_text(json.dumps(old))
    (tmp_path / "n.json").write_text(json.dumps(new))
    r = _tool(ROOT / "scripts/compare_registries.py", tmp_path / "o.json", tmp_path / "n.json", tmp_path / "c.csv")
    assert r.returncode == 0
    got = {x["key"]: x for x in _rows(tmp_path / "c.csv")}
    assert got["same"]["changed"] == "False"
    assert got["downgrade"]["changed_status"] == "True" and got["downgrade"]["changed_reading"] == "False"
    assert got["downgrade"]["changed"] == "True"
    assert got["wider"]["changed_interval"] == "True" and got["wider"]["changed_estimate"] == "False"
    assert got["members"]["changed_membership"] == "True"
    assert got["repaired"]["changed_status"] == "True" and got["repaired"]["changed_reading"] == "True"
    assert got["gone"]["changed_key"] == "True" and got["new"]["changed_key"] == "True"


def test_prereq_status_names_every_failed_or_missing_step(tmp_path):
    (tmp_path / "v.json").write_text(json.dumps({"steps": {"run29": 0, "checks29": 1, "reload29": 99,
                                                           "cuda_tests": 0, "cuda_tests_ran": 1}}))
    r = _tool(ROOT / "scripts/prereq_status.py", tmp_path / "p.txt", f"v64={tmp_path / 'v.json'}:run29,checks29,"
              f"reload29,summary29,cuda_tests,cuda_tests_ran", f"v65={tmp_path / 'none.json'}:run30")
    assert r.returncode == 0
    got = (tmp_path / "p.txt").read_text().splitlines()
    assert got[:4] == ["v64:checks29 (1)", "v64:reload29 (99)", "v64:summary29 (not in the verdict)",
                       "v64:cuda_tests_ran (1)"]
    assert got[4].startswith("v65: verdict missing") and len(got) == 5


# ----------------------------------------------------------------------------- numerics and views

sys.path.insert(0, str(ROOT / "audit_v5" / "tools"))


def test_the_norm_check_is_per_row():
    import torch
    import fork_continuation as FC
    t = torch.tensor([100.0, 1e-4], dtype=torch.float64)
    s = torch.tensor([3.0, 2.0], dtype=torch.float64)
    bad = FC.norm_check([(torch.tensor([100.0, 2e-4], dtype=torch.float64), t, s)])
    assert bad["failed_rows"] == 1 and bad["max_rel"] == pytest.approx(1.0)      # v66's block-max rule passed this
    ok = FC.norm_check([(t * (1 + 3e-7), t, s)])                                   # float32-sized rounding
    assert ok["failed_rows"] == 0 and ok["rows"] == 2
    z = FC.norm_check([(torch.tensor([0.0, 5.0], dtype=torch.float64), torch.tensor([0.0, 5.0], dtype=torch.float64),
                        torch.tensor([0.0, 1.0], dtype=torch.float64))])            # zero source: left to unmatched
    assert z["failed_rows"] == 0 and z["rows"] == 1
    zt = FC.norm_check([(torch.tensor([1e-6], dtype=torch.float64), torch.tensor([0.0], dtype=torch.float64),
                         torch.tensor([1.0], dtype=torch.float64))])                # zero target: atol only
    assert zt["failed_rows"] == 1
    nf = FC.norm_check([(torch.tensor([math.nan]), torch.tensor([1.0]), torch.tensor([1.0]))])
    assert nf["failed_rows"] == -1 and nf["max_rel"] == math.inf


def test_func_compare_rejects_finite_logits_whose_statistics_overflow():
    import torch
    import fork_continuation as FC

    class Fixed(torch.nn.Module):
        def __init__(self, z):
            super().__init__()
            self.z = z

    import f0_panel as FP
    orig = FP.node_values
    try:
        FP.node_values = lambda g, part, nodes, batch: ({}, g.z)
        big = Fixed(torch.tensor([[1e308, -1e308]], dtype=torch.float64))
        neg = Fixed(torch.tensor([[-1e308, 1e308]], dtype=torch.float64))
        c = FC.func_compare(big, neg, {"test": None}, ["test"], 8)
        assert c["rel"] == math.inf and not c["finite"]
        same = FC.func_compare(big, big, {"test": None}, ["test"], 8)      # finite logits, NaN KL (0 x inf)
        assert not same["finite"] and same["rel"] == math.inf
        ok = Fixed(torch.tensor([[2.0, -1.0]], dtype=torch.float64))
        fine = FC.func_compare(ok, ok, {"test": None}, ["test"], 8)
        assert fine["finite"] and fine["rel"] == 0.0 and fine["kl"] == 0.0
    finally:
        FP.node_values = orig


def test_mechanism_compare_reports_undefined_values_and_refuses_corruption():
    import torch
    import mechanism_diagnostics as MD
    z = torch.zeros(3, 2)
    assert MD.compare(z, z)["status"] == "both_zero"
    c = MD.compare(torch.ones(3, 2), z)
    assert c["status"] == "zero_reference" and c["rel"] is None and c["cos"] is None
    with pytest.raises(MD.Fail):
        MD.compare(torch.tensor([[math.nan]]), torch.tensor([[1.0]]))
    with pytest.raises(MD.Fail):
        MD.compare(torch.tensor([[1.0]]), torch.tensor([[math.inf]]))


def _view(*a):
    return _tool(ROOT / "scripts/make_view.py", *a)


def test_a_view_is_rebuilt_safely(tmp_path):
    src = tmp_path / "panel"
    (src / "runs" / "r1").mkdir(parents=True)
    (src / "runs" / "r2").mkdir(parents=True)
    man = tmp_path / "m.jsonl"
    man.write_text("".join(json.dumps({"run_id": r, "cfg": {"k": r}}) + "\n" for r in ("r1", "r2")))
    v = tmp_path / "v"
    assert _view(v, tmp_path / "vm.jsonl", tmp_path / "v.json", "--source", src, man).returncode == 0
    assert (v / ".cop_view").exists() and all(p.is_symlink() for p in (v / "runs").iterdir())
    assert _view(v, tmp_path / "vm.jsonl", tmp_path / "v.json", "--source", src, man).returncode == 0   # rebuild
    assert sorted(p.name for p in (v / "runs").iterdir()) == ["r1", "r2"] and (src / "runs" / "r1").is_dir()
    # a conflict leaves the old view as it was
    bad = tmp_path / "bad.jsonl"
    bad.write_text(json.dumps({"run_id": "r1", "cfg": {"k": "other"}}) + "\n")
    assert _view(v, tmp_path / "vm.jsonl", tmp_path / "v.json", "--source", src, man, "--source", src,
                 bad).returncode == 1
    assert sorted(p.name for p in (v / "runs").iterdir()) == ["r1", "r2"]
    # a directory that is not a view is never replaced, nor a view overlapping a source
    other = tmp_path / "other"
    other.mkdir()
    (other / "notes.txt").write_text("keep")
    assert _view(other, tmp_path / "om.jsonl", tmp_path / "o.json", "--source", src, man).returncode == 1
    assert (other / "notes.txt").read_text() == "keep"
    assert _view(src / "inside", tmp_path / "im.jsonl", tmp_path / "i.json", "--source", src, man).returncode == 1
    (v / "stray.txt").write_text("x")
    assert _view(v, tmp_path / "vm.jsonl", tmp_path / "v.json", "--source", src, man).returncode == 1
    assert (v / "stray.txt").exists()


# ----------------------------------------------------------------------------- miniature (waves 31 + 32)

@pytest.fixture(scope="module")
def mini(tmp_path_factory):
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import v65_mini as VM
    from cop.orchestration.manifest import generate
    root = tmp_path_factory.mktemp("mini68")
    cf = VM.shrink(generate([31, 32], "full").entries, 349, 0, 2000, 20,
                   {"top": {"n_train": 192}, "params": {"d_causal": 12, "d_noise": 12}}, {"width": 12})
    VM.run_all(cf, root)
    man = VM.write_manifest(root / "m.jsonl", cf)
    r = _tool(ROOT / "audit_v5/tools/fork_continuation.py", root, root / "fork31", "--manifest", man, "--strict",
              "--device", "cpu")
    return {"root": root, "cf": cf, "man": man, "r": r}


def test_the_analysis_binds_its_outputs_and_dependencies(mini, tmp_path):
    assert mini["r"].returncode == 0, mini["r"].stdout[-2000:] + mini["r"].stderr[-2000:]
    root = mini["root"]
    cov = json.loads((root / "fork31_coverage.json").read_text())
    assert cov["analysis_schema"] == "fork_continuation/v68"
    for t in ("contrasts.csv", "audits.csv", "states.csv"):
        assert cov["outputs_sha256"][t] == _sha(root / f"fork31_{t}")
    co = _rows(root / "fork31_contrasts.csv")
    assert all(r["depends_on"] for r in co)
    inter = [r for r in co if r["comparison"].endswith("_interaction")]
    assert inter and all(len(r["depends_on"].split(";")) == 4 for r in inter)
    st = _rows(root / "fork31_states.csv")
    assert all(r["state_at_f0_block_row_norms_f0_bias_norm_failed_rows"] == "0" for r in st)


def test_the_mechanism_diagnostic_reproduces_the_trainer_and_the_hold(mini, tmp_path):
    root = mini["root"]
    r = _tool(ROOT / "audit_v5/tools/mechanism_diagnostics.py", root, tmp_path / "m", "--manifest", mini["man"],
              "--strict", "--expect-forks", "snap_10,snap_25")
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-3000:]
    g = _rows(tmp_path / "m_gradients.csv")
    assert len(g) == 2 * 2 * 3 * 2 * 2
    for x in g:
        assert x["held_columns"] == ("12" if x["parent"] == "B_routed_affine" else "")
        if x["mode"] == "ordinary" and x["precision"] == "float64" and x["edit"] == "swap":
            assert float(x["disp_trainable_rel_change"]) < 1e-12
        if x["mode"] == "routed":
            assert float(x["raw_grad_rel_change"]) > 1e-3
    rg = _rows(tmp_path / "m_regrowth.csv")
    sh = [x for x in rg if x["continuation"] == "routed_shift100" and x["update"] == "0"]
    assert sh and all(float(x["aggregate_branch_rms"]) == 0.0 and float(x["branch_out_bias_max"]) == 0.0 for x in sh)
    cov = json.loads((tmp_path / "m_coverage.json").read_text())
    assert cov["passed"] and cov["gradient_rows"] == 48 and cov["numerics"]["tf32"] is False
    assert r.returncode == 0
    r = _tool(ROOT / "audit_v5/tools/mechanism_diagnostics.py", root, tmp_path / "w", "--manifest", mini["man"],
              "--strict", "--expect-forks", "snap_1000,snap_2500")
    assert r.returncode == 1                              # a design that is not the one declared is not read


def _mech_copy(mini, tmp_path):
    root = tmp_path / "copy"
    shutil.copytree(mini["root"] / "runs", root / "runs")
    return root


def _job(mini, arm, parent, stage):
    from cop.config import run_id
    return run_id(next(c for c in mini["cf"] if (c.get("design") or {}).get("arm") == arm and
                       c["design"]["variant"] == f"{parent}@{stage}"))


@pytest.mark.parametrize("damage, why", [("drop_edit", "continuations missing"),
                                         ("drop_regrowth", "continuations missing"),
                                         ("tamper_path", "saved tensors do not match"),
                                         ("wrong_stage", "path checkpoints at"),     # v69: the plan's updates
                                         ("stale_partition", "differs from its definition")])
def test_the_mechanism_diagnostic_refuses_missing_or_altered_evidence(mini, tmp_path, damage, why):
    import torch
    root = _mech_copy(mini, tmp_path)
    man = tmp_path / "m.jsonl"
    ents = [json.loads(ln) for ln in open(mini["man"])]
    drop = {"drop_edit": _job(mini, "routed_shift50", "A_routed_affine", "snap_10"),
            "drop_regrowth": _job(mini, "ordinary_shift100", "B_routed_affine", "snap_25")}.get(damage)
    man.write_text("".join(json.dumps(e) + "\n" for e in ents if e["run_id"] != drop))
    if damage in ("tamper_path", "wrong_stage"):
        rd = root / "runs" / _job(mini, "routed_shift100", "A_routed_affine", "snap_10") / "ckpt"
        paths = sorted(rd.glob("path_u*.pt"))
        if damage == "tamper_path":
            ck = torch.load(paths[0], weights_only=False)
            k = next(k for k, v in ck["model"]["state"].items() if v.is_floating_point() and v.dim() == 2)
            t = ck["model"]["state"][k]
            t.view(-1)[0] = torch.nextafter(t.view(-1)[0], torch.tensor(math.inf))
            torch.save(ck, paths[0])
        else:
            n = int(paths[0].stem[6:])
            shutil.move(paths[0], rd / f"path_u{n + 1}.pt")
    if damage == "stale_partition":
        tid = next(c for c in mini["cf"] if c["kind"] == "trajectory" and
                   (c.get("growth") or {}).get("spec_partition") == "random_matched")
        from cop.config import run_id
        p = root / "runs" / run_id(tid) / "spec_partition.pt"
        ind = torch.load(p, weights_only=False)
        ind[0] = 1 - ind[0]
        torch.save(ind, p)
    r = _tool(ROOT / "audit_v5/tools/mechanism_diagnostics.py", root, tmp_path / "x", "--manifest", man, "--strict")
    assert r.returncode == 1, r.stdout[-2000:]
    cov = json.loads((tmp_path / "x_coverage.json").read_text())
    assert not cov["passed"] and any(why in f["reason"] for f in cov["failed"]), cov["failed"]
    assert cov["gradient_rows"] == 0 and cov["regrowth_rows"] == 0      # nothing of the failed f0 is kept


def test_the_reference_recompute_reads_the_miniature(mini, tmp_path):
    root = mini["root"]
    r = _tool(ROOT / "audit_v5/tools/reference_recompute.py", root, tmp_path / "ref", "--manifest", mini["man"],
              "--states", root / "fork31_states.csv", "--n-f0", "1")      # v69: a shortfall fails
    assert r.returncode == 0, r.stdout[-2000:] + r.stderr[-2000:]
    rows = _rows(tmp_path / "ref_rows.csv")
    meas = {x["measure"] for x in rows}
    assert {"native", "extraction", "state_at_f0_block_row_norms_f0_bias", "state_at_f0_block_norms_f0_bias",
            "fold"} <= meas
    assert all(x["passed"] == "True" and x["disagree_decided"] in ("0", "") for x in rows)   # v69 name
    assert {x["parent"] for x in rows} == {"A_routed_affine", "B_routed_affine", "f0"}   # v69: f0 itself
