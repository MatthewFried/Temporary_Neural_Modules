"""v68: the re-analysis launcher (scripts/68) in the v48 launcher test's mock COP_HOME.  Trains nothing; builds the
read-only views (wave 32's controls only when v67 trained them), runs the analyses, the mechanism diagnostics, the
validity tables and the reference recompute, passes every failed scientific prerequisite (the source runs' tests,
CUDA tests and checks; this run's tests and CUDA tests, or CUDA recorded as not applicable on a CPU run) to each
registry, compares each with v67's and the original reading, packages.  v64, v65 and v67 folders are only read."""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import test_v48_launcher as L  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = "68_v68_reanalysis.sh"
SRC = (ROOT / "scripts" / SCRIPT).read_text()
FILES = {k: re.search(rf'^{k}="([^"]+)"', SRC, re.M).group(1).split(",") for k in ("IMG_FILES", "FORK_FILES",
                                                                                     "MECH_FILES", "REF_FILES")}
NAMES = {"fork29": "FORK_FILES", "image30": "IMG_FILES", "fork31": "FORK_FILES", "mech31": "MECH_FILES",
         "ref29": "REF_FILES", "ref30": "REF_FILES", "ref31": "REF_FILES"}
TOOL = r"""import json, os, sys
panel, prefix = sys.argv[1], sys.argv[2]
name = os.path.basename(prefix)
want = {"fork29": "results/view29", "image30": "results/view30", "fork31": "cop_results_v65/panel31",
        "mech31": "cop_results_v65/panel31", "ref29": "results/view29", "ref30": "results/view30",
        "ref31": "cop_results_v65/panel31"}[name]
assert panel.endswith(want) and prefix.endswith("v68_reports/" + name), sys.argv
if name.startswith("ref"):
    assert sys.argv[sys.argv.index("--states") + 1].endswith({"ref29": "fork29", "ref30": "image30",
                                                               "ref31": "fork31"}[name] + "_states.csv")
if name == "mech31":
    assert sys.argv[sys.argv.index("--expect-forks") + 1] == "snap_1000,snap_2500"
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write(name + " read " + panel + "\n")
rc = int(os.environ.get("MOCK_RC_" + name, "0"))
for t in os.environ["MOCK_FILES_" + name].split(","):
    if t == "validity.csv":
        continue
    if t.endswith(".json"):
        json.dump({"passed": rc == 0}, open(prefix + "_" + t, "w"))
        continue
    open(prefix + "_" + t, "w").write("variant,x\nB,1\n")
sys.exit(rc)
"""
VALIDITY = r"""import os, sys
open(sys.argv[1] + "_validity.csv", "w").write("f0,x\nb,1\n")
"""
SIMPLE = """import os, sys
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write(os.path.basename(sys.argv[0]) + " " + " ".join(sys.argv[1:]) + "\\n")
"""
VIEW = r"""import json, os, sys
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write("view " + " ".join(sys.argv[1:]) + "\n")
os.makedirs(os.path.join(sys.argv[1], "runs"), exist_ok=True)
open(sys.argv[2], "w").write('{"run_id": "x", "cfg": {}}\n')
json.dump({"entries": 1}, open(sys.argv[3], "w"))
"""
REGISTRY = r"""import json, os, sys
a = sys.argv[1:]
pf = [a[i + 1] for i, x in enumerate(a) if x == "--prerequisite-failed"]
for k in ("--coverage", "--manifest", "--audits", "--states"):
    assert k in a, (k, a)
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write(
    "registry " + os.path.basename(a[0]) + " PF " + json.dumps(pf) + "\n")
json.dump({"results": [{"key": "k", "status": "diagnostic" if pf else "validated", "reading": "inconclusive"}]},
          open(a[2] + ".json", "w"))
open(a[2] + ".csv", "w").write("key\nk\n")
sys.exit(3 if pf else 0)
"""
PYTEST = r'''#!/usr/bin/env bash
echo "pytest $*" >> "$MOCK_HOME/events.txt"
xml=""; prev=""; cuda=0
for a in "$@"; do [ "$prev" = "--junitxml" ] && xml="$a"; [ "$a" = "cuda or gpu_equivalence" ] && cuda=1; prev="$a"; done
sk=0; [ "$cuda" = 1 ] && [ -n "${MOCK_CUDA_ALL_SKIPPED:-}" ] && sk=3
[ -n "$xml" ] && echo "<testsuites><testsuite tests=\"3\" skipped=\"$sk\" failures=\"0\" errors=\"0\"/></testsuites>" > "$xml"
if [ "$cuda" = 1 ]; then exit "${MOCK_CUDA_TEST_RC:-0}"; fi
exit "${MOCK_TEST_RC:-0}"
'''
COMMON = L.COMMON.replace("export WORKERS=1 THREADS=1 DEVICE=cpu", 'export WORKERS=1 THREADS=1 DEVICE="${MOCK_DEVICE:-cpu}"')
assert COMMON != L.COMMON
SRC_STEPS = {"cpu_tests": 0, "cuda_tests": 0, "cuda_tests_ran": 0}
V64 = {**SRC_STEPS, "run29": 0, "checks29": 0, "reload29": 0, "summary29": 0}
V65 = {**SRC_STEPS, "data30": 0, "run30": 0, "checks30": 0, "reload30": 0, "summary30": 0, "seed31": 0,
       "reuse_compare31": 0, "run31": 0, "checks31": 0, "reload31": 0, "summary31": 0}
V67 = {**SRC_STEPS, "seed32_mlp": 0, "seed32_img": 0, "reuse_compare32": 0, "run32": 0, "checks32": 0, "reload32": 0,
       "summary32": 0}


@pytest.fixture
def h(tmp_path):
    home = tmp_path / "home"
    (home / "scripts").mkdir(parents=True)
    shutil.copy2(ROOT / "scripts" / SCRIPT, home / "scripts" / SCRIPT)
    for f in ("package_reports.py", "check_evidence.py", "junit_ran.py", "prereq_status.py", "compare_registries.py"):
        shutil.copy2(ROOT / "scripts" / f, home / "scripts" / f)
    for f, body in (("check_image_data.py", SIMPLE), ("replication_registry.py", REGISTRY), ("make_view.py", VIEW),
                    ("validity_table.py", VALIDITY)):
        (home / "scripts" / f).write_text(body)
    (home / "scripts/common.sh").write_text(COMMON)
    (home / "audit_v5/tools").mkdir(parents=True)
    for name in ("image_forks.py", "fork_continuation.py", "mechanism_diagnostics.py", "reference_recompute.py"):
        (home / "audit_v5/tools" / name).write_text(TOOL)
    (home / "configs").mkdir()
    for f in ("v66_wave29_registry.json", "v66_image_registry.json", "v66_mechanism_registry.json"):
        shutil.copy2(ROOT / "configs" / f, home / "configs" / f)
    pt = home / "fake_pytest.sh"
    pt.write_text(PYTEST)
    pt.chmod(0o755)
    zipdir = tmp_path / "zips"
    zipdir.mkdir()
    for d, panels, steps, rdir, regs in (("cop_results_v64", ["panel29"], V64, "v64_reports", ["registry29"]),
                                         ("cop_results_v65", ["panel30", "panel31"], V65, "v65_reports",
                                          ["registry30", "registry31"]),
                                         ("cop_results_v66", ["panel32"], V67, "v66_reports",
                                          ["registry29", "registry30", "registry31"])):
        for p in panels:
            (tmp_path / d / p).mkdir(parents=True)
        (tmp_path / d / rdir).mkdir()
        (tmp_path / d / rdir / "verdict.json").write_text(json.dumps({"steps": steps}))
        for r in regs:
            (tmp_path / d / rdir / f"{r}.json").write_text(json.dumps({"results": [
                {"key": "k", "reading": "replicated", "mean_favourable": 0.1}]}))
    base = {k: v for k, v in os.environ.items() if k not in ("COP_PYTEST", "V64_RESULTS", "V65_RESULTS",
                                                             "V67_RESULTS")}
    env = dict(base, MOCK_HOME=str(home), COP_RESULTS=str(tmp_path / "results"), ZIP_DIR=str(zipdir), SCALE="full",
               HOME=str(tmp_path), COP_PYTEST=str(pt),
               **{f"MOCK_FILES_{n}": ",".join(FILES[k]) for n, k in NAMES.items()})
    return {"home": home, "res": tmp_path / "results", "zip": zipdir / "cop_v68_reanalysis_reports.zip", "env": env,
            "tmp": tmp_path}


def _sh(h, **env):
    e = dict(h["env"], **{k: str(v) for k, v in env.items()})
    return subprocess.run(["bash", str(h["home"] / "scripts" / SCRIPT)], env=e, capture_output=True, text=True,
                          cwd=str(h["home"]))


def _verdict(h):
    return json.loads((h["res"] / "v68_reports/verdict.json").read_text())


def _events(h):
    p = h["home"] / "events.txt"
    return p.read_text() if p.exists() else ""


def _pf(h):
    return {ln.split()[1]: json.loads(ln.split(" PF ", 1)[1]) for ln in _events(h).splitlines()
            if ln.startswith("registry ")}


def _tree(p: Path) -> list:
    return sorted(str(x.relative_to(p)) for x in p.rglob("*"))


def _set(h, folder, rdir, **steps):
    p = h["tmp"] / folder / rdir / "verdict.json"
    d = json.loads(p.read_text())
    d["steps"].update(steps)
    p.write_text(json.dumps(d))


def test_it_reanalyses_without_training_and_packages(h):
    before = {d: _tree(h["tmp"] / d) for d in ("cop_results_v64", "cop_results_v65", "cop_results_v66")}
    r = _sh(h)
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-3000:]
    assert _verdict(h)["all_passed"]
    ev = _events(h)
    assert not any(x.startswith("cop run") for x in ev.splitlines())
    views = [x for x in ev.splitlines() if x.startswith("view ")]
    assert len(views) == 2 and all("cop_results_v66/panel32" in x for x in views)
    for t in ("fork29 read", "image30 read", "fork31 read", "mech31 read", "ref29 read", "ref30 read", "ref31 read"):
        assert t in ev
    assert _pf(h) == {"v66_wave29_registry.json": [], "v66_image_registry.json": [], "v66_mechanism_registry.json": []}
    v = _verdict(h)
    assert "NOT APPLICABLE" in (h["res"] / "v68_reports/cuda_tests.txt").read_text() and v["steps"]["cuda_tests"] == 0
    for d, t in before.items():
        assert _tree(h["tmp"] / d) == t
    names = zipfile.ZipFile(h["zip"]).namelist()
    for f in ("registry29.json", "registry31.csv", "changes_v67_registry30.csv", "changes_orig_registry29.csv",
              "ref30_rows.csv", "mech31_regrowth.csv", "fork31_validity.csv", "prereq31_failed.txt", "evidence.json"):
        assert f"cop_v68_reanalysis_reports/v68_reports/{f}" in names, f


def test_wave32_enters_the_views_only_when_v67_trained_it(h):
    _set(h, "cop_results_v66", "v66_reports", run32=1)
    _sh(h)
    views = [x for x in _events(h).splitlines() if x.startswith("view ")]
    assert len(views) == 2 and not any("panel32" in x for x in views)
    assert all(v == [] for v in _pf(h).values())          # v67's steps are not this evidence's prerequisites then


@pytest.mark.parametrize("env, flag", [({"MOCK_CUDA_TEST_RC": 1}, "v68:cuda_tests (1)"),
                                       ({"MOCK_CUDA_ALL_SKIPPED": 1}, "v68:cuda_tests_ran (1)")])
def test_a_failed_or_empty_cuda_run_labels_every_registry(h, env, flag):
    r = _sh(h, MOCK_DEVICE="cuda", **env)
    assert r.returncode == 1
    pf = _pf(h)
    assert set(pf) == {"v66_wave29_registry.json", "v66_image_registry.json", "v66_mechanism_registry.json"}
    assert all(flag in v for v in pf.values()), pf


def test_a_cuda_run_that_passes_labels_nothing(h):
    r = _sh(h, MOCK_DEVICE="cuda")
    assert r.returncode == 0, r.stdout[-2000:]
    assert all(v == [] for v in _pf(h).values())


@pytest.mark.parametrize("folder, rdir, step, regs", [
    ("cop_results_v64", "v64_reports", "cuda_tests_ran", {"v66_wave29_registry.json"}),
    ("cop_results_v64", "v64_reports", "reload29", {"v66_wave29_registry.json"}),
    ("cop_results_v65", "v65_reports", "cuda_tests", {"v66_image_registry.json", "v66_mechanism_registry.json"}),
    ("cop_results_v65", "v65_reports", "summary31", {"v66_mechanism_registry.json"}),
    ("cop_results_v66", "v66_reports", "checks32", {"v66_wave29_registry.json", "v66_image_registry.json"}),
    ("cop_results_v66", "v66_reports", "cuda_tests", {"v66_wave29_registry.json", "v66_image_registry.json"})])
def test_a_failed_source_prerequisite_labels_the_registries_that_read_its_runs(h, folder, rdir, step, regs):
    _set(h, folder, rdir, **{step: 1})
    _sh(h)
    pf = _pf(h)
    lab = {"cop_results_v64": "v64", "cop_results_v65": "v65", "cop_results_v66": "v67"}[folder]
    for k, v in pf.items():
        assert (f"{lab}:{step} (1)" in v) == (k in regs), (k, v)


def test_failed_tests_label_every_registry_and_analyses_still_run(h):
    r = _sh(h, MOCK_TEST_RC=1)
    assert r.returncode == 1
    ev = _events(h)
    assert "fork31 read" in ev and "ref29 read" in ev
    assert all(any(x.startswith("v68:cpu_tests") for x in v) for v in _pf(h).values())


def test_a_failed_analysis_is_still_read(h):
    r = _sh(h, MOCK_RC_fork31=1)
    assert r.returncode == 1
    assert "registry v66_mechanism_registry.json" in _events(h)
    assert _verdict(h)["steps"]["fork31"] == 1


def test_a_reduced_scale_is_refused(h):
    r = _sh(h, SCALE="smoke")
    assert r.returncode == 2 and not _events(h)
