"""v68: the implementation against an independent reference (audit_v5/tools/reference_impl.py: raw torch.nn.functional,
no cop.graph or cop.train code).

  forward      logits, the merge input h, every branch output and the merge output, MLP and CNN, one and two rounds,
               unequal channel counts, a non-square image
  gradients    every parameter and the gradient at h, ordinary and routed (mixed, all-a and all-b batches), batch
               permutation; the ordinary reference against finite differences of the forward loss, and the routed
               rule shown NOT to be the forward derivative (the intended surrogate)
  optimizer    the actual trainer (cop.train.Trainer, one segment, fixed batches) against AdamW written from its
               definition: one fresh update and three carried updates, with and without the input hold, with weight
               decay, compared in parameters and in both moments; the held entries exactly unchanged
  edits        the exact fold (W (I + M), b + W c), the swap and the shift (W (I + M)(I + s M)^-1) against the
               implementation's edits: tensors, function, the ordinary gradient unchanged, the routed one changed
  CUDA         the forward, gradients and trainer step in float32 on the GPU against the float64 reference (cuda)"""
from __future__ import annotations

import copy
import math
import sys
from pathlib import Path

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "audit_v5" / "tools"))
import reference_impl as R  # noqa: E402
import test_v65 as T  # noqa: E402
from cop.data.registry import load_bundle  # noqa: E402
from cop.experiments.dissipation import retained_mask_ctx  # noqa: E402
from cop.graph import edits as E  # noqa: E402
from cop.graph.builders import build_model  # noqa: E402
from cop.graph.export import export_compact  # noqa: E402
from cop.graph.redistribute import shift_to_receiver, swap_branches, the_group  # noqa: E402
from cop.orchestration.manifest import generate  # noqa: E402
from cop.train.trainer import Segment, Trainer  # noqa: E402

GROWTH = {"spec_partition": "random_matched", "specialize": "class_halves", "spec_mask_route": "gradient"}
MLP_DATA = {"name": "shortcut", "n_train": 200, "data_seed": 3, "params": {"d_causal": 12, "d_noise": 12}}


def _net(fam, rounds=2, width_mult=0.25, branch_width=5, dtype=torch.float64, seed=0):
    if fam == "cnn":
        b = T._bundle()
        g = build_model({"family": "cnn_cut", "width_mult": width_mult}, b, torch.Generator().manual_seed(seed))
    else:
        b = load_bundle(MLP_DATA)
        g = build_model({"family": "mlp", "width": 12, "depth": 6}, b, torch.Generator().manual_seed(seed))
    h = g.clone(share_params=False)
    G = E.insert_group(h, E.cut_at(h, "post_act", "middle"), torch.Generator().manual_seed(seed))
    for r in range(1, rounds + 1):
        for ab in "ab":
            E.add_branch(h, G, torch.Generator().manual_seed(100 * r + ord(ab)), width=branch_width, act="identity",
                         specialize_mask=f"spec_{ab}", slot=f"spec/r{r}/{ab}")
    gp = torch.Generator().manual_seed(seed + 7)
    with torch.no_grad():
        for n in h.live_nodes():
            if h.nodes[n].owner is not None and h.nodes[n].pkey:
                for p in h.mods[h.nodes[n].pkey].parameters():
                    p.add_(0.4 * torch.randn(p.shape, generator=gp))
    h = copy.deepcopy(h).to(dtype)
    h._plan = None
    return b, h, G


def _graph_grads(g, x, y, masks=None):
    gg = copy.deepcopy(g)
    gg._plan = None
    gg.train()
    gg.zero_grad(set_to_none=True)
    G = the_group(gg)
    entry = gg.implants[G].entry
    out, nv = gg.forward({"x": x}, {"grad_masks": masks} if masks else None, return_nodes=[entry])
    hn = nv[entry]
    hn.retain_grad()
    torch.nn.functional.cross_entropy(out, y.long()).backward()
    return {k.split(".", 1)[1]: p.grad.detach().clone() for k, p in gg.named_parameters()}, \
        (hn.grad.detach().clone() if hn.grad is not None else None)


def _mem(n, seed=1):
    return (torch.rand(n, generator=torch.Generator().manual_seed(seed)) < 0.5).long()


@pytest.mark.parametrize("fam, rounds, wm, bw", [("cnn", 1, 0.25, 5), ("cnn", 2, 0.25, 5), ("cnn", 2, 0.5, 7),
                                                 ("mlp", 1, None, 5), ("mlp", 2, None, 9)])
def test_forward_and_gradients_match_the_reference(fam, rounds, wm, bw):
    b, g, G = _net(fam, rounds, wm or 0.25, bw)
    ref = R.RefNet.from_model_dict(g.checkpoint())
    assert len(ref.branches) == 2 * rounds
    n = 48
    x, y = b.train.X["x"][:n].double(), b.train.y[:n]
    nodes = [g.implants[G].entry, g.implants[G].exit] + \
        [g.implants[i].exit for i in g.implants if g.implants[i].parent == G]
    with torch.no_grad():
        zg, nv = g.forward({"x": x}, return_nodes=nodes)
        zr, inter = ref.forward(x, keep=True)
    assert R.rel(zr, zg) < 1e-12
    assert R.rel(inter["h"], nv[g.implants[G].entry]) < 1e-12 and R.rel(inter["z"], nv[g.implants[G].exit]) < 1e-12
    for i in g.implants:
        if g.implants[i].parent == G:
            assert R.rel(inter[f"t_{i}"], nv[g.implants[i].exit]) < 1e-12
    m = (torch.arange(n) % 3 == 0).double()
    cases = {"ordinary": None, "mixed": {"spec_a": m, "spec_b": 1 - m},
             "all_a": {"spec_a": torch.ones(n, dtype=torch.float64), "spec_b": torch.zeros(n, dtype=torch.float64)},
             "all_b": {"spec_a": torch.zeros(n, dtype=torch.float64), "spec_b": torch.ones(n, dtype=torch.float64)}}
    first = f"{ref.first_layer()}.weight"
    got = {}
    for name, masks in cases.items():
        gG, hG = _graph_grads(g, x, y, masks)
        _, gR, hR = R.grads_of(ref, x, y, masks)
        assert sorted(gR) == sorted(gG)
        for k in gR:
            assert R.rel(gR[k], gG[k]) < 1e-10, (name, k)
        assert hG is not None and R.rel(hR, hG) < 1e-10
        got[name] = gR
        # permutation of the batch leaves the (mean) gradient unchanged
        pi = torch.randperm(n, generator=torch.Generator().manual_seed(5))
        pm = None if masks is None else {k: v[pi] for k, v in masks.items()}
        _, gRp, _ = R.grads_of(ref, x[pi], y[pi], pm)
        gGp, _ = _graph_grads(g, x[pi], y[pi], pm)
        assert R.rel(gRp[first], gR[first]) < 1e-12 and R.rel(gGp[first], gG[first]) < 1e-12
    for name in ("mixed", "all_a", "all_b"):
        assert R.rel(got[name][first], got["ordinary"][first]) > 1e-4        # routing changes the backbone gradient


def test_the_ordinary_reference_is_the_forward_derivative_and_routing_is_not():
    b, g, G = _net("mlp", 1)
    ref = R.RefNet.from_model_dict(g.checkpoint())
    x, y = b.train.X["x"][:32].double(), b.train.y[:32]
    m = (torch.arange(32) % 2 == 0).double()
    _, go, _ = R.grads_of(ref, x, y)
    _, gr, _ = R.grads_of(ref, x, y, {"spec_a": m, "spec_b": 1 - m})
    k = f"{ref.first_layer()}.weight"
    eps = 1e-6
    for (i, j) in [(0, 0), (3, 5), (7, 11)]:
        P = {kk: v.clone() for kk, v in ref.P.items()}
        Pp, Pm = {kk: v.clone() for kk, v in P.items()}, {kk: v.clone() for kk, v in P.items()}
        Pp[k][i, j] += eps
        Pm[k][i, j] -= eps
        lp = R.ce_loss(R.RefNet(ref.family, ref.backbone, ref.recv_index, ref.branches, Pp, ref.cut_after)(x), y)
        lm = R.ce_loss(R.RefNet(ref.family, ref.backbone, ref.recv_index, ref.branches, Pm, ref.cut_after)(x), y)
        fd = float(lp - lm) / (2 * eps)
        assert abs(fd - float(go[k][i, j])) < 1e-7
    assert R.rel(gr[k], go[k]) > 1e-4                  # the routed rule is a surrogate, not the forward derivative


def _tcfg(**over):
    m = generate([30], "full").entries
    t = next(e["cfg"]["train"] for e in m.values() if e["cfg"]["kind"] == "dissipation")
    return {**t, **over}


@pytest.mark.parametrize("fam", ["mlp", "cnn"])
@pytest.mark.parametrize("hold, wd, routed", [(False, 0.0, True), (True, 0.0, True), (True, 0.01, True),
                                              (True, 0.01, False)])
def test_the_trainer_matches_adamw_written_from_its_definition(fam, hold, wd, routed):
    b, g, G = _net(fam, 2)
    N = len(b.train)
    mem = _mem(N)
    tc = _tcfg(precision="fp64", weight_decay=wd, freeze_inputs="shortcut" if hold else "none", lr=3e-3)
    ctx_fn = retained_mask_ctx(b, mem, GROWTH) if routed else None
    bs = 32
    idxs = [torch.randperm(N, generator=torch.Generator().manual_seed(10 + k))[:bs] for k in range(4)]
    batches = [b.train.index(i) for i in idxs]
    ref = R.RefNet.from_model_dict(g.checkpoint())
    first = f"{ref.first_layer()}.weight"
    col = int(b.meta["feature_layout"]["shortcut"])
    gm = copy.deepcopy(g)
    gm._plan = None
    tr = Trainer(gm, b, tc, {"minibatch": 0, "augmentation": 0}, "cpu")
    tr.configure("none", None, reset_state=True)
    it = iter(batches)
    tr.next_batch = lambda: next(it)
    snaps = []
    r = tr.run(Segment("s", 4, batch_ctx=ctx_fn, post_step=lambda trn, k: snaps.append(
        {kk.split(".", 1)[1]: p.detach().clone() for kk, p in trn.model.named_parameters()}),
        freeze_inputs=tc["freeze_inputs"]))
    assert int(r["updates"]) == 4
    opt = R.RefAdamW({k: v.clone() for k, v in ref.P.items()}, lr=tc["lr"], betas=tuple(tc["betas"]), wd=wd,
                     hold=(first, [col]) if hold else None)
    start = ref.P[first][:, col].clone()
    for k, (i, bt) in enumerate(zip(idxs, batches)):
        net = R.RefNet(ref.family, ref.backbone, ref.recv_index, ref.branches, opt.P, ref.cut_after)
        masks = None
        if routed:
            a = mem[i].double()
            masks = {"spec_a": a, "spec_b": 1 - a}
        _, gr, _ = R.grads_of(net, bt.X["x"].double(), bt.y, masks)
        opt.step(gr)
        for kk in opt.P:
            assert R.rel(snaps[k][kk], opt.P[kk]) < 1e-10, (k, kk)
        if hold:
            assert torch.equal(snaps[k][first][:, col], start)      # exactly held, with weight decay too
    names = list(tr.opt_param_names)
    flat = [p for gp in tr.opt.param_groups for p in gp["params"]]
    for nm, p in zip(names, flat):
        st = tr.opt.state[p]
        assert int(st["step"]) == 4
        assert R.rel(st["exp_avg"], opt.m[nm]) < 1e-10 and R.rel(st["exp_avg_sq"], opt.v[nm]) < 1e-10, nm


@pytest.mark.parametrize("fam", ["mlp", "cnn"])
def test_the_edits_match_the_reference(fam):
    b, g, G = _net(fam, 2)
    md = g.checkpoint()
    ref = R.RefNet.from_model_dict(md)
    n = 40
    x, y = b.train.X["x"][:n].double(), b.train.y[:n]
    m = (torch.arange(n) % 3 == 0).double()
    masks = {"spec_a": m, "spec_b": 1 - m}
    first = f"{ref.first_layer()}.weight"
    recv = ref.receiver()
    # fold
    folded = export_compact(E.fold_implant(copy.deepcopy(g), G, share_params=False, drop_grad_masks=True),
                            fold_linear=True)[0]
    rf = ref.folded()
    with torch.no_grad():
        assert R.rel(rf(x), folded({"x": x})) < 1e-12 and R.rel(rf(x), ref(x)) < 1e-12
    fsd = {k.split(".", 1)[1]: v for k, v in folded.state_dict().items()}
    rec_w = [v for k, v in fsd.items() if v.shape == rf.P[f"{recv}.weight"].shape and k.endswith("weight")
             and R.rel(v, rf.P[f"{recv}.weight"]) < 1e-12]
    assert rec_w, "the implementation's folded receiver is not W (I + M)"
    # swap
    gs = copy.deepcopy(g)
    swap_branches(gs)
    rs = ref.with_swap(R.swap_pairs(md))
    ssd = {k.split(".", 1)[1]: v for k, v in gs.state_dict().items()}
    for k in rs.P:
        assert torch.equal(ssd[k], rs.P[k]), k                         # tensors moved exactly
    with torch.no_grad():
        assert R.rel(rs(x), ref(x)) < 1e-12 and R.rel(gs({"x": x}), g({"x": x})) < 1e-12
    _, go0, _ = R.grads_of(ref, x, y)
    _, go1, _ = R.grads_of(rs, x, y)
    _, gr0, _ = R.grads_of(ref, x, y, masks)
    _, gr1, _ = R.grads_of(rs, x, y, masks)
    assert R.rel(go1[first], go0[first]) < 1e-12 and R.rel(gr1[first], gr0[first]) > 1e-4
    gG1, _ = _graph_grads(gs, x, y, masks)
    assert R.rel(gG1[first], gr1[first]) < 1e-10
    # shift
    for t in (0.5, 1.0):
        gh = copy.deepcopy(g)
        shift_to_receiver(gh, t)
        rh = ref.with_shift(t)
        hsd = {k.split(".", 1)[1]: v for k, v in gh.state_dict().items()}
        for k in rh.P:
            assert R.rel(hsd[k], rh.P[k]) < 1e-10, (t, k)
        with torch.no_grad():
            assert R.rel(rh(x), ref(x)) < 1e-10
        _, go1, h1 = R.grads_of(rh, x, y)
        _, go0, h0 = R.grads_of(ref, x, y)
        assert R.rel(go1[first], go0[first]) < 1e-9 and R.rel(h1, h0) < 1e-9     # ordinary: unchanged at h
        _, gr1, _ = R.grads_of(rh, x, y, masks)
        assert R.rel(gr1[first], gr0[first]) > 1e-4                              # routed: changed
        if t == 1.0:
            for br in rh.branches:
                assert float(rh.P[f"{br['B']}.weight"].abs().max()) == 0.0 and \
                    float(rh.P[f"{br['B']}.bias"].abs().max()) == 0.0


# ----------------------------------------------------------------------------- step by step (v69)

def _close(a, b, rtol, atol_scale):
    """|a - b| <= atol + rtol |b| elementwise, atol = atol_scale x max |b| of the tensor; -> (ok, worst ratio)."""
    a, b = a.double().cpu(), b.double().cpu()
    atol = atol_scale * max(float(b.abs().max()), 1e-30) if b.numel() else 0.0
    bound = atol + rtol * b.abs()
    r = float(((a - b).abs() / bound.clamp_min(1e-300)).max()) if b.numel() else 0.0
    return r <= 1.0, r


def _stepwise(fam, hold, wd, dev, dtype, gtol, steps=3):
    """the actual trainer, one segment of `steps` updates on fixed routed batches, captured before and after every
    update; the reference recomputes each update from the trainer's own state before it (parameters, both moments,
    the counters) and is compared with the state after it, on every coordinate.  Returns the worst ratios."""
    b, g64, G = _net(fam, 2)
    bd = b.to(dev) if dev != "cpu" else b
    g = copy.deepcopy(g64).to(dtype).to(dev)
    g._plan = None
    N = len(b.train)
    mem = _mem(N)
    ctx_fn = retained_mask_ctx(bd, mem.to(dev), GROWTH)
    idxs = [torch.randperm(N, generator=torch.Generator().manual_seed(20 + k))[:32] for k in range(steps)]
    batches = [bd.train.index(i.to(dev)) for i in idxs]
    tc = _tcfg(precision="fp64" if dtype == torch.float64 else "fp32", weight_decay=wd, lr=2e-3,
               freeze_inputs="shortcut" if hold else "none")
    tr = Trainer(g, bd, tc, {"minibatch": 0, "augmentation": 0}, dev)
    tr.configure("none", None, reset_state=True)
    it = iter(batches)
    tr.next_batch = lambda: next(it)
    caps = []

    def grab(trn):
        names = list(trn.opt_param_names)
        flat = [p for gp in trn.opt.param_groups for p in gp["params"]]
        return {"P": {n: p.detach().double().cpu().clone() for n, p in zip(names, flat)},
                "st": {n: {k: (v.detach().double().cpu().clone() if torch.is_tensor(v) else v)
                           for k, v in trn.opt.state.get(p, {}).items()} for n, p in zip(names, flat)}}
    tr.run(Segment("s", steps, batch_ctx=ctx_fn, on_step=lambda trn, k: caps.append({"before": grab(trn)}),
                   post_step=lambda trn, k: caps[-1].update(after=grab(trn)), freeze_inputs=tc["freeze_inputs"]))
    assert len(caps) == steps
    ref0 = R.RefNet.from_model_dict(g64.checkpoint())
    first = f"{ref0.first_layer()}.weight"
    col = int(b.meta["feature_layout"]["shortcut"])
    worst = {"grad": 0.0, "h": 0.0, "disp": 0.0, "m": 0.0, "v": 0.0, "sensitive": 0}
    for k, c in enumerate(caps):
        Pb = {n: t.clone() for n, t in c["before"]["P"].items()}
        net = R.RefNet(ref0.family, ref0.backbone, ref0.recv_index, ref0.branches, Pb, ref0.cut_after)
        a = mem[idxs[k]].double()
        masks = {"spec_a": a, "spec_b": 1 - a}
        x, y = batches[k].X["x"].cpu().double(), batches[k].y.cpu()
        _, gr, hr = R.grads_of(net, x, y, masks)
        opt = R.RefAdamW({n: t.clone() for n, t in Pb.items()}, lr=tc["lr"], betas=tuple(tc["betas"]), wd=wd,
                         hold=(first, [col]) if hold else None)
        for n, st in c["before"]["st"].items():
            if st:
                opt.m[n], opt.v[n], opt.t[n] = st["exp_avg"].clone(), st["exp_avg_sq"].clone(), int(float(st["step"]))
        if hold:
            opt.held = c["before"]["P"][first][:, [col]].clone()
        opt.step(gr)
        after = c["after"]
        for n in opt.P:
            st = after["st"][n]
            assert int(float(st["step"])) == opt.t[n] == k + 1, (k, n)
            ok, r = _close(st["exp_avg"], opt.m[n], gtol, gtol)
            assert ok, ("m", k, n, r)
            worst["m"] = max(worst["m"], r)
            ok, r = _close(st["exp_avg_sq"], opt.v[n], 2 * gtol, 2 * gtol)
            assert ok, ("v", k, n, r)
            worst["v"] = max(worst["v"], r)
            d_i, d_r = after["P"][n] - c["before"]["P"][n], opt.P[n] - Pb[n]
            # where the gradient is below the float32 gradient error the Adam ratio m / (sqrt(v) + eps) is not
            # determined by the gradient; there the check is the bound every Adam step obeys
            gscale = float(gr[n].abs().max()) if gr[n].numel() else 0.0
            sens = gr[n].abs() <= 10 * gtol * gscale
            worst["sensitive"] += int(sens.sum())
            # Adam's per-step bound |m_hat / (sqrt(v_hat) + eps)| <= (1 - b1) / sqrt(1 - b2) (3.17 with the
            # defaults), plus the decoupled decay
            lim = tc["lr"] * (1 - tc["betas"][0]) / math.sqrt(1 - tc["betas"][1]) * 1.001 + \
                tc["lr"] * wd * float(Pb[n].abs().max())
            assert float(d_i[sens].abs().max()) <= lim if bool(sens.any()) else True, ("bound", k, n)
            ok_, r = _close(d_i[~sens], d_r[~sens], 1e3 * gtol, 1e3 * gtol) if bool((~sens).any()) else (True, 0.0)
            assert ok_, ("disp", k, n, r)
            worst["disp"] = max(worst["disp"], r)
            assert bool((~sens).any()) or not bool(gr[n].abs().max()), ("no coordinate compared", n)
            if hold and n == first:
                assert torch.equal(after["P"][n][:, col], c["before"]["P"][n][:, col])
    return worst


@pytest.mark.parametrize("fam", ["mlp", "cnn"])
@pytest.mark.parametrize("hold, wd", [(False, 0.0), (True, 0.01)])
def test_every_trainer_step_matches_the_reference_cpu(fam, hold, wd):
    w = _stepwise(fam, hold, wd, "cpu", torch.float64, gtol=1e-9)
    assert w["m"] <= 1 and w["disp"] <= 1


def _gpu_gradients(fam, dev):
    b, g64, G = _net(fam, 2)
    ref = R.RefNet.from_model_dict(g64.checkpoint())
    g32 = copy.deepcopy(g64).float().to(dev)
    g32._plan = None
    n = 64
    x, y = b.train.X["x"][:n], b.train.y[:n]
    m = (torch.arange(n) % 3 == 0).float()
    with torch.no_grad():
        zr = ref(x.double())
        ok, r = _close(g32({"x": x.to(dev)}).cpu(), zr, 1e-4, 1e-4)
        assert ok, ("logits", r)
    gG, hG = _graph_grads(g32, x.to(dev), y.to(dev), {"spec_a": m.to(dev), "spec_b": (1 - m).to(dev)})
    _, gR, hR = R.grads_of(ref, x.double(), y, {"spec_a": m.double(), "spec_b": 1 - m.double()})
    ok, r = _close(hG.cpu(), hR, 1e-3, 1e-4)
    assert ok, ("h", r)
    for k in gR:
        ok, r = _close(gG[k].cpu(), gR[k], 1e-3, 1e-4)
        assert ok, (k, r)


@pytest.mark.skipif(not torch.cuda.is_available(), reason="needs CUDA")
@pytest.mark.parametrize("fam", ["mlp", "cnn"])
@pytest.mark.parametrize("hold, wd", [(False, 0.0), (True, 0.01)])
def test_cuda_float32_against_the_float64_reference(fam, hold, wd):
    """GPU float32: logits, the gradient at h and every parameter gradient; then three trainer updates, each
    recomputed by the reference from the trainer's own state before it: every gradient, update, both moments and
    the counters (mixed tolerances relative to each tensor's scale; coordinates whose gradient is below the float32
    error checked against Adam's step bound, and counted)."""
    import os
    dev = os.environ.get("COP_TEST_CUDA_DEVICE", "cuda")
    tf = (torch.backends.cuda.matmul.allow_tf32, torch.backends.cudnn.allow_tf32)
    torch.backends.cuda.matmul.allow_tf32 = False            # the training policy (cop.utils): no TF32
    torch.backends.cudnn.allow_tf32 = False
    try:
        _gpu_gradients(fam, dev)
        w = _stepwise(fam, hold, wd, dev, torch.float32, gtol=1e-4)
        print("worst", w)
    finally:
        torch.backends.cuda.matmul.allow_tf32, torch.backends.cudnn.allow_tf32 = tf


def test_the_stepwise_check_catches_a_scaled_gradient(monkeypatch):
    """a gradient 1 percent too large leaves Adam's first displacement almost unchanged but not its moments."""
    real = R.grads_of

    def scaled(net, x, y, masks=None):
        l_, g_, h_ = real(net, x, y, masks)
        return l_, {k: 1.01 * v for k, v in g_.items()}, h_
    monkeypatch.setattr(R, "grads_of", scaled)
    with pytest.raises(AssertionError):
        _stepwise("mlp", True, 0.01, "cpu", torch.float64, gtol=1e-6)


def test_a_grown_network_keeps_per_tensor_optimizer_ages():
    """two updates of the compact network, a merge group inserted, the optimizer state preserved for the surviving
    tensors (the trajectories' opt_state_on_edit), one routed update: old tensors at step 3, new ones at step 1, and
    the reference reproduces the update from the trainer's own per-tensor state."""
    b = load_bundle(MLP_DATA)
    g = build_model({"family": "mlp", "width": 12, "depth": 6}, b, torch.Generator().manual_seed(0)).double()
    g._plan = None
    N = len(b.train)
    mem = _mem(N)
    tc = _tcfg(precision="fp64", weight_decay=0.01, lr=2e-3, freeze_inputs="shortcut")
    tr = Trainer(g, b, tc, {"minibatch": 0, "augmentation": 0}, "cpu")
    tr.configure("none", None, reset_state=True)
    bt = [b.train.index(torch.randperm(N, generator=torch.Generator().manual_seed(40 + k))[:32]) for k in range(3)]
    it = iter(bt)
    tr.next_batch = lambda: next(it)
    tr.run(Segment("a", 2, freeze_inputs="shortcut"))
    h = tr.model
    G = E.insert_group(h, E.cut_at(h, "post_act", "middle"), torch.Generator().manual_seed(3))
    for ab in "ab":
        E.add_branch(h, G, torch.Generator().manual_seed(ord(ab)), width=5, act="identity",
                     specialize_mask=f"spec_{ab}", slot=f"spec/r1/{ab}")
    h.to(torch.float64)
    h._plan = None
    tr.configure("none", None, reset_state=False)
    ctx_fn = retained_mask_ctx(b, mem, GROWTH)
    bt[2] = b.train.index(torch.randperm(N, generator=torch.Generator().manual_seed(42))[:32])
    names = list(tr.opt_param_names)
    flat = [p for gp in tr.opt.param_groups for p in gp["params"]]
    before = {n: p.detach().clone() for n, p in zip(names, flat)}
    st0 = copy.deepcopy(tr.state_dict())
    tr.run(Segment("b", 1, batch_ctx=ctx_fn, freeze_inputs="shortcut"))
    after = {n: p.detach().clone() for n, p in zip(names, flat)}
    steps = {n: int(float(tr.opt.state[p]["step"])) for n, p in zip(names, flat)}
    owned = {f"{h.nodes[n].pkey}.{w}" for n in h.live_nodes() if h.nodes[n].owner is not None and h.nodes[n].pkey
             for w in ("weight", "bias")}
    assert owned and all(steps[n] == (1 if n in owned else 3) for n in names), steps
    ref = R.RefNet.from_model_dict(h.checkpoint())
    first = f"{ref.first_layer()}.weight"
    col = int(b.meta["feature_layout"]["shortcut"])
    ref.P.update({n: before[n].clone() for n in names})
    opt = R.RefAdamW.from_saved(ref.P, st0, hold=(first, [col]))
    opt.held = before[first][:, [col]].clone()
    assert all(opt.t[n] == (0 if n in owned else 2) for n in names)
    a = mem[torch.randperm(N, generator=torch.Generator().manual_seed(42))[:32]].double()
    _, gr, _ = R.grads_of(ref, bt[2].X["x"].double(), bt[2].y, {"spec_a": a, "spec_b": 1 - a})
    opt.step(gr)
    for n in names:
        assert R.rel(after[n], opt.P[n]) < 1e-10, n
        assert R.rel(tr.opt.state[flat[names.index(n)]]["exp_avg"], opt.m[n]) < 1e-10, n


def test_an_interrupted_segment_resumes_to_the_same_state():
    b, g, G = _net("mlp", 2)
    N = len(b.train)
    mem = _mem(N)
    tc = _tcfg(precision="fp64", weight_decay=0.01, lr=2e-3, freeze_inputs="shortcut")
    ctx_fn = retained_mask_ctx(b, mem, GROWTH)
    bt = [b.train.index(torch.randperm(N, generator=torch.Generator().manual_seed(60 + k))[:32]) for k in range(4)]

    def trainer(model):
        t = Trainer(model, b, tc, {"minibatch": 0, "augmentation": 0}, "cpu")
        return t
    ga = copy.deepcopy(g)
    ga._plan = None
    ta = trainer(ga)
    ta.configure("none", None, reset_state=True)
    ia = iter(bt)
    ta.next_batch = lambda: next(ia)
    ta.run(Segment("s", 4, batch_ctx=ctx_fn, freeze_inputs="shortcut"))
    gb = copy.deepcopy(g)
    gb._plan = None
    tb = trainer(gb)
    tb.configure("none", None, reset_state=True)
    ib = iter(bt[:2])
    tb.next_batch = lambda: next(ib)
    tb.run(Segment("s", 2, batch_ctx=ctx_fn, freeze_inputs="shortcut"))
    saved_m, saved_t = gb.checkpoint(), copy.deepcopy(tb.state_dict())
    from cop.graph.graph import GraphNet
    gc = GraphNet.from_checkpoint(saved_m, "cpu")
    tcc = trainer(gc)
    tcc.configure("none", None, reset_state=True)
    tcc.load_state_dict(saved_t)
    ic = iter(bt[2:])
    tcc.next_batch = lambda: next(ic)
    tcc.state["segment"], tcc.state["seg_step"] = "s", 2
    tcc.run(Segment("s", 4, batch_ctx=ctx_fn, freeze_inputs="shortcut"))
    for (ka, pa), (kc, pc) in zip(ga.named_parameters(), gc.named_parameters()):
        assert ka == kc and torch.equal(pa, pc), ka


def _mutate(md, fn):
    m = copy.deepcopy(md)
    nodes = {n["id"]: n for n in m["spec"]["nodes"]}
    fn(m, nodes)
    return m


def _role(nodes, r):
    return next(n for n in nodes.values() if n["role"] == r)


@pytest.mark.parametrize("fam, what", [
    ("cnn", "gate"), ("cnn", "conv_k"), ("cnn", "conv_stride"), ("cnn", "pool_avg"), ("cnn", "act_tanh"),
    ("cnn", "rewire_head"), ("cnn", "extra_param"), ("cnn", "side_output"), ("cnn", "merge_coef"),
    ("mlp", "act_tanh"), ("mlp", "rewire_head"), ("mlp", "gate"), ("mlp", "stray_node"), ("mlp", "branch_reads_other")])
def test_the_reference_refuses_what_it_does_not_implement(fam, what):
    b, g, G = _net(fam, 1)
    md = g.checkpoint()
    R.RefNet.from_model_dict(md)                                     # the unaltered network is accepted

    def f(m, nodes):
        sp = m["spec"]
        if what == "gate":
            sp["gate_vals"] = {G: 0.5}
        elif what == "conv_k":
            _role(nodes, "S0.1.conv")["attrs"]["k"] = 5
        elif what == "conv_stride":
            _role(nodes, "S1.conv")["attrs"]["hw"] = [3, 3]
        elif what == "pool_avg":
            _role(nodes, "S1.pool")["attrs"]["kind"] = "avg"
        elif what == "act_tanh":
            next(n for n in nodes.values() if n["op"] == "act" and n["owner"] is None)["attrs"]["fn"] = "tanh"
        elif what == "rewire_head":
            head = _role(nodes, "head")
            other = next(n for n in nodes.values() if n["op"] == "act" and n["owner"] is None)
            head["inputs"] = [other["id"]]
        elif what == "extra_param":
            m["state"]["mods.p99.weight"] = torch.zeros(2, 2, dtype=torch.float64)
        elif what == "side_output":
            sp["side_outputs"] = {"aux": head_id(nodes)}
        elif what == "merge_coef":
            next(n for n in nodes.values() if n["op"] == "add")["attrs"]["coefs"][1] = 0.5
        elif what == "stray_node":
            sp["nodes"].append({"id": "n999", "op": "act", "inputs": ["n1"], "attrs": {"fn": "relu"}, "pkey": None,
                                "owner": None, "role": "stray"})
        elif what == "branch_reads_other":
            A = next(n for n in nodes.values() if n.get("role") == "A")
            A["inputs"] = ["n1"]
    with pytest.raises(R.Unsupported):
        R.RefNet.from_model_dict(_mutate(md, f))


def head_id(nodes):
    return _role(nodes, "head")["id"]
