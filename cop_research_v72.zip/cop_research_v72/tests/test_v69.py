"""v69: the review of v68 (CHANGES_v69.md).

  reference certificates  on a waves 31 + 32 miniature: the strict reference passes on the real checkpoints (both fork
                          points, every continuation, the saved edits); and fails, or is incomplete, when the
                          implementation's logits are doubled (decisions unchanged), when its normalised weights are
                          off by 0.1 percent (decisions unchanged), when a states row or metric is missing, duplicated
                          or non-finite, when the table value is off by one example, and when two examples swap
                          correctness (the same error rate)
  undecided examples      per example: an outlier logit or a common offset does not make other examples undecided
  registry                --exclude-states makes exactly the dependent rows conditional
  mechanism diagnostic    an f0 that lost its mechanism forks, --expect-f0, a missing promised path checkpoint, a path
                          checkpoint without its update, only the end left: each fails
  carried optimizer state the reference's AdamW imported from a real saved trajectory state (per-tensor ages) gives
                          the trainer's next update
  junit, views            named CUDA reference cases; a symlinked view path is refused"""
from __future__ import annotations

import copy
import csv
import json
import math
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(ROOT / "audit_v5" / "tools"))
import reference_recompute as RC  # noqa: E402
import reference_impl as R  # noqa: E402
from test_v68 import _case, _read, _rows, _tool, _write  # noqa: E402,F401


@pytest.fixture(scope="module")
def mini(tmp_path_factory):
    import v65_mini as VM
    from cop.orchestration.manifest import generate
    root = tmp_path_factory.mktemp("mini69")
    cf = VM.shrink(generate([31, 32], "full").entries, 349, 0, 2000, 20,
                   {"top": {"n_train": 192}, "params": {"d_causal": 12, "d_noise": 12}}, {"width": 12})
    VM.run_all(cf, root)
    man = VM.write_manifest(root / "m.jsonl", cf)
    r = _tool(ROOT / "audit_v5/tools/fork_continuation.py", root, root / "fork31", "--manifest", man, "--strict",
              "--device", "cpu")
    assert r.returncode == 0, r.stdout[-2000:] + r.stderr[-2000:]
    return {"root": root, "cf": cf, "man": man}


def _ref(mini, out, *extra, states=None, cases="standard"):
    root = mini["root"]
    return RC.main([str(root), str(out), "--manifest", str(mini["man"]), "--states",
                    str(states or root / "fork31_states.csv"), "--cases", cases,
                    "--audits", str(root / "fork31_audits.csv"), "--n-f0", "1", *map(str, extra)])


def _cov(out):
    return json.loads(Path(f"{out}_coverage.json").read_text())


@pytest.mark.parametrize("cases", ["standard", "mechanism"])
def test_the_strict_reference_certifies_the_miniature(mini, tmp_path, cases):
    assert _ref(mini, tmp_path / "r", cases=cases) == 0
    c = _cov(tmp_path / "r")
    assert c["complete"] and c["passed"] and c["expected_cases"] == c["checked_cases"] > 0
    plan = json.loads((tmp_path / "r_plan.json").read_text())["cases"]
    forks = {p["fork"] for p in plan if p["parent"] != "f0"}
    assert forks == {"snap_10", "snap_25"}                         # both fork points
    st = {p["state"] for p in plan}
    if cases == "standard":
        assert {"routed_reset", "ordinary_reset", "folded_reset", "frozen_reset", "routed_carry", "folded_start",
                "start", "trajectory_end", "f0"} <= st
    else:
        assert {"routed_swap", "ordinary_swap", "routed_shift50", "routed_shift100", "ordinary_shift100",
                "edit:routed_swap", "edit:routed_shift100"} <= st
        assert c["ill_conditioned"]["run_id"]
    rows = _rows(tmp_path / "r_rows.csv")
    assert all(r["passed"] == "True" for r in rows) and (tmp_path / "r_failed_states.txt").read_text() == ""
    assert c["states_sha256"] and c["manifest_sha256"] and c["checkpoints"]


def test_doubled_logits_fail_although_decisions_agree(mini, tmp_path, monkeypatch):
    real = RC.predict
    monkeypatch.setattr(RC, "predict", lambda *a, **k: 2.0 * real(*a, **k))
    assert _ref(mini, tmp_path / "r") == 4
    rows = _rows(tmp_path / "r_rows.csv")
    assert all(r["function64_ok"] == "False" for r in rows if r.get("function64_ok"))
    assert all(r["disagree"] in ("0", "") for r in rows)          # the same decisions everywhere
    assert _cov(tmp_path / "r")["complete"] and (tmp_path / "r_failed_states.txt").read_text().strip()


def test_off_normalised_weights_fail_the_parameter_certificate(mini, tmp_path, monkeypatch):
    real = RC.impl_edit
    monkeypatch.setattr(RC, "impl_edit", lambda *a, **k: real(*a, **k) * 1.001)
    assert _ref(mini, tmp_path / "r") == 4
    rows = [r for r in _rows(tmp_path / "r_rows.csv") if r["measure"].startswith("state_at_f0")]
    assert rows and all(r["params_ok"] == "False" and r["function64_ok"] == "True" for r in rows
                        if r["state"] != "f0")


def test_two_examples_swapping_correctness_fail(mini, tmp_path, monkeypatch):
    real = RC.predict

    def swap(model, part, batch=4096, dtype=None):
        z = real(model, part, batch, dtype).clone()
        y = part.y.cpu()
        zc = z.double().cpu()
        pr = zc.argmax(1)
        top = zc.topk(2, 1).values
        mg = top[:, 0] - top[:, 1]                               # the two most clearly decided examples
        ok = int(torch.where(pr == y, mg, -math.inf).argmax())
        bad = int(torch.where(pr != y, mg, -math.inf).argmax())
        z[[ok, bad]] = z[[ok, bad]].flip(1)                       # one right example wrong, one wrong one right
        return z
    monkeypatch.setattr(RC, "predict", swap)
    assert _ref(mini, tmp_path / "r") == 4
    rows = _rows(tmp_path / "r_rows.csv")
    nat = [r for r in rows if r["measure"] == "native"]
    assert all(r["deployed_ok"] == "False" and int(r["disagree_decided"]) >= 1 for r in nat)
    assert all(r["table_ok"] == "True" for r in nat)                # the error rate itself did not change


@pytest.mark.parametrize("damage", ["drop_row", "drop_metric", "duplicate", "nonfinite", "off_by_one"])
def test_the_table_comparison_is_required_and_exact(mini, tmp_path, damage):
    rows = _rows(mini["root"] / "fork31_states.csv")
    keys = list(rows[0])
    i = next(k for k, r in enumerate(rows) if (r["parent"], r["fork"], r["state"]) ==
             ("A_routed_affine", "snap_10", "routed_reset"))
    if damage == "drop_row":
        rows.pop(i)
    elif damage == "drop_metric":
        rows[i]["native_test_err"] = ""
    elif damage == "duplicate":
        rows.append(dict(rows[i]))
    elif damage == "nonfinite":
        rows[i]["native_test_err"] = "nan"
    else:
        rows[i]["native_test_err"] = str(float(rows[i]["native_test_err"]) + 1.0 / 8192)
    _write(tmp_path / "s.csv", keys, rows)
    rc = _ref(mini, tmp_path / "r", states=tmp_path / "s.csv")
    c = _cov(tmp_path / "r")
    assert rc != 0 and not c["passed"]
    if damage in ("drop_row", "duplicate"):
        assert not c["complete"]
    else:
        bad = [r for r in _rows(tmp_path / "r_rows.csv") if r["state"] == "routed_reset" and r["fork"] == "snap_10"
               and r["parent"] == "A_routed_affine" and r["measure"] == "native"]
        assert bad and bad[0]["table_ok"] == "False"
        assert "A_routed_affine/snap_10/routed_reset" in (tmp_path / "r_failed_states.txt").read_text()


@pytest.mark.parametrize("why", ["two_f0", "no_audits"])
def test_the_plan_cannot_shrink(mini, tmp_path, why):
    root = mini["root"]
    args = [str(root), str(tmp_path / "r"), "--manifest", str(mini["man"]), "--states",
            str(root / "fork31_states.csv")]
    if why == "two_f0":                                            # the miniature has one f0
        args += ["--n-f0", "2"]
    else:
        args += ["--n-f0", "1", "--cases", "mechanism"]
    assert RC.main(args) == 1
    c = _cov(tmp_path / "r")
    assert not c["complete"] and c["failed"]


def _E(z, tol=1e-4):
    """v70: decisions() takes a bound per example and logit; v69's per-example bound tol (1 + max |z|) as such."""
    return (tol * (1.0 + z.abs().max(dim=1, keepdim=True).values)).expand_as(z).clone()


def test_undecided_examples_are_judged_one_by_one():
    y = torch.tensor([0, 1, 0, 1])
    zr = torch.tensor([[1.0, 0.0], [0.0, 1.0], [2.0, 0.0], [1e6, 0.0]], dtype=torch.float64)
    zd = zr.clone()
    zd[3, 0] -= 1e-4 * 1e6 * 0.5                                    # within the outlier's own bound
    d = RC.decisions(zr, zd, y, _E(zr))
    assert d["ok"] and d["undecided"] == 0                         # the outlier does not widen the others' bounds
    zd2 = zd.clone()
    zd2[0] = torch.tensor([0.0, 1.0], dtype=torch.float64)          # a decided example flips
    d2 = RC.decisions(zr, zd2, y, _E(zr))
    assert not d2["ok"] and d2["disagree_decided"] == 1
    zt = zr.clone()
    zt[0] = torch.tensor([0.5, 0.5 + 1e-12], dtype=torch.float64)
    zt2 = zt.clone()
    zt2[0] = torch.tensor([0.5 + 2e-12, 0.5], dtype=torch.float64)  # a genuine tie, the decision flips
    t = RC.decisions(zt, zt2, y, _E(zt))
    assert t["undecided"] == 1 and t["disagree"] == 1 and t["disagree_decided"] == 0
    assert not t["ok"]                                             # 1 of 4 differing ties exceeds 0.1 percent
    big = torch.zeros(4000, 2, dtype=torch.float64)
    big[:, 0] = 1.0
    big[0] = torch.tensor([0.5, 0.5 + 1e-12], dtype=torch.float64)
    big2 = big.clone()
    big2[0] = torch.tensor([0.5 + 2e-12, 0.5], dtype=torch.float64)
    u = RC.decisions(big, big2, torch.zeros(4000, dtype=torch.long), _E(big))
    assert u["ok"] and u["undecided"] == 1 and u["disagree"] == 1   # one tie in 4000 is allowed


def test_reference_exclusions_make_the_dependent_rows_conditional(tmp_path):
    _case(tmp_path)
    (tmp_path / "x.txt").write_text("b120|P/s1/routed_reset\n")
    r, rec = _read(tmp_path, "--exclude-states", tmp_path / "x.txt")
    assert r.returncode == 3
    one = rec["results"][0]
    assert one["status"] == "conditional" and one["excluded"] == ["b120:P/s1/routed_reset (reference)"]
    assert rec["reference_exclusions"]["states"] == ["b120|P/s1/routed_reset"]


def _mech(mini, tmp_path, man, *extra):
    r = _tool(ROOT / "audit_v5/tools/mechanism_diagnostics.py", tmp_path / "copy", tmp_path / "x", "--manifest", man,
              "--strict", *extra)
    return r, json.loads((tmp_path / "x_coverage.json").read_text())


@pytest.mark.parametrize("damage", ["no_mechanism_forks", "expect_two", "drop_path", "no_update", "only_end"])
def test_the_mechanism_design_cannot_shrink(mini, tmp_path, damage):
    from cop.config import run_id
    shutil.copytree(mini["root"] / "runs", tmp_path / "copy" / "runs")
    ents = [json.loads(ln) for ln in open(mini["man"])]
    man = tmp_path / "m.jsonl"
    keep = ents
    if damage == "no_mechanism_forks":
        keep = [e for e in ents if not str((e["cfg"].get("dissipation") or {}).get("method", "")).startswith(
            ("keep_swap", "keep_shift"))]
    man.write_text("".join(json.dumps(e) + "\n" for e in keep))
    cn = next(c for c in mini["cf"] if (c.get("design") or {}).get("arm") == "routed_shift100" and
              c["design"]["variant"] == "A_routed_affine@snap_10")
    rd = tmp_path / "copy" / "runs" / run_id(cn) / "ckpt"
    paths = sorted(rd.glob("path_u*.pt"))
    if damage == "drop_path":
        paths[1].unlink()
    elif damage == "no_update":
        ck = torch.load(paths[0], weights_only=False)
        ck["extra"].pop("update", None)
        torch.save(ck, paths[0])
    elif damage == "only_end":
        for p in paths:
            p.unlink()
    r, c = _mech(mini, tmp_path, man, *(["--expect-f0", "2"] if damage == "expect_two" else []))
    assert r.returncode == 1 and not c["passed"], c
    assert c["gradient_rows"] == 0 or damage == "expect_two"
    if damage == "no_mechanism_forks":
        assert c["expected_f0"] == 1 and "continuations missing" in c["failed"][0]["reason"]


def test_the_reference_adamw_continues_a_real_saved_optimizer_state(mini):
    from cop.experiments.dissipation import retained_mask_ctx
    from cop.graph.graph import GraphNet
    from cop.train.trainer import Segment, Trainer
    import selective_reversal as SR
    root = mini["root"]
    tcfg = next(c for c in mini["cf"] if c["kind"] == "trajectory" and
                (c.get("growth") or {}).get("spec_partition") == "random_matched")
    from cop.config import run_id
    tid = run_id(tcfg)
    ck = torch.load(root / "runs" / tid / "ckpt" / "snap_10.pt", weights_only=False)
    saved_t = copy.deepcopy(ck["trainer"])                          # load_state_dict shares the step tensors
    steps = {int(float(v["step"])) for v in saved_t["opt"]["state"].values()}
    assert len(steps) > 1                                          # tensors of different ages
    b = SR.load_bundle(tcfg["data"], None, device="cpu")
    mem = torch.load(root / "runs" / tid / "spec_partition.pt", weights_only=False)
    ctx = retained_mask_ctx(b, mem.long(), tcfg["growth"])
    g = GraphNet.from_checkpoint(ck["model"], "cpu").double()
    g._plan = None
    tc = {**tcfg["train"], "precision": "fp64"}
    tr = Trainer(g, b, tc, {"minibatch": 0, "augmentation": 0}, "cpu")
    tr.configure("none", None, reset_state=True)
    assert list(tr.opt_param_names) == list(saved_t["opt_param_names"])
    tr.opt.load_state_dict(copy.deepcopy(saved_t["opt"]))
    idx = torch.randperm(len(b.train), generator=torch.Generator().manual_seed(3))[:64]
    bt = b.train.index(idx)
    tr.next_batch = lambda: bt
    names = list(tr.opt_param_names)
    flat = [p for gp in tr.opt.param_groups for p in gp["params"]]
    before = {n: p.detach().clone() for n, p in zip(names, flat)}
    tr.run(Segment("next", 1, batch_ctx=ctx, freeze_inputs=tc.get("freeze_inputs")))
    ref = R.RefNet.from_model_dict(g.checkpoint())
    ref.P.update({n: before[n].clone() for n in names})
    first = f"{ref.first_layer()}.weight"
    hold = None
    if tc.get("freeze_inputs") == "shortcut":
        hold = (first, [int(b.meta["feature_layout"]["shortcut"])])
    opt = R.RefAdamW.from_saved(ref.P, saved_t, hold=hold)
    a = mem[idx].double()
    _, gr, _ = R.grads_of(ref, bt.X["x"].double(), bt.y, {"spec_a": a, "spec_b": 1 - a})
    opt.step(gr)
    for n, p in zip(names, flat):
        st = tr.opt.state[p]
        assert int(float(st["step"])) == opt.t[n], n
        assert R.rel(p.detach(), opt.P[n]) < 1e-9 and R.rel(st["exp_avg"], opt.m[n]) < 1e-9, n


def test_junit_requires_the_named_cases(tmp_path):
    x = tmp_path / "j.xml"
    x.write_text('<testsuites><testsuite tests="3" skipped="0" failures="0" errors="0">'
                 '<testcase name="test_cuda_float32_against_the_float64_reference[mlp]"/>'
                 '<testcase name="test_cuda_float32_against_the_float64_reference[cnn]"><skipped/></testcase>'
                 '<testcase name="other"/></testsuite></testsuites>')
    j = ROOT / "scripts/junit_ran.py"
    assert _tool(j, x, 1, "--require", "test_cuda_float32_against_the_float64_reference:1").returncode == 0
    assert _tool(j, x, 1, "--require", "test_cuda_float32_against_the_float64_reference:2").returncode == 1


def test_a_symlinked_view_path_is_refused(tmp_path):
    src = tmp_path / "panel"
    (src / "runs" / "r1").mkdir(parents=True)
    man = tmp_path / "m.jsonl"
    man.write_text(json.dumps({"run_id": "r1", "cfg": {}}) + "\n")
    v = tmp_path / "v"
    assert _tool(ROOT / "scripts/make_view.py", v, tmp_path / "vm", tmp_path / "v.json", "--source", src,
                 man).returncode == 0
    link = tmp_path / "alias"
    os.symlink(v, link)
    before = sorted(p.name for p in (v / "runs").iterdir())
    assert _tool(ROOT / "scripts/make_view.py", link, tmp_path / "vm2", tmp_path / "v2.json", "--source", src,
                 man).returncode == 1
    assert sorted(p.name for p in (v / "runs").iterdir()) == before and link.is_symlink()
