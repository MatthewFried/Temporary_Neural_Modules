"""v69: the re-analysis launcher (scripts/69) in the v48 launcher test's mock COP_HOME.  The reference preflight on
v67's states tables runs before the analyses and stops them when it fails (FORCE=1 continues); the final reference's
failed states reach each registry as exclusions; an incomplete or missing reference, a failed mech31, CUDA reference
tests that did not run by name, and failed source prerequisites make exactly the registries that read that evidence
diagnostic.  Packaging always runs; its exit code is not the scientific outcome."""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import test_v48_launcher as L  # noqa: E402
import test_v68_launcher as L68  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = "69_v69_reanalysis.sh"
SRC = (ROOT / "scripts" / SCRIPT).read_text()
FILES = {k: re.search(rf'^{k}="([^"]+)"', SRC, re.M).group(1).split(",") for k in ("IMG_FILES", "FORK_FILES",
                                                                                     "MECH_FILES", "REF_FILES")}
NAMES = {"fork29": "FORK_FILES", "image30": "IMG_FILES", "fork31": "FORK_FILES", "mech31": "MECH_FILES",
         **{r: "REF_FILES" for r in ("ref29", "ref30", "ref31", "pre_ref29", "pre_ref30", "pre_ref31")}}
TOOL = r"""import json, os, sys
panel, prefix = sys.argv[1], sys.argv[2]
name = os.path.basename(prefix)
base = name.replace("pre_", "")
want = {"fork29": "results/view29", "image30": "results/view30", "fork31": "cop_results_v65/panel31",
        "mech31": "cop_results_v65/panel31", "ref29": "results/view29", "ref30": "results/view30",
        "ref31": "cop_results_v65/panel31"}[base]
assert panel.endswith(want) and prefix.endswith("v69_reports/" + name), sys.argv
if base.startswith("ref"):
    st = sys.argv[sys.argv.index("--states") + 1]
    sf = sys.argv[sys.argv.index("--select-from") + 1]
    assert sf.endswith({"ref29": "fork29", "ref30": "image30", "ref31": "fork31"}[base] + "_states.csv")
    assert "cop_results_v66/v66_reports/" in sf                       # the selection is v67's
    if name.startswith("pre_"):
        assert "--no-table" in sys.argv and "cop_results_v66/v66_reports/" in st
    else:
        assert "--no-table" not in sys.argv and "v69_reports/" in st
    assert sys.argv[sys.argv.index("--cases") + 1] == ("mechanism" if base == "ref31" else "standard")
if name == "mech31":
    assert sys.argv[sys.argv.index("--expect-f0") + 1] == "24"
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write(name + " read " + panel + "\n")
rc = int(os.environ.get("MOCK_RC_" + name, "0"))
if os.environ.get("MOCK_NOOUT_" + name):
    sys.exit(1)
for t in os.environ["MOCK_FILES_" + name].split(","):
    if t == "validity.csv":
        continue
    if t == "coverage.json":
        json.dump({"passed": rc == 0, "complete": rc in (0, 4)}, open(prefix + "_" + t, "w"))
    elif t.endswith(".json"):
        json.dump({"cases": []}, open(prefix + "_" + t, "w"))
    else:
        open(prefix + "_" + t, "w").write("variant,x\nB,1\n")
if base.startswith("ref"):
    open(prefix + "_failed_states.txt", "w").write("b0|A_routed_affine/snap_1000/folded_reset\n" if rc == 4 else "")
sys.exit(rc)
"""
REGISTRY = r"""import json, os, sys
a = sys.argv[1:]
pf = [a[i + 1] for i, x in enumerate(a) if x == "--prerequisite-failed"]
ex = [os.path.basename(a[i + 1]) for i, x in enumerate(a) if x == "--exclude-states"]
for k in ("--coverage", "--manifest", "--audits", "--states"):
    assert k in a, (k, a)
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write(
    "registry " + os.path.basename(a[0]) + " PF " + json.dumps(pf) + " EX " + json.dumps(ex) + "\n")
json.dump({"results": [{"key": "k", "status": "diagnostic" if pf else "validated", "reading": "inconclusive"}]},
          open(a[2] + ".json", "w"))
open(a[2] + ".csv", "w").write("key\nk\n")
sys.exit(3 if pf else 0)
"""
PYTEST = r'''#!/usr/bin/env bash
echo "pytest $*" >> "$MOCK_HOME/events.txt"
xml=""; prev=""; cuda=0
for a in "$@"; do [ "$prev" = "--junitxml" ] && xml="$a"; [ "$a" = "cuda or gpu_equivalence" ] && cuda=1; prev="$a"; done
cases='<testcase name="test_other"/>'
if [ "$cuda" = 1 ] && [ -z "${MOCK_CUDA_NO_NAMED:-}" ]; then
  for p in mlp-False-0.0 mlp-True-0.01 cnn-False-0.0 cnn-True-0.01; do
    cases="$cases<testcase name=\"test_cuda_float32_against_the_float64_reference[$p]\"/>"
  done
fi
[ -n "$xml" ] && echo "<testsuites><testsuite tests=\"5\" skipped=\"0\" failures=\"0\" errors=\"0\">$cases</testsuite></testsuites>" > "$xml"
if [ "$cuda" = 1 ]; then exit "${MOCK_CUDA_TEST_RC:-0}"; fi
exit "${MOCK_TEST_RC:-0}"
'''


@pytest.fixture
def h(tmp_path):
    home = tmp_path / "home"
    (home / "scripts").mkdir(parents=True)
    shutil.copy2(ROOT / "scripts" / SCRIPT, home / "scripts" / SCRIPT)
    for f in ("package_reports.py", "check_evidence.py", "junit_ran.py", "prereq_status.py", "compare_registries.py"):
        shutil.copy2(ROOT / "scripts" / f, home / "scripts" / f)
    for f, body in (("check_image_data.py", L68.SIMPLE), ("replication_registry.py", REGISTRY),
                    ("make_view.py", L68.VIEW), ("validity_table.py", L68.VALIDITY)):
        (home / "scripts" / f).write_text(body)
    (home / "scripts/common.sh").write_text(L68.COMMON)
    (home / "audit_v5/tools").mkdir(parents=True)
    for name in ("image_forks.py", "fork_continuation.py", "mechanism_diagnostics.py", "reference_recompute.py"):
        (home / "audit_v5/tools" / name).write_text(TOOL)
    (home / "configs").mkdir()
    for f in ("v66_wave29_registry.json", "v66_image_registry.json", "v66_mechanism_registry.json"):
        shutil.copy2(ROOT / "configs" / f, home / "configs" / f)
    pt = home / "fake_pytest.sh"
    pt.write_text(PYTEST)
    pt.chmod(0o755)
    zipdir = tmp_path / "zips"
    zipdir.mkdir()
    for d, panels, steps, rdir, regs in (("cop_results_v64", ["panel29"], L68.V64, "v64_reports", ["registry29"]),
                                         ("cop_results_v65", ["panel30", "panel31"], L68.V65, "v65_reports",
                                          ["registry30", "registry31"]),
                                         ("cop_results_v66", ["panel32"], L68.V67, "v66_reports",
                                          ["registry29", "registry30", "registry31"])):
        for p in panels:
            (tmp_path / d / p).mkdir(parents=True)
        (tmp_path / d / rdir).mkdir()
        (tmp_path / d / rdir / "verdict.json").write_text(json.dumps({"steps": steps}))
        for r in regs:
            (tmp_path / d / rdir / f"{r}.json").write_text(json.dumps({"results": [
                {"key": "k", "reading": "replicated", "mean_favourable": 0.1}]}))
    for t in ("fork29_states.csv", "image30_states.csv", "fork31_states.csv", "fork31_audits.csv"):
        (tmp_path / "cop_results_v66" / "v66_reports" / t).write_text("f0,x\nb,1\n")
    base = {k: v for k, v in os.environ.items() if k not in ("COP_PYTEST", "V64_RESULTS", "V65_RESULTS",
                                                             "V67_RESULTS", "FORCE")}
    env = dict(base, MOCK_HOME=str(home), COP_RESULTS=str(tmp_path / "results"), ZIP_DIR=str(zipdir), SCALE="full",
               HOME=str(tmp_path), COP_PYTEST=str(pt),
               **{f"MOCK_FILES_{n}": ",".join(FILES[k]) for n, k in NAMES.items()})
    return {"home": home, "res": tmp_path / "results", "zip": zipdir / "cop_v69_reanalysis_reports.zip", "env": env,
            "tmp": tmp_path}


def _sh(h, **env):
    e = dict(h["env"], **{k: str(v) for k, v in env.items()})
    return subprocess.run(["bash", str(h["home"] / "scripts" / SCRIPT)], env=e, capture_output=True, text=True,
                          cwd=str(h["home"]))


def _events(h):
    p = h["home"] / "events.txt"
    return p.read_text() if p.exists() else ""


def _reg(h):
    out = {}
    for ln in _events(h).splitlines():
        if ln.startswith("registry "):
            name = ln.split()[1]
            pf = json.loads(ln.split(" PF ", 1)[1].split(" EX ", 1)[0])
            ex = json.loads(ln.split(" EX ", 1)[1])
            out[name] = (pf, ex)
    return out


def _verdict(h):
    return json.loads((h["res"] / "v69_reports/verdict.json").read_text())


def test_preflight_then_analyses_then_the_reference_and_exclusions(h):
    r = _sh(h)
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-3000:]
    ev = _events(h)
    lines = ev.splitlines()
    order = [next(i for i, x in enumerate(lines) if x.startswith(f"{n} read "))
             for n in ("pre_ref29", "pre_ref30", "pre_ref31", "fork29", "image30", "fork31", "mech31", "ref29",
                       "ref30", "ref31")]
    assert order == sorted(order)
    assert not any(x.startswith("cop run") for x in ev.splitlines())
    reg = _reg(h)
    assert reg["v66_wave29_registry.json"] == ([], ["ref29_failed_states.txt"])
    assert reg["v66_image_registry.json"] == ([], ["ref30_failed_states.txt"])
    assert reg["v66_mechanism_registry.json"] == ([], ["ref29_failed_states.txt", "ref31_failed_states.txt"])
    names = zipfile.ZipFile(h["zip"]).namelist()
    for f in ("pre_ref30_plan.json", "ref31_failed_states.txt", "ref29_rows.csv", "registry31.json"):
        assert f"cop_v69_reanalysis_reports/v69_reports/{f}" in names, f


@pytest.mark.parametrize("rc", [1, 4])
def test_a_failed_preflight_stops_the_analyses_but_packages(h, rc):
    r = _sh(h, MOCK_RC_pre_ref30=rc)
    assert r.returncode == 1
    ev = _events(h)
    assert "pre_ref31 read" in ev and "\nfork29 read" not in ev and "registry " not in ev
    assert h["zip"].exists() and _verdict(h)["steps"]["fork29"] == 99


def test_force_runs_the_analyses_after_a_failed_preflight(h):
    _sh(h, MOCK_RC_pre_ref30=4, FORCE=1)
    assert "\nfork29 read" in _events(h) and "registry " in _events(h)


def test_missing_v67_tables_stop_the_analyses(h):
    (h["tmp"] / "cop_results_v66" / "v66_reports" / "image30_states.csv").unlink()
    r = _sh(h)
    assert r.returncode == 1 and "\nfork29 read" not in _events(h)


def test_a_reference_with_failed_rows_excludes_and_does_not_label(h):
    _sh(h, MOCK_RC_ref30=4)
    reg = _reg(h)
    assert reg["v66_image_registry.json"] == ([], ["ref30_failed_states.txt"])
    assert (h["res"] / "v69_reports/ref30_failed_states.txt").read_text().strip()


@pytest.mark.parametrize("env, flag, regs", [
    ({"MOCK_RC_ref30": 1}, "v69:ref30_complete (1)", {"v66_image_registry.json"}),
    ({"MOCK_NOOUT_ref30": 1}, "v69:ref30_complete (1)", {"v66_image_registry.json"}),
    ({"MOCK_RC_ref29": 1}, "v69:ref29_complete (1)", {"v66_wave29_registry.json", "v66_mechanism_registry.json"}),
    ({"MOCK_RC_ref31": 1}, "v69:ref31_complete (1)", {"v66_mechanism_registry.json"}),
    ({"MOCK_RC_mech31": 1}, "v69:mech31 (1)", {"v66_mechanism_registry.json"}),
    ({"MOCK_DEVICE": "cuda", "MOCK_CUDA_NO_NAMED": 1}, "v69:cuda_tests_ran (1)",
     {"v66_wave29_registry.json", "v66_image_registry.json", "v66_mechanism_registry.json"})])
def test_incomplete_evidence_labels_exactly_the_registries_that_read_it(h, env, flag, regs):
    r = _sh(h, **env)
    assert r.returncode == 1
    reg = _reg(h)
    assert set(reg) == {"v66_wave29_registry.json", "v66_image_registry.json", "v66_mechanism_registry.json"}
    for k, (pf, _) in reg.items():
        assert (flag in pf) == (k in regs), (k, pf)


def test_named_cuda_reference_tests_pass_the_cuda_gate(h):
    r = _sh(h, MOCK_DEVICE="cuda")
    assert r.returncode == 0, r.stdout[-2000:]
    assert all(pf == [] for pf, _ in _reg(h).values())
