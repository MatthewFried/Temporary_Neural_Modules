"""v70 (CHANGES_v70.md).

  rounding bound     the first-order float32 bound holds on random networks (MLP and CNN, several seeds) and on an
                     ill-conditioned shift edit (I + M/2 nearly singular), on the CPU and (CUDA tests, required by
                     name) on the GPU; it scales with the conditioning; logits moved by twice the bound, a decided
                     example that flips, or too many differing ties fail
  reference          on the waves 31 + 32 miniature with --n-f0 all every row passes; v69's fixed tolerance is reported;
                     --n-f0 is validated; more f0 than the design has fail
  registry           every hypothesis value is recomputed from the states table and must equal the contrasts value: a
                     tampered contrasts value or states value makes the hypothesis incomplete; the rules reproduce every
                     contrast of the three miniature analyses exactly
  retrain            a sample of the miniature retrained from scratch reproduces the saved runs value by value; a saved
                     tensor changed by one unit in the last place, a missing checkpoint or a changed record is found
  reuse of v69       taken only when every code file is the same byte for byte (apart from v70's declared changes), v69
                     finished and the analysis completed"""
from __future__ import annotations

import copy
import csv
import json
import math
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(ROOT / "audit_v5" / "tools"))
sys.path.insert(0, str(ROOT / "scripts"))
import reference_impl as R  # noqa: E402
import reference_recompute as RC  # noqa: E402
import replication_registry as RR  # noqa: E402
import retrain_sample as RS  # noqa: E402
import reuse_v69 as RU  # noqa: E402
from test_v68 import _case, _read, _rows, _tool, _write  # noqa: E402,F401
from test_v68_reference import _net  # noqa: E402
from test_v69 import mini  # noqa: E402,F401  (the waves 31 + 32 miniature fixture)
from cop.graph.redistribute import shift_to_receiver  # noqa: E402
from cop.train.trainer import predict  # noqa: E402


# ----------------------------------------------------------------------------- the rounding bound

def _ill(fam, lam, seed=0):
    """a network whose merge map is M = -lam v v^T (one branch; the others zero), shifted by t = 0.5 into the receiving
    layer: W (I + M)(I + M/2)^-1 has the factor 1 / (1 - lam/2) along v.  float64 edit, stored in float32."""
    b, g, G = _net(fam, 2, seed=seed)
    ref = R.RefNet.from_model_dict(g.checkpoint())
    d = ref.P[f"{ref.branches[0]['A']}.weight"].shape[1]
    v = torch.randn(d, generator=torch.Generator().manual_seed(seed + 5), dtype=torch.float64)
    v = v / v.norm()
    with torch.no_grad():
        for k, br in enumerate(ref.branches):
            A, B = g.mods[br["A"]], g.mods[br["B"]]
            for p in (A.weight, A.bias, B.weight, B.bias):
                p.zero_()
            if k == 0:
                A.weight[0] = v
                B.weight[:, 0] = -lam * v
    gh = copy.deepcopy(g)
    shift_to_receiver(gh, 0.5)
    gh = gh.float()
    gh._plan = None
    return b, gh


def _bound_case(g32, part, dev="cpu"):
    ref = R.RefNet.from_model_dict(g32.checkpoint())
    x = part.X["x"].double()
    zr = R.predictions(ref, x)
    E = R.rounding_bounds(ref, x).clamp(min=1e-300)          # a logit no rounding reaches is exact (0 / 0)
    g = copy.deepcopy(g32).to(dev)
    g._plan = None
    with torch.no_grad():
        z32 = predict(g.eval(), part.to(dev) if dev != "cpu" else part, 4096).double().cpu()
    return zr, z32, E


@pytest.mark.parametrize("fam", ["mlp", "cnn"])
@pytest.mark.parametrize("seed", [0, 1, 2])
def test_the_rounding_bound_holds_on_random_networks(fam, seed):
    b, g, G = _net(fam, 2, dtype=torch.float32, seed=seed)
    zr, z32, E = _bound_case(g, b.partitions()["test"])
    ratio = (z32 - zr).abs() / E
    assert float(ratio.max()) <= 1.0, float(ratio.max())
    assert float((E / (1 + zr.abs())).max()) < 1e-2          # informative: far below the logits
    assert RC.decisions(zr, z32, b.partitions()["test"].y, E)["ok"]


@pytest.mark.parametrize("fam", ["mlp", "cnn"])
def test_the_rounding_bound_follows_the_conditioning(fam):
    out = {}
    for lam in (1.0, 1.99, 1.9999):
        b, g = _ill(fam, lam)
        zr, z32, E = _bound_case(g, b.partitions()["test"])
        assert float(((z32 - zr).abs() / E).max()) <= 1.0, lam
        out[lam] = (float((E / (1 + zr.abs())).max()), float(((z32 - zr).abs() / (1e-4 + 1e-4 * zr.abs())).max()))
    assert out[1.9999][0] > 50 * out[1.0][0]                 # the bound grows with 1 / (1 - lam / 2)
    assert out[1.9999][1] > out[1.0][1]                      # and so does the actual float32 error


def test_decisions_against_the_bound():
    y = torch.tensor([0, 1, 0, 1])
    zr = torch.tensor([[1.0, 0.0], [0.0, 1.0], [2.0, 0.0], [5.0, 0.0]], dtype=torch.float64)
    E = torch.full_like(zr, 0.01)
    assert RC.decisions(zr, zr + 0.009, y, E)["ok"]
    over = zr.clone()
    over[2, 1] += 0.02                                       # twice the bound on one logit
    d = RC.decisions(zr, over, y, E)
    assert not d["ok"] and d["violations"] == 1 and d["disagree"] == 0
    flip = zr.clone()
    flip[0] = torch.tensor([0.0, 1.0], dtype=torch.float64)
    d = RC.decisions(zr, flip, y, torch.full_like(zr, 10.0))  # within a huge bound, but example 0 is then undecided
    assert d["undecided"] == 4 and d["disagree_decided"] == 0 and not d["ok"]   # 1 of 4 differing ties > 0.1%
    Et = E.clone()
    Et[0] = 0.6                                              # example 0: margin 1 < 0.6 + 0.6: undecided
    d = RC.decisions(zr, zr, y, Et)
    assert d["undecided"] == 1 and d["ok"]
    big = torch.zeros(4000, 2, dtype=torch.float64)
    big[:, 0] = 1.0
    big[0] = torch.tensor([0.5, 0.5], dtype=torch.float64)
    big2 = big.clone()
    big2[0, 1] += 1e-6
    u = RC.decisions(big, big2, torch.zeros(4000, dtype=torch.long), torch.full_like(big, 1e-5))
    assert u["ok"] and u["disagree"] == 1 and u["disagree_undecided"] == 1      # one tie in 4000 may differ
    dd = RC.decisions(zr, flip, y, E)
    assert dd["disagree_decided"] == 1 and not dd["ok"]


def _cuda_bound(fam, dev):
    tf = (torch.backends.cuda.matmul.allow_tf32, torch.backends.cudnn.allow_tf32)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    try:
        for seed in (0, 1):
            b, g, G = _net(fam, 2, dtype=torch.float32, seed=seed)
            zr, z32, E = _bound_case(g, b.partitions()["test"], dev)
            assert float(((z32 - zr).abs() / E).max()) <= 1.0, (seed, float(((z32 - zr).abs() / E).max()))
        b, g = _ill(fam, 1.999)
        zr, z32, E = _bound_case(g, b.partitions()["test"], dev)
        assert float(((z32 - zr).abs() / E).max()) <= 1.0
    finally:
        torch.backends.cuda.matmul.allow_tf32, torch.backends.cudnn.allow_tf32 = tf


@pytest.mark.skipif(not torch.cuda.is_available(), reason="needs CUDA")
@pytest.mark.parametrize("fam", ["mlp", "cnn"])
def test_cuda_float32_within_the_rounding_bound(fam):
    _cuda_bound(fam, os.environ.get("COP_TEST_CUDA_DEVICE", "cuda"))


# ----------------------------------------------------------------------------- the reference on the miniature

def _ref(mini, out, *extra, cases="standard"):
    root = mini["root"]
    return RC.main([str(root), str(out), "--manifest", str(mini["man"]), "--states", str(root / "fork31_states.csv"),
                    "--cases", cases, "--audits", str(root / "fork31_audits.csv"), *map(str, extra)])


@pytest.mark.parametrize("cases", ["standard", "mechanism"])
def test_the_reference_passes_every_f0_of_the_miniature(mini, tmp_path, cases):
    assert _ref(mini, tmp_path / "r", "--n-f0", "all", cases=cases) == 0
    c = json.loads((tmp_path / "r_coverage.json").read_text())
    assert c["schema"] == "reference_recompute/v70" and c["complete"] and c["passed"] and c["n_f0"] == "all"
    rows = [r for r in _rows(tmp_path / "r_rows.csv") if r.get("deployed_worst")]
    assert rows and all(float(r["deployed_worst"]) <= 1.0 for r in rows)
    assert all(r["fixed1e4_worst"] not in ("", None) and r["exact_wrong"] not in ("", None) for r in rows)


def test_the_number_of_f0_is_checked(mini, tmp_path):
    for bad in ("0", "x", "-1"):
        assert _ref(mini, tmp_path / "r", "--n-f0", bad) == 2
    assert _ref(mini, tmp_path / "r", "--n-f0", "3") == 1      # the miniature has one f0
    assert not json.loads((tmp_path / "r_coverage.json").read_text())["complete"]


def test_logits_outside_the_bound_fail_the_reference(mini, tmp_path, monkeypatch):
    real = RC.predict

    def nudge(model, part, batch=4096, dtype=None):
        z = real(model, part, batch, dtype)
        if z.dtype == torch.float32:                          # the deployed evaluation only
            z = z.clone()
            z[0, 0] += 1e-3 * (1 + float(z[0, 0].abs()))
        return z
    monkeypatch.setattr(RC, "predict", nudge)
    assert _ref(mini, tmp_path / "r", "--n-f0", "1") == 4
    rows = [r for r in _rows(tmp_path / "r_rows.csv") if r.get("deployed_ok")]
    assert all(r["deployed_ok"] == "False" and r["function64_ok"] == "True" for r in rows)


# ----------------------------------------------------------------------------- the registry recomputes

def _all_contrasts_recompute(con, st):
    S = {(r["f0"], r["parent"], r["fork"], r["state"]): r for r in csv.DictReader(open(st))}
    n = bad = 0
    for r in csv.DictReader(open(con)):
        h = {k: r[k] for k in ("comparison", "parent", "fork", "first", "second", "metric")}
        v, why = RR.recompute(h, r["f0"], S)
        n += 1
        bad += bool(why) or v != float(r["value"])
    return n, bad


def test_the_rules_reproduce_every_contrast_of_the_miniature(mini):
    n, bad = _all_contrasts_recompute(mini["root"] / "fork31_contrasts.csv", mini["root"] / "fork31_states.csv")
    assert n > 1000 and bad == 0
    comps = {r["comparison"] for r in csv.DictReader(open(mini["root"] / "fork31_contrasts.csv"))}
    assert {"swap_interaction", "shift100_interaction", "minus_f0", "continuation_minus_start",
            "routed_minus_ordinary"} <= comps


def _rebind(t, name):
    """the analysis's recorded digest of a table changed after the fact (so only the recomputation can notice)."""
    import hashlib
    cov = json.loads((t / "cov.json").read_text())
    f = {"contrasts.csv": "c.csv", "states.csv": "s.csv"}[name]
    cov["outputs_sha256"][name] = hashlib.sha256((t / f).read_bytes()).hexdigest()
    (t / "cov.json").write_text(json.dumps(cov))


@pytest.mark.parametrize("where", ["contrasts", "states"])
def test_a_value_that_differs_from_the_states_table_is_not_read(tmp_path, where):
    def tamper(t):
        f, col = ("c.csv", "value") if where == "contrasts" else ("s.csv", "m")
        rows = list(csv.DictReader(open(t / f)))
        i = next(k for k, r in enumerate(rows) if r.get(col) not in ("", None) and
                 (where == "contrasts" and r["metric"] == "m" or where == "states" and r["state"] == "routed_reset"))
        rows[i][col] = repr(float(rows[i][col]) + 1e-12)
        _write(t / f, list(rows[0]), rows)
        _rebind(t, "contrasts.csv" if where == "contrasts" else "states.csv")
    _case(tmp_path, after=tamper)
    r, rec = _read(tmp_path)
    assert r.returncode == 1, r.stdout + r.stderr
    one = rec["results"][0]
    assert one["status"] == "incomplete" and "differs from the states table" in one["reading"], one
    assert rec["results"][1]["status"] == "validated"


def test_a_comparison_without_a_rule_is_not_read(tmp_path):
    _case(tmp_path)
    reg = json.loads((tmp_path / "reg.json").read_text())
    reg["hypotheses"][1]["comparison"] = "something_new"
    (tmp_path / "reg.json").write_text(json.dumps(reg))
    rows = list(csv.DictReader(open(tmp_path / "c.csv")))
    for r in rows:
        if r["metric"] == "n":
            r["comparison"] = "something_new"
    _write(tmp_path / "c.csv", list(rows[0]), rows)
    _rebind(tmp_path, "contrasts.csv")
    r, rec = _read(tmp_path)
    assert rec["results"][1]["status"] == "incomplete" and "no independent rule" in rec["results"][1]["reading"]


# ----------------------------------------------------------------------------- retrain and compare

def test_the_comparison_is_value_by_value():
    a = {"model": {"state": {"w": torch.tensor([1.0, 2.0])}, "spec": {"n": 1}}, "lineage": {"code_hash": "x"},
         "trainer": {"step": 3, "timing": 1.5}}
    b = copy.deepcopy(a)
    b["lineage"]["code_hash"] = "y"                           # excluded
    b["trainer"]["timing"] = 9.0                              # wall clock: excluded
    assert RS.diff(a, b) == []
    c = copy.deepcopy(a)
    c["model"]["state"]["w"][1] = torch.nextafter(torch.tensor(2.0), torch.tensor(3.0))
    d = RS.diff(a, c)
    assert d and d[0]["at"] == "model/state/w" and d[0]["differing"] == 1 and 0 < d[0]["max_abs_diff"] < 1e-6
    e = copy.deepcopy(a)
    e["trainer"]["step"] = 4
    assert RS.diff(a, e)[0]["at"] == "trainer/step"
    f = copy.deepcopy(a)
    f["model"]["state"]["w"] = f["model"]["state"]["w"].double()
    assert "float64" in RS.diff(a, f)[0]["what"]


def test_a_retrained_sample_reproduces_the_miniature(mini, tmp_path):
    root, man = mini["root"], mini["man"]
    import fork_continuation as FC
    lines = [json.loads(ln) for ln in open(man) if ln.strip()]
    jobs = FC.fork_jobs({e["run_id"]: e["cfg"] for e in lines})
    f0 = sorted(jobs)[0]
    sub = tmp_path / "sub.jsonl"
    states = "A_routed_affine/snap_10/routed_shift50,A_routed_affine/snap_10/routed_reset"
    assert RS.main(["select", str(man), str(sub), "--f0", f0, "--states", states]) == 0
    kinds = [json.loads(ln)["cfg"]["kind"] for ln in open(sub)]
    assert kinds.count("dissipation") == 2 and "trajectory" in kinds and "baseline" in kinds
    assert RS.main(["select", str(man), str(tmp_path / "s2.jsonl"), "--f0", f0, "--states",
                    "A_routed_affine/snap_10/nonexistent"]) == 1
    scratch = tmp_path / "scratch"
    r = subprocess.run([sys.executable, "-m", "cop.cli", "run", "--manifest", str(sub), "--results", str(scratch),
                        "--device", "cpu", "--data-root", str(root), "--workers", "1", "--threads", "1"],
                       capture_output=True, text=True, cwd=str(ROOT),
                       env={**os.environ, "PYTHONPATH": str(ROOT), "CUDA_VISIBLE_DEVICES": ""})
    assert r.returncode == 0, r.stdout[-2000:] + r.stderr[-2000:]
    assert RS.compare(str(sub), root, scratch, tmp_path / "c.json") == 0
    rec = json.loads((tmp_path / "c.json").read_text())
    assert rec["reproduced"] and rec["n_checkpoints_compared"] > 5
    # one saved tensor one unit in the last place off, in a copy of the panel
    panel = tmp_path / "panel"
    for ln in open(sub):
        rid = json.loads(ln)["run_id"]
        shutil.copytree(root / "runs" / rid, panel / "runs" / rid)
    rid = json.loads(open(sub).readlines()[-1])["run_id"]
    ckp = sorted((panel / "runs" / rid / "ckpt").glob("*.pt"))[-1]
    ck = torch.load(ckp, weights_only=False)
    k0 = next(k for k, v in ck["model"]["state"].items() if v.is_floating_point() and v.numel())
    t = ck["model"]["state"][k0].reshape(-1)
    t[0] = torch.nextafter(t[0], t[0] + 1)
    torch.save(ck, ckp)
    assert RS.compare(str(sub), panel, scratch, tmp_path / "c2.json") == 1
    d = json.loads((tmp_path / "c2.json").read_text())["jobs"][rid]["differing"][ckp.name]
    assert d[0]["at"] == f"model/state/{k0}" and d[0]["differing"] == 1
    ckp.unlink()
    assert RS.compare(str(sub), panel, scratch, tmp_path / "c3.json") == 1
    assert json.loads((tmp_path / "c3.json").read_text())["jobs"][rid]["only_retrained"] == [ckp.name]


# ----------------------------------------------------------------------------- reuse of v69's analyses

def _trees(tmp):
    a, b = tmp / "c69", tmp / "c70"
    for t in (a, b):
        (t / "cop").mkdir(parents=True)
        (t / "cop" / "x.py").write_text("x = 1\n")
        (t / "audit_v5/tools").mkdir(parents=True)
        (t / "audit_v5/tools/fork_continuation.py").write_text("y = 2\n")
    (b / "audit_v5/tools/reference_recompute.py").write_text("changed on purpose\n")
    (b / "tests").mkdir()
    (b / "tests/test_new.py").write_text("")
    rep = tmp / "rep"
    rep.mkdir()
    for f in ("view29.json", "view29_manifest.jsonl", "fork29_states.csv", "view30.json", "view30_manifest.jsonl",
              "image30_states.csv", "wave31_full.jsonl", "fork31_states.csv", "mech31_gradients.csv"):
        (rep / f).write_text("x\n")
    for f in ("fork29", "image30", "fork31"):
        (rep / f"{f}_coverage.json").write_text(json.dumps({"analysis_complete": True}))
    (rep / "fork31.txt").write_text("log\n")
    os.utime(rep / "fork31.txt", (1, 1))
    for p in rep.iterdir():
        os.utime(p, (1000, 1000))
    (rep / "verdict.json").write_text(json.dumps({"steps": {"view29": 0, "fork29": 0, "view30": 0, "image30": 0,
                                                             "fork31": 1, "mech31": 0}}))
    os.utime(rep / "verdict.json", (2000, 2000))
    return a, b, rep


def test_v69_analyses_are_taken_only_when_nothing_changed(tmp_path):
    a, b, rep = _trees(tmp_path)
    out = tmp_path / "o"
    assert RU.main([str(a), str(b), str(rep), str(out)]) == 0
    assert (out / "reused_groups.txt").read_text().split() == ["29", "30", "31"]
    assert (out / "fork31_states.csv").exists() and (out / "wave31_full.jsonl").exists() and \
        (out / "fork31_v69.txt").exists()
    # a changed code file: nothing is taken
    (b / "cop" / "x.py").write_text("x = 2\n")
    out2 = tmp_path / "o2"
    RU.main([str(a), str(b), str(rep), str(out2)])
    assert (out2 / "reused_groups.txt").read_text() == "" and not (out2 / "fork29_states.csv").exists()
    rec = json.loads((out2 / "reuse_v69.json").read_text())
    assert rec["code_differences"] == ["cop/x.py: differs"]


@pytest.mark.parametrize("damage, lost", [("no_verdict", {"29", "30", "31"}), ("incomplete30", {"30"}),
                                          ("failed_view29", {"29"}), ("newer_file", {"31"}),
                                          ("new_code_file", {"29", "30", "31"})])
def test_v69_analyses_are_not_taken_when(tmp_path, damage, lost):
    a, b, rep = _trees(tmp_path)
    if damage == "no_verdict":
        (rep / "verdict.json").unlink()
    elif damage == "incomplete30":
        (rep / "image30_coverage.json").write_text(json.dumps({"analysis_complete": False}))
        os.utime(rep / "image30_coverage.json", (1000, 1000))
    elif damage == "failed_view29":
        v = json.loads((rep / "verdict.json").read_text())
        v["steps"]["view29"] = 1
        (rep / "verdict.json").write_text(json.dumps(v))
        os.utime(rep / "verdict.json", (2000, 2000))
    elif damage == "newer_file":
        os.utime(rep / "mech31_gradients.csv", (3000, 3000))
    else:
        (b / "cop" / "new.py").write_text("")
    out = tmp_path / "o"
    RU.main([str(a), str(b), str(rep), str(out)])
    got = set((out / "reused_groups.txt").read_text().split())
    assert got == {"29", "30", "31"} - lost
