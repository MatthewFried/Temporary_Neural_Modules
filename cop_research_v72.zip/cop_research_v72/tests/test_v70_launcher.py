"""v70: the re-analysis launcher (scripts/70) in the v48 launcher test's mock COP_HOME.  v69's analyses are taken when
scripts/reuse_v69.py says so (mocked here; the script itself is tested in test_v70.py) and computed otherwise; the
reference runs on every f0 (wave 30: N30) against the rounding bound; a sample is retrained and compared; a reference
that is incomplete, a sample that did not reproduce, CUDA tests that did not run by name or a failed mech31 make exactly
the registries that read that evidence diagnostic.  Packaging always runs; its exit code is not the scientific
outcome."""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import test_v68_launcher as L68  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = "70_v70_reanalysis.sh"
SRC = (ROOT / "scripts" / SCRIPT).read_text()
FILES = {k: re.search(rf'^{k}="([^"]+)"', SRC, re.M).group(1).split(",") for k in ("IMG_FILES", "FORK_FILES",
                                                                                     "MECH_FILES", "REF_FILES")}
NAMES = {"fork29": "FORK_FILES", "image30": "IMG_FILES", "fork31": "FORK_FILES", "mech31": "MECH_FILES",
         **{r: "REF_FILES" for r in ("ref29", "ref30", "ref31")}}
TOOL = r"""import json, os, sys
panel, prefix = sys.argv[1], sys.argv[2]
name = os.path.basename(prefix)
v = "cop_results_v69/" if name.replace("ref", "") in os.environ.get("MOCK_REUSE", "").split(",") else "results/"
want = {"fork29": "results/view29", "image30": "results/view30", "fork31": "cop_results_v65/panel31",
        "mech31": "cop_results_v65/panel31", "ref29": v + "view29", "ref30": v + "view30",
        "ref31": "cop_results_v65/panel31"}[name]
assert panel.endswith(want) and prefix.endswith("v70_reports/" + name), (want, sys.argv)
if name.startswith("ref"):
    a = sys.argv
    assert "--select-from" not in a and "--no-table" not in a
    assert a[a.index("--states") + 1].endswith("v70_reports/" + {"ref29": "fork29", "ref30": "image30",
                                                                   "ref31": "fork31"}[name] + "_states.csv")
    assert a[a.index("--cases") + 1] == ("mechanism" if name == "ref31" else "standard")
    assert a[a.index("--n-f0") + 1] == (os.environ.get("N30", "all") if name == "ref30" else "all")
    if name == "ref30":
        assert a[a.index("--bound-dtype") + 1] == "float32" and "--ref-device" in a
    if name == "ref31":
        m = a[a.index("--manifest") + 1]
        assert m.endswith("v70_reports/wave31_full.jsonl" if "31" in os.environ.get("MOCK_REUSE", "") else
                          "manifests/wave31_full.jsonl"), m
if name == "mech31":
    assert sys.argv[sys.argv.index("--expect-f0") + 1] == "24"
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write(name + " read " + panel + "\n")
rc = int(os.environ.get("MOCK_RC_" + name, "0"))
if os.environ.get("MOCK_NOOUT_" + name):
    sys.exit(1)
for t in os.environ["MOCK_FILES_" + name].split(","):
    if t == "validity.csv":
        continue
    if t == "coverage.json":
        json.dump({"passed": rc == 0, "complete": rc in (0, 4), "ill_conditioned": {"f0": "b9"}},
                  open(prefix + "_" + t, "w"))
    elif t == "plan.json":
        json.dump({"selection": ["b1"], "cases": []}, open(prefix + "_" + t, "w"))
    else:
        open(prefix + "_" + t, "w").write("variant,x\nB,1\n")
if name.startswith("ref"):
    open(prefix + "_failed_states.txt", "w").write("b0|A_routed_affine/snap_1000/folded_reset\n" if rc == 4 else "")
sys.exit(rc)
"""
REUSE = r"""import json, os, sys
c69, c70, rep, out = sys.argv[1:5]
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write("reuse_v69 " + rep + "\n")
groups = [g for g in os.environ.get("MOCK_REUSE", "").split(",") if g]
F = {k: os.environ["MOCK_FILES_" + k].split(",") for k in ("fork29", "image30", "fork31", "mech31")}
for g in groups:
    an = {"29": ["fork29"], "30": ["image30"], "31": ["fork31", "mech31"]}[g]
    for a in an:
        for t in F[a]:
            body = json.dumps({"passed": True, "analysis_complete": True}) if t == "coverage.json" else "variant,x\nB,1\n"
            open(os.path.join(out, a + "_" + t), "w").write(body)
        open(os.path.join(out, a + "_v69.txt"), "w").write("log\n")
    if g in ("29", "30"):
        open(os.path.join(out, "view%s_manifest.jsonl" % g), "w").write('{"run_id": "x", "cfg": {}}\n')
        json.dump({"entries": 1}, open(os.path.join(out, "view%s.json" % g), "w"))
    else:
        open(os.path.join(out, "wave31_full.jsonl"), "w").write('{"run_id": "x"}\n')
open(os.path.join(out, "reused_groups.txt"), "w").write("".join(g + "\n" for g in groups))
json.dump({"groups": groups}, open(os.path.join(out, "reuse_v69.json"), "w"))
"""
RETRAIN = r"""import json, os, sys
a = sys.argv[1:]
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write("retrain " + " ".join(a) + "\n")
if a[0] == "select":
    open(a[2], "w").write('{"run_id": "r"}\n')
    sys.exit(int(os.environ.get("MOCK_RC_retrain_select", "0")))
w = [x for x in ("29", "30", "31") if a[4].endswith("retrain" + x + ".json")][0]
json.dump({"reproduced": True}, open(a[4], "w"))
sys.exit(int(os.environ.get("MOCK_RC_retrain_compare" + w, "0")))
"""
PYTEST = r'''#!/usr/bin/env bash
echo "pytest $*" >> "$MOCK_HOME/events.txt"
xml=""; prev=""; cuda=0
for a in "$@"; do [ "$prev" = "--junitxml" ] && xml="$a"; [ "$a" = "cuda or gpu_equivalence" ] && cuda=1; prev="$a"; done
cases='<testcase name="test_other"/>'
if [ "$cuda" = 1 ]; then
  for p in mlp-False-0.0 mlp-True-0.01 cnn-False-0.0 cnn-True-0.01; do
    cases="$cases<testcase name=\"test_cuda_float32_against_the_float64_reference[$p]\"/>"
  done
  if [ -z "${MOCK_CUDA_NO_BOUND:-}" ]; then
    for p in mlp cnn; do cases="$cases<testcase name=\"test_cuda_float32_within_the_rounding_bound[$p]\"/>"; done
  fi
fi
[ -n "$xml" ] && echo "<testsuites><testsuite tests=\"7\" skipped=\"0\" failures=\"0\" errors=\"0\">$cases</testsuite></testsuites>" > "$xml"
if [ "$cuda" = 1 ]; then exit "${MOCK_CUDA_TEST_RC:-0}"; fi
exit "${MOCK_TEST_RC:-0}"
'''
REGISTRY = r"""import json, os, sys
a = sys.argv[1:]
pf = [a[i + 1] for i, x in enumerate(a) if x == "--prerequisite-failed"]
ex = [os.path.basename(a[i + 1]) for i, x in enumerate(a) if x == "--exclude-states"]
man = a[a.index("--manifest") + 1]
for k in ("--coverage", "--manifest", "--audits", "--states"):
    assert k in a, (k, a)
open(os.path.join(os.environ["MOCK_HOME"], "events.txt"), "a").write(
    "registry " + os.path.basename(a[0]) + " PF " + json.dumps(pf) + " EX " + json.dumps(ex) + " MAN " + man + "\n")
json.dump({"results": [{"key": "k", "status": "diagnostic" if pf else "validated", "reading": "inconclusive"}]},
          open(a[2] + ".json", "w"))
open(a[2] + ".csv", "w").write("key\nk\n")
sys.exit(3 if pf else 0)
"""
ALL = {"v66_wave29_registry.json", "v66_image_registry.json", "v66_mechanism_registry.json"}


@pytest.fixture
def h(tmp_path):
    home = tmp_path / "home"
    (home / "scripts").mkdir(parents=True)
    shutil.copy2(ROOT / "scripts" / SCRIPT, home / "scripts" / SCRIPT)
    for f in ("package_reports.py", "check_evidence.py", "junit_ran.py", "prereq_status.py", "compare_registries.py"):
        shutil.copy2(ROOT / "scripts" / f, home / "scripts" / f)
    for f, body in (("check_image_data.py", L68.SIMPLE), ("replication_registry.py", REGISTRY),
                    ("make_view.py", L68.VIEW), ("validity_table.py", L68.VALIDITY), ("reuse_v69.py", REUSE),
                    ("retrain_sample.py", RETRAIN)):
        (home / "scripts" / f).write_text(body)
    (home / "scripts/common.sh").write_text(L68.COMMON)
    (home / "audit_v5/tools").mkdir(parents=True)
    for name in ("image_forks.py", "fork_continuation.py", "mechanism_diagnostics.py", "reference_recompute.py"):
        (home / "audit_v5/tools" / name).write_text(TOOL)
    (home / "configs").mkdir()
    for f in ALL:
        shutil.copy2(ROOT / "configs" / f, home / "configs" / f)
    pt = home / "fake_pytest.sh"
    pt.write_text(PYTEST)
    pt.chmod(0o755)
    zipdir = tmp_path / "zips"
    zipdir.mkdir()
    for d, panels, steps, rdir, regs in (("cop_results_v64", ["panel29"], L68.V64, "v64_reports", ["registry29"]),
                                         ("cop_results_v65", ["panel30", "panel31"], L68.V65, "v65_reports",
                                          ["registry30", "registry31"]),
                                         ("cop_results_v66", ["panel32"], L68.V67, "v66_reports",
                                          ["registry29", "registry30", "registry31"]),
                                         ("cop_results_v69", ["view29", "view30"],
                                          {"view29": 0, "fork29": 0, "validity_fork29": 0, "view30": 0, "image30": 0,
                                           "validity_image30": 0, "fork31": 1, "mech31": 0, "validity_fork31": 0},
                                          "v69_reports", ["registry29"])):
        for p in panels:
            (tmp_path / d / p).mkdir(parents=True)
        (tmp_path / d / rdir).mkdir()
        (tmp_path / d / rdir / "verdict.json").write_text(json.dumps({"steps": steps}))
        for r in regs:
            (tmp_path / d / rdir / f"{r}.json").write_text(json.dumps({"results": [
                {"key": "k", "reading": "replicated", "mean_favourable": 0.1}]}))
    base = {k: v for k, v in os.environ.items() if k not in ("COP_PYTEST", "V64_RESULTS", "V65_RESULTS",
                                                             "V67_RESULTS", "V69_RESULTS", "V69_CODE", "N30",
                                                             "RETRAIN", "MOCK_REUSE")}
    env = dict(base, MOCK_HOME=str(home), COP_RESULTS=str(tmp_path / "results"), ZIP_DIR=str(zipdir), SCALE="full",
               HOME=str(tmp_path), COP_PYTEST=str(pt),
               **{f"MOCK_FILES_{n}": ",".join(FILES[k]) for n, k in NAMES.items()})
    return {"home": home, "res": tmp_path / "results", "zip": zipdir / "cop_v70_reanalysis_reports.zip", "env": env,
            "tmp": tmp_path}


def _sh(h, **env):
    e = dict(h["env"], **{k: str(v) for k, v in env.items()})
    return subprocess.run(["bash", str(h["home"] / "scripts" / SCRIPT)], env=e, capture_output=True, text=True,
                          cwd=str(h["home"]))


def _events(h):
    p = h["home"] / "events.txt"
    return p.read_text() if p.exists() else ""


def _reg(h):
    out = {}
    for ln in _events(h).splitlines():
        if ln.startswith("registry "):
            name = ln.split()[1]
            pf = json.loads(ln.split(" PF ", 1)[1].split(" EX ", 1)[0])
            ex = json.loads(ln.split(" EX ", 1)[1].split(" MAN ", 1)[0])
            out[name] = (pf, ex, ln.split(" MAN ", 1)[1])
    return out


def _verdict(h):
    return json.loads((h["res"] / "v70_reports/verdict.json").read_text())


def _first(lines, prefix):
    return next(i for i, x in enumerate(lines) if x.startswith(prefix))


def test_analyses_then_every_f0_then_the_retrained_sample_then_the_registries(h):
    r = _sh(h)
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-3000:]
    lines = _events(h).splitlines()
    order = [_first(lines, p) for p in ("reuse_v69 ", "fork29 read", "image30 read", "fork31 read", "mech31 read",
                                         "ref29 read", "ref31 read", "ref30 read", "retrain select", "registry ")]
    assert order == sorted(order)
    sel = [x for x in lines if x.startswith("retrain select")]
    assert [x.split("--f0 ")[1].split()[0] for x in sel] == ["b1", "b9", "b1"]      # wave 31: the ill-conditioned f0
    assert sum(x.startswith("cop run --manifest") and "retrain" in x for x in lines) == 3
    reg = _reg(h)
    assert reg["v66_wave29_registry.json"][:2] == ([], ["ref29_failed_states.txt"])
    assert reg["v66_image_registry.json"][:2] == ([], ["ref30_failed_states.txt"])
    assert reg["v66_mechanism_registry.json"][:2] == ([], ["ref29_failed_states.txt", "ref31_failed_states.txt"])
    assert reg["v66_mechanism_registry.json"][2].endswith("manifests/wave31_full.jsonl")
    names = zipfile.ZipFile(h["zip"]).namelist()
    for f in ("ref30_plan.json", "ref31_failed_states.txt", "retrain31.json", "registry31.json", "reuse_v69.json",
              "changes_v69_registry29.csv"):
        assert f"cop_v70_reanalysis_reports/v70_reports/{f}" in names, f


def test_v69_analyses_are_taken_when_the_reuse_check_allows(h):
    r = _sh(h, MOCK_REUSE="29,30,31")
    assert r.returncode == 1                                    # v69's fork31 exited 1 (a failed audit), carried over
    assert [k for k, v in _verdict(h)["steps"].items() if v != 0] == ["fork31"], r.stdout[-3000:]
    ev = _events(h)
    for a in ("fork29", "image30", "fork31", "mech31"):
        assert f"\n{a} read" not in "\n" + ev
    assert "view " not in ev                                    # no view rebuilt
    v = _verdict(h)["steps"]
    assert v["fork31"] == 1 and v["fork29"] == 0 and v["mech31"] == 0   # v69's exit codes carried over
    assert _reg(h)["v66_mechanism_registry.json"][2].endswith("v70_reports/wave31_full.jsonl")
    assert "ref29 read " + str(h["tmp"] / "cop_results_v69/view29") in ev


def test_a_partial_reuse_computes_the_rest(h):
    _sh(h, MOCK_REUSE="30")
    ev = _events(h)
    assert "\nfork29 read" in "\n" + ev and "\nimage30 read" not in "\n" + ev and "\nfork31 read" in "\n" + ev


@pytest.mark.parametrize("env, flag, regs", [
    ({"MOCK_RC_ref30": 1}, "v70:ref30_complete (1)", {"v66_image_registry.json"}),
    ({"MOCK_RC_ref29": 1}, "v70:ref29_complete (1)", {"v66_wave29_registry.json", "v66_mechanism_registry.json"}),
    ({"MOCK_RC_ref31": 1}, "v70:ref31_complete (1)", {"v66_mechanism_registry.json"}),
    ({"MOCK_RC_mech31": 1}, "v70:mech31 (1)", {"v66_mechanism_registry.json"}),
    ({"MOCK_RC_retrain_compare29": 1}, "v70:retrain_compare29 (1)", {"v66_wave29_registry.json"}),
    ({"MOCK_RC_retrain_compare31": 1}, "v70:retrain_compare31 (1)", {"v66_mechanism_registry.json"}),
    ({"MOCK_RC_retrain_compare30": 1}, "v70:retrain_compare30 (1)", {"v66_image_registry.json"}),
    ({"MOCK_DEVICE": "cuda", "MOCK_CUDA_NO_BOUND": 1}, "v70:cuda_tests_ran (1)", ALL)])
def test_missing_evidence_labels_exactly_the_registries_that_read_it(h, env, flag, regs):
    r = _sh(h, **env)
    assert r.returncode == 1
    reg = _reg(h)
    assert set(reg) == ALL
    for k, (pf, _, _) in reg.items():
        assert (flag in pf) == (k in regs), (k, pf)


def test_retrain_can_be_skipped_and_n30_chosen(h):
    r = _sh(h, RETRAIN=0, N30=6)
    ev = _events(h)
    assert "retrain " not in ev and all(pf == [] for pf, _, _ in _reg(h).values())
    assert _verdict(h)["steps"]["retrain_compare29"] == 99
    assert r.returncode == 1                                     # skipped steps are not passes


def test_named_cuda_tests_pass_the_gate(h):
    r = _sh(h, MOCK_DEVICE="cuda")
    assert r.returncode == 0, r.stdout[-2000:]
    assert all(pf == [] for pf, _, _ in _reg(h).values())
