"""v71: the close-out scripts (CHANGES_v71.md).

  export_registered_pairs  reproduces the registry's means and intervals exactly from the states table, keeps excluded
                           pairs as rows with their reason, and fails when the registry says otherwise
  float64_sensitivity      replaces each operand by the reference's float64 error rate; the f0 operand by its native
                           row; reports nothing for a hypothesis with an operand the reference did not evaluate; checks
                           the float32 operand against the reference's deployed count
  final_findings, figures  run on a fabricated set of every input, every number with its source
  release_manifest         follows a view's symlinks to the real run folder; a missing run fails
  diagnosis                runs on the miniature, no training
  terminology              the reference's coverage calls the rounding check a first-order estimate"""
from __future__ import annotations

import csv
import json
import os
import random
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "audit_v5" / "tools"))
import export_registered_pairs as EX  # noqa: E402
import final_findings as FF  # noqa: E402
import float64_sensitivity as F64  # noqa: E402
import paper_figures as PF  # noqa: E402
import release_manifest as RM  # noqa: E402
from test_v68 import DRAWS, SEEDS, _case, _read, _write  # noqa: E402
from test_v69 import mini  # noqa: E402,F401


def _export(tmp, *extra):
    return EX.main([str(tmp / "reg.json"), str(tmp / "o.json"), str(tmp / "s.csv"), str(tmp / "a.csv"),
                    str(tmp / "m.jsonl"), str(tmp / "x"), "--coverage", str(tmp / "cov.json"), *map(str, extra)])


def test_the_export_reproduces_the_registry(tmp_path):
    _case(tmp_path)
    r, rec = _read(tmp_path)
    assert r.returncode == 0
    assert _export(tmp_path) == 0
    rows = list(csv.DictReader(open(tmp_path / "x_pairs.csv")))
    ck = list(csv.DictReader(open(tmp_path / "x_check.csv")))
    assert len(ck) == len(rec["results"]) and all(c["reproduces_registry"] == "True" for c in ck)
    assert len(rows) == len(ck) * len(DRAWS) * len(SEEDS) and all(r_["eligible"] == "True" for r_ in rows)
    assert rows[0]["operand1"] == "P/s1/routed_reset" and rows[0]["operand2"] == "P/s1/ordinary_reset"


def test_excluded_pairs_stay_as_rows_and_the_conditional_summary_reproduces(tmp_path):
    _case(tmp_path, failed=[("b110", "routed_reset")])
    (tmp_path / "x.txt").write_text("b121|P/s1/ordinary_reset\n")
    r, rec = _read(tmp_path, "--exclude-states", tmp_path / "x.txt")
    assert {x["status"] for x in rec["results"]} == {"conditional"}
    assert _export(tmp_path, "--exclude-states", tmp_path / "x.txt") == 0
    rows = list(csv.DictReader(open(tmp_path / "x_pairs.csv")))
    out = {(r_["f0"], r_["exclusion"]) for r_ in rows if r_["eligible"] == "False"}
    assert ("b110", "P/s1/routed_reset: audit failed") in out and ("b121", "P/s1/ordinary_reset: reference") in out
    assert all(c["reproduces_registry"] == "True" for c in csv.DictReader(open(tmp_path / "x_check.csv")))


def test_the_export_fails_when_the_registry_differs(tmp_path):
    _case(tmp_path)
    _read(tmp_path)
    rec = json.loads((tmp_path / "o.json").read_text())
    rec["results"][0]["mean_favourable"] += 1e-9
    (tmp_path / "o.json").write_text(json.dumps(rec))
    assert _export(tmp_path) == 1
    ck = list(csv.DictReader(open(tmp_path / "x_check.csv")))
    assert ck[0]["reproduces_registry"] == "False" and ck[1]["reproduces_registry"] == "True"


# ----------------------------------------------------------------------------- float64 sensitivity

def _sens_case(tmp, n=1000):
    """two hypotheses: one against f0 (normalised metric), one routed - ordinary; 4 draws x 2 seeds; the reference
    has every operand except, for the second hypothesis, nothing missing; deployed = exact unless changed."""
    reg = {"hypotheses": [
        {"key": "fold", "role": "primary", "parent": "A", "fork": "s2", "comparison": "minus_f0", "first": "folded_reset",
         "second": "f0", "metric": "nrm_test_err", "favourable": "second - first"},
        {"key": "early", "role": "primary", "parent": "A", "fork": "s1", "comparison": "routed_minus_ordinary",
         "first": "routed_reset", "second": "ordinary_reset", "metric": "native_test_err",
         "favourable": "first - second"},
        {"key": "compact", "role": "secondary", "parent": "A", "fork": "s2", "comparison": "fork_minus_compact_2U",
         "first": "folded_reset", "second": "compact_2U", "metric": "nrm_test_err", "favourable": "second - first"}]}
    (tmp / "reg.json").write_text(json.dumps(reg))
    rnd = random.Random(0)
    pairs, ref = [], []
    for d in range(4):
        for o in range(2):
            f0 = f"b{d}{o}"
            w = {k: rnd.randrange(100, 300) for k in ("f0", "fr", "rr", "or", "c2")}
            ref += [{"f0": f0, "parent": "f0", "fork": "f0", "state": "f0", "measure": "native", "n": n,
                     "exact_wrong": w["f0"], "deployed_wrong": w["f0"]},
                    {"f0": f0, "parent": "A", "fork": "s2", "state": "folded_reset", "measure": "nrm", "n": n,
                     "exact_wrong": w["fr"], "deployed_wrong": w["fr"]},
                    {"f0": f0, "parent": "A", "fork": "s1", "state": "routed_reset", "measure": "native", "n": n,
                     "exact_wrong": w["rr"], "deployed_wrong": w["rr"]},
                    {"f0": f0, "parent": "A", "fork": "s1", "state": "ordinary_reset", "measure": "native", "n": n,
                     "exact_wrong": w["or"], "deployed_wrong": w["or"]}]
            for key, a_, b_, fav in (("fold", ("A/s2/folded_reset", w["fr"]), ("f0/f0/f0", w["f0"]), -1),
                                     ("early", ("A/s1/routed_reset", w["rr"]), ("A/s1/ordinary_reset", w["or"]), 1),
                                     ("compact", ("A/s2/folded_reset", w["fr"]), ("A/compact/compact_2U", w["c2"]),
                                      -1)):
                v = a_[1] / n - b_[1] / n
                pairs.append({"key": key, "data_draw": d, "optimizer_seed": o, "f0": f0, "operand1": a_[0],
                              "operand1_value": a_[1] / n, "operand2": b_[0], "operand2_value": b_[1] / n,
                              "value": v, "favourable_value": fav * v, "eligible": "True"})
    _write(tmp / "p_pairs.csv", list(pairs[0]), pairs)
    _write(tmp / "ref.csv", list(ref[0]), ref)
    return ref


def _sens(tmp, rc=0):
    assert F64.main([str(tmp / "out.csv"), "--pairs", str(tmp / "p_pairs.csv"), str(tmp / "reg.json"), "--ref",
                     str(tmp / "ref.csv")]) == rc
    return {r["key"]: r for r in csv.DictReader(open(tmp / "out.csv"))}


def test_float64_sensitivity_replaces_operands_by_the_exact_counts(tmp_path):
    ref = _sens_case(tmp_path)
    out = _sens(tmp_path)
    assert out["fold"]["covered"] == "True" and out["early"]["covered"] == "True"     # f0 via its native row
    assert out["compact"]["covered"] == "False" and "compact_2U" in out["compact"]["missing_operand"]
    assert out["compact"]["float64_mean"] == ""                                       # no number claimed
    for k in ("fold", "early"):
        assert abs(float(out[k]["mean_change"])) < 1e-15 and out[k]["float32_operand_mismatches"] == "0"
    # one exact count different: the float64 mean moves by exactly that much (one of 8 pairs, 4 draws x 2 seeds)
    for r in ref:
        if (r["f0"], r["state"]) == ("b00", "routed_reset"):
            r["exact_wrong"] += 8
    _write(tmp_path / "ref.csv", list(ref[0]), ref)
    out = _sens(tmp_path)
    assert abs(float(out["early"]["mean_change"]) - 8 / 1000 / 8) < 1e-12
    # a deployed count that does not match the registered float32 value is counted, and (v72) fails the step
    for r in ref:
        if (r["f0"], r["state"]) == ("b10", "ordinary_reset"):
            r["deployed_wrong"] += 1
    _write(tmp_path / "ref.csv", list(ref[0]), ref)
    assert _sens(tmp_path, rc=1)["early"]["float32_operand_mismatches"] == "1"


# ----------------------------------------------------------------------------- findings, figures (fabricated inputs)

def _fake_v70(root):
    """every input of final_findings and paper_figures, fabricated from the real registry configurations."""
    V, W = root / "v70_reports", root / "v71"
    V.mkdir(parents=True)
    W.mkdir()
    rnd = random.Random(1)
    sens = []
    for reg, cfg in (("registry29", "v66_wave29_registry.json"), ("registry30", "v66_image_registry.json"),
                     ("registry31", "v66_mechanism_registry.json")):
        hs = json.loads((ROOT / "configs" / cfg).read_text())["hypotheses"]
        res, pairs, checks = [], [], []
        for h in hs:
            m = rnd.uniform(-0.05, 0.05)
            lev = 0.99 if h["role"] == "primary" else 0.95
            res.append({**h, "status": "validated", "reading": "replicated" if m > 0.02 else "inconclusive",
                        "mean_favourable": m, "interval_low": m - 0.02, "interval_high": m + 0.02, "ci95_low": m - 0.01,
                        "ci95_high": m + 0.01, "interval_level": lev, "draws_favourable": "8/12",
                        "n_draw_seed_pairs": 24, "excluded": []})
            for d in range(12):
                for o in range(2):
                    v = rnd.gauss(m, 0.01)
                    pairs.append({"key": h["key"], "data_draw": d, "optimizer_seed": o, "f0": f"b{d}{o}", "value": v,
                                  "favourable_value": -v if h["favourable"] == "second - first" else v,
                                  "eligible": "True"})
            checks.append({"key": h["key"], "reproduces_registry": "True"})
            sens.append({"registry": reg, "key": h["key"], "role": h["role"], "covered": "True", "mean_change": "0.0",
                         "reading_changes": "False"})
        (V / f"{reg}.json").write_text(json.dumps({"results": res}))
        _write(V / f"{reg}.csv", ["key", "found_rows", "recomputed_rows", "recomputed_mismatches"],
               [{"key": h["key"], "found_rows": 24, "recomputed_rows": 24, "recomputed_mismatches": 0} for h in hs])
        _write(W / f"{reg}_pairs.csv", list(pairs[0]), pairs)
        _write(W / f"{reg}_check.csv", list(checks[0]), checks)
    _write(W / "float64_sensitivity.csv", list(sens[0]), sens)
    row = {"f0": "b00", "parent": "A_routed_affine", "fork": "snap_2500", "state": "routed_reset", "measure": "native",
           "n": 100, "passed": "True", "function64_ok": "True", "deployed_ok": "True", "params_ok": "",
           "eligibility_ok": "", "table_ok": "True", "exact_wrong": 10, "deployed_wrong": 10,
           "deployed_violations": 0, "deployed_worst": 0.1, "deployed_extra_worst": 0.1, "deployed_extra_wrong": 10,
           "disagree_decided": 0}
    for k in ("ref29", "ref30", "ref31"):
        rows = [row, {**row, "state": "ordinary_reset"}]
        if k == "ref29":
            rows[0] = {**row, "passed": "False", "deployed_ok": "False", "deployed_violations": 1,
                       "deployed_worst": 57.1}
        _write(V / f"{k}_rows.csv", list(rows[0]), rows)
        (V / f"{k}_coverage.json").write_text(json.dumps({"bound_dtype": "float32" if k == "ref30" else "float64"}))
    au = {"f0": "b10", "data_draw": "1", "optimizer_seed": "0", "parent": "B_routed_affine", "fork": "snap_1000",
          "state": "routed_shift50", "audit_passed": "False", "outcome_redistribution_storage64": "1.2e-5",
          "outcome_redistribution_cond": "101450"}
    _write(V / "fork31_audits.csv", list(au), [au, {**au, "audit_passed": "True"}])
    for an in ("fork29", "image30"):
        _write(V / f"{an}_audits.csv", list(au), [{**au, "audit_passed": "True"}])
    (root / "declared.json").write_text(json.dumps({
        "audit_failures": [{"analysis": "fork31", "f0": "b10", "key": "B_routed_affine/snap_1000/routed_shift50"}],
        "reference_rows": [{"reference": "ref29", "f0": "b00", "key": "A_routed_affine/snap_2500/routed_reset",
                            "measure": "native", "allowed_failed_certificates": ["deployed_ok"]}],
        "allowed_nonzero_steps": {"fork31": 1, "ref29": 4, "registry31": 3}}))
    for w in ("29", "30", "31"):
        (V / f"retrain{w}.json").write_text(json.dumps({"n_jobs": 5, "n_checkpoints_compared": 30, "reproduced": True}))
    (V / "mech31_coverage.json").write_text(json.dumps({"expected_f0": 24, "analysed_f0": 24, "gradient_rows": 1152,
                                                        "regrowth_rows": 1920, "passed": True}))
    g, rg = [], []
    for f in range(4):
        for mode, rc, cos in (("ordinary", 1e-15, 1.0), ("routed", 0.9, 0.3)):
            g.append({"f0": f"b{f}", "parent": "A_routed_affine", "fork": "snap_1000", "edit": "swap", "mode": mode,
                      "precision": "float64", "raw_grad_rel_change": rc, "raw_grad_cos": cos, "disp_trainable_cos": cos})
        for cont in ("routed_shift100", "ordinary_shift100"):
            for u in (0, 750, 1500):
                rg.append({"f0": f"b{f}", "parent": "A_routed_affine", "fork": "snap_1000", "continuation": cont,
                           "update": u, "net_over_input": 0.0 if u == 0 else rnd.uniform(0.01, 1)})
    _write(V / "mech31_gradients.csv", list(g[0]), g)
    _write(V / "mech31_regrowth.csv", list(rg[0]), rg)
    for f, n in (("cpu_tests.xml", 10), ("cuda_tests.xml", 4)):
        (V / f).write_text(f'<testsuites><testsuite tests="{n}" skipped="1" failures="0" errors="0"/></testsuites>')
    (V / "verdict.json").write_text(json.dumps({"steps": {"fork31": 1, "ref29": 4, "registry31": 3, "x": 0},
                                                "pending": []}))
    return V, W


def test_the_findings_cite_their_sources(tmp_path):
    V, W = _fake_v70(tmp_path)
    assert FF.main([str(V), str(W), str(tmp_path / "F.md"), "--exceptions", str(tmp_path / "declared.json")]) == 0
    t = (tmp_path / "F.md").read_text()
    for s in ("## (a) Supported findings", "## (b) Contrary and inconclusive findings", "## (c) Validation exceptions",
              "## (d) Numerical assumptions and checks", "first order, not a bound", "Fork audit failure: storage certificate",
              "rounding-estimate exceedance", "`registry29.json:", "not that the science passed",
              "{'fork31': 1, 'ref29': 4, 'registry31': 3}", "## Release checks", "Raw extraction"):
        assert s in t, s
    assert "—" not in t                                         # no em dashes in generated text
    assert "NOT RELEASE-READY" not in t and "FAIL" not in t
    (V / "registry30.json").unlink()
    assert FF.main([str(V), str(W), str(tmp_path / "G.md"), "--exceptions", str(tmp_path / "declared.json")]) == 1
    assert (tmp_path / "G.md").read_text().startswith("# NOT RELEASE-READY")


def test_the_figures_are_drawn(tmp_path):
    V, W = _fake_v70(tmp_path)
    args = [str(tmp_path / "fig")]
    for r in ("registry29", "registry30", "registry31"):
        args += ["--pairs", str(W / f"{r}_pairs.csv"), str(V / f"{r}.json")]
    args += ["--mech-gradients", str(V / "mech31_gradients.csv"), "--mech-regrowth", str(V / "mech31_regrowth.csv")]
    assert PF.main(args) == 0
    for n in ("fig1_component_effects", "fig2_folding_controls", "fig3_swap_mechanism", "figS1_regrowth"):
        assert (tmp_path / "fig" / f"{n}.pdf").stat().st_size > 1000 and (tmp_path / "fig" / f"{n}.png").exists()
    cap = (tmp_path / "fig" / "captions.md").read_text()
    assert cap.count("Neither is the native accuracy") >= 3 and "Unlike raw extraction" in cap


# ----------------------------------------------------------------------------- release manifest

def test_the_release_manifest_follows_views_and_fails_on_a_missing_run(tmp_path):
    real = tmp_path / "panel" / "runs" / "r1" / "ckpt"
    real.mkdir(parents=True)
    (real / "final.pt").write_bytes(b"abc")
    (tmp_path / "view" / "runs").mkdir(parents=True)
    os.symlink(tmp_path / "panel" / "runs" / "r1", tmp_path / "view" / "runs" / "r1")
    man = tmp_path / "m.jsonl"
    man.write_text('{"run_id": "r1"}\n')
    (tmp_path / "rep").mkdir()
    (tmp_path / "rep" / "a.csv").write_text("x\n")
    (tmp_path / "v.json").write_text(json.dumps({"steps": {"a": 0, "b": 4}}))
    assert RM.main([str(tmp_path / "o.json"), "--reports", str(tmp_path / "rep"), "--runs", "w", str(tmp_path / "view"),
                    str(man), "--verdict", str(tmp_path / "v.json"), "--statement", "two exceptions"]) == 0
    rec = json.loads((tmp_path / "o.json").read_text())
    r1 = rec["runs"]["w"]["runs"]["r1"]
    assert r1["path"] == str((tmp_path / "panel" / "runs" / "r1").resolve())
    assert r1["files"]["ckpt/final.pt"]["sha256"] == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
    assert rec["final_verdict"]["not_zero"] == {"b": 4} and rec["final_verdict"]["statement"] == "two exceptions"
    man.write_text('{"run_id": "r1"}\n{"run_id": "r2"}\n')
    assert RM.main([str(tmp_path / "o2.json"), "--runs", "w", str(tmp_path / "view"), str(man)]) == 1


# ----------------------------------------------------------------------------- diagnosis and terminology

def test_the_diagnosis_runs_on_the_miniature(mini, tmp_path):
    import diagnose_estimate_failure as DG
    import fork_continuation as FC
    lines = [json.loads(ln) for ln in open(mini["man"]) if ln.strip()]
    f0 = sorted(FC.fork_jobs({e["run_id"]: e["cfg"] for e in lines}))[0]
    assert DG.main([str(mini["root"]), str(mini["man"]), str(tmp_path / "d.json"), "--f0", f0, "--state",
                    "A_routed_affine/snap_10/routed_reset"]) == 0
    d = json.loads((tmp_path / "d.json").read_text())
    assert d["n"] > 0 and len(d["estimate"]) == len(d["z64"]) and isinstance(d["sign_changes_total"], int)
    assert d["layers"] and all(L["op"] not in ("act",) for L in d["layers"])
    assert max(d["ratio_cpu"]) <= 1.0                             # the miniature is within the estimate


def test_the_reference_calls_its_check_an_estimate(mini, tmp_path):
    import reference_recompute as RC
    root = mini["root"]
    RC.main([str(root), str(tmp_path / "r"), "--manifest", str(mini["man"]), "--states", str(root / "fork31_states.csv"),
             "--n-f0", "1"])
    t = json.loads((tmp_path / "r_coverage.json").read_text())["tolerances"]
    assert t["estimate_kind"] == "first-order estimate, not a rigorous bound" and len(t["estimate_assumptions"]) == 4
    assert "estimate" in t["deployed"] and "bound per" not in t["deployed"]
