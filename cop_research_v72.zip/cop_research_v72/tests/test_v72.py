"""v72: release-integrity and reporting safeguards (CHANGES_v72.md).

  release manifest   files still being written are declared exclusions, not listed; verify re-hashes what is listed
                     and checks every delivered file: a changed, an unlisted or an undelivered listed file fails
  findings           a release-ready document only when every release check passes; corrupted or missing evidence
                     (an export that does not reproduce, a recomputation mismatch, an undeclared audit or reference
                     failure, a declared exception that is absent, a declared reference row that failed another
                     certificate, a float64 operand mismatch, a failed test, an undeclared nonzero step, a missing
                     input) gives NOT RELEASE-READY and exit 1; the two declared exceptions are kept
  export             a fork operand without an audit row is excluded; f0, compacts and trajectory ends need their own
                     records in the analysis coverage, not a fork audit
  wording            the diagnosis does not claim a cause; the estimate's activation pattern is its own dtype's"""
from __future__ import annotations

import csv
import json
import sys
import zipfile
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(ROOT / "scripts"))
import export_registered_pairs as EX  # noqa: E402
import final_findings as FF  # noqa: E402
import release_manifest as RM  # noqa: E402
from test_v68 import _case, _read, _write  # noqa: E402
from test_v71 import _fake_v70  # noqa: E402


# ----------------------------------------------------------------------------- release manifest

def _release(tmp):
    rep = tmp / "reps"
    (rep / "figures").mkdir(parents=True)
    (rep / "a.csv").write_text("x\n1\n")
    (rep / "figures" / "f.png").write_bytes(b"png")
    (rep / "big.csv").write_text("y\n" * 10)
    (rep / "step.txt").write_text("")                      # the manifest step's own log: written after hashing
    code = tmp / "code"
    code.mkdir()
    (code / "s.py").write_text("print(1)\n")
    man = tmp / "reps" / "RELEASE_MANIFEST.json"
    assert RM.main([str(man), "--code", str(code), "--reports", str(rep),
                    "--exclude", str(rep), "RELEASE_MANIFEST.json", "the manifest itself",
                    "--exclude", str(rep), "step.txt", "its log"]) == 0
    (rep / "step.txt").write_text("written after the manifest\n")
    return rep, code, man


def _zip(tmp, rep, skip=()):
    z = tmp / "out.zip"
    with zipfile.ZipFile(z, "w") as zf:
        for p in sorted(rep.rglob("*")):
            rel = p.relative_to(rep).as_posix()
            if p.is_file() and rel not in skip:
                zf.write(p, f"pfx/{rep.name}/{rel}")
        zf.writestr("pfx/verdict.json", "{}")
        if skip:
            zf.writestr("pfx/skipped_large_files.json", json.dumps([{"file": f"{rep.name}/{s}", "bytes": 1}
                                                                     for s in skip]))
    return z


def test_mutable_files_are_declared_and_the_release_verifies(tmp_path):
    rep, code, man = _release(tmp_path)
    rec = json.loads(man.read_text())
    assert "step.txt" not in rec["reports"][str(rep)] and "RELEASE_MANIFEST.json" not in rec["reports"][str(rep)]
    assert rec["excluded_mutable"][str(rep)] == {"RELEASE_MANIFEST.json": "the manifest itself", "step.txt": "its log"}
    z = _zip(tmp_path, rep, skip=("big.csv",))
    assert RM.main(["verify", str(man), "--code", str(code), "--zip", str(z), "pfx", str(rep)]) == 0


@pytest.mark.parametrize("damage", ["changed_on_disk", "changed_in_archive", "unlisted_delivered",
                                    "listed_not_delivered", "code_changed"])
def test_the_release_verification_fails(tmp_path, damage):
    rep, code, man = _release(tmp_path)
    z = _zip(tmp_path, rep)
    if damage == "changed_on_disk":
        (rep / "a.csv").write_text("x\n2\n")
    elif damage == "changed_in_archive":
        (rep / "figures" / "f.png").write_bytes(b"PNG")
        z = _zip(tmp_path, rep)
        (rep / "figures" / "f.png").write_bytes(b"png")
    elif damage == "unlisted_delivered":
        (rep / "late.csv").write_text("z\n")
        z = _zip(tmp_path, rep)
    elif damage == "listed_not_delivered":
        z = _zip(tmp_path, rep)
        with zipfile.ZipFile(z) as zf:
            keep = {n: zf.read(n) for n in zf.namelist() if not n.endswith("a.csv")}
        with zipfile.ZipFile(z, "w") as zf:
            for n, b in keep.items():
                zf.writestr(n, b)
    else:
        (code / "s.py").write_text("print(2)\n")
    assert RM.main(["verify", str(man), "--code", str(code), "--zip", str(z), "pfx", str(rep)]) == 1


# ----------------------------------------------------------------------------- findings refuse inconsistent evidence

def _ff(tmp, V, W):
    return FF.main([str(V), str(W), str(tmp / "F.md"), "--exceptions", str(tmp / "declared.json")])


def _rows(p):
    return list(csv.DictReader(open(p)))


def _set(p, i, **kw):
    rows = _rows(p)
    rows[i].update({k: str(v) for k, v in kw.items()})
    _write(p, list(rows[0]), rows)


@pytest.mark.parametrize("damage, check", [
    ("export_not_reproduced", "export reproduces registry30"),
    ("recomputation_mismatch", "registry29 recomputed from the states table"),
    ("undeclared_audit_failure", "failed fork audits are the declared ones"),
    ("declared_audit_absent", "failed fork audits are the declared ones"),
    ("undeclared_reference_failure", "failed reference rows are the declared ones"),
    ("declared_row_other_certificate", "failed reference rows are the declared ones"),
    ("function64_false", "float64 implementation agreement"),
    ("table_false", "parameter, eligibility and table certificates"),
    ("sensitivity_mismatch", "float64 sensitivity consistent"),
    ("test_failure", "tests"),
    ("undeclared_step", "nonzero steps are the declared ones"),
    ("retrain_differs", "retrained runs reproduce"),
    ("incomplete_status", "registry statuses"),
    ("undeclared_exclusion", "conditional exclusions are declared exceptions")])
def test_inconsistent_evidence_is_not_release_ready(tmp_path, damage, check):
    V, W = _fake_v70(tmp_path)
    if damage == "export_not_reproduced":
        _set(W / "registry30_check.csv", 0, reproduces_registry=False)
    elif damage == "recomputation_mismatch":
        _set(V / "registry29.csv", 2, recomputed_mismatches=1)
    elif damage == "undeclared_audit_failure":
        _set(V / "fork29_audits.csv", 0, audit_passed=False, f0="b99")
    elif damage == "declared_audit_absent":
        _set(V / "fork31_audits.csv", 0, audit_passed=True)
    elif damage == "undeclared_reference_failure":
        _set(V / "ref30_rows.csv", 1, passed=False, deployed_ok=False)
    elif damage == "declared_row_other_certificate":
        _set(V / "ref29_rows.csv", 0, table_ok=False)
    elif damage == "function64_false":
        _set(V / "ref31_rows.csv", 1, function64_ok=False)
    elif damage == "table_false":
        _set(V / "ref30_rows.csv", 0, table_ok=False)
    elif damage == "sensitivity_mismatch":
        rows = _rows(W / "float64_sensitivity.csv")
        rows[0]["float32_operand_mismatches"] = "2"
        _write(W / "float64_sensitivity.csv", list(rows[0]) + (["float32_operand_mismatches"]
                                                               if "float32_operand_mismatches" not in rows[0] else []),
               rows)
    elif damage == "test_failure":
        (V / "cpu_tests.xml").write_text('<testsuites><testsuite tests="10" skipped="1" failures="1" errors="0"/>'
                                         '</testsuites>')
    elif damage == "undeclared_step":
        v = json.loads((V / "verdict.json").read_text())
        v["steps"]["export29"] = 1
        (V / "verdict.json").write_text(json.dumps(v))
    elif damage == "retrain_differs":
        (V / "retrain30.json").write_text(json.dumps({"n_jobs": 5, "n_checkpoints_compared": 30, "reproduced": False}))
    elif damage in ("incomplete_status", "undeclared_exclusion"):
        d = json.loads((V / "registry31.json").read_text())
        if damage == "incomplete_status":
            d["results"][0]["status"] = "incomplete"
        else:
            d["results"][0]["status"] = "conditional"
            d["results"][0]["excluded"] = ["b77:A_routed_affine/snap_1000/routed_reset (reference)"]
        (V / "registry31.json").write_text(json.dumps(d))
    assert _ff(tmp_path, V, W) == 1
    t = (tmp_path / "F.md").read_text()
    assert t.startswith("# NOT RELEASE-READY") and f"- {check}:" in t.split("# CoP")[0], t[:1500]
    assert "FAIL: " + check in t


def test_the_declared_exceptions_alone_are_release_ready(tmp_path):
    V, W = _fake_v70(tmp_path)
    assert _ff(tmp_path, V, W) == 0
    t = (tmp_path / "F.md").read_text()
    assert t.startswith("# CoP") and "completed with 2 localized validation exceptions" in t
    assert "Fork audit failure" in t and "rounding-estimate exceedance" in t
    assert "0 mismatches" in t and "params_ok" not in t.split("## (d)")[0]


@pytest.mark.parametrize("missing", ["registry29.csv", "ref30_coverage.json", "image30_audits.csv", "declared"])
def test_missing_evidence_is_not_release_ready(tmp_path, missing):
    V, W = _fake_v70(tmp_path)
    if missing == "declared":
        (tmp_path / "declared.json").unlink()
    else:
        (V / missing).unlink()
    assert _ff(tmp_path, V, W) == 1
    assert (tmp_path / "F.md").read_text().startswith("# NOT RELEASE-READY")


# ----------------------------------------------------------------------------- export: validation records by kind

def _export(tmp, **cov):
    c = json.loads((tmp / "cov.json").read_text())
    c.update(cov)
    (tmp / "cov2.json").write_text(json.dumps(c))
    return EX.main([str(tmp / "reg.json"), str(tmp / "o.json"), str(tmp / "s.csv"), str(tmp / "a.csv"),
                    str(tmp / "m.jsonl"), str(tmp / "x"), "--coverage", str(tmp / "cov2.json")])


def test_a_fork_operand_without_an_audit_row_is_excluded(tmp_path):
    _case(tmp_path)
    _read(tmp_path)
    rows = _rows(tmp_path / "a.csv")
    drop = rows.pop(0)
    _write(tmp_path / "a.csv", list(drop), rows)
    assert _export(tmp_path) == 1                               # the registry had read the pair; the export refuses it
    out = [r for r in _rows(tmp_path / "x_pairs.csv") if r["eligible"] == "False"]
    assert out and all("no fork audit" in r["exclusion"] and r["f0"] == drop["f0"] for r in out)


def _rules_case():
    cov = {"analysed_f0": 2, "expected_f0": 2, "failed": [{"f0": "bad"}],
           "compact_controls": [["A", "compact_2U"]], "compact_reset_controls": [["A", "snap_1000"]],
           "design": {"arms": ["A_head_all_relu"], "parents": ["A_routed_affine"]}}
    # one small export exercising each kind: f0, a matched compact, a reset-matched compact, a trajectory end
    reg = {"contract": {"data_draws": [1], "optimizer_seeds": [0]}, "hypotheses": [
        {"key": "f0", "role": "secondary", "parent": "A_routed_affine", "fork": "snap_2500", "comparison": "minus_f0",
         "first": "folded_reset", "second": "f0", "metric": "m", "favourable": "first - second"},
        {"key": "c2", "role": "secondary", "parent": "A_routed_affine", "fork": "snap_2500",
         "comparison": "fork_minus_compact_2U", "first": "folded_reset", "second": "compact_2U", "metric": "m",
         "favourable": "first - second"},
        {"key": "cr", "role": "secondary", "parent": "A_routed_affine", "fork": "snap_1000",
         "comparison": "fork_minus_compact_reset", "first": "routed_reset", "second": "compact_reset", "metric": "m",
         "favourable": "first - second"},
        {"key": "arm", "role": "secondary", "parent": "arms", "fork": "trajectory_end", "comparison": "arm_minus_arm",
         "first": "A_routed_affine", "second": "A_head_all_relu", "metric": "m", "favourable": "first - second"}]}
    return reg, cov


def test_the_validation_rules_by_operand_kind(tmp_path):
    reg, cov = _rules_case()
    (tmp_path / "reg.json").write_text(json.dumps(reg))
    (tmp_path / "m.jsonl").write_text(json.dumps({"run_id": "b10", "cfg": {"kind": "baseline", "data": {"data_seed": 1},
                                                                           "seeds": {"optimizer": 0}}}) + "\n")
    st = [{"f0": "b10", "parent": p, "fork": f, "state": s, "m": v} for p, f, s, v in (
        ("f0", "f0", "f0", 0.3), ("A_routed_affine", "snap_2500", "folded_reset", 0.2),
        ("A", "compact", "compact_2U", 0.25), ("A_routed_affine", "snap_1000", "routed_reset", 0.21),
        ("A", "snap_1000", "compact_reset", 0.22), ("A_routed_affine", "end", "trajectory_end", 0.2),
        ("A_head_all_relu", "end", "trajectory_end", 0.23))]
    _write(tmp_path / "s.csv", list(st[0]), st)
    au = [{"f0": "b10", "parent": "A_routed_affine", "fork": f, "state": s, "audit_passed": "True"}
          for f, s in (("snap_2500", "folded_reset"), ("snap_1000", "routed_reset"))]
    _write(tmp_path / "a.csv", list(au[0]), au)
    res = {"results": [{"key": h["key"]} for h in reg["hypotheses"]]}
    (tmp_path / "o.json").write_text(json.dumps(res))

    def run(c):
        (tmp_path / "cov.json").write_text(json.dumps(c))
        EX.main([str(tmp_path / "reg.json"), str(tmp_path / "o.json"), str(tmp_path / "s.csv"), str(tmp_path / "a.csv"),
                 str(tmp_path / "m.jsonl"), str(tmp_path / "x"), "--coverage", str(tmp_path / "cov.json")])
        return {r["key"]: (r["eligible"], r["exclusion"]) for r in _rows(tmp_path / "x_pairs.csv")}
    got = run(cov)                                             # every record present (compact under the hold "A")
    assert all(v[0] == "True" for v in got.values()), got
    got = run({**cov, "compact_controls": [], "compact_reset_controls": [], "design": {"arms": ["A_routed_affine"]},
               "analysed_f0": 1})
    assert got["f0"] == ("False", "f0: the analysis did not analyse every expected f0")
    assert got["c2"][1] == "A/compact/compact_2U: no compact record"
    assert got["cr"][1] == "A/snap_1000/compact_reset: no reset-matched compact record"
    assert got["arm"][1] == "A_head_all_relu/end/trajectory_end: arm not in the analysed design"
    got = run({**cov, "failed": [{"f0": "b10"}]})
    assert got["f0"] == ("False", "f0: failed in the analysis")


# ----------------------------------------------------------------------------- wording

def test_the_wording_is_corrected():
    import diagnose_estimate_failure as DG
    sys.path.insert(0, str(ROOT / "audit_v5" / "tools"))
    import reference_impl as R
    assert "does not\nestablish which caused" in DG.__doc__ and "answers whether" not in DG.__doc__
    doc = R.RefNet.rounding_bound.__doc__
    assert "FIRST-ORDER ESTIMATE" in doc and "in the dtype it is" in doc and "exact (float64) activation" not in doc
