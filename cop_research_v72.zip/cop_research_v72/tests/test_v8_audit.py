"""Regression tests for the independent v7 audit (V7-01 ... V7-07), v8 fixes.

The audit's probes (independent_probes.py) are turned into assertions of the corrected behaviour.
CUDA tests are marked and skip without a device: a skip is NOT validation; scripts/12 runs them on
the GPU and fails on a skip."""
from __future__ import annotations

import json
import math
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import pytest
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests"))

import tiny_configs as T  # noqa: E402
from cop.config import resolve, run_id  # noqa: E402
from cop.data.registry import load_bundle  # noqa: E402
from cop.experiments import diagnostics as D  # noqa: E402
from cop.graph import edits as E  # noqa: E402
from cop.graph.builders import build_mlp, build_transformer  # noqa: E402
from cop.orchestration.runner import run_job, status_of  # noqa: E402
from cop.utils import read_json, torch_gen  # noqa: E402

CUDA = pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA device required (run scripts/12 on the GPU)")


def _run(cfgs, d, device="cpu"):
    for c in cfgs:
        st = run_job(c, d, {"device": device})
        assert st == "complete", status_of(d, run_id(c))
    return d / "runs" / run_id(cfgs[-1])


def _ctx(path, cfg):
    path.mkdir(parents=True, exist_ok=True)
    return SimpleNamespace(dir=path, cfg=cfg, metric=lambda *a, **k: None)


def _fingerprints(g):
    return D._state_fingerprint(g), D._rng_fingerprint(), g.training


# ----------------------------------------------------------------------------- V7-01

def test_fp64_model_with_float32_bundle_completes_every_measurement(tmp_path):
    """The audit's probe: float64 MLP, the ordinary float32 DataBundle, a real implant."""
    cfg = T.base(train={**T.TRAIN, "precision": "fp64"})
    bundle = load_bundle(cfg["data"])
    assert bundle.train.X["x"].dtype == torch.float32
    g = build_mlp(8, [16, 16], 3, torch_gen(0, "init")).double()
    iid = E.insert_residual_zero(g, E.cut_at(g, "post_act", 0), torch_gen(0, "insertion", "fp64"), width=4,
                                 b_init_scale=0.5)
    g.train()
    before = _fingerprints(g)
    rec = D.contraction_diagnostics(_ctx(tmp_path, cfg), g, bundle, [iid], "probe")
    row = rec["implants"][iid]
    assert row["complete"] and "error" not in row, row
    assert all(row[f"{m}_status"] in ("ok", "not_applicable") for m in D.REQUIRED_MEASUREMENTS)
    assert math.isfinite(row["jvp_residual"]) and row["jvp_residual"] > 0
    maps = torch.load(tmp_path / rec["maps_file"], weights_only=False)
    assert iid in maps and maps[iid]["weight"].dtype == torch.float64
    assert rec["state_unchanged"] and _fingerprints(g) == before          # parameters, RNG and train mode


def test_fp64_dissipation_job_records_complete_diagnostics(tmp_path):
    tr = {**T.TRAIN, "precision": "fp64"}
    p = T.traj({"topology": "layered", "rounds": 1}, train=tr)
    d = T.child("dissipation", p[-1], {"dissipation": {"method": "linear", "speed_updates": 4, "post_updates": 4}})
    rec = read_json(_run(p + [d], tmp_path) / "contraction_diagnostics.json")["dissipation_start"]
    assert rec["complete"] and rec["state_unchanged"], rec


def test_injected_jvp_failure_keeps_fit_virtual_deletion_and_the_saved_map(tmp_path, monkeypatch):
    cfg = T.base()
    bundle = load_bundle(cfg["data"])
    g = build_mlp(8, [16, 16], 3, torch_gen(0, "init"))
    iid = E.insert_residual_zero(g, E.cut_at(g, "post_act", 0), torch_gen(0, "insertion", "j"), width=4,
                                 b_init_scale=0.5)

    def boom(*a, **k):
        raise RuntimeError("injected JVP failure")
    monkeypatch.setattr(D, "jvp_sensitivity", boom)
    before = _fingerprints(g)
    rec = D.contraction_diagnostics(_ctx(tmp_path, cfg), g, bundle, [iid], "t")
    row = rec["implants"][iid]
    assert row["fit_status"] == "ok" and row["virtual_status"] == "ok" and row["deletion_status"] == "ok"
    assert row["jvp_status"] == "failed" and "injected" in row["jvp_error"]
    assert "jvp_residual" not in row                           # missing, never zero
    assert row["complete"] is False and rec["complete"] is False and "jvp" in row["error"]
    assert math.isfinite(row["rho_raw"]) and math.isfinite(row["virtual_affine_damage"]["val"])
    assert iid in torch.load(tmp_path / rec["maps_file"], weights_only=False)
    assert _fingerprints(g) == before


def test_eval_inputs_keep_integer_tokens_and_cast_floats():
    g = build_mlp(4, [4], 2, torch_gen(0, "init")).double()
    X = D.eval_inputs(g, {"x": torch.randn(3, 4), "q": torch.tensor([1, 2, 0])})
    assert X["x"].dtype == torch.float64 and X["q"].dtype == torch.long


# ----------------------------------------------------------------------------- V7-02

def _tiny_transformer(dtype=torch.float32):
    g = build_transformer(8, 8, 2, 2, 8, torch_gen(0, "init")).to(dtype).eval()
    iid = E.insert_residual_zero(g, E.cut_at(g, "resid", 0), torch_gen(0, "insertion", "attention"), width=4,
                                 b_init_scale=0.1)
    X = {"x": torch.randint(0, 8, (8, 5), generator=torch.Generator().manual_seed(0))}
    return g, iid, X


def test_transformer_jvp_before_a_downstream_attention_block_matches_central_differences():
    g, iid, X = _tiny_transformer(torch.float64)
    imp = g.implants[iid]
    v = D._values(g, X, [imp.entry, imp.exit], 16)
    W, b, _ = D._fit(v[imp.entry].reshape(-1, 8), v[imp.exit].reshape(-1, 8))
    r = D.jvp_sensitivity(g, iid, W, b, X)
    assert r["jvp_backend"].startswith("math")
    # central finite difference of the output along the residual direction, same backend, float64
    H, Y = v[imp.entry], v[imp.exit]
    R = (Y.reshape(-1, 8).double() - D._apply(W, b, H.reshape(-1, 8))).reshape(Y.shape)
    eps = 1e-5

    def out(z):
        g.value_patch = {imp.exit: (lambda t, z=z: z)}
        try:
            with torch.no_grad():
                return g(D.eval_inputs(g, X)).double()
        finally:
            g.value_patch = None
    fd = (out(Y + eps * R) - out(Y - eps * R)) / (2 * eps)
    fd_val = float((fd.reshape(fd.shape[0], -1) ** 2).sum(1).mean())
    assert r["jvp_residual"] == pytest.approx(fd_val, rel=1e-6)


def test_transformer_diagnostics_complete_in_a_real_job_and_training_kernels_are_restored(tmp_path):
    SEQ = {"name": "seq_select", "n_train": 256, "n_val": 128, "n_test": 128}
    model = {"family": "transformer", "depth": 2, "width": 16}
    p = T.traj({"topology": "layered", "rounds": 1, "cut_kind": "resid"}, data=SEQ, model=model)
    d = T.child("dissipation", p[-1], {"dissipation": {"method": "linear", "speed_updates": 4, "post_updates": 4}})
    rec = read_json(_run(p + [d], tmp_path) / "contraction_diagnostics.json")["dissipation_start"]
    assert rec["complete"], rec
    assert all(r["jvp_backend"].startswith("math") for r in rec["implants"].values() if "skipped" not in r)
    # the backend selection is scoped: outside the diagnostic the default kernels are in force again, so the
    # unscoped double-backward still fails on this CPU build (if it ever succeeds, the scoping is untestable here)
    g, iid, X = _tiny_transformer()
    imp = g.implants[iid]
    Y = D._values(g, X, [imp.exit], 16)[imp.exit]

    def f(z):
        g.value_patch = {imp.exit: (lambda t, z=z: z)}
        try:
            return g(X)
        finally:
            g.value_patch = None
    try:
        torch.autograd.functional.jvp(f, (Y,), (torch.ones_like(Y),))
        unscoped_fails = False
    except RuntimeError:
        unscoped_fails = True
    if not unscoped_fails:
        pytest.skip("this torch build differentiates the fused kernel; scoping is not observable here")


# ----------------------------------------------------------------------------- CUDA

def _tiny_gru(dtype=torch.float64):
    from cop.graph.builders import build_gru
    g = build_gru(8, 8, 2, 8, torch_gen(0, "init")).to(dtype).eval()
    iid = E.insert_residual_zero(g, E.cut_at(g, "gru_out", 0), torch_gen(0, "insertion", "gru"), width=4,
                                 b_init_scale=0.1)
    X = {"x": torch.randint(0, 8, (8, 5), generator=torch.Generator().manual_seed(0))}
    return g, iid, X


def test_gru_jvp_runs_with_cudnn_scoped_off_and_matches_central_differences():
    g, iid, X = _tiny_gru()
    imp = g.implants[iid]
    v = D._values(g, X, [imp.entry, imp.exit], 16)
    W, b, _ = D._fit(v[imp.entry].reshape(-1, 8), v[imp.exit].reshape(-1, 8))
    before = torch.backends.cudnn.enabled
    r = D.jvp_sensitivity(g, iid, W, b, X)
    assert torch.backends.cudnn.enabled == before and "cudnn disabled for RNN" in r["jvp_backend"]
    H, Y = v[imp.entry], v[imp.exit]
    R = (Y.reshape(-1, 8).double() - D._apply(W, b, H.reshape(-1, 8))).reshape(Y.shape)
    eps = 1e-5

    def out(z):
        g.value_patch = {imp.exit: (lambda t, z=z: z)}
        try:
            with torch.no_grad():
                return g(D.eval_inputs(g, X)).double()
        finally:
            g.value_patch = None
    fd = (out(Y + eps * R) - out(Y - eps * R)) / (2 * eps)
    assert r["jvp_residual"] == pytest.approx(float((fd.reshape(fd.shape[0], -1) ** 2).sum(1).mean()), rel=1e-6)


@CUDA
def test_cuda_transformer_and_fp64_diagnostics(tmp_path):
    g, iid, X = _tiny_transformer()
    g = g.cuda()
    X = {k: v.cuda() for k, v in X.items()}
    imp = g.implants[iid]
    v = D._values(g, X, [imp.entry, imp.exit], 16)
    W, b, _ = D._fit(v[imp.entry].reshape(-1, 8), v[imp.exit].reshape(-1, 8))
    r = D.jvp_sensitivity(g, iid, W, b, X)
    assert math.isfinite(r["jvp_residual"]) and r["jvp_backend"].startswith("math")
    gg, gi, GX = _tiny_gru(torch.float32)
    gg = gg.cuda()
    GX = {k: v.cuda() for k, v in GX.items()}
    gimp = gg.implants[gi]
    gv = D._values(gg, GX, [gimp.entry, gimp.exit], 16)
    GW, Gb, _ = D._fit(gv[gimp.entry].reshape(-1, 8), gv[gimp.exit].reshape(-1, 8))
    gr = D.jvp_sensitivity(gg, gi, GW, Gb, GX)                # cuDNN GRU has no double backward
    assert math.isfinite(gr["jvp_residual"]) and torch.backends.cudnn.enabled
    cfg = T.base(train={**T.TRAIN, "precision": "fp64"})
    bundle = load_bundle(cfg["data"], device="cuda")
    m = build_mlp(8, [16, 16], 3, torch_gen(0, "init")).double().cuda()
    i2 = E.insert_residual_zero(m, E.cut_at(m, "post_act", 0), torch_gen(0, "insertion", "c"), width=4,
                                b_init_scale=0.5)
    m.cuda()
    before = _fingerprints(m)
    rec = D.contraction_diagnostics(_ctx(tmp_path / "c", cfg), m, bundle, [i2], "t")
    assert rec["implants"][i2]["complete"] and rec["state_unchanged"] and _fingerprints(m) == before
    SEQ = {"name": "seq_select", "n_train": 256, "n_val": 128, "n_test": 128}
    p = T.traj({"topology": "layered", "rounds": 1, "cut_kind": "resid"}, data=SEQ,
               model={"family": "transformer", "depth": 2, "width": 16})
    d = T.child("dissipation", p[-1], {"dissipation": {"method": "linear", "speed_updates": 4, "post_updates": 4}})
    for c in p + [d]:
        assert run_job(c, tmp_path / "jobs", {"device": "cuda"}) == "complete"
    rec = read_json(tmp_path / "jobs" / "runs" / run_id(d) / "contraction_diagnostics.json")["dissipation_start"]
    assert rec["complete"], rec


# ----------------------------------------------------------------------------- V7-03

def _grid_cfg(b, fams, upd):
    return resolve({"kind": "transplant", "data": T.DATA, "model": T.MODEL, "train": T.TRAIN,
                    "seeds": {"optimizer": 0}, "parents": {"upstream": run_id(b), "downstream": run_id(b)},
                    "transplant": {"upstream_stage": "baseline", "downstream_stage": "baseline", "design": "grid",
                                   "align_families": fams, "adapter_updates": upd}})


def _inject_nan_grads(when):
    """Patch Trainer.run so the alignment gradients become NaN on the chosen adapter_fit updates."""
    from cop.train.trainer import Trainer
    original = Trainer.run

    def run(self, seg, *a, **k):
        handles = []
        if seg.name == "adapter_fit":
            count = {"n": 0}
            for n in self.model.nodes.values():
                if n.role == "alignment":
                    for p in self.model.mods[n.pkey].parameters():
                        def hook(grad, p=p):
                            return torch.full_like(grad, float("nan")) if when(self) else grad
                        handles.append(p.register_hook(hook))
        try:
            return original(self, seg, *a, **k)
        finally:
            for h in handles:
                h.remove()
    return patch.object(Trainer, "run", run)


@pytest.mark.parametrize("case", ["loss_before_any_update", "first_update", "final_update"])
def test_divergent_task_adapters_are_ineligible_and_never_enter_contrasts(tmp_path, case, monkeypatch):
    from cop.analysis.v5_tables import transplant_grid_table
    import cop.train.trainer as TRm
    b = T.base()
    assert run_job(b, tmp_path, {"device": "cpu"}) == "complete"
    upd = 3
    tp = _grid_cfg(b, ["identity", "affine_task"], upd)
    if case == "loss_before_any_update":
        real = TRm.task_loss
        monkeypatch.setattr(TRm, "task_loss", lambda out, y, task: real(out, y, task) * float("nan"))
        st = run_job(tp, tmp_path, {"device": "cpu"})
        monkeypatch.setattr(TRm, "task_loss", real)
    else:
        when = (lambda trn: True) if case == "first_update" else \
            (lambda trn: int(trn.state["global_step"]) >= upd - 1)
        with _inject_nan_grads(when):
            st = run_job(tp, tmp_path, {"device": "cpu"})
    status = status_of(tmp_path, run_id(tp))
    assert st == "complete" and status["validity"] == "unverified", status
    rd = tmp_path / "runs" / run_id(tp)
    res = read_json(rd / "transplant_result.json")
    A = res["info"]["assemblies"]
    done = [res["info"]["fits"][f"{x}_affine_task"]["updates_done"] for x in ("Aup_Adown", "Bup_Adown")]
    if case == "loss_before_any_update":
        assert done == [0, 0]
    elif case == "final_update":
        assert done == [upd, upd]
    assert all(not A[f"{x}_affine_task"]["eligible"] for x in ("Aup_Adown", "Bup_Adown", "Aup_Bdown", "Bup_Bdown"))
    assert all(A[f"{x}_identity"]["eligible"] for x in ("Aup_Adown", "Bup_Adown", "Aup_Bdown", "Bup_Bdown"))
    for part, c in res["contrasts"]["affine_task"].items():
        assert c["new_upstream_gain_on_old_downstream"] is None and c["R_A"] is None
        assert res["contrast_eligibility"]["affine_task"][part]["eligible"] is False
    assert all(e["eligible"] for e in res["contrast_eligibility"]["identity"].values())
    assert all(isinstance(v, (int, float)) or v is None for c in res["contrasts"].values() for x in c.values()
               for v in x.values())                              # contrasts stay numeric (scanner-compatible)
    rows = transplant_grid_table({run_id(tp): {"dir": rd, "cfg": tp, "status": status}})
    bad = [r for r in rows if r["family_adapter"] == "affine_task"]
    good = [r for r in rows if r["family_adapter"] == "identity"]
    assert bad and all(not r["eligible"] and r["R_A"] is None and "diverged" in r["ineligibility_reasons"]
                       for r in bad)
    assert good and all(r["eligible"] and math.isfinite(r["R_A"]) for r in good)


@pytest.mark.parametrize("bad", ["nan", "inf", "-inf", float("nan"), float("inf")])
def test_historical_grid_results_with_serialised_nonfinite_values_are_quarantined(tmp_path, bad):
    from cop.analysis.v5_tables import transplant_grid_table
    keys = ["Aup_Adown_affine_task", "Bup_Adown_affine_task", "Aup_Bdown_affine_task", "Bup_Bdown_affine_task"]
    j = {"info": {"design": "grid", "fits": {k: {"kind": "affine_task", "diverged": False, "params": 4} for k in keys}},
         "rows": {k: {"test": {"mse": 0.5}} for k in keys},
         "contrasts": {"affine_task": {"test": {"R_A": 0.5, "R_B": 0.4, "R_Bup_Adown": 0.45, "R_Aup_Bdown": 0.48,
                                                "new_upstream_gain_on_old_downstream": 0.05,
                                                "new_downstream_gain_with_old_upstream": 0.02}}}}
    j["rows"]["Bup_Adown_affine_task"]["test"]["mse"] = bad
    j["contrasts"]["affine_task"]["test"]["R_Bup_Adown"] = bad
    (tmp_path / "transplant_result.json").write_text(json.dumps(j))
    cfg = {"design": {"contrast": "c"}, "transplant": {}, "parents": {}}
    rows = transplant_grid_table({"r": {"dir": tmp_path, "cfg": cfg, "status": {"status": "complete"}}})
    assert len(rows) == 1 and rows[0]["eligible"] is False and rows[0]["R_Bup_Adown"] is None
    assert "Bup_Adown_affine_task" in rows[0]["ineligibility_reasons"]
    # a diverged historical fit is quarantined even when every number looks finite
    j["rows"]["Bup_Adown_affine_task"]["test"]["mse"] = 0.45
    j["contrasts"]["affine_task"]["test"]["R_Bup_Adown"] = 0.45
    j["info"]["fits"]["Aup_Bdown_affine_task"]["diverged"] = True
    (tmp_path / "transplant_result.json").write_text(json.dumps(j))
    rows = transplant_grid_table({"r": {"dir": tmp_path, "cfg": cfg, "status": {"status": "complete"}}})
    assert rows[0]["eligible"] is False and "diverged" in rows[0]["ineligibility_reasons"]


# ----------------------------------------------------------------------------- V7-04

def _py(args, cwd=ROOT):
    return subprocess.run([sys.executable] + [str(a) for a in args], capture_output=True, text=True, cwd=cwd)


def _resume_with(tmp_path, result, case="diss_diagnostics"):
    """Run the real resume helper with compare_interrupted replaced by a fixed result."""
    tmp_path.mkdir(parents=True, exist_ok=True)
    w = tmp_path / "wrap.py"
    w.write_text("import sys, runpy\n"
                 f"sys.path[:0] = {[str(ROOT), str(ROOT / 'tests')]!r}\n"
                 "import resume_harness\n"
                 f"resume_harness.compare_interrupted = lambda *a, **k: {result!r}\n"
                 f"sys.argv = {['resume_comparisons_v5.py', str(tmp_path / 'out'), case]!r}\n"
                 f"runpy.run_path({str(ROOT / 'audit_v5/tools/resume_comparisons_v5.py')!r}, run_name='__main__')\n")
    return _py([w])


def test_resume_helper_exit_status_follows_its_verdict(tmp_path):
    bad = _resume_with(tmp_path / "a", {"equal": False, "polls_uninterrupted": 10, "interrupted_at_polls": [3],
                                        "error": "injected mismatch"})
    assert bad.returncode == 1 and "injected mismatch" in bad.stdout
    rep = read_json(tmp_path / "a" / "out" / "report.json")
    assert rep["_verdict"]["passed"] is False
    noint = _resume_with(tmp_path / "b", {"equal": True, "polls_uninterrupted": 10, "interrupted_at_polls": []})
    assert noint.returncode == 1                                   # never interrupted: no coverage
    empty = _resume_with(tmp_path / "c", {"equal": True}, case="no_such_case")
    assert empty.returncode == 1                                   # empty / unknown check set
    good = _resume_with(tmp_path / "d", {"equal": True, "polls_uninterrupted": 10, "interrupted_at_polls": [3],
                                         "checkpoints_differing": [], "n_metrics_differing": 0,
                                         "results_differing": [], "work_equal": True})
    assert good.returncode == 0, good.stdout + good.stderr
    from cop.analysis.gates import resume_verdict
    v = resume_verdict({"t": {"polls_uninterrupted": 0, "not_interruptible": True, "outputs_equal": True}},
                       allow_not_interruptible={"t"})
    assert v["passed"] and v["repeatability_only"] == ["t"] and not v["interruption_covered"]
    assert not resume_verdict({"t": {"polls_uninterrupted": 0, "not_interruptible": True, "outputs_equal": True}})["passed"]


def test_fresh_reload_fails_on_corrupt_or_missing_artifacts_and_on_an_empty_set(tmp_path):
    b = T.base()
    assert run_job(b, tmp_path / "res", {"device": "cpu"}) == "complete"
    tool = ROOT / "audit_v5/tools/fresh_reload.py"
    ok = _py([tool, tmp_path / "res", tmp_path / "ok.json"])
    assert ok.returncode == 0, ok.stdout + ok.stderr
    assert read_json(tmp_path / "ok.json")["summary"]["n_checked"] >= 1
    pred = tmp_path / "res" / "runs" / run_id(b) / "preds" / "endpoint__test.pt"
    orig = torch.load(pred, weights_only=False)
    torch.save(orig + 1.0, pred)
    corrupt = _py([tool, tmp_path / "res", tmp_path / "corrupt.json"])
    assert corrupt.returncode == 1
    torch.save(orig * float("nan"), pred)
    nonfinite = _py([tool, tmp_path / "res", tmp_path / "nan.json"])
    assert nonfinite.returncode == 1 and "non-finite" in nonfinite.stdout
    pred.unlink()
    missing = _py([tool, tmp_path / "res", tmp_path / "missing.json"])
    assert missing.returncode == 1 and "missing saved predictions" in missing.stdout
    (tmp_path / "empty" / "runs").mkdir(parents=True)
    empty = _py([tool, tmp_path / "empty", tmp_path / "empty.json"])
    assert empty.returncode == 1 and "empty check set" in empty.stdout


def test_results_checker_requires_complete_diagnostics_and_a_nonempty_check_set(tmp_path):
    tool = ROOT / "audit_v8/tools/check_results.py"
    (tmp_path / "runs" / "r1").mkdir(parents=True)
    assert _py([tool, tmp_path, tmp_path / "none.json"]).returncode == 1          # no check requested
    assert _py([tool, tmp_path, tmp_path / "d0.json", "--diagnostics"]).returncode == 1   # no rows at all
    rec = {"dissipation_start": {"implants": {"I1": {"complete": True, "fit_status": "ok"}}}}
    (tmp_path / "runs" / "r1" / "contraction_diagnostics.json").write_text(json.dumps(rec))
    assert _py([tool, tmp_path, tmp_path / "d1.json", "--diagnostics"]).returncode == 0
    rec["dissipation_start"]["implants"]["I2"] = {"complete": False, "jvp_status": "failed", "error": "jvp: x"}
    (tmp_path / "runs" / "r1" / "contraction_diagnostics.json").write_text(json.dumps(rec))
    bad = _py([tool, tmp_path, tmp_path / "d2.json", "--diagnostics"])
    assert bad.returncode == 1 and "jvp" in bad.stdout


def test_resume_helper_real_case_passes(tmp_path):
    r = _py([ROOT / "audit_v5/tools/resume_comparisons_v5.py", tmp_path / "real", "witness_baseline"])
    assert r.returncode == 0, r.stdout[-2000:] + r.stderr[-2000:]
    v = read_json(tmp_path / "real" / "report.json")["_verdict"]
    assert v["passed"] and v["interruption_covered"] == ["witness_baseline"]


# ----------------------------------------------------------------------------- V7-05

CRIT = {"criteria": {"identity_rel_tol_fp32": 1e-5, "identity_rel_tol_fp64": 1e-10}}


def _gate_obj(sets, dtype=torch.float32):
    from cop.experiments.trajectory import Trajectory  # noqa: F401
    ctx = SimpleNamespace(metrics=lambda *a, **k: None, metric=lambda *a, **k: None, log=lambda *a, **k: None,
                          save_ckpt=lambda *a, **k: None, save_graph=lambda *a, **k: None)
    return SimpleNamespace(ctx=ctx, cfg=T.base(), dtype=dtype, sets=sets)


def _cancellation_pair():
    """The audit's example: f(x) = x; post-edit h(x) = ((x + 1e8) - 1e8) + 0.25, float32."""
    g = build_mlp(1, [1, 1], 1, torch_gen(0, "init"), act="identity")
    h = g.clone(share_params=False)
    lins = [n for n in g.topo_order() if g.nodes[n].op == "linear"]
    with torch.no_grad():
        for net in (g, h):
            for n in lins:
                net.mods[net.nodes[n].pkey].weight.fill_(1.0)
                net.mods[net.nodes[n].pkey].bias.zero_()
        h.mods[h.nodes[lins[0]].pkey].bias.fill_(1e8)
        h.mods[h.nodes[lins[1]].pkey].bias.fill_(-1e8)
        h.mods[h.nodes[lins[2]].pkey].bias.fill_(0.25)
    return g, h


def test_cancellation_example_is_not_labelled_exact():
    from cop.experiments.trajectory import Trajectory
    from cop.experiments import common as Cm
    from cop.experiments.context import ScientificInvalid
    g, h = _cancellation_pair()
    sets = {"calibration": {"x": torch.tensor([[1.0], [2.0], [3.0]])}}
    chk = Cm.identity_check(g, h, sets, torch.float32, CRIT)
    assert chk["verdict"] in ("execution_changed", "changed") and chk["verdict"] != "exact"
    # 0.25 / s with s = max(mean|f|, mean|h|) = max(2, 2.25) (v13: symmetric reference scale)
    assert chk["sets"]["calibration"]["a_high_precision"] == pytest.approx(0.25 / 2.25)
    with pytest.raises(ScientificInvalid, match="L0_"):
        Trajectory.insertion_gate(_gate_obj(sets), h, Cm.outputs_on(g, sets), [], "probe", pre=g)


def test_identity_check_cases():
    from cop.experiments import common as Cm
    G = lambda k: torch_gen(0, "insertion", "v8", k)
    X = {"cal": {"x": torch.randn(256, 8, generator=torch.Generator().manual_seed(0))}}
    # legitimate function-preserving constructions, float32 and float64 storage
    for dt in (torch.float32, torch.float64):
        g = build_mlp(8, [16, 16], 3, torch_gen(0, "init")).to(dt)
        for build in (lambda h: E.insert_residual_zero(h, E.cut_at(h, "post_act", 0), G("r"), width=4),
                      lambda h: E.insert_linear_factor(h, E.cut_at(h, "post_act", 1), G("l")),
                      lambda h: E.factorize_node(h, [n for n in h.topo_order() if h.nodes[n].op == "linear"][1], G("f"))):
            h = g.clone(share_params=False)
            build(h)
            assert Cm.identity_check(g, h, X, dt, CRIT)["verdict"] == "exact", (dt, build)
    g = build_mlp(8, [16, 16], 3, torch_gen(0, "init"))
    # a genuinely changed function
    h = g.clone(share_params=False)
    E.insert_residual_zero(h, E.cut_at(h, "post_act", 0), G("c"), width=4, b_init_scale=0.5)
    assert Cm.identity_check(g, h, X, torch.float32, CRIT)["verdict"] == "changed"
    # ill-conditioned inverse pair: exact in exact arithmetic, not certifiable from float32 storage
    for cond, ok in ((1.0, True), (1e7, False)):
        h = g.clone(share_params=False)
        E.insert_inverse_pair(h, E.cut_at(h, "post_act", 0), G(f"i{cond}"), kind="linear", cond=cond)
        v = Cm.identity_check(g, h, X, torch.float32, CRIT)["verdict"]
        assert (v == "exact") == ok, (cond, v)
    # low output scale: relative comparisons are inconclusive
    z = g.clone(share_params=False)
    head = [n for n in z.topo_order() if z.nodes[n].role == "head"][0]
    with torch.no_grad():
        z.mods[z.nodes[head].pkey].weight.mul_(1e-12)
        z.mods[z.nodes[head].pkey].bias.zero_()
    assert Cm.identity_check(z, z.clone(share_params=False), X, torch.float32, CRIT)["verdict"] == "low_scale"
    # non-finite outputs fail, and each input set is judged on its own
    h = g.clone(share_params=False)
    E.insert_residual_zero(h, E.cut_at(h, "post_act", 0), G("n"), width=4)
    sets = {"cal": X["cal"], "stress": {"x": torch.full((4, 8), 1e38)}}
    chk = Cm.identity_check(g, h, sets, torch.float32, CRIT)
    assert chk["verdict"] == "nonfinite"
    assert chk["sets"]["cal"]["verdict"] == "exact" and chk["sets"]["stress"]["verdict"] == "nonfinite"


def test_digits_control_case_passes_without_tolerance_inflation(tmp_path):
    """The v7 lab case (float32 node factorisation on digits) passes the v8 rule; no tolerance is derived
    from the case."""
    cfg = resolve({"kind": "control", "data": {"name": "digits"}, "model": {"family": "mlp", "width": 64, "depth": 4},
                   "control": {"device": "cpu", "checks": ["insertions"], "dtypes": ["float32", "float64"]}})
    assert run_job(cfg, tmp_path, {"device": "cpu"}) == "complete", status_of(tmp_path, run_id(cfg))
    r = read_json(tmp_path / "runs" / run_id(cfg) / "control_results.json")
    nf = [x for x in r["records"] if x.get("construction") == "node_factorization"]
    assert nf and all(x["pass"] and x["identity_verdict"] == "exact" for x in nf)
    assert all(x["tolerance_rel"] in (1e-5, 1e-10) for x in r["records"] if "tolerance_rel" in x)


# ----------------------------------------------------------------------------- V7-06

@pytest.mark.parametrize("bad", ["nan", "inf", "-inf", float("nan"), float("inf"), float("-inf")])
def test_nonfinite_deletion_utilities_give_an_invalid_landscape_not_a_crash(bad):
    from cop.analysis.dependence_game import game_from_deletions, analyse_game
    dele = {"stage": "final", "info": {"exhaustive": True, "atoms": ["I1"]},
            "rows": [{"atoms": ["I1"], "metrics": {"val": {"delta_risk": bad}}}]}
    g = game_from_deletions(dele, "val")                      # the audit's negative-shift case
    assert g["exact"] is False and "non-finite" in g["reason"]
    assert analyse_game([0.0, float(bad)], 1)["exact"] is False
    ref = {"stage": "final", "info": {"exhaustive": True, "atoms": ["I1"]}, "base": {"val": {"loss": bad}},
           "rows": [{"atoms": ["I1"], "metrics": {"val": {"delta_risk": 0.1}}}]}
    assert game_from_deletions(ref, "val")["exact"] is False


def test_finite_landscapes_keep_their_results_and_one_bad_file_does_not_abort_the_summary(tmp_path):
    from cop.analysis.dependence_game import game_from_deletions
    from cop.analysis.v5_tables import dependence_games
    rows = [{"atoms": [], "metrics": {"val": {"delta_risk": 0.0}}}, {"atoms": ["a"], "metrics": {"val": {"delta_risk": 1.0}}},
            {"atoms": ["b"], "metrics": {"val": {"delta_risk": 1.0}}},
            {"atoms": ["a", "b"], "metrics": {"val": {"delta_risk": 0.0}}}]
    good = {"stage": "final", "info": {"exhaustive": True, "atoms": ["a", "b"]}, "partitions": ["val"], "rows": rows,
            "base": {"val": {"loss": 0.3}}}
    g = game_from_deletions(good, "val", taus=(0.5,))
    assert g["exact"] and g["shapley"] == {"a": 0.0, "b": 0.0} and g["pair_at_empty"]["a,b"] == -2.0
    bad = json.loads(json.dumps(good))
    bad["rows"][1]["metrics"]["val"]["delta_risk"] = "nan"
    for name, d in (("good", good), ("bad", bad)):
        rd = tmp_path / name
        rd.mkdir()
        (rd / "deletions_final.json").write_text(json.dumps(d))
    runs = {n: {"dir": tmp_path / n, "cfg": {"criteria": {}}, "status": {"status": "complete", "validity": "valid"}}
            for n in ("good", "bad")}
    runs["unverified"] = {"dir": tmp_path / "good", "cfg": {}, "status": {"status": "complete", "validity": "unverified"}}
    full, flat = dependence_games(runs)
    by = {r["run_id"]: r for r in flat}
    assert by["good"]["exact"] is True and by["bad"]["exact"] is False and "non-finite" in by["bad"]["reason"]
    assert by["unverified"]["exact"] is False and "not included" in by["unverified"]["reason"]


# ----------------------------------------------------------------------------- V7-07

def test_review_archive_contains_the_v4_v5_evidence_and_an_inventory(tmp_path):
    import zipfile
    from cop.analysis.package import package_for_review
    R = tmp_path / "res"
    b = T.base(data=RELU_DATA, model={"family": "mlp", "width": 16, "depth": 4, "act": "relu"})
    p = T.traj({"topology": "layered", "rounds": 1})
    d = T.child("dissipation", p[-1], {"dissipation": {"method": "linear", "speed_updates": 4, "post_updates": 4}})
    tp = _grid_cfg(p[0], ["identity", "affine"], 2)
    _run([b] + p + [d, tp], R)
    out = tmp_path / "review.zip"
    package_for_review(str(R), str(out), str(ROOT / "manifests"), max_ckpt_mb=500)
    names = set(zipfile.ZipFile(out).namelist())
    want = []
    for rd in (R / "runs").iterdir():
        for f in ("endpoint.json", "contraction_diagnostics.json", "transplant_result.json", "witness.json"):
            if (rd / f).exists():
                want.append(f"results/runs/{rd.name}/{f}")
        want += [f"results/runs/{rd.name}/diagnostics/{f.name}" for f in (rd / "diagnostics").glob("*.pt")] \
            if (rd / "diagnostics").exists() else []
        want += [f"results/runs/{rd.name}/ckpt/{f.name}" for f in (rd / "ckpt").glob("transplant_*.pt")]
        if (rd / "ckpt" / "witness.pt").exists():
            want.append(f"results/runs/{rd.name}/ckpt/witness.pt")
        ep = read_json(rd / "endpoint.json") if (rd / "endpoint.json").exists() else None
        if ep:
            want.append(f"results/runs/{rd.name}/ckpt/{ep['checkpoint']}.pt")
    assert any("contraction_diagnostics" in w for w in want) and any("transplant_" in w for w in want)
    assert any(w.endswith("witness.pt") for w in want)
    missing = [w for w in want if f"review/{w}" not in names]
    assert not missing, missing
    assert "review/results/INVENTORY.json" in names
    # with a tiny binary budget every omitted checkpoint is listed with its reason
    small = tmp_path / "small.zip"
    package_for_review(str(R), str(small), str(ROOT / "manifests"), max_ckpt_mb=0.0001)
    inv = json.loads(zipfile.ZipFile(small).read("small/results/INVENTORY.json"))
    assert inv["omitted"] and all("budget" in o["reason"] for o in inv["omitted"] if "ckpt/" in o["path"])
    assert any(o["path"].endswith("witness.pt") for o in inv["omitted"])


RELU_DATA = {"name": "teacher", "n_train": 256, "n_val": 128, "n_test": 128,
             "params": {"teacher_depth": 2, "teacher_width": 12, "activation": "relu", "task": "regression", "d_in": 8,
                        "out_dim": 3}}


# ----------------------------------------------------------------------------- recovery tooling

def _v7_style_error(rd, tag, iid=None):
    """Turn one complete record into what v7 wrote on failure (error row, no JVP), as in the audit's CSV."""
    p = rd / "contraction_diagnostics.json"
    store = read_json(p)
    rows = store[tag]["implants"]
    iid = iid or next(k for k, v in rows.items() if "skipped" not in v)
    row = rows[iid]
    for k in [k for k in row if k.startswith("jvp") or k.endswith("_status") or k == "complete"]:
        row.pop(k)
    row["error"] = "RuntimeError: mat1 and mat2 must have the same dtype, but got Float and Double"
    p.write_text(json.dumps(store))
    return iid


def test_recompute_dissipation_diagnostics_from_the_parent_checkpoint_keeps_the_original(tmp_path):
    from cop.analysis import recovery as RV
    from cop.analysis.gates import diagnostics_verdict
    p = T.traj({"topology": "layered", "rounds": 1})
    d = T.child("dissipation", p[-1], {"dissipation": {"method": "linear", "speed_updates": 4, "post_updates": 4}})
    rd = _run(p + [d], tmp_path)
    iid = _v7_style_error(rd, "dissipation_start")
    before = (rd / "contraction_diagnostics.json").read_bytes()
    assert not diagnostics_verdict(tmp_path)["passed"]
    man = RV.recovery_manifest(str(tmp_path))
    assert man["runs"][rd.name]["categories"] == ["needs_diagnostic_recompute"]
    s = RV.recompute_diagnostics(str(tmp_path))
    assert s["written"] == [f"{rd.name}:dissipation_start"]
    doc = read_json(tmp_path / "recomputed_diagnostics" / f"{rd.name}.json")
    r = doc["records"]["dissipation_start"]
    assert r["status"] == "ok" and r["reproduces_original_pre_contraction_risk"]
    assert r["source"]["kind"] == "parent_checkpoint" and r["source"]["recorded_param_hash"] == r["source"]["loaded_param_hash"]
    assert r["record"]["implants"][iid]["complete"] and r["original_incomplete_rows"] == [iid]
    assert (rd / "contraction_diagnostics.json").read_bytes() == before          # original untouched
    v = diagnostics_verdict(tmp_path)
    assert v["passed"] and v["resolved_by_recompute"]
    assert RV.recovery_manifest(str(tmp_path))["runs"][rd.name]["categories"] == ["reusable_unchanged"]


def test_cycle_without_a_pre_contraction_checkpoint_is_replayed_and_checked_against_the_original(tmp_path):
    from cop.analysis import recovery as RV
    cfgs = T.traj({"topology": "layered", "rounds": 2, "contract_every": 1, "contract_updates": 4})
    rd = _run(cfgs, tmp_path / "res")
    assert (rd / "ckpt" / "pre_contraction_r1.pt").exists()                   # v8 saves it
    for f in (rd / "ckpt").glob("pre_contraction_r*.pt"):
        f.unlink()                                                              # what a v7 run looks like
    tag = next(t for t in read_json(rd / "contraction_diagnostics.json") if t.startswith("contraction_c"))
    _v7_style_error(rd, tag)
    man = RV.recovery_manifest(str(tmp_path / "res"))
    assert "needs_cycle_replay" in man["runs"][rd.name]["categories"]
    assert RV.recompute_diagnostics(str(tmp_path / "res"))["needs_replay"]
    out = RV.replay_cycles(str(tmp_path / "res"), str(tmp_path / "scratch"))
    assert out[rd.name]["history_reproduced"], out
    assert all(v["equal"] for v in out[rd.name]["rounds"].values())
    r = read_json(tmp_path / "res" / "recomputed_diagnostics" / f"{rd.name}.json")["records"][tag]
    assert r["status"] == "ok" and r["source"]["kind"] == "replayed_pre_contraction_checkpoint"
    assert not (rd / "ckpt" / "pre_contraction_r1.pt").exists()                # the results dir gained nothing


def test_recovery_manifest_flags_failed_adapters_and_identity_rechecks(tmp_path, monkeypatch):
    from cop.analysis import recovery as RV
    import cop.train.trainer as TRm
    b = T.base()
    assert run_job(b, tmp_path, {"device": "cpu"}) == "complete"
    tp = _grid_cfg(b, ["identity", "affine_task"], 2)
    real = TRm.task_loss
    monkeypatch.setattr(TRm, "task_loss", lambda out, y, task: real(out, y, task) * float("nan"))
    run_job(tp, tmp_path, {"device": "cpu"})
    monkeypatch.setattr(TRm, "task_loss", real)
    p = T.traj({"topology": "layered", "rounds": 1})
    rd = _run(p, tmp_path)
    # a v7 metric row: the relaxed gate recorded tolerance 8 x roundoff above the declared 1e-5
    with open(rd / "metrics.jsonl", "a") as f:
        f.write(json.dumps({"metric_name": "insertion_label", "stage": "insert_r1", "metric_value": "exact",
                            "tolerance_rel": 7.4e-5, "roundoff_floor_rel": 9.2e-6}) + "\n")
    man = RV.recovery_manifest(str(tmp_path))
    assert "needs_adapter_refit" in man["runs"][run_id(tp)]["categories"]
    assert "needs_identity_recheck" in man["runs"][rd.name]["categories"]
    chk = RV.recheck_insertions(str(tmp_path))
    assert chk["rechecked"][f"{rd.name}:insert_r1"]["verdict"] == "exact"


# ----------------------------------------------------------------------------- independent review of v8

def test_replay_refuses_a_scratch_folder_inside_the_results_or_not_its_own(tmp_path):
    from cop.analysis import recovery as RV
    cfgs = T.traj({"topology": "layered", "rounds": 2, "contract_every": 1, "contract_updates": 4})
    rd = _run(cfgs, tmp_path / "res")
    for f in (rd / "ckpt").glob("pre_contraction_r*.pt"):
        f.unlink()
    tag = next(t for t in read_json(rd / "contraction_diagnostics.json") if t.startswith("contraction_c"))
    _v7_style_error(rd, tag)
    for bad in (tmp_path / "res", tmp_path / "res" / "scratch", tmp_path):
        with pytest.raises(ValueError, match="outside the results"):
            RV.replay_cycles(str(tmp_path / "res"), str(bad))
    foreign = tmp_path / "scr" / rd.name
    foreign.mkdir(parents=True)
    (foreign / "precious.txt").write_text("keep")
    with pytest.raises(ValueError, match="not created by replay-cycles"):
        RV.replay_cycles(str(tmp_path / "res"), str(tmp_path / "scr"))
    assert (foreign / "precious.txt").read_text() == "keep"
    # vacuous history: without any original round / post-insert checkpoint the replay is not trusted
    for f in list((rd / "ckpt").glob("round_*.pt")) + list((rd / "ckpt").glob("post_insert_r*.pt")):
        f.unlink()
    out = RV.replay_cycles(str(tmp_path / "res"), str(tmp_path / "scr2"))
    assert out[rd.name]["history_reproduced"] is False and "no round_" in out[rd.name]["reason"]
    assert not (tmp_path / "res" / "recomputed_diagnostics" / f"{rd.name}.json").exists()


def test_an_incomplete_recomputation_is_not_ok_and_can_be_retried(tmp_path, monkeypatch):
    from cop.analysis import recovery as RV
    from cop.analysis.gates import diagnostics_verdict
    p = T.traj({"topology": "layered", "rounds": 1})
    d = T.child("dissipation", p[-1], {"dissipation": {"method": "linear", "speed_updates": 4, "post_updates": 4}})
    rd = _run(p + [d], tmp_path)
    _v7_style_error(rd, "dissipation_start")
    real = D.jvp_sensitivity
    monkeypatch.setattr(D, "jvp_sensitivity", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("injected jvp")))
    RV.recompute_diagnostics(str(tmp_path))
    r = read_json(tmp_path / "recomputed_diagnostics" / f"{rd.name}.json")["records"]["dissipation_start"]
    assert r["status"].startswith("incomplete") and r["reproduces_original_pre_contraction_risk"]
    assert not diagnostics_verdict(tmp_path)["passed"]
    assert RV.recovery_manifest(str(tmp_path))["runs"][rd.name]["categories"] == ["needs_diagnostic_recompute"]
    monkeypatch.setattr(D, "jvp_sensitivity", real)
    RV.recompute_diagnostics(str(tmp_path))                     # retry is not skipped
    r = read_json(tmp_path / "recomputed_diagnostics" / f"{rd.name}.json")["records"]["dissipation_start"]
    assert r["status"] == "ok" and diagnostics_verdict(tmp_path)["passed"]


def test_manifest_lists_unverified_runs_and_v7_relaxed_controls(tmp_path):
    from cop.analysis import recovery as RV
    b = T.base()
    assert run_job(b, tmp_path, {"device": "cpu"}) == "complete"
    rd = tmp_path / "runs" / run_id(b)
    st = read_json(rd / "status.json")
    (rd / "status.json").write_text(json.dumps({**st, "validity": "unverified", "validity_reasons": ["parent x"]}))
    (rd / "control_results.json").write_text(json.dumps({"records": [
        {"construction": "linear_factor", "dtype": "float32", "tolerance_rel": 8e-5, "roundoff_floor_rel": 1e-5}]}))
    e = RV.recovery_manifest(str(tmp_path))["runs"][rd.name]
    assert {"unverified_run", "needs_identity_recheck"} <= set(e["categories"])
    assert "reusable_unchanged" not in e["categories"]


def test_grid_table_respects_run_validity_and_keeps_jobs_that_did_not_complete(tmp_path):
    from cop.analysis.v5_tables import transplant_grid_table
    keys = ["Aup_Adown_identity", "Bup_Adown_identity", "Aup_Bdown_identity", "Bup_Bdown_identity"]
    j = {"info": {"design": "grid", "fits": {k: {"kind": "identity", "diverged": False, "params": 0} for k in keys}},
         "rows": {k: {"test": {"mse": 0.5}} for k in keys},
         "contrasts": {"identity": {"test": {"R_A": 0.5, "R_B": 0.4, "R_Bup_Adown": 0.45, "R_Aup_Bdown": 0.48}}}}
    (tmp_path / "transplant_result.json").write_text(json.dumps(j))
    cfg = {"design": {"contrast": "c"}, "transplant": {"design": "grid"}, "parents": {}}
    ok = transplant_grid_table({"r": {"dir": tmp_path, "cfg": cfg, "status": {"status": "complete"}}})
    assert ok and all(r["eligible"] for r in ok)
    bad = transplant_grid_table({"r": {"dir": tmp_path, "cfg": cfg, "status": {
        "status": "complete", "validity": "unverified", "validity_reasons": ["parent p is unverified"]}}})
    assert bad and not any(r["eligible"] for r in bad) and "parent p" in bad[0]["ineligibility_reasons"]
    own = transplant_grid_table({"r": {"dir": tmp_path, "cfg": cfg, "status": {
        "status": "complete", "validity": "unverified", "validity_reasons": ["transplant grid: 1 ineligible"]}}})
    assert all(r["eligible"] for r in own)                      # its own assembly reasons are judged per row
    failed = transplant_grid_table({"r": {"dir": tmp_path / "nope", "cfg": cfg,
                                          "status": {"status": "failed", "reason": "boom"}}})
    assert len(failed) == 1 and failed[0]["eligible"] is False and "failed" in failed[0]["ineligibility_reasons"]


@pytest.mark.parametrize("bad", ["abc", None, 1e300, {"x": 1}, [1.0]])
def test_odd_deletion_utilities_never_crash_or_enter_a_game(bad):
    from cop.analysis.dependence_game import game_from_deletions, analyse_game
    rows = [{"atoms": ["a"], "metrics": {"val": {"delta_risk": 0.5}}},
            {"atoms": ["b"], "metrics": {"val": {"delta_risk": 0.6}}},
            {"atoms": ["a", "b"], "metrics": {"val": {"delta_risk": bad}}}]
    dele = {"stage": "final", "info": {"exhaustive": True, "atoms": ["a", "b"]}, "rows": rows}
    g = game_from_deletions(dele, "val")
    assert g["exact"] is False and g.get("reason")
    assert analyse_game([0.0, 0.5, 0.6, bad], 2)["exact"] is False


def test_results_checker_transplant_flag_is_strict_and_if_any_is_explicit(tmp_path):
    tool = ROOT / "audit_v8/tools/check_results.py"
    (tmp_path / "runs" / "r1").mkdir(parents=True)
    strict = _py([tool, tmp_path, tmp_path / "t.json", "--transplants"])
    assert strict.returncode == 1 and "empty check set" in strict.stdout
    lax = _py([tool, tmp_path, tmp_path / "t2.json", "--transplants-if-any", "--diagnostics-if-any"])
    assert lax.returncode == 0, lax.stdout
    rep = read_json(tmp_path / "t2.json")
    assert rep["transplants"]["empty_check_set"] and rep["diagnostics"]["empty_check_set"]
    rec = {"dissipation_start": {"implants": {"I2": {"complete": False, "jvp_status": "failed", "error": "jvp: x"}}}}
    (tmp_path / "runs" / "r1" / "contraction_diagnostics.json").write_text(json.dumps(rec))
    assert _py([tool, tmp_path, tmp_path / "t3.json", "--diagnostics-if-any"]).returncode == 1


def test_fresh_reload_records_an_unreadable_checkpoint_as_a_failure(tmp_path):
    b = T.base()
    assert run_job(b, tmp_path / "res", {"device": "cpu"}) == "complete"
    rd = tmp_path / "res" / "runs" / run_id(b)
    ck = rd / "ckpt" / (read_json(rd / "endpoint.json")["checkpoint"] + ".pt")
    ck.write_bytes(b"not a checkpoint")
    r = _py([ROOT / "audit_v5/tools/fresh_reload.py", tmp_path / "res", tmp_path / "x.json"])
    assert r.returncode == 1 and "exception during reload check" in r.stdout
    assert read_json(tmp_path / "x.json")["_verdict"]["passed"] is False


def test_review_archive_includes_recomputed_diagnostics_and_transplant_parent_stages(tmp_path):
    import zipfile
    from cop.analysis.package import package_for_review, parent_stage_references
    R = tmp_path / "res"
    b = T.base()
    assert run_job(b, R, {"device": "cpu"}) == "complete"
    tp = _grid_cfg(b, ["identity"], 2)
    run_job(tp, R, {"device": "cpu"})
    (R / "recomputed_diagnostics").mkdir()
    (R / "recomputed_diagnostics" / "r.json").write_text("{}")
    refs = parent_stage_references([R / "runs" / run_id(tp)])
    t = tp["transplant"]
    assert {t["upstream_stage"], t["downstream_stage"]} <= set().union(*refs.values())
    out = tmp_path / "rv.zip"
    package_for_review(str(R), str(out), str(ROOT / "manifests"), max_ckpt_mb=500)
    names = set(zipfile.ZipFile(out).namelist())
    assert "rv/results/recomputed_diagnostics/r.json" in names
    for pid, stages in refs.items():
        for s_ in stages:
            assert f"rv/results/runs/{pid}/ckpt/{s_}.pt" in names


def test_cop_gate_fails_a_complete_job_with_an_incomplete_diagnostic(tmp_path):
    p = T.traj({"topology": "layered", "rounds": 1})
    d = T.child("dissipation", p[-1], {"dissipation": {"method": "linear", "speed_updates": 4, "post_updates": 4}})
    rd = _run(p + [d], tmp_path / "res")
    man = tmp_path / "m.jsonl"
    man.write_text("".join(json.dumps({"run_id": run_id(c), "cfg": c, "blocks": ["t"]}) + "\n" for c in p + [d]))
    gate = [sys.executable, "-m", "cop.cli", "gate", "--manifest", str(man), "--results", str(tmp_path / "res"),
            "--device", "cpu"]
    ok = subprocess.run(gate, capture_output=True, text=True, cwd=ROOT)
    assert ok.returncode == 0, ok.stdout + ok.stderr
    _v7_style_error(rd, "dissipation_start")
    bad = subprocess.run(gate, capture_output=True, text=True, cwd=ROOT)
    assert bad.returncode == 1 and "incomplete_diagnostics" in bad.stdout


def test_review_archive_bounds_predictions_and_maps_by_their_own_budget(tmp_path):
    import zipfile
    from cop.analysis.package import package_for_review
    b = T.base()
    assert run_job(b, tmp_path / "res", {"device": "cpu"}) == "complete"
    out = tmp_path / "ev.zip"
    package_for_review(str(tmp_path / "res"), str(out), str(ROOT / "manifests"), max_ckpt_mb=500, max_evidence_mb=0)
    inv = json.loads(zipfile.ZipFile(out).read("ev/results/INVENTORY.json"))
    om = [o for o in inv["omitted"] if "/preds/" in o["path"]]
    assert om and all("evidence size budget" in o["reason"] for o in om)


def test_recheck_covers_the_all_at_once_schedule_against_baseline_ref(tmp_path):
    from cop.analysis import recovery as RV
    p = T.traj({"topology": "layered", "rounds": 2, "schedule": "all_at_once"})
    rd = _run(p, tmp_path)
    assert (rd / "ckpt" / "post_insert_all.pt").exists() and (rd / "ckpt" / "baseline_ref.pt").exists()
    chk = RV.recheck_insertions(str(tmp_path), all_insertions=True)
    assert chk["rechecked"][f"{rd.name}:insert_all"]["verdict"] == "exact", chk
    assert not chk["unavailable"]


# ----------------------------------------------------------------------------- v9: device placement (lab GPU)

def test_fold_runs_on_the_models_device_not_on_cpu():
    """The lab's MLP CUDA controls failed in fold_implant: affine_map probed CUDA modules with a CPU tensor.
    The meta device reproduces the same mismatch on a CPU-only machine."""
    g = build_mlp(8, [16, 16], 3, torch_gen(0, "init")).double()
    c = E.cut_at(g, "post_act", "middle")
    iid = E.insert_linear_factor(g, c, torch_gen(0, "insertion", "fold"), width=g.node_dim(c.source) + 3)
    imp = g.implants[iid]
    h = g.clone(share_params=False).to("meta")
    W, b = E.affine_map(h, imp.entry, imp.exit, h.region(iid))
    assert W.device.type == "meta" and b.device.type == "meta"      # (fold_implant itself reads b on the host)
    X = {"x": torch.randn(5, 8, dtype=torch.float64, generator=torch.Generator().manual_seed(0))}
    with torch.no_grad():
        assert (g(X) - E.fold_implant(g, iid)(X)).abs().max() < 1e-10       # exactness on CPU unchanged


@CUDA
def test_cuda_mlp_fold_is_exact():
    g = build_mlp(8, [16, 16], 3, torch_gen(0, "init")).double().cuda()
    c = E.cut_at(g, "post_act", "middle")
    iid = E.insert_linear_factor(g, c, torch_gen(0, "insertion", "fold"), width=g.node_dim(c.source) + 3)
    X = {"x": torch.randn(5, 8, dtype=torch.float64, generator=torch.Generator().manual_seed(0)).cuda()}
    with torch.no_grad():
        assert (g(X) - E.fold_implant(g, iid)(X)).abs().max().item() < 1e-10


def _no_device_mismatch(fn):
    """Run fn on meta tensors.  A value read (.item(), float(), .cpu()) on meta is allowed to stop it; a
    cross-device operation is the bug class that failed on the lab GPU and must not occur."""
    try:
        fn()
    except (RuntimeError, NotImplementedError) as ex:
        msg = str(ex)
        assert "expected device" not in msg and "same device" not in msg, msg


def test_probe_cut_and_bottleneck_build_tensors_on_the_activation_device():
    import types
    from cop.data.bundle import Partition
    from cop.experiments.growth import Grower

    def probe():
        g = build_mlp(8, [16, 16, 16], 1, torch_gen(0, "init")).to("meta")
        tr = Partition({"x": torch.empty(64, 8, device="meta")}, torch.empty(64, 1, device="meta"),
                       aux={"z": torch.empty(64, 4, device="meta")})
        Grower({"cut_kind": "post_act"}, 0, types.SimpleNamespace(train=tr))._probe_cut(g, "probe:z")
    _no_device_mismatch(probe)

    def bottleneck():
        g = build_mlp(8, [16, 16], 3, torch_gen(0, "init")).to("meta")
        A = torch.linalg.qr(torch.randn(16, 4, dtype=torch.float64))[0].T.to("meta")
        E.insert_bottleneck(g, E.cut_at(g, "post_act", "middle"), torch_gen(0, "insertion", "b"), 4, A_init=A)
    _no_device_mismatch(bottleneck)


def test_mixing_aligned_known_module_is_fitted_on_cpu():
    from cop.experiments.growth import make_known_module
    gen = lambda: torch_gen(0, "insertion", "known")
    H = torch.randn(64, 8, dtype=torch.float64, generator=torch.Generator().manual_seed(1))
    y = torch.randint(0, 3, (64,), generator=torch.Generator().manual_seed(2))
    out = make_known_module("mixing_aligned", None, gen(), 8, d_src=8, src_train=H, y_train=y)
    W = [m for m in out[0].modules() if isinstance(m, torch.nn.Linear)][0].weight.detach().double()
    assert torch.allclose(W @ W.T, torch.eye(8, dtype=torch.float64), atol=1e-6)   # orthogonal mixing
    _no_device_mismatch(lambda: make_known_module("mixing_aligned", None, gen(), 8, d_src=8, src_train=H.to("meta"),
                                                  y_train=y.to("meta")))


@CUDA
def test_cuda_probe_cut_and_mixing_aligned():
    import types
    from cop.data.bundle import Partition
    from cop.experiments.growth import Grower, make_known_module
    g = build_mlp(8, [16, 16, 16], 1, torch_gen(0, "init")).cuda()
    tr = Partition({"x": torch.randn(64, 8).cuda()}, torch.randn(64, 1).cuda(), aux={"z": torch.randn(64, 4).cuda()})
    Grower({"cut_kind": "post_act"}, 0, types.SimpleNamespace(train=tr))._probe_cut(g, "probe:z")
    H, y = torch.randn(64, 8).cuda(), torch.randint(0, 3, (64,)).cuda()
    gen = lambda: torch_gen(0, "insertion", "known")
    W_gpu = [m for m in make_known_module("mixing_aligned", None, gen(), 8, d_src=8, src_train=H, y_train=y)[0]
             .modules() if isinstance(m, torch.nn.Linear)][0].weight
    W_cpu = [m for m in make_known_module("mixing_aligned", None, gen(), 8, d_src=8, src_train=H.cpu(),
                                          y_train=y.cpu())[0].modules() if isinstance(m, torch.nn.Linear)][0].weight
    assert torch.equal(W_gpu.cpu(), W_cpu)                    # the same map from CPU or GPU activations


# ----------------------------------------------------------------------------- v10: lab pilot summary crash

def test_summary_survives_nonfinite_dissipation_risks_and_a_failing_figure(tmp_path, monkeypatch):
    """The lab pilot's `cop summarize` crashed in Fig 7: a diverged dissipation path stored peak_risk as the
    JSON string 'inf' / 'nan'.  Such paths are counted, not drawn, and one failing figure never stops the rest."""
    from cop.analysis.summarize import summarize
    p = T.traj({"topology": "layered", "rounds": 1})
    d = T.child("dissipation", p[-1], {"dissipation": {"method": "linear", "speed_updates": 4, "post_updates": 4}})
    rd = _run(p + [d], tmp_path / "res")
    man = tmp_path / "m.jsonl"
    man.write_text("".join(json.dumps({"run_id": run_id(c), "cfg": c, "blocks": ["t"]}) + "\n" for c in p + [d]))
    j = read_json(rd / "dissipation_result.json")
    j["peak_risk"], j["final_risk"] = "inf", "nan"
    (rd / "dissipation_result.json").write_text(json.dumps(j))
    res = summarize(str(tmp_path / "res"), [str(man)], str(tmp_path / "sum"))
    assert "fig07_paths.png" in res["figures"] and not res["figure_errors"], res["figure_errors"]
    import matplotlib.axes
    monkeypatch.setattr(matplotlib.axes.Axes, "scatter", lambda *a, **k: (_ for _ in ()).throw(ValueError("boom")))
    res = summarize(str(tmp_path / "res"), [str(man)], str(tmp_path / "sum2"))
    assert res["figure_errors"] and "fig12_certificates.png" in res["figures"]       # later figures still made
    assert (tmp_path / "sum2" / "summary.json").exists()


# ----------------------------------------------------------------------------- v11: lab pilot gate failures

def test_a_child_of_a_recorded_invalid_parent_is_excluded_by_record_not_passed(tmp_path):
    """Lab pilot: an X1 trajectory diverged (recorded numerically invalid), its dissipation child measured the
    diverged model (JVP overflow) and exported non-finite predictions.  The diagnostic row is excluded by the
    parent's own record and listed; without that record the same row still fails."""
    from cop.analysis.gates import diagnostics_verdict
    from cop.analysis import recovery as RV
    p = T.traj({"topology": "layered", "rounds": 1})
    d = T.child("dissipation", p[-1], {"dissipation": {"method": "linear", "speed_updates": 4, "post_updates": 4}})
    rd = _run(p + [d], tmp_path / "res")
    _v7_style_error(rd, "dissipation_start")
    assert not diagnostics_verdict(tmp_path / "res")["passed"]
    par = tmp_path / "res" / "runs" / run_id(p[-1])
    ep = read_json(par / "endpoint.json")
    stage = (d.get("tags") or {}).get("parent_stage", "final")
    assert ep["checkpoint"] == stage
    (par / "endpoint.json").write_text(json.dumps({**ep, "numerically_valid": False, "diverged": True,
                                                    "numerical_reasons": ["diverged: injected"]}))
    v = diagnostics_verdict(tmp_path / "res")
    assert v["passed"] and len(v["excluded_source_recorded_invalid"]) == 1
    assert "recorded numerically invalid" in v["excluded_source_recorded_invalid"][0]["excluded_because"]
    assert "source_recorded_invalid" in RV.recovery_manifest(str(tmp_path / "res"))["runs"][rd.name]["categories"]
    # a different checkpoint of the same parent is not covered by that record
    (par / "endpoint.json").write_text(json.dumps({**ep, "checkpoint": "other", "numerically_valid": False}))
    assert not diagnostics_verdict(tmp_path / "res")["passed"]


def test_reload_accepts_a_recorded_invalid_endpoint_only_if_it_reproduces_exactly(tmp_path):
    b = T.base()
    assert run_job(b, tmp_path / "res", {"device": "cpu"}) == "complete"
    rd = tmp_path / "res" / "runs" / run_id(b)
    tool = ROOT / "audit_v5/tools/fresh_reload.py"
    pred = rd / "preds" / "endpoint__test.pt"
    orig = torch.load(pred, weights_only=False)
    torch.save(orig * float("inf"), pred)                         # saved predictions non-finite, reload finite
    ep = read_json(rd / "endpoint.json")
    (rd / "endpoint.json").write_text(json.dumps({**ep, "numerically_valid": False,
                                                  "numerical_reasons": ["non-finite endpoint metrics"]}))
    bad = _py([tool, tmp_path / "res", tmp_path / "bad.json"])
    assert bad.returncode == 1                                    # recorded invalid, but not reproduced
    torch.save(orig, pred)
    ok = _py([tool, tmp_path / "res", tmp_path / "ok.json"])
    assert ok.returncode == 0, ok.stdout
    s = read_json(tmp_path / "ok.json")["summary"]
    assert s["n_recorded_numerically_invalid"] == 1 and s["n_recorded_numerically_invalid_reproduced"] == 1
    # without the record, non-finite predictions still fail
    (rd / "endpoint.json").write_text(json.dumps(ep))
    torch.save(orig * float("inf"), pred)
    assert _py([tool, tmp_path / "res", tmp_path / "nf.json"]).returncode == 1


def test_recompute_compares_nonfinite_recorded_risks_correctly():
    from cop.analysis.recovery import same_value
    assert same_value("inf", "inf") and same_value("nan", float("nan")) and not same_value("inf", 1.0)
    assert same_value(1.0, 1.0 + 1e-9) and not same_value(1.0, 1.1) and not same_value("-inf", "inf")


# ----------------------------------------------------------------------------- v13: identity gate (audit A1)

def _audit_probe_graph(sign):
    """The v12 audit's real GraphNet counterexample: float64 output 1 for every x; float32 output depends on the
    sign of the last layer because (x + 1e8) - 1e8 loses x in float32."""
    from cop.graph.graph import GraphNet
    g = GraphNet("vec", "identity_probe")
    x = g.set_input("x", 1)

    def linear(inp, w, b):
        n = g.add_node("linear", [inp], {"in": 1, "out": 1, "dim": 1}, build=True)
        with torch.no_grad():
            g.mods[g.nodes[n].pkey].weight.fill_(w)
            g.mods[g.nodes[n].pkey].bias.fill_(b)
        return n
    a = linear(x, 1, 1e8)
    b = linear(a, 1, -1e8)
    err = g.add_node("add", [b, x], {"dim": 1, "coefs": [1.0, -1.0]})
    g.set_output(linear(err, sign, 1))
    return g


def test_audit_counterexample_cannot_be_labelled_exact():
    from cop.experiments import common as Cm
    pre, post = _audit_probe_graph(1.0), _audit_probe_graph(-1.0)
    X = {"audit": {"x": torch.tensor([[1.0], [2.0], [3.0]])}}
    chk = Cm.identity_check(pre, post, X, torch.float32, CRIT)
    r = chk["sets"]["audit"]
    assert r["a_high_precision"] == 0.0 and r["u_pre"] == r["u_post"] == 3.0      # equal magnitudes
    assert r["d_edit"] == pytest.approx(6.0) and r["o_observed"] == pytest.approx(6.0)
    assert chk["verdict"] == "execution_changed"


def _patched_errors(monkeypatch, err_pre, err_post):
    """Execution outputs = float64 outputs + a declared error vector (per example, column 0), pre and post."""
    from cop.experiments import common as Cm
    real = Cm._outs

    def outs(model, X, dtype, train_mode):
        y = real(model, X, torch.float64, train_mode)
        if dtype == torch.float64:
            return y
        e = torch.zeros_like(y)
        e[:, 0] = torch.tensor(err_post if getattr(model, "_is_post", False) else err_pre, dtype=y.dtype)
        return y + e * y.abs().mean()
    monkeypatch.setattr(Cm, "_outs", outs)


def _pre_post_exact():
    g = build_mlp(8, [16, 16], 3, torch_gen(0, "init"))
    post = g.clone(share_params=False)
    E.insert_residual_zero(post, E.cut_at(post, "post_act", "middle"), torch_gen(0, "insertion", "v13"), width=4)
    post._is_post = True
    return g, post


@pytest.fixture
def keep_post_tag(monkeypatch):
    from cop.graph.graph import GraphNet
    orig = GraphNet.clone

    def clone(self, *a, **k):
        h = orig(self, *a, **k)
        h._is_post = getattr(self, "_is_post", False)
        return h
    monkeypatch.setattr(GraphNet, "clone", clone)


def test_identity_gate_judges_the_change_in_execution_error_by_sign_and_location(monkeypatch, keep_post_tag):
    from cop.experiments import common as Cm
    pre, post = _pre_post_exact()
    X = {"s": {"x": torch.randn(4, 8, generator=torch.Generator().manual_seed(0))}}
    lim = Cm.IDENTITY_EDIT_ROUNDOFF_MAX_REL[torch.float32]
    big = 50 * lim
    # identical preexisting error (the lab case): exact, flagged
    _patched_errors(monkeypatch, [big, -big, big, 0.0], [big, -big, big, 0.0])
    chk = Cm.identity_check(pre, post, X, torch.float32, CRIT)
    assert chk["verdict"] == "exact" and chk["sets"]["s"]["d_edit"] == 0.0 and chk["preexisting_instability_sets"] == ["s"]
    # opposite errors of equal norm
    _patched_errors(monkeypatch, [big, 0, 0, 0], [-big, 0, 0, 0])
    r = Cm.identity_check(pre, post, X, torch.float32, CRIT)
    assert r["verdict"] == "execution_changed" and r["sets"]["s"]["u_pre"] == pytest.approx(r["sets"]["s"]["u_post"])
    # the maximum moves to another example
    _patched_errors(monkeypatch, [big, 0, 0, 0], [0, big, 0, 0])
    assert Cm.identity_check(pre, post, X, torch.float32, CRIT)["verdict"] == "execution_changed"
    # a small change below the fixed limit passes; just above it fails
    _patched_errors(monkeypatch, [0, 0, 0, 0], [0.5 * lim, 0, 0, 0])
    assert Cm.identity_check(pre, post, X, torch.float32, CRIT)["verdict"] == "exact"
    _patched_errors(monkeypatch, [0, 0, 0, 0], [2 * lim, 0, 0, 0])
    assert Cm.identity_check(pre, post, X, torch.float32, CRIT)["verdict"] == "execution_changed"
    # a genuine high-precision change is 'changed' whatever the execution errors are
    _patched_errors(monkeypatch, [big, 0, 0, 0], [big, 0, 0, 0])
    with torch.no_grad():
        next(p for n, p in post.named_parameters() if n.endswith("weight")).add_(1e-2)
    assert Cm.identity_check(pre, post, X, torch.float32, CRIT)["verdict"] == "changed"


def test_identity_gate_real_bitwise_identical_edit_with_preexisting_roundoff_passes():
    """The real lab situation without patching: a network whose float32 output carries large round-off
    ((x + 1e8) - 1e8 inside), edited by an exact residual-zero insertion, keeps bitwise identical float32
    outputs, so d_edit = 0 and the edit is exact with the set flagged."""
    from cop.experiments import common as Cm
    g = build_mlp(1, [1, 1], 1, torch_gen(0, "init"))
    lins = [n for n in g.topo_order() if g.nodes[n].op == "linear"]
    with torch.no_grad():
        for n, b in zip(lins, (1e8, -1e8, 1.0)):
            g.mods[g.nodes[n].pkey].weight.fill_(1.0)
            g.mods[g.nodes[n].pkey].bias.fill_(b)
    h = g.clone(share_params=False)
    E.insert_residual_zero(h, E.cut_at(h, "post_act", 1), torch_gen(0, "insertion", "v13l"), width=2)
    X = {"s": {"x": torch.tensor([[1.0], [2.0], [3.0]])}}
    chk = Cm.identity_check(g, h, X, torch.float32, CRIT)
    r = chk["sets"]["s"]
    assert r["u_pre"] == r["u_post"] > 0.1 and r["d_edit"] == 0.0 and r["o_observed"] == 0.0
    assert chk["verdict"] == "exact" and chk["preexisting_instability_sets"] == ["s"]


@CUDA
def test_cuda_identity_gate_dtypes():
    from cop.experiments import common as Cm
    pre, post = _audit_probe_graph(1.0).cuda(), _audit_probe_graph(-1.0).cuda()
    X = {"a": {"x": torch.tensor([[1.0], [2.0], [3.0]]).cuda()}}
    assert Cm.identity_check(pre, post, X, torch.float32, CRIT)["verdict"] == "execution_changed"
    g = build_mlp(8, [16, 16], 3, torch_gen(0, "init")).cuda()
    Xg = {"a": {"x": torch.randn(64, 8, generator=torch.Generator().manual_seed(0)).cuda()}}
    for dt in (torch.float32, torch.float64):
        g2 = g.clone(share_params=False).to(dt)
        h = g2.clone(share_params=False)
        E.insert_linear_factor(h, E.cut_at(h, "post_act", 1), torch_gen(0, "insertion", "cu"))
        assert Cm.identity_check(g2, h, Xg, dt, CRIT)["verdict"] == "exact", dt
