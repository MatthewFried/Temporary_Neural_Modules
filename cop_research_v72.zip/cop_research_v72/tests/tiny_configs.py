"""Tiny configs for every job kind (shared by the dev smoke script and tests)."""
from cop.config import resolve, run_id

DATA = {"name": "teacher", "n_train": 256, "n_val": 128, "n_test": 128,
        "params": {"teacher_depth": 1, "task": "regression", "d_in": 8, "out_dim": 3}}
DATA_C = {"name": "teacher", "n_train": 256, "n_val": 128, "n_test": 128,
          "params": {"teacher_depth": 1, "task": "classification", "d_in": 8, "out_dim": 4}}
MODEL = {"family": "mlp", "width": 16, "depth": 4}
TRAIN = {"baseline_updates": 30, "batch_size": 32, "eval_every": 10}


def base(data=DATA, model=MODEL, train=TRAIN, seed=0):
    return resolve({"kind": "baseline", "data": data, "model": model, "train": train, "seeds": {"optimizer": seed}})


def traj(growth, data=DATA, model=MODEL, train=TRAIN, seed=0, with_fc=True, deletion=None):
    b = base(data, model, train, seed)
    g = {"rounds": 2, "updates_per_round": 15, "width": 8, **growth}
    parents = {"baseline": run_id(b)}
    out = [b]
    if with_fc and g.get("topology", "none") != "none":
        fc = resolve({"kind": "trajectory", "data": data, "model": model, "train": {**train, "freeze": "none"},
                      "growth": {"topology": "none", "rounds": g["rounds"], "updates_per_round": g["updates_per_round"],
                                 "evaluate_deletions": False, "crossover": False},
                      "seeds": {"optimizer": seed}, "parents": {"baseline": run_id(b)}})
        out.append(fc)
        parents["continued"] = run_id(fc)
    cfg = {"kind": "trajectory", "data": data, "model": model, "train": train, "growth": g,
           "seeds": {"optimizer": seed}, "parents": parents}
    if deletion:
        cfg["deletion"] = deletion
    out.append(resolve(cfg))
    return out


def child(kind, parent_cfg, section, seeds_over=None, tags=None):
    pc = parent_cfg
    cfg = {"kind": kind, "data": pc["data"], "model": pc["model"], "train": pc["train"], "growth": pc["growth"],
           "seeds": {**pc["seeds"], **(seeds_over or {})}, "parents": {"trajectory": run_id(pc)}, **section}
    if tags:
        cfg["tags"] = tags
    return resolve(cfg)


def cop(copsec, peg=None, data=DATA, model=None, train=TRAIN, seed=0, parents=None):
    model = model or {"family": "mlp", "width": 16, "depth": 6}
    b = base(data, model, train, seed)
    c = {"kind": "cop", "data": data, "model": model, "train": train,
         "peg": {"dim": 4, "anneal_updates": 5, **(peg or {})},
         "cop": {"n_pearls": 4, "local_updates": 12, "global_updates": 20, "pearl_width": 16, "grow_width": 8,
                 "replace_width": 4, **copsec},
         "seeds": {"optimizer": seed}, "parents": {"baseline": run_id(b), **(parents or {})}}
    return [b, resolve(c)]
