"""v65 test helper: a miniature of a real wave, built from the wave's own manifest entries for one data draw and
optimizer seed.  Every update count is scaled by k = U_small / U (fork points, snapshots, removal and repair
lengths, compact segments and their evaluation points), the data is made small (the image task on its synthetic toy
base; the shortcut task with a small training set), the model can be narrowed, and each configuration is resolved
again with its parents re-pointed to the miniature's run ids.  The design (arms, forks, continuations, holds,
methods, masks) is the wave's own."""
from __future__ import annotations

import json
from pathlib import Path

from cop.config import resolve, run_id

TOY_IMG = {"base": "toy", "positive_classes": [1], "negative_classes": [0], "n_val": 96, "n_cf": 64,
           "toy_pool": 260, "toy_test": 120, "toy_hw": [12, 10]}


def _scale(u, k):
    return max(1, int(round(int(u) * k)))


def _stage(st: str, k) -> str:
    if st.startswith("snap_"):
        return f"snap_{_scale(st.split('_')[1], k)}"
    return st


def shrink(entries: dict, draw: int, seed: int, U: int, U_small: int, data_over: dict, model_over: dict) -> list:
    """the miniature of the wave's jobs of one f0 (data draw, optimizer seed), parents first."""
    k = U_small / U
    mine = {r: e["cfg"] for r, e in entries.items()
            if e["cfg"]["data"]["data_seed"] == draw and (e["cfg"].get("seeds") or {}).get("optimizer") == seed}
    order, seen = [], set()

    def visit(r):
        if r in seen:
            return
        for p in (mine[r].get("parents") or {}).values():
            visit(p)
        seen.add(r)
        order.append(r)
    for r in sorted(mine):
        visit(r)
    ids, out = {}, []
    for r in order:
        c = json.loads(json.dumps(mine[r]))
        c["data"] = {**c["data"], **data_over.get("top", {}),
                     "params": {**c["data"]["params"], **data_over.get("params", {})}}
        c["model"] = {**c["model"], **model_over}
        t = c["train"]
        t["baseline_updates"] = _scale(t["baseline_updates"], k)
        t["eval_every"] = max(1, _scale(t["eval_every"], k))
        if t.get("snapshot_at"):
            t["snapshot_at"] = sorted({_scale(u, k) for u in t["snapshot_at"]})
        if c.get("growth"):
            c["growth"]["updates_per_round"] = U_small
        if c.get("dissipation"):
            dc = c["dissipation"]
            for key in ("speed_updates", "post_updates"):
                if int(dc.get(key, 0) or 0):
                    dc[key] = _scale(dc[key], k)
            dc["early_eval"] = sorted({_scale(u, k) for u in dc.get("early_eval") or []})
        if c.get("continue"):
            cc = c["continue"]
            if cc.get("segments"):
                cc["segments"] = [_scale(u, k) for u in cc["segments"]]
            if cc.get("eval_at"):
                cc["eval_at"] = sorted({_scale(u, k) for u in cc["eval_at"]})
        if (c.get("tags") or {}).get("parent_stage"):
            c["tags"]["parent_stage"] = _stage(c["tags"]["parent_stage"], k)
        d = c.get("design") or {}
        if "@" in str(d.get("variant", "")):
            v, _, st = d["variant"].partition("@")
            d["variant"] = f"{v}@{_stage(st, k)}"
        if c.get("parents"):
            c["parents"] = {kk: ids[v] for kk, v in c["parents"].items()}
        for key in ("wave", "block"):
            c.pop(key, None)
        c = resolve({**c, "wave": entries[r]["cfg"].get("wave", 0), "block": entries[r]["cfg"].get("block", "")})
        ids[r] = run_id(c)
        out.append(c)
    return out


def run_all(cfgs: list, d: Path, device: str = "cpu") -> None:
    from cop.orchestration.runner import run_job, status_of
    for c in cfgs:
        st = run_job(c, d, {"device": device})
        assert st == "complete", (c["kind"], (c.get("design") or {}).get("variant"),
                                  (c.get("design") or {}).get("arm"), status_of(d, run_id(c)).get("reason"))


def write_manifest(path: Path, cfgs: list) -> Path:
    with open(path, "w") as f:
        for c in cfgs:
            f.write(json.dumps({"run_id": run_id(c), "cfg": c, "deps": sorted(set((c.get("parents") or {}).values())),
                                "blocks": [c.get("block", "")], "wp": c.get("wp", []), "wave": c.get("wave")}) + "\n")
    return path
