"""v66: a registry bound to one analysis's coverage (for the miniatures): the contract reads that coverage's schema,
design, and the given draws and seeds."""
from __future__ import annotations

import json
from pathlib import Path


def bind(reg: dict, coverage: Path, draws, seeds, renames: dict | None = None) -> dict:
    cov = json.loads(Path(coverage).read_text())
    r = json.loads(json.dumps(reg))
    for h in r["hypotheses"]:
        h["fork"] = (renames or {}).get(h["fork"], h["fork"])
    r["contract"] = {"analysis_schemas": [cov["analysis_schema"]], "data_draws": list(draws),
                     "optimizer_seeds": list(seeds), "design": cov["design"]}
    return r


def draw_seed(contrasts: Path) -> tuple:
    import csv
    rows = list(csv.DictReader(open(contrasts)))
    return sorted({int(r["data_draw"]) for r in rows}), sorted({int(r["optimizer_seed"]) for r in rows})
